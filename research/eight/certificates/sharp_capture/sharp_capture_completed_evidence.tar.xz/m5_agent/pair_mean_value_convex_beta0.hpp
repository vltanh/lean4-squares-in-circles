// Optional convex-width extension of the frozen beta=0 mean-value bound.
// Uses only the already audited rational-coefficient helpers from the
// charged header; the cost endpoint here is the exact affine beta=0 one.
bool mean_value_reject_convex_beta0(const Segment& sa,const Segment& sb,const PairBox& b,
                                   const Algebra& g,I gamma,Integer hi,unsigned checked_axes,
                                   Integer& worst) {
    if(hi<DMIN.lo){worst=-1;return true;}
    const Integer guard=SCALE+SCALE/1000000000;
    if(b.x.lo<0||b.y.lo<0||b.x.hi>guard||b.y.hi>guard)return false;
    if(Wide(sa.increment.lo)<-16*Wide(sa.step.lo)||Wide(sa.increment.hi)>16*Wide(sa.step.lo)||
       Wide(sb.increment.lo)<-16*Wide(sb.step.lo)||Wide(sb.increment.hi)>16*Wide(sb.step.lo))return false;
    I cut=rational(6,7);
    if((IS_CORE[sa.type]&&b.x.lo<cut.hi&&b.x.hi>cut.lo&&b.x.hi-b.x.lo>SCALE/100) ||
       (IS_CORE[sb.type]&&b.y.lo<cut.hi&&b.y.hi>cut.lo&&b.y.hi-b.y.lo>SCALE/100))return false;
    D x{b.x,rational(1),rational(0)},y{b.y,rational(0),rational(1)};
    D endpoint=D(gamma)+affine_potential(sa,x)-affine_potential(sb,y);
    if(endpoint.v.lo< -5*SCALE/2||endpoint.v.hi>5*SCALE/2)return false;
    Integer upper=std::max(hi,endpoint.v.hi);
    if(upper>5*SCALE/2)return false;
    TrigSpan span{I(DMIN.lo,upper),point_trig(DMIN.lo),point_trig(upper)};
    Integer mx=b.x.lo+(b.x.hi-b.x.lo)/2,my=b.y.lo+(b.y.hi-b.y.lo)/2;
    I xoffset(b.x.lo-mx,b.x.hi-mx),yoffset(b.y.lo-my,b.y.hi-my);
    EndpointSAT box=endpoint_sat(sa,sb,b.x,b.y,gamma);
    EndpointSAT center=endpoint_sat(sa,sb,point(mx),point(my),gamma);
    Integer all=INT64_MIN;
    for(int axis=0;axis<4;++axis)for(int sign:{-1,1}){
        unsigned index=axis+(sign<0?4:0);
        if(!(checked_axes&(1u<<index)))continue;
        Integer best=INT64_MAX;
        for(int sc:{-1,1}){
            for(int ss:{-1,1}){
                best=std::min(best,charged_majorant_bound(g,box,center,span,xoffset,yoffset,
                                                          axis,sign,rational(sc),rational(ss)));
                if(best<0)break;
            }
            if(best<0)break;
        }
        if(best>=0){
            for(int selector:{0,1}){
                for(int fixed:{-1,1}){
                    const D& fixed_term=selector?center.Qs:center.Qc;
                    const D& variable_term=selector?center.Qc:center.Qs;
                    D numerator=D(rational(2*sign))*center.P[axis]-center.Z-D(rational(fixed))*fixed_term;
                    auto coefficient=choose_width_coefficient(numerator,variable_term,xoffset,yoffset);
                    if(!coefficient)continue;
                    I sc=selector?*coefficient:rational(fixed),ss=selector?rational(fixed):*coefficient;
                    best=std::min(best,charged_majorant_bound(g,box,center,span,xoffset,yoffset,
                                                              axis,sign,sc,ss));
                    if(best<0)break;
                }
                if(best<0)break;
            }
        }
        if(best>=0)return false;
        all=std::max(all,best);
    }
    worst=all;return all<0;
}
