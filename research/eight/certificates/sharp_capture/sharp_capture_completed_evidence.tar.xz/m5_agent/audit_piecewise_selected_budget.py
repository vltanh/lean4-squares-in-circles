"""Audit an exact selected-axis piece cover and its full-SAT composition.

Usage: python audit_piecewise_selected_budget.py MANIFEST EXE DATA HEADER SOURCE

Each recorded log is one genuine executable invocation for one closed
affine-piece rectangle. The separately checked complementary owner cover
supplies every omitted signed SAT axis at a stronger pair-cost threshold.
Only after that union is established does this script infer a cyclic budget.
Global coverage of the declared role domains remains a separate theorem.
"""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
manifest_path, executable, data, header, source = map(Path, sys.argv[1:6])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads(manifest_path.read_text())
j = json.loads(data.read_text())
assert m['status'] == 'ALL DECLARED PIECES PASSED'
assert j['certificate_kind'] == 'selected_axis_budget'
source_hashes = {'verify_boundary_pair_costs_sharp_masked.cpp': '3919b795b4df6ef2049f71674da64e880b3e336e7d981934e599f654782cb57c', 'verify_boundary_pair_costs_sharp_masked_mvt.cpp': 'e825397e3c00b46a3c6db7b1e79d05e241c1a0d3b605e1e88e81d0608652d080', 'verify_boundary_pair_costs_sharp_masked_mvt_charged.cpp': '151a6655c7ec837bcab59b92b5fe21935b23b33147288d962dfd1e78c132eea0'}
assert source.name in source_hashes and sha(source) == source_hashes[source.name]
charged = source.name.endswith('_mvt_charged.cpp')
mean_value = charged or source.name.endswith('_mvt.cpp')
assert m['runner_filename'] == ('run_piecewise_charged_boundary_pair_costs.py' if charged else 'run_piecewise_mvt_boundary_pair_costs.py' if mean_value else 'run_piecewise_boundary_pair_costs.py')
paths = {
    'executable_sha256': executable,
    'data_json_sha256': data,
    'data_header_sha256': header,
    'source_sha256': source,
    'arithmetic_source_sha256': ROOT/'exact_dyadic_base.cpp',
    'runner_sha256': ROOT/m['runner_filename'],
}
assert ('mean_value_header_sha256' in m) == mean_value
if mean_value:
    paths['mean_value_header_sha256'] = ROOT/'pair_mean_value_beta0.hpp'
assert ('charged_mean_value_header_sha256' in m) == charged
if charged:
    paths['charged_mean_value_header_sha256'] = ROOT/'pair_mean_value_charged.hpp'
for key, path in paths.items():
    assert sha(path) == m[key], (key, str(path))
assert m['inputs_unchanged_during_run'] is True
assert Fraction(*j['core_radius']) == Fraction(1, 12)

with tempfile.TemporaryDirectory() as tmp:
    regenerated = Path(tmp)/'data.hpp'
    subprocess.run([sys.executable, str(ROOT/'make_selected_budget_pair_data_header.py'),
                    str(data), str(regenerated)], check=True,
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert regenerated.read_bytes() == header.read_bytes()
dynamic = subprocess.run(['readelf', '-d', str(executable)], check=True,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout
assert 'libubsan' in dynamic

N, K = len(j['types']), j['K']
pairs, signs = j['required_pairs'], j['allowed_signs']
assert N == 7 and type(K) is int and 1 <= K <= 256
assert pairs == [[a, (a+1) % 7] for a in range(7)]
assert len(signs) == N
assert all(s and len(s) == len(set(s)) and
           all(type(v) is int and v in (-1, 1) for v in s) for s in signs)
branches = {(a, b, s, t) for a, b in pairs for s in signs[a] for t in signs[b]}
expected = {branch+(ap, bp) for branch in branches for ap in range(K) for bp in range(K)}
assert m['K'] == K and m['required_pairs'] == pairs and m['allowed_signs'] == signs
assert len(m['branches']) == len(branches) and set(map(tuple, m['branches'])) == branches
assert m['expected_piece_count'] == len(expected)
assert len(m['results']) == len(expected)
assert {tuple(r['job']) for r in m['results']} == expected

piece_re = re.compile(r'PIECE (-?\d+) (-?\d+) (-?\d+) (-?\d+) (\d+) (\d+) nodes=(\d+) total=(\d+)')
summary_re = re.compile(r'VERIFIED (-?\d+) (-?\d+) (-?\d+) (-?\d+) nodes=(\d+) leaves=(\d+) depth=(\d+) margin_upper=(-?\d+)/281474976710656 seconds=([\d.eE+-]+)')
nodes = leaves = deepest = 0
margins = []
for r in m['results']:
    job = tuple(r['job'])
    path = manifest_path.parent/('_'.join(map(str, job))+'.log')
    assert r['returncode'] == 0 and r['complete'] is True and sha(path) == r['sha256']
    lines = path.read_text().splitlines()
    assert len(lines) == 2
    p, s = piece_re.fullmatch(lines[0]), summary_re.fullmatch(lines[1])
    assert p and s
    assert tuple(map(int, p.groups()[:6])) == job
    assert tuple(map(int, s.groups()[:4])) == job[:4]
    n, l, d, margin = map(int, s.groups()[4:8])
    assert n > 0 and n % 2 == 1 and l > 0
    assert n == int(p[7]) == int(p[8]) == 2*l-1
    assert margin < 0
    seconds = float(s[9])
    assert math.isfinite(seconds) and seconds >= 0
    nodes += n
    leaves += l
    deepest = max(deepest, d)
    margins.append(margin)
assert nodes == 2*leaves-len(expected)

def sibling_file(filename):
    assert Path(filename).name == filename
    return data.parent/filename

base_path = sibling_file(j['base_budget_filename'])
assert sha(base_path) == j['base_budget_sha256']
base = json.loads(base_path.read_text())
owner_path = sibling_file(j['complementary_owner_data_filename'])
assert sha(owner_path) == j['complementary_owner_data_sha256']
owner = json.loads(owner_path.read_text())
owner_relative = Path(j['complementary_manifest_relpath'])
assert not owner_relative.is_absolute() and '..' not in owner_relative.parts
owner_manifest = data.parent/owner_relative
assert sha(owner_manifest) == j['complementary_manifest_sha256']

same_geometry = [
    'Q', 'core_radius', 'K', 'types', 'is_core', 'positive_domains',
    'allowed_signs', 'psi_numerators', 'psi_negative_numerators',
    'psi_denominator', 'required_pairs', 'beta_by_edge',
]
for key in same_geometry:
    assert j[key] == base[key] == owner[key], ('Geometric/cost premise differs', key)
assert j['gamma_denominator'] == base['gamma_denominator']
assert j['gamma_numerators'] == base['gamma_numerators']
assert j['allowed_cyclic_deficit'] == base['allowed_cyclic_deficit']
assert owner['base_budget_filename'] == j['base_budget_filename']
assert owner['base_budget_sha256'] == j['base_budget_sha256']
assert owner['certificate_kind'] == 'wrong_axis_exclusion'
checked, complementary = j['checked_axes_by_edge'], owner['checked_axes_by_edge']
assert len(checked) == len(complementary) == len(pairs)
assert checked == owner['allowed_axes_by_edge']
for c, d in zip(checked, complementary):
    assert c and d and len(c) == len(set(c)) and len(d) == len(set(d))
    assert set(c).isdisjoint(d) and set(c) | set(d) == set(range(8))
owner_excess = Fraction(*owner['per_edge_excess_upper'])
assert owner_excess > 0
for a, b in pairs:
    threshold = Fraction(j['gamma_numerators'][a][b], j['gamma_denominator'])
    stronger = Fraction(owner['gamma_numerators'][a][b], owner['gamma_denominator'])
    assert stronger == threshold+owner_excess

# Re-audit the entire complementary execution; a previous status label alone
# cannot establish the omitted axes. Its ordinary audit also regenerates the
# owner's header and rechecks every original branch and all input hashes.
assert owner_path.name.endswith('_pair_data.json')
owner_stem = owner_path.name[:-len('_pair_data.json')]
owner_header = owner_path.with_suffix('.hpp')
owner_build = json.loads((data.parent/(owner_stem+'_build.json')).read_text())
assert Path(owner_build['data']).resolve() == owner_path.resolve()
assert Path(owner_build['header']).resolve() == owner_header.resolve()
owner_source=ROOT/'verify_boundary_pair_costs_sharp_masked.cpp'
assert Path(owner_build['source']).resolve() == owner_source.resolve()
assert owner_build['source_sha256'] == sha(owner_source) == source_hashes[owner_source.name]
owner_executable = Path(owner_build['executable'])
subprocess.run([sys.executable, str(ROOT/'audit_boundary_pair_manifest.py'),
                str(owner_manifest), str(owner_executable), str(owner_path),
                str(owner_header), str(owner_source)], check=True,
               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
owner_aggregate = json.loads((owner_manifest.parent/'aggregate.json').read_text())
assert owner_aggregate['manifest_sha256'] == sha(owner_manifest)
assert owner_aggregate['scope'] == 'Only the checked signed SAT axes below each declared pair-cost threshold.'

# The union now proves the full-SAT lower bound at every edge, independently
# of the total cyclic sum. Only here is the physical holonomy used.
total = sum(Fraction(j['gamma_numerators'][a][b], j['gamma_denominator']) for a, b in pairs)
assert total == Fraction(*j['cost_sum']) == Fraction(*base['cost_sum'])
deficit = Fraction(*j['allowed_cyclic_deficit'])
comparison = Fraction(*j['twice_pi_upper'])
sharp_upper = Fraction(6283185307179586476925286766559006, 10**33)
assert comparison == Fraction(*base['twice_pi_upper']) and comparison >= sharp_upper
assert deficit > 0 and total+deficit > comparison
# The strict total residual bound is also the per-edge residual bound.
# To infer that a complementary separating axis is impossible, its
# separately certified excess must dominate that allowed total deficit.
assert owner_excess >= deficit
charges = [Fraction(*v) for v in j['beta_by_edge']]
assert len(charges) == len(pairs) and all(0 <= b < 2 for b in charges)

ratio = lambda x: [x.numerator, x.denominator]
result = {
    'status': 'COMPLETE PIECE COVER AND COMPLEMENTARY FULL-SAT BUDGET CHECKED',
    'scope': 'Full signed SAT on exactly the role domains and signs in the bound data; global domain coverage is a separate theorem.',
    'manifest_sha256': sha(manifest_path),
    'partition': 'One genuine exact executable invocation per closed affine-piece rectangle.',
    'branches': len(branches),
    'initial_rectangles': len(expected),
    'nodes': nodes,
    'terminal_rectangles': leaves,
    'maximum_depth': deepest,
    'maximum_recorded_scaled_margin_upper_numerator': max(margins),
    'scale': 2**48,
    'empty_domain_sentinel_note': '-1 may denote an already empty cost-failure gap domain.',
    'header_regenerated_byte_identically': True,
    'ubsan_runtime_linked': True,
    'checked_axes_by_edge': checked,
    'complementary_axes_by_edge': complementary,
    'base_budget_sha256': sha(base_path),
    'complementary_data_sha256': sha(owner_path),
    'complementary_manifest_sha256': sha(owner_manifest),
    'complementary_full_cover_reaudited': True,
    'complementary_initial_rectangles': owner_aggregate['initial_rectangles'],
    'complementary_nodes': owner_aggregate['nodes'],
    'directed_seven_edge_sum': ratio(total),
    'twice_pi_upper': ratio(comparison),
    'allowed_cyclic_deficit': ratio(deficit),
    'reserve_after_allowed_deficit': ratio(total+deficit-comparison),
    'edge_width_charges': j['beta_by_edge'],
    'consequence': 'At physical holonomy 2pi, the sum of beta_edge times width excess is strictly less than the declared cyclic deficit. The complementary stronger pair bounds and this deficit also force every separating axis to lie in the selected set.',
    'noncircular_composition': 'Each selected axis has cost at least gamma; every complementary axis has the separately certified cost at least gamma plus a positive excess. Their union proves the full-SAT gamma bound before any cyclic sum is used.',
}
if mean_value:
    result['mean_value_header_sha256'] = m['mean_value_header_sha256']
    result['optional_mean_value_rejection'] = 'Beta=0 only; original interval rejection retained as fallback.'
if charged:
    result['charged_mean_value_header_sha256'] = m['charged_mean_value_header_sha256']
    result['optional_charged_mean_value_rejection'] = 'Exact union of four smooth signed-cost sublevel sets, with rational convex SAT width majorants; original interval rejection retained as fallback.'
(manifest_path.parent/'aggregate.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
