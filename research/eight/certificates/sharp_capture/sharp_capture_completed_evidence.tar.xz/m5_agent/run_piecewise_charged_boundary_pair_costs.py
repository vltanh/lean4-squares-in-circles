"""Check every closed affine-piece rectangle in separate exact invocations.

Usage: python run_piecewise_charged_boundary_pair_costs.py EXE DATA HEADER SOURCE OUT [WORKERS]
Each immutable per-piece log is genuine executable output. No synthetic
whole-branch executable output is produced. Only the complete final
manifest can support a proof that covers the declared role domains.
"""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
exe,data,header,source,out=map(Path,sys.argv[1:6])
workers=int(sys.argv[6]) if len(sys.argv)>6 else 4
assert source.name=='verify_boundary_pair_costs_sharp_masked_mvt_charged.cpp'
j=json.loads(data.read_text())
N,K=len(j['types']),j['K']
pairs=j['required_pairs'];signs=j['allowed_signs']
assert 1<=K<=256 and workers>0 and len(signs)==N
assert len(set(map(tuple,pairs)))==len(pairs)
assert all(0<=a<N and 0<=b<N for a,b in pairs)
assert all(s and len(s)==len(set(s)) and set(s)<=set((-1,1)) for s in signs)
branches=[(a,b,s,t) for a,b in pairs for s in signs[a] for t in signs[b]]
# Interleaving the branches exposes difficult contacts from every edge early.
jobs=[branch+(ap,bp) for ap in range(K) for bp in range(K) for branch in branches]
assert len(jobs)==len(set(jobs))
out.mkdir(parents=True,exist_ok=False)
paths={'executable_sha256':exe,'data_json_sha256':data,'data_header_sha256':header,
       'source_sha256':source,'arithmetic_source_sha256':ROOT/'exact_dyadic_base.cpp',
       'mean_value_header_sha256':ROOT/'pair_mean_value_beta0.hpp',
       'charged_mean_value_header_sha256':ROOT/'pair_mean_value_charged.hpp',
       'runner_sha256':Path(__file__)}
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bound={key:digest(p) for key,p in paths.items()}
piece_re=re.compile(r'PIECE (-?\d+) (-?\d+) (-?\d+) (-?\d+) (\d+) (\d+) nodes=(\d+) total=(\d+)')
summary_re=re.compile(r'VERIFIED (-?\d+) (-?\d+) (-?\d+) (-?\d+) nodes=(\d+) leaves=(\d+) depth=(\d+) margin_upper=(-?\d+)/281474976710656 seconds=([\d.eE+-]+)')
def run(job):
    path=out/('_'.join(map(str,job))+'.log')
    start=time.monotonic()
    with path.open('x') as stream:
        p=subprocess.run([str(exe),*map(str,job)],stdout=stream,stderr=subprocess.STDOUT)
    lines=path.read_text().splitlines()
    a=piece_re.fullmatch(lines[0]) if len(lines)==2 else None
    b=summary_re.fullmatch(lines[1]) if len(lines)==2 else None
    complete=bool(a and b and tuple(map(int,a.groups()[:6]))==job
                  and tuple(map(int,b.groups()[:4]))==job[:4]
                  and int(a[7])==int(a[8])==int(b[5])==2*int(b[6])-1
                  and int(b[8])<0)
    record={'job':job,'returncode':p.returncode,'complete':complete,
            'seconds':time.monotonic()-start,'sha256':digest(path)}
    if p.returncode or not complete:
        print('FAILED',json.dumps(record),'tail='+str(lines[-2:]),flush=True)
    return record
start=time.monotonic();results=[]
with ThreadPoolExecutor(max_workers=workers) as pool:
    for future in as_completed([pool.submit(run,job) for job in jobs]):
        results.append(future.result())
        if len(results)%100==0 or len(results)==len(jobs):
            progress={'completed':len(results),'expected':len(jobs),
                      'failed':sum(r['returncode']!=0 or not r['complete'] for r in results),
                      'seconds':time.monotonic()-start}
            (out/'progress.json').write_text(json.dumps(progress,indent=2)+'\n')
            print('PROGRESS',json.dumps(progress),flush=True)
unchanged=all(digest(p)==bound[key] for key,p in paths.items())
ok=unchanged and len(results)==len(jobs) and all(r['returncode']==0 and r['complete'] for r in results)
manifest={'status':'ALL DECLARED PIECES PASSED' if ok else 'INCOMPLETE/FAILED',
          'partition':'One exact executable invocation for every closed affine-piece rectangle.',
          'K':K,'required_pairs':pairs,'allowed_signs':signs,'branches':branches,
          'expected_piece_count':len(jobs),'inputs_unchanged_during_run':unchanged,
          'runner_filename':Path(__file__).name,**bound,
          'results':sorted(results,key=lambda r:r['job'])}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(manifest['status'],flush=True)
raise SystemExit(0 if ok else 1)
