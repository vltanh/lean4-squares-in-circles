"""Generate a data header with an exact configurable rational disk ceiling.

The base header format is unchanged. Q is a pair of integers representing
a rational in [3,4], with denominator at most 10^21. Its numerator and
denominator are emitted as exact signed128-bit integer expressions.
"""
from pathlib import Path
from fractions import Fraction
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
data, output = map(Path, sys.argv[1:3])
j = json.loads(data.read_text())
q = Fraction(*j['Q'])
assert 3 <= q <= 4 and q.denominator <= 10**21

def wide(n):
    assert 0 <= n <= 4*10**21
    high, low = divmod(n, 10**18)
    return f'(Wide({high})*1000000000000000000+{low})'

subprocess.run([sys.executable, str(ROOT/'make_pair_data_header.py'),
                str(data), str(output)], check=True)
prefix = ('// Rational disk ceiling; exact before dyadic outward rounding.\n'
          '#define PAIR_CONFIGURABLE_Q 1\n'
          f'constexpr Wide PAIR_Q_NUM={wide(q.numerator)};\n'
          f'constexpr Wide PAIR_Q_DEN={wide(q.denominator)};\n')
output.write_text(prefix+output.read_text())
