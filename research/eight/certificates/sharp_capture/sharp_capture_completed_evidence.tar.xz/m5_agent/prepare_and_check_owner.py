"""Normalize an owner input, check its complement, then prepare budget data.

Usage: python prepare_and_check_owner.py PREFIX ORIGINAL_BUDGET ORIGINAL_OWNER
Original discovery files are never modified. A complete exact owner result
is required before the selected budget input binds its manifest hash.
"""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
prefix=sys.argv[1]
original_budget,original_owner=map(lambda p:Path(p).resolve(),sys.argv[2:4])
assert prefix and all(c.isalnum() or c=='_' for c in prefix)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base_path=ROOT/(prefix+'_budget_pair_data.json')
owner_path=ROOT/(prefix+'_owner_pair_data.json')
selected_path=ROOT/(prefix+'_selected_budget_pair_data.json')
assert not any(p.exists() for p in (base_path,owner_path,selected_path))
shutil.copyfile(original_budget,base_path)
base=json.loads(base_path.read_text());owner=json.loads(original_owner.read_text())
owner['certificate_kind']='wrong_axis_exclusion'
owner['status']='FROZEN INPUT FOR EXACT COMPLEMENTARY AXIS CHECK; complete cover required'
owner['checked_axes_by_edge']=owner.get('checked_axes_by_edge',owner.get('checked_axes'))
owner['allowed_axes_by_edge']=owner.get('allowed_axes_by_edge',owner.get('allowed_axes'))
owner['per_edge_excess_upper']=owner.get('per_edge_excess_upper',owner.get('pair_excess_upper'))
owner['base_budget_filename']=base_path.name
owner['base_budget_sha256']=sha(base_path)
owner['normalized_from']=str(original_owner)
owner['normalized_from_sha256']=sha(original_owner)
for key in ['Q','core_radius','K','types','is_core','positive_domains','allowed_signs',
            'psi_numerators','psi_negative_numerators','psi_denominator',
            'required_pairs','beta_by_edge']:
    assert owner[key]==base[key],key
excess=Fraction(*owner['per_edge_excess_upper'])
assert excess>=Fraction(*base['allowed_cyclic_deficit'])>0
for a,b in base['required_pairs']:
    assert (Fraction(owner['gamma_numerators'][a][b],owner['gamma_denominator']) ==
            Fraction(base['gamma_numerators'][a][b],base['gamma_denominator'])+excess)
for a,b in zip(owner['checked_axes_by_edge'],owner['allowed_axes_by_edge']):
    assert set(a)|set(b)==set(range(8)) and not set(a)&set(b)
owner_path.write_text(json.dumps(owner,indent=2)+'\n')
header=owner_path.with_suffix('.hpp')
subprocess.run([sys.executable,str(ROOT/'make_masked_pair_data_header.py'),str(owner_path),str(header)],check=True)
source=ROOT/'verify_boundary_pair_costs_sharp_masked.cpp'
assert sha(source)=='3919b795b4df6ef2049f71674da64e880b3e336e7d981934e599f654782cb57c'
name=prefix+'_owner';exe=Path('/tmp')/('verify_'+name+'_pairs')
cmd=['g++','-O3','-std=c++17','-fsanitize=undefined','-fno-sanitize-recover=all',
     '-DPAIR_DATA_FILE="'+header.name+'"',str(source),'-o',str(exe)]
subprocess.run(cmd,check=True)
published=ROOT/(name+'_pair_logs_checked')
assert not published.exists()
out=Path(tempfile.mkdtemp(prefix='n8_m5_'+name+'_',dir='/tmp'))/'pair_logs'
build={'data':str(owner_path),'header':str(header),'source':str(source),
       'source_sha256':sha(source),'executable':str(exe),'build_argv':cmd,
       'staged_output':str(out),'original':str(original_owner),'original_sha256':sha(original_owner)}
(ROOT/(name+'_build.json')).write_text(json.dumps(build,indent=2)+'\n')
r=subprocess.run([sys.executable,str(ROOT/'run_restricted_boundary_pair_costs.py'),
                  str(exe),str(owner_path),str(header),str(out),'2','--source',str(source)])
if r.returncode==0:
    subprocess.run([sys.executable,str(ROOT/'audit_boundary_pair_manifest.py'),
                    str(out/'manifest.json'),str(exe),str(owner_path),str(header),str(source)],check=True)
shutil.copytree(out,published)
if r.returncode:
    raise SystemExit(r.returncode)
subprocess.run([sys.executable,str(ROOT/'audit_boundary_pair_manifest.py'),
                str(published/'manifest.json'),str(exe),str(owner_path),str(header),str(source)],check=True)
selected=dict(base)
selected.update(status='CANDIDATE SELECTED-AXIS BUDGET: complete piece cover and complementary composition required',
                certificate_kind='selected_axis_budget',
                checked_axes_by_edge=owner['allowed_axes_by_edge'],
                base_budget_filename=base_path.name,base_budget_sha256=sha(base_path),
                complementary_owner_data_filename=owner_path.name,
                complementary_owner_data_sha256=sha(owner_path),
                complementary_manifest_relpath=str(published.relative_to(ROOT)/'manifest.json'),
                complementary_manifest_sha256=sha(published/'manifest.json'))
selected_path.write_text(json.dumps(selected,indent=2)+'\n')
print('PREPARED SELECTED BUDGET INPUT',selected_path,flush=True)
