"""Index the four completed full-SAT terminal budget/owner compositions.
The role-domain cover and geometric terminal implications remain separate.
"""
from pathlib import Path
from fractions import Fraction
import hashlib,json
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
items=[('long_two_core','long_local_selected_budget_v1_charged'),
       ('all_outer','all_outer_terminal_v1_selected_budget'),
       ('one_core_t','one_core_t_terminal_v1_selected_budget'),
       ('one_core_g','one_core_g_terminal_v1_selected_budget')]
records=[]
for case,name in items:
    build_path=ROOT/(name+'_build.json')
    b=json.loads(build_path.read_text())
    folder=ROOT/(name+'_piece_logs_checked')
    manifest,aggregate=folder/'manifest.json',folder/'aggregate.json'
    m,a=json.loads(manifest.read_text()),json.loads(aggregate.read_text())
    assert a['status']=='COMPLETE PIECE COVER AND COMPLEMENTARY FULL-SAT BUDGET CHECKED'
    assert sha(manifest)==a['manifest_sha256']
    data=Path(b['data']);j=json.loads(data.read_text())
    assert sha(data)==m['data_json_sha256']
    total=Fraction(*a['directed_seven_edge_sum'])
    deficit=Fraction(*a['allowed_cyclic_deficit'])
    upper=Fraction(*a['twice_pi_upper'])
    assert total+deficit>upper
    records.append({'case':case,'name':name,'manifest':str(manifest),
                    'manifest_sha256':sha(manifest),'aggregate':str(aggregate),
                    'data':str(data),'data_sha256':sha(data),'header':b['header'],
                    'source':b['source'],'executable':b['executable'],
                    'build':str(build_path),'Q':j['Q'],
                    'types':j['types'],'is_core':j['is_core'],
                    'positive_domains':j['positive_domains'],
                    'allowed_signs':j['allowed_signs'],
                    **{k:a[k] for k in ['branches','initial_rectangles','nodes',
                    'terminal_rectangles','maximum_depth','checked_axes_by_edge',
                    'complementary_manifest_sha256','complementary_data_sha256',
                    'base_budget_sha256','directed_seven_edge_sum','twice_pi_upper',
                    'allowed_cyclic_deficit','reserve_after_allowed_deficit','edge_width_charges',
                    'noncircular_composition','scope','consequence']}})
out={'status':'FOUR COMPLETED FULL-SAT TERMINAL BUDGET AND OWNER COMPOSITIONS',
     'warning':'Only the declared role domains are covered; ordinary finite covers and terminal hand geometry are separate proof gates.',
     'count':len(records),'records':records}
(ROOT/'completed_terminal_budget_registry.json').write_text(json.dumps(out,indent=2)+'\n')
print('Indexed',len(records),'complete terminal budget/owner compositions')
