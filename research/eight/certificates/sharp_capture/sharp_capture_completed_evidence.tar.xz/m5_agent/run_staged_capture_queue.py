"""Build, fully check, and audit independent frozen capture candidates.

Usage: python run_staged_capture_queue.py QUEUE_JSON RESULTS_JSON [WORKERS] [SOURCE] [RUNNER]
The queue contains {name, original} records. Existing exact data/header files
must match their originals; existing run directories are never overwritten.
One failed candidate does not prevent checking the other declared cases.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
queue, results_path = map(Path,sys.argv[1:3])
workers = int(sys.argv[3]) if len(sys.argv)>3 else 2
source = Path(sys.argv[4]) if len(sys.argv)>4 else ROOT/'verify_boundary_pair_costs_sharp_cached.cpp'
runner = Path(sys.argv[5]) if len(sys.argv)>5 else ROOT/'run_restricted_boundary_pair_costs.py'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
rows = []
for item in json.loads(queue.read_text()):
    name,original = item['name'],Path(item['original'])
    assert name and all(c.isalnum() or c=='_' for c in name)
    data,header = ROOT/(name+'_pair_data.json'),ROOT/(name+'_pair_data.hpp')
    exe,published = Path('/tmp')/('verify_'+name+'_pairs'),ROOT/(name+'_pair_logs_checked')
    staging = Path(tempfile.mkdtemp(prefix='n8_m5_'+name+'_', dir='/tmp'))
    out = staging/'pair_logs'
    assert not published.exists(), 'A published run directory already exists: '+str(published)
    if data.exists():
        assert data.read_bytes()==original.read_bytes(), 'Existing data differs from original'
    else:
        shutil.copyfile(original,data)
    with tempfile.TemporaryDirectory() as tmp:
        regenerated=Path(tmp)/'data.hpp'
        subprocess.run([sys.executable,str(ROOT/'make_sharp_pair_data_header.py'),
                        str(data),str(regenerated)],check=True,stdout=subprocess.PIPE)
        if header.exists():
            assert header.read_bytes()==regenerated.read_bytes()
        else:
            header.write_bytes(regenerated.read_bytes())
    assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
    cmd=['g++','-O3','-std=c++17','-fsanitize=undefined','-fno-sanitize-recover=all',
         '-DPAIR_DATA_FILE="'+header.name+'"',str(source),'-o',str(exe)]
    subprocess.run(cmd,check=True)
    record={**item,'data':str(data),'header':str(header),'executable':str(exe),
            'source':str(source),'source_sha256':source_hash,'build_argv':cmd}
    (ROOT/(name+'_build.json')).write_text(json.dumps(record,indent=2)+'\n')
    print('START',name,flush=True)
    start=time.monotonic()
    r=subprocess.run([sys.executable,str(runner),
                      str(exe),str(data),str(header),str(out),str(workers),
                      '--source',str(source)])
    record.update(returncode=r.returncode,seconds=time.monotonic()-start,
                  manifest=str(out/'manifest.json'))
    if r.returncode==0:
        audit=subprocess.run([sys.executable,str(ROOT/'audit_boundary_pair_manifest.py'),
                              str(out/'manifest.json'),str(exe),str(data),str(header),str(source)],
                             stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (out/'audit_stdout.log').write_text(audit.stdout)
        record['audit_returncode']=audit.returncode
        assert audit.returncode==0,audit.stdout
    # Publish only closed, immutable logs; active stdout remains in /tmp.
    shutil.copytree(out,published)
    record['staged_manifest']=record['manifest']
    record['manifest']=str(published/'manifest.json')
    if r.returncode==0:
        replay=subprocess.run([sys.executable,str(ROOT/'audit_boundary_pair_manifest.py'),
                               str(published/'manifest.json'),str(exe),str(data),str(header),str(source)],
                              stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        assert replay.returncode==0,replay.stdout
        record['published_audit_returncode']=replay.returncode
    rows.append(record)
    results_path.write_text(json.dumps(rows,indent=2)+'\n')
    print('FINISHED',name,'returncode='+str(r.returncode),flush=True)
