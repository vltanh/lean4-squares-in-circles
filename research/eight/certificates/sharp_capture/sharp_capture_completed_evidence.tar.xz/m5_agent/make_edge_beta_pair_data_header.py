"""Add one exact nonnegative width-charge coefficient per ordered role pair.

The input field beta_by_edge is aligned with required_pairs. Pairs outside
that explicit list receive zero charge and remain outside the claimed cover.
"""
from pathlib import Path
from fractions import Fraction
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
data, output = map(Path, sys.argv[1:3])
j = json.loads(data.read_text())
n = len(j['types'])
pairs = j['required_pairs']
charges = [Fraction(*v) for v in j['beta_by_edge']]
assert len(pairs) == len(charges) and len(set(map(tuple,pairs))) == len(pairs)
assert all(0 <= a < n and 0 <= b < n for a,b in pairs)
assert all(0 <= c < 2 and max(c.numerator,c.denominator) < 2**63 for c in charges)
nums = [[0]*n for _ in range(n)]
dens = [[1]*n for _ in range(n)]
for (a,b),c in zip(pairs,charges):
    nums[a][b],dens[a][b] = c.numerator,c.denominator
subprocess.run([sys.executable,str(ROOT/'make_sharp_pair_data_header.py'),
                str(data),str(output)],check=True)

def matrix(name,values):
    return ('constexpr Integer '+name+'['+str(n)+']['+str(n)+']={'
            +','.join('{'+','.join(map(str,row))+'}' for row in values)+'};\n')

with output.open('a') as f:
    f.write('#define PAIR_EDGE_BETA 1\n')
    f.write(matrix('PAIR_EDGE_BETA_NUM',nums))
    f.write(matrix('PAIR_EDGE_BETA_DEN',dens))
