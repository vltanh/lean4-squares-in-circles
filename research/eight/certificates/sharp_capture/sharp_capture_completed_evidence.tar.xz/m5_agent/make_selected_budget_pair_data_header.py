"""Generate the selected-axis half of a complementary full-SAT budget proof."""
from pathlib import Path
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
data,output=map(Path,sys.argv[1:3])
j=json.loads(data.read_text())
assert j['certificate_kind']=='selected_axis_budget'
pairs,checked=j['required_pairs'],j['checked_axes_by_edge']
n=len(j['types'])
assert len(pairs)==len(checked)
assert all(v and len(v)==len(set(v)) and
           all(type(k) is int and 0<=k<8 for k in v) for v in checked)
matrix=[[255]*n for _ in range(n)]
for (a,b),axes in zip(pairs,checked):
    matrix[a][b]=sum(1<<k for k in axes)
subprocess.run([sys.executable,str(ROOT/'make_edge_beta_pair_data_header.py'),
                str(data),str(output)],check=True)
with output.open('a') as f:
    f.write('#define PAIR_MASKED_AXES 1\n')
    f.write('constexpr Integer PAIR_CHECKED_AXES['+str(n)+']['+str(n)+']={'
            +','.join('{'+','.join(map(str,row))+'}' for row in matrix)+'};\n')
