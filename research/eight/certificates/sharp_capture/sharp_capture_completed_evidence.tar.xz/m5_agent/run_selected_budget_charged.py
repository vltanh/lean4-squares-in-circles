"""Build and audit a complete selected-axis budget with immutable staging.

Usage: python run_selected_budget_charged.py NAME DATA [WORKERS]
The separate complementary owner input/manifest must already be bound by DATA.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
name,data=sys.argv[1],Path(sys.argv[2]).resolve()
workers=int(sys.argv[3]) if len(sys.argv)>3 else 4
assert name and all(c.isalnum() or c=='_' for c in name)
assert workers>0
source=ROOT/'verify_boundary_pair_costs_sharp_masked_mvt_charged.cpp'
header=data.with_suffix('.hpp')
exe=Path('/tmp')/('verify_'+name+'_pairs')
published=ROOT/(name+'_piece_logs_checked')
assert not published.exists()
with tempfile.TemporaryDirectory() as tmp:
    regenerated=Path(tmp)/'data.hpp'
    subprocess.run([sys.executable,str(ROOT/'make_selected_budget_pair_data_header.py'),
                    str(data),str(regenerated)],check=True)
    if header.exists():assert header.read_bytes()==regenerated.read_bytes()
    else:header.write_bytes(regenerated.read_bytes())
freeze=json.loads((ROOT/'charged_mean_value_kernel_freeze.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(ROOT/n)==h for n,h in freeze.items())
cmd=['g++','-O3','-std=c++17','-fsanitize=undefined','-fno-sanitize-recover=all',
     '-DPAIR_DATA_FILE="'+header.name+'"',str(source),'-o',str(exe)]
subprocess.run(cmd,check=True)
out=Path(tempfile.mkdtemp(prefix='n8_m5_'+name+'_',dir='/tmp'))/'piece_logs'
build={'data':str(data),'header':str(header),'source':str(source),'source_sha256':sha(source),
       'executable':str(exe),'build_argv':cmd,'staged_output':str(out),
       'included_header_hashes':{n:h for n,h in freeze.items() if n.endswith('.hpp')}}
(ROOT/(name+'_build.json')).write_text(json.dumps(build,indent=2)+'\n')
r=subprocess.run([sys.executable,str(ROOT/'run_piecewise_charged_boundary_pair_costs.py'),
                  str(exe),str(data),str(header),str(source),str(out),str(workers)])
if r.returncode==0:
    subprocess.run([sys.executable,str(ROOT/'audit_piecewise_selected_budget.py'),
                    str(out/'manifest.json'),str(exe),str(data),str(header),str(source)],check=True)
shutil.copytree(out,published)
if r.returncode==0:
    subprocess.run([sys.executable,str(ROOT/'audit_piecewise_selected_budget.py'),
                    str(published/'manifest.json'),str(exe),str(data),str(header),str(source)],check=True)
raise SystemExit(r.returncode)
