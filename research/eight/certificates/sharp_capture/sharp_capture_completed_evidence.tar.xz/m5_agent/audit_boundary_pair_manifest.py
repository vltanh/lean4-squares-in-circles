"""Independently check the complete branch cover and bindings of a pair run.

Usage: python audit_boundary_pair_manifest.py MANIFEST EXE DATA HEADER SOURCE

This checks the recorded execution and the declared domains. It does not
prove that a declared anchor-domain cover is globally exhaustive; that is
the responsibility of the separate geometric case argument.
"""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
manifest_path, executable, data, header, source = map(Path, sys.argv[1:6])
m = json.loads(manifest_path.read_text())
j = json.loads(data.read_text())
assert m['status'] in ('ALL REQUIRED BRANCHES PASSED', 'ALL DECLARED BRANCHES PASSED')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = {'executable_sha256':executable, 'data_json_sha256':data,
         'data_header_sha256':header, 'source_sha256':source,
         'arithmetic_source_sha256':ROOT/'exact_dyadic_base.cpp'}
if 'runner_sha256' in m:
    runner = m.get('runner_filename','run_restricted_boundary_pair_costs.py')
    assert runner in ('run_restricted_boundary_pair_costs.py',
                      'run_streamed_boundary_pair_costs.py',
                      'run_restricted_boundary_pair_costs_mvt.py',
                      'run_restricted_boundary_pair_costs_mvt_convex.py')
    paths['runner_sha256'] = ROOT/runner
convex_beta0 = source.name == 'verify_boundary_pair_costs_sharp_mvt_convex.cpp'
mean_value = convex_beta0 or source.name in ('verify_boundary_pair_costs_sharp_mvt.cpp',
                             'verify_boundary_pair_costs_sharp_masked_mvt.cpp')
assert ('mean_value_header_sha256' in m) == mean_value
if mean_value:
    paths['mean_value_header_sha256'] = ROOT/'pair_mean_value_beta0.hpp'
assert ('charged_mean_value_header_sha256' in m) == convex_beta0
assert ('convex_beta0_header_sha256' in m) == convex_beta0
if convex_beta0:
    paths['charged_mean_value_header_sha256'] = ROOT/'pair_mean_value_charged.hpp'
    paths['convex_beta0_header_sha256'] = ROOT/'pair_mean_value_convex_beta0.hpp'
for label, path in paths.items():
    assert sha(path) == m[label], (label, str(path))
if 'inputs_unchanged_during_run' in m:
    assert m['inputs_unchanged_during_run'] is True

sharp = convex_beta0 or source.name in ('verify_boundary_pair_costs_sharp.cpp',
                        'verify_boundary_pair_costs_sharp_cached.cpp',
                        'verify_boundary_pair_costs_sharp_shortcircuit.cpp',
                        'verify_boundary_pair_costs_sharp_edge_beta.cpp',
                        'verify_boundary_pair_costs_sharp_masked.cpp',
                        'verify_boundary_pair_costs_sharp_mvt.cpp',
                        'verify_boundary_pair_costs_sharp_masked_mvt.cpp')
masked = source.name in ('verify_boundary_pair_costs_sharp_masked.cpp',
                         'verify_boundary_pair_costs_sharp_masked_mvt.cpp')
edge_beta = masked or source.name == 'verify_boundary_pair_costs_sharp_edge_beta.cpp'
assert ('beta_by_edge' in j) == edge_beta, 'Declared edge charges must match the executed kernel'
assert ('checked_axes_by_edge' in j) == masked, 'Partial-axis scope must match the executed kernel'
assert Fraction(*j.get('core_radius',[1,12])) == Fraction(1,12)
if not sharp:
    assert source.name == 'verify_boundary_pair_costs.cpp'
    assert Fraction(*j['Q']) == Fraction(9789,2500)
generator = ROOT/('make_masked_pair_data_header.py' if masked else
                 'make_edge_beta_pair_data_header.py' if edge_beta else
                 'make_sharp_pair_data_header.py' if sharp else 'make_pair_data_header.py')
with tempfile.TemporaryDirectory() as tmp:
    regenerated = Path(tmp)/'data.hpp'
    subprocess.run([sys.executable, str(generator), str(data), str(regenerated)],
                   check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert regenerated.read_bytes() == header.read_bytes(), 'Header differs from regenerated exact data'
dynamic = subprocess.run(['readelf','-d',str(executable)],check=True,
                         stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True).stdout
assert 'libubsan' in dynamic, 'The recorded executable has no UBSan runtime linkage'

N, K = len(j['types']), j['K']
pairs = j.get('required_pairs', [[a,b] for a in range(N) for b in range(a,N)])
signs = j.get('allowed_signs', [[-1,1] for _ in range(N)])
expected = {(a,b,s,t) for a,b in pairs for s in signs[a] for t in signs[b]}
assert m['required_pairs'] == pairs and m['K'] == K
if 'allowed_signs' in m:
    assert m['allowed_signs'] == [sorted(x) for x in signs]
assert len(m['results']) == len(expected)
assert {tuple(r['branch']) for r in m['results']} == expected
piece_pattern = re.compile(r'PIECE (-?\d+) (-?\d+) (-?\d+) (-?\d+) (\d+) (\d+) nodes=(\d+) total=(\d+)')
summary_pattern = re.compile(r'VERIFIED (-?\d+) (-?\d+) (-?\d+) (-?\d+) nodes=(\d+) leaves=(\d+) depth=(\d+) margin_upper=(-?\d+)/281474976710656 seconds=([\d.eE+-]+)')
nodes = leaves = deepest = 0
margins = []
for r in m['results']:
    branch = tuple(r['branch'])
    path = manifest_path.parent/('_'.join(map(str,branch))+'.log')
    assert r['returncode'] == 0 and r['complete'] is True and sha(path) == r['sha256']
    lines = path.read_text().splitlines()
    assert len(lines) == K*K+1
    pieces = [piece_pattern.fullmatch(line) for line in lines[:-1]]
    assert all(pieces)
    assert all(tuple(map(int,p.groups()[:4])) == branch for p in pieces)
    assert {tuple(map(int,p.groups()[4:6])) for p in pieces} == {(a,b) for a in range(K) for b in range(K)}
    cumulative = 0
    for p in pieces:
        count = int(p[7])
        assert count > 0 and count % 2 == 1
        cumulative += count
        assert cumulative == int(p[8])
    s = summary_pattern.fullmatch(lines[-1])
    assert s and tuple(map(int,s.groups()[:4])) == branch and lines[-1] == r['summary']
    n,l,d,margin = map(int,s.groups()[4:8])
    assert n == cumulative == 2*l-K*K and margin < 0
    nodes += n
    leaves += l
    deepest = max(deepest,d)
    margins.append(margin)
assert nodes == 2*leaves-len(expected)*K*K
result = {
    'status':'COMPLETE DECLARED PAIR COVER AND ALL BINDINGS CHECKED',
    'scope':'The role domains and signs in the bound data; global case coverage is a separate theorem.',
    'manifest_sha256':sha(manifest_path),
    'branches':len(expected),
    'initial_rectangles':len(expected)*K*K,
    'nodes':nodes,
    'terminal_rectangles':leaves,
    'maximum_depth':deepest,
    'maximum_recorded_scaled_margin_upper_numerator':max(margins),
    'scale':2**48,
    'empty_domain_sentinel_note':'-1 can indicate an already empty cost-failure gap domain, not an evaluated SAT margin.',
    'header_regenerated_byte_identically':True,
    'ubsan_runtime_linked':True,
}
if mean_value:
    result['mean_value_header_sha256'] = m['mean_value_header_sha256']
    result['optional_mean_value_rejection'] = 'For beta=0 only, with the original interval rejection retained as fallback.'
if convex_beta0:
    result['charged_mean_value_header_sha256'] = m['charged_mean_value_header_sha256']
    result['convex_beta0_header_sha256'] = m['convex_beta0_header_sha256']
    result['optional_convex_beta0_rejection'] = 'Exact affine beta0 endpoint with fixed rational convex SAT majorants; original interval and beta0 MVT bounds remain as fallbacks.'
if masked:
    assert j['certificate_kind']=='wrong_axis_exclusion'
    checked,allowed=j['checked_axes_by_edge'],j['allowed_axes_by_edge']
    assert len(checked)==len(allowed)==len(pairs)
    assert all(set(c)|set(a)==set(range(8)) and not set(c)&set(a)
               and len(c)==len(set(c)) and len(a)==len(set(a)) for c,a in zip(checked,allowed))
    filename=j['base_budget_filename']
    assert Path(filename).name==filename
    base_path=data.parent/filename
    assert sha(base_path)==j['base_budget_sha256']
    base=json.loads(base_path.read_text())
    for key in ['Q','K','types','is_core','positive_domains','allowed_signs',
                'psi_numerators','psi_negative_numerators','psi_denominator',
                'required_pairs','beta_by_edge']:
        assert j[key]==base[key], ('Budget/owner premise differs',key)
    excess=Fraction(*j['per_edge_excess_upper'])
    assert excess>0
    for a,b in pairs:
        assert (Fraction(j['gamma_numerators'][a][b],j['gamma_denominator']) ==
                Fraction(base['gamma_numerators'][a][b],base['gamma_denominator'])+excess)
    result['scope']='Only the checked signed SAT axes below each declared pair-cost threshold.'
    result['checked_axes_by_edge']=checked
    result['allowed_axes_by_edge']=allowed
    result['base_budget_sha256']=j['base_budget_sha256']
    result['per_edge_excess_upper']=j['per_edge_excess_upper']
    result['consequence']='If each pair cost is strictly below its base-budget gamma plus the stated excess, every separating signed axis belongs to its allowed set.'
    result['base_budget_status']='Separate; this owner certificate does not itself establish the pair-cost budget.'
elif N == 7 and pairs == [[a,(a+1)%7] for a in range(7)]:
    total = sum(Fraction(j['gamma_numerators'][a][b],j['gamma_denominator']) for a,b in pairs)
    if 'cost_sum' in j:
        assert total == Fraction(*j['cost_sum'])
    result['directed_seven_edge_sum'] = [total.numerator,total.denominator]
    reserve = total-Fraction(710,113)
    result['reserve_over_710_113'] = [reserve.numerator,reserve.denominator]
    comparison = Fraction(*j.get('twice_pi_upper',[710,113]))
    # The exact Machin proof is in audit_capture/SHARP_RATIONAL_PI_BOUND.md.
    # A larger rational upper bound is also valid for a declared dataset.
    sharp_upper = Fraction(6283185307179586476925286766559006,10**33)
    assert comparison >= sharp_upper, 'Comparison constant lacks the recorded pi enclosure'
    selected_reserve = total-comparison
    result['twice_pi_upper'] = [comparison.numerator,comparison.denominator]
    result['reserve_over_twice_pi_upper'] = [selected_reserve.numerator,selected_reserve.denominator]
    if 'allowed_cyclic_deficit' in j:
        assert edge_beta, 'A deficit budget requires the declared edge-charge kernel'
        deficit = Fraction(*j['allowed_cyclic_deficit'])
        assert deficit > 0 and total+deficit > comparison
        charges = [Fraction(*v) for v in j['beta_by_edge']]
        assert len(charges) == len(pairs) and all(0 <= c < 2 for c in charges)
        result['allowed_cyclic_deficit'] = [deficit.numerator,deficit.denominator]
        result['edge_width_charges'] = j['beta_by_edge']
        result['consequence'] = 'At holonomy 2pi, the sum of beta_edge times width excess is less than the declared cyclic deficit.'
    else:
        assert selected_reserve > 0, 'The declared exclusion has no positive cyclic reserve'
(manifest_path.parent/'aggregate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
