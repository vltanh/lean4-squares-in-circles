"""Check every signed branch of an explicitly declared boundary-role domain.

Usage: python run_restricted_boundary_pair_costs_mvt.py EXE DATA HEADER OUT [WORKERS]
       [--source PATH]

The optional data field allowed_signs has one nonempty subset of {-1,1} for
each role. Omitting it requests both signs for every role. A successful
manifest proves only the domains declared in DATA; a separate geometric
cover must show that these domains exhaust the case under consideration.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('executable', type=Path)
parser.add_argument('data', type=Path)
parser.add_argument('header', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('workers', type=int, nargs='?', default=3)
parser.add_argument('--source', type=Path, default=ROOT/'verify_boundary_pair_costs.cpp')
args = parser.parse_args()
assert args.workers > 0
assert args.source.name in ('verify_boundary_pair_costs_sharp_mvt.cpp','verify_boundary_pair_costs_sharp_masked_mvt.cpp')
j = json.loads(args.data.read_text())
N, K = len(j['types']), j['K']
assert isinstance(K, int) and K > 0
pairs = j.get('required_pairs', [[a,b] for a in range(N) for b in range(a,N)])
assert len(set(map(tuple, pairs))) == len(pairs)
assert all(0 <= a < N and 0 <= b < N for a,b in pairs)
if j.get('unordered_pairs', True):
    assert all(a <= b for a,b in pairs)
signs = j.get('allowed_signs', [[-1,1] for _ in range(N)])
assert len(signs) == N
assert all(len(x) in (1,2) and len(set(x)) == len(x)
           and all(type(s) is int and s in (-1,1) for s in x) for x in signs)
signs = [sorted(x) for x in signs]
jobs = [(a,b,s,t) for a,b in pairs for s in signs[a] for t in signs[b]]
assert len(jobs) == len(set(jobs)) and jobs
args.output.mkdir(parents=True, exist_ok=True)
paths = {
    'executable_sha256': args.executable,
    'source_sha256': args.source,
    'arithmetic_source_sha256': ROOT/'exact_dyadic_base.cpp',
    'mean_value_header_sha256': ROOT/'pair_mean_value_beta0.hpp',
    'data_header_sha256': args.header,
    'data_json_sha256': args.data,
    'runner_sha256': Path(__file__),
}
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
bound = {label:digest(path) for label,path in paths.items()}

def run(job):
    start = time.monotonic()
    p = subprocess.run([str(args.executable), *map(str,job)],
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    txt = p.stdout
    lines = txt.strip().splitlines()
    tail = lines[-1] if lines else ''
    prefix = 'PIECE '+' '.join(map(str,job))+' '
    pieces = [line[len(prefix):].split()[:2] for line in lines if line.startswith(prefix)]
    complete = (len(lines) == K*K+1 and len(pieces) == K*K
                and set(map(tuple,pieces)) == {(str(a),str(b)) for a in range(K) for b in range(K)}
                and tail.startswith('VERIFIED '+' '.join(map(str,job))+' '))
    (args.output/('_'.join(map(str,job))+'.log')).write_text(txt)
    result = {'branch':job, 'returncode':p.returncode, 'complete':complete,
              'seconds':time.monotonic()-start, 'summary':tail,
              'sha256':hashlib.sha256(txt.encode()).hexdigest()}
    print(tail if p.returncode == 0 and complete else 'FAILED '+str(result), flush=True)
    return result

with ThreadPoolExecutor(max_workers=args.workers) as pool:
    results = [f.result() for f in as_completed([pool.submit(run,x) for x in jobs])]
unchanged = all(digest(path) == bound[label] for label,path in paths.items())
ok = (unchanged and len(results) == len(jobs)
      and all(r['returncode'] == 0 and r['complete'] for r in results))
payload = {
    'status':'ALL DECLARED BRANCHES PASSED' if ok else 'INCOMPLETE/FAILED',
    'runner_filename':Path(__file__).name,
    'scope':'Only the role intervals and signs declared in the bound data file.',
    'required_pairs':pairs,
    'allowed_signs':signs,
    'expected_branch_count':len(jobs),
    'K':K,
    'inputs_unchanged_during_run':unchanged,
    **bound,
    'results':sorted(results, key=lambda r:r['branch']),
}
(args.output/'manifest.json').write_text(json.dumps(payload,indent=2)+'\n')
print(payload['status'], flush=True)
raise SystemExit(0 if ok else 1)
