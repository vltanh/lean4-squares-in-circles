// Optional smooth-branch mean-value rejection for 0 < beta <= 1/10.
// The original absolute-width cost failure is exactly the union of the four
// signed linear-width cost failures. Each signed cost is strictly increasing
// in delta because its width derivative has magnitude <= sqrt(2)/2.
#include <optional>

D endpoint_majorant_coefficients(const EndpointSAT& g,int axis,int sign,I sc,I ss) {
    return D(rational(2*sign))*g.P[axis]-g.Z-D(sc)*g.Qc-D(ss)*g.Qs;
}
Integer charged_majorant_bound(const Algebra& g,const EndpointSAT& box,
                               const EndpointSAT& center,const TrigSpan& span,
                               I xoffset,I yoffset,int axis,int sign,I sc,I ss) {
    // |Qc|+|Qs| >= sc*Qc+ss*Qs for every fixed sc,ss in [-1,1].
    // Fractional coefficients are convex combinations of the four familiar
    // sign majorants and are useful at parallel/quarter-aligned contacts.
    if(sc.lo<-SCALE||sc.hi>SCALE||ss.lo<-SCALE||ss.hi>SCALE)
        throw std::runtime_error("Width coefficient outside[-1,1]");
    I X=rational(2*sign)*g.X[axis]-sc*g.K-ss*g.L;
    I Y=rational(2*sign)*g.Y[axis]-ss*g.K+sc*g.L;
    I C=rational(2*sign)*g.C[axis]-g.Z;
    Integer direct=trig_max(X,Y,C,span);
    if(direct<0)return direct;
    if(trig_max(-Y,X,rational(0),span)>0)return INT64_MAX;
    D range=endpoint_majorant_coefficients(box,axis,sign,sc,ss);
    D value=endpoint_majorant_coefficients(center,axis,sign,sc,ss);
    return (value.v+range.dx*xoffset+range.dy*yoffset).hi;
}
std::optional<I> choose_width_coefficient(const D& numerator,const D& denominator,
                                        I xoffset,I yoffset) {
    // Floating-point arithmetic chooses an auxiliary RATIONAL coefficient;
    // it never accepts a box. The returned numerator is range checked, and
    // charged_majorant_bound then proves every bound by exact dyadic code.
    long double nx=(static_cast<long double>(numerator.dx.lo)+numerator.dx.hi)/2;
    long double ny=(static_cast<long double>(numerator.dy.lo)+numerator.dy.hi)/2;
    long double dx=(static_cast<long double>(denominator.dx.lo)+denominator.dx.hi)/2;
    long double dy=(static_cast<long double>(denominator.dy.lo)+denominator.dy.hi)/2;
    long double wx=static_cast<long double>(xoffset.hi)-xoffset.lo;
    long double wy=static_cast<long double>(yoffset.hi)-yoffset.lo;
    nx*=wx;dx*=wx;ny*=wy;dy*=wy;
    long double square=dx*dx+dy*dy;
    if(!(square>0)||!std::isfinite(square))return std::nullopt;
    long double value=(nx*dx+ny*dy)/square;
    if(!std::isfinite(value))return std::nullopt;
    value=std::clamp(value,static_cast<long double>(-1),static_cast<long double>(1));
    constexpr Integer denominator_scale=1000000000;
    Integer p=std::llround(value*denominator_scale);
    if(p<-denominator_scale||p>denominator_scale)return std::nullopt;
    return rational(p,denominator_scale);
}

I signed_cost_at(const Algebra& g,Integer delta,I gamma,I beta,int sc,int ss) {
    Trig q=point_trig(delta);I cs(q.cl,q.ch),sn(q.sl,q.sh);
    I width=quotient(rational(sc)*(g.K*cs-g.L*sn)+rational(ss)*(g.K*sn+g.L*cs),
                     rational(2)*g.Z)-rational(1,2);
    return point(delta)-beta*width+g.dpsi-gamma;
}
std::optional<I> signed_cost_root(const Algebra& g,I gamma,I beta,int sc,int ss,Integer resolution) {
    I r2=root(rational(2));
    Integer left=(gamma-g.dpsi-beta*(r2+rational(1))*rational(1,2)).lo;
    Integer right=(gamma-g.dpsi+beta*(r2-rational(1))*rational(1,2)).hi;
    if(left< -5*SCALE/2||right>5*SCALE/2)return std::nullopt;
    if(left>right)throw std::runtime_error("Reversed signed-cost root bracket");
    // Every update of a returned endpoint is justified by a sign for ALL
    // states in the tangent box. Search endpoints may be inconclusive; they
    // are never returned as certified root bounds without the sign test.
    Integer lower=left,upper=right,lo=left,hi=right;
    for(int k=0;k<64&&hi-lo>resolution;++k){
        Integer mid=lo+(hi-lo)/2;
        if(signed_cost_at(g,mid,gamma,beta,sc,ss).hi<=0){lower=mid;lo=mid;}
        else hi=mid;
    }
    lo=lower;hi=right;
    for(int k=0;k<64&&hi-lo>resolution;++k){
        Integer mid=lo+(hi-lo)/2;
        if(signed_cost_at(g,mid,gamma,beta,sc,ss).lo>=0){upper=mid;hi=mid;}
        else lo=mid;
    }
    return I(lower,upper);
}

std::optional<EndpointSAT> charged_endpoint_sat(const Segment& sa,const Segment& sb,
                                               I xvalue,I yvalue,I gamma,I beta,
                                               int sc,int ss,Integer resolution) {
    D x{xvalue,rational(1),rational(0)},y{yvalue,rational(0),rational(1)};
    D t=D(rational(sa.sign))*x,u=D(rational(sb.sign))*y;
    D aa=differential_local_a(sa.type,x),ab=differential_local_a(sb.type,y);
    D one(rational(1)),A=one+t*t,B=one+u*u;
    D Z=differential_root(A*B),K=one+t*u,L=u-t;
    D pa=affine_potential(sa,x),pb=affine_potential(sb,y);
    PairBox point_box{xvalue,yvalue,0};Algebra g=algebra(sa,sb,point_box);
    g.dpsi=pb.v-pa.v;
    auto root_interval=signed_cost_root(g,gamma,beta,sc,ss,resolution);
    if(!root_interval)return std::nullopt;
    Trig q=trig_bounds(*root_interval);I sn(q.sl,q.sh),cs(q.cl,q.ch);
    I Qc=K.v*cs-L.v*sn,Qs=K.v*sn+L.v*cs;
    I hp=quotient(-rational(sc)*Qs+rational(ss)*Qc,rational(2)*Z.v);
    I denominator=rational(1)-beta*hp;
    if(denominator.lo<=0)return std::nullopt;
    // phi=delta+atan(sign_b*y)-atan(sign_a*x). Implicit differentiation
    // retains both signed coordinate factors and the affine potential slope.
    I dx=quotient(pa.dx-beta*hp*quotient(rational(sa.sign),A.v),denominator);
    I dy=quotient(-pb.dy+beta*hp*quotient(rational(sb.sign),B.v),denominator);
    D delta{*root_interval,dx,dy};
    auto tr=differential_trig(delta);D cosine=tr.first,sine=tr.second;
    D V=ab*B,W=aa*A;
    std::array<D,4> projections{
        V*(cosine+t*sine)-aa*Z,
        V*(sine-t*cosine)+aa*t*Z,
        ab*Z-W*(cosine-u*sine),
        -ab*u*Z+W*(sine+u*cosine)
    };
    return EndpointSAT{delta,Z,K*cosine-L*sine,K*sine+L*cosine,projections};
}

bool mean_value_reject_charged(const Segment& sa,const Segment& sb,const PairBox& b,
                              const Algebra& g,I gamma,I beta,unsigned checked_axes,
                              Integer& worst) {
    if(beta.lo<=0||beta.hi>SCALE/10)return false;
    const Integer guard=SCALE+SCALE/1000000000;
    if(b.x.lo<0||b.y.lo<0||b.x.hi>guard||b.y.hi>guard)return false;
    if(Wide(sa.increment.lo)<-16*Wide(sa.step.lo)||Wide(sa.increment.hi)>16*Wide(sa.step.lo)||
       Wide(sb.increment.lo)<-16*Wide(sb.step.lo)||Wide(sb.increment.hi)>16*Wide(sb.step.lo))return false;
    I cut=rational(6,7);
    if((IS_CORE[sa.type]&&b.x.lo<cut.hi&&b.x.hi>cut.lo&&b.x.hi-b.x.lo>SCALE/100) ||
       (IS_CORE[sb.type]&&b.y.lo<cut.hi&&b.y.hi>cut.lo&&b.y.hi-b.y.lo>SCALE/100))return false;
    Integer mx=b.x.lo+(b.x.hi-b.x.lo)/2,my=b.y.lo+(b.y.hi-b.y.lo)/2;
    I xoffset(b.x.lo-mx,b.x.hi-mx),yoffset(b.y.lo-my,b.y.hi-my);
    Integer resolution=std::max(Integer(8),std::max(b.x.hi-b.x.lo,b.y.hi-b.y.lo)/128);
    Integer all=INT64_MIN;
    for(int cost_sc:{-1,1})for(int cost_ss:{-1,1}){
        auto enclosed_endpoint=charged_endpoint_sat(sa,sb,b.x,b.y,gamma,beta,cost_sc,cost_ss,resolution);
        if(!enclosed_endpoint)return false;
        const EndpointSAT& box=*enclosed_endpoint;
        if(box.d.v.hi<DMIN.lo){all=std::max(all,Integer(-1));continue;}
        auto center_endpoint=charged_endpoint_sat(sa,sb,point(mx),point(my),gamma,beta,cost_sc,cost_ss,8);
        if(!center_endpoint)return false;
        const EndpointSAT& center=*center_endpoint;
        TrigSpan span{I(DMIN.lo,box.d.v.hi),point_trig(DMIN.lo),point_trig(box.d.v.hi)};
        for(int axis=0;axis<4;++axis)for(int sign:{-1,1}){
            unsigned index=axis+(sign<0?4:0);
            if(!(checked_axes&(1u<<index)))continue;
            Integer best=INT64_MAX;
            for(int sc:{-1,1}){
                for(int ss:{-1,1}){
                    best=std::min(best,charged_majorant_bound(g,box,center,span,xoffset,yoffset,
                                                              axis,sign,rational(sc),rational(ss)));
                    if(best<0)break;
                }
                if(best<0)break;
            }
            if(best>=0){
                for(int selector:{0,1}){
                    for(int fixed:{-1,1}){
                        const D& fixed_term=selector?center.Qs:center.Qc;
                        const D& variable_term=selector?center.Qc:center.Qs;
                        D numerator=D(rational(2*sign))*center.P[axis]-center.Z-D(rational(fixed))*fixed_term;
                        auto coefficient=choose_width_coefficient(numerator,variable_term,xoffset,yoffset);
                        if(!coefficient)continue;
                        I sc=selector?*coefficient:rational(fixed),ss=selector?rational(fixed):*coefficient;
                        best=std::min(best,charged_majorant_bound(g,box,center,span,xoffset,yoffset,axis,sign,sc,ss));
                        if(best<0)break;
                    }
                    if(best<0)break;
                }
            }
            if(best>=0)return false;
            all=std::max(all,best);
        }
    }
    worst=all;return all<0;
}
