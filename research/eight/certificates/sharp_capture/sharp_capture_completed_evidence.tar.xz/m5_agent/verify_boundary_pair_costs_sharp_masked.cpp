// Exact boundary-pair validator with configurable rational Q and role data.
// Masked edge-beta variant: certify only the explicitly checked signed axes.
// This proves a conditional owner restriction, not full-SAT pair nonexistence.
// Endpoint trig intervals are shared within each SAT bound.
// A proof requires successful completion of every declared closed branch.
// Its arithmetic is the audited 2^-48 dyadic interval arithmetic from PR #9.
#define main original_dyadic_main
#include "exact_dyadic_base.cpp"
#undef main
#include <fstream>
#include <string>
#ifndef PAIR_DATA_FILE
#define PAIR_DATA_FILE "boundary_pair_data.hpp"
#endif
#include PAIR_DATA_FILE
#ifndef PAIR_SEPARATE_POTENTIAL_SIGNS
#define PAIR_SEPARATE_POTENTIAL_SIGNS 0
#endif

I quotient(I a,I b) {
    if(b.lo<=0) throw std::runtime_error("Nonpositive interval divisor");
    Wide n[]={Wide(a.lo)*SCALE,Wide(a.hi)*SCALE};
    Integer ls[]={floor_div(n[0],b.lo),floor_div(n[0],b.hi),floor_div(n[1],b.lo),floor_div(n[1],b.hi)};
    Integer hs[]={ceil_div(n[0],b.lo),ceil_div(n[0],b.hi),ceil_div(n[1],b.lo),ceil_div(n[1],b.hi)};
    return {*std::min_element(ls,ls+4),*std::max_element(hs,hs+4)};
}
I absolute(I a) {
    if(a.lo>=0)return a;
    if(a.hi<=0)return -a;
    return {0,std::max(-a.lo,a.hi)};
}
I point(Integer x){return {x,x};}
I enclosed(I a,I b){return {a.lo,b.hi};}
#ifndef PAIR_CONFIGURABLE_Q
#error "Sharp validator requires a configurable-Q data header"
#endif
I configured_ceiling() {
    const Wide max_den=Wide(1000000000000000000)*1000;
    if(PAIR_Q_DEN<=0 || PAIR_Q_DEN>max_den ||
       PAIR_Q_NUM<3*PAIR_Q_DEN || PAIR_Q_NUM>4*PAIR_Q_DEN)
        throw std::runtime_error("Invalid configured rational ceiling");
    // The product is at most 4*10^21*2^48 < 2^120, inside signed128.
    return {floor_div(PAIR_Q_NUM*SCALE,PAIR_Q_DEN),
            ceil_div(PAIR_Q_NUM*SCALE,PAIR_Q_DEN)};
}
const I QQ=configured_ceiling(),DMIN=rational(3,5);
#ifndef PAIR_EDGE_BETA
#error "Edge-beta validator requires a pair-beta data header"
#endif
#ifndef PAIR_MASKED_AXES
#error "Masked validator requires explicit checked signed axes"
#endif

struct Segment {int type,sign,piece; I left,right,value,increment,step;};
I actual_knot(int type,int k) {
    return rational(LOW_NUM[type],LOW_DEN[type])+rational(STEP_NUM[type],STEP_DEN[type])*rational(k);
}
Segment segment(int ty,int sign,int k) {
    I l=actual_knot(ty,k),r=actual_knot(ty,k+1);
#if PAIR_SEPARATE_POTENTIAL_SIGNS
    const Integer* values=sign>0?VALUES[ty]:NEGATIVE_VALUES[ty];
#else
    const Integer* values=VALUES[ty];
#endif
    I step=rational(STEP_NUM[ty],STEP_DEN[ty]);
    if(step.lo<=0)throw std::runtime_error("Affine step below dyadic resolution");
    return {ty,sign,k,l,r,rational(values[k],PSI_DEN),
            rational(values[k+1]-values[k],PSI_DEN),step};
}
I potential(const Segment& s,I x) {
    // Normalized interpolation avoids ever constructing 1/step or a large
    // slope/intercept. Every true point in this affine piece has coordinate
    // (x-left)/step in [0,1], even for a very narrow role domain. Clamping
    // both endpoints preserves every actual point and gives a harmless
    // constant extension over rounded domain endpoints.
    I coordinate=quotient(x-s.left,s.step);
    coordinate.lo=std::clamp(coordinate.lo,Integer(0),SCALE);
    coordinate.hi=std::clamp(coordinate.hi,Integer(0),SCALE);
    I value=s.value+s.increment*coordinate;
#if PAIR_SEPARATE_POTENTIAL_SIGNS
    return value;
#else
    return rational(s.sign)*value;
#endif
}
I local_a_point(int type,Integer x) {
    I t=point(x);
    if(!IS_CORE[type]){
        I A=rational(1)+square(t),L=rational(1)+t;
        return quotient(root(square(L)+rational(4)*A*(QQ-rational(1,2)))-L,rational(2)*A);
    }
    I cut=rational(6,7);
    if(x<=cut.lo)return rational(7,12);
    I A=rational(1)+square(t),L=rational(1)+t;
    I result=quotient(L+root(square(L)-rational(4)*A*rational(71,144)),rational(2)*A);
    if(x<cut.hi){I side=rational(7,12);result.lo=std::min(result.lo,side.lo);result.hi=std::max(result.hi,side.hi);}
    return result;
}
I local_a(int type,I x) {
    // On every boundary local a decreases with |t|; the core side is constant.
    return enclosed(local_a_point(type,x.hi),local_a_point(type,x.lo));
}

struct PairBox {I x,y;unsigned depth;};
struct Algebra {I t,u,aa,ab,A,B,Z,K,L,dpsi;std::array<I,4> X,Y,C;};
Algebra algebra(const Segment& sa,const Segment& sb,const PairBox& box) {
    Algebra g;g.t=rational(sa.sign)*box.x;g.u=rational(sb.sign)*box.y;
    g.aa=local_a(sa.type,box.x);g.ab=local_a(sb.type,box.y);
    g.A=rational(1)+square(g.t);g.B=rational(1)+square(g.u);
    g.Z=root(g.A*g.B);g.K=rational(1)+g.t*g.u;g.L=g.u-g.t;
    g.dpsi=potential(sb,box.y)-potential(sa,box.x);
    I V=g.ab*g.B,W=g.aa*g.A;
    g.X={V,-V*g.t,-W,W*g.u};
    g.Y={V*g.t,V,W*g.u,W};
    g.C={-g.aa*g.Z,g.aa*g.t*g.Z,g.ab*g.Z,-g.ab*g.u*g.Z};
    return g;
}
I cost_at(const Algebra& g,Integer d,I gamma,I beta) {
    Trig q=point_trig(d);I C(q.cl,q.ch),S(q.sl,q.sh);
    I width=quotient(absolute(g.K*C-g.L*S)+absolute(g.K*S+g.L*C),rational(2)*g.Z)-rational(1,2);
    return point(d)-beta*width+g.dpsi-gamma;
}
Integer delta_upper(const Algebra& g,I gamma,I beta,Integer resolution) {
    I excess=(root(rational(2))-rational(1))*rational(1,2);
    Integer hi=(gamma-g.dpsi+beta*excess).hi;
    if(hi<=DMIN.lo)return hi;
    if(hi>5*SCALE/2)throw std::runtime_error("Cost gap exceeds trig domain");
    if(beta.hi==0)return hi;
    Integer lo=DMIN.lo;
    for(int k=0;k<64 && hi-lo>resolution;++k){
        Integer mid=lo+(hi-lo)/2;
        if(cost_at(g,mid,gamma,beta).lo>=0)hi=mid;else lo=mid;
    }
    return hi;
}

struct TrigSpan { I d; Trig left,right; };
Integer scalar_trig_max(Integer x,Integer y,const TrigSpan& span) {
    // d in[3/5,5/2], where sin ispositive. Max ofxcos+y sin.
    const Trig& ql=span.left;const Trig& qh=span.right;
    I X=point(x),Y=point(y);
    I vl=X*I(ql.cl,ql.ch)+Y*I(ql.sl,ql.sh);
    I vh=X*I(qh.cl,qh.ch)+Y*I(qh.sl,qh.sh);
    Integer out=std::max(vl.hi,vh.hi);
    // An interior maximum has xcos+y sin>0 and equals hypot(x,y).
    // It has derivative positive at left andnegative at right. Endpoint
    // derivative signs also exclude stationary minima. This is sufficient
    // because aninterval oflength<pi contains atmostone zero of derivative.
    I dl=-X*I(ql.sl,ql.sh)+Y*I(ql.cl,ql.ch);
    I dh=-X*I(qh.sl,qh.sh)+Y*I(qh.cl,qh.ch);
    if(dl.hi>=0 && dh.lo<=0)out=std::max(out,root(square(X)+square(Y)).hi);
    return out;
}
Integer trig_max(I x,I y,I z,const TrigSpan& span) {
    // sin(d)>=0 throughoutthedeclared domain, so theupper yendpoint suffices.
    if(span.d.hi<rational(157,100).lo)return scalar_trig_max(x.hi,y.hi,span)+z.hi;
    return std::max(scalar_trig_max(x.lo,y.hi,span),scalar_trig_max(x.hi,y.hi,span))+z.hi;
}
Integer sat_upper(const Algebra& g,I d,unsigned checked_axes) {
    const TrigSpan span{d,point_trig(d.lo),point_trig(d.hi)};
    Integer result=INT64_MIN;
    for(int axis=0;axis<4;++axis)for(int sign:{-1,1}){
        const unsigned signed_axis=axis+(sign<0?4:0);
        if(!(checked_axes&(1u<<signed_axis)))continue;
        Integer best=INT64_MAX;
        // A single negative width-sign upper bound rejects this signed axis.
        // A nonnegative minimum means the whole gap box is not certified;
        // return the positive sentinel immediately, with no acceptance claim.
        for(int sc:{-1,1}){
            for(int ss:{-1,1}){
                I X=rational(2*sign)*g.X[axis]-rational(sc)*g.K-rational(ss)*g.L;
                I Y=rational(2*sign)*g.Y[axis]-rational(ss)*g.K+rational(sc)*g.L;
                I C=rational(2*sign)*g.C[axis]-g.Z;
                best=std::min(best,trig_max(X,Y,C,span));
                if(best<0)break;
            }
            if(best<0)break;
        }
        if(best>=0)return INT64_MAX;
        result=std::max(result,best);
    }
    return result;
}
bool reject_all_gaps(const Algebra& g,Integer hi,int gap_depth,Integer& worst,unsigned checked_axes) {
    if(hi<DMIN.lo){worst=-1;return true;}
    struct D {I d;int depth;};
    std::vector<D> pending{{I(DMIN.lo,hi),0}};
    Integer all=INT64_MIN;
    while(!pending.empty()){
        D n=pending.back();pending.pop_back();
        Integer upper=sat_upper(g,n.d,checked_axes);
        if(upper<0){all=std::max(all,upper);continue;}
        if(n.depth==gap_depth){worst=upper;return false;}
        Integer mid=n.d.lo+(n.d.hi-n.d.lo)/2;
        pending.push_back({I(n.d.lo,mid),n.depth+1});
        pending.push_back({I(mid,n.d.hi),n.depth+1});
    }
    worst=all;return true;
}

void verify_branch(int at,int bt,int as,int bs,uint64_t limit,int selected_a=-1,int selected_b=-1) {
    uint64_t nodes=0,leaves=0;unsigned deepest=0;Integer worstmargin=INT64_MIN;
    auto start=std::chrono::steady_clock::now();
    for(int ap=0;ap<PIECES;++ap)for(int bp=0;bp<PIECES;++bp){
        if(selected_a>=0 && ap!=selected_a)continue;
        if(selected_b>=0 && bp!=selected_b)continue;
        Segment sa=segment(at,as,ap),sb=segment(bt,bs,bp);
        std::vector<PairBox> pending{{enclosed(sa.left,sa.right),enclosed(sb.left,sb.right),0}};
        uint64_t localnodes=0,localleaves=0;
        while(!pending.empty()){
            PairBox b=pending.back();pending.pop_back();++nodes;++localnodes;
            if(nodes>limit)throw std::runtime_error("Node budget exhausted: NO certificate");
            deepest=std::max(deepest,b.depth);
            Algebra g=algebra(sa,sb,b);Integer wx=b.x.hi-b.x.lo,wy=b.y.hi-b.y.lo;
            Integer resolution=std::max(Integer(8),std::max(wx,wy)/32);
            I beta=rational(PAIR_EDGE_BETA_NUM[at][bt],PAIR_EDGE_BETA_DEN[at][bt]);
            Integer hi=delta_upper(g,rational(GAMMAS[at][bt],GAMMA_DEN),beta,resolution),margin;
            int gap_depth=b.depth>28?12:b.depth>12?6:2;
            if(reject_all_gaps(g,hi,gap_depth,margin,PAIR_CHECKED_AXES[at][bt])){
                ++leaves;++localleaves;worstmargin=std::max(worstmargin,margin);continue;
            }
            if(b.depth>70){
                std::cerr<<"UNRESOLVED "<<at<<" "<<bt<<" "<<as<<" "<<bs<<" pieces="<<ap<<","<<bp<<" x="<<b.x.lo<<","<<b.x.hi<<" y="<<b.y.lo<<","<<b.y.hi<<" gap_hi="<<hi<<" margin="<<margin<<" scale="<<SCALE<<std::endl;
                throw std::runtime_error("Depth budget exhausted: NO certificate");
            }
            bool choose_x=wx>wy;
            PairBox left=b,right=b;Integer mid;
            if(choose_x){mid=b.x.lo+wx/2;if(mid==b.x.lo)throw std::runtime_error("Resolution exhausted");left.x.hi=mid;right.x.lo=mid;}
            else{mid=b.y.lo+wy/2;if(mid==b.y.lo)throw std::runtime_error("Resolution exhausted");left.y.hi=mid;right.y.lo=mid;}
            ++left.depth;++right.depth;pending.push_back(left);pending.push_back(right);
        }
        if(localnodes!=2*localleaves-1)throw std::runtime_error("Binary cover accounting failed");
        std::cout<<"PIECE "<<at<<" "<<bt<<" "<<as<<" "<<bs<<" "<<ap<<" "<<bp<<" nodes="<<localnodes<<" total="<<nodes<<std::endl;
    }
    std::cout<<"VERIFIED "<<at<<" "<<bt<<" "<<as<<" "<<bs<<" nodes="<<nodes<<" leaves="<<leaves<<" depth="<<deepest<<" margin_upper="<<worstmargin<<"/"<<SCALE<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
}
int main(int argc,char**argv){
 try{
    if(BETA_NUM<0||BETA_DEN<=0||Wide(BETA_NUM)>=2*Wide(BETA_DEN)||PSI_DEN<=0||GAMMA_DEN<=0||PIECES<=0||PIECES>256)throw std::runtime_error("Invalid cost data");
    for(int ty=0;ty<TYPE_COUNT;++ty){
        for(int k=0;k<=PIECES;++k){
            if(Wide(VALUES[ty][k]) < -2*Wide(PSI_DEN) || Wide(VALUES[ty][k]) > 2*Wide(PSI_DEN))throw std::runtime_error("Potential node outside checked arithmetic range");
#if PAIR_SEPARATE_POTENTIAL_SIGNS
            if(Wide(NEGATIVE_VALUES[ty][k]) < -2*Wide(PSI_DEN) || Wide(NEGATIVE_VALUES[ty][k]) > 2*Wide(PSI_DEN))throw std::runtime_error("Negative-sign potential node outside checked arithmetic range");
#endif
        }
        for(int tj=0;tj<TYPE_COUNT;++tj){
            if(Wide(GAMMAS[ty][tj]) < -2*Wide(GAMMA_DEN) || Wide(GAMMAS[ty][tj]) > 2*Wide(GAMMA_DEN))throw std::runtime_error("Cost constant outside checked arithmetic range");
            if(PAIR_CHECKED_AXES[ty][tj]<=0 || PAIR_CHECKED_AXES[ty][tj]>255)throw std::runtime_error("Invalid signed-axis mask");
            if(PAIR_EDGE_BETA_NUM[ty][tj]<0 || PAIR_EDGE_BETA_DEN[ty][tj]<=0 || Wide(PAIR_EDGE_BETA_NUM[ty][tj])>=2*Wide(PAIR_EDGE_BETA_DEN[ty][tj]))throw std::runtime_error("Pair width charge outside monotone range");
        }
    }
    for(int k=0;k<TYPE_COUNT;++k){if(LOW_DEN[k]<=0||STEP_NUM[k]<=0||STEP_DEN[k]<=0)throw std::runtime_error("Invalid tangent domain");if(LOW_NUM[k]<0||Wide(LOW_NUM[k])*STEP_DEN[k]+Wide(PIECES)*STEP_NUM[k]*LOW_DEN[k]>Wide(LOW_DEN[k])*STEP_DEN[k])throw std::runtime_error("Tangent domain outside[0,1]");}
    Integer factorial[20];factorial[0]=1;for(int k=1;k<20;++k)factorial[k]=factorial[k-1]*k;
    for(int k=0;k<10;++k){I sn=rational(k%2?-1:1,factorial[2*k+1]);sine19.push_back(sn);if(k<9)sine17.push_back(sn);I cn=rational(k%2?-1:1,factorial[2*k]);cosine18.push_back(cn);if(k<9)cosine16.push_back(cn);}
    if(argc!=5 && argc!=7)throw std::runtime_error("Usage: verifier at bt as bs [ap bp]");
    int at=std::atoi(argv[1]),bt=std::atoi(argv[2]),as=std::atoi(argv[3]),bs=std::atoi(argv[4]);
    if(at<0||at>=TYPE_COUNT||bt<0||bt>=TYPE_COUNT||std::abs(as)!=1||std::abs(bs)!=1)throw std::runtime_error("Invalid branch");
    int ap=argc==7?std::atoi(argv[5]):-1,bp=argc==7?std::atoi(argv[6]):-1;
    if(argc==7 && (ap<0||ap>=PIECES||bp<0||bp>=PIECES))throw std::runtime_error("Invalid affine piece");
    verify_branch(at,bt,as,bs,100000000,ap,bp);
    return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}
}
