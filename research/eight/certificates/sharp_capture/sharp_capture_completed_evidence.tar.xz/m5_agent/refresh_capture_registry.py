"""Index only complete, audited capture runs; failed candidates are excluded.

The registry is a navigation aid. Each immutable manifest and its exact
data, source, executable, and per-branch logs remain the proof authority.
"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={sha(p):p for p in ROOT.glob('verify_boundary_pair_costs*.cpp')}
records=[]
for folder in sorted(ROOT.glob('*_pair_logs_checked')):
    name=folder.name.removesuffix('_pair_logs_checked')
    if not name.startswith(('all_outer_','long_','one_core_')):
        continue
    aggregate,manifest=folder/'aggregate.json',folder/'manifest.json'
    if not aggregate.exists() or not manifest.exists():
        continue
    a,m=json.loads(aggregate.read_text()),json.loads(manifest.read_text())
    if m['status']!='ALL DECLARED BRANCHES PASSED':
        continue
    assert sha(manifest)==a['manifest_sha256']
    assert m['inputs_unchanged_during_run'] is True
    data,header=ROOT/(name+'_pair_data.json'),ROOT/(name+'_pair_data.hpp')
    assert sha(data)==m['data_json_sha256'] and sha(header)==m['data_header_sha256']
    source=sources[m['source_sha256']]
    j=json.loads(data.read_text())
    record={'name':name,'manifest':str(manifest),'manifest_sha256':sha(manifest),
            'aggregate':str(aggregate),'data':str(data),'header':str(header),
            'source':str(source),'source_sha256':m['source_sha256'],
            'scope':a['scope'],
            'word':j.get('word'),'Q':j['Q'],'positive_domains':j['positive_domains'],
            'allowed_signs':m['allowed_signs']}
    for k in ['branches','initial_rectangles','nodes','terminal_rectangles',
              'maximum_depth','directed_seven_edge_sum','twice_pi_upper',
              'reserve_over_twice_pi_upper','allowed_cyclic_deficit',
              'checked_axes_by_edge','allowed_axes_by_edge','base_budget_sha256',
              'per_edge_excess_upper','base_budget_status']:
        if k in a:record[k]=a[k]
    records.append(record)
payload={'status':'INDEX OF COMPLETED AND AUDITED DECLARED CAPTURE CERTIFICATES',
         'warning':'This index does not assert global capture or overall proof closure.',
         'count':len(records),'records':records}
(ROOT/'completed_capture_registry.json').write_text(json.dumps(payload,indent=2)+'\n')
print('Indexed',len(records),'complete audited capture inputs')
