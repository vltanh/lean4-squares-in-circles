// Optional exact two-variable mean-value rejection for an uncharged edge.
// The ordinary interval rejection remains the fallback. This file changes
// no dyadic primitive and does not accept a box without a strict upper bound.

struct Differential {
    I v, dx, dy;
    Differential(I value) : v(value), dx(rational(0)), dy(rational(0)) {}
    Differential(I value,I x,I y) : v(value), dx(x), dy(y) {}
};
using D = Differential;
D operator+(const D& a,const D& b) { return {a.v+b.v,a.dx+b.dx,a.dy+b.dy}; }
D operator-(const D& a) { return {-a.v,-a.dx,-a.dy}; }
D operator-(const D& a,const D& b) { return a+(-b); }
D operator*(const D& a,const D& b) {
    return {a.v*b.v,a.dx*b.v+a.v*b.dx,a.dy*b.v+a.v*b.dy};
}
D differential_root(const D& a) {
    I r=root(a.v),den=rational(2)*r;
    return {r,quotient(a.dx,den),quotient(a.dy,den)};
}
std::pair<D,D> differential_trig(const D& d) {
    Trig q=trig_bounds(d.v);
    I sn(q.sl,q.sh),cs(q.cl,q.ch);
    return {{cs,-sn*d.dx,-sn*d.dy},{sn,cs*d.dx,cs*d.dy}};
}

I local_a_derivative(int type,I x) {
    // Implicit derivatives of the two exact boundary quadratics.
    // local_a itself uses the separately proved monotonicity enclosure.
    if(!IS_CORE[type]) {
        I a=local_a(type,x),b=x*a+rational(1,2);
        return quotient(-a*b,a+rational(1,2)+x*b);
    }
    I cut=rational(6,7);
    if(x.hi<=cut.lo)return rational(0);
    I corner(std::max(x.lo,cut.lo),x.hi);
    I a=local_a(type,corner),b=corner*a-rational(1,2);
    I derivative=quotient(-a*b,a-rational(1,2)+corner*b);
    if(x.lo<cut.hi){derivative.lo=std::min(derivative.lo,Integer(0));derivative.hi=std::max(derivative.hi,Integer(0));}
    return derivative;
}
D differential_local_a(int type,const D& x) {
    I derivative=local_a_derivative(type,x.v);
    return {local_a(type,x.v),derivative*x.dx,derivative*x.dy};
}
D affine_potential(const Segment& s,const D& x) {
    // This is the exact affine nodal function extended over the harmless
    // rounded endpoint overhang. Its derivative is NOT the derivative of
    // the clamped enclosure used by the ordinary interval implementation.
    I slope=quotient(s.increment,s.step);
    D result{s.value+quotient(s.increment*(x.v-s.left),s.step),
             slope*x.dx,slope*x.dy};
#if PAIR_SEPARATE_POTENTIAL_SIGNS
    return result;
#else
    return D(rational(s.sign))*result;
#endif
}

struct EndpointSAT { D d,Z,Qc,Qs;std::array<D,4> P; };
EndpointSAT endpoint_sat(const Segment& sa,const Segment& sb,I xvalue,I yvalue,I gamma) {
    D x{xvalue,rational(1),rational(0)},y{yvalue,rational(0),rational(1)};
    D t=D(rational(sa.sign))*x,u=D(rational(sb.sign))*y;
    D aa=differential_local_a(sa.type,x),ab=differential_local_a(sb.type,y);
    D one(rational(1)),A=one+t*t,B=one+u*u;
    D Z=differential_root(A*B),K=one+t*u,L=u-t;
    D delta=D(gamma)+affine_potential(sa,x)-affine_potential(sb,y);
    auto tr=differential_trig(delta);D cs=tr.first,sn=tr.second;
    D V=ab*B,W=aa*A;
    std::array<D,4> projections{
        V*(cs+t*sn)-aa*Z,
        V*(sn-t*cs)+aa*t*Z,
        ab*Z-W*(cs-u*sn),
        -ab*u*Z+W*(sn+u*cs)
    };
    return {delta,Z,K*cs-L*sn,K*sn+L*cs,projections};
}
D endpoint_majorant(const EndpointSAT& g,int axis,int sign,int sc,int ss) {
    return D(rational(2*sign))*g.P[axis]-g.Z-D(rational(sc))*g.Qc-D(rational(ss))*g.Qs;
}

bool mean_value_reject_beta0(const Segment& sa,const Segment& sb,const PairBox& b,
                            const Algebra& g,I gamma,Integer hi,unsigned checked_axes,
                            Integer& worst) {
    if(hi<DMIN.lo){worst=-1;return true;}
    // These optional guards keep the new derivative expressions in a small
    // independently checked arithmetic range. A failed guard only falls
    // back to the original kernel; it can never accept a rectangle.
    const Integer guard=SCALE+SCALE/1000000000;
    if(b.x.lo<0||b.y.lo<0||b.x.hi>guard||b.y.hi>guard)return false;
    // Check the rational slope range before quotient can narrow its result.
    // A tiny positive step therefore causes a safe fallback, not a large
    // intermediate inverse or an unchecked conversion to a dyadic endpoint.
    if(Wide(sa.increment.lo)<-16*Wide(sa.step.lo)||Wide(sa.increment.hi)>16*Wide(sa.step.lo)||
       Wide(sb.increment.lo)<-16*Wide(sb.step.lo)||Wide(sb.increment.hi)>16*Wide(sb.step.lo))return false;
    I aslope=quotient(sa.increment,sa.step),bslope=quotient(sb.increment,sb.step);
    if(aslope.lo< -16*SCALE||aslope.hi>16*SCALE||bslope.lo< -16*SCALE||bslope.hi>16*SCALE)return false;
    // An interval quotient for a core box crossing 6/7 can have a broad
    // denominator. Such boxes are left to the old domain subdivision.
    I cut=rational(6,7);
    if((IS_CORE[sa.type]&&b.x.lo<cut.hi&&b.x.hi>cut.lo&&b.x.hi-b.x.lo>SCALE/100) ||
       (IS_CORE[sb.type]&&b.y.lo<cut.hi&&b.y.hi>cut.lo&&b.y.hi-b.y.lo>SCALE/100))return false;
    // Bound the exact affine endpoint before asking for any trig enclosure.
    D x{b.x,rational(1),rational(0)},y{b.y,rational(0),rational(1)};
    D endpoint=D(gamma)+affine_potential(sa,x)-affine_potential(sb,y);
    if(endpoint.v.lo< -5*SCALE/2 || endpoint.v.hi>5*SCALE/2)return false;
    Integer upper=std::max(hi,endpoint.v.hi);
    if(upper>5*SCALE/2)return false;
    TrigSpan span{I(DMIN.lo,upper),point_trig(DMIN.lo),point_trig(upper)};
    Integer mx=b.x.lo+(b.x.hi-b.x.lo)/2,my=b.y.lo+(b.y.hi-b.y.lo)/2;
    I xoffset(b.x.lo-mx,b.x.hi-mx),yoffset(b.y.lo-my,b.y.hi-my);
    EndpointSAT box=endpoint_sat(sa,sb,b.x,b.y,gamma);
    EndpointSAT center=endpoint_sat(sa,sb,point(mx),point(my),gamma);
    Integer all=INT64_MIN;
    for(int axis=0;axis<4;++axis)for(int sign:{-1,1}){
        unsigned index=axis+(sign<0?4:0);
        if(!(checked_axes&(1u<<index)))continue;
        Integer best=INT64_MAX;
        for(int sc:{-1,1}){
            for(int ss:{-1,1}){
                I X=rational(2*sign)*g.X[axis]-rational(sc)*g.K-rational(ss)*g.L;
                I Y=rational(2*sign)*g.Y[axis]-rational(ss)*g.K+rational(sc)*g.L;
                I C=rational(2*sign)*g.C[axis]-g.Z;
                Integer direct=trig_max(X,Y,C,span);
                if(direct<0){best=std::min(best,direct);break;}
                // -F_delta = -Y cos(delta)+X sin(delta). Its nonpositive
                // upper bound proves F increases on the full failure gap.
                if(trig_max(-Y,X,rational(0),span)>0)continue;
                D range=endpoint_majorant(box,axis,sign,sc,ss);
                D value=endpoint_majorant(center,axis,sign,sc,ss);
                I bound=value.v+range.dx*xoffset+range.dy*yoffset;
                best=std::min(best,bound.hi);
                if(best<0)break;
            }
            if(best<0)break;
        }
        if(best>=0)return false;
        all=std::max(all,best);
    }
    worst=all;return all<0;
}
