"""Exact finite arithmetic for the self-contained Machin-series pi bound."""
from fractions import Fraction as F

def partial(reciprocal, last):
    return sum((F((-1)**k,(2*k+1)*reciprocal**(2*k+1))
                for k in range(last+1)),F(0))

TWO_PI_UPPER=F(6283185307179586476925286767,10**27)
machin_upper=32*partial(5,20)-8*partial(239,5)
machin_lower=32*partial(5,21)-8*partial(239,6)
assert machin_lower<machin_upper<TWO_PI_UPPER
assert TWO_PI_UPPER-machin_lower<F(1,10**27)
assert F(4)*(F(1,5)-F(1,375))-F(1,239)>0
assert (F(120,119)-F(1,239))/(1+F(120,119)*F(1,239))==1
TWO_PI_UPPER_33=F(6283185307179586476925286766559006,10**33)
upper_33=32*partial(5,24)-8*partial(239,7)
lower_33=32*partial(5,25)-8*partial(239,6)
assert lower_33<upper_33<TWO_PI_UPPER_33<TWO_PI_UPPER
assert TWO_PI_UPPER_33-lower_33<F(1,10**33)
print('PASS: exact Machin and alternating-series comparisons')
print('2*pi <',TWO_PI_UPPER)
print('This rational upper bound exceeds 2*pi by less than 10^-27')
print('2*pi <',TWO_PI_UPPER_33)
print('This sharper rational upper bound exceeds 2*pi by less than 10^-33')
