#!/usr/bin/env python3
"""Exact scalar slider interface for the all-outer terminal box.

The broad stationary-reference interval for h2 is an explicit external
premise; this checker does not purport to prove that analytic chart bound.
All arithmetic establishing boundary roots and slider reserves is rational.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent
source = ROOT/'all_outer_terminal_budget_v1.json'
budget = json.loads(source.read_text())
Q = F(*budget['Q'])
S = F(1, 14000)
radial_transfer = F(1, 10**16)
h2 = (F(-29, 20), F(-7, 5))
comparison_T = (F(29, 50), F(7, 5))
comparison_eta = (F(-1, 2), F(37, 100))


def boundary_polynomial(a, x):
    return (a+F(1, 2))**2+(a*x+F(1, 2))**2-Q


def local_a_bounds(role, lower, upper):
    signed = tuple(F(*v) for v in budget['signed_intervals'][role])
    assert signed[0]*signed[1] > 0
    xmin, xmax = sorted(map(abs, signed))
    low_test = boundary_polynomial(lower, xmax)
    high_test = boundary_polynomial(upper, xmin)
    assert 0 < lower < upper and low_test < 0 < high_test
    # The polynomial is strictly increasing in a>0 and x>=0.
    return (lower, upper), (low_test, high_test)


T_a, T_tests = local_a_bounds(3, F(13632, 10000), F(13693, 10000))
G_a, G_tests = local_a_bounds(6, F(13715, 10000), F(13779, 10000))
assert Q < 4
# Every boundary radius is less than 3/2: r²+rB+1/2=Q<4, B>=1.
assert F(3, 2)**2+F(3, 2)+F(1, 2) > Q

# In the named frame T has local center (-a*t3,a). Its frame differs from
# A's by at most S, so a rotation changes its vertical projection by <3S/2.
T = (T_a[0]-F(3, 2)*S-radial_transfer,
     T_a[1]+F(3, 2)*S+radial_transfer)
# G's actual frame is the named tilted reference frame, so its transverse
# coordinate is exactly -a. The reference H coordinate is h2+1/2.
eta = (-G_a[1]-h2[1]-F(1, 2)-radial_transfer,
       -G_a[0]-h2[0]-F(1, 2)+radial_transfer)
assert comparison_T[0] < T[0] < T[1] < comparison_T[1]
assert comparison_eta[0] < eta[0] < eta[1] < comparison_eta[1]


def rationals(values):
    return [[v.numerator, v.denominator] for v in values]


out = {
    'status': 'EXACT CONDITIONAL ALL-OUTER SLIDER AUDIT PASS',
    'input': str(source),
    'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'external_premises': {
        'terminal_signed_owner_and_angle_budget': 'separate complete pair certificates',
        'named_quarter_turns': 'separate exact scalar angle audit and sector deduction',
        'stationary_reference_h2_bounds': rationals(h2),
    },
    'Q': [Q.numerator, Q.denominator],
    'S_upper': [S.numerator, S.denominator],
    'radial_transfer_allowance': [radial_transfer.numerator, radial_transfer.denominator],
    'T_local_a_bounds': rationals(T_a),
    'G_local_a_bounds': rationals(G_a),
    'T_boundary_substitution_signs': rationals(T_tests),
    'G_boundary_substitution_signs': rationals(G_tests),
    'actual_T_height_bounds': rationals(T),
    'actual_G_eta_bounds': rationals(eta),
    'comparison_T_interval': rationals(comparison_T),
    'comparison_eta_interval': rationals(comparison_eta),
    'approximate_T_height_bounds': list(map(float, T)),
    'approximate_G_eta_bounds': list(map(float, eta)),
    'scope': 'All scalar substitutions exact; the declared broad-chart h2 bound remains an external analytic premise.',
}
dest = ROOT/'all_outer_terminal_slider_audit.json'
with dest.open('w') as f:
    json.dump(out, f, indent=2)
    f.write('\n')
    f.flush()
    os.fsync(f.fileno())
print(out['status'])
print('T height:', out['approximate_T_height_bounds'])
print('G eta:', out['approximate_G_eta_bounds'])
