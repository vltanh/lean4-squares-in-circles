#!/usr/bin/env python3
"""Independent exact owner/slider coefficient audit on the broad graph.

The stationary graph is proved separately. This program encloses its whole
certified affine corridor and all32 owner choices on the four slider corners.
It uses no sampled minima or numerical solver.
"""
from fractions import Fraction as F
from pathlib import Path
from contextlib import redirect_stdout
from itertools import product
from types import SimpleNamespace
import hashlib
import io
import json
import os
import sys

sys.path.insert(0, 'n8/research/eight')
with redirect_stdout(io.StringIO()):
    import verify_quantitative_slider_tube as old

I = old.I
scale = old.ROOT.SCALE
premise_path = Path('global_attack/broad_stationary_h2_audit.json')
premise = json.loads(premise_path.read_text())
assert premise['status'] == 'EXACT BROAD STATIONARY GRAPH AND h2 AUDIT PASS'
assert premise['q_box_scaled'] == [old.ROOT.q.lo, old.ROOT.q.hi]
assert premise['scale'] == scale
T = (F(29, 50), F(7, 5))
ETA = (F(-1, 2), F(37, 100))
names = ('A', 'B', 'T', 'D', 'E', 'H', 'G')
where = {name: k for k, name in enumerate(names)}
zero, one, two, half = I(0), I(1), I(2), I(F(1, 2))
inner = lambda a, b: a[0]*b[0]+a[1]*b[1]
sub = lambda a, b: (a[0]-b[0], a[1]-b[1])
norm2 = lambda a: abs(a[0])*abs(a[0])+abs(a[1])*abs(a[1])
rows = []
previous = F(1, 20)
for cell_index, cell in enumerate(premise['rows']):
    zl, zh = [F(*v) for v in cell['z_interval']]
    assert zl == previous < zh
    previous = zh
    z = I(zl, zh)
    y = I(old.ROOT.y0)+F(5, 4)*(z-I(old.ROOT.z0))+I(F(-1, 2000), F(1, 2000))
    d = SimpleNamespace(**old.calc(old.ROOT.q, y, z))
    d.Fyy.gt(7)
    d.c.gt(0)
    d.s.gt(0)
    (d.s/d.c).lt(F(1, 5))
    mu = [d.mA, d.mB, d.mD, d.mE, d.mH]
    weights = [d.ab, d.tb, d.dt, d.ed, d.W, d.wHG, d.he]
    for v in mu:
        v.gt(F(1, 50))
        v.lt(1)
    for v in weights:
        v.gt(0)
        v.lt(1)
    sum(weights, zero).lt(6)
    (d.h1*d.h1+d.h2*d.h2).lt(4)
    incidence = [d.ab+d.W, d.ab+d.tb, d.dt+d.ed, d.ed+d.he, d.W+d.he]
    bcoef = [2*m+v for m, v in zip(mu, incidence)]
    young = sum((b*b/(2*m) for b, m in zip(bcoef, mu)), zero)
    young.lt(100)
    pA = (d.x1-half, d.y+half)
    pB = (d.x2-half, d.y+I(F(3, 2)))
    pD = (d.x3+half, d.y3-half)
    pE = (d.x4+half, d.y4+half)
    pH = ((d.h1+half)*d.c-(d.h2+half)*d.s,
          (d.h1+half)*d.s+(d.h2+half)*d.c)
    edges = [('A', 'B', d.ab), ('T', 'B', d.tb), ('D', 'T', d.dt),
             ('E', 'D', d.ed), ('H', 'G', d.wHG)]
    e, f = (d.c, d.s), (-d.s, d.c)
    minimum = None
    max_neighbor_norm2 = None
    max_slider_norm2 = None
    comparisons = 0
    for height, eta in product(T, ETA):
        height, eta = I(height), I(eta)
        pT = (d.x2-I(F(3, 2)), height)
        pG = (pH[0]+d.c-eta*d.s, pH[1]+d.s+eta*d.c)
        poses = dict(A=pA, B=pB, T=pT, D=pD, E=pE, H=pH, G=pG)
        for a, b in [('A', 'B'), ('T', 'B'), ('D', 'T'), ('E', 'D'),
                     ('G', 'A'), ('H', 'G'), ('H', 'E')]:
            n = norm2(sub(poses[b], poses[a]))
            n.lt(4)
            max_neighbor_norm2 = n.hi if max_neighbor_norm2 is None else max(max_neighbor_norm2, n.hi)
        for point in (pT, pG):
            n = norm2(point)
            n.lt(4)
            max_slider_norm2 = n.hi if max_slider_norm2 is None else max(max_slider_norm2, n.hi)
        transverse = [d.x1-d.x2, pB[1]-height, height-pD[1], d.x4-d.x3, eta]
        Y_GA = inner(f, sub(pA, pG))
        Y_HE = -inner(e, sub(pE, pH))
        smooth = [d.B[0], d.B[1], zero, d.B[3], d.B[4],
                  d.mH*(d.h1-d.h2)+d.he*((d.c-d.s)/two-Y_HE),
                  d.W*((d.c-d.s)/two-Y_GA)]
        for owners in product((0, 1), repeat=5):
            v = [I(x) for x in smooth]
            for k, choice in enumerate(owners):
                a, b, weight = edges[k]
                owner = (a, b)[choice]
                v[where[owner]] = v[where[owner]]-weight*transverse[k]
            cED = v[where['E']]
            cDT = v[where['D']]+cED
            cTB = v[where['T']]+cDT
            cAB = -v[where['B']]-cTB
            cHG = v[where['H']]
            for coefficient, (_, _, weight) in zip((cAB, cTB, cDT, cED, cHG), edges):
                reserve = weight/two-abs(coefficient)
                reserve.gt(F(9, 500))
                minimum = reserve.lo if minimum is None else min(minimum, reserve.lo)
                comparisons += 1
    assert comparisons == 640
    rows.append({'z_interval': cell['z_interval'], 'minimum_reserve_lower': minimum,
                 'young_upper': young.hi, 'max_neighbor_norm_squared': max_neighbor_norm2,
                 'max_slider_norm_squared': max_slider_norm2, 'owner_coefficient_comparisons': comparisons})

assert previous == F(81, 1000) and len(rows) == 512
assert F(9, 500)-128*F(1, 10000) > 0
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
result = {
    'status': 'INDEPENDENT EXACT BROAD DUAL COEFFICIENT AUDIT PASS',
    'source_sha256': sha(__file__), 'stationary_graph_audit_sha256': sha(premise_path),
    'arithmetic_source_sha256': sha('n8/research/eight/verify_adaptive_seven_square_dual.py'),
    'derivative_source_sha256': sha('n8/research/eight/verify_quantitative_slider_tube.py'),
    'pieces': len(rows), 'owner_coefficient_comparisons': sum(r['owner_coefficient_comparisons'] for r in rows),
    'scale': scale, 'T_interval': [[x.numerator, x.denominator] for x in T],
    'eta_interval': [[x.numerator, x.denominator] for x in ETA],
    'minimum_angular_reserve_lower': min(r['minimum_reserve_lower'] for r in rows),
    'maximum_young_upper': max(r['young_upper'] for r in rows),
    'nonlinear_remainder_coefficient': 128,
    'uniform_final_linear_reserve': [13, 2500],
    'rows': rows,
}
dest = Path('audit_capture/broad_dual_coefficients_independent_audit.json')
with dest.open('w') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
    f.flush()
    os.fsync(f.fileno())
print(result['status'])
print('All327680 owner coefficients exceed9/500; Young sum<100; all norm/weight bounds pass.')
print('Minimum reserve display:', result['minimum_angular_reserve_lower']/scale)
print('Maximum Young display:', result['maximum_young_upper']/scale)
