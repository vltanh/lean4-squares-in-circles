#!/usr/bin/env python3
"""Exact rational audit of the entire canonical all-outer capture cover.

This proves interval-cover and input-domain interfaces. Each pair inequality
still requires its complete executable manifest; absent proofs are reported
as pending. The reflection/canonical-maximum argument is a separate hand
lemma explicitly stated in ALL_OUTER_CAPTURE_ROADMAP.md.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib, json, os

BASE=Path('audit_capture')
REGISTRY=Path('m5_agent/completed_capture_registry.json')
records=json.loads(REGISTRY.read_text())['records']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=[(r,json.loads(Path(r['data']).read_text())) for r in records]
proof_keys=('Q','core_radius','is_core','K','positive_domains','allowed_signs',
            'beta','beta_by_edge','psi_numerators','psi_negative_numerators',
            'psi_denominator','gamma_numerators','gamma_denominator',
            'symmetric_gamma','unordered_pairs','required_pairs')
QS=F(97888353437936885663,25000000000000000000)
PI2HI=F(6283185307179586476925286766559006,10**33)
used=[]
stages=[]

def interval(v): return tuple(F(str(x)) for x in v)
def encode(b): return [[[a.numerator,a.denominator],[c.numerator,c.denominator]] for a,c in b]
def merge(iv):
    ans=[]
    for a,b in sorted(iv):
        if ans and a<=ans[-1][1]: ans[-1]=(ans[-1][0],max(ans[-1][1],b))
        else: ans.append((a,b))
    return ans
def subset(v,iv): return any(a<=v[0]<=v[1]<=b for a,b in iv)
def domains(j):
    ans=[]
    for v,s in zip(j['positive_domains'],j['allowed_signs']):
        lo,hi=[F(*x)for x in v]
        assert F(0)<=lo<hi<=1 and s and set(s)<=set((-1,1))
        ans.append(merge([(-hi,-lo)]*(-1 in s)+[(lo,hi)]*(1 in s)))
    assert len(ans)==7
    return ans
def canonical_cap(b):
    assert b[0][1]<=0
    cap=-b[0][0]
    return [b[0]]+[(max(a,-cap),min(c,cap))for a,c in b[1:]]

def cut(path,premise,role,outside):
    path=Path(path)
    j=json.loads(path.read_text())
    wanted=list(premise);wanted[role]=outside;wanted=canonical_cap(wanted)
    assert F(*j['Q'])==QS and F(*j['core_radius'])==F(1,12)
    assert j['is_core']==[False]*7
    assert F(*j['beta'])==0 and all(F(*b)==0 for b in j.get('beta_by_edge',[]))
    assert not j['symmetric_gamma'] and not j['unordered_pairs']
    assert j['required_pairs']==[[i,(i+1)%7] for i in range(7)]
    assert not j.get('checked_axes_by_edge') and not j.get('checked_axes')
    declared=domains(j)
    for i,v in enumerate(wanted): assert subset(v,declared[i]),(str(path),i,v,declared[i])
    total=sum(F(j['gamma_numerators'][i][(i+1)%7],j['gamma_denominator'])for i in range(7))
    assert total==F(*j['cost_sum']) and total>PI2HI
    matches=[]
    for r,j2 in frozen:
        if all(j.get(k)==j2.get(k)for k in proof_keys):
            mp=Path(r['manifest']);m=json.loads(mp.read_text())
            assert sha(mp)==r['manifest_sha256'] and m['status']=='ALL DECLARED BRANCHES PASSED'
            assert sha(r['data'])==m['data_json_sha256']
            audit=BASE/(r['name']+'_audit.json')
            independent=False
            if audit.exists():
                a=json.loads(audit.read_text())
                independent=(a['manifest_sha256']==sha(mp) and
                             a['status']=='INDEPENDENT BINDING AND COVERAGE AUDIT PASS')
            matches.append({'name':r['name'],'manifest':str(mp),'sha256':sha(mp),
                            'independent_audit_matches':independent})
    used.append({'input':str(path),'input_sha256':sha(path),'role':role,
                 'closed_excluded_interval':encode([outside])[0],
                 'covered_box_after_canonical_cap':encode(wanted),
                 'exact_status':'MATCHED AUDITED MANIFEST'if matches else'PENDING EXACT MANIFEST',
                 'matching_manifests':matches})
    return outside

def cover(old,retained,cuts):
    assert subset(old,merge([retained]+cuts)),(old,retained,cuts)
def record_stage(name,before,after,start):
    stages.append({'name':name,'premise_box':encode(before),
                   'conclusion_box':encode(after),'cuts':list(range(start,len(used)))})

# Choosing a maximum absolute tangent and reflecting reverses the cyclic order
# while negating every tangent. It leaves the all-O word unchanged.
full=[(F(-1),F(0))]+[(F(-1),F(1))]*6
start=len(used)
cuts=[cut('m5_agent/all_outer_far0_pair_data.json',full,0,(F(-1,2),F(0))),
      cut('m5_agent/all_outer_far1_pair_data.json',full,0,(F(-3,4),F(-1,2)))]
first=list(full);first[0]=(F(-1),F(-3,4))
cover(full[0],first[0],cuts)
record_stage('Canonical max tangent exceeds3/4',full,first,start)

def prefix(plan_name,before,alias=None):
    plan=json.loads((BASE/plan_name).read_text())
    grouped={}
    for r in plan['branches']: grouped.setdefault(r['role'],[]).append(r)
    state=list(before);start=len(used)
    for role,rows in sorted(grouped.items()):
        retained=interval(rows[0]['target'])
        assert state[role][0]<=retained[0]<retained[1]<=state[role][1]
        cuts=[]
        for row in rows:
            assert interval(row['target'])==retained
            outside=interval(row['outside'])
            assert state[role][0]<=outside[0]<outside[1]<=state[role][1]
            stem=str(row['file']).removesuffix('.box.json')
            path=(alias or {}).get(stem,stem+'_checked_candidate.json')
            cuts.append(cut(path,state,role,outside))
        cover(state[role],retained,cuts)
        state[role]=retained
    expected=[interval(v)for v in plan['terminal_box']]
    assert state==expected,(plan_name,state,expected)
    record_stage(plan_name,before,state,start)
    return state

coarse=prefix('all_outer_coarse_prefix_v2_plan.json',first,{
    'audit_capture/all_outer_v2_prefix_1_0':'m5_agent/all_outer_role1_negative_pair_data.json',
    'audit_capture/all_outer_v2_prefix_1_1':'m5_agent/all_outer_role1_positive_pair_data.json'})

start=len(used)
cuts=[cut(BASE/'all_outer_anchor_low_checked_candidate.json',coarse,0,(F(-1),F(-97,100))),
      cut(BASE/'all_outer_anchor_high_checked_candidate.json',coarse,0,(F(-9,10),F(-3,4)))]
anchored=list(coarse);anchored[0]=(F(-97,100),F(-9,10))
cover(coarse[0],anchored[0],cuts)
anchored=canonical_cap(anchored)
record_stage('Canonical H anchor',coarse,anchored,start)
near=prefix('all_outer_near_prefix_plan.json',anchored)
terminal=prefix('all_outer_terminal_prefix_plan.json',near)

budget=json.loads((BASE/'all_outer_terminal_budget_v1.json').read_text())
assert domains(budget)==[[v]for v in terminal]
assert len(used)==45
pending=[r['input']for r in used if not r['matching_manifests']]
not_independent=[r['input']for r in used if not any(m['independent_audit_matches']for m in r['matching_manifests'])]
summary={'status':'EXACT RATIONAL DOMAIN-COVER AUDIT PASS; pair and terminal proof status remains explicit',
         'geometric_premises':['physical seven-exterior radial boundary ring',
              'fixed-Qsharp outer-radius transfer','cyclic relabeling',
              'plane reflection plus reversal negates all local tangents',
              'role0 has maximum absolute tangent and nonpositive sign'],
         'registry':str(REGISTRY),'registry_sha256':sha(REGISTRY),
         'ordinary_cut_count':45,'matched_exact_cut_count':45-len(pending),
         'independently_audited_cut_count':45-len(not_independent),
         'all_pair_manifests_matched':not pending,'pending_inputs':pending,
         'pending_independent_audits':not_independent,'stages':stages,'cuts':used,
         'terminal_budget_domain_matches':True,
         'terminal_budget_sha256':sha(BASE/'all_outer_terminal_budget_v1.json')}
dest=BASE/'all_outer_domain_cover_audit.json'
with dest.open('w')as f:json.dump(summary,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print('PASS: all45 closed exclusion domains cover the entire canonical all-O domain outside the terminal box')
print('PASS: every canonical-maximum truncation and rational input-domain inclusion')
print('PASS: final box exactly matches the terminal budget domain')
print('Exact manifests:',45-len(pending),'/45; independent audits:',45-len(not_independent),'/45')
