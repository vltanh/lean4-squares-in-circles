#!/usr/bin/env python3
"""Exact reduced-curvature audit on the already certified stationary corridor.

Ftt is formed using h1tt=-h1-2 and h2tt=-h2-1. The resulting Schur
complement is d²/dt² F(q,y(t),t) along the graph Fy=0.
"""
from fractions import Fraction as F
from pathlib import Path
from contextlib import redirect_stdout
import hashlib
import io
import json
import os
import sys

sys.path.insert(0,'n8/research/eight')
with redirect_stdout(io.StringIO()):
    import verify_quantitative_slider_tube as old
I=old.I
source=Path('global_attack/broad_stationary_h2_audit.json')
premise=json.loads(source.read_text())
assert premise['status']=='EXACT BROAD STATIONARY GRAPH AND h2 AUDIT PASS'
Q=old.ROOT.q
assert [Q.lo,Q.hi]==premise['q_box_scaled']
Y0=old.ROOT.y0;Z0=old.ROOT.z0
slope=F(*premise['affine_slope']);radius=F(*premise['half_corridor_width'])
scale=old.ROOT.SCALE
rows=[]
for row in premise['rows']:
    lo,hi=[F(*x) for x in row['z_interval']]
    z=I(lo,hi);y=I(Y0)+slope*(z-I(Z0))+I(-radius,radius)
    v=old.calc(Q,y,z)
    v['Fyy'].gt(7)
    Ftt=2*(v['h1t']*v['h1t']+v['h2t']*v['h2t']
           -v['h1']*(v['h1']+2)-v['h2']*(v['h2']+1))
    reduced=Ftt-abs(v['Fyt'])*abs(v['Fyt'])/v['Fyy']
    reduced.gt(1)
    rows.append({'z_interval':row['z_interval'],'Ftt_lower':Ftt.lo,
                  'reduced_curvature_lower':reduced.lo,
                  'reduced_curvature_upper':reduced.hi})

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
result={'status':'EXACT BROAD REDUCED CURVATURE AUDIT PASS',
        'source_sha256':sha(__file__),'stationary_graph_audit':str(source),
        'stationary_graph_audit_sha256':sha(source),
        'arithmetic_source_sha256':sha('n8/research/eight/verify_adaptive_seven_square_dual.py'),
        'derivative_source_sha256':sha('n8/research/eight/verify_quantitative_slider_tube.py'),
        'scale':scale,'pieces':len(rows),'uniform_rational_lower_bound':[1,1],
        'reduced_curvature_lower':min(x['reduced_curvature_lower'] for x in rows),
        'reduced_curvature_upper':max(x['reduced_curvature_upper'] for x in rows),
        'rows':rows}
path=Path('global_attack/broad_reduced_curvature_audit.json')
with path.open('w') as f:
    f.write(json.dumps(result,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print('PASS: reduced curvature Ftt-Fyt²/Fyy>1 on the full broad stationary corridor')
print('Enclosure display:',result['reduced_curvature_lower']/scale,
      result['reduced_curvature_upper']/scale)
print('Consequently the stationary reduced F is strictly convex, with its candidate minimum0')
