#!/usr/bin/env python3
"""Exact scalar angle-lift consequences of a frozen endpoint budget.

Independent conditional audit: it does not certify the pair budget itself.
"""
import argparse
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import os

ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('--output')
ap.add_argument('--capture-domain',help='An already proved subdomain; pair-budget domain is unchanged')
ap.add_argument('--phase',choices=['t','g','all_o']);args=ap.parse_args()
src=Path(args.input);p=json.loads(src.read_text());phase=args.phase or p['phase']
K=p['K'];pd=p['psi_denominator'];eps=F(*p['pair_excess_upper'])
U=F(6283185307179586476925286766559006,10**33);L=U-F(1,10**33)
halfpi=(L/4,U/4)
captured=[[F(*x) for x in row] for row in p['signed_intervals']]
capture_binding=None
if args.capture_domain:
    cap=Path(args.capture_domain);raw=json.loads(cap.read_text())
    captured=[[F(*x) for x in row] for row in raw['rational_intervals']]
    for actual,declared in zip(captured,p['signed_intervals']):
        a,b=map(lambda x:F(*x),declared)
        assert a<=actual[0]<actual[1]<=b
    capture_binding={'path':str(cap),'sha256':hashlib.sha256(cap.read_bytes()).hexdigest()}


def atan_bounds(x):
    if x<0:
        lo,hi=atan_bounds(-x);return -hi,-lo
    assert 0<=x<1
    terms=[(-1)**j*x**(2*j+1)/F(2*j+1) for j in range(20)]
    return sum(terms),sum(terms[:-1])


def f_bounds(i):
    lo,hi=[F(*x) for x in p['signed_intervals'][i]]
    assert lo*hi>=0
    neg=hi<=0
    a,b=[F(*x) for x in p['positive_domains'][i]]
    vals=p['psi_negative_numerators'][i] if neg else p['psi_numerators'][i]
    pieces=[]
    for k in range(K):
        x0,x1=a+(b-a)*F(k,K),a+(b-a)*F(k+1,K)
        t0,t1=(-x1,-x0) if neg else (x0,x1)
        t0,t1=max(t0,captured[i][0]),min(t1,captured[i][1])
        if t0>=t1:continue
        v0,v1=F(vals[k],pd),F(vals[k+1],pd)
        def at(t):return v0+(v1-v0)*(abs(t)-x0)/(x1-x0)
        w0,w1=at(t0),at(t1)
        pieces.append((min(w0,w1)-atan_bounds(t1)[1],
                       max(w0,w1)-atan_bounds(t0)[0]))
    return min(x[0] for x in pieces),max(x[1] for x in pieces)


expected,mixed={
    't':([1,0,None,0,None,1,0],2),
    'g':([None,0,1,0,1,None,0],0),
    'all_o':([None,1,0,1,0,None,0],5),
}[phase]
ranges=[f_bounds(i) for i in range(7)];rows=[]
for i in range(7):
    j=(i+1)%7;gamma=F(p['gamma_numerators'][i][j],p['gamma_denominator'])
    beta=F(*p['beta_by_edge'][i])
    lo=gamma+ranges[i][0]-ranges[j][1]
    hi=gamma+ranges[i][1]-ranges[j][0]+beta/4+eps
    k=expected[i]
    if k is not None:
        assert lo>k*halfpi[1]-F(1,4),(i,float(lo))
        assert hi<k*halfpi[0]+F(1,4),(i,float(hi))
    rows.append({'edge':[i,j],'quarter_turn':k,
                 'phi_bounds':[[lo.numerator,lo.denominator],[hi.numerator,hi.denominator]],
                 'approximate_phi_bounds':[float(lo),float(hi)]})
assert F(*p['beta_by_edge'][mixed])==0
phi_lo,phi_hi=map(lambda x:F(*x),rows[mixed]['phi_bounds'])
tlo,thi=halfpi[0]-phi_hi,halfpi[1]-phi_lo
print('NAMED TILT EXACT ENCLOSURE, approximate display:',float(tlo),float(thi),flush=True)
passed=F(1,10)<tlo<=thi<F(4,25)
result={'status':'PASS' if passed else 'BROAD CHART NOT YET COVERED',
        'scope':'Conditional on the frozen pair budget and its captured role domain',
        'input':str(src),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
        'capture_domain':capture_binding,
        'phase':phase,'mixed_tilt_edge':mixed,'relative_angles':rows,
        'named_tilt_bounds':[[tlo.numerator,tlo.denominator],[thi.numerator,thi.denominator]],
        'approximate_named_tilt_bounds':[float(tlo),float(thi)],
        'required_named_tilt_bounds':[[1,10],[4,25]]}
dest=Path(args.output) if args.output else src.with_name(src.stem+'_angle_audit.json')
with dest.open('w') as f:
    f.write(json.dumps(result,indent=2)+'\n');f.flush();os.fsync(f.fileno())
assert passed
print('PASS: all five aligned quarter-turns fixed; named tilt in[1/10,4/25]')
