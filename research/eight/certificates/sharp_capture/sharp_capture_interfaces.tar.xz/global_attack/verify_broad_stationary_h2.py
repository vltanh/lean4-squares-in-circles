#!/usr/bin/env python3
"""Independent rational certificate of the broad stationary graph and h2.

Uses the existing exact fixed-point interval arithmetic and derivative
formulas. The affine corridor is proved by strict derivative signs; it is
not taken from floating minimization. No dual coefficient theorem is assumed.
"""
from fractions import Fraction as F
from pathlib import Path
from contextlib import redirect_stdout
import argparse
import hashlib
import io
import json
import os
import sys

ap=argparse.ArgumentParser();ap.add_argument('--pieces',type=int,default=512)
ap.add_argument('--output',default='global_attack/broad_stationary_h2_audit.json')
args=ap.parse_args();assert args.pieces>0
sys.path.insert(0,'n8/research/eight')
with redirect_stdout(io.StringIO()):
    import verify_quantitative_slider_tube as old
I=old.I
Q=old.ROOT.q
Y0=old.ROOT.y0;Z0=old.ROOT.z0
ZL=F(1,20);ZH=F(81,1000);YR=F(1,2000);SLOPE=F(5,4)
HL=F(-29,20);HH=F(-7,5)
scale=old.ROOT.SCALE
assert 2*(ZL-ZL**3/3)<F(1,10)
assert 2*(ZH-ZH**3/3)>F(4,25)
# At t=.10, z=tan(t/2)>.05 since atan(z)<z. The second inequality
# proves .16<2atan(.081). Thus the captured tilt interval is inside this chart.
root_y=I(Y0-F(1,10**16),Y0+F(1,10**16))
root_z=I(Z0-F(1,10**16),Z0+F(1,10**16))
center_at_root=I(Y0)+SLOPE*(root_z-I(Z0))
assert root_y.lo>(center_at_root-I(YR)).hi
assert root_y.hi<(center_at_root+I(YR)).lo

rows=[]
for k in range(args.pieces):
    lo=ZL+(ZH-ZL)*F(k,args.pieces)
    hi=ZL+(ZH-ZL)*F(k+1,args.pieces)
    z=I(lo,hi)
    center=I(Y0)+SLOPE*(z-I(Z0))
    lower=old.calc(Q,center-I(YR),z)['Fy']
    upper=old.calc(Q,center+I(YR),z)['Fy']
    vals=old.calc(Q,center+I(-YR,YR),z)
    lower.lt(0);upper.gt(0);vals['Fyy'].gt(7)
    vals['h2'].gt(HL);vals['h2'].lt(HH)
    rows.append({'z_interval':[[lo.numerator,lo.denominator],[hi.numerator,hi.denominator]],
                  'lower_Fy_upper':lower.hi,'upper_Fy_lower':upper.lo,
                  'Fyy_lower':vals['Fyy'].lo,'h2_lower':vals['h2'].lo,'h2_upper':vals['h2'].hi})

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
result={'status':'EXACT BROAD STATIONARY GRAPH AND h2 AUDIT PASS',
        'scope':'Each q in the isolated root q interval; stationary graph identified with the exact candidate at its root',
        'source_sha256':sha(__file__),
        'arithmetic_source':'n8/research/eight/verify_adaptive_seven_square_dual.py',
        'arithmetic_source_sha256':sha('n8/research/eight/verify_adaptive_seven_square_dual.py'),
        'derivative_source':'n8/research/eight/verify_quantitative_slider_tube.py',
        'derivative_source_sha256':sha('n8/research/eight/verify_quantitative_slider_tube.py'),
        'scale':scale,'q_box_scaled':[Q.lo,Q.hi],
        'z_interval':[[ZL.numerator,ZL.denominator],[ZH.numerator,ZH.denominator]],
        'affine_slope':[SLOPE.numerator,SLOPE.denominator],
        'half_corridor_width':[YR.numerator,YR.denominator],
        'h2_rational_bound':[[HL.numerator,HL.denominator],[HH.numerator,HH.denominator]],
        'pieces':args.pieces,'worst_lower_Fy_upper':max(r['lower_Fy_upper'] for r in rows),
        'worst_upper_Fy_lower':min(r['upper_Fy_lower'] for r in rows),
        'Fyy_lower':min(r['Fyy_lower'] for r in rows),
        'h2_lower':min(r['h2_lower'] for r in rows),
        'h2_upper':max(r['h2_upper'] for r in rows),'rows':rows}
path=Path(args.output)
with path.open('w') as f:
    f.write(json.dumps(result,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print('PASS:',args.pieces,'closed z cells cover[1/20,81/1000]')
print('PASS: opposite Fy signs on the affine corridor, with Fyy>7 throughout')
print('PASS: the stationary graph contains the exact candidate root')
print('PASS: -29/20<h2<-7/5 on the entire stationary graph')
print('h2 enclosure display:',result['h2_lower']/scale,result['h2_upper']/scale)
