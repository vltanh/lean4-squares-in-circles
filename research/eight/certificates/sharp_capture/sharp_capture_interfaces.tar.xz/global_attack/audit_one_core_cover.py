#!/usr/bin/env python3
"""Exact finite-union audit for the two one-core terminal branches.

Only rational domain inclusions and closed interval covers are proved here.
Every ordinary pair input is separately matched to the exact-checker registry;
missing matches are reported, never promoted to proof by a discovery screen.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import os

ROOT=Path('global_attack')
REGISTRY=Path('m5_agent/completed_capture_registry.json')
Q=F(97888353437936885663,25000000000000000000)
U=F(6283185307179586476925286766559006,10**33)
PROOF_KEYS=('Q','core_radius','is_core','K','positive_domains','allowed_signs',
            'beta','beta_by_edge','psi_numerators','psi_negative_numerators',
            'psi_denominator','gamma_numerators','gamma_denominator',
            'symmetric_gamma','unordered_pairs','required_pairs')
records=json.loads(REGISTRY.read_text())['records']
frozen=[(r,json.loads(Path(r['data']).read_text())) for r in records]
cuts=[]
stages=[]


def box(rows):
    return [tuple(F(x) for x in row) for row in rows]


def encode(rows):
    return [[[a.numerator,a.denominator],[b.numerator,b.denominator]]
            for a,b in rows]


def merge(intervals):
    result=[]
    for a,b in sorted(intervals):
        assert a<=b
        if result and a<=result[-1][1]:
            result[-1]=(result[-1][0],max(b,result[-1][1]))
        else:result.append((a,b))
    return result


def contains(interval,union):
    a,b=interval
    return any(lo<=a<=b<=hi for lo,hi in union)


def domains(data):
    result=[]
    for row,signs in zip(data['positive_domains'],data['allowed_signs']):
        lo,hi=[F(*x) for x in row]
        assert 0<=lo<hi<=1 and set(signs)<=set((-1,1)) and signs
        pieces=[]
        if -1 in signs:pieces.append((-hi,-lo))
        if 1 in signs:pieces.append((lo,hi))
        result.append(merge(pieces))
    assert len(result)==7
    return result


def cut(path,premise,role,outside):
    path=Path(path);p=json.loads(path.read_text())
    wanted=list(premise);wanted[role]=tuple(F(x) for x in outside)
    assert F(*p['Q'])==Q and F(*p['core_radius'])==F(1,12)
    assert list(map(bool,p['is_core']))==[True,False,False,False,False,False,False]
    assert p.get('certificate_kind') in (None,'cyclic_exclusion')
    assert not p['symmetric_gamma'] and not p['unordered_pairs']
    assert not p.get('checked_axes_by_edge') and not p.get('checked_axes')
    assert p.get('required_pairs')==[[i,(i+1)%7] for i in range(7)]
    if p.get('beta_by_edge') is not None:
        assert all(F(*v)==0 for v in p['beta_by_edge'])
    else:assert F(*p['beta'])==0
    gamma=sum(F(p['gamma_numerators'][i][(i+1)%7],p['gamma_denominator'])
              for i in range(7))
    assert gamma>U,(str(path),'nonpositive cyclic exclusion reserve')
    declared=domains(p)
    for i,(a,b) in enumerate(zip(wanted,declared)):
        assert contains(a,b),(str(path),i,a,b)
    matches=[]
    for rec,q in frozen:
        if all(p.get(k)==q.get(k) for k in PROOF_KEYS):
            manifest=Path(rec['manifest'])
            assert hashlib.sha256(manifest.read_bytes()).hexdigest()==rec['manifest_sha256']
            m=json.loads(manifest.read_text())
            assert m['status']=='ALL DECLARED BRANCHES PASSED'
            assert hashlib.sha256(Path(rec['data']).read_bytes()).hexdigest()==m['data_json_sha256']
            assert not q.get('checked_axes_by_edge') and not q.get('checked_axes')
            audit=Path('audit_capture')/(rec['name']+'_audit.json')
            independent=False
            if audit.exists():
                a=json.loads(audit.read_text())
                independent=(a['manifest_sha256']==rec['manifest_sha256'] and
                             a['status']=='INDEPENDENT BINDING AND COVERAGE AUDIT PASS')
            matches.append({'name':rec['name'],'manifest':str(manifest),
                            'sha256':rec['manifest_sha256'],
                            'independent_audit_matches':independent})
    cuts.append({'input':str(path),'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                 'role':role,'excluded_closed_interval':encode([wanted[role]])[0],
                 'covered_box':encode(wanted),'cyclic_reserve':[gamma.numerator*U.denominator-U.numerator*gamma.denominator,gamma.denominator*U.denominator],
                 'matching_manifests':matches,
                 'exact_status':'MATCHED AUDITED MANIFEST' if matches else 'PENDING EXACT MANIFEST'})
    return wanted[role]


def cover(before,role,retained,excluded):
    union=merge(list(retained)+list(excluded))
    assert contains(before[role],union),(role,before[role],union)


def stage(name,before,after,start):
    stages.append({'name':name,'premise_box':encode(before),
                   'conclusion_box':encode(after),'cut_indices':list(range(start,len(cuts)))})


# A unique core is labelled0. Reflection and reversal i -> -i preserve that
# word and negate t0, so it suffices to cover the closed half interval[-1,0].
initial=box([('-1','1')]*7);initial[0]=(F(-1),F(0))
anchored=list(initial);anchored[0]=(F(-1,2),F(-1,8))
start=len(cuts)
out=[cut('m5_agent/one_core_b0_pair_data.json',initial,0,('-1','-1/2')),
     cut('m5_agent/one_core_b1_v2_pair_data.json',initial,0,('-1/8','0'))]
cover(initial,0,[anchored[0]],out)
stage('Unique-core sign choice and baseline anchor',initial,anchored,start)

# The prefix is sequential: its role2 inputs already assume role1, etc.
plan=json.loads(Path('audit_capture/one_core_coarse_prefix_plan.json').read_text())
ready=json.loads(Path('audit_capture/one_core_coarse_prefix_ready.json').read_text())
by_stem={v['stem']:v['candidate'] for v in ready['candidates']}
current=list(anchored)
for role in range(1,7):
    before=list(current);start=len(cuts);out=[]
    rows=[r for r in plan['branches'] if r['role']==role]
    assert rows
    target=tuple(F(x) for x in rows[0]['target'])
    for r in rows:
        assert tuple(F(x) for x in r['target'])==target
        stem=r['file'].removesuffix('.box.json')
        out.append(cut(by_stem[stem],before,role,r['outside']))
    cover(before,role,[target],out);current[role]=target
    stage(f'Coarse prefix role{role}',before,current,start)
base=box([('-1/2','-1/8'),('1/8','3/4'),('-3/4','-1/8'),('0','1/4'),
          ('-1','-3/4'),('-1/8','1/8'),('3/4','1')])
assert current==base

# Four ordinary cuts separate the two physically different endpoint phases.
phase_intervals={'t':(F(-9,32),F(-17,64)),
                 'g':(F(-15,64),F(-7,32))}
start=len(cuts);out=[]
for label,interval in [('t_anchor_left',('-1/2','-9/32')),
                       ('t_anchor_right',('-17/64','-1/4')),
                       ('g_anchor_left',('-1/4','-15/64')),
                       ('g_anchor_right',('-7/32','-1/8'))]:
    out.append(cut(ROOT/f'one_core_{label}_candidate_v2.json',base,0,interval))
cover(base,0,list(phase_intervals.values()),out)
stages.append({'name':'Two disjoint endpoint core phases','premise_box':encode(base),
               'retained_core_intervals':{k:encode([v])[0] for k,v in phase_intervals.items()},
               'cut_indices':list(range(start,len(cuts)))})

terminal={}
for phase in ['t','g']:
    premise=list(base);premise[0]=phase_intervals[phase]
    cap_path=ROOT/f'one_core_{phase}_capture_target.json'
    cap=json.loads(cap_path.read_text())
    target=[tuple(F(*x) for x in r) for r in cap['rational_intervals']]
    assert target[0]==premise[0]
    first=list(target)
    # The opposite side of role4 is reserved for one final conditional cut.
    first[4]=(target[4][0],premise[4][1]) if phase=='t' else (premise[4][0],target[4][1])
    role_plan=json.loads((ROOT/f'one_core_{phase}_first_role_cut_plan.json').read_text())
    results=json.loads((ROOT/f'one_core_{phase}_first_screened.json').read_text())['results']
    result_by_label={r['label']:r for r in results}
    start=len(cuts);excluded={i:[] for i in range(1,7)}
    for r in role_plan['records']:
        label=r['label']
        skip={'t':{'r2_low','r4_high'},'g':{'r4_low'}}[phase]
        if label in skip:continue
        result=result_by_label[label]
        assert result['status']=='SCREENED CANDIDATE READY FOR EXACT VALIDATION'
        path=Path(result['candidate'])
        assert hashlib.sha256(path.read_bytes()).hexdigest()==result['sha256']
        excluded[r['role']].append(cut(path,premise,r['role'],r['interval']))
    if phase=='t':
        excluded[2].append(cut(ROOT/'one_core_t_a_lower_stronger_complete_round0_candidate.json',
                                premise,2,('-3/4','-11/32')))
    for role in range(1,7):cover(premise,role,[first[role]],excluded[role])
    stage(f'{phase.upper()} phase independent role sides',premise,first,start)
    start=len(cuts)
    path=ROOT/('one_core_t_final_r4_high_complete_round0_candidate.json' if phase=='t'
               else 'one_core_g_final_r4_low_complete_round0_candidate.json')
    outside=(target[4][1],first[4][1]) if phase=='t' else (first[4][0],target[4][0])
    out=[cut(path,first,4,outside)]
    cover(first,4,[target[4]],out)
    stage(f'{phase.upper()} phase final conditional role4 side',first,target,start)
    budget_path=ROOT/f'one_core_{phase}_aligned_budget_v1.json'
    budget=json.loads(budget_path.read_text());declared=domains(budget)
    for i in range(7):assert contains(target[i],declared[i])
    terminal[phase]={'capture_target':str(cap_path),
                      'capture_sha256':hashlib.sha256(cap_path.read_bytes()).hexdigest(),
                      'box':encode(target),'budget':str(budget_path),
                      'budget_sha256':hashlib.sha256(budget_path.read_bytes()).hexdigest(),
                      'captured_box_is_subset_of_budget_domain':True}

assert len(cuts)==46
pending=[c['input'] for c in cuts if not c['matching_manifests']]
not_independent=[c['input'] for c in cuts
                 if not any(m['independent_audit_matches'] for m in c['matching_manifests'])]
summary={'status':'EXACT DOMAIN-COVER AUDIT PASS; missing pair manifests remain pending' if pending
                  else 'EXACT DOMAIN-COVER AND ALL46 PAIR-MANIFEST MATCHES PASS',
         'geometric_premises':['one unique core rotated to role0',
                               'reflection and reversal t_i -> -t_(-i mod7) permits t0<=0',
                               'sharp-ceiling boundary ring with physical holonomy2pi'],
         'registry':str(REGISTRY),'registry_sha256':hashlib.sha256(REGISTRY.read_bytes()).hexdigest(),
         'ordinary_cut_count':len(cuts),'matched_exact_cut_count':len(cuts)-len(pending),
         'independently_audited_cut_count':len(cuts)-len(not_independent),
         'all_pair_manifests_matched':not pending,'pending_inputs':pending,
         'pending_independent_audits':not_independent,
         'stages':stages,'cuts':cuts,'terminal_branches':terminal}
dest=ROOT/'one_core_domain_cover_audit.json'
with dest.open('w') as f:
    f.write(json.dumps(summary,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print('PASS: all46 closed exclusions cover the declared complements, with no domain gap')
print('PASS: two retained core phases, sequential prefixes, and conditional last cuts match')
print('PASS: both captured boxes lie in their frozen terminal budget domains')
print('Audited pair inputs matched:',len(cuts)-len(pending),'of',len(cuts))
print('Independent binding/coverage audits:',len(cuts)-len(not_independent),'of',len(cuts))
print('Pending exact inputs:',len(pending))
