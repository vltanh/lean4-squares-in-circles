#!/usr/bin/env python3
"""Exact scalar audit of the angle-lift consequences of the terminal budget.

This is conditional on the separately checked pair budget and its role box.
Only Fraction arithmetic is used. The alternating arctangent series supplies
outward bounds; the sharp Machin bound has its own independent audit.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import os

SOURCE = Path('global_attack/long_local_aligned_budget_v1.json')
p = json.loads(SOURCE.read_text())
K = p['K']
pd = p['psi_denominator']
eps = F(7, 10**7)
pi2_hi = F(6283185307179586476925286766559006, 10**33)
pi2_lo = pi2_hi - F(1, 10**33)
halfpi = (pi2_lo/4, pi2_hi/4)


def atan_positive_bounds(x):
    assert 0 <= x < 1
    # S_19 is below atan(x), while S_18 is above it.
    terms = [(-1)**j*x**(2*j+1)/F(2*j+1) for j in range(20)]
    return sum(terms), sum(terms[:-1])


def atan_bounds(x):
    if x < 0:
        lo, hi = atan_positive_bounds(-x)
        return -hi, -lo
    return atan_positive_bounds(x)


def psi_minus_atan_range(role):
    lo, hi = [F(*v) for v in p['signed_intervals'][role]]
    assert lo*hi >= 0 and lo < hi
    negative = hi <= 0
    abslo, abshi = [F(*v) for v in p['positive_domains'][role]]
    assert (abslo, abshi) == ((-hi, -lo) if negative else (lo, hi))
    vals = p['psi_negative_numerators'][role] if negative else p['psi_numerators'][role]
    extrema = []
    for k in range(K):
        x0 = abslo + (abshi-abslo)*F(k, K)
        x1 = abslo + (abshi-abslo)*F(k+1, K)
        t0, t1 = (-x1, -x0) if negative else (x0, x1)
        v0, v1 = F(vals[k], pd), F(vals[k+1], pd)
        # Piecewise linear psi lies between its nodal endpoint values. atan
        # is increasing, so the separate outward ranges are immediate.
        extrema.append((min(v0, v1)-atan_bounds(t1)[1],
                        max(v0, v1)-atan_bounds(t0)[0]))
    return min(x[0] for x in extrema), max(x[1] for x in extrema)


ranges = [psi_minus_atan_range(i) for i in range(7)]
rows = []
expected_quarters = [1, 0, None, 0, None, 1, 0]
for i in range(7):
    j = (i+1)%7
    gamma = F(p['gamma_numerators'][i][j], p['gamma_denominator'])
    beta = F(*p['beta_by_edge'][i])
    # δ+atan(t_next)-atan(t_source) = gamma+f_source-f_next
    # plus beta*h and the nonnegative pair residual. Here h<1/4 suffices.
    lo = gamma + ranges[i][0] - ranges[j][1]
    hi = gamma + ranges[i][1] - ranges[j][0] + beta/4 + eps
    k = expected_quarters[i]
    if k is not None:
        assert lo > k*halfpi[1] - F(1, 4)
        assert hi < k*halfpi[0] + F(1, 4)
    rows.append({'edge': [i, j], 'relative_canonical_angle':
                 [[lo.numerator, lo.denominator], [hi.numerator, hi.denominator]],
                 'approximate_enclosure': [float(lo), float(hi)],
                 'aligned_quarter_turn': k})

# Edge2 has no penalty. The actual named tilt is pi/2 minus this canonical
# relative angle. Its positive interval fixes the choice of frame representative.
assert F(*p['beta_by_edge'][2]) == 0
edge2lo, edge2hi = [F(*v) for v in rows[2]['relative_canonical_angle']]
tiltlo, tilthi = halfpi[0]-edge2hi, halfpi[1]-edge2lo
assert tiltlo > F(1, 10)
assert tilthi < F(4, 25)

out = {
    'status': 'EXACT CONDITIONAL SCALAR AUDIT PASS; pair budget and role cover are separate gates',
    'input': str(SOURCE), 'input_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'method': 'Fraction arithmetic; 20-term alternating atan bounds; independent 33-place Machin enclosure',
    'pair_excess_upper': [eps.numerator, eps.denominator],
    'canonical_relative_angle_bounds': rows,
    'actual_named_tilt_bounds': [[tiltlo.numerator, tiltlo.denominator],
                                [tilthi.numerator, tilthi.denominator]],
    'actual_named_tilt_rational_outer_bounds': [[1, 10], [4, 25]],
    'approximate_tilt_enclosure': [float(tiltlo), float(tilthi)],
}
dest = Path('global_attack/long_terminal_angle_lift_audit.json')
with dest.open('w') as f:
    f.write(json.dumps(out, indent=2)+'\n')
    f.flush()
    os.fsync(f.fileno())
print('PASS: all five aligned quarter-turn lifts are fixed')
print('PASS: named mixed-frame tilt lies strictly between1/10 and4/25')
print('outward exact enclosure, decimals for display:', float(tiltlo), float(tilthi))
