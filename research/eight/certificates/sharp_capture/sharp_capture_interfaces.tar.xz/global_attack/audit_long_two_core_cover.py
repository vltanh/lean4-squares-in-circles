#!/usr/bin/env python3
"""Audit the exact finite domain cover and match available proof manifests.

This checks rational box inclusion, one-coordinate interval coverage, and the
explicit reflection/max-core deductions. It does not replace the mathematical
radial-reduction, reflection, or pair-inequality theorems.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import os

BASE=Path('global_attack')
REGISTRY=Path('m5_agent/completed_capture_registry.json')
records=json.loads(REGISTRY.read_text())['records']
proof_keys=('Q','core_radius','is_core','K','positive_domains','allowed_signs',
            'beta','beta_by_edge','psi_numerators','psi_negative_numerators',
            'psi_denominator','gamma_numerators','gamma_denominator',
            'symmetric_gamma','unordered_pairs','required_pairs')
frozen=[]
for rec in records:
    data=Path(rec['data'])
    frozen.append((rec,json.loads(data.read_text())))


def box(*rows):
    return [tuple(F(x) for x in row) for row in rows]


def merge(intervals):
    result=[]
    for a,b in sorted(intervals):
        if result and a<=result[-1][1]:result[-1]=(result[-1][0],max(b,result[-1][1]))
        else:result.append((a,b))
    return result


def domains(data):
    result=[]
    for row,signs in zip(data['positive_domains'],data['allowed_signs']):
        lo,hi=map(lambda v:F(*v),row)
        assert 0<=lo<hi<=1 and set(signs)<=set((-1,1)) and signs
        intervals=[]
        if -1 in signs:intervals.append((-hi,-lo))
        if 1 in signs:intervals.append((lo,hi))
        result.append(merge(intervals))
    return result


def subset(interval,union):
    a,b=interval
    return any(lo<=a<=b<=hi for lo,hi in union)


def reflected(b):
    return [(-b[(3-i)%7][1],-b[(3-i)%7][0]) for i in range(7)]


def encode(b):
    return [[[a.numerator,a.denominator],[c.numerator,c.denominator]] for a,c in b]


out=[]
used=[]
QC=F(9789,2500)
QS=F(97888353437936885663,25000000000000000000)


def cut(stem,premise,coordinate,interval,ceiling=QS,max_core=False):
    path=BASE/(stem+'.json');data=json.loads(path.read_text())
    target=list(premise);target[coordinate]=tuple(F(x) for x in interval)
    if max_core:
        assert coordinate==0 and target[0][1]<0
        target[3]=(target[3][0],min(target[3][1],-target[0][0]))
    assert F(*data['Q'])==ceiling and F(*data['core_radius'])==F(1,12)
    assert list(map(bool,data['is_core']))==[True,False,False,True,False,False,False]
    assert not data['symmetric_gamma'] and not data['unordered_pairs']
    assert not data.get('checked_axes_by_edge') and not data.get('checked_axes')
    assert data['required_pairs']==[[i,(i+1)%7] for i in range(7)]
    assert F(*data['beta'])==0 and all(F(*v)==0 for v in data.get('beta_by_edge',[]))
    declared=domains(data)
    for i,(wanted,have) in enumerate(zip(target,declared)):
        assert subset(wanted,have),(stem,i,wanted,have)
    matching=[]
    for rec,candidate in frozen:
        if all(data.get(k)==candidate.get(k) for k in proof_keys):
            mpath=Path(rec['manifest'])
            assert hashlib.sha256(mpath.read_bytes()).hexdigest()==rec['manifest_sha256']
            manifest=json.loads(mpath.read_text())
            assert manifest['status']=='ALL DECLARED BRANCHES PASSED'
            assert hashlib.sha256(Path(rec['data']).read_bytes()).hexdigest()==manifest['data_json_sha256']
            assert not candidate.get('checked_axes_by_edge') and not candidate.get('checked_axes')
            independent=False
            audit_path=Path('audit_capture')/(rec['name']+'_audit.json')
            if audit_path.exists():
                independent_audit=json.loads(audit_path.read_text())
                independent=(independent_audit['manifest_sha256']==rec['manifest_sha256'] and
                             independent_audit['status']=='INDEPENDENT BINDING AND COVERAGE AUDIT PASS')
            matching.append({'name':rec['name'],'manifest':str(mpath),
                             'sha256':rec['manifest_sha256'],
                             'independent_audit_matches':independent})
    used.append({'input':str(path),'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                 'coordinate':coordinate,'closed_excluded_interval':encode([target[coordinate]])[0],
                 'covered_box':encode(target),'max_core_used':max_core,
                 'exact_status':'MATCHED AUDITED MANIFEST' if matching else 'PENDING EXACT MANIFEST',
                 'matching_manifests':matching})
    return target[coordinate]


def cover(base,coordinate,retained,cuts):
    # The retained interval and excluded closed intervals cover the old role
    # domain with no open gap. Endpoint overlap is intentional.
    a,b=base[coordinate]
    combined=merge([tuple(F(x) for x in retained)]+cuts)
    assert subset((a,b),combined),(coordinate,base,retained,cuts)


def stage(name,before,after,indices):
    out.append({'name':name,'premise_box':encode(before),'conclusion_box':encode(after),
                'cuts':indices})


full=box(*[('-1','1')]*7)
core=list(full);core[0]=(F(-3,8),F(-1,8));core[3]=(F(1,8),F(3,8))
start=len(used)
cs=[]
for k,interval in [(0,('-1','-1/2')),(1,('-1/2','-3/8')),
                   (4,('-1/8','0')),(5,('0','1/4')),(6,('1/4','1/2')),(7,('1/2','1'))]:
    stem=f'long_core_anchor_{k}_candidate'+('_v2' if k==4 else '')
    cs.append(cut(stem,full,0,interval,QC))
cover(full,0,core[0],cs)
# The word is invariant under reflection; applying the same role0 theorem to
# the reflected ring gives the role3 interval, independent of a prior core box.
assert reflected(core)==core
stage('Two core anchors; coarse-to-sharp transport and reflection',full,core,list(range(start,len(used))))

outer=list(core);outer[4]=(F(-1),F(-3,4));outer[6]=(F(3,4),F(1))
start=len(used)
cs=[]
for stem,interval in [('long_sharp_outer_role_0_candidate',('-3/4','-1/2')),
                      ('long_sharp_outer_role_1_candidate',('-1/2','0')),
                      ('long_sharp_positive_outer_split_0_candidate',('0','1/2')),
                      ('long_sharp_positive_outer_split_1_candidate_v2',('1/2','1'))]:
    cs.append(cut(stem,core,4,interval))
cover(core,4,outer[4],cs)
assert reflected(core)==core and reflected(outer)==outer
stage('Outer frame sides; reflected role6 bound',core,outer,list(range(start,len(used))))

symmetric=list(outer)
symmetric[1]=(F(1,4),F(3,4));symmetric[2]=(F(-3,4),F(-1,4));symmetric[5]=(F(-1,4),F(1,4))
start=len(used);cs=[]
for label,interval in [('o1_negative',('-1','0')),('o1_low',('0','1/4')),('o1_high',('3/4','1'))]:
    cs.append(cut('long_sharp_refine_'+label+'_candidate',outer,1,interval))
cover(outer,1,symmetric[1],cs)
cs=[cut('long_sharp_refine_o5_high_candidate',outer,5,('1/4','1'))]
cs.append((-cs[0][1],-cs[0][0]))
cover(outer,5,symmetric[5],cs)
assert reflected(symmetric)==symmetric
stage('Remaining outer tangents; reflection',outer,symmetric,list(range(start,len(used))))

selected=list(symmetric);selected[0]=(F(-5,16),F(-15,64));selected[3]=(F(1,8),F(5,16))
start=len(used);cs=[]
for stem,interval in [('long_sharp_coarse_core_left_candidate_v2',('-3/8','-5/16')),
                      ('long_sharp_coarse_core_right_middle_candidate_v2',('-15/64','-3/16')),
                      ('long_sharp_coarse_core_right_high_candidate',('-3/16','-1/8'))]:
    cs.append(cut(stem,symmetric,0,interval,max_core=True))
cover(symmetric,0,selected[0],cs)
assert selected[3][1]==-selected[0][0]
stage('Choose reflected representative with t3<=-t0; coarse refinement',symmetric,selected,list(range(start,len(used))))

anchored=list(selected);anchored[0]=(F(-9,32),F(-17,64));anchored[3]=(F(1,8),F(9,32))
start=len(used);cs=[]
for stem,interval in [('long_sharp_left_complete_round0_candidate',('-5/16','-9/32')),
                      ('long_sharp_right_complete_k96_candidate_v2',('-17/64','-15/64'))]:
    cs.append(cut(stem,selected,0,interval,max_core=True))
cover(selected,0,anchored[0],cs)
stage('Fine core anchor',selected,anchored,list(range(start,len(used))))

first=list(anchored)
first[1]=(F(31,64),F(33,64));first[2]=(F(-23,64),F(-21,64))
first[3]=(F(13,64),F(9,32));first[5]=(F(1,64),F(3,64));first[6]=(F(55,64),F(1))
start=len(used);byrole={i:[] for i in [1,2,3,5,6]}
for stem,i,interval in [
    ('long_terminal_o1_low_complete_round0_candidate',1,('1/4','31/64')),
    ('long_sharp_terminal_domain_o1_high_candidate',1,('33/64','3/4')),
    ('long_sharp_terminal_domain_o2_low_candidate_v2',2,('-3/4','-23/64')),
    ('long_sharp_terminal_domain_o2_high_candidate',2,('-21/64','-1/4')),
    ('long_terminal_c3_low_complete_round0_candidate',3,('1/8','13/64')),
    ('long_sharp_terminal_domain_o5_negative_candidate_v2',5,('-1/4','0')),
    ('long_sharp_terminal_domain_o5_low_candidate',5,('0','1/64')),
    ('long_sharp_terminal_domain_o5_high_candidate',5,('3/64','1/4')),
    ('long_sharp_terminal_domain_o6_low_candidate',6,('3/4','55/64'))]:
    byrole[i].append(cut(stem,anchored,i,interval))
for i,cs in byrole.items():cover(anchored,i,first[i],cs)
stage('First nine terminal cuts',anchored,first,list(range(start,len(used))))

terminal=list(first);terminal[3]=(F(13,64),F(15,64));terminal[4]=(F(-61,64),F(-59,64));terminal[6]=(F(55,64),F(57,64))
start=len(used);byrole={i:[] for i in [3,4,6]}
for stem,i,interval in [
    ('long_terminal_second_c3_high_complete_round0_candidate',3,('15/64','9/32')),
    ('long_terminal_second_o4_low_complete_round0_candidate',4,('-1','-61/64')),
    ('long_terminal_second_o4_high_complete_round0_candidate',4,('-59/64','-3/4')),
    ('long_sharp_terminal_second_o6_high_candidate',6,('57/64','1'))]:
    byrole[i].append(cut(stem,first,i,interval))
for i,cs in byrole.items():cover(first,i,terminal[i],cs)
stage('Four final terminal cuts',first,terminal,list(range(start,len(used))))

budget=json.loads((BASE/'long_local_aligned_budget_v1.json').read_text())
assert domains(budget)==[[v] for v in terminal]
pending=[x['input'] for x in used if not x['matching_manifests']]
not_independent=[x['input'] for x in used
                 if not any(m['independent_audit_matches'] for m in x['matching_manifests'])]
summary={'status':'EXACT DOMAIN-COVER AUDIT PASS; unverified pair inputs remain pending' if pending
                  else 'EXACT DOMAIN-COVER AND ALL32 PAIR-MANIFEST MATCHES PASS',
         'geometric_premises':['radial boundary reduction','outer-radius monotonicity',
                               'physical reflection t_i -> -t_(3-i mod7)',
                               'choice |t0|>=|t3| in the symmetric box'],
         'registry':str(REGISTRY),'registry_sha256':hashlib.sha256(REGISTRY.read_bytes()).hexdigest(),
         'ordinary_cut_count':len(used),'matched_exact_cut_count':len(used)-len(pending),
         'independently_audited_cut_count':len(used)-len(not_independent),
         'all_pair_manifests_matched':not pending,'pending_inputs':pending,
         'pending_independent_audits':not_independent,
         'stages':out,'cuts':used,'terminal_budget_domain_matches':True}
dest=BASE/'long_two_core_domain_cover_audit.json'
with dest.open('w') as f:
    f.write(json.dumps(summary,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print('PASS: all32 closed exclusions cover the declared complements, with no domain gap')
print('PASS: reflection and maximum-core box interfaces match the exact input domains')
print('PASS: final box is exactly the terminal budget domain')
print('Audited pair inputs matched:',len(used)-len(pending),'of',len(used))
print('Independent binding/coverage audits:',len(used)-len(not_independent),'of',len(used))
print('Pending exact inputs:',len(pending))
