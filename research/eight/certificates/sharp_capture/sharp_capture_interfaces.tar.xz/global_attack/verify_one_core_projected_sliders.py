#!/usr/bin/env python3
"""Exact projected-slider consequences of the one-core terminal hypotheses.

Pair budgets and owner/lift capture are separate theorems. This script binds
the now-certified stationary h2 range and verifies every remaining root and
rational substitution.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import os

Q=F(97888353437936885663,25000000000000000000)
QLOW=Q-F(3,10**16)
H2=(F(-29,20),F(-7,5))
TY=(F(29,50),F(7,5))
ETA=(F(-1,2),F(37,100))
PI_UPPER=F(6283185307179586476925286766559006,10**33)
H2_PROOF=Path('global_attack/broad_stationary_h2_audit.json')
h2_proof=json.loads(H2_PROOF.read_text())
assert h2_proof['status']=='EXACT BROAD STATIONARY GRAPH AND h2 AUDIT PASS'
assert tuple(F(*x) for x in h2_proof['h2_rational_bound'])==H2


def enc(v):return [v.numerator,v.denominator]


def interval(v):return [enc(x) for x in v]


def polynomial(a,x,q):
    return (1+x*x)*a*a+(1+x)*a+F(1,2)-q


def root_bounds(tangent,claimed):
    lo,hi=sorted(abs(v) for v in tangent)
    a,b=claimed
    # The polynomial increases in a>0 and x>=0. Its root increases in q.
    lower_sign=polynomial(a,hi,QLOW)
    upper_sign=polynomial(b,lo,Q)
    assert lower_sign<0<upper_sign
    return {'tangent_abs_bounds':interval((lo,hi)),
            'longitudinal_root_bounds':interval(claimed),
            'lower_test_polynomial':enc(lower_sign),
            'upper_test_polynomial':enc(upper_sign)}


records=[]
for phase in ['t','g']:
    bp=Path(f'global_attack/one_core_{phase}_aligned_budget_v1.json')
    cp=Path(f'global_attack/one_core_{phase}_capture_target.json')
    b=json.loads(bp.read_text());c=json.loads(cp.read_text())
    ds=[tuple(F(*x) for x in row) for row in c['rational_intervals']]
    eps=F(*b['pair_excess_upper'])
    betas=[F(*x) for x in b['beta_by_edge']]
    assert betas.count(F(1,50))==5 and betas.count(F(0))==2
    gamma=sum(F(b['gamma_numerators'][i][(i+1)%7],b['gamma_denominator'])
              for i in range(7))
    assert PI_UPPER-gamma<eps
    # h(d)>=d/4 first gives S<=4U<1/1000. Taylor then gives h(d)>49d/100.
    U=50*eps;S0=4*U
    assert S0<F(1,1000)
    assert (1-S0/2-S0*S0/6)/2>F(49,100)
    S=100*U/49
    assert S<=F(9,98000)<F(1,10000)
    roots=[]
    if phase=='t':
        t_role,g_role=0,3
        assert max(abs(x) for x in ds[t_role])<F(6,7)
        aT=(F(7,12),F(7,12))
        aG=(F(27,20),F(7,5))
        roots.append({'named_square':'G',**root_bounds(ds[g_role],aG)})
    else:
        t_role,g_role=3,0
        assert max(abs(x) for x in ds[g_role])<F(6,7)
        aT=(F(27,20),F(69,50))
        aG=(F(7,12),F(7,12))
        roots.append({'named_square':'T',**root_bounds(ds[t_role],aT)})
    xmax=max(abs(x) for x in ds[t_role])
    height=(aT[0]*(1-S*S/2-xmax*S),aT[1]*(1+xmax*S))
    eta=(-aG[1]-H2[1]-F(1,2),-aG[0]-H2[0]-F(1,2))
    assert TY[0]<height[0]<=height[1]<TY[1]
    assert ETA[0]<=eta[0]<=eta[1]<ETA[1]
    records.append({'phase':phase,'budget':str(bp),
                    'budget_sha256':hashlib.sha256(bp.read_bytes()).hexdigest(),
                    'capture_domain':str(cp),
                    'capture_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),
                    'S_upper':enc(S),'outer_root_checks':roots,
                    'T_projected_height_bounds':interval(height),
                    'eta_bounds':interval(eta),
                    'approximate_height_bounds':[float(x) for x in height],
                    'approximate_eta_bounds':[float(x) for x in eta]})

output={'status':'EXACT RATIONAL SLIDER AUDIT PASS',
        'scope':'Under the proved captured owners/quarter lifts and pair budgets; h2 is on the certified reference graph at q*',
        'h2_proof':str(H2_PROOF),
        'h2_proof_sha256':hashlib.sha256(H2_PROOF.read_bytes()).hexdigest(),
        'circle_ceiling_interval':interval((QLOW,Q)),
        'required_h2_bound':interval(H2),
        'comparison_T_interval':interval(TY),'comparison_eta_interval':interval(ETA),
        'records':records}
path=Path('global_attack/one_core_projected_slider_audit.json')
with path.open('w') as f:
    f.write(json.dumps(output,indent=2)+'\n');f.flush();os.fsync(f.fileno())
print('PASS: both exact outer-root bounds hold throughout the pullback q interval')
print('PASS: both projected T heights lie in[29/50,7/5]')
print('PASS: both eta intervals lie in[-1/2,37/100], using the certified broad h2 range')
