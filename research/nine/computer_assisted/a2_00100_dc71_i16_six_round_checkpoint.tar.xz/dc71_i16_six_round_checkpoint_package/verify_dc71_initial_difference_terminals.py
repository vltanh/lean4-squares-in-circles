#!/usr/bin/env python3
"""Exact interval exclusions in two closed quarters of the original Dc71 cell."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import argparse
import hashlib
import json
import sys

ID='positive-c71dc2feef1abb0b'
PREFIX_SHA='3d5c6def24cd920103c2a26b81d4f898e135cda0b125a2eea87a8880fee840fa'
PATH=[['angle',3,1],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[2]]]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--context',type=Path,required=True)
    ap.add_argument('--report',type=Path,required=True)
    a=ap.parse_args();root=a.context.resolve()
    sys.path.insert(0,str(root))
    from verify_cd_triple_energy_recursive_bounds import Checker
    frozen=(root/'SHA256_MANIFEST.json').read_bytes()
    inputs=json.loads(frozen)['files']
    for name,h in inputs.items():assert sha(root/name)==h,name
    checker=Checker(root,root/'ancestry',root)
    prefix=root/'ancestry/cd_family/diagonal_results'/(ID+'.json')
    assert sha(prefix)==PREFIX_SHA
    literal=json.loads(prefix.read_text())
    assert literal['id']==ID and literal['path']==PATH and literal['rounds']==[]
    prior,parent,diagonal=checker.D.replay(prefix)
    assert prior['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert parent['id']==ID and parent['path']==PATH
    K=checker.K
    eff,error=K.V.effective_boxes(parent['angles'],parent['choices'],K.LEGACY)
    assert error is None
    results=[]
    for tile in ((0,1),(0,2)):
        pos=list(parent['positions'])
        for axis,index in enumerate(tile):
            lo,hi=parent['positions'][16+axis]
            pos[16+axis]=(lo+(hi-lo)*F(index,4),lo+(hi-lo)*F(index+1,4))
        propagated,hs,gs,error=K.V.center_bounds(eff,tuple(pos),parent['choices'],K.LEGACY)
        assert error is None
        witnesses=[]
        for pair in combinations(range(9),2):
            geometric=K.V.difference_bounds(pair,propagated,gs,K.LEGACY)
            inherited=parent['differences'][pair]
            for axis,((a0,b0),(a1,b1)) in enumerate(zip(geometric,inherited)):
                lo,hi=max(a0,a1),min(b0,b1)
                if lo>hi:
                    witnesses.append(dict(pair=list(pair),axis=axis,
                        physical_interval=list(map(str,(a0,b0))),
                        inherited_interval=list(map(str,(a1,b1))),
                        intersection=list(map(str,(lo,hi))),strict_gap=str(lo-hi)))
        assert witnesses,('No independent contradiction',tile)
        results.append(dict(tile=list(tile),closed_cover_parts=[4,4],
            rectangle=K.view(pos[16:18]),status='PASS_COMPLETE_PHYSICAL_TILE',
            terminal_kind='disjoint_proved_original_difference_intervals',
            witnesses=witnesses,closed_faces_retained=True,new_original_cells=0,new_masks=0))
    assert not any(n in sys.modules for n in ('numpy','scipy','highspy','v3_whole_parent_pass','diagonal_rows','quadratic_moment_pilot'))
    assert (root/'SHA256_MANIFEST.json').read_bytes()==frozen
    for name,h in inputs.items():assert sha(root/name)==h,name
    report=dict(schema='independent_Dc71_initial_difference_interval_terminals_v1',
        status='PASS_ALL_LISTED_PHYSICAL_TILES',id=ID,original_parent_path=PATH,
        original_prefix_sha256=PREFIX_SHA,original_prefix_replay=prior,
        source_manifest_sha256=hashlib.sha256(frozen).hexdigest(),checker_sha256=sha(__file__),
        strict_portable_root_used=True,all_frozen_inputs_unchanged=True,
        complete_fixed_tiles=len(results),tile_reports=results,
        whole_original_cover_checked=False,new_original_cells=0,new_masks=0)
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],complete_fixed_tiles=len(results),
        witnesses=[len(x['witnesses']) for x in results],new_original_cells=0,new_masks=0)))

if __name__=='__main__':main()
