#!/usr/bin/env python3
"""Replay the complete declared I grid; seven members remain explicitly open."""
from pathlib import Path
from itertools import product
import hashlib,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert __debug__
 started=time.monotonic();raw=(HERE/'SHA256_MANIFEST.json').read_bytes();manifest=json.loads(raw)
 def unchanged():
  assert (HERE/'SHA256_MANIFEST.json').read_bytes()==raw
  for name,h in manifest['files'].items():
   path=(HERE/name).resolve();assert path.is_relative_to(HERE) and sha(path)==h,name
 unchanged()
 for logfile,args in (
  ('CHECKPOINT_ENERGY_REPLAY.log',[sys.executable,'-B','-S',str(HERE/'energy_proof/verify_all.py')]),
  ('CHECKPOINT_DIFFERENCE_REPLAY.log',[sys.executable,'-B','-S',str(HERE/'verify_dc71_initial_difference_terminals.py'),'--context',str(HERE),'--report',str(HERE/'CHECKPOINT_DIFFERENCE_REPLAY.json')])):
  with (HERE/logfile).open('w')as output:subprocess.run(args,cwd=HERE,stdout=output,stderr=subprocess.STDOUT,check=True)
 energy=json.loads((HERE/'energy_proof/COMPLETE_REPLAY.json').read_text())
 assert energy['status']=='PASS_SHARED_THREE_SQUARE_ENERGY_ROWS' and energy['energy_lower_bound']=='7/2'
 assert energy['exact_geometric_evaluators']==2 and energy['row_identities_checked']==1877
 direct=json.loads((HERE/'CHECKPOINT_DIFFERENCE_REPLAY.json').read_text())
 assert direct['status']=='PASS_ALL_LISTED_PHYSICAL_TILES' and direct['complete_fixed_tiles']==2
 from verify_cd_triple_energy_recursive_bounds import Checker
 checker=Checker(HERE,HERE/'ancestry',HERE)
 records=json.loads((HERE/'DC71_SIX_ROUND_RECORDS.json').read_text())
 results=[]
 for entry in records['records']:
  path=(HERE/entry['certificate']).resolve();assert path.is_relative_to(HERE)
  assert sha(path)==entry['sha256']
  r=checker.replay(path,allow_open=True)
  assert r['tile']==entry['tile'];results.append(r)
 assert len(results)==14 and sum(r['bound_deductions']for r in results)==6467
 direct_tiles={tuple(r['tile'])for r in direct['tile_reports']}
 regular_tiles={tuple(r['tile'])for r in results}
 assert len(regular_tiles)==14 and direct_tiles=={(0,1),(0,2)}
 assert not direct_tiles&regular_tiles and direct_tiles|regular_tiles==set(product(range(4),range(4)))
 closed=direct_tiles|{tuple(r['tile'])for r in results if r['status']=='PASS_COMPLETE_PHYSICAL_TILE'}
 opened={tuple(r['tile'])for r in results if r['status']=='PASS_CERTIFIED_TILE_STATE_OPEN'}
 assert opened=={(1,0),(1,1),(1,2),(1,3),(2,1),(2,2),(2,3)} and len(closed)==9
 prefix='3d5c6def24cd920103c2a26b81d4f898e135cda0b125a2eea87a8880fee840fa'
 path=[['angle',3,1],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[2]]]
 for r in results:
  assert r['id']=='positive-c71dc2feef1abb0b' and r['original_parent_path']==path
  assert r['closed_cover_parts']==[4,4] and r['h_rectangle']is None
  assert r['original_prefix_replay']['certificate_sha256']==prefix
 assert direct['id']=='positive-c71dc2feef1abb0b' and direct['original_parent_path']==path
 assert direct['original_prefix_sha256']==prefix
 modules={}
 for name,module in sys.modules.items():
  origin=getattr(module,'__file__',None)
  if origin and Path(origin).resolve().is_relative_to('/workspace'):
   assert Path(origin).resolve().is_relative_to(HERE)
   modules[name]=str(Path(origin).resolve().relative_to(HERE))
 assert not any(n in sys.modules for n in ('numpy','scipy','highspy','v3_whole_parent_pass','three_square_energy_rows','quadratic_moment_pilot'))
 unchanged()
 report=dict(schema='Dc71_complete_declared_I16_six_round_checkpoint_replay_v1',
  status='PASS_COMPLETE_I16_DECLARATION_WITH_SEVEN_OPEN_RECTANGLES',id='positive-c71dc2feef1abb0b',
  original_parent_path=path,original_prefix_sha256=prefix,original_I_grid=[4,4],
  complete_closed_domain_union_checked=True,closed_faces_retained=True,
  declared_I_rectangles=16,complete_fixed_I_rectangles=9,open_I_rectangles=7,
  closed_I_tiles=[list(t)for t in sorted(closed)],open_I_tiles=[list(t)for t in sorted(opened)],
  bound_rounds=sum(r['bound_rounds']for r in results),bound_deductions=6467,
  printed_rows_checked=sum(r['printed_rows_checked']for r in results),
  terminal_rows=sum(r['terminal_rows']for r in results),tile_reports=results,
  direct_interval_report=direct,physical_three_square_energy_theorem_replayed=True,
  exact_energy_row_identities=1877,energy_replay_sha256=sha(HERE/'energy_proof/COMPLETE_REPLAY.json'),
  source_manifest_sha256=hashlib.sha256(raw).hexdigest(),frozen_inputs=len(manifest['files']),
  local_module_import_audit=modules,all_frozen_inputs_unchanged=True,
  whole_original_closed=False,whole_original_cover_checked=False,new_original_cells=0,new_masks=0,
  lean_lake_ci_run=False,seconds=time.monotonic()-started)
 (HERE/'CHECKPOINT_PORTABLE_REPLAY.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k not in ('tile_reports','direct_interval_report','local_module_import_audit')},indent=2))
 return report

if __name__=='__main__':main()
