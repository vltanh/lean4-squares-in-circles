#!/usr/bin/env python3
"""Independent full-prefix replay with independently reconstructed central rows.

No producer or central row generator is imported. The accepted v4 geometry
and existing independent original-frame row checker are reused. New global
central rows are reconstructed by the root's separate independent module.
"""
import sys,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE
sys.path.insert(0,str(OLD))
import verify_joint_original as J
sys.path.insert(0,str(HERE))
import independent_central_rows as C
J.HERE=HERE
J.REG=HERE/'original_register.json'
BASE_REBUILD=J.rebuild_joint
BASE_ROWS=J.rows_for_record

def rows_for_record(saved,oldrows,scalar,diffs,angles):
    positions=J.box(saved['propagated_positions'])
    def rebuild(name,sc,ds,ag,point_rule):
        if name.startswith('central_nine_'):
            return C.rebuild(name,positions,sc)
        return BASE_REBUILD(name,sc,ds,ag,point_rule)
    J.rebuild_joint=rebuild
    try:return BASE_ROWS(saved,oldrows,scalar,diffs,angles)
    finally:J.rebuild_joint=BASE_REBUILD

J.rows_for_record=rows_for_record

def replay(path,return_state=False):
    d=json.loads(Path(path).read_text())
    result=J.replay(path,allow_open=d['status']=='OPEN',return_state=return_state)
    report=result[0]if return_state else result
    report['independent_central_reconstructor_sha256']=J.digest(C.__file__)
    report['central_adapter_sha256']=J.digest(__file__)
    (HERE/'new_reviews'/(d['id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('certificate');a=p.parse_args()
    replay(a.certificate)
