#!/usr/bin/env python3
"""Independent full-prefix, complete-cover, rational-arithmetic replay.

Imports no central row producer, no cover producer, no support optimizer,
and no numerical solver. Reconstructs the complete near-original cover
from physical own-coordinate and center intervals. Conditional support
rows may appear only under a listed near-original pair, and EVERY pair
must either prove the objective bound or have an exact contradiction.
"""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction as Q
from itertools import product,combinations
HERE=Path(__file__).resolve().parent
import verify_central_bounds as P
J=P.J;K=J.K;U=P.C
H=Q(23,100)


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def independently_classify(pos,scalar):
    allbounds=tuple(pos)+tuple(scalar);facts=[]
    far_norm=Q(1,2)+H*H+H*Q(99,70);assert Q(99,70)**2>2
    for i in range(9):
        minimum=sum(Q(0)if a<=0<=b else min(a*a,b*b)for a,b in pos[2*i:2*i+2])
        maximum=sum(max(a*a,b*b)for a,b in pos[2*i:2*i+2])
        ranges=[]
        for axis in(0,1):
            terms=((18+i,2*i,1),(27+i,2*i+1,1))if axis==0 else((18+i,2*i+1,1),(27+i,2*i,-1))
            l=u=Q(0)
            for a,b,sign in terms:
                values=[sign*x*y for x in allbounds[a]for y in allbounds[b]]
                l+=min(values);u+=max(values)
            ranges.append((l,u))
        lower=upper=Q(0)
        for a,b in ranges:
            least=Q(0)if a<=0<=b else min(abs(a),abs(b));most=max(abs(a),abs(b))
            lower+=max(Q(0),least-Q(1,2))**2;upper+=max(Q(0),most-Q(1,2))**2
        near=[];far=[]
        if maximum<(H+Q(1,2))**2:near.append('incircle_center_upper')
        if upper<H*H:near.append('own_projection_distance_upper')
        if minimum>=far_norm:far.append('circumcircle_center_lower')
        if lower>=H*H:far.append('own_projection_distance_lower')
        facts.append({'original':i,'near_rules':near,'far_rules':far,
            'center_min_squared':str(minimum),'center_max_squared':str(maximum),
            'own_projection_intervals':[[str(a),str(b)]for a,b in ranges],
            'own_distance_lower_squared':str(lower),'own_distance_upper_squared':str(upper)})
    near=[f['original']for f in facts if f['near_rules']]
    possible=[f['original']for f in facts if not f['far_rules']]
    contradictory=any(f['near_rules']and f['far_rules']for f in facts)
    if contradictory or len(possible)<2:pairs=[]
    elif len(near)>=2:pairs=[tuple(near[:2])]
    elif near:pairs=[tuple(sorted((near[0],j)))for j in possible if j!=near[0]]
    else:pairs=list(combinations(possible,2))
    return {'classifications':facts,'known_near':near,'eligible_near':possible,
        'contradictory_classification':contradictory,'complete_pairs':[list(p)for p in pairs]}


def conditional_support(name,scalar,pair):
    p=name.split('_');assert p[:3]==['central','nine','near']and len(p)==7
    i=int(p[4]);sign=int(p[6]);assert 0<=i<9 and i in pair and sign in(-1,1)
    if p[3]=='axis':
        axis=int(p[5]);assert axis in(0,1)
        return U.clean({2*i+axis:Q(sign),18+i:Q(-1,2),36+i:Q(-1,2)},H,name)
    assert p[3]=='support'
    raw=[(Q(1),Q(0)),(Q(0),Q(1)),(Q(3,5),Q(4,5)),(Q(4,5),Q(3,5)),
        (Q(5,13),Q(12,13)),(Q(12,13),Q(5,13)),(Q(8,17),Q(15,17)),
        (Q(15,17),Q(8,17)),(Q(7,25),Q(24,25)),(Q(24,25),Q(7,25))]
    dirs=[]
    for x,y in raw:
        for s in(-1,1):
            if(x,s*y)not in dirs:dirs.append((x,s*y))
    k=int(p[5]);assert 0<=k<len(dirs)
    x,y=dirs[k];assert x*x+y*y==1
    def abs_chord(a,b):
        vals=[a*u+b*v for u in scalar[i]for v in scalar[9+i]]
        lo,hi=min(vals),max(vals)
        if lo>=0:return a,b,Q(0)
        if hi<=0:return -a,-b,Q(0)
        slope=(hi+lo)/(hi-lo);intercept=-2*lo*hi/(hi-lo)
        return a*slope,b*slope,intercept
    first,second=abs_chord(x,y),abs_chord(y,-x)
    ca,cb,shift=((a+b)/2 for a,b in zip(first,second))
    return U.clean({2*i:sign*x,2*i+1:sign*y,18+i:-ca,27+i:-cb},H+shift,name)


def physical_rows(printed,base,pos,scalar,diffs,angles,pair=None):
    indices=[d['index']for d in printed];assert len(indices)==len(set(indices))
    rows=list(base)
    if indices:rows.extend([((),Q(0),'UNUSED_UNVERIFIED')]*max(0,max(indices)+1-len(rows)))
    for entry in printed:
        index=entry['index'];assert type(index)is int and index>=0
        name=entry['name']
        if index>=len(base):
            if name.startswith('central_nine_near_')and pair is not None:
                actual=conditional_support(name,scalar,pair)
            elif name.startswith('central_nine_'):
                actual=U.rebuild(name,pos,scalar)
            else:
                actual=P.BASE_REBUILD(name,scalar,diffs,angles,J.point_row)
            rows[index]=actual
        co,rhs,actual_name=rows[index]
        assert name==actual_name and Q(entry['rhs'])==rhs
        assert [(k,Q(v))for k,v in entry['coefficients']if Q(v)]==[(k,v)for k,v in co if v]
    return rows,set(indices)


def exact_contradiction(saved,rows,bounds):
    co,rhs=K.sum_rows(rows,bounds,saved['weights'])
    reserve=-rhs-sum(m*abs(v)for m,v in zip(bounds,co))
    assert reserve>0 and reserve==Q(saved['reserve'])
    assert co==list(map(Q,saved['weighted_coefficients']))and rhs==Q(saved['weighted_rhs'])
    return reserve


def check_support(rr,base,bounds,pos,scalar,diffs,angles):
    answer=rr['complete_support'];cover=independently_classify(pos,scalar)
    assert rr['central_cover']==cover
    complete={tuple(p)for p in cover['complete_pairs']}
    assert len(answer['complete_pairs'])==len(complete)and {tuple(p)for p in answer['complete_pairs']}==complete
    table=answer['printed_rows_by_pair'];assert len(table)==len(complete)
    assert {tuple(x['pair'])for x in table}==complete
    rows={};printed={};used={p:set()for p in complete}
    for x in table:
        pair=tuple(x['pair']);rows[pair],printed[pair]=physical_rows(x['rows'],base,pos,scalar,diffs,angles,pair)
    excluded=set()
    for ex in answer['excluded_cases']:
        pair=tuple(ex['pair']);assert pair in complete and pair not in excluded;excluded.add(pair)
        exact_contradiction(ex,rows[pair],bounds);used[pair].update(k for k,w in ex['weights'])
    viable=complete-excluded
    assert len(answer['viable_pairs'])==len(viable)and {tuple(p)for p in answer['viable_pairs']}==viable
    assert answer['status']==('COMPLETE_COVER_IMPOSSIBLE'if not viable else'COMPLETE_COVER_BOUNDS')
    nextpos=[list(ab)for ab in pos];nextscalar=[list(ab)for ab in scalar]
    nextdiff={p:[list(ab)for ab in ds]for p,ds in diffs.items()}
    seen_objectives=set()
    for proposal in answer['proposals']:
        assert viable
        key=proposal['key'];sign=proposal['sign'];assert sign in(-1,1)
        if proposal['kind']=='scalar':
            assert type(key)is int and 0<=key<54 and proposal['objective']==[[key,sign]]
            target=nextpos[key]if key<18 else nextscalar[key-18]
            old=(pos+scalar)[key][1]if sign==1 else-(pos+scalar)[key][0]
        else:
            assert proposal['kind']=='difference'and len(key)==3
            i,j,axis=key;assert 0<=i<j<9 and axis in(0,1)
            assert proposal['objective']==[[2*j+axis,sign],[2*i+axis,-sign]]
            target=nextdiff[i,j][axis];ab=diffs[i,j][axis]
            old=ab[1]if sign==1 else-ab[0]
        obj=tuple(tuple(x)for x in proposal['objective']);assert obj not in seen_objectives;seen_objectives.add(obj)
        assert Q(proposal['old'])==old
        alternatives=proposal['alternatives'];assert len(alternatives)==len(viable)
        assert {tuple(x['pair'])for x in alternatives}==viable
        uppers=[]
        for part in alternatives:
            pair=tuple(part['pair']);upper=K.audit_bound(rows[pair],bounds,dict(part,objective=proposal['objective']))
            used[pair].update(k for k,w in part['weights']);uppers.append(upper)
        upper=Q(proposal['upper']);assert upper==max(uppers)and old-upper>=Q(1,2000)
        if sign==1:target[1]=min(target[1],upper)
        else:target[0]=max(target[0],-upper)
    for pair in complete:assert used[pair]==printed[pair]
    return tuple(map(tuple,nextpos)),tuple(map(tuple,nextscalar)),{p:tuple(map(tuple,ds))for p,ds in nextdiff.items()},len(answer['proposals']),sum(len(x)for x in printed.values()),not viable


def replay(filename):
    started=time.monotonic();path=Path(filename);record=json.loads(path.read_text())
    assert record['schema']=='whole_original_complete_central_cover_bounds_v1'
    assert record['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and record['new_refinement_nodes']==0
    assert record['status']in('OPEN','COMPLETE_ORIGINAL_CANDIDATE')
    for p,h in record['sources'].items():assert sha(J.local_source(p))==h,('source_changed',p)
    prior=J.local_source(record['prior']['file']);assert sha(prior)==record['prior']['sha256']
    prefix,state=P.replay(prior,return_state=True)
    assert state['id']==record['id']and state['path']==record['path']
    angles=state['angles'];pos=state['positions'];scalar=state['scalar'];differences=state['differences'];choices=state['choices']
    count=printed_count=0;complete=False;terminal_reserve=None
    def prepare(rr):
        assert J.box(rr['angles_before'])==angles and J.box(rr['positions_before'])==pos and J.box(rr['scalar_before'])==scalar
        assert rr['differences_before']==K.diffview(differences)
        base,bounds,prop,phys,effective,guards=K.rebuild(state['path'],angles,pos,choices,scalar,differences)
        assert J.box(rr['propagated_positions'])==prop and J.box(rr['physical_scalar_intersection'])==phys
        assert rr['effective_differences']==K.diffview(effective)and rr['three_square_guards'][:len(guards)]==guards
        assert rr['absolute_variable_bounds']==list(map(str,bounds))
        assert rr['central_cover']==independently_classify(prop,phys)
        return base,bounds,prop,phys,effective
    for ri,rr in enumerate(record['rounds']):
        assert rr['round']==ri
        base,bounds,prop,phys,effective=prepare(rr)
        pos,scalar,differences,newcount,printed,impossible=check_support(rr,base,bounds,prop,phys,effective,angles)
        assert not impossible
        assert all(a<=b for a,b in pos+scalar)and all(a<=b for ds in differences.values()for a,b in ds)
        angles=K.angles_from_scalar(angles,scalar,rr['physical_frame_inferences'])
        analytic=K.analytic(angles);scalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(scalar,analytic))
        assert all(a<=b for a,b in scalar)
        assert J.box(rr['angles_after'])==angles and J.box(rr['positions_after'])==pos and J.box(rr['scalar_after'])==scalar
        assert rr['differences_after']==K.diffview(differences)
        count+=newcount;printed_count+=printed
        print(record['id'],'PASS COMPLETE-COVER BOUND ROUND',ri,newcount,flush=True)
    if record['status']=='COMPLETE_ORIGINAL_CANDIDATE':
        terminal=record['terminal'];rr=terminal['state'];assert rr['round']==len(record['rounds'])
        base,bounds,prop,phys,effective=prepare(rr)
        kind=terminal['kind']
        if kind=='empty_complete_central_cover':assert not independently_classify(prop,phys)['complete_pairs'];complete=True
        elif kind=='positive_exact_reserve':
            rows,indices=physical_rows(terminal['printed_rows'],base,prop,phys,effective,angles)
            assert indices=={k for k,w in terminal['weights']}
            terminal_reserve=exact_contradiction(terminal,rows,bounds);printed_count+=len(indices);complete=True
        else:
            p,s,d,newcount,printed,impossible=check_support(rr,base,bounds,prop,phys,effective,angles)
            count+=newcount;printed_count+=printed
            if kind=='complete_central_cover_contradiction':assert impossible;complete=True
            elif kind=='proved_empty_interval':
                assert any(a>b for a,b in p+s)or any(a>b for ds in d.values()for a,b in ds);complete=True
            else:raise AssertionError(('unsupported_terminal',kind))
    elif 'final_test'in record:prepare(record['final_test'])
    assert J.box(record['final_angles'])==angles and J.box(record['final_positions'])==pos and J.box(record['final_scalar'])==scalar
    assert record['final_differences']==K.diffview(differences)
    report={'schema':'independent_complete_central_cover_bound_replay_v1','id':record['id'],
        'status':'PASS_COMPLETE_ORIGINAL_PARENT'if complete else'PASS_CERTIFIED_COMPLETE_COVER_PARENT_STATE_OPEN',
        'whole_original_parent_closed':complete,'new_originals_closed':int(complete),
        'whole_mask_closed':False,'new_refinement_nodes':0,'rounds':len(record['rounds']),
        'new_deductions':count,'printed_rows_checked':printed_count,'reserve':str(terminal_reserve),
        'complete_cover_checked_independently':True,'conditional_rows_promoted_without_complete_cover':False,
        'unsupported_rules_accepted':False,'prior_report':prefix,'source_sha256':sha(path),
        'checker_sha256':sha(__file__),'seconds':time.monotonic()-started}
    dest=HERE/'cover_reviews';dest.mkdir(exist_ok=True)
    (dest/(record['id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='prior_report'}),flush=True)
    return report

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('certificate');a=p.parse_args();replay(a.certificate)
