"""Small exact algebra checks of the new row interface, not a packing proof."""
from fractions import Fraction as Q
from itertools import product
import central_nine_rows as N

# All signed McCormick upper planes on three unequal rational rectangles.
for ab,cd in [((Q(-3,5),Q(7,8)),(Q(-9,11),Q(1,3))),
              ((Q(7,10),Q(1)),(Q(-2),Q(3))),
              ((Q(-1),Q(-1,2)),(Q(-3,2),Q(-1,4)))]:
    bounds=(ab,cd)
    for sign in(-1,1):
        for terms,const in N.product_upper_planes(0,1,sign,bounds):
            for a,b in product((ab[0],sum(ab)/2,ab[1]),(cd[0],sum(cd)/2,cd[1])):
                assert sign*a*b<=terms[0]*a+terms[1]*b+const

# Every conditional near-support row contains exact samples of a true
# square plus a point in the open central disk, using one physical frame.
scalar=tuple([(Q(7,10),Q(1))]*9+[(Q(-71,100),Q(71,100))]*9+
             [(Q(0),Q(71,100))]*9+[(Q(1,3),Q(1,2))]*9)
rows=N.near_support_rows(0,scalar)
for alpha,beta in((Q(1),Q(0)),(Q(4,5),Q(3,5)),(Q(4,5),Q(-3,5)),(Q(12,13),Q(5,13))):
    assert alpha*alpha+beta*beta==1
    for s,t,px,py in product((Q(-1,2),Q(0),Q(1,2)),repeat=4):
        px/=4;py/=4
        assert px*px+py*py<N.H*N.H
        point=[Q(0)]*54
        point[0]=px-s*alpha+t*beta
        point[1]=py-s*beta-t*alpha
        point[18]=alpha;point[27]=beta;point[36]=abs(beta)
        for co,rhs,name in rows:
            assert sum(v*point[k]for k,v in co)<=rhs,name
print('PASS exact signed-product planes and conditional near-support rows')
