#!/usr/bin/env python3
"""Standard-library-only replay of the complete central-capacity evidence."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def local(name):
 p=Path(name);assert not p.is_absolute()and '..'not in p.parts
 f=HERE/p;assert f.is_file()and f.resolve().is_relative_to(HERE)
 return f

def main():
 assert __debug__,'Assertions must be enabled for exact verification.'
 manifest=json.loads(local('SHA256_MANIFEST.json').read_text())
 assert manifest['schema']=='immutable_global_nine_central_capacity_evidence_v1'
 for name,h in manifest['files'].items():assert sha(local(name))==h,('changed_file',name)
 index=json.loads(local('index.json').read_text())
 assert index['schema']=='portable_global_nine_central_capacity_evidence_v1'
 assert index['new_originals_closed']==index['new_masks_closed']==0 and index['no_lean_lake_ci']is True
 bindings=json.loads(local('source_bindings.json').read_text())
 for target in bindings.values():local(target)
 reg=json.loads(local('original_register.json').read_text());assert len(reg['cells'])==231
 byid={c['id']:c for c in reg['cells']};assert len(byid)==231
 for ident,file in index['parent_states'].items():
  record=json.loads(local(file).read_text());assert record['id']==ident and record['path']==byid[ident]['path']
  assert byid[ident]['status']=='OPEN'and record['status']=='OPEN'
  assert record['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and record['new_branch_nodes']==0
  source=record['continuation_input'];old=json.loads(local(bindings[source['file']]).read_text())
  assert sha(local(bindings[source['file']]))==source['sha256']
  assert old['rounds']==record['rounds'][:len(old['rounds'])]
 from verify_central_cover_bounds import replay as cover_replay
 from verify_central_bounds import replay as state_replay
 complete=cover_replay(local(index['complete_cover_certificate']))
 assert complete['status']=='PASS_CERTIFIED_COMPLETE_COVER_PARENT_STATE_OPEN'
 assert not complete['whole_original_parent_closed']and complete['new_originals_closed']==0
 expected=index['expected_f14'];prefix=complete['prior_report']
 assert prefix['rounds']==expected['prefix_rounds']and prefix['new_deductions']==expected['prefix_new_deductions']
 assert prefix['printed_rows_checked']==expected['prefix_printed_rows']
 assert complete['rounds']==expected['cover_rounds']and complete['new_deductions']==expected['cover_new_deductions']
 assert complete['printed_rows_checked']==expected['cover_printed_rows']
 cert=json.loads(local(index['complete_cover_certificate']).read_text());round0=cert['rounds'][0]
 assert round0['central_cover']['complete_pairs']==expected['complete_pairs']
 exclusions=round0['complete_support']['excluded_cases'];assert len(exclusions)==1
 assert exclusions[0]['pair']==expected['excluded_pair']and Q(exclusions[0]['reserve'])==Q(expected['excluded_reserve'])>0
 ident='negative-462e78d2e2d8be05';second=state_replay(local(index['parent_states'][ident]))
 assert second['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'and not second['whole_original_parent_closed']
 from verify_central_enhanced_eight_obstruction import report as eight
 assert eight['status']=='PASS_EXACT_EIGHT_ORIGINAL_CENTRAL_EXTRACTION_BARRIER'
 assert eight['original_count']==8 and eight['physical_pairs_checked']==28 and eight['corner_count']==32
 assert not eight['ninth_original_supplied']and not eight['nine_square_counterexample_claimed']
 hand=json.loads(local('accepted_reports/central_chain_near_exclusion_review.json').read_text())
 fgrows=next(x['rows']for x in round0['complete_support']['printed_rows_by_pair']if x['pair']==[5,6])
 assert hand['rows']==fgrows
 co={};rhs=Q(0)
 for row,w in zip(fgrows,map(Q,hand['weights'])):
  rhs+=w*Q(row['rhs'])
  for k,c in row['coefficients']:co[k]=co.get(k,Q(0))+w*Q(c)
 assert not any(co.values())and -rhs==Q(hand['positive_reserve'])==Q(327247,6553600)>0
 summary={'status':'PASS_PORTABLE_ALL_NINE_CENTRAL_EVIDENCE_OPEN','new_originals_closed':0,'new_masks_closed':0,
  'f14_parent_rounds':prefix['rounds'],'f14_complete_cover_cases':5,'f14_excluded_central_pairs':1,
  'f14_remaining_central_pairs':4,'f14_complete_cover_bound_deductions':complete['new_deductions'],
  'f14_exact_exclusion_reserve':expected['excluded_reserve'],'second_parent_rounds':second['rounds'],
  'eight_original_extraction_barrier_checked':True,'ninth_original_supplied':False,'central_chain_exclusion_reserve':str(-rhs),'all_sources_local_and_pinned':True,'solver_required':False,'lean_lake_ci_run':False}
 dest=HERE/'new_reviews';dest.mkdir(exist_ok=True)
 (dest/'portable_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
