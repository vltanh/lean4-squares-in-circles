#!/usr/bin/env python3
"""Independent exact rational audit of the eight-square hand obstruction.

No discovery program, optimizer, sampling grid, Lean, or CI is imported.
Checks every actual corner, every physical pair, all central distances,
the two-direction obstruction, and the scalar reserves covering ALL
witness directions in the hand proof.
"""
from fractions import Fraction as Q
from itertools import combinations,product
import json
from pathlib import Path

C=Q(159999,160001);S=Q(800,160001)
assert C*C+S*S==1 and 0<S<C
D=1/C;X=D/2;HALF=(C+S)/2;DELTA=HALF-Q(1,2)
LOW=Q(-83,120);MID=Q(37,120);TOP=MID+Q(1,2)+HALF
R2=Q(1105,256);small=Q(23,100);exclusion=Q(27,100)
assert X<Q(501,1000)and Q(1,2)<HALF<Q(503,1000)and 0<DELTA<Q(1,400)
centers=[(-1,LOW),(-1,MID),(0,MID),(X,TOP),(0,LOW),(1,LOW),(1,MID),(-X,TOP)]
frames=[((Q(1),Q(0)),(Q(0),Q(1)))for _ in centers]
for i in(3,7):frames[i]=((C,S),(-S,C))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def support(i,n):return sum(abs(dot(n,u))for u in frames[i])/2
maxcorners=[]
for i,(point,frame)in enumerate(zip(centers,frames)):
 values=[]
 for sign1,sign2 in product((-1,1),repeat=2):
  corner=tuple(point[k]+(sign1*frame[0][k]+sign2*frame[1][k])/2 for k in(0,1))
  values.append(dot(corner,corner))
 assert max(values)<R2
 maxcorners.append(max(values))
separations=[]
for i,j in combinations(range(8),2):
 difference=sub(centers[j],centers[i]);axes=list(frames[i])+list(frames[j])
 gaps=[abs(dot(difference,n))-support(i,n)-support(j,n)for n in axes]
 assert max(gaps)>=0,(i,j,gaps)
 separations.append({'pair':[i,j],'largest_axis_clearance':str(max(gaps))})
near=[];ownmax=[];dist2=[]
for i,(point,frame)in enumerate(zip(centers,frames)):
 projections=[dot(point,n)for n in frame];largest=max(abs(x)for x in projections)
 assert largest>exclusion
 distance=sum(max(abs(x)-Q(1,2),Q(0))**2 for x in projections)
 if distance<small*small:near.append(i)
 ownmax.append(largest);dist2.append(distance)
assert near==[2,4]and dist2[2]==0 and dist2[4]==Q(23,120)**2
# Unique horizontal and vertical requirements come from these literal
# touching aligned pairs, as proved for arbitrary (p,q) in the hand note.
assert sub(centers[2],centers[1])==(1,0)
assert sub(centers[1],centers[0])==(0,1)
assert D*C==1 and C+S-D==S*(C-S)/C>0
assert centers[3][1]==centers[7][1]
# Every positive arithmetic reserve in the all-direction span proof.
reserves={
 'top_corner_envelope':R2-Q(17217,4000),
 'bottom_under_four':4-Q(52849,14400),
 'middle_under_four':4-Q(41809,14400),
 'top_x_envelope':Q(201,200)-X-HALF,
 'top_y_envelope':Q(363,200)-TOP-HALF,
 'frame_perturbation':Q(1,250)-Q(4010,1120007),
 'small_direction_span':Q(4591,86750)-Q(1,400),
 'large_direction_coordinate':Q(31,100)**2-Q(239,2500),
 'large_direction_span':Q(52893,200000)-Q(1,4),
 'large_direction_gap':Q(1,4)-Q(3,125),
 'literal_CD_weakness':1+C-X-Q(1,2)-HALF,
 'central_C_exclusion':MID-exclusion,
 'central_E_nearness':small-Q(23,120)}
assert reserves['top_corner_envelope']==Q(389,32000)
assert all(v>0 for v in reserves.values())
# Exact identities behind the h0 split, with no sampled angles.
assert Q(1,2)+Q(1,250)<=Q(347,500)
assert Q(69,100)+Q(1,250)==Q(347,500)
assert Q(500,347)-Q(347,250)==Q(4591,86750)
assert 2-Q(69,50)**2==Q(239,2500)
assert (Q(69,50)-Q(31,100))/2==Q(107,200)
assert Q(499,1000)*Q(107,200)-Q(1,400)==Q(52893,200000)
assert (1-C+S)*Q(5,7)==Q(4010,1120007)
report={'status':'PASS_EXACT_EIGHT_ORIGINAL_CENTRAL_EXTRACTION_BARRIER',
 'original_count':8,'corner_count':32,'physical_pairs_checked':28,
 'all_corners_strictly_below_Q':True,'Q':str(R2),
 'largest_actual_corner_squared':str(max(maxcorners)),
 'corner_norm_squared_by_original':list(map(str,maxcorners)),
 'exactly_near_originals':['C','E'],'near_clearance_squared':list(map(str,dist2)),
 'own_axis_maxima':list(map(str,ownmax)),
 'two_direction_cover_impossible':True,
 'any_cone_four_with_actual_link_impossible':'hand proof split covers all h0 in [1/2,1/sqrt(2)]; exact scalar reserves audited',
 'rational_reserves':{k:str(v)for k,v in reserves.items()},
 'physical_pair_clearances':separations,
 'ninth_original_supplied':False,'nine_square_counterexample_claimed':False,
 'new_originals_closed':0,'new_masks_closed':0,'no_lean_lake_ci':True}
destination=Path(__file__).with_name('new_reviews');destination.mkdir(exist_ok=True)
(destination/'central_enhanced_eight_obstruction_review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in('physical_pair_clearances','corner_norm_squared_by_original','near_clearance_squared','own_axis_maxima')},indent=2))
