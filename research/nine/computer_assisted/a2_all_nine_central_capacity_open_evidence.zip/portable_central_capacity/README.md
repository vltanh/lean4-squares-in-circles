# Portable all-nine central capacity and complete-cover evidence

This package preserves the exact global physical theorem and the completed
B-family bound experiments. It closes **zero originals and zero masks**.

The arc theorem forces every original own-axis maximum above 27/100 and at
least two originals to meet the open 23/100 disk. The same-frame row generator
is preserved under source_files and explained in proofs.

The f14 parent has a fully replayed 12-round original state. F is universally
near by its center-radius box, so the complete central pair cover is FB,FC,
FG,FH,FI. The FG alternative has an exact four-row contradiction. The other
four alternatives remain open. No conditional row is promoted without its
full cover. The support-max exploration tested all 252 standard objectives
and found no bound exceeding the existing tolerance. This negative numerical
observation is not used as a proof premise.

Run `python verify_all.py` with the standard Python library. The checker
needs no solver, network, Lean, Lake, or CI. It replays the full f14 prefix,
reconstructs every central alternative independently, checks the FG reserve,
and also independently replays the second bounded 462 parent state. Every
external-looking source name resolves through source_bindings.json to a
pinned local file. No original-cell path or ledger status is changed.

## All-mask extraction boundary

The new exact eight-original construction satisfies both central
consequences, yet has no actual consecutive link in any center-cone
four-chain in any frame and no cover by two fixed projection directions.
Its 32 corners, 28 physical pairs, central classification, and the rational
reserves covering all directions are audited separately. It is explicitly
an eight-original obstruction: the ninth square is not supplied, and no
nine-square counterexample or mask closure is claimed.

The positive central-near chain law shows that a near actual successor of
P forces x_P+H_P<h. At h=23/100, an original with |x_P|<=27/100 has no
near actual neighbor. It gives a clean four-row f14 G-near contradiction
with reserve 327247/6553600, while the other four central choices remain open.
