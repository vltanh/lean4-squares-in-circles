#!/usr/bin/env python3
"""Fresh exact replay of the complete eight-domain partial checkpoint."""
from pathlib import Path
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=(HERE/'SHA256_MANIFEST.json').read_bytes()
manifest=json.loads(raw)
for name,h in manifest['files'].items():assert sha(HERE/name)==h,name
subprocess.run([sys.executable,'-B','-S',str(HERE/'verify_c887_whole_eight_height_cover.py'),
 str(HERE/'RECOVERED_EIGHT_DOMAINS.json'),'--context',str(HERE),'--ancestry',str(HERE/'ancestry'),
 '--strict-root',str(HERE),'--allow-partial','--report',str(HERE/'CHECKPOINT_PORTABLE_REPLAY.json')],cwd=HERE,check=True)
r=json.loads((HERE/'CHECKPOINT_PORTABLE_REPLAY.json').read_text())
assert r['status']=='PASS_DECLARED_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_WITH_OPEN_DOMAINS'
assert r['conditional_terminals']==1 and r['open_domain_indices']==list(range(7))
assert r['local_bound_rounds']==22 and r['local_bound_deductions']==2158
assert r['new_original_cells']==r['new_masks']==0
assert (HERE/'SHA256_MANIFEST.json').read_bytes()==raw
for name,h in manifest['files'].items():assert sha(HERE/name)==h,name
print(json.dumps(dict(status=r['status'],frozen_inputs=len(manifest['files']),
 complete_closed_domains=8,conditional_terminals=1,open_domains=7,
 new_original_cells=0,new_masks=0,all_frozen_inputs_unchanged=True)))
