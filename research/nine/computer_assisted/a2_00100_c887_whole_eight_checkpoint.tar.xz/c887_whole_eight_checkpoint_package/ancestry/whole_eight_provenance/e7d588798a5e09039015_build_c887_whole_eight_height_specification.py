#!/usr/bin/env python3
"""Exact attachment of the eight height alternatives at original C887 scope."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import importlib.util
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REPO=ROOT/'pr11'
PACKET=REPO/'research/nine/computer_assisted/opposite_tilt_ahid_row'
FOUNDATION=ROOT/'c887_sharp_foundation_package'
ANCESTRY=FOUNDATION/'ancestry'
PREFIX=ROOT/'cd_family/new_cd_prefixes/negative-887236b78100baf3.json'
EXPECTED_PREFIX='9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3'
EXPECTED_V3='d7ad68039cefde5580f63db10002a6dcb436381ee20ac04e9955fb5f127a84f0'
EXPECTED_GUARD='3d1a74e8108f9eb02e431e2e25f9f24aa7bffd55aac8f3a956d2f54a11886c0d'
ORIGINAL_PATH=[['angle',3,0],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[1]]]
OUT=HERE/'C887_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_SPECIFICATION.json'

def sha(p):return sha256(Path(p).read_bytes()).hexdigest()

def row_literal(row):
    co,rhs,name=row
    return {'coefficients':[[i,str(c)] for i,c in sorted(co)],'rhs':str(rhs),'name':name}

def main():
    guard=PACKET/'opposite_tilt_four_row_guard.py'
    assert sha(guard)==EXPECTED_GUARD and sha(PREFIX)==EXPECTED_PREFIX
    legacy=ANCESTRY/'legacy/current_proof/v3_results/negative-887236b78100baf3.json'
    replay=ANCESTRY/'cd_family/diagonal_replay_reports/negative-887236b78100baf3.json'
    assert sha(legacy)==EXPECTED_V3
    dependencies=[Path(__file__).resolve(),HERE/'C887_WHOLE_ORIGINAL_EIGHT_HEIGHT_HAND_REDUCTION.md',
                  PREFIX,legacy,replay,PACKET/'MANIFEST.json',guard,
                  ANCESTRY/'MANIFEST.json',ANCESTRY/'SOURCE_BINDINGS.json',FOUNDATION/'replay_context.py',
                  REPO/'research/nine/OPPOSITE_ENDPOINT_TILTS_FULL_ANGLE_FOUR_ROW_HAND_TERMINAL.md',
                  REPO/'research/nine/A2_00100_C887_I21_SHARP_FOUNDATION_HAND_PROOF.md',
                  REPO/'research/nine/computer_assisted/a2_00100_c887_sharp_foundation_checkpoint_manifest.json']
    sources={str(p.resolve()):sha(p) for p in dependencies}
    for directory,key in ((PACKET,'immutable_inputs'),(ANCESTRY,'frozen_file_sha256')):
        inventory=json.loads((directory/'MANIFEST.json').read_text())[key]
        for name,h in inventory.items():
            p=(directory/name).resolve()
            assert p.is_relative_to(directory.resolve()) and sha(p)==h,(name,h)
            sources[str(p)]=h
    d=json.loads(PREFIX.read_text());old=json.loads(legacy.read_text());report=json.loads(replay.read_text())
    assert d['schema']=='correlated_diagonal_whole_parent_v1' and d['rounds']==[]
    assert d['status']=='OPEN' and d['new_original_cells']==0
    assert d['id']==old['id']=='negative-887236b78100baf3' and d['path']==old['path']==ORIGINAL_PATH
    assert d['prior']['kind']=='v3' and d['prior']['sha256']==EXPECTED_V3
    assert 'tile' not in d and 'tile' not in d['prior'] and 'rectangle' not in d['prior']
    assert report['certificate_sha256']==EXPECTED_PREFIX and report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert report['new_original_cells']==0 and report['rounds']==[]
    prior_report=report['prior_report']
    assert prior_report['certificate_sha256']==EXPECTED_V3 and prior_report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert prior_report['center_cover'] is None and not prior_report['whole_original_parent_closed']
    assert prior_report['bound_induction_branch_nodes']==0 and prior_report['rounds']==5
    assert prior_report['new_deductions']==364 and prior_report['prior_coordinate_deductions']==29
    state=d['final']
    assert state['angles']==old['final_angles'] and state['positions']==old['final_positions']
    assert state['scalar']==old['final_scalar'] and state['differences']==old['final_differences']
    assert state['diagonal']==[]
    spec=importlib.util.spec_from_file_location('accepted_opposite_tilt_guard',guard)
    G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G)
    assert Path(G.__file__).resolve()==guard.resolve()
    pos,angles,scalar,diffs=G.unpack(state)
    assert diffs[0,7][0]==(F(26355,1048576),F(83,30))
    assert diffs[7,8][0]==(F(0),F(2785067,1048576))
    assert diffs[3,8][0]==(F(-3064161,1048576),F(-434432029724121,5000000000000000))
    orders=[G.difference(pos,diffs,i,j,0) for i,j in ((0,7),(7,8),(8,3))]
    assert angles[0][0]>=0 and angles[3][1]<=0 and all(v[0]>=0 for v in orders)
    rows=[]
    for index,(e1,e2,e3) in enumerate(product((-1,1),repeat=3)):
        co={1:F(e1),15:F(-e1+e2),17:F(-e2+e3),7:F(-e3)}
        row=(tuple(sorted((i,c) for i,c in co.items() if c)),F(-23,100),'opposite_tilt_AHID_variation_'+str(index))
        rows.append({'branch':index,'signs':[e1,e2,e3],'conditional_row':row_literal(row),
                     'status':'PENDING_COMPLETE_EXACT_CHILD_PROOF'})
    assert [r['conditional_row'] for r in rows]==[row_literal(r) for r in G.complement_rows()[3:]]
    result={
        'schema':'C887_whole_original_complete_opposite_endpoint_height_cover_specification_v1',
        'status':'PASS_EXACT_WHOLE_ORIGINAL_COVER_ATTACHMENT_ONLY',
        'scope':'complete necessary eight-domain cover of unchanged original; every child exclusion pending',
        'theorem_commit':'ce782652','theorem_version':G.THEOREM_VERSION,
        'theorem_manifest_sha256':sha(PACKET/'MANIFEST.json'),
        'parent':{'path':str(PREFIX),'sha256':EXPECTED_PREFIX,'schema':d['schema']},
        'whole_v3_parent':{'path':str(legacy),'sha256':EXPECTED_V3},
        'accepted_parent_replay':{'path':str(replay),'sha256':sha(replay)},
        'original_id':d['id'],'original_path':ORIGINAL_PATH,
        'center_subdivisions':0,'extra_angle_subdivisions':0,
        'opposite_signed_slopes':[[str(v) for v in angles[i]] for i in (0,3)],
        'proved_weak_order_intervals':[[str(v) for v in z] for z in orders],
        'deduced_physical_variation':'V(A,H,I,D)>23/100',
        'closed_cover_threshold':'23/100','complete_closed_domains':8,
        'children_are_independent_same_parent_restrictions':True,
        'earlier_sibling_complements_added':False,'all_equality_faces_retained':True,
        'children':rows,'source_sha256':sources,
        'ancestor_replay_scope':'reuse frozen accepted full-original replay; no subdivided state is used',
        'new_original_closures':0,'new_mask_closures':0,
    }
    assert all(sha(p)==h for p,h in sources.items())
    with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'status':result['status'],'sources':len(sources),'domains':8,
                      'specification':str(OUT),'specification_sha256':sha(OUT),
                      'whole_original_sha256':EXPECTED_PREFIX},indent=2))

if __name__=='__main__':main()
