#!/usr/bin/env python3
"""Untrusted exact-dual discovery for the full C887 eight-domain complement.

One original source already proves all three weak AHID orders and opposite
endpoint signs. A complete attachment therefore needs all eight closed signed
height failures. This producer never grants original or mask closure credit.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
from fractions import Fraction as Q
import argparse,hashlib,json,sys,time

HERE=Path(__file__).resolve().parent
ENGINE=Path('/workspace/scratch/1b414599b857/cd_cells_work/engine/current_proof')
FOUNDATION=Path('/workspace/scratch/1b414599b857/cd_cells_work/c887_sharp_foundation_package')
sys.path.insert(0,str(ENGINE))
import v3_whole_parent_pass as M
import four_center_rows as FC
import square_area_moment_rows as AREA
import three_square_energy_rows as TE
sys.path.insert(0,str(FOUNDATION/'ancestry/cd_family'))
import diagonal_rows as D
import correlated_capacity_rows as C
sys.path.insert(0,str(HERE))
import opposite_tilt_four_row_guard as GUARD
import active_highs as FAST
FAST.install(M)

SCHEMA='CD_inherited_opposite_tilt_complement_discovery_v1'
TARGET='negative-887236b78100baf3'
TARGET_PATH=[['angle',3,0],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[1]]]
EPS=Q(1,2000)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(x):return tuple(tuple(Q(z)for z in ab)for ab in x)
def differences(x):return {tuple(r['pair']):box(r['intervals'])for r in x}
def view(s,d,g):return dict(angles=M.render(s['angles']),positions=M.render(s['positions']),scalar=M.render(s['scalar']),differences=M.render_diff(d),diagonal=M.render_diff(g))
def literal(row):
    co,rhs,name=row
    return dict(coefficients=[[i,str(v)]for i,v in co],rhs=str(rhs),name=name)
def row_from_literal(row):
    return tuple((i,Q(v))for i,v in row['coefficients']),Q(row['rhs']),row['name']

def load(parent,branch):
    base=json.loads(parent.read_text())
    assert base['id']==TARGET and base['path']==TARGET_PATH and base['status']=='OPEN'
    final=base['final']
    if base['schema']!='correlated_diagonal_whole_parent_v1':
        assert base['rounds'] and final==base['rounds'][-1]['after']
        assert base['final_test']['round']==len(base['rounds']) and base['final_test']['proposals']==[]
    _,_,choices=M.V.reconstruct(base['path'])
    s=dict(id=base['id'],path=base['path'],choices=choices,
           angles=box(final['angles']),positions=box(final['positions']),scalar=box(final['scalar']))
    dd=differences(final['differences']);dg=differences(final['diagonal'])
    guard=GUARD.evaluate(dict(s,differences=dd))
    assert guard['opposite_endpoint_signs_proved']
    assert all(Q(gap[0])>=0 for gap in guard['horizontal_order_intervals'])
    old=base.get('domain_context',{}).get('conditional_rows',[])
    selected=GUARD.complement_rows()[3+branch]
    rows=[row_from_literal(r)for r in old]
    if selected not in rows:rows.append(selected)
    context=dict(kind='complete_eight_signed_height_failure_attachment',
        parent=dict(path=str(parent),sha256=sha(parent),schema=base['schema']),
        branch=branch,complete_domains=8,full_original_parent=base['schema']=='correlated_diagonal_whole_parent_v1',
        conditional_rows=[literal(r)for r in rows],
        original_proved_order_and_endpoint_guard=guard,all_closed_faces_retained=True,
        all_other_inherited_bounds_retained=True,
        theorem_version=GUARD.THEOREM_VERSION)
    FAST.add_seed_record(base)
    return s,dd,dg,rows,context

def collect(s,d,g,conditional):
    rows,absolute,terminal,pos,sc,diff,guards=M.collect(s,d)
    if terminal:return rows,absolute,terminal,pos,sc,diff,g
    diag=D.effective(diff,g)
    if any(a>b for vv in diag.values()for a,b in vv):
        return rows,absolute,'empty_correlated_diagonal',pos,sc,diff,diag
    rows+=D.rows(sc,diff,diag)
    extra,guards=C.generate_rows(diff,diag);rows+=extra
    rows+=FC.linear_rows(diff,diag)
    rows+=AREA.generate_linear(diff)
    rows+=TE.linear_rows(diff,diag)
    rows+=list(conditional)
    terminal_guard=GUARD.evaluate(dict(s,positions=pos,scalar=sc,differences=diff))
    if terminal_guard['status']=='PASS_OPPOSITE_TILT_AHID_TERMINAL':
        return rows,absolute,dict(kind='opposite_tilt_AHID_boundary_terminal',guard=terminal_guard),pos,sc,diff,diag
    return rows,absolute,None,pos,sc,diff,diag

def terminal_record(rows,absolute,h):
    sol=h.getSolution()
    if sol.col_value[-1]<=1e-8:return None
    weights=M.terms(sol.row_dual)
    co,rhs=M.R.weighted_sum(rows,absolute,weights)
    reserve=-rhs-sum(a*abs(v)for a,v in zip(absolute,co))
    if reserve<=0:return None
    return dict(kind='positive_exact_reserve',weights=weights,reserve=str(reserve),
        printed_rows=M.R.printed_rows(rows,{i for i,w in weights}),
        absolute_variable_bounds=list(map(str,absolute)),weighted_rhs=str(rhs),weighted_coefficients=list(map(str,co)))

def run(parent,output,branch,rounds):
    s,diffs,diag,conditional,context=load(parent,branch)
    start=time.monotonic()
    record=dict(schema=SCHEMA,scope='ONE_CLOSED_HEIGHT_FAILURE_OF_ORIGINAL_OR_PROVED_PARENT',
        new_original_cells=0,new_masks=0,id=TARGET,path=TARGET_PATH,status='OPEN',rounds=[],
        domain_context=context,sources={str(Path(m.__file__).resolve()):sha(m.__file__)
            for m in (M,D,C,FC,AREA,TE,GUARD,FAST)})
    record['sources'][str(Path(__file__).resolve())]=sha(__file__)
    output.mkdir(parents=True,exist_ok=True);dest=output/'bound_rounds.json'
    assert not dest.exists()
    for ri in range(rounds+1):
        before=view(s,diffs,diag)
        rows,ab,term,pos,sc,dd,gg=collect(s,diffs,diag,conditional)
        item=dict(round=ri,before=before,rows=len(rows),propagated_positions=M.render(pos),
            physical_scalar_intersection=M.render(sc),effective_differences=M.render_diff(dd),
            effective_diagonal=M.render_diff(gg),proposals=[])
        if term:
            terminal=dict(kind=term['kind'],guard=term['guard'],state=item)if isinstance(term,dict)else dict(kind='exact_interval_terminal',label=term,state=item)
            record.update(status='CANDIDATE_CLOSED',terminal=terminal);break
        h=M.highs(rows,len(ab));h.run()
        if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:
            record['solver_status']=str(h.getModelStatus());break
        item['phase_margin']=h.getSolution().col_value[-1]
        tc=terminal_record(rows,ab,h)
        if tc:record.update(status='CANDIDATE_CLOSED',terminal=dict(tc,state=item));break
        if ri==rounds:record['final_test']=item;break
        h.changeColCost(len(ab),0.);h.changeColBounds(len(ab),0.,0.)
        targets=[]
        for k,(lo,hi)in enumerate(pos+sc):
            for sign in(-1,1):targets.append(dict(kind='scalar',key=k,sign=sign,objective=[[k,sign]],old=hi if sign==1 else-lo))
        for kind,mapping in(('difference',dd),('diagonal',gg)):
            for (i,j),vv in sorted(mapping.items()):
                for axis,(lo,hi)in enumerate(vv):
                    for sign in(-1,1):
                        obj=[[2*j+axis,sign],[2*i+axis,-sign]]if kind=='difference'else[[2*j,sign],[2*i,-sign],[2*j+1,sign*(1 if axis==0 else-1)],[2*i+1,-sign*(1 if axis==0 else-1)]]
                        targets.append(dict(kind=kind,key=[i,j,axis],sign=sign,objective=obj,old=hi if sign==1 else-lo))
        np=[list(x)for x in pos];ns=[list(x)for x in sc]
        nd={k:[list(x)for x in v]for k,v in dd.items()};ng={k:[list(x)for x in v]for k,v in gg.items()}
        used=set();previous=[]
        for target_index,t in enumerate(targets):
            for k,c in previous:h.changeColCost(k,0.)
            for k,c in t['objective']:h.changeColCost(k,-float(c))
            previous=t['objective'];h.setOptionValue('time_limit',h.getRunTime()+3.);h.run()
            if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:continue
            if float(t['old'])+h.getObjectiveValue()<float(EPS):continue
            weights=M.terms(h.getSolution().row_dual);co,rhs=M.R.weighted_sum(rows,ab,weights)
            for k,c in t['objective']:co[k]-=Q(c)
            correction=sum(a*abs(v)for a,v in zip(ab,co));proved=rhs+correction;upper=M.ceil_grid(proved)
            if t['old']-upper<EPS:continue
            proposal=dict(t,old=str(t['old']),upper=str(upper),proved_upper=str(proved),weights=weights,
                summed_rhs=str(rhs),residual_coefficients=[[k,str(v)]for k,v in enumerate(co)if v],residual_correction=str(correction))
            item['proposals'].append(proposal);used.update(i for i,w in weights)
            key=t['key'];sign=t['sign'];kind=t['kind']
            target=(np[key]if key<18 else ns[key-18])if kind=='scalar'else(nd if kind=='difference'else ng)[tuple(key[:2])][key[2]]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
        item['printed_rows']=M.R.printed_rows(rows,used);item['absolute_variable_bounds']=list(map(str,ab))
        pos=tuple(map(tuple,np));sc=tuple(map(tuple,ns))
        diffs={k:tuple(map(tuple,v))for k,v in nd.items()};diag={k:tuple(map(tuple,v))for k,v in ng.items()}
        if any(a>b for a,b in pos+sc)or any(a>b for zz in list(diffs.values())+list(diag.values())for a,b in zz):
            record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='empty_proved_interval'));break
        angles,contradiction,inferences=M.R.infer_angles(s['angles'],sc);item['physical_frame_inferences']=inferences
        if contradiction:record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind=contradiction));break
        analytic=M.K.analytic(angles);sc=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(sc,analytic))
        if any(a>b for a,b in sc):record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='empty_physical_frame'));break
        s.update(positions=pos,scalar=sc,angles=angles)
        item['after']=view(s,diffs,diag);record['rounds'].append(item)
        record['final']=view(s,diffs,diag);record['seconds']=time.monotonic()-start
        dest.write_text(json.dumps(record,indent=2)+'\n')
        print('BRANCH',branch,'ROUND',ri,'DEDUCTIONS',len(item['proposals']),'SECONDS',round(record['seconds'],2),flush=True)
    record['final']=view(s,diffs,diag);record['seconds']=time.monotonic()-start
    dest.write_text(json.dumps(record,indent=2)+'\n')
    print('BRANCH',branch,'RESULT',record['status'],'SECONDS',round(record['seconds'],2),flush=True)
    return record

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('parent',type=Path);ap.add_argument('output',type=Path)
    ap.add_argument('branch',type=int);ap.add_argument('--rounds',type=int,default=0)
    args=ap.parse_args();assert 0<=args.branch<8 and 0<=args.rounds<=8
    run(args.parent.resolve(),args.output.resolve(),args.branch,args.rounds)
