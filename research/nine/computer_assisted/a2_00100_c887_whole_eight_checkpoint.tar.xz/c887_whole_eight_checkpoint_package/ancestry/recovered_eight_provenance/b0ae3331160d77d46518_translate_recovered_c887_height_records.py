"""Losslessly adapt completed discovery metadata; independently replay all arithmetic.

Raw records are preserved unchanged. No geometric bound, dual weight, printed
row, terminal reserve, or saved state is altered by this schema translation.
"""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/1b414599b857/whole_mask_work/c887_chiral_route')
OUT = ROOT / 'recovered_c887_whole_eight_0656'
ID = 'negative-887236b78100baf3'
PATH = [['angle', 3, 0], ['angle_cut', [0, '0'], 1], ['alternate_four_escape', [1, 7], [1]]]
PARENT_SHA = '9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3'
PARENT = dict(path=str(ROOT / 'cd_family/new_cd_prefixes' / (ID + '.json')),
              sha256=PARENT_SHA, schema='correlated_diagonal_whole_parent_v1')
MATH_FIELDS = ('id', 'path', 'status', 'rounds', 'final', 'final_test', 'terminal')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def payload(record):
    return {key: record[key] for key in MATH_FIELDS if key in record}

def translate(raw, raw_reference, translator_reference, parent=PARENT):
    assert raw['schema'] == 'CD_inherited_opposite_tilt_complement_discovery_v1'
    assert raw['scope'] == 'ONE_CLOSED_HEIGHT_FAILURE_OF_ORIGINAL_OR_PROVED_PARENT'
    assert raw['id'] == ID and raw['path'] == PATH
    assert raw['new_original_cells'] == raw['new_masks'] == 0
    assert raw['status'] in ('OPEN', 'CANDIDATE_CLOSED') and len(raw['rounds']) <= 3
    if raw['status'] == 'OPEN':
        assert raw['final_test']['round'] == len(raw['rounds'])
        assert raw['final_test']['proposals'] == []
    else:
        assert raw['terminal']['kind'] == 'positive_exact_reserve'
    context = raw['domain_context']
    assert context['kind'] == 'complete_eight_signed_height_failure_attachment'
    assert context['full_original_parent'] is True and context['complete_domains'] == 8
    assert context['all_closed_faces_retained'] is True
    assert context['all_other_inherited_bounds_retained'] is True
    assert 'closed_restrictions' not in context and len(context['conditional_rows']) == 1
    assert context['parent']['sha256'] == parent['sha256'] == PARENT_SHA
    assert context['parent']['schema'] == parent['schema'] == 'correlated_diagonal_whole_parent_v1'
    branch = context['branch']
    assert type(branch) is int and 0 <= branch < 8
    signs = tuple(1 if branch & (1 << (2-i)) else -1 for i in range(3))
    terms = {}
    chain = (0, 7, 8, 3)
    for i, j, sign in zip(chain, chain[1:], signs):
        terms[2*i+1] = terms.get(2*i+1, 0) + sign
        terms[2*j+1] = terms.get(2*j+1, 0) - sign
    row = dict(coefficients=[[k, str(v)] for k, v in sorted(terms.items()) if v],
               rhs='-23/100', name='opposite_tilt_AHID_variation_' + str(branch))
    assert context['conditional_rows'] == [row]
    result = copy.deepcopy(raw)
    del result['domain_context']
    result['schema'] = 'C887_whole_original_opposite_tilt_height_bound_discovery_v1'
    result['scope'] = 'ONE_CLOSED_HEIGHT_DOMAIN_OF_WHOLE_UNCHANGED_ORIGINAL'
    result['prior'] = copy.deepcopy(parent)
    result['sharp_restriction'] = dict(kind='opposite_tilt_height_closed_complement',
        parent=copy.deepcopy(parent), selected_row=list(chain), variation_bound='23/100',
        branch=branch, complete_closed_domains=8, closed_faces_retained=True, conditional_row=row)
    result['sources'][raw_reference['path']] = raw_reference['sha256']
    result['sources'][translator_reference['path']] = translator_reference['sha256']
    result['format_translation'] = dict(raw_record=raw_reference, translator=translator_reference,
        original_domain_context=copy.deepcopy(context), arithmetic_fields_preserved=list(MATH_FIELDS),
        no_coordinate_or_angle_cut=True, no_sibling_restriction_added=True)
    assert payload(result) == payload(raw)
    assert all(result['sources'][key] == value for key, value in raw['sources'].items())
    return result

def main():
    assert not OUT.exists()
    (OUT / 'raw').mkdir(parents=True)
    (OUT / 'converted').mkdir()
    screen = SOURCE / 'whole_original_rounds_3/SCREEN_RESULTS.json'
    screen_bytes = screen.read_bytes()
    screen_data = json.loads(screen_bytes)
    assert [x['branch'] for x in screen_data['members']] == list(range(8))
    (OUT / 'SOURCE_SCREEN_RESULTS.json').write_bytes(screen_bytes)
    translator = dict(path=str(Path(__file__).resolve()), sha256=sha(__file__))
    entries = []
    for entry in screen_data['members']:
        original = Path(entry['path'])
        data = original.read_bytes()
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        raw = OUT / 'raw' / ('branch_%02d.json' % entry['branch'])
        raw.write_bytes(data)
        reference = dict(path=str(raw), sha256=sha(raw))
        record = json.loads(data)
        result = translate(record, reference, translator)
        converted = OUT / 'converted' / raw.name
        converted.write_text(json.dumps(result, indent=2) + '\n')
        assert payload(json.loads(converted.read_text())) == payload(record)
        assert original.read_bytes() == data
        entries.append(dict(branch=entry['branch'], source_record=dict(path=str(original), sha256=entry['sha256']),
                            raw_record=reference,
                            converted_record=dict(path=str(converted), sha256=sha(converted), schema=result['schema']),
                            status=result['status'], rounds=len(result['rounds']),
                            mathematical_fields_identical=True))
    assert screen.read_bytes() == screen_bytes
    manifest = dict(schema='C887_completed_foreign_height_record_lossless_translation_v1',
                    source_workspace_read_only=True, original_files_modified=False,
                    parent=PARENT, translator=translator,
                    source_screen_sha256=hashlib.sha256(screen_bytes).hexdigest(),
                    entries=entries, independent_arithmetic_replay_required=True,
                    new_original_cells=0, new_masks=0)
    (OUT / 'TRANSLATION_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(output=str(OUT), records=len(entries),
                         candidate_terminals=sum(x['status'] == 'CANDIDATE_CLOSED' for x in entries),
                         new_original_cells=0, new_masks=0)))

if __name__ == '__main__':
    main()
