# C887: the eight height domains already cover the whole original

November 4, 2026. Complete necessary-cover declaration only. All eight domain
exclusions remain pending. No original or mask is marked closed.

## Original scope, before every I or H subdivision

The original is `negative-887236b78100baf3` of the unchanged full-nine
`001/00` predicate, with literal path

```json
[["angle",3,0],["angle_cut",[0,"0"],1],["alternate_four_escape",[1,7],[1]]]
```

Retain all nine original physical squares, all 36 original corners, all
36 physical pairs, all five original cone comparisons, actual AB, BC,
EF, FG and strictly weak CD. The enclosing disk may be the closed
`Q=1105/256`; the strict CD comparison is retained at its equality boundary.

The complete whole-original v3 ancestor is bound by
`d7ad68039cefde5580f63db10002a6dcb436381ee20ac04e9955fb5f127a84f0`.
Its zero-round identity wrapper is
`9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3`.
The wrapper explicitly has `rounds=[]`, `new_original_cells=0` and
status OPEN. It contains no I rectangle, H rectangle, grid member or angle
restriction beyond the original path. Its final state is the independently
replayed whole v3 state, not a state promoted from a later subdivision.

The accepted foundation's frozen `diagonal_replay_reports` entry binds this
wrapper and its prior. It reports 29 earlier coordinate deductions followed
by 364 exact whole-parent deductions in five rounds, with 976 printed
premise rows. It reports no center cover and no original closure. The present
attachment reuses that accepted replay; it does not run old report-writing
checkers inside a frozen packet.

## Whole-original hypotheses of the new theorem

In that whole-original final state, before every I cut, the exact Cartesian
difference intervals are

\[
\begin{split}
x_H-x_A&\in[26355/1048576,83/30],\\
x_I-x_H&\in[0,2785067/1048576],\\
x_I-x_D&\in[-3064161/1048576,
             -434432029724121/5000000000000000].
\end{split}
\]

Thus `x_A<x_H<=x_I<x_D`. The strict outer order reserves are positive;
the middle equality is retained. The same original state gives

\[
t_A\in[0,21144313723523/140737488355328],\qquad
t_D\in[-1,0].
\]

These are precisely the opposite endpoint signs and three weak horizontal
orders required by the new full-angle theorem published in `ce782652`.
The short original EFG chain is already actual. The theorem requires no
angle-size, shoulder-height or normalized CD transverse-gap premise.

Its unchanged strict-original equality argument excludes

\[
|y_H-y_A|+|y_I-y_H|+|y_D-y_I|\le23/100
\]

throughout this **whole original**. Consequently every physical survivor
satisfies strict total variation greater than `23/100`.

## Complete closed eight-member cover

For every independent sign triple `e in {-1,+1}^3`, impose the one closed
restriction

\[
e_1(y_H-y_A)+e_2(y_I-y_H)+e_3(y_D-y_I)\ge23/100.
\]

The maximum of these eight forms is exactly the total variation, so their
closed union covers the entire unchanged original caller. These children
share the same whole-original parent; no fixed I or H cover is needed for
this logical reduction. A later proof may still choose such subdivisions
inside a child, provided its complete scope is retained.

In the `<=` row convention the nonzero coefficients are

`y_A:e1, y_H:-e1+e2, y_I:-e2+e3, y_D:-e3`,

and the right side is `-23/100`. All eight sign choices occur once in
lexicographic order. No child has predecessor guards from earlier siblings.
The closed shared faces, including equality at `23/100`, remain covered.

The three order hypotheses are proved from this parent. This is why the
cover contains only eight height domains; it does not assert that the
three opposite closed order halfspaces are empty at their equality faces.
Likewise the old sharp theorem's beta and shoulder escapes are irrelevant
to this new theorem and are not premises or deleted branches of this cover.

`build_c887_whole_eight_height_specification.py` checks these exact literals,
the parent and accepted replay hashes, and the complete theorem/foundation
inventories before and after producing
`C887_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_SPECIFICATION.json`.
It is an immutable attachment check, not a fresh ancestor induction replay
or a proof of any of the eight pending exclusions. Only a later complete
eight-member proof can close this original.
