"""Exact attachment contract for a leaf-only continuation of the published A165 cover."""
if not __debug__:
    raise RuntimeError('Exact retained-cover checks require assertions.')
from pathlib import Path
from copy import deepcopy
import hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=ROOT/'d_work/A_c744_component3_four_first_use_snapshot'
SOURCE_MANIFEST_SHA='a8f67d1de94a9a8eac0034b3a85f77d971fff500de3ea73d2458501246a3a1ad'
OPEN_LEAVES=(144,145,146,148,149,151,152,154,155,156,157,158,159,160,161,163,164)
TARGET='positive-c744bc031d40ee64'
ORIGINAL_PATH=[['angle',3,1],['angle_cut',[0,'0'],0],['inward_row_escape',[7,8],[4]]]
FAMILY_SHA='63458318a3681d677745baf4a00d8a738a5705c6276659174e59f440fa9a06e3'
PREFIX='certified_a_c744_original_i64_bound_'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())

def verify_source_freeze():
    freeze=read(HERE/'SOURCE_BINDINGS.json')
    for name,h in freeze['files'].items():assert sha(HERE/name)==h,name
    for path,h in freeze['external_input_sha256'].items():assert sha(path)==h,path
    return freeze

def source_manifest():
    path=SOURCE/'manifest.json';assert sha(path)==SOURCE_MANIFEST_SHA
    m=read(path)
    assert m['schema']=='same_original_physical_SAT_proxy_angle_tree_discovery_v1'
    assert m['id']==TARGET and m['original_path']==ORIGINAL_PATH
    assert m['component']==3 and m['scope']=='ONE_CLOSED_MEMBER_OF_THE_COMPLETE_ACTUAL_AB_FIVE_COVER'
    assert m['closed_domain']==dict(name='two_link_actual_AB_escape_3',coefficients=[[3,'1'],[7,'1'],[17,'-2']],rhs='-3/5')
    assert m['status']=='OPEN'and m['new_original_cells']==m['new_masks']==0
    assert [n['index']for n in m['nodes']]==list(range(165))
    leaves=tuple(n['index']for n in m['nodes']if not n['children']and n['status']=='OPEN')
    assert leaves==OPEN_LEAVES
    for n in m['nodes']:
        assert n['file']==f"node_{n['index']:05d}.json"
        assert sha(SOURCE/n['file'])==n['sha256']
    for path,h in m['source_sha256'].items():assert sha(path)==h,path
    return m

def check_metadata(old,new,may_change_payload):
    assert set(old)==set(new)
    assert {k:v for k,v in old.items()if k not in('status','sha256')}=={k:v for k,v in new.items()if k not in('status','sha256')}
    if not may_change_payload:assert old['sha256']==new['sha256']
    if old['children']:
        assert new['status']in('OPEN','CANDIDATE_COVER_CLOSED')
    elif may_change_payload:
        assert old['status']=='OPEN'and new['status']in('OPEN','CANDIDATE_CLOSED')
    else:assert new['status']==old['status']

def check_record_extension(old,new,index,old_sha):
    assert index in OPEN_LEAVES and old['status']=='OPEN'
    assert new['initial']==old['initial']
    assert new['id']==old['id']==TARGET and new['original_path']==old['original_path']==ORIGINAL_PATH
    old_count=len(old['rounds']);assert new['rounds'][:old_count]==old['rounds']
    extra=new['rounds'][old_count:];assert 0<=len(extra)<=2
    preserved=lambda r:{k:v for k,v in r.items()if k not in('status','rounds','final','terminal','terminal_state','i64_original_bound_suffix')}
    assert preserved(new)==preserved(old)
    assert set(new)<=set(old)|{'terminal','i64_original_bound_suffix'}
    assert new['i64_original_bound_suffix']==dict(source_node_sha256=old_sha,
        old_rounds=old_count,appended_rounds=len(extra),source_final_before=old['final'],
        family_binding_sha256=FAMILY_SHA,new_I64_restriction_added=False,numerical_solves=0)
    if extra:assert extra[0]['before']==old['final']
    for number,rr in enumerate(extra):
        assert rr['direct_shared_affine_copy']is True and rr['numerical_solves']==rr['numeric_failures']==0
        assert all(row['name'].startswith(PREFIX+FAMILY_SHA+'_')for row in rr['printed_rows'])
        if number:
            assert rr['before']==extra[number-1]['after']
            assert rr['printed_rows']==rr['proposals']==[]
        for proposal in rr['proposals']:
            assert len(proposal['weights'])==1 and proposal['weights'][0][1]==1<<40
            assert proposal['residual_coefficients']==[]and proposal['residual_correction']=='0'
    if new['status']=='OPEN':
        assert 'terminal'not in new
        assert new['final']==(extra[-1]['after']if extra else old['final'])
    else:assert new['status']=='CANDIDATE_CLOSED'and'final'not in new and'terminal'in new
    return dict(index=index,old_rounds=old_count,appended_rounds=len(extra),
        appended_deductions=sum(len(r['proposals'])for r in extra),
        appended_printed_rows=sum(len(r['printed_rows'])for r in extra),status=new['status'])

def verify_attachment(folder):
    old=source_manifest();folder=Path(folder).resolve();assert folder!=SOURCE.resolve()
    m=read(folder/'manifest.json')
    assert set(m)==set(old)|{'original_i64_leaf_continuation'}
    assert {k:v for k,v in m.items()if k not in('status','nodes','source_sha256','original_i64_leaf_continuation')}=={k:v for k,v in old.items()if k not in('status','nodes','source_sha256')}
    assert len(m['nodes'])==165
    attachment=m['original_i64_leaf_continuation']
    assert attachment['source_manifest']==dict(path=str(SOURCE/'manifest.json'),sha256=SOURCE_MANIFEST_SHA)
    assert attachment['family_binding_sha256']==FAMILY_SHA
    assert attachment['processed_open_leaf_indices']==list(OPEN_LEAVES)
    for key in('all_original_nodes_and_splits_retained','all_child_initial_states_unchanged','all_old_rounds_retained','only_open_leaf_suffixes_added'):
        assert attachment[key]is True
    assert attachment['new_restrictions']==attachment['new_nodes']==attachment['numerical_solves']==0
    for path,h in old['source_sha256'].items():assert m['source_sha256'][path]==h
    for path,h in m['source_sha256'].items():assert sha(path)==h,path
    changed=[];unchanged=0
    for before,after in zip(old['nodes'],m['nodes']):
        i=before['index'];check_metadata(before,after,i in OPEN_LEAVES)
        path=folder/after['file'];assert sha(path)==after['sha256']
        if before['sha256']==after['sha256']:
            unchanged+=1;continue
        assert i in OPEN_LEAVES
        previous=read(SOURCE/before['file']);current=read(path)
        changed.append(check_record_extension(previous,current,i,before['sha256']))
    assert attachment['changed_open_leaf_indices']==[x['index']for x in changed]
    assert attachment['unchanged_payloads']==unchanged
    # This is an attachment/byte check only. The frozen reader must still
    # reconstruct every original child, every exact round, and every terminal.
    return dict(source_manifest_sha256=SOURCE_MANIFEST_SHA,total_nodes=165,
        retained_open_leaf_domains=17,unchanged_payloads=unchanged,changed_leaves=changed,
        child_states_not_rebased=True,cover_arithmetic_checked=False)
