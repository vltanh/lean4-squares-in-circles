#!/usr/bin/env python3
"""Fresh complete A165 arithmetic/cover replay with explicitly historical source reuse."""
if not __debug__:raise RuntimeError('Exact retained-cover replay requires assertions.')
from pathlib import Path
import argparse,json,sys,time
import retained_cover_contract as CONTRACT
import i64_retained_cover_adapter as ATTACH
I=ATTACH.ROWS

def replay(folder,output):
    started=time.monotonic();folder=Path(folder).resolve();output=Path(output).resolve()
    assert not output.exists();internal=output.with_name(output.stem+'_INHERITED_A165.json');assert not internal.exists()
    freeze=CONTRACT.verify_source_freeze()
    before=CONTRACT.verify_attachment(folder);binding=I.verify_binding();evidence,cache=I.HISTORY.validate()
    instances=[];Checker,Adapter=ATTACH.classes(binding,instances)
    four,consequence,lazy=ATTACH.FOUR,ATTACH.CONSEQUENCE,ATTACH.TREE.LAZY
    saved=[(four,'Checker',four.Checker),(four,'Adapter',four.Adapter),
        (consequence,'Checker',consequence.Checker),(consequence,'Adapter',consequence.Adapter),
        (consequence,'BASE',consequence.BASE),(consequence,'_source_report',consequence._source_report),
        (consequence,'_checker',consequence._checker),(lazy,'Adapter',lazy.Adapter),(lazy.ALL,'Checker',lazy.ALL.Checker)]
    try:
        four.Checker=Checker;four.Adapter=Adapter
        with I.HISTORY.InstalledCache(cache)as installed:
            inherited=ATTACH.TREE.replay(folder,internal)
        calls=installed.calls
    finally:
        for module,name,value in reversed(saved):setattr(module,name,value)
    assert len(instances)==1;checker=instances[0]
    assert calls==dict(post=0,shared=0,a1=0,complements=1)
    assert inherited['nodes']==165 and inherited['component']==3
    assert inherited['original_id']==I.TARGET and inherited['original_path']==I.ORIGINAL_PATH
    assert inherited['closed_domain']==dict(name='two_link_actual_AB_escape_3',coefficients=[[3,'1'],[7,'1'],[17,'-2']],rhs='-3/5')
    assert inherited['all_nine_originals_retained']is True and inherited['closed_shared_faces_retained']is True
    assert inherited['node_payloads_replayed_lazily']is True
    assert inherited['new_original_cells']==inherited['new_masks']==0
    assert inherited['freshly_replayed_original_complement_consequences']==cache['complements']
    assert CONTRACT.verify_attachment(folder)==before
    I.verify_binding();again,_=I.HISTORY.validate();assert again==evidence
    CONTRACT.verify_source_freeze()
    assert not any(name in sys.modules for name in('numpy','scipy','highspy','original_i64_bound_rows','extend_retained_cover'))
    result=dict(status='PASS_A165_I64_COMPLETE_COMPONENT_EXCLUDED'if inherited['open_leaves']==0 else'PASS_A165_I64_COMPLETE_RETAINED_COVER_OPEN',
        original_id=I.TARGET,original_path=I.ORIGINAL_PATH,component=3,closed_domain=inherited['closed_domain'],
        scope='ENTIRE_RETAINED_OLD_3_5_COMPONENT3_COVER_WITH_ORIGINAL_WIDE_NECESSARY_ROWS',
        family_binding_sha256=I.BINDING_SHA,source_manifest_sha256=CONTRACT.SOURCE_MANIFEST_SHA,
        continued_manifest_sha256=CONTRACT.sha(folder/'manifest.json'),attachment=before,
        nodes=inherited['nodes'],leaf_domains=inherited['leaf_domains'],excluded_leaves=inherited['excluded_leaves'],open_leaves=inherited['open_leaves'],
        rounds=inherited['rounds'],deductions=inherited['deductions'],printed_rows_checked=inherited['printed_rows_checked'],
        weighted_I64_endpoint_occurrences=checker.i64_original_endpoint_occurrences,
        weighted_I64_height_occurrences=checker.i64_original_height_occurrences,
        inherited_complete_arithmetic_report=dict(path=str(internal),sha256=CONTRACT.sha(internal)),
        historical_source_proof_reuse=evidence,cached_source_provider_calls=calls,
        legacy_report_freshly_replayed_source_field_is_explicit_historical_reuse=True,
        all165_nodes_freshly_replayed=True,all_old_rounds_retained=True,all_child_initial_states_unchanged=True,
        new_I64_height_predicate_not_added_to_path=True,complete_4_8_2_covers_unchanged=True,
        historical_A1_and_source_arithmetic_repeated=False,fresh813_source_repeated=False,
        cold_portable_replay_claimed=False,numerical_solves=0,
        all_nine_originals_retained=True,original_corners=36,original_pairs=36,marked_cones=5,mask='001/00',
        closed_shared_faces_retained=True,new_original_cells=0,new_masks=0,seconds=time.monotonic()-started)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in('status','nodes','excluded_leaves','open_leaves','deductions','weighted_I64_endpoint_occurrences','seconds')}),flush=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('output',type=Path);a=p.parse_args();replay(a.folder,a.output)
