#!/usr/bin/env python3
"""Append one direct endpoint round and one ordinary propagation round per OPEN leaf.

This is a candidate constructor, not an acceptance checker. It performs no LP
solve, creates no children, and leaves each original initial state unchanged.
"""
if not __debug__:raise RuntimeError('Exact construction requires assertions.')
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from copy import deepcopy
import argparse,json,os,sys,time
import retained_cover_contract as CONTRACT
import i64_retained_cover_adapter as ATTACH
I=ATTACH.ROWS
import original_i64_bound_rows as PRODUCER
import direct_shared_bound_round_snapshot as DIRECT
import independent_physical_sat_diagonal_replay as CORE

def write_new(path,raw):
    path=Path(path)
    with path.open('xb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
def write_json(path,value):write_new(path,(json.dumps(value,indent=2)+'\n').encode())

def state(value,choices):
    result=dict(id=value['id'],path=deepcopy(value['path']))
    for name in('angles','positions','scalar'):result[name]=tuple(tuple(map(F,z))for z in value[name])
    for name in('differences','diagonal'):
        result[name]={tuple(z['pair']):tuple(tuple(map(F,x))for x in z['intervals'])for z in value[name]}
    result['choices']=choices(result['path']);CORE.valid_state(result);return result

class Engine:
    SCALE=CORE.DENOMINATOR;GRID=CORE.GRID
    ceil_grid=staticmethod(CORE.ceiling_grid);stateview=staticmethod(CORE.state_view)
    @staticmethod
    def printed(rows,indices):
        return [dict(index=k,coefficients=[[i,str(v)]for i,v in rows[k][0]],rhs=str(rows[k][1]),name=rows[k][2])for k in sorted(indices)]

def propagation_terminal(adapter,current):
    """Discover only terminal types already checked by the frozen adapter."""
    K=adapter.K;V=K.V
    effective,label=V.effective_boxes(current['angles'],current['choices'],K.LEGACY)
    if label is not None:return dict(kind='accepted_effective_angle_terminal',label=label)
    positions,hs,gs,label=V.center_bounds(effective,current['positions'],current['choices'],K.LEGACY)
    if label is not None:return dict(kind='accepted_center_interval_terminal',label=label)
    for index,((a,b),(c,d))in enumerate(zip(current['scalar'],K.analytic(effective))):
        lo,hi=max(a,c),min(b,d)
        if lo>hi:return dict(kind='empty_propagated_scalar',index=index,lower=str(lo),upper=str(hi))
    differences={}
    for pair in combinations(range(9),2):
        intervals=V.difference_bounds(pair,positions,gs,K.LEGACY)
        if pair in current['differences']:
            intervals=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(intervals,current['differences'][pair]))
        for axis,(lo,hi)in enumerate(intervals):
            if lo>hi:return dict(kind='empty_propagated_difference',pair=list(pair),axis=axis,lower=str(lo),upper=str(hi))
        differences[pair]=intervals
    diagonal=adapter.checker.ID.intervals(differences,current['diagonal'])
    if any(a>b for intervals in diagonal.values()for a,b in intervals):return dict(kind='empty_correlated_diagonal')
    return None

class Context:
    def __init__(self,adapter,binding,copy_rows):
        self.adapter=adapter;self.binding=binding;self.copy_rows=copy_rows
        self.R=adapter.R;self.K=adapter.K
    def collect(self,current):
        I.assert_caller(current)
        terminal=propagation_terminal(self.adapter,current)
        if terminal is not None:
            assert self.adapter.verify_early_terminal(deepcopy(current),terminal)is True
            return None,None,None,terminal
        _,bounds,propagated=self.adapter.rebuild(current,[])
        rows=PRODUCER.necessary_rows(current,self.binding)if self.copy_rows else[]
        return rows,bounds,propagated,None

def extended_record(previous,old_sha,index,adapter,binding):
    assert previous['status']=='OPEN'
    current=state(previous['final'],adapter.choices);new=deepcopy(previous)
    appended=[];terminal=None
    for copy_rows in(True,False):
        after,round_record,terminal=DIRECT.bound_round(Engine,Context(adapter,binding,copy_rows),current,(I.PREFIX,))
        if round_record is not None:appended.append(round_record)
        if terminal is not None:break
        current=after
    if terminal is None:
        terminal=propagation_terminal(adapter,current)
        if terminal is not None:assert adapter.verify_early_terminal(deepcopy(current),terminal)is True
    if not appended and terminal is None:return previous
    new['rounds']=previous['rounds']+appended
    if terminal is None:new.update(status='OPEN',final=CORE.state_view(current))
    else:
        new.update(status='CANDIDATE_CLOSED',terminal=terminal);new.pop('final')
    new['i64_original_bound_suffix']=dict(source_node_sha256=old_sha,old_rounds=len(previous['rounds']),
        appended_rounds=len(appended),source_final_before=previous['final'],family_binding_sha256=I.BINDING_SHA,
        new_I64_restriction_added=False,numerical_solves=0)
    CONTRACT.check_record_extension(previous,new,index,old_sha)
    return new

def run(folder):
    started=time.monotonic();folder=Path(folder).resolve();assert not folder.exists()
    source=CONTRACT.source_manifest();binding=I.verify_binding();evidence,cache=I.HISTORY.validate()
    freeze=CONTRACT.verify_source_freeze()
    old_report=ATTACH.CONSEQUENCE._source_report
    ATTACH.CONSEQUENCE._source_report=deepcopy(cache['complements'])
    instances=[];Checker,Adapter=ATTACH.classes(binding,instances)
    try:
        checker=Checker()
        whole_raw=I.read(binding['whole_original_parent']['path'])['record']['final']
        whole=state(whole_raw,lambda path:checker.K.V.reconstruct(path)[2])
        adapter=Adapter(checker,whole,3)
        folder.mkdir(parents=True,exist_ok=False);manifest=deepcopy(source);changed=[];unchanged=0
        for node in manifest['nodes']:
            index=node['index'];original=CONTRACT.SOURCE/node['file'];target=folder/node['file']
            assert CONTRACT.sha(original)==node['sha256']
            if index not in CONTRACT.OPEN_LEAVES:
                os.link(original,target);unchanged+=1;continue
            old=CONTRACT.read(original);new=extended_record(old,node['sha256'],index,adapter,binding)
            if new==old:
                os.link(original,target);unchanged+=1;continue
            write_json(target,new);node['sha256']=CONTRACT.sha(target);node['status']=new['status'];changed.append(index)
            print(json.dumps(dict(index=index,status=new['status'],appended_rounds=len(new['rounds'])-len(old['rounds']),
                appended_deductions=sum(len(r['proposals'])for r in new['rounds'][len(old['rounds']):]))),flush=True)
        def status(index):
            n=manifest['nodes'][index]
            if not n['children']:return n['status']=='CANDIDATE_CLOSED'
            outcomes=[status(k)for k in n['children']]
            closed=all(outcomes);n['status']='CANDIDATE_COVER_CLOSED'if closed else'OPEN';return closed
        manifest['status']='CANDIDATE_COVER_CLOSED'if status(0)else'OPEN'
        manifest['original_i64_leaf_continuation']=dict(
            source_manifest=dict(path=str(CONTRACT.SOURCE/'manifest.json'),sha256=CONTRACT.SOURCE_MANIFEST_SHA),
            family_binding_sha256=I.BINDING_SHA,processed_open_leaf_indices=list(CONTRACT.OPEN_LEAVES),
            changed_open_leaf_indices=changed,unchanged_payloads=unchanged,
            all_original_nodes_and_splits_retained=True,all_child_initial_states_unchanged=True,
            all_old_rounds_retained=True,only_open_leaf_suffixes_added=True,new_restrictions=0,new_nodes=0,numerical_solves=0)
        for name,h in freeze['files'].items():manifest['source_sha256'][str(CONTRACT.HERE/name)]=h
        manifest['source_sha256'][str(CONTRACT.HERE/'SOURCE_BINDINGS.json')]=CONTRACT.sha(CONTRACT.HERE/'SOURCE_BINDINGS.json')
        write_json(folder/'manifest.json',manifest)
        attachment=CONTRACT.verify_attachment(folder)
        I.verify_binding();CONTRACT.source_manifest();CONTRACT.verify_source_freeze()
        assert not any(name in sys.modules for name in('numpy','scipy','highspy'))
        receipt=dict(status='CANDIDATE_A165_I64_EXACT_ONLY_LEAF_CONTINUATION',manifest_sha256=CONTRACT.sha(folder/'manifest.json'),
            attachment=attachment,historical_source_reuse=evidence,ordinary_rounds_and_terminals_require_full_replay=True,
            new_original_cells=0,new_masks=0,numerical_solves=0,seconds=time.monotonic()-started)
        write_json(folder/'CONSTRUCTION_RECEIPT.json',receipt)
        print(json.dumps({k:receipt[k]for k in('status','manifest_sha256','seconds')}),flush=True)
    finally:ATTACH.CONSEQUENCE._source_report=old_report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();run(a.output)
