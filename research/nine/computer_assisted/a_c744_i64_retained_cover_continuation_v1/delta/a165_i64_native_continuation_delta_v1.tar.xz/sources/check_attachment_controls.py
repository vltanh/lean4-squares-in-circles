#!/usr/bin/env python3
"""Small scope/prefix controls, expressly separate from complete node arithmetic."""
if not __debug__:raise RuntimeError('Attachment controls require assertions.')
from pathlib import Path
from copy import deepcopy
import argparse,json
import retained_cover_contract as C

def rejected(fn):
    try:fn()
    except(AssertionError,KeyError,TypeError,ValueError):return
    raise AssertionError('Damaged attachment was accepted.')

def run(output):
    output=Path(output);assert not output.exists();C.verify_source_freeze();m=C.source_manifest()
    old=dict(id=C.TARGET,original_path=deepcopy(C.ORIGINAL_PATH),initial={'point':'original exact state'},
        status='OPEN',rounds=[{'before':'old exact round','after':'old final'}],final={'point':'old certified final'},
        ignored_numeric_note='retained byte-for-byte')
    proposal=dict(weights=[[0,1<<40]],residual_coefficients=[],residual_correction='0')
    rr=dict(before=deepcopy(old['final']),after={'point':'new certified final'},direct_shared_affine_copy=True,
        numerical_solves=0,numeric_failures=0,printed_rows=[dict(index=0,name=C.PREFIX+C.FAMILY_SHA+'_fixture')],
        proposals=[proposal])
    new=deepcopy(old);new['rounds'].append(rr);new['final']=deepcopy(rr['after'])
    new['i64_original_bound_suffix']=dict(source_node_sha256='a'*64,old_rounds=1,appended_rounds=1,
        source_final_before=old['final'],family_binding_sha256=C.FAMILY_SHA,new_I64_restriction_added=False,numerical_solves=0)
    C.check_record_extension(old,new,144,'a'*64);damages=0
    changes=[lambda x:x.__setitem__('initial',{'point':'rebased child'}),
        lambda x:x.__setitem__('id','foreign'),lambda x:x.__setitem__('original_path',[]),
        lambda x:x['rounds'][0].__setitem__('before','changed old proof'),
        lambda x:x['rounds'][1].__setitem__('before',{'point':'unproved box'}),
        lambda x:x['rounds'][1]['printed_rows'][0].__setitem__('name','foreign_row'),
        lambda x:x['rounds'][1]['proposals'][0].__setitem__('weights',[[0,-1]]),
        lambda x:x['rounds'][1]['proposals'][0].__setitem__('residual_correction','1'),
        lambda x:x['i64_original_bound_suffix'].__setitem__('new_I64_restriction_added',True),
        lambda x:x['i64_original_bound_suffix'].__setitem__('source_node_sha256','b'*64),
        lambda x:x.__setitem__('final',{'point':'unproved final'}),
        lambda x:x.__setitem__('foreign_metadata','new unreviewed field')]
    for change in changes:
        damaged=deepcopy(new);change(damaged)
        rejected(lambda damaged=damaged:C.check_record_extension(old,damaged,144,'a'*64));damages+=1
    rejected(lambda:C.check_record_extension(old,new,2,'a'*64));damages+=1
    meta=deepcopy(m['nodes'][0]);other=deepcopy(meta);other['status']='CANDIDATE_COVER_CLOSED'
    C.check_metadata(meta,other,False)
    for field,value in [('children',meta['children'][:-1]),('parent',7),('depth',1),('restriction',{'kind':'foreign'}),('sha256','0'*64)]:
        damaged=deepcopy(meta);damaged[field]=value
        rejected(lambda damaged=damaged:C.check_metadata(meta,damaged,False));damages+=1
    damaged=deepcopy(meta);damaged['split']['pair']=[0,8]
    rejected(lambda:C.check_metadata(meta,damaged,False));damages+=1
    C.verify_source_freeze()
    result=dict(status='PASS_A165_ATTACHMENT_SCOPE_AND_PREFIX_CONTROLS',
        source_manifest_sha256=C.SOURCE_MANIFEST_SHA,source_payload_hashes_checked=165,
        retained_open_leaves=list(C.OPEN_LEAVES),damaged_attachments_rejected=damages,
        synthetic_records_only=True,weighted_arithmetic_checked=False,whole_cover_replayed=False,
        no_candidate_tree_constructed=True,numerical_solves=0,new_original_cells=0,new_masks=0)
    output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();run(a.output)
