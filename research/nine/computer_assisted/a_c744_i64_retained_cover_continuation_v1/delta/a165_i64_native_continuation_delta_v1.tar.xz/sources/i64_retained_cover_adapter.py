"""Only the accepted original-wide literals extend the unchanged A component adapter."""
from pathlib import Path
from fractions import Fraction as F
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'a_c744_original_i64_bounds_v2'))
import independent_original_i64_bounds as ROWS
import verify_ac_two_link_consequence_four_lazy_tree as TREE

FOUR=TREE.FOUR
CONSEQUENCE=FOUR.BASE
OLD_CHECKER=FOUR.Checker
OLD_ADAPTER=FOUR.Adapter

def classes(binding,instances):
    class Checker(OLD_CHECKER):
        def __init__(self):
            super().__init__()
            self.i64_original_binding=binding
            self.i64_original_endpoint_occurrences=0
            self.i64_original_height_occurrences=0
            instances.append(self)
    class Adapter(OLD_ADAPTER):
        def rebuild(self,state,printed):
            ROWS.assert_caller(state)
            def extra(row):return row['name'].startswith(ROWS.PREFIX)or row['name']==ROWS.HEIGHT_NAME
            rows,bounds,physical=super().rebuild(state,[r for r in printed if not extra(r)])
            for row in printed:
                if not extra(row):continue
                literal=(tuple((i,F(value))for i,value in row['coefficients']),F(row['rhs']),row['name'])
                ROWS.verify_literal(literal,state,self.checker.i64_original_binding)
                assert row['index']not in rows;rows[row['index']]=literal
                if row['name']==ROWS.HEIGHT_NAME:self.checker.i64_original_height_occurrences+=1
                else:self.checker.i64_original_endpoint_occurrences+=1
            return rows,bounds,physical
    return Checker,Adapter
