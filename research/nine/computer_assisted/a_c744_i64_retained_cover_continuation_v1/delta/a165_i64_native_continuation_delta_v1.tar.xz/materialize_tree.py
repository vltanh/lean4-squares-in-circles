#!/usr/bin/env python3
"""File-only assembly of a retained A165 tree from an exact delta and published A1 base."""
if not __debug__:raise RuntimeError('Exact materialization requires assertions.')
from pathlib import Path
import argparse,hashlib,json,os

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def local(folder,name):
    p=Path(name)
    assert not p.is_absolute()and p.parts and all(x not in('','..','.')for x in p.parts)
    path=folder/p;assert path.resolve().is_relative_to(folder)and not path.is_symlink()
    assert path.is_file();return path

def run(delta,base,output):
    delta=Path(delta).resolve();base=Path(base).resolve();output=Path(output).resolve()
    assert delta.is_dir()and base.is_dir()and not output.exists()
    assert not output.is_relative_to(delta)and not output.is_relative_to(base)
    inventory=read(delta/'INPUT_MANIFEST.json');pins={str(delta/'INPUT_MANIFEST.json'):sha(delta/'INPUT_MANIFEST.json')}
    assert inventory['schema']=='A165_native_exact_continuation_delta_v1'
    assert not any(p.is_symlink()for p in delta.rglob('*'))
    assert {str(p.relative_to(delta))for p in delta.rglob('*')if p.is_file()}==set(inventory['files'])|{'INPUT_MANIFEST.json'}
    for name,entry in inventory['files'].items():
        path=local(delta,name);assert path.stat().st_size==entry['bytes']and sha(path)==entry['sha256'];pins[str(path)]=entry['sha256']
    assembly=read(delta/'TREE_ASSEMBLY.json')
    assert assembly['schema']=='A165_verified_native_delta_tree_assembly_v1'
    assert sha(base/'INPUT_MANIFEST.json')==assembly['base_input_manifest_sha256']=='d8ca6d465aa3831e26d6d0149b8ce734a1043c51694f81a9ce9b9a4e3baaf965'
    assert sha(base/'BINDINGS.json')==assembly['base_binding_sha256']=='d3c7032b4aeb12649d8d971d0256de95e05dfdcb622ead8a4b6e69ccb633bde2'
    pins[str(base/'INPUT_MANIFEST.json')]=assembly['base_input_manifest_sha256'];pins[str(base/'BINDINGS.json')]=assembly['base_binding_sha256']
    base_inventory=read(base/'INPUT_MANIFEST.json')['files'];manifest=read(delta/'tree/manifest.json')
    assert sha(delta/'tree/manifest.json')==assembly['continued_manifest_sha256']
    assert len(assembly['nodes'])==len(manifest['nodes'])==165
    assert assembly['unchanged_published_payloads']==148 and assembly['included_changed_payloads']==17
    sources=[]
    for number,(item,node)in enumerate(zip(assembly['nodes'],manifest['nodes'])):
        assert item['index']==node['index']==number
        assert item['file']==node['file']==f'node_{number:05d}.json'and item['sha256']==node['sha256']
        if item['source']=='THIS_DELTA':
            source=local(delta,item['member']);assert inventory['files'][item['member']]['sha256']==item['sha256']
        else:
            assert item['source']=='PUBLISHED_A1_ASSEMBLED_PACKET'
            source=local(base,item['member']);assert base_inventory[item['member']]==item['sha256']
        assert sha(source)==item['sha256'];pins[str(source)]=item['sha256'];sources.append((source,item))
    assert sum(item['source']=='THIS_DELTA'for _,item in sources)==17
    output.mkdir(parents=True,exist_ok=False)
    for source,item in sources:
        with (output/item['file']).open('xb')as stream:
            stream.write(source.read_bytes());stream.flush();os.fsync(stream.fileno())
        assert sha(output/item['file'])==item['sha256']
    raw=(delta/'tree/manifest.json').read_bytes()
    with (output/'manifest.json').open('xb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    assert sha(output/'manifest.json')==assembly['continued_manifest_sha256']
    for path,h in pins.items():assert sha(path)==h,path
    receipt=dict(status='PASS_EXACT_A165_NATIVE_DELTA_TREE_ASSEMBLY',nodes=165,included_delta_nodes=17,reused_published_nodes=148,
        manifest_sha256=assembly['continued_manifest_sha256'],delta_input_manifest_sha256=sha(delta/'INPUT_MANIFEST.json'),
        all_source_hashes_unchanged=True,all_outputs_copied_not_shared=True,arithmetic_replayed=False,cold_proof_claimed=False,
        native_source_aliases_still_required_for_arithmetic=True,new_original_cells=0,new_masks=0)
    with (output/'ASSEMBLY_RECEIPT.json').open('x')as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    print(json.dumps(receipt),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--delta',required=True,type=Path);p.add_argument('--a1-packet',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path);a=p.parse_args();run(a.delta,a.a1_packet,a.output)
