#!/usr/bin/env python3
"""Preserve a successful retained-cover continuation without copying its148 old payloads."""
from pathlib import Path
import json,hashlib

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
CODE=WORK/'a165_i64_exact_continuation_v1'
TREE=WORK/'a165_i64_exact_continued_tree_v1'
SOURCE=ROOT/'d_work/A_c744_component3_four_first_use_snapshot'
BASE=Path('/tmp/recovered_a1_packet_064e4aa')
OUT=WORK/'a165_i64_native_continuation_delta_v1'
REPORT=WORK/'A165_I64_EXACT_CONTINUATION_REPLAY_V1.json'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def write(path,value):
    assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')

def main():
    report=read(REPORT)
    assert report['status']=='PASS_A165_I64_COMPLETE_RETAINED_COVER_OPEN'
    assert report['all165_nodes_freshly_replayed']is True
    assert (report['nodes'],report['leaf_domains'],report['excluded_leaves'],report['open_leaves'])==(165,132,118,14)
    assert report['new_original_cells']==report['new_masks']==0
    assert report['historical_A1_and_source_arithmetic_repeated']is False
    assert report['fresh813_source_repeated']is False and report['cold_portable_replay_claimed']is False
    assert sha(BASE/'INPUT_MANIFEST.json')=='d8ca6d465aa3831e26d6d0149b8ce734a1043c51694f81a9ce9b9a4e3baaf965'
    assert sha(BASE/'BINDINGS.json')=='d3c7032b4aeb12649d8d971d0256de95e05dfdcb622ead8a4b6e69ccb633bde2'
    old=read(SOURCE/'manifest.json');new=read(TREE/'manifest.json')
    assert sha(SOURCE/'manifest.json')==report['source_manifest_sha256']
    assert sha(TREE/'manifest.json')==report['continued_manifest_sha256']
    assert not OUT.exists();OUT.mkdir();copies={}
    def copy(source,member):
        source=Path(source).resolve();target=OUT/member
        assert source.is_file()and not source.is_symlink()and not target.exists()
        data=source.read_bytes();h=hashlib.sha256(data).hexdigest()
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        assert sha(source)==sha(target)==h
        copies[str(source)]=dict(member=member,sha256=h,bytes=len(data))
    for path in sorted(CODE.iterdir()):
        if path.is_file():copy(path,'sources/'+path.name)
    copy(TREE/'manifest.json','tree/manifest.json');copy(TREE/'CONSTRUCTION_RECEIPT.json','reports/CONSTRUCTION_RECEIPT.json')
    copy(SOURCE/'manifest.json','SOURCE_MANIFEST.json')
    aliases=read(BASE/'BINDINGS.json')['files'];base_inventory=read(BASE/'INPUT_MANIFEST.json')['files'];nodes=[]
    for before,after in zip(old['nodes'],new['nodes']):
        assert before['index']==after['index']and before['file']==after['file']
        original=SOURCE/before['file'];current=TREE/after['file']
        assert sha(original)==before['sha256']and sha(current)==after['sha256']
        source_alias=aliases[str(original)];assert source_alias['sha256']==before['sha256']
        assert base_inventory[source_alias['path']]==before['sha256']==sha(BASE/source_alias['path'])
        if before['sha256']==after['sha256']:
            nodes.append(dict(index=after['index'],file=after['file'],sha256=after['sha256'],
                source='PUBLISHED_A1_ASSEMBLED_PACKET',member=source_alias['path']))
        else:
            assert after['index']in new['original_i64_leaf_continuation']['changed_open_leaf_indices']
            member='tree/'+after['file'];copy(current,member)
            nodes.append(dict(index=after['index'],file=after['file'],sha256=after['sha256'],source='THIS_DELTA',member=member))
    assert sum(x['source']=='THIS_DELTA'for x in nodes)==17
    for path in(REPORT,Path(report['inherited_complete_arithmetic_report']['path']),
        WORK/'A165_I64_EXACT_CONTINUATION_REPLAY_V1.log',WORK/'A165_I64_CONSTRUCTION_V1.log',
        WORK/'A165_I64_CONSTRUCTION_OBSERVED_EXIT_V1.json',WORK/'A165_I64_FULL_REPLAY_OBSERVED_EXIT_V1.json',
        WORK/'A165_I64_ATTACHMENT_PREPARATION_CONTROLS_V1.json',ROOT/'d_work/A165_I64_CONTINUATION_ROOT_SOURCE_REVIEW.json'):
        copy(path,'reports/'+path.name)
    copy(__file__,'build_native_delta.py')
    copy(WORK/'materialize_a165_delta_tree_v1.py','materialize_tree.py')
    write(OUT/'TREE_ASSEMBLY.json',dict(schema='A165_verified_native_delta_tree_assembly_v1',
        base_input_manifest_sha256=sha(BASE/'INPUT_MANIFEST.json'),base_binding_sha256=sha(BASE/'BINDINGS.json'),
        source_manifest_sha256=sha(SOURCE/'manifest.json'),continued_manifest_sha256=sha(TREE/'manifest.json'),
        nodes=nodes,unchanged_published_payloads=148,included_changed_payloads=17,
        new_original_cells=0,new_masks=0))
    # The complete-source family already records the explicit published A1,
    # fresh813, and original-wide endpoint dependency chain. Keep its exact
    # byte identities here; this delta does not claim a cold proof.
    prior=WORK/'a_c744_original_i64_endpoint_native_v1'
    write(OUT/'DEPENDENCIES.json',dict(schema='A165_native_continuation_dependencies_v1',
        complete_A1_assembled_packet=dict(input_manifest_sha256=sha(BASE/'INPUT_MANIFEST.json'),binding_sha256=sha(BASE/'BINDINGS.json'),
            publication='research/nine/computer_assisted/a2_00100_a_c744_complete_a1_portable_checkpoint_v2'),
        whole_original_I64_endpoint_packet=dict(input_manifest_sha256=sha(prior/'INPUT_MANIFEST.json'),
            native_packet_folder=str(prior),dependency_map_sha256=sha(prior/'DEPENDENCIES.json')),
        source_code_freeze=dict(member='sources/SOURCE_BINDINGS.json',sha256=sha(CODE/'SOURCE_BINDINGS.json')),
        historical_source_identity_reuse_explicit=True,full_cold_replay_claimed=False,
        unchanged_native_aliases_required_for_arithmetic=True,new_original_cells=0,new_masks=0))
    copy(prior/'DEPENDENCIES.json','I64_ENDPOINT_DEPENDENCIES.json')
    (OUT/'README.md').write_text('''# Retained A165 cover: exact I64 leaf continuation

The full165-node consumer was independently replayed. It retains the old
component3 domain yB+yD-2yI<=-3/5, every original initial state, all old rounds,
and every4/8/2 alternative. Original-wide necessary I64 endpoint rows were used
in ordinary exact rounds on retained OPEN leaves. No LP or new split ran.

All17 old OPEN payloads changed;148 other payloads remain byte-identical.
The complete retained cover now has118 excluded leaves and14 OPEN leaves.
The new zero-round existing-geometry exclusions are155,158,160. The original
and mask remain OPEN, and this checkpoint awards no new cell or mask credit.

This delta includes the complete new manifest, the17 changed payloads, source
adapter/attachment checks, full fresh consumer report and inherited report,
actual execution logs, source review and prefix controls. TREE_ASSEMBLY.json
maps each of the148 omitted payloads to its exact published assembled A1
packet member. It also identifies every included changed payload.

Historical A1/complement source proofs and the separately published fresh813
source are explicitly reused by identity; their arithmetic was not repeated.
All165 consumer records, terminals and complete covers were freshly checked.
The result is native exact evidence, not a cold self-contained proof. Exact
native source aliases listed by the source freeze are needed to rerun it.

The original source and all candidate/current manifests are immutable. A
future continuation must preserve this complete cover and all current OPEN
siblings. No lost235-node or later vanished numerical suffix is claimed.
''')
    write(OUT/'COPY_PROVENANCE.json',dict(schema='exact_A165_delta_publication_copies_v1',sources=copies))
    files={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(OUT.rglob('*'))if p.is_file()}
    write(OUT/'INPUT_MANIFEST.json',dict(schema='A165_native_exact_continuation_delta_v1',files=files,new_original_cells=0,new_masks=0))
    print(json.dumps(dict(folder=str(OUT),input_manifest_sha256=sha(OUT/'INPUT_MANIFEST.json'),files=len(files)+1,
        total_bytes=sum(v['bytes']for v in files.values())+(OUT/'INPUT_MANIFEST.json').stat().st_size,
        changed_payloads=17,reused_published_payloads=148,remaining_open_leaves=14)),flush=True)

if __name__=='__main__':main()
