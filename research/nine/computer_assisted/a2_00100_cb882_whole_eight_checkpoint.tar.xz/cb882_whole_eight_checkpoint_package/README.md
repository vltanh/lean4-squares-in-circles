# Cb882 exact first-pass checkpoint

Run `python -B -S verify_all.py` in this directory.

The exact result is two excluded height domains and six certified OPEN
states of the same whole original. This packet closes no original or mask.
`HAND_PROOF.md` gives the physical reduction and exact contradictions;
`COVER_TABLE.json` binds every one of the eight required domains.
The full shared theorem packets and all original ancestry are included.
