#!/usr/bin/env python3
"""Fresh portable replay of the CB882 two-excluded/six-OPEN whole-eight checkpoint."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import importlib
import json
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
CORE_SHA='96e8353f02eff5fb4fd32dc8b05c7c07578863207206b56cf46bf953afd16845'
COMPONENT_SHA='53313a8e79b32bcf4b035c9e57b9f5a7df091ae6fe9762ba33058e6892865ba0'
TABLE_SHA='b98dd915ca1a3c85da9554960ac014493b886a40cd432d5962e89eda27515ca1'
HAND_SHA='14fc29b95bab66ebaea4926e264426a42706d26d668a49fa047a02a185deecf8'
PHYSICAL_SHA='08e8da63655a39df7bf2a922d6d19dd80dccd9bbdc1dd78bb496bc22632656de'
FIRST_REPLAY_SHA='365fad3113460e83967da29c445dbbbdb1b975bcdd917c363fdd2b3b5dfca809'
digest=lambda p:sha256(Path(p).read_bytes()).hexdigest()


def descriptor(child):
    r=child['bound_report']
    return dict(branch=child['branch'],signs=child['signs'],row=child['row'],status=child['status'],
        certificate_sha256=r['certificate_sha256'],rounds=r['bound_rounds'],
        deductions=r['bound_deductions'],premise_rows=r['printed_rows_checked']-r['terminal_rows'],
        terminal_rows=r['terminal_rows'],reserve=r['reserve'],terminal_kind=r['terminal_kind'],
        terminal_label=r['terminal_label'],terminal_evidence=r['terminal_evidence'],
        three_square_rows=r['independently_rebuilt_three_square_energy_rows'],
        conditional_rows=r['independently_rebuilt_conditional_sharp_rows'])


def check_table(report,manifest):
    assert digest(HERE/'COVER_TABLE.json')==TABLE_SHA
    assert digest(HERE/'HAND_PROOF.md')==HAND_SHA
    assert digest(HERE/'PHYSICAL_THEOREM_DEPENDENCIES.json')==PHYSICAL_SHA
    table=json.loads((HERE/'COVER_TABLE.json').read_text())
    assert table['schema']=='CB882_first_pass_whole_eight_height_checkpoint_table_v1'
    assert table['source_report']==dict(packet_path='review_inputs/FIRST_PASS_EXACT_REPLAY.json',sha256=FIRST_REPLAY_SHA)
    first_path=HERE/table['source_report']['packet_path']
    assert digest(first_path)==FIRST_REPLAY_SHA
    first=json.loads(first_path.read_text())
    assert report['status']==first['status']=='PASS_DECLARED_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_WITH_OPEN_DOMAINS'
    for key in ('original_prefix_sha256','cover_sha256'):
        assert table[key]==report[key]==first[key]
    assert table['original_id']==report['id']==first['id']
    assert table['original_path']==report['original_parent_path']==first['original_parent_path']
    assert table['physical_parent_state_sha256']==report['whole_original_physical_state_sha256']==first['whole_original_physical_state_sha256']
    assert table['whole_parent_prerequisites']==report['whole_original_prerequisites']==first['whole_original_prerequisites']
    assert table['specification_sha256']==report['cover_specification_sha256']==first['cover_specification_sha256']
    assert table['members']==[descriptor(c)for c in report['child_reports']]==[descriptor(c)for c in first['child_reports']]
    assert [r['branch']for r in table['members']]==list(range(8))
    assert table['excluded_domains']==[4,7]
    assert table['open_domains']==report['open_domain_indices']==[0,1,2,3,5,6]
    assert report['conditional_terminals']==2 and report['open_domains']==6
    assert report['complete_domain_union_checked']and report['closed_faces_retained']
    assert report['earlier_sibling_complements_added']is False and report['center_subdivisions']==0
    assert table['closed_faces_retained']is True
    assert table['common_parent']==dict(rounds=5,deductions=386,premise_rows=1073,earlier_coordinate_deductions=30)
    old=report['parent_exact_replay']['prior_report']
    assert old['rounds']==5 and old['new_deductions']==386 and old['printed_rows_checked']==1073
    assert old['prior_coordinate_deductions']==report['earlier_coordinate_deductions']==30
    assert report['common_whole_parent_counted_once']is True
    assert report['total_bound_rounds_including_common_parent']==25
    assert report['total_bound_deductions_including_common_parent']==3392
    totals=dict(rounds=sum(r['rounds']for r in table['members']),
        deductions=sum(r['deductions']for r in table['members']),
        premise_rows=sum(r['premise_rows']for r in table['members']),
        terminal_rows=sum(r['terminal_rows']for r in table['members']),
        three_square_row_occurrences=sum(r['three_square_rows']for r in table['members']),
        selected_height_row_occurrences=sum(r['conditional_rows']for r in table['members']))
    assert table['local_totals']==totals==dict(rounds=20,deductions=3006,premise_rows=5018,
        terminal_rows=21,three_square_row_occurrences=12,selected_height_row_occurrences=20)
    assert report['local_bound_rounds']==20 and report['local_bound_deductions']==3006
    assert report['local_bound_premise_rows']==5018 and report['terminal_rows']==21
    assert table['positive_reserve_floor']=={'7':'1/2048'}
    assert F(table['members'][7]['reserve'])>F(1,2048)
    evidence=table['members'][4]['terminal_evidence']
    assert evidence['pair']==[1,7]and len(evidence['four_original_inset_alternatives_rejected_directly'])==4
    for case in evidence['four_original_inset_alternatives_rejected_directly']:
        assert F(case['inset_halfwidth_sum_lower'])-F(case['signed_center_gap_upper'])==F(case['strict_gap_deficit'])>0
    assert report['checker_sha256']==CORE_SHA and report['component_checker_sha256']==COMPONENT_SHA
    assert report['all_earlier_sibling_theorem_and_ancestor_bytes_rehashed']is True
    assert report['strict_portable_root_used']is True
    for key in ('whole_original_cover_checked','complete_eight_height_cover_checked'):
        assert report[key]is False
    assert table['whole_original_closed']is False
    assert table['new_original_cells']==table['new_masks']==report['new_original_cells']==report['new_masks']==0

    physical=json.loads((HERE/'PHYSICAL_THEOREM_DEPENDENCIES.json').read_text())
    assert physical['schema']=='CB882_checkpoint_used_physical_theorems_v1'
    for name,expected in physical['theorem_text_and_review_sha256'].items():
        relative=Path(name);assert not relative.is_absolute()and '..'not in relative.parts
        assert manifest['files'][name]==expected==digest(HERE/name)
    inventory=[]
    for member in table['members']:
        path=HERE/'data'/('branch_%02d.json'%member['branch'])
        assert digest(path)==member['certificate_sha256']
        raw=json.loads(path.read_text())
        groups=[rr['printed_rows']for rr in raw['rounds']]
        if raw.get('terminal',{}).get('kind')=='positive_exact_reserve':groups.append(raw['terminal']['printed_rows'])
        for group in groups:
            for row in group:
                if row['name'].startswith(('three_square_center_energy_','planar_four_center_','square_area_')):
                    inventory.append(dict(branch=member['branch'],name=row['name'],coefficients=row['coefficients'],rhs=row['rhs']))
    assert physical['selected_local_energy_row_occurrences']==inventory
    assert len(inventory)==physical['three_square_occurrences']==12
    assert all(r['name'].startswith('three_square_center_energy_')for r in inventory)
    assert physical['four_center_occurrences']==physical['square_area_occurrences']==0
    assert physical['fresh_replay_required']==['opposite_tilt_theorem/verify_all.py','energy_proof/verify_all.py']
    return table,physical


def main():
    assert __debug__
    start=time.monotonic();manifest_path=HERE/'SHA256_MANIFEST.json'
    manifest_bytes=manifest_path.read_bytes();manifest=json.loads(manifest_bytes)

    def unchanged():
        assert manifest_path.read_bytes()==manifest_bytes
        for name,expected in manifest['files'].items():
            relative=Path(name);assert not relative.is_absolute()and '..'not in relative.parts
            path=(HERE/relative).resolve();assert path.is_relative_to(HERE)
            assert digest(path)==expected,('changed_input',name)

    unchanged()
    assert manifest['files']['verify_all.py']==digest(__file__)
    assert digest(HERE/'verify_cb882_whole_eight_height_cover.py')==CORE_SHA
    assert digest(HERE/'verify_cb882_whole_opposite_tilt_height_bounds.py')==COMPONENT_SHA
    with (HERE/'ENERGY_THEOREM_AND_ROWS_REPLAY.log').open('w')as stream:
        subprocess.run([sys.executable,'-B','-S',str(HERE/'energy_proof/verify_all.py')],
            cwd=HERE,stdout=stream,stderr=subprocess.STDOUT,check=True)
    energy=json.loads((HERE/'energy_proof/COMPLETE_REPLAY.json').read_text())
    assert energy['status']=='PASS_SHARED_THREE_SQUARE_ENERGY_ROWS'
    assert energy['energy_lower_bound']=='7/2'and energy['exact_geometric_evaluators']==2
    assert energy['row_identities_checked']==1877 and energy['new_original_cells']==energy['new_masks']==0
    unchanged()
    core=importlib.import_module('verify_cb882_whole_eight_height_cover')
    assert Path(core.__file__).resolve()==HERE/'verify_cb882_whole_eight_height_cover.py'
    checker=core.WholeCoverChecker(HERE,HERE/'ancestry',HERE)
    report=checker.replay(HERE/'EIGHT_HEIGHT_DOMAINS.json',allow_partial=True)
    table,physical=check_table(report,manifest)
    checker.recheck();unchanged()
    modules={}
    for name,module in sorted(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename and Path(filename).resolve().is_relative_to('/workspace'):
            path=Path(filename).resolve();assert path.is_relative_to(HERE),('external_module',name,str(path))
            modules[name]=str(path.relative_to(HERE))
    assert not any(name in sys.modules for name in('numpy','scipy','highspy','v3_whole_parent_pass','quadratic_moment_pilot','three_square_energy_rows'))
    unchanged()
    result=dict(schema='portable_CB882_whole_eight_height_checkpoint_replay_v1',
        status='PASS_PORTABLE_CB882_WHOLE_EIGHT_CHECKPOINT_WITH_SIX_OPEN_DOMAINS',
        original_id=report['id'],original_prefix_sha256=report['original_prefix_sha256'],
        conditional_domains=8,excluded_domains=[4,7],open_domains=[0,1,2,3,5,6],
        local_bound_rounds=20,local_bound_deductions=3006,local_bound_premise_rows=5018,terminal_rows=21,
        common_parent_counted_once=True,common_parent_rounds=5,common_parent_deductions=386,
        common_parent_premise_rows=1073,earlier_coordinate_deductions=30,
        exact_full_angle_scalar_domains=80,exact_full_angle_scalar_leaves=1405,
        exact_full_angle_coefficient_checks=878125,exact_energy_geometric_evaluators=2,
        exact_energy_row_identities=1877,used_three_square_row_occurrences=12,
        hand_proof_sha256=HAND_SHA,cover_table_sha256=TABLE_SHA,physical_dependency_sha256=PHYSICAL_SHA,
        frozen_input_count=len(manifest['files']),source_manifest_sha256=sha256(manifest_bytes).hexdigest(),
        complete_table_checked=True,all_frozen_inputs_rehashed_after_replay=True,
        all_workspace_reads_confined_to_packet=True,local_module_import_audit=modules,
        complete_eight_height_cover_proved=False,whole_original_closed=False,
        new_original_cells=0,new_masks=0,lean_lake_ci_run=False,
        cover_replay=report,seconds=time.monotonic()-start)
    (HERE/'COMPLETE_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('cover_replay','local_module_import_audit')},indent=2))
    return result


if __name__=='__main__':main()
