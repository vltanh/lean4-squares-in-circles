#!/usr/bin/env python3
"""Portable exact C887 sharp foundation; fifteen failures remain explicitly open."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OMITTED_RUNTIME_FIELDS = {'seconds', 'source_sha256', 'checker_dependency_sha256'}
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def mathematical_content(value):
    if isinstance(value, dict):
        return {key: mathematical_content(item) for key, item in value.items()
                if key not in OMITTED_RUNTIME_FIELDS}
    if isinstance(value, list):
        return [mathematical_content(item) for item in value]
    return value


def main():
    assert __debug__
    started = time.monotonic()
    manifest_bytes = (HERE / 'SHA256_MANIFEST.json').read_bytes()
    manifest = json.loads(manifest_bytes)

    def unchanged():
        assert (HERE / 'SHA256_MANIFEST.json').read_bytes() == manifest_bytes
        for name, expected in manifest['files'].items():
            path = (HERE / name).resolve()
            assert path.is_relative_to(HERE) and digest(path) == expected, name

    unchanged()
    binding_path = HERE / 'review_inputs/PORTABLE_BINDINGS.json'
    assert digest(binding_path) == 'f882b93874017a731677dea80153e1ad8e6af86f9eb76333afdd5f634d9b16c1'
    binding = json.loads(binding_path.read_text())
    assert binding['status'] == 'FROZEN_PORTABLE_CORE_WITH_FIFTEEN_OPEN_FAILURES'
    core_path = HERE / 'review_inputs/PORTABLE_CORE_INVENTORY.json'
    assert digest(core_path) == binding['reviewed_core_inventory']['sha256']
    core = json.loads(core_path.read_text())
    assert core['files'] == binding['core_file_sha256'] and len(core['files']) == 179
    for name, expected in core['files'].items():
        assert manifest['files'][name] == expected and digest(HERE / name) == expected
    for supplement in binding['supplementary_inputs_to_copy_unchanged']:
        path = (HERE / supplement['packet_path']).resolve()
        assert path.is_relative_to(HERE) and digest(path) == supplement['sha256']
    assert digest(HERE / 'FOUNDATION_HAND_PROOF.md') == binding['hand_proof']['sha256']
    portable_review = json.loads((HERE / 'review_inputs/PORTABLE_REVIEW.json').read_text())
    assert portable_review['status'] == 'PASS_STRICT_PORTABLE_IDENTITY_AND_COMPLETE_EVIDENCE_RETENTION'
    assert portable_review['portable_binding_sha256'] == digest(binding_path)
    assert portable_review['revised_hand_proof_sha256'] == digest(HERE / 'FOUNDATION_HAND_PROOF.md')
    for key in ('complete_fixed_tiles', 'new_original_cells', 'new_masks'):
        assert binding[key] == portable_review[key] == 0
    source_review = json.loads((HERE / binding['accepted_source_review']['packet_path']).read_text())
    assert source_review['status'] == 'PASS_SOURCE_COVERAGE_AND_ATTACHMENT_GATES'
    assert source_review['component_sha256'] == digest(HERE / 'verify_cd_sharp_complement_bounds_v2.py')
    assert source_review['cover_checker_sha256'] == digest(HERE / 'verify_CD_sharp_cover.py')

    with (HERE / 'ENERGY_THEOREM_AND_ROWS_REPLAY.log').open('w') as stream:
        subprocess.run([sys.executable, '-B', '-S', str(HERE / 'energy_proof/verify_all.py')],
                       cwd=HERE, stdout=stream, stderr=subprocess.STDOUT, check=True)
    energy = json.loads((HERE / 'energy_proof/COMPLETE_REPLAY.json').read_text())
    assert energy['status'] == 'PASS_SHARED_THREE_SQUARE_ENERGY_ROWS'
    assert energy['energy_lower_bound'] == '7/2'
    assert energy['exact_geometric_evaluators'] == 2 and energy['row_identities_checked'] == 1877
    assert energy['new_original_cells'] == energy['new_masks'] == 0
    unchanged()

    from verify_CD_sharp_cover import SharpCoverChecker
    checker = SharpCoverChecker(context=HERE, ancestry=HERE / 'ancestry', strict_root=HERE)
    report = checker.replay(HERE / 'DECLARED_TWENTY_DOMAIN_COVER.json', allow_partial=True)
    checker.recheck()
    assert report['status'] == 'PASS_DECLARED_SHARP_COVER_WITH_OPEN_FAILURES'
    assert report['complete_closed_guard_failures'] == 20
    assert report['interval_failure_domains'] == 5 and report['open_failure_domains'] == 15
    assert report['open_failure_indices'] == binding['open_indices']
    assert report['bound_terminal_failure_domains'] == report['nested_complete_failure_domains'] == 0
    assert report['bound_deductions'] == 506 and report['bound_premise_rows'] == 1601
    assert report['terminal_rows'] == report['complete_fixed_tiles'] == 0
    assert report['complete_twenty_failure_cover_checked'] is False
    assert report['new_original_cells'] == report['new_masks'] == 0
    normalized = hashlib.sha256(json.dumps(mathematical_content(report), sort_keys=True,
                               separators=(',', ':')).encode()).hexdigest()
    assert normalized == binding['mathematical_report_normal_form_sha256']
    assert binding['omitted_report_fields_only'] == sorted(OMITTED_RUNTIME_FIELDS)
    module_audit = {}
    for name, module in sorted(sys.modules.items()):
        origin = getattr(module, '__file__', None)
        if origin:
            origin = Path(origin).resolve()
            if origin.is_relative_to('/workspace'):
                assert origin.is_relative_to(HERE), ('external module', name, str(origin))
                module_audit[name] = str(origin.relative_to(HERE))
    assert not any(name in sys.modules for name in
                   ('numpy', 'scipy', 'highspy', 'quadratic_moment_pilot',
                    'v3_whole_parent_pass', 'three_square_energy_rows'))
    unchanged()
    result = dict(schema='portable_C887_sharp_foundation_replay_v1',
        status='PASS_PORTABLE_SHARP_FOUNDATION_WITH_FIFTEEN_OPEN_FAILURES',
        id='negative-887236b78100baf3', original_I_tile=[2, 1],
        complete_closed_complement_declarations=20, strict_interval_exclusions=5,
        independently_replayed_open_conditional_states=15,
        common_six_round_deductions_counted_once=506,
        common_six_round_premise_rows_counted_once=1601,
        accepted_physical_sharp_region_retained=True,
        physical_three_square_energy_theorem_replayed=True,
        independent_geometric_evaluators=2, exact_energy_row_identities_replayed=1877,
        hand_table_sha256=digest(HERE / 'FOUNDATION_HAND_PROOF.md'),
        reviewed_core_files=179, frozen_input_files=len(manifest['files']),
        source_manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
        mathematical_report_normal_form_sha256=normalized,
        all_frozen_inputs_rehashed_after_replay=True,
        all_workspace_reads_confined_to_packet=True, local_module_import_audit=module_audit,
        complete_twenty_failure_cover_proved=False, complete_fixed_tiles=0,
        whole_original_cover_checked=False, new_original_cells=0, new_masks=0,
        lean_lake_ci_run=False, cover_replay=report, seconds=time.monotonic() - started)
    (HERE / 'FOUNDATION_REPLAY.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                     if key not in ('cover_replay', 'local_module_import_audit')}, indent=2))
    return result


if __name__ == '__main__':
    main()
