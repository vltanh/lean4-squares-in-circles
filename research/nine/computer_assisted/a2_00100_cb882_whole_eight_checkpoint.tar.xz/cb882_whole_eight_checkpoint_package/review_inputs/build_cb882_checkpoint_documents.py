#!/usr/bin/env python3
"""Prepare source-bound hand/table documents for the proved first-pass checkpoint."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json

HERE=Path(__file__).resolve().parent
BASE=HERE/'cb882_whole_eight_fast3_replay_package'
OUT=HERE/'cb882_checkpoint_documents'
REPORT=BASE/'CB882_WHOLE_EIGHT_FAST3_EXACT_REPLAY.json'
digest=lambda p:sha256(Path(p).read_bytes()).hexdigest()


def descriptor(child):
    r=child['bound_report']
    return dict(branch=child['branch'],signs=child['signs'],row=child['row'],status=child['status'],
        certificate_sha256=r['certificate_sha256'],rounds=r['bound_rounds'],
        deductions=r['bound_deductions'],premise_rows=r['printed_rows_checked']-r['terminal_rows'],
        terminal_rows=r['terminal_rows'],reserve=r['reserve'],terminal_kind=r['terminal_kind'],
        terminal_label=r['terminal_label'],terminal_evidence=r['terminal_evidence'],
        three_square_rows=r['independently_rebuilt_three_square_energy_rows'],
        conditional_rows=r['independently_rebuilt_conditional_sharp_rows'])


def main():
    assert not OUT.exists()
    assert digest(REPORT)=='365fad3113460e83967da29c445dbbbdb1b975bcdd917c363fdd2b3b5dfca809'
    report=json.loads(REPORT.read_text());OUT.mkdir()
    rows=[descriptor(c)for c in report['child_reports']]
    assert len(rows)==8 and [r['branch']for r in rows]==list(range(8))
    assert report['open_domain_indices']==[0,1,2,3,5,6]
    assert F(rows[7]['reserve'])>F(1,2048)
    table=dict(schema='CB882_first_pass_whole_eight_height_checkpoint_table_v1',
        original_id=report['id'],original_path=report['original_parent_path'],
        original_prefix_sha256=report['original_prefix_sha256'],
        physical_parent_state_sha256=report['whole_original_physical_state_sha256'],
        whole_parent_prerequisites=report['whole_original_prerequisites'],
        source_report=dict(packet_path='review_inputs/FIRST_PASS_EXACT_REPLAY.json',sha256=digest(REPORT)),
        cover_sha256=report['cover_sha256'],specification_sha256=report['cover_specification_sha256'],
        members=rows,positive_reserve_floor={'7':'1/2048'},excluded_domains=[4,7],
        open_domains=report['open_domain_indices'],closed_faces_retained=True,
        common_parent=dict(rounds=5,deductions=386,premise_rows=1073,earlier_coordinate_deductions=30),
        local_totals=dict(rounds=20,deductions=3006,premise_rows=5018,terminal_rows=21,
                          three_square_row_occurrences=sum(r['three_square_rows']for r in rows),
                          selected_height_row_occurrences=sum(r['conditional_rows']for r in rows)),
        whole_original_closed=False,new_original_cells=0,new_masks=0)
    (OUT/'COVER_TABLE.json').write_text(json.dumps(table,indent=2)+'\n')
    inventory=[]
    for member in rows:
        raw=json.loads((BASE/'data'/('branch_%02d.json'%member['branch'])).read_text())
        groups=[rr['printed_rows']for rr in raw['rounds']]
        if raw.get('terminal',{}).get('kind')=='positive_exact_reserve':groups.append(raw['terminal']['printed_rows'])
        for group in groups:
            for row in group:
                if row['name'].startswith(('three_square_center_energy_','planar_four_center_','square_area_')):
                    inventory.append(dict(branch=member['branch'],name=row['name'],
                        coefficients=row['coefficients'],rhs=row['rhs']))
    assert len(inventory)==12 and all(e['name'].startswith('three_square_center_energy_')for e in inventory)
    original_manifest=json.loads((BASE/'SHA256_MANIFEST.json').read_text())
    dependencies={name:expected for name,expected in original_manifest['files'].items()
        if name.startswith(('ancestry/hand_premises/','hand_inputs/'))and name.endswith('.md')}
    for name in ('opposite_tilt_theorem/HAND_PROOF.md','opposite_tilt_theorem/ROOT_INDEPENDENT_REVIEW.md',
                 'energy_proof/theorem/global_theorem/THREE_SQUARE_CENTER_ENERGY_HAND_PROOF.md',
                 'energy_proof/theorem/a_family/THREE_SQUARE_CENTER_ENERGY_INDEPENDENT_REVIEW.md',
                 'energy_proof/THREE_SQUARE_ENERGY_ROW_REVIEW.md'):
        dependencies[name]=original_manifest['files'][name]
    physical=dict(schema='CB882_checkpoint_used_physical_theorems_v1',
        theorem_text_and_review_sha256=dependencies,
        selected_local_energy_row_occurrences=inventory,three_square_occurrences=12,
        four_center_occurrences=0,square_area_occurrences=0,
        fresh_replay_required=['opposite_tilt_theorem/verify_all.py','energy_proof/verify_all.py'],
        preserved_original_caller='all nine original unit squares; strict weak CD; q<Q',
        new_original_cells=0,new_masks=0)
    (OUT/'PHYSICAL_THEOREM_DEPENDENCIES.json').write_text(json.dumps(physical,indent=2)+'\n')
    forms=['−y_A+y_D','−y_A−y_D+2y_I','−y_A+y_D+2y_H−2y_I','−y_A−y_D+2y_H',
           'y_A+y_D−2y_H','y_A−y_D−2y_H+2y_I','y_A+y_D−2y_I','y_A−y_D']
    lines=[]
    for r,form in zip(rows,forms):
        status='Excluded: inset contradiction'if r['branch']==4 else 'Excluded: positive reserve'if r['branch']==7 else 'OPEN, certified state'
        lines.append(f"| {r['branch']} | ${form}$ | {status} | {r['rounds']} | {r['deductions']} | {r['premise_rows']} | {r['terminal_rows']} |")
    hand=rf'''# Cb882 whole-original eight-height checkpoint

## Exact result and remaining obligation

This packet proves that two of the eight necessary height domains of original
`negative-b882d8ade0cf9ea0` are empty. Domains **4 and 7 are excluded**;
domains **0, 1, 2, 3, 5 and 6 remain OPEN** with independently proved three-round
bound states. This is a complete declaration and exact replay of the necessary
eight-domain union, not a completed exclusion of the original. It earns
**zero original cells and zero masks**. No center or additional angle cut is
introduced, and no earlier sibling's failure is added to a later sibling.

The source report is `review_inputs/FIRST_PASS_EXACT_REPLAY.json`, SHA256
`{digest(REPORT)}`. The machine-readable table binds every certificate hash,
literal halfspace, count, terminal witness and reserve below to that report.

## Unchanged physical caller

All nine original unit squares remain physical, with disjoint interiors in a
disk of squared radius $q<Q=1105/256$. The original strict weak C–D condition
is retained. Its immutable path is
`angle(3,0); angle_cut([0,0],1); alternate_four_escape([1,7],[3])`.
The zero-round whole-original diagonal wrapper has SHA256
`{report['original_prefix_sha256']}`. It wraps the same five-round whole
ancestor, with 386 proved deductions and 1,073 printed premise rows, plus
30 earlier coordinate deductions. The exact checker replays that common
ancestor once; it never treats a discovery status or a saved interval as an
axiom. No I/H grid, tile rectangle or inherited extra angle partition appears
in this caller.

The replayed whole state gives the endpoint slope intervals
$t_A\in[0,21144313723523/140737488355328]$ and $t_D\in[-1,0]$.
The original-center orders already follow with exact lower bounds

$$x_H-x_A\ge35461/524288,\qquad x_I-x_H\ge0,\qquad
x_D-x_I\ge434432029724121/5000000000000000.$$

The weak H/I equality face is retained. These are whole-original facts,
not properties obtained by imposing a convenient center tile.

## Why the eight closed domains cover every possible survivor

The full-angle opposite-endpoint theorem, included verbatim in
`opposite_tilt_theorem/HAND_PROOF.md`, applies to the physical row A,H,I,D
and the actual E,F,G row. Its sign and weak-order hypotheses are exactly the
facts just displayed. It says that total variation

$$V=|y_H-y_A|+|y_I-y_H|+|y_D-y_I|\le23/100$$

forces $q\ge Q$. The accepted equality argument also retains the original
strict weak C–D caller. Thus every physical counterexample in this original
must satisfy $V>23/100$. The maximum of the eight signed sums of the three
successive height differences equals $V$. Therefore at least one signed sum
is at least $23/100$. Negating each sum gives the eight closed inequalities
in the table, each with right side **$-23/100$**. Their overlaps and touching
faces cause no loss of coverage. They are independent restrictions of the
same complete original, and their union is the full remaining obligation.

The wrapper freshly replays the theorem's 101 immutable inputs, all 80
scalar domains, 1,405 leaves and 878,125 exact coefficient checks. It also
checks the original endpoint signs and all three orders again from the
independently reconstructed whole state.

## Exhaustive literal table

| Domain | Left side, with right side $-23/100$ | Exact status | Rounds | Deductions | Premise rows | Terminal rows |
|---:|---|---|---:|---:|---:|---:|
{chr(10).join(lines)}

The local totals are **20 rounds, 3,006 deductions, 5,018 premise rows and
21 terminal rows**. Including the common five-round ancestor once gives
25 rounds and 3,392 deductions, with the 30 earlier coordinate deductions
recorded separately. Repeated replay for assurance is not counted as new
mathematical work. The six OPEN states retain every inherited Cartesian,
frame, scalar, difference and correlated-diagonal bound and contain no
unstated positive clearance assumption.

## The two exact exclusions

Domain 4 ends after one bound round with a physical B/H inset contradiction.
Each original square contains its axis-aligned central inset square.
Disjoint interiors require one of the four signed Cartesian center gaps to
be at least the sum of those two inset halfwidths. The independently derived
lower halfwidth sum is $114592626572919/140737488355328$.
The upper signed x gaps are $1640851/3932160$ and $27755/65536$;
both signed y gaps have upper bound $655061/1048576$. Every upper bound is
strictly smaller than the lower halfwidth sum. The four positive exact
deficits are retained in `COVER_TABLE.json`; the checker reconstructs them
from the proved state rather than accepting the terminal's text.

Domain 7 ends after one bound round with a 21-row nonnegative rational
combination. Its corrected reserve is

$$\frac{{{F(rows[7]['reserve']).numerator}}}{{{F(rows[7]['reserve']).denominator}}}>\frac1{{2048}}>0.$$

The checker independently reconstructs every used physical affine row,
forms the weighted sum over the same 54 original variables, and pays the
entire residual coefficient vector with proved absolute variable bounds.
The strictly positive remaining reserve contradicts the selected domain.
No floating-point LP or numerical positive-semidefinite assertion is used
as proof.

## Physical row scope and independent arithmetic

Each local deduction is a nonnegative exact combination of valid rows,
followed by a rational residual payment and exact bound intersection.
The original unit-frame identities then narrow the original angle
intervals; no original frame or square is replaced. The selected height
row is permitted only in its matching domain. All declared source hashes,
all earlier sibling dependencies and every frozen input are rechecked
through final assembly.

Twelve used local rows invoke the accepted three-square center-energy
lower bound $7/2$. The packet includes the complete geometric proof, both
independent exact geometric evaluators, the literal 128-triangle table,
the row-conversion proof and its independent review. The wrapper freshly
replays both evaluators and all 1,877 row identities. The local printed
proofs use no four-center energy or square-area row. The exact used-row
inventory and the complete retained original physical hand premises are
listed in `PHYSICAL_THEOREM_DEPENDENCIES.json`.

## Reproduction and permitted conclusion

Run `python -B -S verify_all.py` from the extracted packet. The wrapper
first verifies the frozen inventory, freshly replays the two shared
theorem packets, replays the whole ancestor and all eight conditional
certificates, compares the complete hand table with fresh exact results,
and rehashes every input before writing `COMPLETE_REPLAY.json`.
All project reads and imported project modules are confined to the packet.
No Lean, Lake or CI execution is used.

The only accepted final conclusion is the necessary eight-domain cover
with domains 4 and 7 excluded and six explicitly certified OPEN states.
Further continuations belong to separate source-bound records and are
not premises of this immutable first-pass checkpoint.
'''
    (OUT/'HAND_PROOF.md').write_text(hand)
    (OUT/'README.md').write_text('''# Cb882 exact first-pass checkpoint

Run `python -B -S verify_all.py` in this directory.

The exact result is two excluded height domains and six certified OPEN
states of the same whole original. This packet closes no original or mask.
`HAND_PROOF.md` gives the physical reduction and exact contradictions;
`COVER_TABLE.json` binds every one of the eight required domains.
The full shared theorem packets and all original ancestry are included.
''')
    print(json.dumps({p.name:digest(p)for p in sorted(OUT.iterdir())},indent=2))


if __name__=='__main__':main()
