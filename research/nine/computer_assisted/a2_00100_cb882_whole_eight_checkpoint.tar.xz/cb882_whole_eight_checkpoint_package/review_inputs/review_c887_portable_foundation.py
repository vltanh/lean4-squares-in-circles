#!/usr/bin/env python3
"""Bind the strict portable C887 foundation, without the broad local inventory."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PACKET = ROOT / 'c887_sharp_foundation_package'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
SNAPSHOT_SHA = 'b378f9bb26f5733cf07eb88f017037da8cae9432a0a7b579f0f0053379da4add'
STRICT_SHA = '150de45f9edb59a3a0c9c20a7c12b2ce7134c2bed76774e89db52d0ad1c41a58'
LOCAL_SHA = '7aa33d74bd01d44f319fa9f8c27ad4d24a67ce3d6953e36d1acd1da41bfae25e'
SOURCE_REVIEW_SHA = 'fe6e2fb0d98de0b2553b9f7753fdfdc78a3e969b6a6f7dfab927f516c9d6f7b6'
OLD_HAND_SHA = '7882d9c33036e426d1d5ae287553c9386168013bd460b8914f2d33ed43628a2e'

snapshot = HERE / 'C887_I21_SHARP_FOUNDATION_PORTABLE_CORE_INVENTORY.json'
if not snapshot.exists():
    assert sha(PACKET / 'SHA256_MANIFEST.json') == SNAPSHOT_SHA
    snapshot.write_bytes((PACKET / 'SHA256_MANIFEST.json').read_bytes())
assert sha(snapshot) == SNAPSHOT_SHA
files = read(snapshot)['files']
assert len(files) == 179
for name, h in files.items():
    path = (PACKET / name).resolve()
    assert path.is_relative_to(PACKET) and sha(path) == h, name
strict_path = PACKET / 'STRICT_FOUNDATION_REPLAY.json'
local_path = PACKET / 'accepted_reports/C887_I21_COMPLETE_SHARP_SCREEN_REPLAY.json'
source_review_path = PACKET / 'review_inputs/C887_SHARP_COMPONENT_AND_COMPLETE_COVER_SOURCE_REVIEW.json'
assert sha(strict_path) == STRICT_SHA and sha(local_path) == LOCAL_SHA
assert sha(source_review_path) == SOURCE_REVIEW_SHA
strict, local, source_review = read(strict_path), read(local_path), read(source_review_path)

OMITTED_RUNTIME_FIELDS = {'seconds', 'source_sha256', 'checker_dependency_sha256'}
def mathematical_content(value):
    if isinstance(value, list):
        return [mathematical_content(x) for x in value]
    if isinstance(value, dict):
        return {k: mathematical_content(x) for k, x in value.items() if k not in OMITTED_RUNTIME_FIELDS}
    return value
assert mathematical_content(strict) == mathematical_content(local)
normalized_hash = hashlib.sha256(json.dumps(mathematical_content(strict), sort_keys=True, separators=(',', ':')).encode()).hexdigest()
portable_dependencies = {}
for field in ('source_sha256', 'checker_dependency_sha256'):
    for filename, h in strict[field].items():
        path = Path(filename).resolve()
        assert path.is_relative_to(PACKET)
        relative = str(path.relative_to(PACKET))
        assert relative in files and files[relative] == h and sha(path) == h
        assert relative not in portable_dependencies or portable_dependencies[relative] == h
        portable_dependencies[relative] = h
assert strict['all_sibling_sources_and_ancestors_rehashed_before_report'] is True
assert strict['complete_fixed_tiles'] == strict['new_original_cells'] == strict['new_masks'] == 0
assert strict['open_failure_indices'] == [1] + list(range(3, 17))

ancestry = PACKET / 'ancestry'
ancestry_manifest = read(ancestry / 'MANIFEST.json')
aliases = read(ancestry / 'SOURCE_BINDINGS.json')
assert len(ancestry_manifest['frozen_file_sha256']) == 126
for name, h in ancestry_manifest['frozen_file_sha256'].items():
    assert sha(ancestry / name) == h
def locate(name):
    path = (ancestry / aliases[name]).resolve()
    assert path.is_relative_to(PACKET)
    return path
parent = read(locate(strict['parent']['path']))
assert sha(locate(strict['parent']['path'])) == strict['parent']['sha256']
declarations = read(PACKET / 'DECLARED_TWENTY_DOMAIN_COVER.json')
assert sha(PACKET / 'DECLARED_TWENTY_DOMAIN_COVER.json') == strict['cover_sha256']
for item in declarations['children']:
    if 'bound' in item:
        bound = locate(item['bound']['path'])
        assert sha(bound) == item['bound']['sha256']
        record = read(bound)
        assert record['final'] == parent['final'] and record['status'] == 'OPEN' and record['rounds'] == []
energy_manifest = PACKET / 'energy_proof/SHA256_MANIFEST.json'
assert sha(energy_manifest) == '4aeddae4064ff2e7814e3b5b55eae458e143ac9ff7050eb3a0874cc3e8caa8a2'
energy_files = read(energy_manifest)['files']
assert len(energy_files) == 21
for name, h in energy_files.items():
    assert sha(PACKET / 'energy_proof' / name) == h

supplements = [
    dict(source_path=str(ROOT / 'global_theorem/SHARED_ABID_STRICT_TERMINAL_CHECK.json'),
         packet_path='hand_inputs/SHARED_ABID_STRICT_TERMINAL_CHECK.json',
         sha256='24174d47b3871e53f07859241d0e4dc7be024c3db678490558fca1591629b691'),
    dict(source_path=str(ROOT / 'pr11/research/nine/THREE_SQUARE_ENERGY_ROW_CONVERSION_HAND_PROOF.md'),
         packet_path='hand_inputs/THREE_SQUARE_ENERGY_ROW_CONVERSION_HAND_PROOF.md',
         sha256='61cd4d619f4702e4ef8501aa627ec7907c5e827230673da33da21236692b4c97'),
    dict(source_path=str(HERE / 'review_c887_sharp_sources.py'),
         packet_path='review_inputs/review_c887_sharp_sources.py',
         sha256='87754168fee77130fa685e26f8aca8dcdebe5a5d7d9de84eeb2d5d48cd654c9b'),
]
for item in supplements:
    assert sha(item['source_path']) == item['sha256']
    if (PACKET / item['packet_path']).exists():
        assert sha(PACKET / item['packet_path']) == item['sha256']

old_hand = HERE / 'C887_I21_SHARP_FOUNDATION_HAND_PROOF.md'
assert sha(old_hand) == OLD_HAND_SHA
text = old_hand.read_text()
text = text.replace('# C887 I21: exact foundation for the complete sharp complement',
                    '# C887 I21: portable exact foundation for the complete sharp complement', 1)
text = text.replace('The accepted whole-screen report is\n`C887_I21_COMPLETE_SHARP_SCREEN_REPLAY.json`, SHA-256\n`' + LOCAL_SHA + '`.',
                    'The fresh strict portable whole-screen report is\n`STRICT_FOUNDATION_REPLAY.json`, SHA-256\n`' + STRICT_SHA + '`.')
old_paragraph = ('The companion `C887_I21_SHARP_FOUNDATION_BINDINGS.json` binds this note, every\n'
    'table literal and conditional certificate, the accepted screen report and\n'
    'source audit, the full source/checker dependency maps, and the nested physical\n'
    'energy packet. The principal accepted hashes are:')
new_paragraph = ('The companion `C887_I21_SHARP_FOUNDATION_PORTABLE_BINDINGS.json` binds this\n'
    'note, every table literal and conditional certificate, the fresh strict\n'
    'screen report, the accepted source audit, the actual portable dependency\n'
    'maps, and the complete nested physical energy packet. The reviewed core is\n'
    'the frozen 179-file inventory, including 126 ancestry members and the\n'
    'complete original indexed legacy bundle. The final checkpoint also includes\n'
    'this hand note, its portable review and bindings, and the three small\n'
    'supplementary proof/review files listed in that binding.\n\n'
    'The strict report and the earlier accepted local report have identical\n'
    'mathematical contents, including every nested ancestor/child result, after\n'
    'removing only elapsed times and location-dependent source/checker maps.\n'
    'Every dependency actually recorded by the strict replay resolves inside\n'
    'the portable packet and matches the frozen core inventory. The original\n'
    'local review and broad local binding remain unchanged as historical\n'
    'artifacts; unrelated certificates in that old shared context are not\n'
    'premises of this portable proof. No mathematical check or evidence has\n'
    'been removed. The principal accepted hashes are:')
assert old_paragraph in text
text = text.replace(old_paragraph, new_paragraph)
new_hand = HERE / 'C887_I21_SHARP_FOUNDATION_PORTABLE_HAND_PROOF.md'
new_hand.write_text(text)

binding = dict(
    schema='C887_I21_sharp_foundation_portable_bindings_v1',
    status='FROZEN_PORTABLE_CORE_WITH_FIFTEEN_OPEN_FAILURES',
    packet='c887_sharp_foundation_package',
    hand_proof=dict(source_path=str(new_hand), sha256=sha(new_hand)),
    reviewed_core_inventory=dict(source_path=str(snapshot), sha256=SNAPSHOT_SHA, immutable_files=179),
    core_file_sha256=files,
    strict_report=dict(packet_path='STRICT_FOUNDATION_REPLAY.json', sha256=STRICT_SHA),
    accepted_local_report=dict(packet_path='accepted_reports/C887_I21_COMPLETE_SHARP_SCREEN_REPLAY.json', sha256=LOCAL_SHA),
    accepted_source_review=dict(packet_path='review_inputs/C887_SHARP_COMPONENT_AND_COMPLETE_COVER_SOURCE_REVIEW.json', sha256=SOURCE_REVIEW_SHA),
    mathematical_report_normal_form_sha256=normalized_hash,
    omitted_report_fields_only=sorted(OMITTED_RUNTIME_FIELDS),
    actual_portable_runtime_dependency_sha256=portable_dependencies,
    actual_portable_runtime_dependency_files=len(portable_dependencies),
    ancestry_manifest_sha256=sha(ancestry / 'MANIFEST.json'),
    source_alias_map_sha256=sha(ancestry / 'SOURCE_BINDINGS.json'),
    complete_ancestry_members=126, complete_energy_packet_members=21,
    complete_closed_complement_definitions=source_review['actual_screen_table'],
    interval_exclusion_indices=[0, 2, 17, 18, 19], open_indices=strict['open_failure_indices'],
    common_six_round_state=dict(rounds=6, deductions=506, premise_row_occurrences=1601, counted_once=True),
    supplementary_inputs_to_copy_unchanged=supplements,
    root_outer_manifest_may_add_documentation_but_core_bytes_must_remain_unchanged=True,
    broad_local_193_input_inventory_not_a_required_portable_dependency=True,
    terminal_rows=0, complete_fixed_tiles=0, new_original_cells=0, new_masks=0)
binding_path = HERE / 'C887_I21_SHARP_FOUNDATION_PORTABLE_BINDINGS.json'
binding_path.write_text(json.dumps(binding, indent=2) + '\n')
review = dict(
    schema='independent_C887_I21_sharp_foundation_portable_review_v1',
    status='PASS_STRICT_PORTABLE_IDENTITY_AND_COMPLETE_EVIDENCE_RETENTION',
    reviewed_strict_report_sha256=STRICT_SHA, compared_local_report_sha256=LOCAL_SHA,
    reviewed_core_inventory_sha256=SNAPSHOT_SHA, checked_core_files=179,
    portable_dependency_files=len(portable_dependencies),
    all_actual_replay_sources_and_checkers_resolve_inside_packet=True,
    all_actual_replay_sources_and_checkers_match_frozen_core_inventory=True,
    full_original_indexed_legacy_bundle_and_all_126_ancestry_members_retained=True,
    complete_21_input_energy_proof_retained=True,
    mathematical_report_normal_form_sha256=normalized_hash,
    mathematical_report_identity_ignored_only=sorted(OMITTED_RUNTIME_FIELDS),
    mathematical_checks_evidence_and_all_twenty_domains_unchanged=True,
    strict_interval_exclusions=5, independently_checked_OPEN_states=15,
    common_six_round_deductions_counted_once=506, common_six_round_premise_rows_counted_once=1601,
    revised_hand_proof_sha256=sha(new_hand), portable_binding_sha256=sha(binding_path),
    preserved_original_hand_proof_sha256=OLD_HAND_SHA,
    preserved_source_review_sha256=SOURCE_REVIEW_SHA,
    supplementary_sources_checked_and_required_unchanged=supplements,
    review_script_sha256=sha(__file__), mathematical_arithmetic_replayed=False,
    portable_exact_runtime_done_by_root=True, terminal_rows=0,
    complete_fixed_tiles=0, new_original_cells=0, new_masks=0)
review_path = HERE / 'C887_I21_SHARP_FOUNDATION_PORTABLE_REVIEW.json'
review_path.write_text(json.dumps(review, indent=2) + '\n')
for name, h in files.items():
    assert sha(PACKET / name) == h
assert sha(strict_path) == STRICT_SHA and sha(local_path) == LOCAL_SHA
print('PORTABLE_FOUNDATION_PASS', 'hand', sha(new_hand), 'binding', sha(binding_path), 'review', sha(review_path))
