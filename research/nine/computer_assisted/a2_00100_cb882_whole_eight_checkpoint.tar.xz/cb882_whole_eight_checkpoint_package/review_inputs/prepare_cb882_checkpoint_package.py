#!/usr/bin/env python3
"""Freeze the reviewed first-pass checkpoint without changing prior evidence."""
from pathlib import Path
from hashlib import sha256
import json
import shutil

HERE=Path(__file__).resolve().parent
BASE=HERE/'cb882_whole_eight_fast3_replay_package'
DOCS=HERE/'cb882_checkpoint_documents'
OUT=HERE/'cb882_whole_eight_checkpoint_package'
digest=lambda p:sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not OUT.exists()
    old_bytes=(BASE/'SHA256_MANIFEST.json').read_bytes()
    assert sha256(old_bytes).hexdigest()=='aed1e586e11ecd62599cd9aaf3d9f0e6e015bb3750a9f2a49c3a35130b9f08e3'
    old=json.loads(old_bytes)
    for name,expected in old['files'].items():
        source=BASE/name;assert digest(source)==expected
        target=OUT/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    review=OUT/'review_inputs';review.mkdir(exist_ok=True)
    shutil.copyfile(BASE/'verify_all.py',review/'EARLIER_FOUNDATION_WRAPPER.py')
    (review/'FIRST_PASS_SHA256_MANIFEST.json').write_bytes(old_bytes)
    shutil.copyfile(BASE/'CB882_WHOLE_EIGHT_FAST3_EXACT_REPLAY.json',review/'FIRST_PASS_EXACT_REPLAY.json')
    for path in DOCS.iterdir():
        assert path.is_file()and path.suffix in('.py','.json','.md')
        shutil.copyfile(path,OUT/path.name)
    sources=[
        (HERE.parent/'a_family/other_masks/CB882_CHECKPOINT_WRAPPER_AND_HAND_TABLE_INDEPENDENT_REVIEW.json',
         '8dd4b13fe4681838d5946fe1c62a1a3407e9ff36757c9d91f12e9722fa14696d'),
        (HERE.parent/'a_family/other_masks/review_cb882_checkpoint_wrapper.py',
         '0d9c01577530afdf9065b1b56e7b0c04aee0f61fa732573b9abd85a2adbdd94c')]
    for path,expected in sources:
        assert digest(path)==expected;shutil.copyfile(path,review/path.name)
    for path in(HERE/'build_cb882_checkpoint_documents.py',Path(__file__).resolve()):
        shutil.copyfile(path,review/path.name)
    files={str(p.relative_to(OUT)):digest(p)for p in OUT.rglob('*')if p.is_file()}
    manifest=dict(schema='CB882_portable_whole_eight_checkpoint_inventory_v1',files=files,
        original_id='negative-b882d8ade0cf9ea0',
        original_prefix_sha256='1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03',
        reviewed_first_pass_manifest_sha256=sha256(old_bytes).hexdigest(),
        exact_excluded_height_domains=[4,7],certified_open_height_domains=[0,1,2,3,5,6],
        whole_original_closed=False,new_original_cells=0,new_masks=0)
    (OUT/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    assert(BASE/'SHA256_MANIFEST.json').read_bytes()==old_bytes
    for name,expected in old['files'].items():assert digest(BASE/name)==expected
    print('FROZEN_CHECKPOINT',len(files),'MANIFEST',digest(OUT/'SHA256_MANIFEST.json'))


if __name__=='__main__':main()
