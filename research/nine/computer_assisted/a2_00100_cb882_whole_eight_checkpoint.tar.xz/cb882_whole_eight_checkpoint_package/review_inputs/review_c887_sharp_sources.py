#!/usr/bin/env python3
"""Independent source/coverage audit; never replays or invents mathematical rows.

The control-flow probes reuse already accepted OPEN0 reports as fixtures. Their
purpose is to reject malformed attachments and premature closure, not to grant
any new arithmetic, tile, original, or mask credit.
"""
import ast
import copy
from fractions import Fraction as F
import hashlib
import importlib
from itertools import product
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
GLOBAL = ROOT / 'global_theorem'
CD = ROOT / 'cd_family'
SCREEN = CD / 'c887_I21_sharp_complete_screen'
PINNED = {
    GLOBAL / 'verify_cd_sharp_complement_bounds_v2.py': '282d2e7a5f4adb5fec870d58111f0da1b3a1381714076053d2b592fd8b87dc42',
    GLOBAL / 'verify_cd_sharp_complement_bounds.py': 'cfa751ff8bb7c9c4d747a2c2f4fd8c73c03a52ec4a51f4183d5ae4beee3b3d33',
    GLOBAL / 'verify_CD_sharp_cover.py': 'e5391fc202a323ab8f16dfa7eb1094ef3c1bcaa15aec0757ec359822ffe45937',
    GLOBAL / 'verify_caaa_energy_derived_h_bounds.py': '6b9d5af165e13c3691e2e30ee72f3e839d704436a26dff7e81687a7ae0b58c29',
    GLOBAL / 'verify_cd_triple_energy_recursive_bounds.py': 'e73773f57e99797edcf5ee9726000c57ce212936b853c75247ff63ce9f16e0f4',
    GLOBAL / 'independent_sharp_complement_rows.py': 'f9ca410dbb44168c342e7d4aa80d34a863c3e113323df73630d88ef88f1294ce',
    GLOBAL / 'shared_strict_row_terminal.py': '43a74c66c7c0b91da76e6577ce511e6ae8de7bda9ab6e0adbf81a1cc2b013d43',
    ROOT / 'c_887_bound_package/replay_context.py': 'be53b0adf7485a68c0475d6148b5018df9d1dbe8e9bba9c110ab7b98ef4084da',
    CD / 'c887_sharp_complement_bounds.py': 'e394a7ecb6df2cc618f26f7d23dcd6cb95bddb18dd3eb30e8316c31a11d867ff',
    CD / 'run_c887_I21_sharp_screen.py': '04ddd96b7aaadf8cfa326c77c341d3dc137acdf8bb58ac73f48e56a82dbb88ac',
    SCREEN / 'COVER_SPECIFICATION.json': 'f42728e116ac4d28577db286948c1ab5225c5b2f746f671d24ade5e5e29326ce',
    SCREEN / 'completed_discovery_manifest.json': 'e305c794d55789f6a1ea0de4151e79e6d69a875259af557b26b63f49d818d5f0',
    CD / 'triple_energy_continued_tile_CD_negative-887236b78100baf3_2_1/bound_rounds.json': 'caa176c72bc4eecd0c199837a334433f5bcf7570f9f6cdd14cd13d88711f18d3',
    CD / 'new_cd_prefixes/negative-887236b78100baf3.json': '9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3',
    GLOBAL / 'C887_I21_COMPLETE_SHARP_SCREEN_REPLAY.json': '7aa33d74bd01d44f319fa9f8c27ad4d24a67ce3d6953e36d1acd1da41bfae25e',
    GLOBAL / 'SHARED_ABID_STRICT_BOUNDARY_TERMINAL.md': 'a4b923589a52be57fb84e484c92f4438c275dbc13e5b01a8e9add9d4dd40edcb',
    ROOT / 'pr11/research/nine/ALL_SIGN_CORRELATED_CORNER_ROW_HAND_STRENGTHENING.md': '0d233bddea414938482cb312519da061a546d26c4ee5a5bb83a14b48c178ed02',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def dump(node):
    return ast.dump(node, include_attributes=False)


def methods(path):
    tree = ast.parse(Path(path).read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Checker')
    return {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}


def oracle_rows(order, b, u):
    """Construct the twenty guards independently from their logical meanings."""
    label = ''.join('ABCDEFGHI'[i] for i in order)
    first = 'A_B_order_escape' if order == (0, 1, 8, 3) else 'H_left_escape'
    names = (first, 'I_left_escape', 'I_right_escape')
    answer = []
    for (left, right), name in zip(zip(order, order[1:]), names):
        answer.append((((2 * right, F(1)), (2 * left, F(-1))), F(0), 'sharp_' + label + '_' + name))
    seven = sorted(set(order) | {4, 5, 6})
    assert len(seven) == 7
    for i in seven:
        answer.append((((36 + i, F(-1)),), -b, 'sharp_' + label + '_abs_beta_escape_' + str(i)))
    for signs in product((-1, 1), repeat=3):
        # Negate sum s_k (y_right-y_left) >= u to obtain <= form.
        co = [F(0)] * 18
        for (left, right), s in zip(zip(order, order[1:]), signs):
            co[2 * left + 1] += s
            co[2 * right + 1] -= s
        terms = tuple((2 * i + 1, co[2 * i + 1]) for i in order if co[2 * i + 1])
        answer.append((terms, -u, 'sharp_' + label + '_height_escape_' + '_'.join(map(str, signs))))
    answer += [(((9, F(1)), (1, F(-1))), F(0), 'sharp_' + label + '_A_E_shoulder_escape'),
               (((13, F(1)), (7, F(-1))), F(0), 'sharp_' + label + '_D_G_shoulder_escape')]
    return tuple(answer)


def independent_lower(row, state):
    terms, rhs, name = row
    bounds = state['positions'] + state['scalar']
    value = sum(a * bounds[k][0 if a > 0 else 1] for k, a in terms)
    if len(terms) == 2:
        (i, a), (j, b) = terms
        if i < 18 and j < 18 and i % 2 == j % 2 and a == -b and abs(a) == 1:
            plus, minus = (i, j) if a == 1 else (j, i)
            left, right, axis = minus // 2, plus // 2, i % 2
            if left < right and (left, right) in state['differences']:
                value = max(value, state['differences'][left, right][axis][0])
            if right < left and (right, left) in state['differences']:
                value = max(value, -state['differences'][right, left][axis][1])
    return value


def state_of(record):
    saved = record['final']
    box = lambda xs: tuple(tuple(map(F, pair)) for pair in xs)
    return dict(positions=box(saved['positions']), scalar=box(saved['scalar']), angles=box(saved['angles']),
                differences={tuple(x['pair']): box(x['intervals']) for x in saved['differences']},
                conditional_sharp_rows=())


def rejects(fn, label, cases):
    try:
        fn()
    except AssertionError:
        cases.append(label)
    else:
        raise AssertionError('Expected gate rejection: ' + label)


def main():
    for path, h in PINNED.items():
        assert sha(path) == h, path
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(GLOBAL))
    C = importlib.import_module('verify_cd_sharp_complement_bounds_v2')
    G = importlib.import_module('verify_CD_sharp_cover')
    S = importlib.import_module('independent_sharp_complement_rows')
    current = methods(Path(C.__file__))
    v1 = methods(GLOBAL / 'verify_cd_sharp_complement_bounds.py')
    baseline = methods(GLOBAL / 'verify_caaa_energy_derived_h_bounds.py')
    for name in current:
        if name != '__init__':
            assert dump(current[name]) == dump(v1[name]), name
    loop = lambda node: next(n for n in node.body if isinstance(n, ast.For)
        and isinstance(n.target, ast.Tuple) and [x.id for x in n.target.elts] == ['ri', 'rr'])
    assert dump(loop(current['_replay'])) == dump(loop(baseline['replay']))
    terminal_ifs = lambda node: [n for n in node.body if isinstance(n, ast.If)]
    new_ifs = terminal_ifs(current['_replay'])
    ordinary_ifs = [n for n in new_ifs if 'accepted_shared_sharp_boundary_terminal' not in ast.unparse(n.test)]
    assert [dump(n) for n in ordinary_ifs] == [dump(n) for n in terminal_ifs(baseline['replay'])]

    count = 0
    for order in ((0, 1, 8, 3), (0, 7, 8, 3)):
        for b, u in ((F(1, 30), F(11, 30)), (F(1, 50), F(9, 20)), (F(1, 200), F(53, 100))):
            assert S.complete_rows(order, b, u) == oracle_rows(order, b, u)
            count += 20
    # The algebraic reason is |d1|+|d2|+|d3| = max_s sum(s_k*d_k).
    # These exact samples check signs/zero/equality handling in the table.
    height_samples = 0
    for deltas in product((F(-53, 100), F(-1, 10), F(0), F(1, 10), F(53, 100)), repeat=3):
        assert max(sum(s * d for s, d in zip(signs, deltas)) for signs in product((-1, 1), repeat=3)) == sum(map(abs, deltas))
        height_samples += 1

    specification = read(SCREEN / 'COVER_SPECIFICATION.json')
    manifest = read(SCREEN / 'completed_discovery_manifest.json')
    runtime = read(GLOBAL / 'C887_I21_COMPLETE_SHARP_SCREEN_REPLAY.json')
    parent = read(manifest['parent']['path'])
    state = state_of(parent)
    assert manifest['parent'] == specification['parent'] == runtime['parent']
    assert parent['id'] == C.TARGET_ID and parent['path'] == C.TARGET_PATH
    assert parent['prior']['sha256'] == C.ORIGINAL_PREFIX_SHA256
    assert parent['prior']['tile'] == [2, 1] and parent['prior']['h_rectangle'] is None
    assert manifest['parent']['sha256'] == C.ROOT_PARENT_SHA256
    assert parent['status'] == 'OPEN' and len(parent['rounds']) == 6
    assert parent['final'] == parent['rounds'][-1]['after']
    assert parent['final_test']['round'] == 6 and parent['final_test']['proposals'] == []
    assert runtime['original_parent_bound_replay']['certificate_sha256'] == C.ROOT_PARENT_SHA256
    assert runtime['original_parent_bound_replay']['status'] == 'PASS_CERTIFIED_TILE_STATE_OPEN'
    rows = oracle_rows((0, 7, 8, 3), F(1, 200), F(53, 100))
    assert [x['index'] for x in manifest['children']] == list(range(20))
    table = []
    for i, (entry, row) in enumerate(zip(manifest['children'], rows)):
        assert entry['row'] == S.literal(row) == specification['children'][i]['row']
        lower = independent_lower(row, state)
        assert lower == S.lower_lhs(row, state['positions'], state['scalar'], state['differences'])
        item = dict(index=i, name=row[2], closed_guard=S.literal(row), lower_lhs=str(lower), rhs=str(row[1]))
        if entry['kind'] == 'interval_exclusion':
            assert lower > row[1]
            assert entry['evidence'] == dict(lower_lhs=str(lower), rhs=str(row[1]), positive_gap=str(lower - row[1]))
            item.update(status='EXACT_STRICT_INTERVAL_EXCLUSION', positive_gap=str(lower - row[1]))
        else:
            assert entry['kind'] == 'open_bound_state'
            child = read(entry['bound']['path'])
            assert sha(entry['bound']['path']) == entry['bound']['sha256']
            assert child['status'] == 'OPEN' and child['rounds'] == []
            assert child['final'] == parent['final'] and child['prior'] == parent['prior']
            assert child['sharp_restriction']['parent'] == manifest['parent']
            assert child['sharp_restriction']['branch'] == i
            assert S.selected_row(child['sharp_restriction']) == row
            for filename, h in child['sources'].items():
                assert sha(filename) == h
            item.update(status='OPEN_ZERO_ROUND_CONDITIONAL_STATE', certificate_sha256=entry['bound']['sha256'])
        table.append(item)
    assert [x['index'] for x in table if x['status'] == 'EXACT_STRICT_INTERVAL_EXCLUSION'] == [0, 2, 17, 18, 19]
    assert not (SCREEN / 'complete_cover.json').exists()
    assert runtime['open_failure_indices'] == [1] + list(range(3, 17))
    assert runtime['complete_fixed_tiles'] == runtime['new_original_cells'] == runtime['new_masks'] == 0
    assert runtime['bound_deductions'] == 506 and runtime['bound_premise_rows'] == 1601
    assert runtime['distinct_bound_records'] == 16 and runtime['terminal_rows'] == 0

    cases = []
    # A literal name alone must never attach a different threshold or guard.
    obj = C.Checker.__new__(C.Checker)
    obj.active_sharp_rows = (rows[3],)
    def check_printed(row):
        entry = dict(index=0, **S.literal(row))
        return obj.printed_rows([entry], 1, [], [F(2)] * 54, (), {}, {}, ())
    assert check_printed(rows[3])[0][0] == rows[3]
    rejects(lambda: check_printed(S.complete_rows(S.AHID, F(1, 30), F(11, 30))[3]),
            'same conditional name with different right side', cases)
    rejects(lambda: check_printed(rows[4]), 'different branch conditional row', cases)
    obj.active_sharp_rows = ()
    rejects(lambda: check_printed(rows[3]), 'conditional row absent from proved parent chain', cases)
    conditional_source = read(manifest['children'][1]['bound']['path'])
    for label, alter in (
        ('different original id', lambda d: d.update(id='negative-other')),
        ('different original path', lambda d: d.update(path=[])),
        ('different original prefix hash', lambda d: d['prior'].update(sha256='0' * 64)),
        ('different I tile', lambda d: d['prior'].update(tile=[1, 1])),
        ('different I partition', lambda d: d['prior'].update(closed_cover_parts=[2, 4])),
        ('unexpected H restriction', lambda d: d['prior'].update(h_rectangle=[['0', '1'], ['0', '1']]))):
        bad = copy.deepcopy(conditional_source); alter(bad)
        rejects(lambda bad=bad: obj.conditional_initial_state(bad), label, cases)

    # Exercise actual replay's try/finally state restoration without any math.
    obj.recheck = lambda: None
    obj.register_dependencies = lambda *args, **kwargs: None
    obj.active = set()
    sentinel = (rows[0],)
    obj.active_sharp_rows = sentinel
    def simulated_failure(*args):
        obj.active_sharp_rows = (rows[7],)
        raise AssertionError('deliberate metadata probe')
    obj._replay = simulated_failure
    rejects(lambda: obj.replay(manifest['children'][1]['bound']['path']), 'in-flight conditional failure', cases)
    assert obj.active_sharp_rows == sentinel and not obj.active

    # Use published exact OPEN0 component reports as control-flow fixtures.
    # No local/ancestral mathematical replay is replaced by these probes.
    child_reports = {x['bound_report']['certificate_sha256']: x['bound_report']
                     for x in runtime['child_reports'] if 'bound_report' in x}
    parent_report = runtime['original_parent_bound_replay']

    class FixtureChecker:
        strict_root = None
        def __init__(self, after_last=None):
            self.touched = {}; self.dependencies = {}; self.after_last = after_last
        def locate(self, name):
            return Path(name)
        def recheck(self):
            for name, h in self.touched.items():
                assert sha(name) == h
        def replay(self, path, **kwargs):
            record = read(path); report = copy.deepcopy(child_reports[sha(path)])
            assert report['certificate_sha256'] == sha(path)
            child_state = copy.deepcopy(state)
            child_state['conditional_sharp_rows'] = (S.selected_row(record['sharp_restriction']),)
            if record['sharp_restriction']['branch'] == 16 and self.after_last:
                self.after_last()
            return report, child_state, {}

    def fixture_gate(selected_state=None, after_last=None):
        gate = G.SharpCoverChecker.__new__(G.SharpCoverChecker)
        gate.checker = FixtureChecker(after_last)
        gate.active = set(); gate.completed = {}; gate.bound_records = {}
        gate.dependencies = {str(Path(G.__file__).resolve()): sha(G.__file__)}
        def parent_fixture(reference):
            assert reference == manifest['parent']
            gate.register_bound_report(parent_report)
            return parent, parent_report, copy.deepcopy(state if selected_state is None else selected_state), {}
        gate.parent_state = parent_fixture
        return gate

    with tempfile.TemporaryDirectory(prefix='c887_sharp_control_', dir=HERE) as tmp:
        tmp = Path(tmp)
        def run_fixture(value, allow_partial=True, selected_state=None, after_last=None):
            p = tmp / 'cover.json'; p.write_text(json.dumps(value) + '\n')
            return fixture_gate(selected_state, after_last).replay(p, allow_partial=allow_partial)
        result = run_fixture(manifest)
        assert result['status'] == 'PASS_DECLARED_SHARP_COVER_WITH_OPEN_FAILURES'
        assert result['open_failure_domains'] == 15 and result['complete_fixed_tiles'] == 0
        assert result['bound_deductions'] == 506 and result['bound_premise_rows'] == 1601
        assert result['distinct_bound_records'] == 16
        cases.append('all fifteen actual OPEN0 reports remain OPEN and shared parent is counted once')
        rejects(lambda: run_fixture(manifest, False), 'partial declaration without explicit allow-partial', cases)
        alterations = (
            ('complete schema with an OPEN child', lambda d: d.update(schema=G.COMPLETE_SCHEMA)),
            ('missing one of twenty domains', lambda d: d['children'].pop()),
            ('duplicate domain index', lambda d: d['children'][3].update(index=2)),
            ('different declared literal', lambda d: d['children'][0]['row'].update(rhs='1')),
            ('nonpositive or altered exclusion evidence', lambda d: d['children'][0]['evidence'].update(positive_gap='0')),
            ('OPEN child promoted to terminal', lambda d: d['children'][1].update(kind='bound_terminal')),
            ('different child file hash', lambda d: d['children'][1]['bound'].update(sha256='0' * 64)),
            ('guard from another sibling', lambda d: d['children'][1].update(bound=copy.deepcopy(d['children'][3]['bound']))),
            ('unrecognized helper bytes', lambda d: d.update(helper_sha256='0' * 64)),
            ('removed equality faces', lambda d: d.update(closed_faces_retained=False)),
        )
        for label, alter in alterations:
            bad = copy.deepcopy(manifest); alter(bad)
            rejects(lambda bad=bad: run_fixture(bad), label, cases)
        equality_state = copy.deepcopy(state)
        pos = list(equality_state['positions']); pos[0] = pos[14] = (F(0), F(0))
        equality_state['positions'] = tuple(pos)
        old = equality_state['differences'][0, 7]
        equality_state['differences'][0, 7] = ((F(0), F(0)), old[1])
        bad = copy.deepcopy(manifest)
        bad['children'][0]['evidence'] = dict(lower_lhs='0', rhs='0', positive_gap='0')
        assert independent_lower(rows[0], equality_state) == rows[0][1]
        rejects(lambda: run_fixture(bad, selected_state=equality_state), 'equality face excluded using lower >= rhs', cases)
        extra = tmp / 'source.txt'; extra.write_text('frozen source\n')
        bad = copy.deepcopy(manifest); bad['sources'][str(extra)] = sha(extra)
        rejects(lambda: run_fixture(bad, after_last=lambda: extra.write_text('changed source\n')),
                'source changed after an earlier sibling but before final report', cases)

    # Verify the actual new context preflight rejects wrong origins/bytes
    # before it can construct an ancestor checker.
    init = current['__init__'].body
    stop = next(i for i, n in enumerate(init) if isinstance(n, ast.Assign)
                and ast.unparse(n.targets[0]) == 'ancestor')
    preflight = compile(ast.Module(body=init[:stop], type_ignores=[]), str(C.__file__), 'exec')
    def context_probe(module_path, actual_hash):
        env = dict(context=ROOT / 'c_887_bound_package', Path=Path,
            sys=SimpleNamespace(path=[]), importlib=SimpleNamespace(import_module=lambda name: SimpleNamespace(__file__=str(module_path))),
            digest=lambda path: actual_hash, CONTEXT_SHA256=C.CONTEXT_SHA256)
        exec(preflight, env)
    context_probe(ROOT / 'c_887_bound_package/replay_context.py', C.CONTEXT_SHA256)
    rejects(lambda: context_probe(HERE / 'replay_context.py', C.CONTEXT_SHA256), 'cached context from another packet', cases)
    rejects(lambda: context_probe(ROOT / 'c_887_bound_package/replay_context.py', '0' * 64), 'changed context loader bytes', cases)

    for path, h in PINNED.items():
        assert sha(path) == h, path
    assert not any(n in sys.modules for n in ('numpy', 'scipy', 'highspy', 'v3_whole_parent_pass'))
    report = dict(
        schema='independent_C887_sharp_component_and_complete_cover_source_review_v1',
        status='PASS_SOURCE_COVERAGE_AND_ATTACHMENT_GATES',
        component_sha256=PINNED[Path(C.__file__)], cover_checker_sha256=PINNED[Path(G.__file__)],
        source_sha256={str(p): h for p, h in PINNED.items()}, review_script_sha256=sha(__file__),
        exact_induction_loop_AST_unchanged=True, ordinary_terminal_ASTs_unchanged=True,
        revised_component_only_adds_pinned_actual_context_origin_before_ancestor_and_end_hash=True,
        independent_conditional_row_definitions_checked=count,
        signed_height_identity_exact_samples=height_samples,
        complete_cover_derivation={
            'order': 'Three closed domains cover every failure of nondecreasing order; equality faces are retained.',
            'frame': 'Seven domains -e_i <= -b cover |beta_i| >= b in the original physical absolute-frame variables.',
            'height': 'The eight signed height sums have maximum equal to the total absolute height variation; each escape is closed at U.',
            'shoulders': 'Both nonpositive shoulder gaps are explicitly retained; outside the cover both upward gaps are strictly positive.',
            'remainder': 'Outside all twenty domains the seven-square physical theorem applies with strict interior order, frame and variation bounds; touching faces remain in one or more declared closed domains.',
            'caller': 'The pinned C887 original keeps nine original frames, all corners and physical pairs, actual AB/BC/EF/FG, and the original strictly weak CD bit. No conditional row is used to prove its unconditional ancestor.',
            'equality': 'On the accepted sharp theorem equality face, all seven selected frames align and x_D-x_A=3; original AB,BC plus CD cone-inset force B,C aligned and contradict strictly weak CD.'},
        original_id=C.TARGET_ID, original_path=C.TARGET_PATH, original_prefix_sha256=C.ORIGINAL_PREFIX_SHA256,
        completed_six_round_parent_sha256=C.ROOT_PARENT_SHA256, original_I_tile=[2, 1],
        conditional_rows_match_full_coefficients_rhs_and_name=True,
        nested_sharp_rows_retained_and_unconditional_ancestor_uses_separate_checker=True,
        full_dependency_closure_and_actual_context_rehashed_at_leaf_and_sibling_end=True,
        nested_complete_cover_must_match_exact_child_parent_guard_and_conditional_state=True,
        source_hash_deduplicated_induction_accounting=True,
        control_flow_probes=cases, control_flow_probe_count=len(cases),
        actual_screen_table=table, actual_screen_interval_exclusions=5, actual_screen_OPEN_domains=15,
        accepted_runtime_report_sha256=PINNED[GLOBAL / 'C887_I21_COMPLETE_SHARP_SCREEN_REPLAY.json'],
        accepted_root_induction_deductions_counted_once=506, accepted_root_premise_rows_counted_once=1601,
        actual_screen_distinct_bound_records=16, actual_screen_terminal_rows=0,
        mathematical_arithmetic_replayed_by_this_audit=False,
        control_flow_fixtures_grant_no_mathematical_credit=True,
        complete_fixed_tiles=0, new_original_cells=0, new_masks=0,
        limitations='This accepts source, scope, coverage and immutable-input gates. The actual screen retains fifteen OPEN failures. Each later numerical candidate still requires independent exact replay and every remaining failure must be closed before I21 is closed.')
    output = HERE / 'C887_SHARP_COMPONENT_AND_COMPLETE_COVER_SOURCE_REVIEW.json'
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(report['status'], 'control gates', len(cases), 'review SHA', sha(output))


if __name__ == '__main__':
    main()
