#!/usr/bin/env python3
"""Independent frozen wrapper/hand-table audit, without repeating bound replay."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DOCS=ROOT/'global_theorem/cb882_checkpoint_documents'
BASE=ROOT/'global_theorem/cb882_whole_eight_fast3_replay_package'
OUT=HERE/'CB882_CHECKPOINT_WRAPPER_AND_HAND_TABLE_INDEPENDENT_REVIEW.json'
PINS={'verify_all.py':'7d6900c5e688f3a49168e6c722e4997cb86bdc2378d2012016239db7ac574956',
      'HAND_PROOF.md':'14fc29b95bab66ebaea4926e264426a42706d26d668a49fa047a02a185deecf8',
      'COVER_TABLE.json':'b98dd915ca1a3c85da9554960ac014493b886a40cd432d5962e89eda27515ca1',
      'PHYSICAL_THEOREM_DEPENDENCIES.json':'08e8da63655a39df7bf2a922d6d19dd80dccd9bbdc1dd78bb496bc22632656de'}
FIRST_SHA='365fad3113460e83967da29c445dbbbdb1b975bcdd917c363fdd2b3b5dfca809'


def main():
    assert __debug__ and not OUT.exists()
    inputs={}
    def bind(path,expected=None):
        path=Path(path).resolve();raw=path.read_bytes();h=sha256(raw).hexdigest()
        if expected is not None:assert h==expected,(str(path),h,expected)
        assert path not in inputs or inputs[path]==h
        inputs[path]=h;return raw
    for name,h in PINS.items():bind(DOCS/name,h)
    table=json.loads((DOCS/'COVER_TABLE.json').read_text())
    physical=json.loads((DOCS/'PHYSICAL_THEOREM_DEPENDENCIES.json').read_text())
    first=json.loads(bind(BASE/'CB882_WHOLE_EIGHT_FAST3_EXACT_REPLAY.json',FIRST_SHA))
    manifest=json.loads(bind(BASE/'SHA256_MANIFEST.json'))
    for name,h in manifest['files'].items():
        p=(BASE/name).resolve();assert p.is_relative_to(BASE);bind(p,h)
    assert first['status']=='PASS_DECLARED_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_WITH_OPEN_DOMAINS'
    assert table['source_report']==dict(packet_path='review_inputs/FIRST_PASS_EXACT_REPLAY.json',sha256=FIRST_SHA)
    assert table['original_id']==first['id']=='negative-b882d8ade0cf9ea0'
    assert table['original_path']==first['original_parent_path']==[['angle',3,0],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[3]]]
    assert table['original_prefix_sha256']==first['original_prefix_sha256']=='1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'
    assert table['physical_parent_state_sha256']==first['whole_original_physical_state_sha256']
    assert table['whole_parent_prerequisites']==first['whole_original_prerequisites']
    assert table['specification_sha256']==first['cover_specification_sha256']=='e4825423f302b0920ce001090cea28624af840904d27169e98cdb22c3eed8b48'
    assert first['checker_sha256']=='96e8353f02eff5fb4fd32dc8b05c7c07578863207206b56cf46bf953afd16845'
    assert first['component_checker_sha256']=='53313a8e79b32bcf4b035c9e57b9f5a7df091ae6fe9762ba33058e6892865ba0'
    assert len(first['child_reports'])==len(table['members'])==8
    descriptors=[]
    used_energy=[]
    for branch,(signs,child,member) in enumerate(zip(product((-1,1),repeat=3),first['child_reports'],table['members'])):
        coefficients={}
        for sign,(i,j) in zip(signs,((1,15),(15,17),(17,7))):
            coefficients[i]=coefficients.get(i,0)+sign
            coefficients[j]=coefficients.get(j,0)-sign
        row=dict(coefficients=[[k,str(v)]for k,v in sorted(coefficients.items())if v],
                 rhs='-23/100',name='opposite_tilt_AHID_variation_'+str(branch))
        assert child['branch']==member['branch']==branch and child['signs']==list(signs)
        assert child['row']==member['row']==row
        r=child['bound_report']
        descriptor=dict(branch=branch,signs=list(signs),row=row,status=child['status'],
            certificate_sha256=r['certificate_sha256'],rounds=r['bound_rounds'],
            deductions=r['bound_deductions'],premise_rows=r['printed_rows_checked']-r['terminal_rows'],
            terminal_rows=r['terminal_rows'],reserve=r['reserve'],terminal_kind=r['terminal_kind'],
            terminal_label=r['terminal_label'],terminal_evidence=r['terminal_evidence'],
            three_square_rows=r['independently_rebuilt_three_square_energy_rows'],
            conditional_rows=r['independently_rebuilt_conditional_sharp_rows'])
        assert descriptor==member;descriptors.append(descriptor)
        raw=json.loads(bind(BASE/'data'/('branch_%02d.json'%branch),r['certificate_sha256']))
        groups=[rr['printed_rows']for rr in raw['rounds']]
        if raw.get('terminal',{}).get('kind')=='positive_exact_reserve':groups.append(raw['terminal']['printed_rows'])
        for group in groups:
            for rr in group:
                if rr['name'].startswith(('three_square_center_energy_','planar_four_center_','square_area_')):
                    used_energy.append(dict(branch=branch,name=rr['name'],coefficients=rr['coefficients'],rhs=rr['rhs']))
    assert table['excluded_domains']==[4,7] and table['open_domains']==[0,1,2,3,5,6]
    assert first['conditional_terminals']==2 and first['open_domains']==6
    for i in table['open_domains']:
        assert descriptors[i]['status']=='OPEN_CERTIFIED_HEIGHT_DOMAIN' and descriptors[i]['rounds']==3
    for i in table['excluded_domains']:assert descriptors[i]['status']=='PASS_COMPLETE_HEIGHT_DOMAIN'
    assert table['local_totals']==dict(rounds=20,deductions=3006,premise_rows=5018,terminal_rows=21,
                                     three_square_row_occurrences=12,selected_height_row_occurrences=20)
    for key,target in (('rounds',20),('deductions',3006),('premise_rows',5018),('terminal_rows',21),
                       ('three_square_rows',12),('conditional_rows',20)):
        assert sum(m[key]for m in descriptors)==target
    assert table['common_parent']==dict(rounds=5,deductions=386,premise_rows=1073,earlier_coordinate_deductions=30)
    assert first['total_bound_rounds_including_common_parent']==25
    assert first['total_bound_deductions_including_common_parent']==3392
    evidence=descriptors[4]['terminal_evidence']
    assert evidence['pair']==[1,7]
    options=evidence['four_original_inset_alternatives_rejected_directly']
    assert {(r['left'],r['right'],r['axis'])for r in options}=={(1,7,0),(7,1,0),(1,7,1),(7,1,1)}
    for option in options:
        assert F(option['inset_halfwidth_sum_lower'])-F(option['signed_center_gap_upper'])==F(option['strict_gap_deficit'])>0
    reserve=F(descriptors[7]['reserve']);assert reserve>F(1,2048)
    assert used_energy==physical['selected_local_energy_row_occurrences'] and len(used_energy)==12
    assert all(r['name'].startswith('three_square_center_energy_')for r in used_energy)
    assert physical['four_center_occurrences']==physical['square_area_occurrences']==0
    for name,h in physical['theorem_text_and_review_sha256'].items():bind(BASE/name,h)
    hand=(DOCS/'HAND_PROOF.md').read_text()
    hand_rows=[]
    for line in hand.splitlines():
        m=re.match(r'^\| (\d) \| (.*?) \| (.*?) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \|$',line)
        if m:
            i,literal,status,rounds,deductions,premise,terminal=m.groups();i=int(i);hand_rows.append(i)
            saved=descriptors[i]
            assert list(map(int,(rounds,deductions,premise,terminal)))==[saved[k]for k in ('rounds','deductions','premise_rows','terminal_rows')]
            assert status.startswith('OPEN') == (i in table['open_domains'])
    assert hand_rows==list(range(8))
    assert str(reserve.numerator)in hand and str(reserve.denominator)in hand
    assert first['complete_domain_union_checked'] and first['closed_faces_retained']
    assert first['center_subdivisions']==0 and first['earlier_sibling_complements_added'] is False
    assert first['all_earlier_sibling_theorem_and_ancestor_bytes_rehashed'] is True
    assert first['whole_original_cover_checked'] is False and first['complete_eight_height_cover_checked'] is False
    assert first['new_original_cells']==first['new_masks']==table['new_original_cells']==table['new_masks']==0
    bind(__file__)
    for path,h in inputs.items():assert sha256(path.read_bytes()).hexdigest()==h
    out=dict(status='PASS_FROZEN_CHECKPOINT_WRAPPER_AND_HAND_TABLE_SOURCE_REVIEW',
        scope='New wrapper/hand attachment only; accepted scalar, ancestor and conditional arithmetic not repeated',
        wrapper_sha256=PINS['verify_all.py'],hand_sha256=PINS['HAND_PROOF.md'],
        table_sha256=PINS['COVER_TABLE.json'],physical_dependency_sha256=PINS['PHYSICAL_THEOREM_DEPENDENCIES.json'],
        accepted_first_pass_sha256=FIRST_SHA,
        exact_literal_domains=8,excluded_domains=[4,7],open_three_round_domains=[0,1,2,3,5,6],
        complete_hand_entries_checked=8,local_rounds=20,local_deductions=3006,
        induction_row_occurrences=5018,terminal_row_occurrences=21,
        independent_inset_alternatives_checked=4,positive_reserve_lower_bound='1/2048',
        used_local_triple_energy_rows=12,
        manually_reviewed_source_findings=[
            'The wrapper pins the accepted whole-eight gate and conditional component, and resolves the imported core inside the final packet.',
            'Fresh shared energy replay precedes the accepted gate, whose unchanged implementation freshly replays the full-angle theorem and original parent.',
            'All eight fresh descriptors must equal the frozen table and accepted first-pass report, including literal rows, witnesses, reserves and exact original state.',
            'The complete caller, independent sibling restrictions and all closed faces remain unchanged.',
            'OPEN states remain explicit; neither the declaration nor the two exclusions is promoted to original closure.',
            'All physical proof texts, exact used energy rows, immutable inputs and earlier sibling dependencies are rehashed before final output.'
        ],
        final_relocated_runtime_still_required=True,
        source_sha256={str(p):h for p,h in sorted(inputs.items())},
        evaluator_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
        new_original_cells=0,new_masks=0,lean_lake_ci_run=False)
    OUT.write_text(json.dumps(out,indent=2)+'\n')
    print(out['status']);print('REVIEW_SHA256',sha256(OUT.read_bytes()).hexdigest())
    print('EVALUATOR_SHA256',out['evaluator_sha256'])

if __name__=='__main__':main()
