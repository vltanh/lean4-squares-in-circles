"""Independently expand exact frame-to-slope inference until contradiction."""
from fractions import Fraction as F

def verify(K,old_angles,scalar,saved):
    assert len(old_angles)==9 and len(scalar)==36
    assert 1<=len(saved)<=9
    for i,(old_lo,old_hi)in enumerate(old_angles):
        amin,amax=scalar[i];bmin,bmax=scalar[9+i];vmin,vmax=scalar[18+i]
        assert 0<amin<=amax<=1 and -1<bmin<=bmax<1 and 0<=vmin<=vmax<1
        cap=K.sqrtbox(1/(amin*amin)-1)[1]
        blo=K.inverse_beta(bmin)[0];bhi=K.inverse_beta(bmax)[1]
        lo=max(old_lo,-cap,blo);hi=min(old_hi,cap,bhi)
        abs_cap=K.inverse_beta(vmax)[1]
        lo=max(lo,-abs_cap);hi=min(hi,abs_cap)
        floor=None
        if lo>=0 or hi<=0:
            floor=K.inverse_beta(vmin)[0]
            if amax<1:floor=max(floor,K.sqrtbox(1/(amax*amax)-1)[0])
            if lo>=0:lo=max(lo,floor)
            if hi<=0:hi=min(hi,-floor)
        expected=dict(original=i,old_slope_interval=list(map(str,(old_lo,old_hi))),
            alpha_interval=list(map(str,(amin,amax))),beta_interval=list(map(str,(bmin,bmax))),
            absolute_beta_interval=list(map(str,(vmin,vmax))),alpha_lower_slope_cap=str(cap),
            beta_inverse_interval=list(map(str,(blo,bhi))),absolute_beta_slope_cap=str(abs_cap),
            one_sign_slope_floor=str(floor),new_slope_interval=list(map(str,(lo,hi))))
        assert i<len(saved)and saved[i]==expected
        if lo>hi:
            assert len(saved)==i+1
            upper=amax*amax+max(bmin*bmin,bmax*bmax)
            witness=dict(kind='proved_empty_original_angle_interval',original=i,
                lower=str(lo),upper=str(hi),gap=str(lo-hi),checked_frame_inferences=i+1,
                alpha_interval=list(map(str,(amin,amax))),beta_interval=list(map(str,(bmin,bmax))),
                absolute_beta_interval=list(map(str,(vmin,vmax))))
            if upper<1:
                witness['independent_unit_frame_square_sum_upper']=str(upper)
                witness['independent_unit_frame_square_sum_gap']=str(1-upper)
            return witness
    raise AssertionError('No empty original-angle interval was independently derived.')
