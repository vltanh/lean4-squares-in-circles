#!/usr/bin/env python3
"""Exact closed failures of the accepted seven-square sharp-row hypotheses.

The caller must independently prove all original physical premises of the
strict 001/00 problem, including actual EF and FG. These are conditional
cover rows, not unconditional necessary inequalities. This module neither
proves an ancestor nor closes a domain.
"""
from fractions import Fraction as F
from itertools import product

ABID=(0,1,8,3)
AHID=(0,7,8,3)
PARAMETERS=((F(1,30),F(11,30)),(F(1,50),F(9,20)),(F(1,200),F(53,100)))

def complete_rows(row=ABID,beta=F(1,200),variation=F(53,100)):
    """All20 closed failure domains; shared equality faces are retained."""
    row=tuple(row);beta,variation=F(beta),F(variation)
    assert row in(ABID,AHID)and(beta,variation)in PARAMETERS
    label='ABID'if row==ABID else'AHID'
    order_names=(['A_B_order_escape','I_left_escape','I_right_escape']if row==ABID
                 else['H_left_escape','I_left_escape','I_right_escape'])
    rows=[]
    for i,j,name in zip(row,row[1:],order_names):
        rows.append((((2*j,F(1)),(2*i,F(-1))),F(0),'sharp_'+label+'_'+name))
    seven=tuple(sorted(set(row)|{4,5,6}));assert len(seven)==7
    for i in seven:
        rows.append((((36+i,F(-1)),),-beta,'sharp_'+label+'_abs_beta_escape_'+str(i)))
    for signs in product((-1,1),repeat=3):
        coefficients={}
        for i,j,sign in zip(row,row[1:],signs):
            coefficients[2*i+1]=coefficients.get(2*i+1,F(0))+sign
            coefficients[2*j+1]=coefficients.get(2*j+1,F(0))-sign
        terms=tuple((2*i+1,coefficients[2*i+1])for i in row if coefficients[2*i+1])
        rows.append((terms,-variation,'sharp_'+label+'_height_escape_'+'_'.join(map(str,signs))))
    rows += [(((9,F(1)),(1,F(-1))),F(0),'sharp_'+label+'_A_E_shoulder_escape'),
             (((13,F(1)),(7,F(-1))),F(0),'sharp_'+label+'_D_G_shoulder_escape')]
    assert len(rows)==20 and len({name for terms,rhs,name in rows})==20
    return tuple(rows)

def literal(row):
    terms,rhs,name=row
    return dict(coefficients=[[k,str(v)]for k,v in terms],rhs=str(rhs),name=name)

def selected_row(detail):
    """Reconstruct one declared conditional guard; this is no coverage gate."""
    assert detail['complete_closed_domains']==20 and detail['closed_faces_retained']is True
    index=detail['branch'];assert type(index)is int and 0<=index<20
    row=complete_rows(detail['selected_row'],detail['beta_bound'],detail['variation_bound'])[index]
    assert detail['conditional_row']==literal(row)
    return row

def lower_lhs(row,positions,scalar,differences):
    """A valid interval lower bound, optionally intersecting a pair difference.

    To exclude the row a·z<=rhs, the caller must require the strict comparison
    lower_lhs>rhs. A non-strict comparison would discard an equality face.
    """
    positions=tuple(tuple(map(F,ab))for ab in positions)
    scalar=tuple(tuple(map(F,ab))for ab in scalar)
    assert len(positions)==18 and len(scalar)==36
    assert all(lo<=hi for lo,hi in positions+scalar)
    differences={tuple(pair):tuple(tuple(map(F,ab))for ab in intervals)
                 for pair,intervals in differences.items()}
    assert all(len(pair)==2 and 0<=pair[0]<pair[1]<9 and len(intervals)==2
               and all(len(ab)==2 and ab[0]<=ab[1]for ab in intervals)
               for pair,intervals in differences.items())
    terms,rhs,name=row;values=positions+scalar
    lower=sum(v*values[k][0 if v>0 else 1]for k,v in terms)
    if len(terms)==2 and all(k<18 for k,v in terms):
        (a,u),(b,v)=terms
        if u==-v and abs(u)==1 and a%2==b%2:
            negative=a if u<0 else b;positive=b if u<0 else a
            i,j,axis=negative//2,positive//2,negative%2
            if i<j and(i,j)in differences:
                lower=max(lower,F(differences[i,j][axis][0]))
            elif j<i and(j,i)in differences:
                lower=max(lower,-F(differences[j,i][axis][1]))
    return lower
