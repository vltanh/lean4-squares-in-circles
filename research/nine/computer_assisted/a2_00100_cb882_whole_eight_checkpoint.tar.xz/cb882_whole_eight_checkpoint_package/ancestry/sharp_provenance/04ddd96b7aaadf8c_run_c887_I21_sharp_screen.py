#!/usr/bin/env python3
"""One complete finite sharp-complement screen on C887's proved I21 state."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'global_theorem'))
import independent_sharp_complement_rows as SHARP

PARENT = HERE / 'triple_energy_continued_tile_CD_negative-887236b78100baf3_2_1/bound_rounds.json'
PARENT_REVIEW = HERE.parent / 'c_887_bound_package/I21_SIX_ROUND_ENERGY_STATE_REPLAY.json'
OUT = HERE / 'c887_I21_sharp_complete_screen'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(SHARP.__file__) == 'f9ca410dbb44168c342e7d4aa80d34a863c3e113323df73630d88ef88f1294ce'
assert not OUT.exists()
parent_hash, review_hash = sha(PARENT), sha(PARENT_REVIEW)
assert parent_hash=='caa176c72bc4eecd0c199837a334433f5bcf7570f9f6cdd14cd13d88711f18d3'
producer=HERE/'c887_sharp_complement_bounds.py'
assert sha(producer)=='e394a7ecb6df2cc618f26f7d23dcd6cb95bddb18dd3eb30e8316c31a11d867ff'
sources={str(p):sha(p)for p in(PARENT,PARENT_REVIEW,Path(SHARP.__file__),producer,Path(__file__).resolve())}
parent, batch_review = json.loads(PARENT.read_text()), json.loads(PARENT_REVIEW.read_text())
assert batch_review['status']=='PASS_LISTED_BOUND_STATES'and len(batch_review['tile_reports'])==1
review=batch_review['tile_reports'][0]
assert review['certificate_sha256'] == parent_hash
assert review['status'] == 'PASS_CERTIFIED_TILE_STATE_OPEN'
assert review['tile'] == [2, 1]
assert parent['status'] == 'OPEN' and len(parent['rounds']) == 6 and parent['final_test']['round']==6
parent_ref = dict(path=str(PARENT), sha256=parent_hash, schema=parent['schema'])
differences = {tuple(entry['pair']): entry['intervals'] for entry in parent['final']['differences']}
rows = SHARP.complete_rows(SHARP.AHID, '1/200', '53/100')
children = []
for index, row in enumerate(rows):
    lower = SHARP.lower_lhs(row, parent['final']['positions'], parent['final']['scalar'], differences)
    entry = dict(index=index, row=SHARP.literal(row))
    if lower > row[1]:
        entry.update(kind='interval_exclusion',
                     evidence=dict(lower_lhs=str(lower), rhs=str(row[1]), positive_gap=str(lower-row[1])))
    else:
        entry.update(kind='pending_bound_screen', output=str(OUT / ('branch_%02d' % index)))
    children.append(entry)
manifest = dict(
    schema='declared_inherited_CD_tile_sharp_guard_cover_v1',
    status='DISCOVERY_ONLY_NO_PARENT_CLOSURE',
    original_closure_credit=0, parent=parent_ref,
    parent_existing_exact_replay=dict(path=str(PARENT_REVIEW), sha256=review_hash),
    selected_row=list(SHARP.AHID), beta_bound='1/200', variation_bound='53/100',
    complete_closed_domains=20, closed_faces_retained=True,
    helper_sha256=sha(SHARP.__file__), sources=sources, children=children,
)
OUT.mkdir()
specification = OUT / 'COVER_SPECIFICATION.json'
specification.write_text(json.dumps(manifest, indent=2) + '\n')
specification_hash = sha(specification)


def save():
    for name,value in sources.items():assert sha(name)==value,name
    assert sha(PARENT) == parent_hash and sha(PARENT_REVIEW) == review_hash
    assert sha(specification) == specification_hash
    temporary = OUT / 'completed_discovery_manifest.json.partial'
    temporary.write_text(json.dumps(manifest, indent=2) + '\n')
    temporary.replace(OUT / 'completed_discovery_manifest.json')


for entry in children:
    index = entry['index']
    if entry['kind'] == 'interval_exclusion':
        print('EXACT_PARENT_INTERVAL_EXCLUSION', index, entry['evidence']['positive_gap'], flush=True)
        save()
        continue
    output = Path(entry.pop('output'))
    log = OUT / ('branch_%02d.log' % index)
    assert not output.exists() and not log.exists()
    print('START_CLOSED_SHARP_FAILURE_SCREEN', index, entry['row']['name'], flush=True)
    with log.open('w') as stream:
        result = subprocess.run([
            sys.executable, str(HERE / 'c887_sharp_complement_bounds.py'), str(PARENT), str(output),
            str(index), '--row', 'AHID', '--beta', '1/200', '--variation', '53/100', '--rounds', '0',
        ], stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, str(log)
    bound = output / 'bound_rounds.json'
    record = json.loads(bound.read_text())
    assert 'final' in record and record['sharp_restriction']['parent'] == parent_ref
    assert record['sharp_restriction']['conditional_row'] == entry['row']
    assert record['sharp_restriction']['branch'] == index
    assert len(record['rounds']) == 0
    entry.update(kind='bound_terminal' if record['status'] == 'CANDIDATE_CLOSED' else 'open_bound_state',
                 bound=dict(path=str(bound), sha256=sha(bound), schema=record['schema']),
                 status=record['status'], rounds=len(record['rounds']))
    save()
    print('FINISHED_CLOSED_SHARP_FAILURE_SCREEN', index, record['status'],
          record.get('terminal', {}).get('kind'), flush=True)
assert len(children) == 20 and all(e['kind'] != 'pending_bound_screen' for e in children)
if all(e['kind'] in ('interval_exclusion', 'bound_terminal') for e in children):
    complete = dict(manifest, schema='complete_inherited_CD_tile_sharp_guard_cover_v1',
                    status='COMPLETE_CANDIDATE_SHARP_COVER_REQUIRES_INDEPENDENT_REPLAY')
    (OUT / 'complete_cover.json').write_text(json.dumps(complete, indent=2) + '\n')
save()
print('COMPLETE_FINITE_C887_I21_SHARP_SCREEN', flush=True)
