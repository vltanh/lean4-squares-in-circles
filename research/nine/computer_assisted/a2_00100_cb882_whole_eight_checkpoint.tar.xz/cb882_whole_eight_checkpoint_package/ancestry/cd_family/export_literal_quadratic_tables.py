"""Export exact necessary-row tables without running any optimization."""
from pathlib import Path
from fractions import Fraction as F
import json,gzip
import quadratic_moment_pilot as P
import quadratic_owned_axis_union as U
import quadratic_global_nine_cardinality as G

HERE=Path(__file__).resolve().parent
def row_table(rows):
    return [dict(name=name,rhs=str(rhs),coefficients=[[k,str(c)]for k,c in co])for co,rhs,name in rows]

def export(path):
    path=Path(path).resolve();r=json.loads(path.read_text())
    assert r['status']=='OPEN'and r['stop_reason']=='bounded_square_budget_exhausted'
    for source,digest in r['sources'].items():assert P.P.sha(source)==digest
    state,dd,dg,prior=P.read_prefix(r['prior']['path']);assert prior==r['prior']
    rows,absolute,metadata,physical=P.collect(state,dd,dg,r['metadata']['rlt_mode'])
    assert metadata==r['metadata']and physical==r['physical_state']
    linears=rows[:metadata['initial_linear_rows']];newrows=rows[metadata['initial_linear_rows']:]
    for s in r['squares']:newrows.append(P.L.psd_square_row(tuple(map(F,s['coefficients'])),s['index']))
    box=P.P.box;f=physical;diff={tuple(v['pair']):box(v['intervals'])for v in f['differences']};diag={tuple(v['pair']):box(v['intervals'])for v in f['diagonal']}
    extra,guards=U.generate(box(f['angles']),diff,diag);assert guards==r['owned_axis_union_guards'];newrows+=extra
    extra,guards=G.generate(box(f['positions']));assert guards==r['all_nine_guards'];newrows+=extra
    data=dict(schema='same_original_quadratic_necessary_rows_literal_table_v1',id=r['id'],path=r['path'],
       status='OPEN_RESEARCH_NECESSARY_ROWS_ONLY',new_original_cells=0,whole_mask_closed=False,
       prior=r['prior'],source_moment=dict(path=str(path),sha256=P.P.sha(path)),physical_state=physical,
       original_linear_row_count=len(linears),rlt_sources=P.P.M.R.printed_rows(linears,set(metadata['rlt_source_indices'])),
       squares=[dict(index=s['index'],coefficients=s['coefficients'])for s in r['squares']],
       owned_axis_union_guards=r['owned_axis_union_guards'],all_nine_guards=r['all_nine_guards'],
       absolute_variable_bounds=list(map(str,absolute)),rows=row_table(newrows),
       source_hashes=dict(r['sources'],**{str(Path(__file__).resolve()):P.P.sha(__file__)}))
    out=HERE/'literal_quadratic_tables';out.mkdir(exist_ok=True);destination=out/(r['id']+'.json.gz')
    with gzip.GzipFile(filename=str(destination),mode='wb',mtime=0)as fp:fp.write(json.dumps(data,separators=(',',':')).encode())
    print(r['id'],'EXPORTED',len(newrows),'quadratic rows',len(data['rlt_sources']),'RLT premises',P.P.sha(destination),flush=True)
    return dict(id=r['id'],path=str(destination),sha256=P.P.sha(destination),rows=len(newrows),rlt_premises=len(data['rlt_sources']))

if __name__=='__main__':
    reports=[export(p)for p in sorted((HERE/'cardinality_moment').glob('*.json'))]
    (HERE/'literal_quadratic_tables'/'manifest.json').write_text(json.dumps(reports,indent=2)+'\n')
