import sys,json,time
from pathlib import Path
from fractions import Fraction as Q
import diagonal_pass as P
import correlated_capacity_rows as C
HERE=Path(__file__).resolve().parent
out=HERE/'capacity_screen';out.mkdir(exist_ok=True)
for p in sorted((HERE/'diagonal_results').glob('*.json')):
    start=time.monotonic();r=json.loads(p.read_text());f=r['final']
    _,_,choices=P.M.V.reconstruct(r['path'])
    s=dict(id=r['id'],path=r['path'],choices=choices,angles=P.box(f['angles']),positions=P.box(f['positions']),scalar=P.box(f['scalar']))
    ds={tuple(x['pair']):P.box(x['intervals'])for x in f['differences']};dg={tuple(x['pair']):P.box(x['intervals'])for x in f['diagonal']}
    rr,ab,tm,pos,sc,dd,gg=P.collect(s,ds,dg)
    extra,guards=C.generate_rows(dd,gg);rr+=extra
    h=P.M.highs(rr,len(ab));h.run();tc=P.terminal_record(rr,ab,h)
    data=dict(id=r['id'],source=str(p),source_sha256=P.sha(p),source_rounds=len(r['rounds']),new_capacity_rows=len(extra),guards=guards,
        phase_margin=float(h.getSolution().col_value[-1]),terminal=tc,status='CANDIDATE_CLOSED'if tc else'OPEN',seconds=time.monotonic()-start)
    (out/(r['id']+'.json')).write_text(json.dumps(data,indent=2)+'\n')
    print(r['id'],'newrows',len(extra),'phase',data['phase_margin'],data['status'],'sec',data['seconds'],flush=True)
