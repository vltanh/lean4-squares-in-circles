"""Independent polynomial/guard audit after complete inherited-prefix replay.

The producers enumerate candidate rows only. Every quadratic is reconstructed
by a separately written polynomial module; every RLT affine premise is rebuilt
in the same certified parent. OPEN numerical states grant no exclusion credit.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,time,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'a_family'))
sys.path.insert(0,str(HERE.parent))
import independent_moment_rows as I
import independent_owned_axis_union as O
from independent_nine_cardinality import physical_row as cardinality_row, original_data
import verify_diagonal_pass as V
from independent_diagonal_rows import intervals,physical_row as diagonal_row
from independent_correlated_capacity import physical_row as capacity_row
import quadratic_moment_pilot as PRODUCER
import quadratic_owned_axis_union as UNION_PRODUCER
import quadratic_global_nine_cardinality as CARDINALITY_PRODUCER

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(row):
    co,rhs,name=row;cc={}
    for k,c in co:cc[k]=cc.get(k,F(0))+c
    return tuple((k,c)for k,c in sorted(cc.items())if c),rhs,name

def replay(path):
    begin=time.monotonic();path=Path(path);r=json.loads(path.read_text())
    for source,digest in r['sources'].items():assert sha(source)==digest,(source,'source changed')
    assert sha(r['prior']['path'])==r['prior']['sha256']
    prior,state,diag=V.replay(r['prior']['path'])
    assert r['id']==state['id']and r['path']==state['path']
    base,_,pos,scalar,diff,guards=V.K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
    diagonal=intervals(diff,diag);f=r['physical_state']
    assert f['angles']==V.K.view(state['angles'])and f['positions']==V.K.view(pos)and f['scalar']==V.K.view(scalar)
    assert f['differences']==V.K.diffview(diff)and f['diagonal']==V.K.diffview(diagonal)
    # Producer enumeration is not a premise. Its source rows are checked below.
    ss,dd,dg,source=PRODUCER.read_prefix(r['prior']['path'])
    rows,absolute,meta,physical=PRODUCER.collect(ss,dd,dg,r['metadata']['rlt_mode'])
    assert meta==r['metadata']and physical==r['physical_state']
    assert absolute==I.lifted_absolute_bounds(pos,scalar)
    rebuilt_affine={}
    def affine_source(index):
        assert type(index)is int and 0<=index<meta['initial_linear_rows']
        if index not in rebuilt_affine:
            produced=rows[index];name=produced[2]
            if index<len(base):correct=base[index]
            elif name.startswith(('correlated_rotated_','correlated_diagonal_altitude_')):correct=capacity_row(name,diff,diagonal)
            elif name.startswith('correlated_'):correct=diagonal_row(name,scalar,diff,diagonal)
            else:correct=V.J.rebuild_joint(name,scalar,diff,state['angles'],V.J.point_row)
            assert canonical(produced)==canonical(correct),(index,name,'affine source')
            rebuilt_affine[index]=canonical(correct)
        return rebuilt_affine[index]
    moment=I.Rebuilder(pos,scalar,state['angles'],diff,diagonal,r['squares'],affine_source,meta['initial_linear_rows'])
    count=0
    for produced in rows[meta['initial_linear_rows']:]:
        assert canonical(produced)==canonical(moment.rebuild(produced[2])),produced[2]
        count+=1
    for square in r['squares']:
        name='moment_psd_square_'+str(square['index']);correct=moment.rebuild(name)
        q=tuple(map(F,square['coefficients']));assert canonical(correct)==canonical(PRODUCER.L.psd_square_row(q,square['index']))
        count+=1
    owned=None;owned_count=0;comparisons=0
    if 'owned_axis_union_guards'in r:
        owned=O.Replay(state['angles'],diff,diagonal,r['owned_axis_union_guards'])
        candidates,g=UNION_PRODUCER.generate(state['angles'],diff,diagonal)
        assert g==r['owned_axis_union_guards']
        assert len(candidates)==r['owned_axis_union_rows']==len(owned.rows)
        for produced in candidates:assert canonical(produced)==canonical(owned.rows[produced[2]])
        owned_count=len(candidates);comparisons=owned.projection_comparisons
    global_count=0
    if 'all_nine_guards'in r:
        candidates,g=CARDINALITY_PRODUCER.generate(pos)
        assert g==r['all_nine_guards']and len(candidates)==r['all_nine_rows']
        u,info=original_data(pos)
        assert F(g['near_norm_upper'])==u
        assert g['far']==[i for i,(_,_,c)in enumerate(info)if c=='far']
        assert g['constant_indicator_upper']==[i for i,(_,_,c)in enumerate(info)if c=='constant']
        assert g['radial_indicator_upper']==[i for i,(_,_,c)in enumerate(info)if c=='radial']
        for produced in candidates:assert canonical(produced)==canonical(cardinality_row(produced[2],pos))
        global_count=len(candidates)
    reserve=None;terminal_rows=0
    if r['status']=='CANDIDATE_CLOSED':
        terminal=r['terminal'];assert terminal['kind']=='positive_exact_reserve'
        entries=terminal['printed_rows'];indices=[e['index']for e in entries]
        assert len(indices)==len(set(indices))and set(indices)=={k for k,w in terminal['weights']}
        checked=[((),F(0),'UNUSED')]*(max(indices)+1)
        for entry in entries:
            index=entry['index'];name=entry['name']
            if name.startswith('moment_'):correct=moment.rebuild(name)
            elif name.startswith('owned_axis_'):assert owned is not None;correct=owned.rows[name]
            elif name.startswith('all_nine_'):correct=cardinality_row(name,pos)
            else:correct=affine_source(index)
            printed=(tuple((k,F(c))for k,c in entry['coefficients']),F(entry['rhs']),name)
            assert canonical(printed)==canonical(correct)
            checked[index]=canonical(correct)
        assert terminal['absolute_variable_bounds']==list(map(str,absolute))
        co,rhs=V.K.sum_rows(checked,absolute,terminal['weights'])
        reserve=-rhs-sum(a*abs(c)for a,c in zip(absolute,co))
        assert reserve>0 and reserve==F(terminal['reserve'])and rhs==F(terminal['weighted_rhs'])
        assert co==list(map(F,terminal['weighted_coefficients']))
        terminal_rows=len(entries)
    else:assert r['status']=='OPEN'
    report=dict(id=r['id'],status='PASS_COMPLETE_ORIGINAL_PARENT'if reserve is not None else'PASS_NECESSARY_QUADRATIC_ROWS_PARENT_OPEN',
      prior_report=prior,quadratic_and_rlt_rows=count,rlt_affine_premises=len(rebuilt_affine),
      owned_axis_rows=owned_count,owned_axis_radical_comparisons=comparisons,all_nine_rows=global_count,
      terminal_rows=terminal_rows,reserve=str(reserve),new_original_cells=int(reserve is not None),whole_mask_closed=False,
      certificate_sha256=sha(path),reviewer_sha256=sha(__file__),independent_polynomial_sha256=sha(I.__file__),
      independent_owned_axis_sha256=sha(O.__file__),independent_all_nine_sha256=sha(HERE/'independent_nine_cardinality.py'),
      seconds=time.monotonic()-begin,lean_lake_ci_run=False)
    out=HERE/'quadratic_extension_reviews';out.mkdir(exist_ok=True)
    (out/(r['id']+'-'+r['schema']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='prior_report'}),flush=True)
    return report

if __name__=='__main__':
    for path in sys.argv[1:]:replay(path)
