"""Final bounded degree-two pilot with shared all-nine cardinality rows."""
from pathlib import Path
from fractions import Fraction as Q
import json,sys,time
import numpy as np
import quadratic_moment_pilot as P
import quadratic_owned_axis_union as U
import quadratic_global_nine_cardinality as G
from independent_nine_cardinality import physical_row as independent_global_row

HERE=Path(__file__).resolve().parent

def run(prior_path,rounds=4,lp_seconds=60):
    started=time.monotonic();prior_path=Path(prior_path).resolve();old=json.loads(prior_path.read_text())
    assert old['status']=='OPEN'and old.get('stop_reason')=='bounded_square_budget_exhausted'
    state,dd,dg,prior=P.read_prefix(old['prior']['path']);assert prior==old['prior']
    rows,absolute,meta,physical=P.collect(state,dd,dg,old['metadata']['rlt_mode'])
    assert meta==old['metadata']and physical==old['physical_state']
    original_linear_rows=list(rows[:meta['initial_linear_rows']])
    box=P.P.box;angles=box(physical['angles']);pos=box(physical['positions']);bounds=pos+box(physical['scalar'])
    diff={tuple(x['pair']):box(x['intervals'])for x in physical['differences']};diag={tuple(x['pair']):box(x['intervals'])for x in physical['diagonal']}
    squares=list(old['squares']);known=set()
    for s in squares:
        q=tuple(map(Q,s['coefficients']));assert s['index']==len(known)and q not in known
        rows.append(P.L.psd_square_row(q,s['index']));known.add(q)
    owned,guards=U.generate(angles,diff,diag);assert guards==old['owned_axis_union_guards'];rows+=owned
    extra,global_guards=G.generate(pos)
    for co,rhs,name in extra:assert(co,rhs,name)==independent_global_row(name,pos)
    rows+=extra
    record=dict(schema='same_original_quadratic_all_nine_cardinality_probe_v1',id=state['id'],path=state['path'],
       prior=prior,prior_moment=dict(path=str(prior_path),sha256=P.P.sha(prior_path)),physical_state=physical,
       metadata=meta,status='OPEN',scope='WHOLE_UNCHANGED_ORIGINAL_PARENT',maximum_new_rounds=rounds,new_branch_nodes=0,
       inherited_squares=len(squares),squares=squares,rounds=[],owned_axis_union_rows=len(owned),owned_axis_union_guards=guards,
       all_nine_rows=len(extra),all_nine_guards=global_guards,
       sources={str(Path(p).resolve()):P.P.sha(p)for p in(__file__,G.__file__,U.__file__,P.__file__,P.L.__file__,HERE/'independent_nine_cardinality.py')})
    out=HERE/'cardinality_moment';out.mkdir(exist_ok=True);dest=out/(state['id']+'.json')
    def save():
        record['seconds']=time.monotonic()-started;dest.write_text(json.dumps(record,indent=2)+'\n')
    save();h=P.P.M.highs(rows,P.L.SIZE);h.setOptionValue('solver','ipm')
    print(state['id'],'ALL NINE INITIAL','rows',len(rows),'new',len(extra),'inherited squares',len(squares),flush=True)
    for ri in range(rounds+1):
        h.setOptionValue('time_limit',h.getRunTime()+lp_seconds);h.run();status=h.getModelStatus()
        item=dict(round=ri,rows=len(rows),solver_status=str(status));record['rounds'].append(item)
        if status!=P.P.M.H.HighsModelStatus.kOptimal:
            record['stop_reason']='bounded_lp_limit_or_nonoptimal';save();break
        solution=h.getSolution();values=np.array(solution.col_value[:P.L.SIZE]);item['phase_margin']=float(solution.col_value[-1])
        terminal=P.exact_terminal(rows,absolute,solution)
        if terminal and terminal['kind']=='positive_exact_reserve':
            source_ids={int(v['name'].split('_')[3])for v in terminal['printed_rows']if v['name'].startswith(('moment_rlt_lower_','moment_rlt_upper_'))}
            terminal['rlt_source_rows']=P.P.M.R.printed_rows(original_linear_rows,source_ids)
            record.update(status='CANDIDATE_CLOSED',terminal=terminal);save();break
        if terminal:item['rejected_terminal']=terminal
        proposals,ev=P.discover_squares(values,bounds,24,known)
        item.update(minimum_normalized_eigenvalue=float(ev[0]),negative_eigenvalues=int(sum(ev< -1e-7)),proposed_squares=len(proposals))
        print(state['id'],'ALL NINE ROUND',ri,'phase',item['phase_margin'],'minEig',float(ev[0]),'cuts',len(proposals),flush=True)
        if ri==rounds or not proposals:
            record['stop_reason']='bounded_square_budget_exhausted'if ri==rounds else'no_new_violated_rational_square'
            record['relaxed_original_variables']=list(map(float,values[:P.L.N]));save();break
        for q,row,eigenvalue,violation in proposals:
            index=len(record['squares']);assert row[2]==f'moment_psd_square_{index}'
            record['squares'].append(dict(index=index,coefficients=list(map(str,q)),discovery_eigenvalue=eigenvalue,
               discovery_violation=violation,installed_after_cardinality_round=ri))
            known.add(q);rows.append(row)
            co,rhs,name=row;indices=np.array([k for k,v in co]+[P.L.SIZE],dtype=np.int32)
            vv=np.array([float(v)for k,v in co]+[-1.],dtype=np.float64)
            h.addRow(-np.inf,float(rhs),len(indices),indices,vv)
        save()
    print(state['id'],'ALL NINE RESULT',record['status'],record.get('stop_reason',''),'seconds',round(time.monotonic()-started,2),flush=True)
    return record

if __name__=='__main__':run(sys.argv[1])
