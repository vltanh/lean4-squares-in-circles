"""Bounded IPM adaptation of the same exact moment-row pilot."""
import sys
import quadratic_moment_pilot as P

original_highs=P.P.M.highs
def ipm(rows,n):
    h=original_highs(rows,n)
    h.setOptionValue('solver','ipm')
    return h

if __name__=='__main__':
    P.P.M.highs=ipm
    P.run(sys.argv[1],rounds=12,cuts=24,rlt='core',lp_seconds=60,tag='ipm')
