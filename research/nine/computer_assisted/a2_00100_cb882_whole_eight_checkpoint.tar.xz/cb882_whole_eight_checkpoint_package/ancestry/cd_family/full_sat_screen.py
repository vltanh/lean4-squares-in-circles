"""Bounded full-eight-owned-axis pair cover, from frozen complete prefixes."""
from pathlib import Path
import sys,json,time,itertools
import diagonal_pass as P
import correlated_capacity_rows as C
HERE=Path(__file__).resolve().parent

def run(ident,pairs):
    out=HERE/'full_sat';out.mkdir(exist_ok=True);(out/'prefixes').mkdir(exist_ok=True)
    frozen=out/'prefixes'/(ident+'.json');destination=out/(ident+'.json')
    if destination.exists():
        record=json.loads(destination.read_text());assert P.sha(frozen)==record['prior_sha256']
        r=json.loads(frozen.read_text())
    else:
        source=HERE/'diagonal_results'/(ident+'.json');data=source.read_bytes();r=json.loads(data);frozen.write_bytes(data)
        record=dict(id=ident,path=r['path'],schema='complete_owned_axis_static_pair_cover_v1',prior=str(frozen),prior_sha256=P.sha(frozen),pairs=[],status='OPEN')
    f=r['final'];_,_,choices=P.M.V.reconstruct(r['path'])
    state=dict(id=ident,path=r['path'],choices=choices,angles=P.box(f['angles']),positions=P.box(f['positions']),scalar=P.box(f['scalar']))
    dd={tuple(x['pair']):P.box(x['intervals'])for x in f['differences']};dg={tuple(x['pair']):P.box(x['intervals'])for x in f['diagonal']}
    for i,j in pairs:
        if any(pp['pair']==[i,j]and len(pp['cases'])==8 for pp in record['pairs']):continue
        if any(pair==(i,j)and kind=='sat'for pair,kind,ch in choices):continue
        cases=[];start=time.monotonic()
        for owner,axis,sign in itertools.product((i,j),(0,1),(-1,1)):
            step=['sat',[i,j],[owner,axis,sign]];path=state['path']+[step]
            _,_,ch=P.M.V.reconstruct(path);ss=dict(state,path=path,choices=ch)
            item=dict(owner=owner,axis=axis,sign=sign,status='OPEN',path=path)
            try:
                rows,ab,tm,pos,sc,dt,gt=P.collect(ss,dd,dg)
                item.update(rows=len(rows),propagated_positions=P.M.render(pos),physical_scalar_intersection=P.M.render(sc),effective_differences=P.M.render_diff(dt),effective_diagonal=P.M.render_diff(gt))
                if tm:item.update(status='CANDIDATE_CLOSED',terminal={'kind':'exact_interval_terminal','label':tm})
                else:
                    extra,guards=C.generate_rows(dt,gt);rows+=extra;item.update(rows=len(rows),capacity_guards=guards)
                    h=P.M.highs(rows,len(ab));h.run()
                    if h.getModelStatus()==P.M.H.HighsModelStatus.kOptimal:
                        item['phase_margin']=float(h.getSolution().col_value[-1]);tc=P.terminal_record(rows,ab,h)
                        if tc:item.update(status='CANDIDATE_CLOSED',terminal=tc)
                        else:item['relaxed_original_variables']=list(map(float,h.getSolution().col_value[:54]))
            except Exception as e:
                import traceback;item['diagnostic_error']=traceback.format_exc()
            cases.append(item)
        complete=all(s['status']=='CANDIDATE_CLOSED'for s in cases)
        record['pairs'].append(dict(pair=[i,j],cases=cases,status='COMPLETE_CANDIDATE_PARENT_COVER'if complete else'OPEN_PARENT',seconds=time.monotonic()-start))
        if complete:record['status']='CANDIDATE_CLOSED'
        destination.write_text(json.dumps(record,indent=2)+'\n')
        print(ident,'SAT',i,j,'closed',sum(s['status']=='CANDIDATE_CLOSED'for s in cases),'/8',record['status'],'seconds',round(time.monotonic()-start,2),flush=True)
        if complete:break
    return record
if __name__=='__main__':
    ids=sys.argv[1:]or['negative-6181e7007bf6714b','negative-95371f658da581d0','positive-a4979e5f2a7e8734']
    for ident in ids:run(ident,[(7,8),(5,7),(5,8)])
