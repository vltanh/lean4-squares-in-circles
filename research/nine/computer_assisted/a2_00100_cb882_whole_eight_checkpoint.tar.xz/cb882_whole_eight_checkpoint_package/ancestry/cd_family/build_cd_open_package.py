"""Assemble the frozen C/D OPEN research package and exact replay bindings."""
from pathlib import Path
import json,gzip,hashlib,shutil,os

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=Path('/workspace/scratch/29af4f6e10bf')
DEST=ROOT/'cd_family_open_package_20261103'
DEST.mkdir(exist_ok=True)
BINDINGS={};HASH_PATH={};FILES={};QUEUE=[];SEEN=set()
IDS=['negative-6181e7007bf6714b','negative-95371f658da581d0','positive-a4979e5f2a7e8734']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def destination(p):
    if p.is_relative_to(HERE):
        rel=p.relative_to(HERE)
        if rel.parts[0]in('replay_reports','diagonal_replay_reports','full_sat_reviews','quadratic_extension_reviews','literal_quadratic_reviews'):
            return Path('frozen_reports')/rel
        return Path('cd_family')/rel
    if p.is_relative_to(OLD):return Path('legacy')/p.relative_to(OLD)
    if p==ROOT/'owned_axis_independent_review.json':return Path('frozen_reports')/p.name
    if p.is_relative_to(ROOT/'a_family'):return Path('a_family')/p.relative_to(ROOT/'a_family')
    if p==ROOT/'independent_owned_axis_union.py':return Path(p.name)
    return Path('source_snapshots')/(sha(p)[:16]+'_'+p.name)
def add(p,rel=None,follow=False):
    p=Path(p).resolve();assert p.is_file(),p
    rel=Path(rel)if rel is not None else destination(p);target=DEST/rel
    digest=sha(p)
    if str(p)in BINDINGS:
        assert sha(DEST/BINDINGS[str(p)])==digest
    else:BINDINGS[str(p)]=str(rel)
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert sha(target)==digest,(target,'existing package byte changed')
    elif digest in HASH_PATH:os.link(DEST/HASH_PATH[digest],target)
    else:shutil.copyfile(p,target)
    HASH_PATH.setdefault(digest,str(rel));FILES[str(rel)]=digest
    if follow and p not in SEEN:QUEUE.append(p);SEEN.add(p)
    return str(rel)
def references(value):
    if isinstance(value,dict):
        for k,v in value.items():yield from references(k);yield from references(v)
    elif isinstance(value,list):
        for v in value:yield from references(v)
    elif isinstance(value,str)and value.startswith('/workspace/'):
        p=Path(value)
        if p.is_file():yield p

# Frozen producers, exact reviewers, and mathematical derivations.
for p in HERE.glob('*.py'):
    if p.name not in('five_cap_probe.py',):add(p)
for p in HERE.glob('*.md'):add(p)
add(ROOT/'a_family/independent_moment_rows.py')
add(ROOT/'independent_owned_axis_union.py');add(ROOT/'owned_axis_independent_review.json')
for name in('all_nine_cardinality_literal_row_tables.json','all_nine_cardinality_global_review.json'):
    add(HERE/name)

# Complete geometric records and all stopping records; no partial cover is used.
for directory in('results','diagonal_results','full_sat','moment_results','owned_axis_union','cardinality_moment','literal_quadratic_tables','capacity_screen'):
    for p in(HERE/directory).rglob('*'):
        if p.is_file()and(p.suffix=='.json'or p.name.endswith('.json.gz')):add(p,follow=True)
for directory in('replay_reports','diagonal_replay_reports','full_sat_reviews','quadratic_extension_reviews','literal_quadratic_reviews'):
    for p in(HERE/directory).glob('*.json'):add(p)

# Accepted independent baseline. Its original index hashes remain unchanged.
base=OLD/'current_proof'
for name in('verify_joint_original.py','independent_all_rules.py','original_register.json'):add(base/name)
bundle=base/'shared_capacity_three_b_v4'
index=json.loads((bundle/'replay_index.json').read_text())
for name in('verify_shared_bound.py','independent_v4_rows.py','replay_index.json',index['baseline_register']):add(bundle/name)
for name in index['frozen_files']:add(bundle/name)
for dirname in('geometry','sources'):
    for p in(bundle/dirname).glob('*'):
        if p.is_file()and p.suffix in('.py','.json'):add(p)

while QUEUE:
    p=QUEUE.pop()
    if p.name.endswith('.json.gz'):
        with gzip.open(p,'rt')as fp:value=json.load(fp)
    elif p.suffix=='.json':value=json.loads(p.read_text())
    else:continue
    for ref in references(value):
        add(ref,follow=ref.suffix=='.json'or ref.name.endswith('.json.gz'))

# Mathematical premises referenced by the new hand proofs.
notes=ROOT/'pr11/research/nine'
for name in('SMALLER_CENTRAL_DISKS_NINE_UNIT_CAPACITY.md','ORIGINAL_SUPPORT_HEIGHT_PAIR_HAND_PROOF.md',
 'OWNER_FREE_RELATIVE_SUPPORT_HAND_PROOF.md','ORIGINAL_POINT_INCIRCLE_FRAME_COUPLING_HAND_PROOF.md',
 'INSET_SEPARATION_QUADRATIC_FAMILY_HAND_PROOF.md','THREE_ORIGINAL_ALTITUDE_CAPACITY_HAND_PROOF.md',
 'THREE_ORIGINAL_SHARP_STRIP_CAPACITY_HAND_PROOF.md','ORIGINAL_FRAME_PERSPECTIVE_AND_DIRECTIONAL_SUPPORT_HAND_PROOF.md',
 'A2_00100_ORIGINAL_FRAME_BOUND_HAND_PROOF.md','WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md'):
    add(notes/name,Path('hand_premises')/name)
review=notes/'reviews/2026-10-27/REVIEW_SMALLER_CENTRAL_DISKS_AND_C5_S124_DOMAIN_TRIANGLE_BRIDGES_2026_10_27.md'
add(review,Path('hand_premises')/review.name)
add(ROOT/'global_masks/GLOBAL_NINE_CENTRAL_CAPACITY_ROWS.md',Path('hand_premises/GLOBAL_NINE_CENTRAL_CAPACITY_ROWS.md'))
add(HERE/'portable_replay_template.py','replay.py')

jobs=[dict(kind='complete_pair_covers',file=BINDINGS[str(HERE/'full_sat'/(i+'.json'))])for i in IDS]
jobs += [dict(kind='literal_quadratic_rows',file=BINDINGS[str(HERE/'literal_quadratic_tables'/(i+'.json.gz'))])for i in IDS[1:]]
readme='''# Completed C/D OPEN research checkpoint

This package adds **zero original cells** and **zero complete masks**. It leaves
the fixed 231-cell and 32-mask registers unchanged. All nine original squares,
the inherited original paths, and the actual CD bits are retained.

Run the exact portable review with Python3.12 or later:

    python replay.py

The default replay uses only the standard library. It imports no numerical
producer, NumPy, SciPy, HiGHS, Lean, Lake, or CI. It verifies all frozen file
hashes, rejects reads from unbound external workspace paths, replays the complete
inherited prefixes, checks all72 signed owned-axis alternatives, and reconstructs
both final literal quadratic tables. The historical absolute source names in
certificates are resolved by SOURCE_BINDINGS.json. Frozen historical reports
are kept separately from newly produced replay reports.

## Complete bounded outcomes

| Original | H/I exact/open | F/H exact/open | F/I exact/open | Result |
|---|---:|---:|---:|---|
| negative-6181e7007bf6714b |0/8|2/6|0/8|OPEN|
| negative-95371f658da581d0 |2/6|2/6|2/6|OPEN|
| positive-a4979e5f2a7e8734 |0/8|4/4|1/7|OPEN|

All72 alternatives were checked:13 exact terminals and59 OPEN alternatives.
No eight-way pair cover is complete, so none closes its original parent.

The preceding exact whole-parent arc unions install160 bounds on C953 and190
on D a497. Four correlated-diagonal rounds then install547,240,583 bounds on
C618,C953,D a497 respectively. Each of these unchanged original parents remains
OPEN. The package contains every dual table and the full independent replay.

The two bounded shared-moment pilots use all54 original variables and1,485
shared product coordinates. The initial12-round runs remain OPEN after273/264
rational square cuts. A separate four-round complete-owned-axis continuation
adds89/92 squares, and a final four-round all-nine-cardinality continuation
adds90/89 squares. Final totals are452/445 rational squares. All declared runs
have finished; no recursive descendant tree or additional optimization gate is
left running.

The final literal tables contain52,501 and55,085 necessary quadratic rows,
including401/425 independently reconstructed affine RLT premises,517 owned-axis
rows per parent, and25/24 global all-nine rows. Their validity is independently
checked; they supply no positive exact terminal. The final numerical moment
matrices still have negative eigenvalues. Thus these are neither physical
packings nor feasibility/counterexample certificates.

## Mathematical and replay scope

Read the hand proofs in cd_family/ for the correlated diagonal bounds, shared
quadratic identities, complete-owned-axis union inequalities, and all-nine
radial/cardinality rows. The accepted geometric premises are included under
hand_premises/. The separately written polynomial, signed-radical, and global
cardinality checkers are included with their frozen reports.

The shared global-cardinality review also records necessary-row checks on two B
states. Those B state closures are outside this C/D package's default replay and
grant no credit here. Discovery producers are preserved for provenance but are
not executed by replay.py. Re-running numerical discovery would require the
original NumPy/SciPy environment and is not part of this stopping checkpoint.

The fixed C8+D4 family remains open at the gate level. This package preserves
completed reusable bounds and exact necessary-row proofs; a full original
contradiction or a stronger physical all-nine theorem is still needed.
'''
(DEST/'README.md').write_text(readme)
(DEST/'SOURCE_BINDINGS.json').write_text(json.dumps(dict(sorted(BINDINGS.items())),indent=2)+'\n')
FILES['README.md']=sha(DEST/'README.md');FILES['SOURCE_BINDINGS.json']=sha(DEST/'SOURCE_BINDINGS.json')
manifest=dict(schema='cd_open_research_frozen_package_v1',scope='COMPLETE_BOUNDED_CD_RESEARCH_ALL_TESTED_ORIGINALS_OPEN',
  new_original_cells=0,whole_masks_closed=0,fixed_original_count=231,fixed_mask_count=32,
  tested_originals=IDS,quadratic_tested_originals=IDS[1:],exact_pair_alternatives=13,open_pair_alternatives=59,
  replay_jobs=jobs,historical_source_bindings=len(BINDINGS),frozen_file_sha256=dict(sorted(FILES.items())),
  no_optimization_in_default_replay=True,lean_lake_ci_run=False)
(DEST/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(package=str(DEST),frozen_files=len(FILES),source_bindings=len(BINDINGS),manifest_sha256=sha(DEST/'MANIFEST.json'))),flush=True)
