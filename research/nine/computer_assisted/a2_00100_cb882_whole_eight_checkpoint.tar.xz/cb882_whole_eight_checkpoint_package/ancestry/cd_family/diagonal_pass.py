#!/usr/bin/env python3
"""Exact-dual discovery of correlated pair-diagonal whole-parent bounds."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,argparse,hashlib
from pathlib import Path
from fractions import Fraction as Q
OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof')
sys.path.insert(0,str(OLD))
import v3_whole_parent_pass as M
import diagonal_rows as D
HERE=Path(__file__).resolve().parent
EPS=Q(1,2000)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(x):return tuple(tuple(Q(z)for z in ab)for ab in x)
def view(s,d,g):return dict(angles=M.render(s['angles']),positions=M.render(s['positions']),scalar=M.render(s['scalar']),differences=M.render_diff(d),diagonal=M.render_diff(g))
def load(ident,arc=False):
    p=(HERE/'results'if arc else OLD/'v3_results')/(ident+'.json');r=json.loads(p.read_text())
    _,_,choices=M.V.reconstruct(r['path'])
    if arc:
        rr=r['final'];angles=rr['angles'];positions=rr['positions'];scalar=rr['scalar'];diff=rr['differences']
    else:angles=r['final_angles'];positions=r['final_positions'];scalar=r['final_scalar'];diff=r['final_differences']
    s=dict(id=ident,path=r['path'],choices=choices,angles=box(angles),positions=box(positions),scalar=box(scalar))
    return s,{tuple(x['pair']):box(x['intervals'])for x in diff},dict(path=str(p),sha256=sha(p),kind='arc'if arc else'v3')
def collect(s,d,g):
    rows,absbound,terminal,pos,sc,diff,guards=M.collect(s,d)
    if terminal:return rows,absbound,terminal,pos,sc,diff,g
    diag=D.effective(diff,g)
    if any(a>b for vv in diag.values()for a,b in vv):return rows,absbound,'empty_correlated_diagonal',pos,sc,diff,diag
    rows+=D.rows(sc,diff,diag)
    return rows,absbound,None,pos,sc,diff,diag
def terminal_record(rows,ab,h):
    sol=h.getSolution()
    if sol.col_value[-1]<=1e-8:return None
    ws=M.terms(sol.row_dual);co,rhs=M.R.weighted_sum(rows,ab,ws);reserve=-rhs-sum(a*abs(v)for a,v in zip(ab,co))
    if reserve<=0:return None
    return dict(kind='positive_exact_reserve',weights=ws,reserve=str(reserve),printed_rows=M.R.printed_rows(rows,{i for i,w in ws}),absolute_variable_bounds=list(map(str,ab)),weighted_rhs=str(rhs),weighted_coefficients=list(map(str,co)))
def run(ident,rounds=4,arc=False):
    state,diffs,prior=load(ident,arc);diag={};start=time.monotonic()
    record=dict(schema='correlated_diagonal_whole_parent_v1',id=ident,path=state['path'],status='OPEN',prior=prior,rounds=[],
       sources={str(Path(__file__)):sha(__file__),str(Path(M.__file__)):sha(M.__file__),str(Path(D.__file__)):sha(D.__file__)})
    out=HERE/'diagonal_results';out.mkdir(exist_ok=True);dest=out/(ident+'.json')
    for ri in range(rounds+1):
        before=view(state,diffs,diag)
        rows,ab,term,pos,sc,dd,gg=collect(state,diffs,diag)
        item=dict(round=ri,before=before,rows=len(rows),propagated_positions=M.render(pos),physical_scalar_intersection=M.render(sc),effective_differences=M.render_diff(dd),effective_diagonal=M.render_diff(gg),proposals=[])
        if term:
            record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='exact_interval_terminal',label=term,state=item));break
        h=M.highs(rows,len(ab));h.run()
        if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:
            record.update(solver_status=str(h.getModelStatus()));break
        tc=terminal_record(rows,ab,h)
        if tc:record.update(status='CANDIDATE_CLOSED',terminal=dict(tc,state=item));break
        if ri==rounds:record['final_test']=item;break
        h.changeColCost(len(ab),0.);h.changeColBounds(len(ab),0.,0.)
        targets=[]
        for k,(lo,hi)in enumerate(pos+sc):
            for sign in(-1,1):targets.append(dict(kind='scalar',key=k,sign=sign,objective=[[k,sign]],old=hi if sign==1 else-lo))
        for kind,dictv in(('difference',dd),('diagonal',gg)):
            for (i,j),vv in sorted(dictv.items()):
                for axis,(lo,hi)in enumerate(vv):
                    for sign in(-1,1):
                        obj=[[2*j+axis,sign],[2*i+axis,-sign]]if kind=='difference'else[[2*j,sign],[2*i,-sign],[2*j+1,sign*(1 if axis==0 else-1)],[2*i+1,-sign*(1 if axis==0 else-1)]]
                        targets.append(dict(kind=kind,key=[i,j,axis],sign=sign,objective=obj,old=hi if sign==1 else-lo))
        np=[list(x)for x in pos];ns=[list(x)for x in sc];nd={k:[list(x)for x in v]for k,v in dd.items()};ng={k:[list(x)for x in v]for k,v in gg.items()}
        used=set();previous=[]
        for t in targets:
            for k,c in previous:h.changeColCost(k,0.)
            for k,c in t['objective']:h.changeColCost(k,-float(c))
            previous=t['objective'];h.setOptionValue('time_limit',h.getRunTime()+3.);h.run()
            if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:continue
            if float(t['old'])+h.getObjectiveValue()<float(EPS):continue
            ws=M.terms(h.getSolution().row_dual);co,rhs=M.R.weighted_sum(rows,ab,ws)
            for k,c in t['objective']:co[k]-=Q(c)
            correction=sum(a*abs(v)for a,v in zip(ab,co));proved=rhs+correction;upper=M.ceil_grid(proved)
            if t['old']-upper<EPS:continue
            p=dict(t,old=str(t['old']),upper=str(upper),proved_upper=str(proved),weights=ws,summed_rhs=str(rhs),residual_coefficients=[[k,str(v)]for k,v in enumerate(co)if v],residual_correction=str(correction))
            item['proposals'].append(p);used.update(i for i,w in ws)
            key=t['key'];sign=t['sign'];kind=t['kind']
            target=(np[key]if key<18 else ns[key-18])if kind=='scalar'else(nd if kind=='difference'else ng)[tuple(key[:2])][key[2]]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
        item['printed_rows']=M.R.printed_rows(rows,used);item['absolute_variable_bounds']=list(map(str,ab))
        pos=tuple(map(tuple,np));sc=tuple(map(tuple,ns));diffs={k:tuple(map(tuple,v))for k,v in nd.items()};diag={k:tuple(map(tuple,v))for k,v in ng.items()}
        if any(a>b for a,b in pos+sc)or any(a>b for zz in list(diffs.values())+list(diag.values())for a,b in zz):
            record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='empty_proved_interval'));break
        angles,contradiction,ids=M.R.infer_angles(state['angles'],sc);item['physical_frame_inferences']=ids
        if contradiction:record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind=contradiction));break
        analytic=M.K.analytic(angles);sc=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(sc,analytic))
        if any(a>b for a,b in sc):record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='empty_physical_frame'));break
        state.update(positions=pos,scalar=sc,angles=angles)
        item['after']=view(state,diffs,diag);record['rounds'].append(item)
        record['final']=view(state,diffs,diag);record['seconds']=time.monotonic()-start;dest.write_text(json.dumps(record,indent=2)+'\n')
        print(ident,'DIAGONAL ROUND',ri,len(item['proposals']),'seconds',round(record['seconds'],2),flush=True)
        if not item['proposals']:break
    record['final']=view(state,diffs,diag);record['seconds']=time.monotonic()-start;dest.write_text(json.dumps(record,indent=2)+'\n')
    print(ident,'DIAGONAL RESULT',record['status'],'seconds',round(record['seconds'],2),flush=True)
    return record
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('id');ap.add_argument('--rounds',type=int,default=4);ap.add_argument('--arc',action='store_true');a=ap.parse_args();run(a.id,a.rounds,a.arc)
