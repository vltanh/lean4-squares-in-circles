#!/usr/bin/env python3
"""Relocate frozen source names and replay the complete C/D OPEN checkpoint.

Only exact standard-library checkers are imported. Historical source names are
resolved through the explicit package binding table. An audit hook rejects any
unbound read from another /workspace directory, so existing scratch files cannot
silently supply a missing package dependency.
"""
from pathlib import Path
import sys,json,hashlib,copy,time
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
bindings=json.loads((ROOT/'SOURCE_BINDINGS.json').read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for name,expected in manifest['frozen_file_sha256'].items():
    assert digest(ROOT/name)==expected,('frozen package file changed',name)
def locate(name):
    p=Path(name);key=str(p)
    if key in bindings:return ROOT/bindings[key]
    if not p.is_absolute():return ROOT/p
    if p.is_relative_to(ROOT):return p
    raise FileNotFoundError('Historical path has no explicit package binding: '+key)
def bound_digest(name):return digest(locate(name))
def audit(event,args):
    if event=='open'and isinstance(args[0],str):
        p=Path(args[0])
        if p.is_absolute()and str(p).startswith('/workspace/')and not p.is_relative_to(ROOT):
            raise PermissionError('Unbound external workspace read rejected: '+str(p))
sys.addaudithook(audit)
legacy=ROOT/'legacy/current_proof'
for p in (ROOT,ROOT/'a_family',ROOT/'cd_family',legacy,legacy/'shared_capacity_three_b_v4',
          legacy/'shared_capacity_three_b_v4/geometry',legacy/'shared_capacity_three_b_v4/sources'):
    sys.path.insert(0,str(p))
import verify_joint_original as J
import review_guarded_frame_bounds_independent
import verify_arc_union as A
import verify_diagonal_pass as D
import verify_full_sat_screen as S
import verify_literal_quadratic_tables as Q
J.local_source=locate;J.digest=bound_digest
for module in (A,D,S):module.digest=bound_digest
Q.sha=bound_digest
def relocate_replay(module,cached=False):
    function=module.replay;cache={}
    def run(path,*args,**kwargs):
        target=locate(path)
        if not cached:return function(target,*args,**kwargs)
        key=(str(target),digest(target))
        if key not in cache:cache[key]=function(target,*args,**kwargs)
        return copy.deepcopy(cache[key])
    module.replay=run
relocate_replay(J)
relocate_replay(A,True)
relocate_replay(D,True)
relocate_replay(S)
relocate_replay(Q)
begin=time.monotonic();full=[];quadratic=[]
for job in manifest['replay_jobs']:
    if job['kind']=='complete_pair_covers':full.append(S.replay(ROOT/job['file']))
    elif job['kind']=='literal_quadratic_rows':quadratic.append(Q.replay(ROOT/job['file']))
    else:raise AssertionError(('unsupported replay job',job))
assert all(r['new_original_cells']==0 and r['whole_mask_closed']is False for r in full+quadratic)
assert not any(name in sys.modules for name in ('numpy','scipy','highspy'))
report=dict(schema='cd_open_research_portable_replay_v1',status='PASS_EXACT_REPLAY_ALL_PARENTS_OPEN',
   complete_pair_cover_reports=full,literal_quadratic_reports=quadratic,
   exact_excluded_alternatives=sum(p['exact_terminals']for r in full for p in r['pairs']),
   open_alternatives=sum(p['open_alternatives']for r in full for p in r['pairs']),
   new_original_cells=0,whole_masks_closed=0,numerical_producer_or_optimizer_imported=False,
   unbound_external_workspace_reads_allowed=False,lean_lake_ci_run=False,seconds=time.monotonic()-begin)
(ROOT/'PORTABLE_REPLAY_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in('complete_pair_cover_reports','literal_quadratic_reports')}),flush=True)
