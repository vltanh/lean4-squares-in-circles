"""Pair separation rows preserving correlated diagonal difference bounds.

For each physical pair, s=dx+dy, t=dx-dy are the same original
center displacement: |d|²=(s²+t²)/2. Their independently proved
intervals sharpen the quadratic secant and McCormick lower planes.
"""
from fractions import Fraction as Q
from itertools import combinations,product

def linear(box,p,q):
    return (min(p*box[0][0],p*box[0][1])+min(q*box[1][0],q*box[1][1]),
            max(p*box[0][0],p*box[0][1])+max(q*box[1][0],q*box[1][1]))
def project(box,diag,p,q):
    a,b=linear(box,p,q);c,d=linear(diag,(p+q)/2,(p-q)/2)
    return max(a,c),min(b,d)
def effective(differences,prior):
    out={}
    for pair,box in sorted(differences.items()):
        s=linear(box,Q(1),Q(1));t=linear(box,Q(1),Q(-1))
        dd=(s,t)
        if pair in prior:dd=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(dd,prior[pair]))
        out[pair]=dd
    return out
def clean(co,rhs,name):return tuple((k,v)for k,v in sorted(co.items())if v),rhs,name
def append_difference(i,j,cx,cy,extra,rhs,name):
    co={2*i:-cx,2*j:cx,2*i+1:-cy,2*j+1:cy};co.update(extra)
    return clean(co,rhs,name)
def rows(scalar,differences,diagonal):
    result=[]
    points=sorted({(Q(a,2),Q(b,2))for a,b in product(range(-2,3),repeat=2)if abs(a)==2 or abs(b)==2})
    for (i,j),dd in sorted(diagonal.items()):
        assert all(a<=b for a,b in dd)
        (a,b),(c,d)=dd
        for axis,(lo,hi)in enumerate(dd):
            sy=1 if axis==0 else-1
            for sign,upper in ((1,hi),(-1,-lo)):
                result.append(append_difference(i,j,Q(sign),Q(sign*sy),{},upper,
                    f'correlated_diagonal_bound_{i}_{j}_{axis}_{sign}'))
        dx=(a+b+c+d)/2;dy=(a+b-c-d)/2;dc=-(a*b+c*d)/2
        result.append(append_difference(i,j,-dx,-dy,{},dc-1,
                       f'correlated_diagonal_unit_distance_{i}_{j}'))
        gl=scalar[27+i][0]+scalar[27+j][0];gu=scalar[27+i][1]+scalar[27+j][1]
        for v in map(Q,('-7/8','-3/4','-1/2','-1/4','0','1/4','1/2','3/4','7/8')):
            p=(1-v)/2;q=(1+v)/2;r=1-v*v
            ex=p*(a+b)+q*(c+d);ey=p*(a+b)-q*(c+d);ec=-p*a*b-q*c*d
            for z in sorted({gl,(gl+gu)/2,gu,Q(1)}):
                result.append(append_difference(i,j,-ex,-ey,{45+i:2*r*z,45+j:2*r*z},r*z*z+ec,
                        f'correlated_diagonal_inset_ellipse_{i}_{j}_{v}_{z}'))
        for owner in(i,j):
            alpha,beta=scalar[owner],scalar[9+owner]
            for s,t in points:
                pb=project(differences[i,j],dd,s,t);qb=project(differences[i,j],dd,-t,s)
                assert pb[0]<=pb[1]and qb[0]<=qb[1]
                for ap,bp in product((0,1),repeat=2):
                    aa,pp=alpha[ap],pb[ap];bb,qq=beta[bp],qb[bp]
                    result.append(append_difference(i,j,aa*s-bb*t-dx,aa*t+bb*s-dy,
                         {18+owner:pp,27+owner:qq},dc+(s*s+t*t-1)/4+aa*pp+bb*qq,
                         f'correlated_point_incircle_{i}_{j}_{owner}_{s}_{t}_{ap}_{bp}'))
    return result
