"""Standard-library independent replay of literal necessary-row tables.

No numerical producer, LP solver, NumPy or SciPy is imported. The entire
inherited physical prefix is replayed, followed by every literal new row.
"""
from pathlib import Path
from fractions import Fraction as F
import json,gzip,sys,time,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'a_family'));sys.path.insert(0,str(HERE.parent))
import independent_moment_rows as I
import independent_owned_axis_union as O
import independent_nine_cardinality_global_review as G
import verify_diagonal_pass as V
from independent_diagonal_rows import intervals,physical_row as diagonal_row
from independent_correlated_capacity import physical_row as capacity_row

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(row):
    terms,rhs,name=row;co={}
    for k,c in terms:co[k]=co.get(k,F(0))+c
    return tuple((k,c)for k,c in sorted(co.items())if c),rhs,name
def printed(entry):return tuple((k,F(c))for k,c in entry['coefficients']),F(entry['rhs']),entry['name']

def replay(path):
    started=time.monotonic();path=Path(path)
    with gzip.open(path,'rt')as fp:r=json.load(fp)
    assert r['schema']=='same_original_quadratic_necessary_rows_literal_table_v1'
    assert r['status']=='OPEN_RESEARCH_NECESSARY_ROWS_ONLY'and r['new_original_cells']==0 and r['whole_mask_closed']is False
    for source,digest in r['source_hashes'].items():assert sha(source)==digest,(source,'source hash')
    assert sha(r['source_moment']['path'])==r['source_moment']['sha256']
    assert sha(r['prior']['path'])==r['prior']['sha256']
    prior,state,diag=V.replay(r['prior']['path']);assert r['id']==state['id']and r['path']==state['path']
    base,_,pos,scalar,diff,guards=V.K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
    diagonal=intervals(diff,diag);f=r['physical_state']
    assert f['angles']==V.K.view(state['angles'])and f['positions']==V.K.view(pos)and f['scalar']==V.K.view(scalar)
    assert f['differences']==V.K.diffview(diff)and f['diagonal']==V.K.diffview(diagonal)
    bounds=I.lifted_absolute_bounds(pos,scalar);assert r['absolute_variable_bounds']==list(map(str,bounds))
    sources={x['index']:x for x in r['rlt_sources']};assert len(sources)==len(r['rlt_sources'])
    checked={}
    def source(index):
        assert index in sources and 0<=index<r['original_linear_row_count']
        if index not in checked:
            entry=sources[index];name=entry['name']
            if index<len(base):correct=base[index]
            elif name.startswith(('correlated_rotated_','correlated_diagonal_altitude_')):correct=capacity_row(name,diff,diagonal)
            elif name.startswith('correlated_'):correct=diagonal_row(name,scalar,diff,diagonal)
            else:correct=V.J.rebuild_joint(name,scalar,diff,state['angles'],V.J.point_row)
            assert canonical(printed(entry))==canonical(correct),(index,name)
            checked[index]=canonical(correct)
        return checked[index]
    moment=I.Rebuilder(pos,scalar,state['angles'],diff,diagonal,r['squares'],source,r['original_linear_row_count'])
    owned=O.Replay(state['angles'],diff,diagonal,r['owned_axis_union_guards'])
    counts=dict(moment=0,owned_axis=0,all_nine=0)
    for entry in r['rows']:
        name=entry['name']
        if name.startswith('moment_'):correct=moment.rebuild(name);counts['moment']+=1
        elif name.startswith('owned_axis_'):correct=owned.rows[name];counts['owned_axis']+=1
        elif name.startswith('all_nine_'):correct=G.physical_row(name,pos);counts['all_nine']+=1
        else:raise AssertionError(('unsupported row',name))
        assert canonical(printed(entry))==canonical(correct),name
        assert all(type(k)is int and 0<=k<I.SIZE for k,c in correct[0])
    assert set(checked)==set(sources)
    assert counts['owned_axis']==len(owned.rows)
    report=dict(id=r['id'],status='PASS_ALL_LITERAL_NECESSARY_ROWS_PARENT_OPEN',prior_report=prior,
       rows=len(r['rows']),row_families=counts,rlt_affine_premises=len(checked),rational_squares=len(r['squares']),
       complete_signed_alternatives=owned.alternative_count,excluded_alternatives=owned.eliminated,
       radical_comparisons=owned.projection_comparisons,new_original_cells=0,whole_mask_closed=False,
       literal_table_sha256=sha(path),reviewer_sha256=sha(__file__),independent_polynomial_sha256=sha(I.__file__),
       independent_owned_axis_sha256=sha(O.__file__),independent_all_nine_sha256=sha(G.__file__),
       seconds=time.monotonic()-started,lean_lake_ci_run=False,numerical_producer_or_optimizer_imported=False)
    out=HERE/'literal_quadratic_reviews';out.mkdir(exist_ok=True)
    (out/(r['id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='prior_report'}),flush=True)
    return report

if __name__=='__main__':
    for path in sys.argv[1:]:replay(path)
