#!/usr/bin/env python3
"""Whole-parent original-frame disjunctive bound discovery with exact duals.

This producer is untrusted. Its finite arc covers retain every closed face;
each installed objective is proved on every nonexcluded arc child.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import sys, json, time, argparse, hashlib, traceback
from pathlib import Path
from fractions import Fraction as Q
OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof')
sys.path.insert(0,str(OLD))
import v3_whole_parent_pass as M
HERE=Path(__file__).resolve().parent
GRID=1<<20
EPS=Q(1,2000)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(x):return tuple(tuple(Q(y)for y in z)for z in x)
def encode(s,d):
    return dict(angles=M.render(s['angles']),positions=M.render(s['positions']),
                scalar=M.render(s['scalar']),differences=M.render_diff(d))
def load(ident):
    p=OLD/'v3_results'/(ident+'.json');r=json.loads(p.read_text())
    _,_,ch=M.V.reconstruct(r['path'])
    s=dict(id=ident,path=r['path'],choices=ch,angles=box(r['final_angles']),
           positions=box(r['final_positions']),scalar=box(r['final_scalar']))
    d={tuple(t['pair']):box(t['intervals'])for t in r['final_differences']}
    return s,d,dict(path=str(p),sha256=sha(p))

def targets(state,diffs,scope):
    out=[]
    for k,(lo,hi)in enumerate(state['positions']+state['scalar']):
        if scope=='centers'and k>=18:continue
        for sg in(-1,1):out.append(dict(kind='scalar',key=k,sign=sg,objective=[[k,sg]],old=str(hi if sg==1 else-lo)))
    if scope=='all':
        for (i,j),ds in sorted(diffs.items()):
            for ax,(lo,hi)in enumerate(ds):
                for sg in(-1,1):out.append(dict(kind='difference',key=[i,j,ax],sign=sg,
                    objective=[[2*j+ax,sg],[2*i+ax,-sg]],old=str(hi if sg==1 else-lo)))
    return out

def exact_bound(rows,bounds,solution,obj):
    weights=M.terms(solution.row_dual);co,rhs=M.R.weighted_sum(rows,bounds,weights)
    for k,a in obj:co[k]-=Q(a)
    correction=sum(a*abs(c)for a,c in zip(bounds,co));proved=rhs+correction
    upper=M.ceil_grid(proved)
    return dict(objective=obj,upper=str(upper),proved_upper=str(proved),weights=weights,
                summed_rhs=str(rhs),residual_coefficients=[[k,str(c)]for k,c in enumerate(co)if c],
                residual_correction=str(correction))

def phase(state,diffs):
    rows,bounds,terminal,pos,sc,ds,guards=M.collect(state,diffs)
    if terminal:return dict(kind='accepted_interval_terminal',label=terminal),None
    h=M.highs(rows,len(bounds));h.run()
    if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:return None,None
    sol=h.getSolution()
    if sol.col_value[-1]>1e-8:
        ws=M.terms(sol.row_dual);co,rhs=M.R.weighted_sum(rows,bounds,ws)
        reserve=-rhs-sum(a*abs(c)for a,c in zip(bounds,co))
        if reserve>0:return dict(kind='positive_exact_reserve',weights=ws,reserve=str(reserve),
              printed_rows=M.R.printed_rows(rows,{i for i,w in ws}),rows=len(rows),
              absolute_variable_bounds=list(map(str,bounds)),weighted_rhs=str(rhs),
              weighted_coefficients=list(map(str,co)),propagated_positions=M.render(pos),
              physical_scalar_intersection=M.render(sc),effective_differences=M.render_diff(ds)),None
    return None,(rows,bounds,h,pos,sc,ds,guards)

def union_pass(state,diffs,original,parts,scope='all'):
    before=encode(state,diffs);a,b=state['angles'][original]
    cuts=sorted({a,b,*[Q(2*i-parts,parts)for i in range(parts+1)if a<Q(2*i-parts,parts)<b]})
    if len(cuts)<2:return state,diffs,dict(status='NO_INTERVAL')
    tt=targets(state,diffs,scope);children=[];live=[]
    for ci,(lo,hi)in enumerate(zip(cuts,cuts[1:])):
        ast=list(state['angles']);ast[original]=(lo,hi);ast=tuple(ast)
        physical=M.K.analytic(ast)
        scalar=tuple((max(x,l),min(y,u))for(x,y),(l,u)in zip(state['scalar'],physical))
        child=dict(index=ci,interval=[str(lo),str(hi)],status='OPEN',bounds={})
        if any(x>y for x,y in scalar):
            child.update(status='CLOSED',terminal={'kind':'empty_analytic_scalar','scalar':M.render(scalar)})
            children.append(child);continue
        ss=dict(state,angles=ast,scalar=scalar)
        term,model=phase(ss,diffs)
        if term is not None:
            child.update(status='CLOSED',terminal=term);children.append(child);continue
        if model is None:raise RuntimeError('missing optimal phase model')
        rows,absbound,h,prop,sc,ds,guards=model
        h.changeColCost(len(absbound),0.);h.changeColBounds(len(absbound),0.,0.)
        previous=[];solutions={};values={}
        for ti,t in enumerate(tt):
            for k,co in previous:h.changeColCost(k,0.)
            for k,co in t['objective']:h.changeColCost(k,-float(co))
            previous=t['objective'];h.setOptionValue('time_limit',h.getRunTime()+3.);h.run()
            if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:
                values[ti]=float(Q(t['old']));continue
            values[ti]=-h.getObjectiveValue()
            if values[ti]<float(Q(t['old'])-EPS):solutions[ti]=h.getSolution().row_dual
        child.update(rows=len(rows),absolute_variable_bounds=list(map(str,absbound)),
              propagated_positions=M.render(prop),physical_scalar_intersection=M.render(sc),
              effective_differences=M.render_diff(ds),three_square_guards=guards)
        children.append(child);live.append((ci,rows,absbound,solutions,values))
        print(state['id'],'arc',original,ci,'numeric_improved',len(solutions),flush=True)
    saved=dict(original=original,parts=parts,cover=[list(map(str,ab))for ab in zip(cuts,cuts[1:])],
               before=before,children=children,installed=[])
    if not live:
        saved['status']='COMPLETE_PARENT_CLOSED';return state,diffs,saved
    nextpos=[list(x)for x in state['positions']];nextscalar=[list(x)for x in state['scalar']]
    nextdiff={k:[list(x)for x in v]for k,v in diffs.items()};used={ci:set()for ci,*_ in live}
    for ti,t in enumerate(tt):
        if any(ti not in sol for ci,r,absb,sol,val in live):continue
        if max(val[ti]for ci,r,absb,sol,val in live)>=float(Q(t['old'])-EPS):continue
        proofs={}
        for ci,rows,absb,sol,val in live:
            class Proposal:pass
            p=Proposal();p.row_dual=sol[ti]
            proofs[ci]=exact_bound(rows,absb,p,t['objective'])
        upper=max(Q(p['upper'])for p in proofs.values())
        if Q(t['old'])-upper<EPS:continue
        n=len(saved['installed']);saved['installed'].append(dict(t,upper=str(upper),child_indices=sorted(proofs)))
        for ci,p in proofs.items():
            children[ci]['bounds'][str(n)]=p;used[ci].update(i for i,w in p['weights'])
        key=t['key'];sg=t['sign']
        target=(nextpos[key]if key<18 else nextscalar[key-18])if t['kind']=='scalar'else nextdiff[tuple(key[:2])][key[2]]
        if sg==1:target[1]=min(target[1],upper)
        else:target[0]=max(target[0],-upper)
    for ci,rows,absb,sol,val in live:
        children[ci]['printed_rows']=M.R.printed_rows(rows,used[ci])
    pos=tuple(map(tuple,nextpos));sc=tuple(map(tuple,nextscalar));dd={k:tuple(map(tuple,v))for k,v in nextdiff.items()}
    if any(a>b for a,b in pos+sc)or any(a>b for v in dd.values()for a,b in v):
        saved['status']='COMPLETE_PARENT_CLOSED';saved['terminal']={'kind':'empty_union_bound'}
        return state,diffs,saved
    angles,contradiction,identities=M.R.infer_angles(state['angles'],sc)
    saved['physical_frame_inferences']=identities
    if contradiction:
        saved['status']='COMPLETE_PARENT_CLOSED';saved['terminal']={'kind':contradiction};return state,diffs,saved
    physical=M.K.analytic(angles);sc=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(sc,physical))
    if any(a>b for a,b in sc):
        saved['status']='COMPLETE_PARENT_CLOSED';saved['terminal']={'kind':'empty_union_analytic'};return state,diffs,saved
    ss=dict(state,positions=pos,scalar=sc,angles=angles);saved['after']=encode(ss,dd)
    saved['status']='OPEN_WITH_CERTIFIED_UNION_BOUNDS';return ss,dd,saved

def run(ident,originals,parts,cycles,scope):
    state,diffs,prior=load(ident);record=dict(schema='whole_parent_original_frame_union_v1',id=ident,
         path=state['path'],prior=prior,status='OPEN',passes=[],
         source_files={str(Path(__file__)):sha(__file__),str(Path(M.__file__)):sha(M.__file__)})
    out=HERE/'results';out.mkdir(exist_ok=True);dest=out/(ident+'.json');start=time.monotonic()
    for cycle in range(cycles):
        for i in originals:
            state,diffs,p=union_pass(state,diffs,i,parts,scope);record['passes'].append(p)
            print(ident,'cycle',cycle,'ORIGINAL',i,'installed',len(p.get('installed',[])),p['status'],'seconds',round(time.monotonic()-start,2),flush=True)
            if p['status']=='COMPLETE_PARENT_CLOSED':record['status']='CANDIDATE_CLOSED'
            record['final']=encode(state,diffs);record['seconds']=time.monotonic()-start;dest.write_text(json.dumps(record,indent=2)+'\n')
            if record['status']=='CANDIDATE_CLOSED':return record
            term,_=phase(state,diffs)
            if term:
                record.update(status='CANDIDATE_CLOSED',terminal=term);dest.write_text(json.dumps(record,indent=2)+'\n');print('CLOSED',ident,flush=True);return record
    return record
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('id');ap.add_argument('--originals',default='7,8,5,2');ap.add_argument('--parts',type=int,default=4);ap.add_argument('--cycles',type=int,default=1);ap.add_argument('--scope',default='all',choices=['all','centers','scalar']);args=ap.parse_args()
    run(args.id,list(map(int,args.originals.split(','))),args.parts,args.cycles,args.scope)
