"""Existing physical three-square capacity with correlated pair projections."""
from fractions import Fraction as Q
from itertools import combinations,permutations,product
from math import isqrt
import diagonal_rows as D

def directions():
    out=[(Q(1),Q(0)),(Q(0),Q(1))]
    for a,b,c in((3,4,5),(5,12,13),(8,15,17),(7,24,25),(20,21,29),(9,40,41)):
        for p,q in((a,b),(b,a)):
            for sign in(-1,1):out.append((Q(p,c),Q(sign*q,c)))
    return out
def root_lower(x):
    den=1<<48;n=isqrt(x.numerator*den*den//x.denominator);r=Q(n,den)
    assert r*r<=x<(r+Q(1,den))**2
    return r
def generate_rows(cartesian,diagonal):
    rows=[];guards=[]
    def projection(i,j,e):
        lo,hi=D.project(cartesian[min(i,j),max(i,j)],diagonal[min(i,j),max(i,j)],*e)
        assert lo<=hi
        return (lo,hi)if i<j else(-hi,-lo)
    def delta(boxes,i,j):
        v=boxes[min(i,j),max(i,j)]
        return v if i<j else tuple((-b,-a)for a,b in v)
    for e in directions():
        f=(-e[1],e[0]);assert sum(t*t for t in e)==1
        for i,j in combinations(range(9),2):
            across=projection(i,j,e);along=projection(i,j,f);width=max(abs(x)for x in across)
            if width>=1:continue
            bound=root_lower(1-width*width)
            for sign in(1,-1):
                if not(along[0]>-bound if sign==1 else along[1]<bound):continue
                co={2*i:sign*f[0],2*i+1:sign*f[1],2*j:-sign*f[0],2*j+1:-sign*f[1]}
                rows.append(D.clean(co,-bound,f'correlated_rotated_unit_gap_{i}_{j}_{e[0]}_{e[1]}_{sign}'))
        for triple in combinations(range(9),3):
            width=max(abs(v)for i,j in combinations(triple,2)for v in projection(i,j,e))
            if width>Q(7,10):continue
            order=next((s for s in permutations(triple)if projection(s[0],s[1],f)[0]>=0 and projection(s[1],s[2],f)[0]>=0),None)
            if order is None:continue
            l,m,u=order;a,b=projection(l,u,e);capacity=min(Q(2),Q(280,99)-2*width)
            factor=Q(13,50)*(a+b);n=(f[0]+factor*e[0],f[1]+factor*e[1])
            co={2*l:n[0],2*l+1:n[1],2*u:-n[0],2*u+1:-n[1]}
            name=f'correlated_rotated_sharp_strip_{l}_{m}_{u}_{e[0]}_{e[1]}'
            rows.append(D.clean(co,-capacity-Q(13,50)*a*b,name))
            guards.append(dict(kind='sharp_strip',name=name,width=str(width),triple=list(order)))
    def dot_min(a,b):return min(x[0]*y[0]+x[1]*y[1]for x in product(*a)for y in product(*b))
    def det_max(a,b):return max(abs(x[0]*y[1]-x[1]*y[0])for x in product(*a)for y in product(*b))
    def norm_min(a):return sum(Q(0)if l<=0<=u else min(l*l,u*u)for l,u in a)
    for l,m,u in permutations(range(9),3):
        first,last,end=(delta(cartesian,a,b)for a,b in((l,m),(m,u),(l,u)))
        dfirst,dlast,dend=(delta(diagonal,a,b)for a,b in((l,m),(m,u),(l,u)))
        nf=max(Q(1),norm_min(first),norm_min(dfirst)/2);nl=max(Q(1),norm_min(last),norm_min(dlast)/2)
        adjacent=max(dot_min(first,last),dot_min(dfirst,dlast)/2)
        left=max(dot_min(first,end),dot_min(dfirst,dend)/2,nf+adjacent)
        right=max(dot_min(last,end),dot_min(dlast,dend)/2,nl+adjacent)
        if min(left,right)<0:continue
        norm2=max(Q(1),norm_min(end),norm_min(dend)/2);den=root_lower(norm2)
        area=min(det_max(first,last),det_max(first,end),det_max(last,end),
                 det_max(dfirst,dlast)/2,det_max(dfirst,dend)/2,det_max(dlast,dend)/2)
        h=area/den
        if h>Q(7,10):continue
        length=min(Q(2),Q(280,99)-2*h)
        (a,b),(c,d)=dend;ex=(a+b+c+d)/2;ey=(a+b-c-d)/2
        co={2*l:ex,2*l+1:ey,2*u:-ex,2*u+1:-ey}
        name=f'correlated_diagonal_altitude_capacity_{l}_{m}_{u}'
        rows.append(D.clean(co,-length*length-(a*b+c*d)/2,name))
        guards.append(dict(kind='altitude',name=name,altitude=str(h),left_dot=str(left),right_dot=str(right)))
    return rows,guards
