#!/usr/bin/env python3
"""Independent exact replay of original-frame cover lifting.

No new discovery code or solver is imported. Reconstruct used physical rows
from the accepted baseline and separately proved row rules. Check all child
covers, every printed dual, and simultaneous whole-parent installation.
"""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof')
sys.path.insert(0,str(OLD))
import verify_joint_original as J
K=J.K
sys.path.insert(0,str(OLD/'shared_capacity_three_b_v4/sources'))
import review_guarded_frame_bounds_independent as R

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(values):return tuple(tuple(Q(z)for z in ab)for ab in values)
def stateview(s):return dict(angles=K.view(s['angles']),positions=K.view(s['positions']),
       scalar=K.view(s['scalar']),differences=K.diffview(s['differences']))
def mathematical_state(s):return {k:s[k]for k in ('angles','positions','scalar','differences')}

def reconstruct_rows(state,saved):
    base,absolute,pos,sc,diff,guards=K.rebuild(state['path'],state['angles'],state['positions'],
         state['choices'],state['scalar'],state['differences'])
    assert box(saved['propagated_positions'])==pos
    assert box(saved['physical_scalar_intersection'])==sc
    assert saved['effective_differences']==K.diffview(diff)
    assert list(map(str,absolute))==saved['absolute_variable_bounds']
    rows,names=J.rows_for_record(saved,base,sc,diff,state['angles'])
    return rows,absolute,len(saved['printed_rows']),names

def terminal(state,t):
    kind=t['kind']
    if kind=='accepted_interval_terminal':
        rows,absolute,label=R.collect_guarded(state['path'],state['angles'],state['positions'],
                  state['choices'],state['scalar'])
        assert label is not None and label==t['label'];return dict(rows=0,kind=kind,reserve=None)
    assert kind=='positive_exact_reserve'
    rows,absolute,n,names=reconstruct_rows(state,t)
    indices={i for i,w in t['weights']};assert indices=={s['index']for s in t['printed_rows']}
    co,rhs=K.sum_rows(rows,absolute,t['weights']);reserve=-rhs-sum(m*abs(v)for m,v in zip(absolute,co))
    assert reserve>0 and reserve==Q(t['reserve'])
    assert co==list(map(Q,t['weighted_coefficients']))and rhs==Q(t['weighted_rhs'])
    return dict(rows=n,kind=kind,reserve=str(reserve))

def replay(path):
    begin=time.monotonic();p=Path(path);r=json.loads(p.read_text())
    assert r['schema']=='whole_parent_original_frame_union_v1'and r['status']in('OPEN','CANDIDATE_CLOSED')
    assert digest(r['prior']['path'])==r['prior']['sha256']
    report,state=J.replay(r['prior']['path'],allow_open=True,return_state=True)
    assert r['id']==state['id']and r['path']==state['path']
    K.verify_index();totalrows=0;totalbounds=0;closed=False;passes=[];terminals=[]
    for pi,pp in enumerate(r['passes']):
        assert not closed
        assert pp['before']==stateview(state)
        original=pp['original'];assert type(original)is int and 0<=original<9
        cover=box(pp['cover']);assert len(cover)>=1
        a,b=state['angles'][original]
        assert cover[0][0]==a and cover[-1][1]==b
        assert all(lo<hi for lo,hi in cover)
        assert all(cover[i][1]==cover[i+1][0]for i in range(len(cover)-1))
        assert len(pp['children'])==len(cover)
        live={};bounds=[[]for _ in pp['installed']];newrows=0;nduals=0
        for ci,(child,interval)in enumerate(zip(pp['children'],cover)):
            assert child['index']==ci and box([child['interval']])[0]==interval
            angles=list(state['angles']);angles[original]=interval;angles=tuple(angles)
            analytic=K.analytic(angles)
            scalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(state['scalar'],analytic))
            childstate=dict(state,angles=angles,scalar=scalar)
            if any(a>b for a,b in scalar):
                assert child['status']=='CLOSED'and child['terminal']['kind']=='empty_analytic_scalar'
                assert child['terminal']['scalar']==K.view(scalar)
                continue
            if child['status']=='CLOSED':
                tr=terminal(childstate,child['terminal']);newrows+=tr['rows'];terminals.append(tr);continue
            assert child['status']=='OPEN'
            rows,absolute,n,names=reconstruct_rows(childstate,child);newrows+=n;used=set()
            assert set(child['bounds'])=={str(i)for i in range(len(pp['installed']))}
            for ii,t in enumerate(pp['installed']):
                proof=child['bounds'][str(ii)]
                assert proof['objective']==t['objective']
                upper=K.audit_bound(rows,absolute,proof);bounds[ii].append((ci,upper));nduals+=1
                used.update(k for k,w in proof['weights'])
            assert used=={s['index']for s in child['printed_rows']}
            live[ci]=child
        if not live:
            assert pp['status']=='COMPLETE_PARENT_CLOSED'and not pp['installed'];closed=True
        else:
            positions=[list(x)for x in state['positions']];scalar=[list(x)for x in state['scalar']]
            differences={k:[list(x)for x in v]for k,v in state['differences'].items()}
            for ii,t in enumerate(pp['installed']):
                assert sorted(live)==t['child_indices']==[ci for ci,v in bounds[ii]]
                upper=max(v for ci,v in bounds[ii]);assert upper==Q(t['upper'])
                key=t['key'];sg=t['sign'];assert sg in(-1,1)
                if t['kind']=='scalar':
                    assert type(key)is int and 0<=key<54 and t['objective']==[[key,sg]]
                    old=state['positions'][key]if key<18 else state['scalar'][key-18]
                    dest=positions[key]if key<18 else scalar[key-18]
                else:
                    assert t['kind']=='difference'and len(key)==3
                    i,j,ax=key;assert 0<=i<j<9 and ax in(0,1)
                    assert t['objective']==[[2*j+ax,sg],[2*i+ax,-sg]]
                    old=state['differences'][i,j][ax];dest=differences[i,j][ax]
                assert Q(t['old'])==(old[1]if sg==1 else-old[0])
                if sg==1:dest[1]=min(dest[1],upper)
                else:dest[0]=max(dest[0],-upper)
            positions=tuple(map(tuple,positions));scalar=tuple(map(tuple,scalar))
            differences={k:tuple(map(tuple,v))for k,v in differences.items()}
            if any(a>b for a,b in positions+scalar)or any(a>b for vv in differences.values()for a,b in vv):
                assert pp['status']=='COMPLETE_PARENT_CLOSED'and pp['terminal']['kind']=='empty_union_bound';closed=True
            else:
                angles,contradiction,identities=R.infer_angles(state['angles'],scalar)
                assert identities==pp['physical_frame_inferences']
                if contradiction is not None:
                    assert pp['status']=='COMPLETE_PARENT_CLOSED'and pp['terminal']['kind']==contradiction;closed=True
                else:
                    analytic=K.analytic(angles);scalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(scalar,analytic))
                    if any(a>b for a,b in scalar):
                        assert pp['status']=='COMPLETE_PARENT_CLOSED'and pp['terminal']['kind']=='empty_union_analytic';closed=True
                    else:
                        assert pp['status']=='OPEN_WITH_CERTIFIED_UNION_BOUNDS'
                        state.update(positions=positions,angles=angles,scalar=scalar,differences=differences)
                        assert pp['after']==stateview(state)
        totalrows+=newrows;totalbounds+=nduals
        passes.append(dict(original=original,closed_children=len(cover)-len(live),
             intervals=len(cover),installed_bounds=len(pp['installed']),checked_duals=nduals,printed_rows=newrows))
        print(r['id'],'PASS ARC UNION',pi,passes[-1],flush=True)
    if r['status']=='CANDIDATE_CLOSED'and not closed:
        tr=terminal(state,r['terminal']);totalrows+=tr['rows'];terminals.append(tr);closed=True
    assert closed==(r['status']=='CANDIDATE_CLOSED')
    assert r['final']==stateview(state)
    out=dict(id=r['id'],status='PASS_COMPLETE_ORIGINAL_PARENT'if closed else'PASS_CERTIFIED_PARENT_STATE_OPEN',
       original_path=r['path'],original_prior=report,passes=passes,checked_duals=totalbounds,
       printed_rows=totalrows,terminals=terminals,new_original_cells=int(closed),whole_mask_closed=False,
       certificate_sha256=digest(path),reviewer_sha256=digest(__file__),seconds=time.monotonic()-begin,
       lean_lake_ci_run=False)
    dest=HERE/'replay_reports';dest.mkdir(exist_ok=True);(dest/(r['id']+'.json')).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k not in('original_prior','original_path','passes')}),flush=True)
    return out,state
if __name__=='__main__':replay(sys.argv[1])
