"""Print certified-linear premises needed by used RLT terminal rows.

This untrusted formatting step grants no new proof credit. The independent
reviewer must reconstruct every premise in the unchanged original parent.
"""
from pathlib import Path
import json,sys
import quadratic_moment_pilot as DEFAULT

def augment(path,driver=DEFAULT):
    path=Path(path);record=json.loads(path.read_text())
    assert record['status']=='CANDIDATE_CLOSED'
    assert record['terminal']['kind']=='positive_exact_reserve'
    state,dd,dg,prior=driver.read_prefix(record['prior']['path'])
    assert prior==record['prior']
    rows,absolute,metadata,physical=driver.collect(state,dd,dg,record['metadata']['rlt_mode'])
    assert metadata==record['metadata'] and physical==record['physical_state']
    sources=set()
    for item in record['terminal']['printed_rows']:
        name=item['name']
        if name.startswith(('moment_rlt_lower_','moment_rlt_upper_')):
            source=int(name.split('_')[3]);assert source in metadata['rlt_source_indices']
            assert source<metadata['initial_linear_rows'];sources.add(source)
    record['terminal']['rlt_source_rows']=driver.P.M.R.printed_rows(rows,sources)
    record['augmentation']=dict(source_certificate=str(path.resolve()),source_sha256=driver.P.sha(path),
                                script=str(Path(__file__).resolve()),script_sha256=driver.P.sha(__file__))
    destination=path.with_name(path.stem+'-complete-premises.json')
    destination.write_text(json.dumps(record,indent=2)+'\n')
    print('AUGMENTED',destination,'RLT premises',len(sources),flush=True)
    return destination

if __name__=='__main__':augment(sys.argv[1])
