"""Independent reconstruction of all-nine radial/cardinality moment rows.

Imports no row producer or optimizer. All conditions are rebuilt directly from
the certified original coordinate intervals and the accepted all-nine theorem.
"""
from fractions import Fraction as F

def square_index(k):
    return 54+sum(54-i for i in range(k))

def original_data(positions):
    assert len(positions)==18 and all(a<=b for a,b in positions)
    radius=F(91,60);u=F(1,2)+F(23,100)**2+F(99,70)*F(23,100)
    info=[]
    for i in range(9):
        x,y=positions[2*i:2*i+2]
        lower=sum(min(a*a,b*b)if not a<=0<=b else F(0)for a,b in(x,y))
        maximum=min(radius*radius,sum(max(a*a,b*b)for a,b in(x,y)))
        classification='far'if lower>=u else'constant'if maximum<=u else'radial'
        info.append((lower,maximum,classification))
    return u,info

def physical_row(name,positions):
    u,info=original_data(positions);co={}
    if name.startswith('all_nine_radial_'):
        tokens=name.split('_');assert len(tokens)==5 and tokens[3]in('lower','upper')
        i=int(tokens[4]);assert 0<=i<9
        if tokens[3]=='lower':sg=F(-1);rhs=-F(27,100)**2
        else:sg=F(1);rhs=info[i][1]
        co[square_index(2*i)]=sg;co[square_index(2*i+1)]=sg
    else:
        assert name.startswith('all_nine_near_cardinality_')
        suffix=name.removeprefix('all_nine_near_cardinality_')
        constants=sum(t=='constant'for l,m,t in info)
        labels=[i for i,(l,m,t)in enumerate(info)if t=='radial']
        assert constants<2
        if suffix=='all':required=F(2-constants)
        else:
            assert suffix.startswith('omit_')and constants==0
            omitted=int(suffix[5:]);assert omitted in labels;labels.remove(omitted);required=F(1)
        rhs=-required
        for i in labels:
            maximum=info[i][1];assert maximum>u
            coefficient=1/(maximum-u)
            co[square_index(2*i)]=co[square_index(2*i+1)]=coefficient
            rhs+=maximum*coefficient
    return tuple(sorted(co.items())),rhs,name
