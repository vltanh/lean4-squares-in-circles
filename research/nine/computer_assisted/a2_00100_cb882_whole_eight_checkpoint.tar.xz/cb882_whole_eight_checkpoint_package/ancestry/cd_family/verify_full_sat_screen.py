#!/usr/bin/env python3
"""Check exact terminals and exhaustive eight-axis physical cover scope.

OPEN alternatives are deliberately retained. Replaying exact alternatives
does not close an original unless all eight alternatives of one pair close.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,sys,time,hashlib
import verify_diagonal_pass as P
from independent_diagonal_rows import intervals,physical_row as diagonal_row
from independent_correlated_capacity import physical_row as capacity_row
J=P.J;K=P.K;R=P.R;HERE=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exact_case(state,diag,case):
    term=case['terminal']
    if term['kind']=='exact_interval_terminal':
        base,absolute,label=R.collect_guarded(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'])
        if label is not None:
            assert label==term['label'];return dict(kind='accepted_interval',printed_rows=0)
        assert term['label']=='empty_correlated_diagonal'
        base,absolute,pos,sc,diff,guards=K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
        gg=intervals(diff,diag);assert any(a>b for vv in gg.values()for a,b in vv)
        return dict(kind='empty_correlated_diagonal',printed_rows=0)
    assert term['kind']=='positive_exact_reserve'
    base,absolute,pos,sc,diff,guards=K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
    gg=intervals(diff,diag)
    assert case['propagated_positions']==K.view(pos)and case['physical_scalar_intersection']==K.view(sc)
    assert case['effective_differences']==K.diffview(diff)and case['effective_diagonal']==K.diffview(gg)
    assert term['absolute_variable_bounds']==list(map(str,absolute))
    used=term['printed_rows'];indices=[v['index']for v in used];assert len(indices)==len(set(indices))
    rows=list(base);maximum=max(indices,default=-1)
    if maximum>=len(rows):rows += [((),F(0),'UNUSED_UNVERIFIED')]*(maximum+1-len(rows))
    newrules=[]
    for entry in used:
        k=entry['index'];assert type(k)is int and 0<=k<case['rows'];name=entry['name']
        if k>=len(base):
            if name.startswith(('correlated_rotated_','correlated_diagonal_altitude_')):rows[k]=capacity_row(name,diff,gg)
            elif name.startswith('correlated_'):rows[k]=diagonal_row(name,sc,diff,gg)
            else:rows[k]=J.rebuild_joint(name,sc,diff,state['angles'],J.point_row)
            newrules.append(name)
        co,rhs,nm=rows[k];assert name==nm and F(entry['rhs'])==rhs
        assert [(i,F(c))for i,c in entry['coefficients']if F(c)]==[(i,c)for i,c in co if c]
    assert {i for i,w in term['weights']}==set(indices)
    co,rhs=K.sum_rows(rows,absolute,term['weights']);reserve=-rhs-sum(m*abs(v)for m,v in zip(absolute,co))
    assert reserve>0 and reserve==F(term['reserve'])and rhs==F(term['weighted_rhs'])and co==list(map(F,term['weighted_coefficients']))
    return dict(kind='positive_exact_reserve',printed_rows=len(indices),reserve=str(reserve),new_rules=newrules)

def replay(path):
    begin=time.monotonic();path=Path(path);r=json.loads(path.read_text());assert r['schema']=='complete_owned_axis_static_pair_cover_v1'
    assert digest(r['prior'])==r['prior_sha256']
    prior,state,diag=P.replay(r['prior']);assert r['id']==state['id']and r['path']==state['path']
    report=dict(id=r['id'],status='OPEN_PARENT',prior_report=prior,pairs=[],new_original_cells=0,whole_mask_closed=False,
          certificate_sha256=digest(path),reviewer_sha256=digest(__file__),independent_capacity_sha256=digest(HERE/'independent_correlated_capacity.py'))
    for pp in r['pairs']:
        pair=pp['pair'];assert len(pair)==2;i,j=pair;assert 0<=i<j<9
        assert len(pp['cases'])==8
        descriptors=[(c['owner'],c['axis'],c['sign'])for c in pp['cases']]
        assert len(set(descriptors))==8 and set(descriptors)==set(product((i,j),(0,1),(-1,1)))
        cases=[]
        for case in pp['cases']:
            path=state['path']+[['sat',pair,[case['owner'],case['axis'],case['sign']]]]
            assert case['path']==path
            _,_,choices=K.V.reconstruct(path)
            child=dict(state,path=path,choices=choices)
            result=dict(owner=case['owner'],axis=case['axis'],sign=case['sign'],status='OPEN')
            if case['status']=='CANDIDATE_CLOSED':
                result.update(status='PASS_EXACT_TERMINAL',**exact_case(child,diag,case))
            else:assert case['status']=='OPEN'
            cases.append(result)
        count=sum(c['status']=='PASS_EXACT_TERMINAL'for c in cases)
        complete=count==8
        assert pp['status']==('COMPLETE_CANDIDATE_PARENT_COVER'if complete else'OPEN_PARENT')
        report['pairs'].append(dict(pair=pair,exact_terminals=count,open_alternatives=8-count,complete_cover=complete,cases=cases))
        if complete:report.update(status='PASS_COMPLETE_ORIGINAL_PARENT',new_original_cells=1)
        print(r['id'],'PASS FULL SAT COVER SCOPE',pair,'exact',count,'open',8-count,flush=True)
    assert (r['status']=='CANDIDATE_CLOSED')==(report['new_original_cells']==1)
    report['seconds']=time.monotonic()-begin;report['lean_lake_ci_run']=False
    out=HERE/'full_sat_reviews';out.mkdir(exist_ok=True);(out/(r['id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in('prior_report','pairs')}),flush=True)
    return report
if __name__=='__main__':
    for path in sys.argv[1:]:replay(path)
