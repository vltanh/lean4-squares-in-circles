#!/usr/bin/env python3
"""Independent exact attachment audit; no ancestor or scalar replay is repeated."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
GLOBAL = ROOT / 'global_theorem'
SPEC = GLOBAL / 'CB882_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_SPECIFICATION.json'
PACKET = GLOBAL / 'cb882_whole_eight_package'
OUTPUT = HERE / 'CB882_WHOLE_EIGHT_HEIGHT_ATTACHMENT_INDEPENDENT_REVIEW.json'
ID = 'negative-b882d8ade0cf9ea0'
PATH = [['angle', 3, 0], ['angle_cut', [0, '0'], 1],
        ['alternate_four_escape', [1, 7], [3]]]
SPEC_SHA = 'e4825423f302b0920ce001090cea28624af840904d27169e98cdb22c3eed8b48'
PREFIX_SHA = '1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'
V3_SHA = '61d2a2f8ac9656b6c5f8a9f89113a8ea80dc239b767baa0c601d27d91f1007d8'
PARENT_REPLAY_SHA = 'adc73edc62fe70b7909eeb2fee7836747309751882783b45af21e385576e6120'
THEOREM_MANIFEST_SHA = '603024e697b2d11b6ef4dc5092cf07df7cccaf5ddefbac1bc4bb04d0338d2104'


def main():
    assert __debug__
    assert not OUTPUT.exists(), 'Preserve previous audit bytes; use a new output for another run.'
    inventory = {}

    def bind(path, expected=None):
        path = Path(path).resolve()
        content = path.read_bytes()
        actual = sha256(content).hexdigest()
        if expected is not None:
            assert actual == expected, (str(path), actual, expected)
        assert path not in inventory or inventory[path] == actual
        inventory[path] = actual
        return content

    spec = json.loads(bind(SPEC, SPEC_SHA))
    assert spec['original_id'] == ID and spec['original_path'] == PATH
    assert spec['status'] == 'PASS_EXACT_WHOLE_ORIGINAL_COVER_ATTACHMENT_ONLY'
    assert spec['center_subdivisions'] == spec['extra_angle_subdivisions'] == 0
    assert spec['new_original_closures'] == spec['new_mask_closures'] == 0
    assert spec['complete_closed_domains'] == 8
    assert spec['children_are_independent_same_parent_restrictions'] is True
    assert spec['earlier_sibling_complements_added'] is False
    assert spec['all_equality_faces_retained'] is True
    assert spec['closed_cover_threshold'] == '23/100'
    assert spec['deduced_physical_variation'] == 'V(A,H,I,D)>23/100'
    assert len(spec['source_sha256']) == 109
    for name, expected in spec['source_sha256'].items():
        bind(name, expected)

    assert spec['parent']['sha256'] == PREFIX_SHA
    assert spec['whole_v3_parent']['sha256'] == V3_SHA
    assert spec['accepted_parent_replay']['sha256'] == PARENT_REPLAY_SHA
    prefix = json.loads(bind(spec['parent']['path'], PREFIX_SHA))
    v3 = json.loads(bind(spec['whole_v3_parent']['path'], V3_SHA))
    replay = json.loads(bind(spec['accepted_parent_replay']['path'], PARENT_REPLAY_SHA))
    for obj in (prefix, v3):
        assert obj['id'] == ID and obj['path'] == PATH and obj['status'] == 'OPEN'
        assert 'tile' not in obj and 'center_cover' not in obj
    assert prefix['rounds'] == [] and prefix['prior']['kind'] == 'v3'
    assert prefix['prior']['sha256'] == V3_SHA and 'tile' not in prefix['prior']
    assert v3['scope'] == 'WHOLE_UNCHANGED_ORIGINAL_PARENT' and v3['new_branch_nodes'] == 0
    assert len(v3['rounds']) == 5
    assert replay['status'] == 'PASS_CERTIFIED_WHOLE_ORIGINAL_STATE_OPEN'
    assert replay['id'] == ID and replay['original_path'] == PATH
    assert replay['certificate_sha256'] == PREFIX_SHA and replay['full_original_v3_sha256'] == V3_SHA
    assert replay['original_caller_before_every_center_or_angle_subdivision'] is True
    assert replay['all_frozen_inputs_rehashed'] is True
    assert replay['new_original_cells'] == replay['new_masks'] == 0
    assert prefix['final'] == replay['physical_state']
    state = prefix['final']
    for key in ('angles', 'positions', 'scalar', 'differences'):
        assert state[key] == v3['final_' + key]
        assert state[key] == v3['rounds'][-1][key + '_after']
        assert state[key] == v3['final_test'][key + '_before']
    assert state['diagonal'] == []
    ancestor = replay['ancestor_replay']
    assert ancestor['certificate_sha256'] == PREFIX_SHA
    assert ancestor['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert ancestor['rounds'] == [] and ancestor['new_exact_deductions'] == 0
    old = ancestor['prior_report']
    assert old['certificate_sha256'] == V3_SHA
    assert old['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert old['whole_original_parent_closed'] is False and old['bound_induction_branch_nodes'] == 0
    assert old['center_cover'] is None
    assert (old['rounds'], old['new_deductions'], old['prior_coordinate_deductions'],
            old['printed_rows_checked'], old['terminal_rows']) == (5, 386, 30, 1073, 0)

    # Bind the strict replay's actual portable sources, beyond its report bytes.
    manifest_path = PACKET / 'SHA256_MANIFEST.json'
    manifest = json.loads(bind(manifest_path, replay['source_manifest_sha256']))
    assert len(manifest['files']) == replay['frozen_inputs'] == 302
    for name, expected in manifest['files'].items():
        path = (PACKET / name).resolve()
        assert path.is_relative_to(PACKET)
        bind(path, expected)
    assert replay['checker_sha256'] == manifest['files']['replay_cb882_whole_parent.py']
    assert replay['checker_sha256'] == '3aa87a4941a4b0b5f7b71ce9b47fd41698ed774237dae666fa7f9a68df0a5cf0'
    assert manifest['files']['verify_cd_triple_energy_recursive_bounds.py'] == 'e73773f57e99797edcf5ee9726000c57ce212936b853c75247ff63ce9f16e0f4'
    bind(PACKET / 'ancestry/cd_family/diagonal_results' / (ID + '.json'), PREFIX_SHA)
    bind(PACKET / 'ancestry/legacy/current_proof/v3_results' / (ID + '.json'), V3_SHA)
    for name in replay['workspace_module_import_audit'].values():
        assert name in manifest['files']

    # Reconstruct all three orders directly from exact whole-original intervals.
    positions = [tuple(map(F, pair)) for pair in state['positions']]
    angles = [tuple(map(F, pair)) for pair in state['angles']]
    differences = {tuple(e['pair']): tuple(tuple(map(F, pair)) for pair in e['intervals'])
                   for e in state['differences']}
    assert angles[0][0] >= 0 and angles[3][1] <= 0
    orders = []
    for i, j in ((0, 7), (7, 8), (8, 3)):
        lower = positions[2*j][0] - positions[2*i][1]
        upper = positions[2*j][1] - positions[2*i][0]
        pair_lower, pair_upper = differences[min(i, j), max(i, j)][0]
        if i > j:
            pair_lower, pair_upper = -pair_upper, -pair_lower
        lower, upper = max(lower, pair_lower), min(upper, pair_upper)
        assert 0 <= lower <= upper
        orders.append([str(lower), str(upper)])
    assert [pair[0] for pair in orders] == [
        '35461/524288', '0', '434432029724121/5000000000000000']
    assert orders == spec['proved_weak_order_intervals']
    assert orders == replay['opposite_tilt_eight_height_prerequisites']['proved_weak_order_intervals']
    assert [[str(v) for v in angles[i]] for i in (0, 3)] == spec['opposite_signed_slopes']

    # Independent coefficient expansion: negate each signed difference sum.
    expressions = []
    assert len(spec['children']) == 8
    for index, signs in enumerate(product((-1, 1), repeat=3)):
        child = spec['children'][index]
        coefficients = {}
        for sign, (start, end) in zip(signs, ((1, 15), (15, 17), (17, 7))):
            coefficients[start] = coefficients.get(start, F(0)) + sign
            coefficients[end] = coefficients.get(end, F(0)) - sign
        literal = [[k, str(v)] for k, v in sorted(coefficients.items()) if v]
        assert child['branch'] == index and child['signs'] == list(signs)
        assert child['conditional_row'] == dict(coefficients=literal, rhs='-23/100',
                                               name='opposite_tilt_AHID_variation_' + str(index))
        assert child['status'] == 'PENDING_COMPLETE_EXACT_CHILD_PROOF'
        expressions.append((signs, coefficients))
    identities = unions = equality_faces = 0
    for gaps in product((F(-1), F(-23, 100), F(0), F(23, 100), F(1)), repeat=3):
        coordinates = {1: F(7, 13)}
        for gap, (i, j) in zip(gaps, ((1, 15), (15, 17), (17, 7))):
            coordinates[j] = coordinates[i] + gap
        signed_values = []
        for signs, coefficients in expressions:
            signed = sum(sign * gap for sign, gap in zip(signs, gaps))
            assert sum(a * coordinates[k] for k, a in coefficients.items()) == -signed
            signed_values.append(signed)
            identities += 1
        variation = sum(map(abs, gaps))
        assert max(signed_values) == variation
        assert (variation >= F(23, 100)) == any(v >= F(23, 100) for v in signed_values)
        unions += 1
        if variation == F(23, 100):
            assert sum(v == F(23, 100) for v in signed_values) == 4
            equality_faces += 1
    assert (identities, unions, equality_faces) == (1000, 125, 6)

    theorem_path = ROOT / 'pr11/research/nine/computer_assisted/opposite_tilt_ahid_row/MANIFEST.json'
    theorem = json.loads(bind(theorem_path, THEOREM_MANIFEST_SHA))
    assert spec['theorem_manifest_sha256'] == THEOREM_MANIFEST_SHA
    for name, expected in theorem['immutable_inputs'].items():
        path = (theorem_path.parent / name).resolve()
        assert path.is_relative_to(theorem_path.parent)
        bind(path, expected)
    bind(__file__)
    for path, expected in inventory.items():
        assert sha256(path.read_bytes()).hexdigest() == expected
    result = dict(
        schema='independent_CB882_whole_original_eight_height_attachment_review_v1',
        status='PASS_ATTACHMENT_REVIEW_ONLY_ALL_EIGHT_CHILD_EXCLUSIONS_PENDING',
        original_id=ID, original_path=PATH, specification_sha256=SPEC_SHA,
        whole_prefix_sha256=PREFIX_SHA, whole_v3_sha256=V3_SHA,
        accepted_parent_replay_sha256=PARENT_REPLAY_SHA,
        original_caller_no_center_or_extra_angle_cuts=True,
        state_identical_to_accepted_whole_v3_final=True,
        proved_weak_order_intervals=orders,
        endpoint_opposite_signs_checked=True,
        independent_literal_rows=8, signed_expression_identities=identities,
        max_variation_union_checks=unions, threshold_equality_faces=equality_faces,
        physical_hand_review=[
            'Seven unchanged AHID/EFG originals are distinct and physical; EFG remains actual.',
            'The full-angle theorem uses exactly the proved three weak orders and opposite signs.',
            'At closed Q its equality aligns endpoints and gives AD span three; actual AB/BC plus CD inset then contradict strict weak CD.',
            'Therefore V>23/100; the eight independent closed height domains cover all survivors, retaining their shared faces.',
            'Settled weak order hypotheses permit this reduction without claiming their closed opposite halfspaces empty.'
        ],
        inherited_ancestor_and_scalar_replays_repeated=False,
        prior_rounds=5, prior_exact_deductions=386, earlier_coordinate_deductions=30,
        prior_printed_row_occurrences=1073,
        specification_inputs=109, portable_ancestor_inputs=302,
        all_referenced_inputs_rehashed=True, unique_bound_paths=len(inventory),
        evaluator_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
        source_sha256={str(p): h for p, h in sorted(inventory.items())},
        new_original_closures=0, new_mask_closures=0,
        lean_lake_ci_run=False)
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'])
    print('REPORT_SHA256', sha256(OUTPUT.read_bytes()).hexdigest())
    print('EVALUATOR_SHA256', result['evaluator_sha256'])
    print('BOUND_PATHS', len(inventory))


if __name__ == '__main__':
    main()
