#!/usr/bin/env python3
"""Independent exact proof in one closed height domain of the whole original C887.

The full original physical ancestor is replayed independently. Every selected
height domain retains all original bounds without any center subdivision.
An accepted leaf excludes only that conditional domain. This module never
assembles eight failures or awards fixed-tile, original, or mask credit.
"""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import argparse
import copy
import hashlib
import importlib
import json
import sys
import time
import verify_cd_triple_energy_recursive_bounds as R
from verify_cd_triple_energy_recursive_bounds import digest,box,canonical
import independent_three_square_energy_rows as TE
import independent_opposite_tilt_height_rows as SHARP
import shared_strict_row_terminal as SHARP_TERMINAL
from independent_empty_angle_terminal import verify as verify_empty_angle
from independent_fixed_bound_terminals import empty_interval_witness

SHARP_SCHEMA='C887_whole_original_opposite_tilt_height_bound_discovery_v1'
SHARP_SCOPE='ONE_CLOSED_HEIGHT_DOMAIN_OF_WHOLE_UNCHANGED_ORIGINAL'
TARGET_ID='negative-887236b78100baf3'
TARGET_PATH=[['angle',3,0],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[1]]]
ROOT_PARENT_SHA256='9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3'
ORIGINAL_PREFIX_SHA256='9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3'
DEFAULT_CONTEXT=Path('/workspace/scratch/fee12ff81cbd/c_887_bound_package')
ANCESTOR_CHECKER_SHA256='e73773f57e99797edcf5ee9726000c57ce212936b853c75247ff63ce9f16e0f4'
CONTEXT_SHA256='be53b0adf7485a68c0475d6148b5018df9d1dbe8e9bba9c110ab7b98ef4084da'
TRIPLE_HELPER_SHA256='d7f0e356bf268e6c9396287c1d1cadbebc32505b6dd71771e999f918baba5edc'
SHARP_ROWS_SHA256='74eff0691ccd464ae23aeaf6d36ee20c411732e965dad040dad9304dc5b286d6'
SHARP_TERMINAL_SHA256='43a74c66c7c0b91da76e6577ce511e6ae8de7bda9ab6e0adbf81a1cc2b013d43'
PROOFS={
 '/workspace/scratch/fee12ff81cbd/global_theorem/SHARED_ABID_STRICT_BOUNDARY_TERMINAL.md':
 'a4b923589a52be57fb84e484c92f4438c275dbc13e5b01a8e9add9d4dd40edcb',
 '/workspace/scratch/fee12ff81cbd/pr11/research/nine/ALL_SIGN_CORRELATED_CORNER_ROW_HAND_STRENGTHENING.md':
 '0d233bddea414938482cb312519da061a546d26c4ee5a5bb83a14b48c178ed02'}

def value_digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def exact_restriction(detail):
    assert set(detail)=={'kind','parent','selected_row','variation_bound','branch',
                         'complete_closed_domains','closed_faces_retained','conditional_row'}
    assert detail['kind']=='opposite_tilt_height_closed_complement'
    assert set(detail['parent'])=={'path','sha256','schema'}
    return SHARP.selected_row(detail)

class Checker(R.Checker):
    def __init__(self,context=DEFAULT_CONTEXT,ancestry=None,strict_root=None):
        context=Path(context).resolve();sys.path.insert(0,str(context))
        context_module=importlib.import_module('replay_context')
        assert Path(context_module.__file__).resolve()==context/'replay_context.py'
        assert digest(context_module.__file__)==CONTEXT_SHA256
        ancestor=R.Checker(context,ancestry,strict_root)
        self.__dict__.update(ancestor.__dict__)
        # The unconditional ancestor has no conditional-row dispatch or state.
        self.ancestor=ancestor
        self.parents={};self.active=set();self.active_sharp_rows=()
        self.touched={};self.dependencies={}
        self.dependencies[str(Path(context_module.__file__).resolve())]=CONTEXT_SHA256
        self.check_pins()
        for module in(self.J,self.D,self.K,self.ID,self.IC,self.A,
                      importlib.import_module('independent_empty_angle_terminal'),
                      importlib.import_module('independent_fixed_bound_terminals')):
            path=Path(module.__file__).resolve();self.dependencies[str(path)]=digest(path)
        # The installed independent ancestry was checked on entry. Retain its
        # literal inventory and every frozen byte through the entire batch.
        manifest_path=self.ancestry/'MANIFEST.json'
        manifest=json.loads(manifest_path.read_text())
        for name,h in manifest['frozen_file_sha256'].items():
            path=(self.ancestry/name).resolve();assert path.is_relative_to(self.ancestry)
            assert digest(path)==h;self.dependencies[str(path)]=h
        for path in(manifest_path,self.ancestry/'SOURCE_BINDINGS.json'):
            self.dependencies[str(path)]=digest(path)
        for filename,expected in PROOFS.items():
            path=self.locate(filename).resolve();assert digest(path)==expected
            self.dependencies[str(path)]=expected

    def check_pins(self):
        for module,expected in((R,ANCESTOR_CHECKER_SHA256),(TE,TRIPLE_HELPER_SHA256),
                               (SHARP,SHARP_ROWS_SHA256),(SHARP_TERMINAL,SHARP_TERMINAL_SHA256)):
            path=Path(module.__file__).resolve();assert digest(path)==expected
            self.dependencies[str(path)]=expected
        own=str(Path(__file__).resolve());current=digest(own)
        assert own not in self.dependencies or self.dependencies[own]==current
        self.dependencies[own]=current

    def recheck(self):
        self.check_pins()
        for mapping in(self.touched,self.dependencies):
            for filename,expected in mapping.items():
                assert digest(filename)==expected,('immutable_input_changed',filename)

    def register_dependencies(self,filename,expected,seen=None,resolved=False):
        seen=set()if seen is None else seen
        path=Path(filename).resolve()if resolved else self.locate(filename).resolve()
        if resolved and self.strict_root is not None:
            assert path.is_relative_to(Path(self.strict_root).resolve())
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==expected
        name=str(path);assert name not in self.touched or self.touched[name]==expected
        self.touched[name]=expected
        key=name,expected
        if key in seen:return
        seen.add(key);record=json.loads(raw)
        for field in('sources','additional_sources'):
            for source,h in(record.get(field)or{}).items():
                resolved=str(self.locate(source).resolve())
                assert resolved not in self.touched or self.touched[resolved]==h
                assert digest(resolved)==h;self.touched[resolved]=h
        prior=record.get('prior')or{}
        if isinstance(prior.get('source'),dict):
            ref=prior['source'];self.register_dependencies(ref['path'],ref['sha256'],seen)
        elif 'file'in prior and 'sha256'in prior:
            self.register_dependencies(prior['file'],prior['sha256'],seen)
        elif 'path'in prior and 'sha256'in prior:
            self.register_dependencies(prior['path'],prior['sha256'],seen)
        continuation=record.get('continuation')or{}
        if 'file'in continuation:
            self.register_dependencies(continuation['file'],continuation['sha256'],seen)
        restriction=record.get('sharp_restriction')or{}
        if 'parent'in restriction:
            ref=restriction['parent'];self.register_dependencies(ref['path'],ref['sha256'],seen)

    def conditional_initial_state(self,record):
        assert record['id']==TARGET_ID and record['path']==TARGET_PATH
        prior=record['prior']
        assert set(prior)=={'path','sha256','schema'}
        assert prior['sha256']==ORIGINAL_PREFIX_SHA256==ROOT_PARENT_SHA256
        assert prior['schema']=='correlated_diagonal_whole_parent_v1'
        detail=record['sharp_restriction'];selected=exact_restriction(detail)
        reference=detail['parent'];assert reference==prior
        parent_path=self.locate(reference['path']).resolve()
        raw=parent_path.read_bytes();assert hashlib.sha256(raw).hexdigest()==reference['sha256']
        literal=json.loads(raw)
        assert literal['schema']==reference['schema']
        assert literal['id']==record['id']and literal['path']==record['path']
        assert literal['status']=='OPEN'and literal['rounds']==[] and 'terminal'not in literal
        assert 'tile'not in literal and 'tile'not in literal['prior']
        frozen=self.ancestry/'cd_family/diagonal_results'/(TARGET_ID+'.json')
        assert digest(frozen)==ORIGINAL_PREFIX_SHA256
        key=str(frozen),ORIGINAL_PREFIX_SHA256
        if key not in self.parents:
            report,parent,diagonal=self.D.replay(frozen)
            assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
            assert parent['id']==TARGET_ID and parent['path']==TARGET_PATH
            assert literal['final']==self.view(parent,diagonal)
            assert not parent.get('conditional_sharp_rows')
            self.parents[key]=(report,copy.deepcopy(parent),copy.deepcopy(diagonal))
        self.recheck()
        report,parent,diagonal=self.parents[key]
        assert digest(frozen)==ORIGINAL_PREFIX_SHA256 and digest(parent_path)==ORIGINAL_PREFIX_SHA256
        assert literal['final']==self.view(parent,diagonal)
        state=copy.deepcopy(parent);state['conditional_sharp_rows']=(selected,)
        facts=dict(parent_bound_record=dict(reference),whole_original_prefix_sha256=ROOT_PARENT_SHA256,
            parent_physical_state_sha256=value_digest(self.view(parent,diagonal)),
            inherited_sharp_rows=[],selected_sharp_row=SHARP.literal(selected),
            all_inherited_bounds_retained=True,original_prefix_sha256=ORIGINAL_PREFIX_SHA256,
            center_or_angle_subdivision_used=False,earlier_sibling_restrictions_added=False)
        return state,copy.deepcopy(diagonal),report,report,facts

    def printed_rows(self,saved,total,base,bounds,scalar,diff,diagonal,angles):
        indices=[e['index']for e in saved]
        assert len(indices)==len(set(indices))and all(type(k)is int and 0<=k<total for k in indices)
        ordinary=[entry for entry in saved if not entry['name'].startswith(('opposite_tilt_AHID_',))]
        rows,names=super().printed_rows(ordinary,total,base,bounds,scalar,diff,diagonal,angles)
        rows.extend([((),F(0),'UNUSED_UNVERIFIED')]*max(0,max(indices,default=-1)+1-len(rows)))
        for entry in saved:
            k,name=entry['index'],entry['name']
            if not name.startswith(('opposite_tilt_AHID_',)):continue
            assert k>=len(base)
            # Names are not sufficient: nested parameter choices can produce
            # identical names with different right sides. Compare the entire
            # selected literal against every retained physical restriction.
            matches=[row for row in self.active_sharp_rows
                     if canonical(row,len(bounds))==canonical((entry['coefficients'],entry['rhs'],name),len(bounds))]
            assert matches,('unproved_conditional_sharp_row',name)
            rows[k]=matches[0];names.append(name)
        return rows,names

    def replay(self,filename,allow_open=False,return_state=False):
        path=Path(filename).resolve();expected=digest(path);key=str(path),expected
        assert key not in self.active,'Cyclic conditional ancestry.'
        self.recheck();self.register_dependencies(str(path),expected,resolved=True)
        previous=self.active_sharp_rows;self.active.add(key)
        try:
            result=self._replay(path,expected,allow_open)
            self.recheck()
        finally:
            self.active.remove(key);self.active_sharp_rows=previous
        return result if return_state else result[0]

    def _replay(self,path,expected,allow_open):
        start=time.monotonic();raw=path.read_bytes();record=json.loads(raw)
        filehash=hashlib.sha256(raw).hexdigest();assert filehash==expected
        assert record['schema']==SHARP_SCHEMA and record['scope']==SHARP_SCOPE
        assert record['status']in('OPEN','CANDIDATE_CLOSED')and record['new_original_cells']==0
        assert 'continuation'not in record and 'execution_recovery'not in record
        assert len(record['rounds'])<=3
        state,diagonal,prior_report,parent_report,parent_facts=self.conditional_initial_state(record)
        self.active_sharp_rows=tuple(state['conditional_sharp_rows'])
        K=self.K;totalrows=0;deductions=0;newnames=[];stats=[];variable_counts=set()
        early_closed=False;terminal_evidence=None
        for ri,rr in enumerate(record['rounds']):
            assert rr['round']==ri
            base,bounds,pos,scalar,diff,gg=self.reconstruct(rr,state,diagonal)
            assert rr['absolute_variable_bounds']==list(map(str,bounds))
            rows,names=self.printed_rows(rr['printed_rows'],rr['rows'],base,bounds,scalar,diff,gg,state['angles'])
            newnames+=names;variable_counts.add(len(bounds))
            pp=[list(ab)for ab in pos];ss=[list(ab)for ab in scalar]
            dd={pair:[list(ab)for ab in ds]for pair,ds in diff.items()}
            dg={pair:[list(ab)for ab in ds]for pair,ds in gg.items()}
            used=set();objectives=set();counts=Counter()
            for p in rr['proposals']:
                kind,key,sign=p['kind'],p['key'],p['sign']
                assert type(sign)is int and sign in(-1,1)
                assert kind in('scalar','difference','diagonal');counts[kind]+=1
                if kind=='scalar':
                    assert type(key)is int and 0<=key<54 and p['objective']==[[key,sign]]
                    target=pp[key]if key<18 else ss[key-18]
                    old=pos[key]if key<18 else scalar[key-18]
                else:
                    assert isinstance(key,list)and len(key)==3 and all(type(k)is int for k in key)
                    i,j,axis=key;assert 0<=i<j<9 and axis in(0,1)
                    if kind=='difference':
                        assert p['objective']==[[2*j+axis,sign],[2*i+axis,-sign]]
                        target=dd[i,j][axis];old=diff[i,j][axis]
                    else:
                        sy=1 if axis==0 else-1
                        assert p['objective']==[[2*j,sign],[2*i,-sign],[2*j+1,sign*sy],[2*i+1,-sign*sy]]
                        target=dg[i,j][axis];old=gg[i,j][axis]
                objective=tuple(map(tuple,p['objective']));assert objective not in objectives
                objectives.add(objective)
                assert F(p['old'])==(old[1]if sign==1 else-old[0])
                upper=K.audit_bound(rows,bounds,p)
                if sign==1:target[1]=min(target[1],upper)
                else:target[0]=max(target[0],-upper)
                used.update(k for k,w in p['weights']);deductions+=1
            assert used=={e['index']for e in rr['printed_rows']};totalrows+=len(used)
            pos=box(pp,True);scalar=box(ss,True)
            diff={pair:box(ds,True)for pair,ds in dd.items()};diagonal={pair:box(ds,True)for pair,ds in dg.items()}
            witness=empty_interval_witness(pos+scalar,'empty_proved_interval')
            if witness is None:
                for kind,mapping in(('difference',diff),('diagonal',diagonal)):
                    for pair,intervals in sorted(mapping.items()):
                        for axis,(lo,hi)in enumerate(intervals):
                            if lo>hi:
                                witness=dict(kind='empty_proved_interval',coordinate_kind=kind,
                                    pair=list(pair),axis=axis,lower=str(lo),upper=str(hi),gap=str(lo-hi))
                                break
                        if witness is not None:break
                    if witness is not None:break
            if witness is not None:
                assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='empty_proved_interval'
                assert ri==len(record['rounds'])-1 and 'after'not in rr
                terminal_evidence=witness;early_closed=True
                expected_final=self.view(state,diagonal);expected_final['differences']=K.diffview(diff)
                assert record['final']==expected_final
                stats.append(dict(round=ri,printed_rows=len(used),**counts))
                break
            if record.get('terminal',{}).get('kind')=='proved_empty_original_angle_interval'and ri==len(record['rounds'])-1:
                assert record['status']=='CANDIDATE_CLOSED'and 'after'not in rr
                terminal_evidence=verify_empty_angle(K,state['angles'],scalar,rr['physical_frame_inferences'])
                early_closed=True
                # The producer exits before updating the scalar/center/angle
                # state, but after updating its two local difference maps.
                expected_final=self.view(state,diagonal)
                expected_final['differences']=K.diffview(diff)
                assert record['final']==expected_final
                stats.append(dict(round=ri,printed_rows=len(used),**counts))
                break
            angles=K.angles_from_scalar(state['angles'],scalar,rr['physical_frame_inferences'])
            analytic=K.analytic(angles)
            intersection=tuple((max(lo,a),min(hi,b))for(lo,hi),(a,b)in zip(scalar,analytic))
            witness=empty_interval_witness(intersection,'empty_physical_frame',18)
            if witness is not None:
                assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='empty_physical_frame'
                assert ri==len(record['rounds'])-1 and 'after'not in rr
                index=witness['index']-18
                witness.update(certified_interval=list(map(str,scalar[index])),
                    analytic_interval=list(map(str,analytic[index])),
                    derived_slope_interval=list(map(str,angles[index%9])),checked_frame_inferences=9)
                terminal_evidence=witness;early_closed=True
                expected_final=self.view(state,diagonal)
                expected_final['differences']=K.diffview(diff)
                assert record['final']==expected_final
                stats.append(dict(round=ri,printed_rows=len(used),**counts))
                break
            scalar=box(intersection)
            state=dict(state,positions=pos,scalar=scalar,angles=angles,differences=diff)
            assert rr['after']==self.view(state,diagonal)
            stats.append(dict(round=ri,printed_rows=len(used),**counts))
            print(record['id'],'PASS FIXED-TILE DIAGONAL ROUND',stats[-1],flush=True)
        if not early_closed:assert record['final']==self.view(state,diagonal)
        reserve=None;terminal_rows=0
        if record['status']=='CANDIDATE_CLOSED'and not early_closed and record['terminal']['kind']=='accepted_shared_sharp_boundary_terminal':
            terminal=record['terminal'];rr=terminal['state']
            assert rr['round']==len(record['rounds'])and rr['proposals']==[]
            base,bounds,pos,scalar,diff,gg=self.reconstruct(rr,state,diagonal)
            physical=dict(state,positions=pos,scalar=scalar,differences=diff)
            guard=SHARP_TERMINAL.evaluate_any_guard(physical)
            assert guard['status']=='PASS_SHARP_PHYSICAL_ROW_GUARD'
            assert terminal['guard']==guard
            terminal_evidence=dict(kind='accepted_shared_sharp_boundary_terminal',guard=guard,
                strict_original_C887_caller_replayed=True,all_nine_originals_retained=True)
            early_closed=True
        if record['status']=='CANDIDATE_CLOSED'and not early_closed and record['terminal']['kind']=='exact_interval_terminal':
            terminal_evidence=self.interval_terminal(record['terminal'],state,diagonal,len(record['rounds']))
            early_closed=True
        if record['status']=='CANDIDATE_CLOSED'and not early_closed:
            terminal=record['terminal'];assert terminal['kind']=='positive_exact_reserve','Unsupported terminal kind.'
            rr=terminal['state'];assert rr['round']==len(record['rounds'])
            base,bounds,pos,scalar,diff,gg=self.reconstruct(rr,state,diagonal)
            assert terminal['absolute_variable_bounds']==list(map(str,bounds))
            rows,names=self.printed_rows(terminal['printed_rows'],rr['rows'],base,bounds,scalar,diff,gg,state['angles'])
            newnames+=names;variable_counts.add(len(bounds))
            used={k for k,w in terminal['weights']};assert used=={e['index']for e in terminal['printed_rows']}
            co,rhs=K.sum_rows(rows,bounds,terminal['weights'])
            reserve=-rhs-sum(bound*abs(c)for bound,c in zip(bounds,co))
            assert reserve>0 and reserve==F(terminal['reserve'])
            assert terminal['weighted_rhs']==str(rhs)and terminal['weighted_coefficients']==list(map(str,co))
            terminal_rows=len(used);totalrows+=terminal_rows
        elif record['status']=='OPEN':
            assert allow_open,'Explicit --allow-open required for a state-only replay.'
            if 'final_test'in record:
                assert record['final_test']['round']==len(record['rounds'])
                assert record['final_test']['proposals']==[]
                self.reconstruct(record['final_test'],state,diagonal)
        forbidden=('numpy','scipy','highspy','v3_whole_parent_pass','quadratic_moment_pilot',
                   'diagonal_rows','correlated_capacity_rows','four_center_rows','square_area_moment_rows','three_square_energy_rows')
        assert not any(name in sys.modules for name in forbidden)
        assert digest(path)==filehash,'The producer rewrote this record during replay.'
        self.recheck()
        prior=record['prior']
        report=dict(schema='independent_C887_whole_opposite_tilt_height_replay_v1',id=record['id'],
            status='PASS_COMPLETE_CONDITIONAL_ORIGINAL_DOMAIN'if reserve is not None or early_closed else'PASS_CERTIFIED_CONDITIONAL_ORIGINAL_STATE_OPEN',
            tile=None,closed_cover_parts=None,rectangle=None,
            h_rectangle=None,original_parent_path=record['path'],
            sharp_restriction=record['sharp_restriction'],conditional_sharp_rows=[SHARP.literal(row)for row in self.active_sharp_rows],
            original_prefix_replay=prior_report,conditional_parent_replay=parent_report,
            conditional_parent_facts=parent_facts,inherited_diagonals_retained=True,
            all_inherited_bounds_retained_before_local_propagation=True,
            bound_rounds=len(stats),bound_deductions=deductions,round_reports=stats,
            original_variables=54,affine_variable_counts=sorted(variable_counts),
            printed_rows_checked=totalrows,terminal_rows=terminal_rows,reserve=str(reserve)if reserve is not None else None,
            terminal_kind=record.get('terminal',{}).get('kind'),terminal_label=record.get('terminal',{}).get('label'),
            terminal_evidence=terminal_evidence,early_exit_stale_final_fields_used_as_derived_state=False,
            independently_rebuilt_new_rule_counts=dict(Counter(name.split('_')[0]for name in newnames)),
            independently_rebuilt_three_square_energy_rows=sum(name.startswith('three_square_center_energy_')for name in newnames),
            independently_rebuilt_conditional_sharp_rows=sum(name.startswith(('opposite_tilt_AHID_',))for name in newnames),
            source_sha256=dict(self.touched),checker_dependency_sha256=dict(self.dependencies),
            all_declared_dependencies_rehashed_after_replay=True,certificate_sha256=filehash,
            checker_sha256=digest(__file__),verified_producer_source_bindings=len(record['sources']),
            ancestor_checker_sha256=ANCESTOR_CHECKER_SHA256,unfinished_rounds_admitted=False,
            unsupported_rules_accepted=False,numerical_producer_or_optimizer_imported=False,
            whole_parent_cover_checked=False,complete_eight_height_cover_checked=False,
            complete_fixed_tiles=0,new_original_cells=0,new_masks=0,seconds=time.monotonic()-start)
        print(record['id'],'CONDITIONAL SHARP BOUND REPLAY',report['status'],'rows',totalrows,flush=True)
        return report,state,diagonal

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('certificates',type=Path,nargs='+')
    ap.add_argument('--context',type=Path,default=DEFAULT_CONTEXT)
    ap.add_argument('--ancestry',type=Path)
    ap.add_argument('--strict-root',type=Path)
    ap.add_argument('--allow-open',action='store_true')
    ap.add_argument('--report',type=Path,required=True)
    a=ap.parse_args();checker=Checker(a.context,a.ancestry,a.strict_root)
    results=[checker.replay(path,a.allow_open)for path in a.certificates]
    keys=[r['certificate_sha256']for r in results];assert len(keys)==len(set(keys))
    checker.recheck()
    for result in results:
        for field in('source_sha256','checker_dependency_sha256'):
            for name,h in result[field].items():assert digest(name)==h,('earlier_sibling_input_changed',name)
    report=dict(schema='independent_C887_whole_opposite_tilt_height_batch_v1',
        status='PASS_ALL_LISTED_CONDITIONAL_PROOFS',conditional_records=len(results),
        conditional_terminals=sum(r['status']=='PASS_COMPLETE_CONDITIONAL_ORIGINAL_DOMAIN'for r in results),
        conditional_open_states=sum(r['status']=='PASS_CERTIFIED_CONDITIONAL_ORIGINAL_STATE_OPEN'for r in results),
        bound_deductions=sum(r['bound_deductions']for r in results),
        printed_rows_checked=sum(r['printed_rows_checked']for r in results),conditional_reports=results,
        all_sibling_inputs_rehashed_before_report=True,complete_eight_height_cover_checked=False,
        complete_fixed_tiles=0,whole_parent_cover_checked=False,new_original_cells=0,new_masks=0)
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='conditional_reports'},indent=2))

if __name__=='__main__':main()
