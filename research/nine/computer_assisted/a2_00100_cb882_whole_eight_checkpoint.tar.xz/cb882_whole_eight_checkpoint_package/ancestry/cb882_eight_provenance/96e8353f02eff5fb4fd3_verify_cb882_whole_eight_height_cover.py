#!/usr/bin/env python3
"""Exact whole-original CB882 cover by all eight opposite-tilt height domains.

The published full-angle theorem is freshly replayed first.  The complete
original ancestor is then replayed independently, and its opposite endpoint
signs and all three weak AHID orders are checked before the eight literal
closed height domains are assembled.  An OPEN child never closes an original.
"""
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import argparse
import copy
import importlib
import json
import subprocess
import sys
import time

if not __debug__:
    raise RuntimeError('Exact replay requires assertions; Python -O is unsupported')

COMPONENT_NAME = 'verify_cb882_whole_opposite_tilt_height_bounds'
COMPONENT_SHA = '53313a8e79b32bcf4b035c9e57b9f5a7df091ae6fe9762ba33058e6892865ba0'
HELPER_SHA = '74eff0691ccd464ae23aeaf6d36ee20c411732e965dad040dad9304dc5b286d6'
SPEC_SHA = 'e4825423f302b0920ce001090cea28624af840904d27169e98cdb22c3eed8b48'
PREFIX_SHA = '1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'
V3_SHA = '61d2a2f8ac9656b6c5f8a9f89113a8ea80dc239b767baa0c601d27d91f1007d8'
THEOREM_MANIFEST_SHA = '603024e697b2d11b6ef4dc5092cf07df7cccaf5ddefbac1bc4bb04d0338d2104'
THEOREM_CHECKER_SHA = 'a43677be66d0dd2ac2d629ae839c7b9256ceda0aaef517ffbe5813e65f8d30d0'
THEOREM_HAND_SHA = 'db830ffbebdc807b0e05f78766e0a0509d11418be31b9a7ef0623b212328831a'
DECLARED_SCHEMA = 'declared_CB882_whole_original_eight_height_cover_v1'
COMPLETE_SCHEMA = 'complete_CB882_whole_original_eight_height_cover_v1'
TARGET = 'negative-b882d8ade0cf9ea0'
TARGET_PATH = [['angle', 3, 0], ['angle_cut', [0, '0'], 1],
               ['alternate_four_escape', [1, 7], [3]]]


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def value_digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def literal_rows():
    """Reconstruct the eight forms directly, independently of the component."""
    result = []
    for index, (a, b, c) in enumerate(product((-1, 1), repeat=3)):
        co = {1: F(a), 15: F(b-a), 17: F(c-b), 7: F(-c)}
        terms = tuple((k, v) for k, v in sorted(co.items()) if v)
        row = terms, F(-23, 100), 'opposite_tilt_AHID_variation_' + str(index)
        literal = dict(coefficients=[[k, str(v)] for k, v in terms],
                       rhs='-23/100', name=row[2])
        result.append((list((a, b, c)), row, literal))
    assert len(result) == 8
    return result


def prerequisites(state):
    """Exact whole-parent signs and coordinate/difference interval intersection."""
    angles = [tuple(map(F, ab)) for ab in state['angles']]
    positions = [tuple(map(F, ab)) for ab in state['positions']]
    assert len(angles) == 9 and len(positions) == 18
    assert angles[0][0] >= 0 and angles[3][1] <= 0
    intervals = []
    for i, j in ((0, 7), (7, 8), (8, 3)):
        lo = positions[2*j][0] - positions[2*i][1]
        hi = positions[2*j][1] - positions[2*i][0]
        if i < j:
            a, b = state['differences'][i, j][0]
        else:
            a, b = state['differences'][j, i][0]
            a, b = -F(b), -F(a)
        lo, hi = max(lo, F(a)), min(hi, F(b))
        assert 0 <= lo <= hi, 'An unproved weak order cannot be omitted from the cover'
        intervals.append([str(lo), str(hi)])
    assert [ab[0] for ab in intervals] == [
        '35461/524288', '0', '434432029724121/5000000000000000']
    return dict(opposite_endpoint_signs_proved=True,
        endpoint_angle_intervals=[[str(v) for v in angles[i]] for i in (0, 3)],
        proved_weak_order_intervals=intervals)


class WholeCoverChecker:
    def __init__(self, context, ancestry=None, strict_root=None, theorem_root=None):
        self.context = Path(context).resolve()
        self.strict_root = Path(strict_root).resolve() if strict_root is not None else None
        if self.strict_root is not None:
            assert self.context.is_relative_to(self.strict_root)
        self.dependencies = {str(Path(__file__).resolve()): digest(__file__)}
        self.outer_manifest_path = self.context / 'SHA256_MANIFEST.json'
        self.outer_manifest_bytes = self.outer_manifest_path.read_bytes()
        outer = json.loads(self.outer_manifest_bytes)
        assert isinstance(outer['files'], dict)
        for name, expected in outer['files'].items():
            relative = Path(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            path = (self.context / relative).resolve()
            assert path.is_relative_to(self.context)
            self.retain(path, expected)
        self.retain(self.outer_manifest_path, sha256(self.outer_manifest_bytes).hexdigest())
        self.theorem_root = Path(theorem_root or self.context / 'opposite_tilt_theorem').resolve()
        if self.strict_root is not None:
            assert self.theorem_root.is_relative_to(self.strict_root)
        # Run the independent scalar packet before installing ancestor read guards.
        # All input bytes are retained across the subprocess and all later siblings.
        self.theorem_report = self.replay_theorem()
        sys.path.insert(0, str(self.context))
        self.C = importlib.import_module(COMPONENT_NAME)
        assert Path(self.C.__file__).resolve() == self.context / (COMPONENT_NAME + '.py')
        self.retain(self.C.__file__, COMPONENT_SHA)
        assert Path(self.C.SHARP.__file__).resolve() == self.context / 'independent_opposite_tilt_height_rows.py'
        self.retain(self.C.SHARP.__file__, HELPER_SHA)
        self.checker = self.C.Checker(self.context, ancestry, self.strict_root)
        self.recheck()

    def retain(self, path, expected):
        path = Path(path).resolve()
        if self.strict_root is not None:
            assert path.is_relative_to(self.strict_root)
        name = str(path)
        old = self.dependencies.get(name)
        assert old is None or old == expected, ('conflicting_input_hash', name)
        assert digest(path) == expected, ('changed_input', name)
        self.dependencies[name] = expected

    def recheck(self):
        assert self.outer_manifest_path.read_bytes() == self.outer_manifest_bytes
        for filename, expected in self.dependencies.items():
            assert digest(filename) == expected, ('immutable_input_changed', filename)
        if hasattr(self, 'checker'):
            self.checker.recheck()

    def replay_theorem(self):
        manifest_path = self.theorem_root / 'MANIFEST.json'
        self.retain(manifest_path, THEOREM_MANIFEST_SHA)
        manifest = json.loads(manifest_path.read_text())
        assert manifest['schema'] == 'opposite_tilt_ahid_row_packet_v1'
        assert len(manifest['immutable_inputs']) == 101
        for name, expected in manifest['immutable_inputs'].items():
            relative = Path(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            path = (self.theorem_root / relative).resolve()
            assert path.is_relative_to(self.theorem_root)
            self.retain(path, expected)
        self.retain(self.theorem_root / 'verify_all.py', THEOREM_CHECKER_SHA)
        self.retain(self.theorem_root / 'HAND_PROOF.md', THEOREM_HAND_SHA)
        output = self.theorem_root / 'FRESH_REPLAY.json'
        log = self.context / 'new_reviews/WHOLE_EIGHT_HEIGHT_THEOREM_REPLAY.log'
        assert str(output.resolve()) not in self.dependencies
        assert str(log.resolve()) not in self.dependencies
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('w') as stream:
            subprocess.run([sys.executable, '-B', '-S', str(self.theorem_root / 'verify_all.py')],
                           cwd=self.theorem_root, stdout=stream, stderr=subprocess.STDOUT, check=True)
        report = json.loads(output.read_text())
        assert report['status'] == 'PASS_PORTABLE_COMPLETE_OPPOSITE_TILT_AHID_ROW'
        assert report['immutable_inputs_checked'] == 101
        scalar = report['table']
        assert scalar['complete_domains'] == 80 and scalar['leaves'] == 1405
        assert scalar['coefficient_checks'] == 878125 and scalar['frontier'] == 0
        assert report['guard_algebra']['checks'] == 529
        assert report['guard_algebra']['complete_complement_domains'] == 11
        assert len(report['negative_controls']['controls']) == 8
        assert report['new_original_cells_closed'] == report['new_masks_closed'] == 0
        self.recheck()
        return dict(report=report, fresh_report_sha256=digest(output),
                    manifest_sha256=THEOREM_MANIFEST_SHA, checker_sha256=THEOREM_CHECKER_SHA,
                    hand_proof_sha256=THEOREM_HAND_SHA, freshly_replayed=True)

    def frozen(self, reference):
        assert isinstance(reference, dict) and {'path', 'sha256'} <= set(reference)
        path = self.checker.locate(reference['path']).resolve()
        self.retain(path, reference['sha256'])
        raw = path.read_bytes()
        assert sha256(raw).hexdigest() == reference['sha256']
        record = json.loads(raw)
        if 'schema' in reference:
            assert record['schema'] == reference['schema']
        return path, record

    def replay_parent(self, reference):
        assert set(reference) == {'path', 'sha256', 'schema'}
        assert reference['sha256'] == PREFIX_SHA
        assert reference['schema'] == 'correlated_diagonal_whole_parent_v1'
        path, literal = self.frozen(reference)
        self.checker.register_dependencies(reference['path'], PREFIX_SHA)
        assert literal['id'] == TARGET and literal['path'] == TARGET_PATH
        assert literal['status'] == 'OPEN' and literal['rounds'] == []
        assert literal['new_original_cells'] == 0 and 'terminal' not in literal
        assert literal['prior']['kind'] == 'v3' and literal['prior']['sha256'] == V3_SHA
        forbidden = {'tile', 'tile_context', 'rectangle', 'h_rectangle', 'center_cover',
                     'slope_restriction', 'sharp_restriction', 'derived_H_cover'}
        assert not (set(literal) & forbidden) and not (set(literal['prior']) & forbidden)
        frozen = self.checker.ancestry / 'cd_family/diagonal_results' / (TARGET + '.json')
        self.retain(frozen, PREFIX_SHA)
        report, state, diagonal = self.checker.D.replay(frozen)
        assert report['certificate_sha256'] == PREFIX_SHA
        assert report['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
        assert report['rounds'] == [] and report['new_original_cells'] == 0
        old = report['prior_report']
        assert old['certificate_sha256'] == V3_SHA and old['center_cover'] is None
        assert old['whole_original_parent_closed'] is False
        assert old['bound_induction_branch_nodes'] == 0 and old['rounds'] == 5
        assert old['new_deductions'] == 386 and old['prior_coordinate_deductions'] == 30
        assert state['id'] == TARGET and state['path'] == TARGET_PATH
        assert not state.get('conditional_sharp_rows')
        physical_view = self.checker.view(state, diagonal)
        assert literal['final'] == physical_view
        evidence = prerequisites(state)
        assert evidence == self.C.SHARP.prerequisites(state)
        # The component's whole-parent loader uses this exact immutable cache key.
        key = str(frozen), PREFIX_SHA
        assert key not in self.checker.parents
        self.checker.parents[key] = report, copy.deepcopy(state), copy.deepcopy(diagonal)
        self.recheck()
        return literal, report, state, diagonal, evidence, value_digest(physical_view)

    def replay(self, filename, allow_partial=False):
        start = time.monotonic()
        path = Path(filename).resolve()
        raw = path.read_bytes()
        manifest_sha = sha256(raw).hexdigest()
        self.retain(path, manifest_sha)
        manifest = json.loads(raw)
        assert manifest['schema'] in (DECLARED_SCHEMA, COMPLETE_SCHEMA)
        assert manifest['schema'] == COMPLETE_SCHEMA or allow_partial
        assert manifest['new_original_cells'] == manifest['new_masks'] == 0
        assert manifest['selected_row'] == [0, 7, 8, 3] and manifest['variation_bound'] == '23/100'
        assert manifest['complete_closed_domains'] == 8 and manifest['closed_faces_retained'] is True
        assert manifest['children_are_independent_same_parent_restrictions'] is True
        assert manifest['earlier_sibling_complements_added'] is False and manifest['center_subdivisions'] == 0
        specification = manifest['specification']
        assert specification['sha256'] == SPEC_SHA
        _, spec = self.frozen(specification)
        assert spec['schema'] == 'CB882_whole_original_complete_opposite_endpoint_height_cover_specification_v1'
        for filename, expected in spec['source_sha256'].items():
            self.retain(self.checker.locate(filename), expected)
        parent_ref = manifest['parent']
        assert parent_ref == spec['parent']
        parent, prior, parent_state, diagonal, facts, state_hash = self.replay_parent(parent_ref)
        assert spec['original_id'] == TARGET and spec['original_path'] == TARGET_PATH
        assert spec['proved_weak_order_intervals'] == facts['proved_weak_order_intervals']
        assert spec['opposite_signed_slopes'] == facts['endpoint_angle_intervals']
        assert spec['center_subdivisions'] == spec['extra_angle_subdivisions'] == 0
        assert spec['theorem_manifest_sha256'] == THEOREM_MANIFEST_SHA
        expected_rows = literal_rows()
        assert tuple(row for signs, row, literal in expected_rows) == self.C.SHARP.complete_rows()
        children = manifest['children']
        assert len(children) == 8 and [entry['branch'] for entry in children] == list(range(8))
        assert all(type(entry['branch']) is int for entry in children)
        reports = []
        used = {}
        for branch, (entry, (signs, row, literal)) in enumerate(zip(children, expected_rows)):
            assert entry['signs'] == signs and entry['row'] == literal
            assert spec['children'][branch]['branch'] == branch
            assert spec['children'][branch]['signs'] == signs
            assert spec['children'][branch]['conditional_row'] == literal
            assert entry['kind'] in ('bound_terminal', 'open_bound_state')
            reference = entry['bound']
            assert set(reference) == {'path', 'sha256', 'schema'}
            assert reference['schema'] == self.C.SHARP_SCHEMA
            child_path, child = self.frozen(reference)
            if 'packet_certificate' in entry:
                relative = Path(entry['packet_certificate'])
                assert not relative.is_absolute() and '..' not in relative.parts
                packet_path = (self.context / relative).resolve()
                assert packet_path.is_relative_to(self.context)
                self.retain(packet_path, reference['sha256'])
                assert packet_path.read_bytes() == child_path.read_bytes()
                child_path = packet_path
            expected_detail = dict(kind='opposite_tilt_height_closed_complement', parent=parent_ref,
                selected_row=[0, 7, 8, 3], variation_bound='23/100', branch=branch,
                complete_closed_domains=8, closed_faces_retained=True, conditional_row=literal)
            assert child['id'] == TARGET and child['path'] == TARGET_PATH and child['prior'] == parent_ref
            assert child['scope'] == self.C.SHARP_SCOPE and child['sharp_restriction'] == expected_detail
            report, state, child_diagonal = self.checker.replay(child_path, allow_open=True, return_state=True)
            assert report['certificate_sha256'] == reference['sha256'] == digest(child_path)
            assert report['checker_sha256'] == COMPONENT_SHA
            assert report['original_parent_path'] == TARGET_PATH
            assert report['tile'] is report['rectangle'] is report['h_rectangle'] is None
            assert report['new_original_cells'] == report['new_masks'] == report['complete_fixed_tiles'] == 0
            assert report['original_prefix_replay']['certificate_sha256'] == PREFIX_SHA
            pf = report['conditional_parent_facts']
            assert pf['parent_bound_record'] == parent_ref
            assert pf['parent_physical_state_sha256'] == state_hash
            assert pf['whole_original_prefix_sha256'] == pf['original_prefix_sha256'] == PREFIX_SHA
            assert pf['all_inherited_bounds_retained'] is True and pf['inherited_sharp_rows'] == []
            assert pf['selected_sharp_row'] == literal
            assert pf['center_or_angle_subdivision_used'] is False
            assert pf['earlier_sibling_restrictions_added'] is False
            assert report['conditional_sharp_rows'] == [literal] and state['conditional_sharp_rows'] == (row,)
            closed = entry['kind'] == 'bound_terminal'
            if closed:
                assert child['status'] == 'CANDIDATE_CLOSED'
                assert report['status'] == 'PASS_COMPLETE_CONDITIONAL_ORIGINAL_DOMAIN'
            else:
                assert allow_partial and manifest['schema'] == DECLARED_SCHEMA
                assert child['status'] == 'OPEN'
                assert report['status'] == 'PASS_CERTIFIED_CONDITIONAL_ORIGINAL_STATE_OPEN'
                assert child['final_test']['round'] == len(child['rounds'])
                assert child['final_test']['proposals'] == []
                assert child['final'] == self.checker.view(state, child_diagonal)
                if child['rounds']:
                    assert child['final'] == child['rounds'][-1]['after']
            key = report['certificate_sha256']
            assert key not in used, 'A child certificate cannot stand for two different domains'
            used[key] = dict(certificate_sha256=key, branch=branch,
                bound_rounds=report['bound_rounds'], bound_deductions=report['bound_deductions'],
                bound_premise_rows=report['printed_rows_checked'] - report['terminal_rows'],
                terminal_rows=report['terminal_rows'], reserve=report['reserve'],
                terminal_kind=report['terminal_kind'])
            assert used[key]['bound_premise_rows'] >= 0
            reports.append(dict(branch=branch, signs=signs, row=literal,
                status='PASS_COMPLETE_HEIGHT_DOMAIN' if closed else 'OPEN_CERTIFIED_HEIGHT_DOMAIN',
                bound_report=report))
            self.recheck()
        open_indices = [r['branch'] for r in reports if r['status'] == 'OPEN_CERTIFIED_HEIGHT_DOMAIN']
        complete = not open_indices
        assert allow_partial or complete
        if manifest['schema'] == COMPLETE_SCHEMA:
            assert complete
        self.recheck()
        for report in reports:
            for field in ('source_sha256', 'checker_dependency_sha256'):
                for filename, expected in report['bound_report'][field].items():
                    assert digest(filename) == expected, ('earlier_sibling_changed', filename)
        modules = {}
        if self.strict_root is not None:
            for name, module in sorted(sys.modules.items()):
                origin = getattr(module, '__file__', None)
                if origin and Path(origin).resolve().is_relative_to('/workspace'):
                    origin = Path(origin).resolve()
                    assert origin.is_relative_to(self.strict_root), ('external_loaded_module', name, str(origin))
                    modules[name] = str(origin.relative_to(self.strict_root))
        old = prior['prior_report']
        descriptors = [used[key] for key in sorted(used)]
        local_rounds = sum(r['bound_rounds'] for r in descriptors)
        local_deductions = sum(r['bound_deductions'] for r in descriptors)
        local_rows = sum(r['bound_premise_rows'] for r in descriptors)
        result = dict(schema='independent_CB882_whole_original_eight_height_cover_replay_v1',
            status='PASS_COMPLETE_ORIGINAL_BY_EIGHT_HEIGHT_COVER' if complete else 'PASS_DECLARED_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_WITH_OPEN_DOMAINS',
            id=TARGET, original_parent_path=TARGET_PATH, parent=parent_ref,
            original_prefix_sha256=PREFIX_SHA, whole_original_physical_state_sha256=state_hash,
            whole_original_prerequisites=facts, parent_exact_replay=prior,
            fresh_opposite_tilt_theorem_replay=self.theorem_report,
            cover_specification_sha256=SPEC_SHA, cover_sha256=manifest_sha,
            selected_row=[0, 7, 8, 3], variation_bound='23/100', complete_closed_domains=8,
            complete_domain_union_checked=True, closed_faces_retained=True,
            children_are_independent_same_whole_parent_restrictions=True,
            earlier_sibling_complements_added=False, center_subdivisions=0,
            conditional_terminals=8-len(open_indices), open_domains=len(open_indices),
            open_domain_indices=open_indices, child_reports=reports,
            local_distinct_bound_records=8, local_unique_bound_records=descriptors,
            local_bound_rounds=local_rounds, local_bound_deductions=local_deductions,
            local_bound_premise_rows=local_rows,
            terminal_rows=sum(r['terminal_rows'] for r in descriptors),
            common_whole_parent_counted_once=True,
            common_whole_parent_rounds=old['rounds'], common_whole_parent_deductions=old['new_deductions'],
            earlier_coordinate_deductions=old['prior_coordinate_deductions'],
            total_bound_rounds_including_common_parent=local_rounds + old['rounds'],
            total_bound_deductions_including_common_parent=local_deductions + old['new_deductions'],
            source_sha256=dict(self.checker.touched),
            checker_dependency_sha256=dict(self.checker.dependencies, **self.dependencies),
            all_earlier_sibling_theorem_and_ancestor_bytes_rehashed=True,
            source_manifest_sha256=sha256(self.outer_manifest_bytes).hexdigest(),
            checker_sha256=digest(__file__), component_checker_sha256=COMPONENT_SHA,
            local_module_import_audit=modules, strict_portable_root_used=self.strict_root is not None,
            complete_eight_height_cover_checked=complete, whole_original_cover_checked=complete,
            complete_fixed_tiles=0, new_original_cells=int(complete), new_masks=0,
            seconds=time.monotonic()-start)
        self.recheck()
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cover', type=Path)
    parser.add_argument('--context', type=Path, required=True)
    parser.add_argument('--ancestry', type=Path)
    parser.add_argument('--strict-root', type=Path)
    parser.add_argument('--theorem-root', type=Path)
    parser.add_argument('--allow-partial', action='store_true')
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    checker = WholeCoverChecker(args.context, args.ancestry, args.strict_root, args.theorem_root)
    result = checker.replay(args.cover, allow_partial=args.allow_partial)
    output = args.report.resolve()
    if checker.strict_root is not None:
        assert output.is_relative_to(checker.strict_root)
    assert str(output) not in checker.dependencies and str(output) not in checker.checker.touched
    checker.recheck()
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'conditional_terminals', 'open_domains',
        'local_bound_rounds', 'local_bound_deductions', 'local_bound_premise_rows', 'terminal_rows',
        'new_original_cells', 'new_masks')}, indent=2))


if __name__ == '__main__':
    main()
