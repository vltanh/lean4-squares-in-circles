#!/usr/bin/env python3
"""Freeze the necessary whole-original CB882 height cover before discovery."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PACKET = HERE / 'cb882_whole_eight_package'
THEOREM = ROOT / 'pr11/research/nine/computer_assisted/opposite_tilt_ahid_row'
PREFIX = ROOT / 'cd_family/new_cd_prefixes/negative-b882d8ade0cf9ea0.json'
OUT = HERE / 'CB882_WHOLE_ORIGINAL_EIGHT_HEIGHT_COVER_SPECIFICATION.json'
digest = lambda p: sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not OUT.exists()
    report_path = PACKET / 'CB882_WHOLE_PARENT_EXACT_REPLAY.json'
    report = json.loads(report_path.read_text())
    assert report['status'] == 'PASS_CERTIFIED_WHOLE_ORIGINAL_STATE_OPEN'
    assert report['certificate_sha256'] == digest(PREFIX) == '1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'
    assert report['ancestor_replay']['prior_report']['new_deductions'] == 386
    assert report['ancestor_replay']['prior_report']['rounds'] == 5
    prefix = json.loads(PREFIX.read_text())
    assert prefix['final'] == report['physical_state'] and prefix['rounds'] == []
    state = prefix['final']
    pos = [tuple(map(F, ab)) for ab in state['positions']]
    angles = [tuple(map(F, ab)) for ab in state['angles']]
    differences = {tuple(e['pair']): tuple(tuple(map(F, ab)) for ab in e['intervals'])
                   for e in state['differences']}
    assert angles[0][0] >= 0 and angles[3][1] <= 0
    orders = []
    for i, j in ((0, 7), (7, 8), (8, 3)):
        lo, hi = pos[2*j][0]-pos[2*i][1], pos[2*j][1]-pos[2*i][0]
        a, b = differences[min(i,j), max(i,j)][0]
        if i > j:
            a, b = -b, -a
        lo, hi = max(lo, a), min(hi, b)
        assert 0 <= lo <= hi
        orders.append([str(lo), str(hi)])
    assert [ab[0] for ab in orders] == ['35461/524288', '0', '434432029724121/5000000000000000']
    assert orders == report['opposite_tilt_eight_height_prerequisites']['proved_weak_order_intervals']
    dependencies = [Path(__file__).resolve(), HERE/'CB882_WHOLE_EIGHT_HEIGHT_HAND_REDUCTION.md',
        PREFIX, Path(prefix['prior']['path']), report_path,
        HERE/'independent_opposite_tilt_height_rows.py', THEOREM/'MANIFEST.json',
        ROOT/'pr11/research/nine/OPPOSITE_ENDPOINT_TILTS_FULL_ANGLE_FOUR_ROW_HAND_TERMINAL.md']
    sources = {str(path): digest(path) for path in dependencies}
    theorem = json.loads((THEOREM/'MANIFEST.json').read_text())
    assert digest(THEOREM/'MANIFEST.json') == '603024e697b2d11b6ef4dc5092cf07df7cccaf5ddefbac1bc4bb04d0338d2104'
    for name, expected in theorem['immutable_inputs'].items():
        path = (THEOREM/name).resolve()
        assert path.is_relative_to(THEOREM) and digest(path) == expected
        sources[str(path)] = expected
    children = []
    for index, (a,b,c) in enumerate(product((-1,1), repeat=3)):
        coefficients = {1:a, 15:b-a, 17:c-b, 7:-c}
        children.append(dict(branch=index, signs=[a,b,c], conditional_row=dict(
            coefficients=[[k,str(v)] for k,v in sorted(coefficients.items()) if v],
            rhs='-23/100', name='opposite_tilt_AHID_variation_'+str(index)),
            status='PENDING_COMPLETE_EXACT_CHILD_PROOF'))
    result = dict(schema='CB882_whole_original_complete_opposite_endpoint_height_cover_specification_v1',
        status='PASS_EXACT_WHOLE_ORIGINAL_COVER_ATTACHMENT_ONLY',
        scope='complete necessary eight-domain cover of unchanged original; child exclusions pending',
        theorem_commit='ce782652', theorem_version='opposite_endpoint_full_angle_AHID_row_23_100_v1',
        theorem_manifest_sha256=digest(THEOREM/'MANIFEST.json'),
        parent=dict(path=str(PREFIX),sha256=digest(PREFIX),schema=prefix['schema']),
        whole_v3_parent=dict(path=prefix['prior']['path'],sha256=prefix['prior']['sha256']),
        accepted_parent_replay=dict(path=str(report_path),sha256=digest(report_path)),
        original_id=prefix['id'],original_path=prefix['path'], center_subdivisions=0,
        extra_angle_subdivisions=0, opposite_signed_slopes=[[str(v) for v in angles[i]] for i in(0,3)],
        proved_weak_order_intervals=orders, deduced_physical_variation='V(A,H,I,D)>23/100',
        closed_cover_threshold='23/100',complete_closed_domains=8,
        children_are_independent_same_parent_restrictions=True,earlier_sibling_complements_added=False,
        all_equality_faces_retained=True,children=children,source_sha256=sources,
        new_original_closures=0,new_mask_closures=0)
    for path, expected in sources.items():
        assert digest(path) == expected
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    print('FROZEN_EIGHT_DOMAINS',digest(OUT),len(sources))


if __name__ == '__main__':
    main()
