"""Necessary energy rows for three retained physical unit squares.

The independently reviewed geometric theorem is
sum_{i<j} |c_j-c_i|^2 >= 7/2 for any three interior-disjoint unit squares.
For l <= t <= u, t^2 <= (l+u)t-lu. Cartesian and orthogonal diagonal
secants therefore turn that theorem into unconditional affine inequalities.
This producer is separate from every previously frozen proof source.
"""
from fractions import Fraction as Q
from itertools import combinations, product


def linear_rows(differences, diagonal=None, all_combinations=True):
    """Return rows (coefficient_pairs, rhs, name) in the <= convention.

    differences[i,j] bounds (x_j-x_i, y_j-y_i). Optional diagonal[i,j]
    bounds (dx+dy, dx-dy); its squared terms carry the factor one-half.
    A code selects Cartesian (0) or diagonal (1) coordinates per pair.
    """
    diagonal = diagonal or {}
    rows = []
    for triple in combinations(range(9), 3):
        pairs = tuple(combinations(triple, 2))
        choices = [(0, 1) if all_combinations and pair in diagonal else (0,)
                   for pair in pairs]
        for codes in product(*choices):
            coefficients = {}
            rhs = -Q(7, 2)
            for (i, j), code in zip(pairs, codes):
                bounds = diagonal[i, j] if code else differences[i, j]
                factor = Q(1, 2) if code else Q(1)
                assert len(bounds) == 2
                for axis, (lo, hi) in enumerate(bounds):
                    lo, hi = Q(lo), Q(hi)
                    assert lo <= hi
                    if code:
                        sign = 1 if axis == 0 else -1
                        linear = {2*j: Q(1), 2*i: Q(-1),
                                  2*j+1: Q(sign), 2*i+1: Q(-sign)}
                    else:
                        linear = {2*j+axis: Q(1), 2*i+axis: Q(-1)}
                    for variable, value in linear.items():
                        coefficients[variable] = coefficients.get(variable, Q(0)) - factor*(lo+hi)*value
                    rhs -= factor*lo*hi
            name = ('three_square_center_energy_' + '_'.join(map(str, triple))
                    + '_' + ''.join(map(str, codes)))
            rows.append((tuple((k, value) for k, value in sorted(coefficients.items()) if value),
                         rhs, name))
    return rows


def moment_rows(lift):
    """Return the 84 exact quadratic inequalities before any secant cuts."""
    rows = []
    for triple in combinations(range(9), 3):
        coefficients = {}
        for i, j in combinations(triple, 2):
            for axis in (0, 1):
                delta = lift.delta(i, j, axis)
                lift.multiply(coefficients, delta, delta, -1)
        rows.append(lift.clean(coefficients, -Q(7, 2),
                              'three_square_center_energy_moment_' + '_'.join(map(str, triple))))
    return rows
