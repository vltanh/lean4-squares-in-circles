#!/usr/bin/env python3
"""Discovery in one of eight declared opposite-tilt height domains of the whole original CB882."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,argparse,hashlib
from pathlib import Path
from fractions import Fraction as Q
OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof')
sys.path.insert(0,str(OLD))
import v3_whole_parent_pass as M
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/cd_family')
import diagonal_rows as D
import quadratic_moment_pilot as QM
import correlated_capacity_rows as C
sys.path.insert(0,'/workspace/scratch/fee12ff81cbd/cd_family')
import four_center_rows as FC
sys.path.insert(0,'/workspace/scratch/fee12ff81cbd/b_family')
import square_area_moment_rows as AREA
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'a_family'))
import three_square_energy_rows as TE
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'global_theorem'))
import independent_opposite_tilt_height_rows as SHARP
import shared_strict_row_terminal as SHARP_TERMINAL
import active_highs_discovery as FAST
FAST.install(M)
HERE=Path(__file__).resolve().parent
EPS=Q(1,2000)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(x):return tuple(tuple(Q(z)for z in ab)for ab in x)
def view(s,d,g):return dict(angles=M.render(s['angles']),positions=M.render(s['positions']),scalar=M.render(s['scalar']),differences=M.render_diff(d),diagonal=M.render_diff(g))
SHARP_SCHEMA='CB882_whole_original_opposite_tilt_height_bound_discovery_v1'
BASE_SCHEMAS=('CD_fixed_tile_affine_bound_induction_discovery_v1',
              'CD_fixed_tile_affine_bound_continuation_discovery_v1',
              'CD_fixed_tile_affine_bound_interrupted_resume_discovery_v1')

def load(ident,arc=False):
    global RESTRICTION,CONDITIONAL_ROWS
    assert sha(PARENT)=='1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'
    base=json.loads(PARENT.read_text())
    assert base['schema']=='correlated_diagonal_whole_parent_v1'
    assert base['status']=='OPEN'and base['id']==ident=='negative-b882d8ade0cf9ea0'
    assert base['rounds']==[] and 'tile'not in base and 'tile'not in base['prior']
    state,dd,dg,binding=QM.read_prefix(PARENT)
    FAST.add_seed_record(json.loads(Path(base['prior']['path']).read_text()))
    assert state['id']==ident and state['path']==base['path']
    selected=SHARP.complete_rows(SHARP.AHID,VARIATION)[BRANCH]
    CONDITIONAL_ROWS=(selected,)
    RESTRICTION=dict(kind='opposite_tilt_height_closed_complement',parent=binding,
        selected_row=list(SHARP.AHID),variation_bound=str(VARIATION),
        branch=BRANCH,complete_closed_domains=8,closed_faces_retained=True,
        conditional_row=SHARP.literal(selected))
    assert SHARP.selected_row(RESTRICTION)==selected
    return state,dd,dg,binding
def collect(s,d,g):
    rows,absbound,terminal,pos,sc,diff,guards=M.collect(s,d)
    if terminal:return rows,absbound,terminal,pos,sc,diff,g
    diag=D.effective(diff,g)
    if any(a>b for vv in diag.values()for a,b in vv):return rows,absbound,'empty_correlated_diagonal',pos,sc,diff,diag
    rows+=D.rows(sc,diff,diag)
    extra,guards=C.generate_rows(diff,diag);rows+=extra
    rows+=FC.linear_rows(diff,diag)
    rows+=AREA.generate_linear(diff)
    rows+=TE.linear_rows(diff,diag)
    rows+=list(CONDITIONAL_ROWS)
    sharp=SHARP_TERMINAL.evaluate_any_guard(dict(s,positions=pos,scalar=sc,differences=diff))
    if sharp['status']=='PASS_SHARP_PHYSICAL_ROW_GUARD':
        return rows,absbound,dict(kind='accepted_shared_sharp_boundary_terminal',guard=sharp),pos,sc,diff,diag
    return rows,absbound,None,pos,sc,diff,diag
def terminal_record(rows,ab,h):
    sol=h.getSolution()
    if sol.col_value[-1]<=1e-8:return None
    ws=M.terms(sol.row_dual);co,rhs=M.R.weighted_sum(rows,ab,ws);reserve=-rhs-sum(a*abs(v)for a,v in zip(ab,co))
    if reserve<=0:return None
    return dict(kind='positive_exact_reserve',weights=ws,reserve=str(reserve),printed_rows=M.R.printed_rows(rows,{i for i,w in ws}),absolute_variable_bounds=list(map(str,ab)),weighted_rhs=str(rhs),weighted_coefficients=list(map(str,co)))
def run(ident,rounds=4,arc=False):
    state,diffs,diag,prior=load(ident,arc);start=time.monotonic()
    record=dict(schema=SHARP_SCHEMA,scope='ONE_CLOSED_HEIGHT_DOMAIN_OF_WHOLE_UNCHANGED_ORIGINAL',new_original_cells=0,id=ident,path=state['path'],status='OPEN',prior=prior,rounds=[],
       sources={str(Path(q).resolve()):sha(q)for q in(__file__,M.__file__,D.__file__,QM.__file__,C.__file__,FC.__file__,AREA.__file__,TE.__file__,SHARP.__file__,SHARP_TERMINAL.__file__,FAST.__file__)})
    record['sharp_restriction']=RESTRICTION
    out=OUTPUT;out.mkdir(parents=True,exist_ok=True);dest=out/'bound_rounds.json';assert not dest.exists()
    for ri in range(rounds+1):
        before=view(state,diffs,diag)
        rows,ab,term,pos,sc,dd,gg=collect(state,diffs,diag)
        item=dict(round=ri,before=before,rows=len(rows),propagated_positions=M.render(pos),physical_scalar_intersection=M.render(sc),effective_differences=M.render_diff(dd),effective_diagonal=M.render_diff(gg),proposals=[])
        if term:
            if isinstance(term,dict)and term.get('kind')=='accepted_shared_sharp_boundary_terminal':
                terminal=dict(kind='accepted_shared_sharp_boundary_terminal',guard=term['guard'],state=item)
            else:terminal=dict(kind='exact_interval_terminal',label=term,state=item)
            record.update(status='CANDIDATE_CLOSED',terminal=terminal);break
        h=M.highs(rows,len(ab));h.run()
        if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:
            record.update(solver_status=str(h.getModelStatus()));break
        tc=terminal_record(rows,ab,h)
        if tc:record.update(status='CANDIDATE_CLOSED',terminal=dict(tc,state=item));break
        if ri==rounds:record['final_test']=item;break
        h.changeColCost(len(ab),0.);h.changeColBounds(len(ab),0.,0.)
        targets=[]
        for k,(lo,hi)in enumerate(pos+sc):
            for sign in(-1,1):targets.append(dict(kind='scalar',key=k,sign=sign,objective=[[k,sign]],old=hi if sign==1 else-lo))
        for kind,dictv in(('difference',dd),('diagonal',gg)):
            for (i,j),vv in sorted(dictv.items()):
                for axis,(lo,hi)in enumerate(vv):
                    for sign in(-1,1):
                        obj=[[2*j+axis,sign],[2*i+axis,-sign]]if kind=='difference'else[[2*j,sign],[2*i,-sign],[2*j+1,sign*(1 if axis==0 else-1)],[2*i+1,-sign*(1 if axis==0 else-1)]]
                        targets.append(dict(kind=kind,key=[i,j,axis],sign=sign,objective=obj,old=hi if sign==1 else-lo))
        np=[list(x)for x in pos];ns=[list(x)for x in sc];nd={k:[list(x)for x in v]for k,v in dd.items()};ng={k:[list(x)for x in v]for k,v in gg.items()}
        used=set();previous=[]
        for t in targets:
            for k,c in previous:h.changeColCost(k,0.)
            for k,c in t['objective']:h.changeColCost(k,-float(c))
            previous=t['objective'];h.setOptionValue('time_limit',h.getRunTime()+3.);h.run()
            if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:continue
            if float(t['old'])+h.getObjectiveValue()<float(EPS):continue
            ws=M.terms(h.getSolution().row_dual);co,rhs=M.R.weighted_sum(rows,ab,ws)
            for k,c in t['objective']:co[k]-=Q(c)
            correction=sum(a*abs(v)for a,v in zip(ab,co));proved=rhs+correction;upper=M.ceil_grid(proved)
            if t['old']-upper<EPS:continue
            p=dict(t,old=str(t['old']),upper=str(upper),proved_upper=str(proved),weights=ws,summed_rhs=str(rhs),residual_coefficients=[[k,str(v)]for k,v in enumerate(co)if v],residual_correction=str(correction))
            item['proposals'].append(p);used.update(i for i,w in ws)
            key=t['key'];sign=t['sign'];kind=t['kind']
            target=(np[key]if key<18 else ns[key-18])if kind=='scalar'else(nd if kind=='difference'else ng)[tuple(key[:2])][key[2]]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
        item['printed_rows']=M.R.printed_rows(rows,used);item['absolute_variable_bounds']=list(map(str,ab))
        pos=tuple(map(tuple,np));sc=tuple(map(tuple,ns));diffs={k:tuple(map(tuple,v))for k,v in nd.items()};diag={k:tuple(map(tuple,v))for k,v in ng.items()}
        if any(a>b for a,b in pos+sc)or any(a>b for zz in list(diffs.values())+list(diag.values())for a,b in zz):
            record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='empty_proved_interval'));break
        angles,contradiction,ids=M.R.infer_angles(state['angles'],sc);item['physical_frame_inferences']=ids
        if contradiction:record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind=contradiction));break
        analytic=M.K.analytic(angles);sc=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(sc,analytic))
        if any(a>b for a,b in sc):record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal=dict(kind='empty_physical_frame'));break
        state.update(positions=pos,scalar=sc,angles=angles)
        item['after']=view(state,diffs,diag);record['rounds'].append(item)
        record['final']=view(state,diffs,diag);record['seconds']=time.monotonic()-start;dest.write_text(json.dumps(record,indent=2)+'\n')
        print(ident,'DIAGONAL ROUND',ri,len(item['proposals']),'seconds',round(record['seconds'],2),flush=True)
        if not item['proposals']:break
    record['final']=view(state,diffs,diag);record['seconds']=time.monotonic()-start;dest.write_text(json.dumps(record,indent=2)+'\n')
    print(ident,'DIAGONAL RESULT',record['status'],'seconds',round(record['seconds'],2),flush=True)
    return record
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('output',type=Path)
    ap.add_argument('branch',type=int)
    ap.add_argument('--variation',default='23/100')
    ap.add_argument('--rounds',type=int,default=3)
    args=ap.parse_args();PARENT=args.source.resolve();OUTPUT=args.output.resolve()
    assert OUTPUT.is_relative_to(HERE)and OUTPUT!=PARENT.parent
    VARIATION,BRANCH=Q(args.variation),args.branch
    assert VARIATION==SHARP.VARIATION and 0<=BRANCH<8 and 0<=args.rounds<=3
    base=json.loads(PARENT.read_text());run(base['id'],rounds=args.rounds)
