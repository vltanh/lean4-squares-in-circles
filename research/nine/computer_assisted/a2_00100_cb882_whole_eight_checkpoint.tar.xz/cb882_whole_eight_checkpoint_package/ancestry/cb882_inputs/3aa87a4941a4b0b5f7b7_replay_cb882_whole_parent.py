#!/usr/bin/env python3
"""Strict exact replay of the unchanged complete CB882 original ancestor."""
from pathlib import Path
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ID = 'negative-b882d8ade0cf9ea0'
PREFIX_SHA = '1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'
V3_SHA = '61d2a2f8ac9656b6c5f8a9f89113a8ea80dc239b767baa0c601d27d91f1007d8'
PATH = [['angle', 3, 0], ['angle_cut', [0, '0'], 1], ['alternate_four_escape', [1, 7], [3]]]
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert __debug__
    start = time.monotonic()
    snapshot = (HERE / 'SHA256_MANIFEST.json').read_bytes()
    inventory = json.loads(snapshot)['files']
    def unchanged():
        assert (HERE / 'SHA256_MANIFEST.json').read_bytes() == snapshot
        for name, expected in inventory.items():
            p = (HERE / name).resolve()
            assert p.is_relative_to(HERE) and digest(p) == expected
    unchanged()
    sys.path.insert(0, str(HERE))
    import verify_cd_triple_energy_recursive_bounds as R
    import independent_opposite_tilt_height_rows as H
    assert Path(R.__file__).resolve() == HERE / 'verify_cd_triple_energy_recursive_bounds.py'
    assert digest(R.__file__) == 'e73773f57e99797edcf5ee9726000c57ce212936b853c75247ff63ce9f16e0f4'
    assert Path(H.__file__).resolve() == HERE / 'independent_opposite_tilt_height_rows.py'
    assert digest(H.__file__) == '74eff0691ccd464ae23aeaf6d36ee20c411732e965dad040dad9304dc5b286d6'
    checker = R.Checker(HERE, HERE / 'ancestry', HERE)
    source = HERE / 'ancestry/cd_family/diagonal_results' / (ID + '.json')
    assert digest(source) == PREFIX_SHA
    literal = json.loads(source.read_text())
    assert literal['id'] == ID and literal['path'] == PATH
    assert literal['rounds'] == [] and literal['status'] == 'OPEN'
    assert literal['prior']['kind'] == 'v3' and literal['prior']['sha256'] == V3_SHA
    assert 'tile' not in literal and 'tile' not in literal['prior']
    report, state, diagonal = checker.D.replay(source)
    assert report['certificate_sha256'] == PREFIX_SHA
    assert report['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert state['id'] == ID and state['path'] == PATH
    assert literal['final'] == checker.view(state, diagonal)
    old = report['prior_report']
    assert old['certificate_sha256'] == V3_SHA and old['center_cover'] is None
    assert old['rounds'] == 5 and old['new_deductions'] == 386
    assert old['prior_coordinate_deductions'] == 30
    prerequisites = H.prerequisites(state)
    assert [ab[0] for ab in prerequisites['proved_weak_order_intervals']] == [
        '35461/524288', '0', '434432029724121/5000000000000000']
    unchanged()
    modules = {}
    for name, module in sys.modules.items():
        origin = getattr(module, '__file__', None)
        if origin and Path(origin).resolve().is_relative_to('/workspace'):
            p = Path(origin).resolve()
            assert p.is_relative_to(HERE), (name, str(p))
            modules[name] = str(p.relative_to(HERE))
    result = dict(schema='strict_CB882_whole_original_ancestor_replay_v1',
        status='PASS_CERTIFIED_WHOLE_ORIGINAL_STATE_OPEN', id=ID, original_path=PATH,
        certificate_sha256=PREFIX_SHA, full_original_v3_sha256=V3_SHA,
        ancestor_replay=report, physical_state=checker.view(state, diagonal),
        opposite_tilt_eight_height_prerequisites=prerequisites,
        original_caller_before_every_center_or_angle_subdivision=True,
        all_frozen_inputs_rehashed=True, frozen_inputs=len(inventory),
        source_manifest_sha256=hashlib.sha256(snapshot).hexdigest(),
        checker_sha256=digest(__file__), workspace_module_import_audit=modules,
        new_original_cells=0, new_masks=0, seconds=time.monotonic()-start)
    (HERE / 'CB882_WHOLE_PARENT_EXACT_REPLAY.json').write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'], old['new_deductions'], old['printed_rows_checked'])


if __name__ == '__main__':
    main()
