"""Eight closed height domains after the opposite-tilt row prerequisites.

The caller must independently prove the unchanged physical001/00 ancestry,
opposite A/D signs and all three weak AHID orders. These rows are conditional
domains, never unconditional inequalities or an original-cell closure.
"""
from fractions import Fraction as F
from itertools import product

AHID = (0, 7, 8, 3)
VARIATION = F(23, 100)

def complete_rows(row=AHID, variation=VARIATION):
    assert tuple(row) == AHID and F(variation) == VARIATION
    result = []
    for index, signs in enumerate(product((-1, 1), repeat=3)):
        coefficients = {}
        for i, j, sign in zip(AHID, AHID[1:], signs):
            coefficients[2*i+1] = coefficients.get(2*i+1, F(0)) + sign
            coefficients[2*j+1] = coefficients.get(2*j+1, F(0)) - sign
        terms = tuple(sorted((k, v) for k, v in coefficients.items() if v))
        result.append((terms, -VARIATION, 'opposite_tilt_AHID_variation_' + str(index)))
    assert len(result) == 8 and len(set(result)) == 8
    return tuple(result)

def literal(row):
    terms, rhs, name = row
    return dict(coefficients=[[k, str(v)] for k, v in terms], rhs=str(rhs), name=name)

def selected_row(detail):
    assert detail['kind'] == 'opposite_tilt_height_closed_complement'
    assert detail['complete_closed_domains'] == 8 and detail['closed_faces_retained'] is True
    branch = detail['branch']
    assert type(branch) is int and 0 <= branch < 8
    row = complete_rows(detail['selected_row'], detail['variation_bound'])[branch]
    assert detail['conditional_row'] == literal(row)
    return row

def difference(positions, differences, i, j, axis):
    lo = F(positions[2*j+axis][0]) - F(positions[2*i+axis][1])
    hi = F(positions[2*j+axis][1]) - F(positions[2*i+axis][0])
    if i < j and (i, j) in differences:
        a, b = differences[i, j][axis]
        lo, hi = max(lo, F(a)), min(hi, F(b))
    elif j < i and (j, i) in differences:
        a, b = differences[j, i][axis]
        lo, hi = max(lo, -F(b)), min(hi, -F(a))
    assert lo <= hi
    return lo, hi

def prerequisites(state):
    angles = state['angles']
    opposite = ((F(angles[0][0]) >= 0 and F(angles[3][1]) <= 0)
                or (F(angles[0][1]) <= 0 and F(angles[3][0]) >= 0))
    orders = [difference(state['positions'], state['differences'], i, j, 0)
              for i, j in zip(AHID, AHID[1:])]
    assert opposite, 'Unproved opposite endpoint signs'
    assert all(lo >= 0 for lo, hi in orders), 'Unproved weak horizontal order'
    return dict(opposite_endpoint_signs_proved=True,
                endpoint_angle_intervals=[[str(v) for v in angles[i]] for i in (0, 3)],
                proved_weak_order_intervals=[[str(v) for v in ab] for ab in orders])

def lower_lhs(row, positions, scalar, differences):
    values = tuple(tuple(map(F, ab)) for ab in tuple(positions) + tuple(scalar))
    assert len(values) == 54 and all(lo <= hi for lo, hi in values)
    terms, rhs, name = row
    lower = sum(v * values[k][0 if v > 0 else 1] for k, v in terms)
    if len(terms) == 2:
        (a, u), (b, v) = terms
        if u == -v and abs(u) == 1 and a % 2 == b % 2 and a < 18 and b < 18:
            negative, positive = (a, b) if u < 0 else (b, a)
            lower = max(lower, difference(positions, differences, negative//2, positive//2, negative % 2)[0])
    return lower
