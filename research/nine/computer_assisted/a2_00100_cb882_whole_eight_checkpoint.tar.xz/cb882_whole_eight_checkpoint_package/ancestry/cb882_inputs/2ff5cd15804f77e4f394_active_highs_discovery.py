"""Untrusted constraint-generation acceleration for affine discovery LPs.

Every returned multiplier is expanded back to the full original row list.
Certificates are accepted only by exact weighted-sum replay, independent of
which numerical rows were initially active or whether the LP converged.
"""
import numpy as np
from scipy.sparse import csr_matrix
from types import SimpleNamespace

class ActiveHighs:
 def __init__(self,rows,n,base,H):
  self.rows=rows;self.n=n;self.H=H;self.active=[];self.mask=np.zeros(len(rows),dtype=bool)
  rr=[];cc=[];vv=[];bb=[]
  for i,(co,b,name)in enumerate(rows):
   for k,v in co:rr.append(i);cc.append(k);vv.append(float(v))
   rr.append(i);cc.append(n);vv.append(-1.);bb.append(float(b))
  self.matrix=csr_matrix((vv,(rr,cc)),shape=(len(rows),n+1));self.rhs=np.array(bb)
  selected=[i for i,(co,b,name)in enumerate(rows)if len(co)<=1 or name in SEED_NAMES]
  if not selected:selected=list(range(min(100,len(rows))))
  self.active.extend(selected);self.mask[selected]=True
  self.inner=base([rows[i]for i in selected],n)
  self.run_calls=0;self.additions=0
 def __getattr__(self,name):return getattr(self.inner,name)
 def run(self):
  self.run_calls+=1
  for cycle in range(96):
   answer=self.inner.run()
   if self.inner.getModelStatus()!=self.H.HighsModelStatus.kOptimal:return answer
   sol=self.inner.getSolution();xx=np.array(sol.col_value)
   violations=self.matrix@xx-self.rhs
   candidates=np.flatnonzero((violations>2e-8)&~self.mask)
   if len(candidates)==0:return answer
   if len(candidates)>256:
    candidates=candidates[np.argpartition(violations[candidates],-256)[-256:]]
   candidates=np.sort(candidates);mm=self.matrix[candidates].tocsr()
   status=self.inner.addRows(len(candidates),np.full(len(candidates),-np.inf),self.rhs[candidates],mm.nnz,mm.indptr.astype(np.int32),mm.indices.astype(np.int32),mm.data)
   assert status==self.H.HighsStatus.kOk,status
   self.active.extend(map(int,candidates));self.mask[candidates]=True;self.additions+=len(candidates)
  return self.inner.run()
 def getSolution(self):
  raw=self.inner.getSolution();dual=np.zeros(len(self.rows))
  assert len(raw.row_dual)==len(self.active)
  dual[self.active]=raw.row_dual
  return SimpleNamespace(col_value=raw.col_value,row_dual=dual,col_dual=raw.col_dual,row_value=raw.row_value)

SEED_NAMES=set()
def add_seed_record(record):
 for rr in record.get('rounds',[]):
  SEED_NAMES.update(x['name']for x in rr.get('printed_rows',[]))
 term=record.get('terminal',{})
 SEED_NAMES.update(x['name']for x in term.get('rows',[]))

def install(M):
 base=M.highs
 def highs(rows,n):return ActiveHighs(rows,n,base,M.H)
 M.highs=highs
