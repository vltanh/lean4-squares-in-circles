#!/usr/bin/env python3
"""Preserve raw screen errors, then propose exact empty-intersection terminals.

This continuation is still discovery.  The independent checker must repeat
the original ancestry, closed rectangle and interval intersection from scratch.
"""
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, '/workspace/scratch/0220f3e5a56d/cd_family')
import quadratic_moment_pilot as P

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main(ident):
    state, differences, diagonal, prior = P.read_prefix(HERE/'new_cd_prefixes'/(ident+'.json'))
    K = P.P.M.K
    for path in sorted((HERE/'new_cd_I_grid').glob(ident+'_*.json')):
        record = json.loads(path.read_text())
        if not record.get('error'):
            continue
        raw = HERE/'new_cd_raw_errors'/path.name
        raw.parent.mkdir(exist_ok=True)
        assert not raw.exists(), 'Raw screen error must not be overwritten'
        raw.write_bytes(path.read_bytes())
        positions = list(state['positions'])
        for axis,index in enumerate(record['tile']):
            lo,hi = positions[16+axis]
            positions[16+axis] = (lo+(hi-lo)*index/4, lo+(hi-lo)*(index+1)/4)
        effective, early = K.V.effective_boxes(state['angles'],state['choices'],K.LEGACY)
        assert early is None
        propagated,hs,gs,early = K.V.center_bounds(effective,tuple(positions),state['choices'],K.LEGACY)
        assert early is None
        gap = None
        for pair,prior_bounds in differences.items():
            current = K.V.difference_bounds(pair,propagated,gs,K.LEGACY)
            for axis,((a,b),(c,d)) in enumerate(zip(current,prior_bounds)):
                if max(a,c)>min(b,d):
                    gap = dict(kind='empty_exact_pair_difference_intersection',
                               pair=list(pair),axis=axis,
                               derived=list(map(str,(a,b))),prior=list(map(str,(c,d))))
                    break
            if gap:
                break
        assert gap, 'The original error has no independently interpretable interval gap'
        del record['error']
        record.update(status='CANDIDATE_CLOSED',
                      terminal=dict(kind='exact_interval',label=gap),
                      raw_error_record=str(raw),raw_error_sha256=digest(raw),
                      continuation_source=str(Path(__file__).resolve()),
                      continuation_source_sha256=digest(__file__))
        path.write_text(json.dumps(record,indent=2)+'\n')
        print(ident,record['tile'],'EXACT_INTERVAL_CANDIDATE',gap,flush=True)

if __name__ == '__main__':
    for ident in sys.argv[1:]:
        main(ident)
