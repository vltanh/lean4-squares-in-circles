#!/usr/bin/env python3
"""One complete fixed I-center cover for two unchanged original parents.

This is discovery. Only all tiles closed with exact terminals, followed by
independent reconstruction, can discharge the unchanged original parent.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
import sys,json,time,itertools,concurrent.futures
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/cd_family')
import quadratic_moment_pilot as P
import correlated_capacity_rows as C
sys.path.insert(0,str(HERE))
import four_center_rows as FC
sys.path.insert(0,'/workspace/scratch/fee12ff81cbd/b_family')
import square_area_moment_rows as AREA

def job(args):
    ident,ix,iy,parts=args
    prefix=HERE/'new_cd_prefixes'/(ident+'.json')
    s,dd,dg,prior=P.read_prefix(prefix)
    positions=list(s['positions']); rectangle=[]
    for axis,index in ((0,ix),(1,iy)):
        lo,hi=positions[16+axis]; ab=(lo+(hi-lo)*index/parts,lo+(hi-lo)*(index+1)/parts)
        positions[16+axis]=ab; rectangle.append(list(map(str,ab)))
    ss=dict(s,positions=tuple(positions));start=time.monotonic()
    out=dict(id=ident,tile=[ix,iy],parts=parts,original=8,rectangle=rectangle,prior=prior,status='OPEN')
    try:
        rows,ab,term,pos,scalar,diff,diag=P.P.collect(ss,dd,dg)
        if term:
            out.update(status='CANDIDATE_CLOSED',terminal={'kind':'exact_interval','label':term})
        else:
            extra,guards=C.generate_rows(diff,diag);rows+=extra
            rows+=FC.linear_rows(diff,diag)
            rows+=AREA.generate_linear(diff)
            solver=P.P.M.highs(rows,len(ab));solver.run()
            out.update(rows=len(rows),solver_status=str(solver.getModelStatus()))
            if solver.getModelStatus()==P.P.M.H.HighsModelStatus.kOptimal:
                solution=solver.getSolution();out['phase_margin']=float(solution.col_value[-1])
                tc=P.P.terminal_record(rows,ab,solver)
                if tc:out.update(status='CANDIDATE_CLOSED',terminal=tc)
                else:out['relaxed_original_variables']=list(map(float,solution.col_value[:54]))
    except Exception:
        import traceback
        out['error']=traceback.format_exc()
    out['seconds']=time.monotonic()-start
    folder=HERE/'new_cd_I_grid';folder.mkdir(exist_ok=True)
    (folder/(ident+f'_{ix}_{iy}.json')).write_text(json.dumps(out,indent=2)+'\n')
    return {k:out[k]for k in ('id','tile','status','seconds')}|({'error':out['error']}if 'error'in out else{})

if __name__=='__main__':
    identifiers=sys.argv[1:] or ['negative-95371f658da581d0','positive-a4979e5f2a7e8734']
    tasks=[(ident,i,j,4)for ident in identifiers for i,j in itertools.product(range(4),repeat=2)]
    with concurrent.futures.ProcessPoolExecutor(max_workers=2)as pool:
        for result in pool.map(job,tasks):print(json.dumps(result),flush=True)
