# CB882: eight closed height domains of the complete original

This is a complete necessary cover, with all eight exclusions still pending.
It gives no original-cell or mask credit by itself.

The original is `negative-b882d8ade0cf9ea0` of the unchanged strict full-nine
`001/00` caller. Its literal path is

```json
[["angle",3,0],["angle_cut",[0,"0"],1],["alternate_four_escape",[1,7],[3]]]
```

All nine original physical squares, their original corners and frames, all
physical pairs, the five original cone comparisons, actual AB, BC, EF and FG,
and strictly weak CD are retained. The disk bound is the closed
`Q=1105/256`. No I-center, H-center, or additional angle restriction is used.

The whole original v3 source has SHA-256
`61d2a2f8ac9656b6c5f8a9f89113a8ea80dc239b767baa0c601d27d91f1007d8`.
The zero-round identity wrapper has SHA-256
`1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03`.
The separate strict portable replay rechecked 30 coordinate deductions and
then all 386 deductions in the five whole-parent rounds, using 1,073 printed
row occurrences. It returned the whole state OPEN, with no center cover.

## The full-angle theorem applies to this whole original

The exactly replayed whole state proves

\[
x_H-x_A\ge35461/524288>0,\qquad x_I-x_H\ge0,\qquad
x_D-x_I\ge434432029724121/5000000000000000>0.
\]

The signed endpoint slope intervals are

\[
t_A\in[0,21144313723523/140737488355328],\qquad t_D\in[-1,0].
\]

Thus all three weak AHID horizontal orders and opposite A/D endpoint signs
are proved before every subdivision. The original EFG projection chain is
actual. These are precisely the hypotheses of the published
`OPPOSITE_ENDPOINT_TILTS_FULL_ANGLE_FOUR_ROW_HAND_TERMINAL.md` (commit
`ce782652`), with no small-angle or shoulder-height assumption.

That theorem excludes the unchanged strict original caller at closed Q if

\[
V=|y_H-y_A|+|y_I-y_H|+|y_D-y_I|\le23/100.
\]

Its equality argument is part of the accepted theorem: the seven row/cap
originals align and the main span is three; original actual AB and BC then
force equality in the remaining original CD comparison, contradicting its
strictly weak bit. No new scalar table or cap theorem is asserted here.

## The complete eight-domain union

Every physical survivor therefore has `V>23/100`. Since V is the maximum
of the eight signed sums, the following eight closed inequalities cover
every physical survivor. The table uses the convention `lhs<=-23/100`.

| Branch | Signs on `(yH-yA,yI-yH,yD-yI)` | Left side |
|---:|:---:|---|
| 0 | `(-1,-1,-1)` | `-yA+yD` |
| 1 | `(-1,-1,+1)` | `-yA-yD+2yI` |
| 2 | `(-1,+1,-1)` | `-yA+yD+2yH-2yI` |
| 3 | `(-1,+1,+1)` | `-yA-yD+2yH` |
| 4 | `(+1,-1,-1)` | `yA+yD-2yH` |
| 5 | `(+1,-1,+1)` | `yA-yD-2yH+2yI` |
| 6 | `(+1,+1,-1)` | `yA+yD-2yI` |
| 7 | `(+1,+1,+1)` | `yA-yD` |

Each child adds exactly its one selected row to the identical complete
original parent. No child inherits a restriction from an earlier sibling.
All shared equality faces are retained. The weak horizontal orders have
already been proved; no closed opposite-order face is discarded by a
strict-negation argument.

The finite numerical experiment permits at most three additional affine
induction rounds in each of the eight children. Its active-row LP helper is
untrusted discovery machinery; all multipliers are expanded to original
row indices, and every later accepted deduction must be independently
reconstructed and summed with exact rational arithmetic. A single child
terminal excludes only that height domain. Only a complete independently
replayed eight-member union can close this original.
