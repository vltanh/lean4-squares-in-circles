"""Load immutable earlier exact checkers with explicit portable source bindings.

No discovery row generator or numerical optimizer is imported. This context
redirects historical absolute names to byte-identified files in this packet.
"""
from pathlib import Path
import copy
import hashlib
import json
import sys

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def install(ancestry, allowed_root=None):
    ancestry = Path(ancestry).resolve()
    manifest = json.loads((ancestry/'MANIFEST.json').read_text())
    bindings = json.loads((ancestry/'SOURCE_BINDINGS.json').read_text())
    for name, expected in manifest['frozen_file_sha256'].items():
        assert digest(ancestry/name) == expected, ('frozen ancestry changed', name)
    def locate(name):
        p = Path(name)
        if str(p) in bindings:
            return ancestry/bindings[str(p)]
        if not p.is_absolute():
            return ancestry/p
        if p.is_relative_to(ancestry):
            return p
        raise FileNotFoundError('No explicit ancestry binding: '+str(p))
    def bound_digest(name):
        return digest(locate(name))
    if allowed_root is not None:
        allowed_root = Path(allowed_root).resolve()
        assert ancestry.is_relative_to(allowed_root)
        def audit(event, args):
            if event == 'open' and isinstance(args[0], str):
                p = Path(args[0])
                if p.is_absolute() and str(p).startswith('/workspace/'):
                    if not p.is_relative_to(allowed_root):
                        raise PermissionError('Unbound external workspace read: '+str(p))
        sys.addaudithook(audit)
    legacy = ancestry/'legacy/current_proof'
    for p in (ancestry, ancestry/'a_family', ancestry/'cd_family', legacy,
              legacy/'shared_capacity_three_b_v4',
              legacy/'shared_capacity_three_b_v4/geometry',
              legacy/'shared_capacity_three_b_v4/sources'):
        sys.path.insert(0, str(p))
    import verify_joint_original as J
    import review_guarded_frame_bounds_independent
    import verify_arc_union as A
    import verify_diagonal_pass as D
    J.local_source = locate
    J.digest = bound_digest
    A.digest = D.digest = bound_digest
    for module in (J, A, D):
        function = module.replay
        cache = {}
        def wrapped(path, *args, _fn=function, _cache=cache, **kwargs):
            target = locate(path)
            key = (str(target), digest(target), repr(args), repr(kwargs))
            if key not in _cache:
                _cache[key] = _fn(target, *args, **kwargs)
            return copy.deepcopy(_cache[key])
        module.replay = wrapped
    return J, D, locate
