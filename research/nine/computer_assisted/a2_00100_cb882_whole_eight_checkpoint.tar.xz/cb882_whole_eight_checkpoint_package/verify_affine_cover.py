#!/usr/bin/env python3
"""Independently replay the affine and interval parts of a fixed I/H cover.

Every accepted tile starts from the independently replayed original ancestor.
The numerical producer is never imported. Partial coverage earns no original
closure: the remaining tile list is an explicit output for the PSD checker.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations, product
import argparse
import hashlib
import json
import sys
import time

from replay_context import install, digest

HERE = Path(__file__).resolve().parent

def four_energy(name, cartesian, diagonal):
    p = name.split('_')
    assert p[:3] == ['four', 'center', 'energy'] and len(p) == 8
    quad = tuple(map(int, p[3:7])); codes = p[7]
    assert len(set(quad)) == 4 and tuple(sorted(quad)) == quad
    assert all(0 <= k < 9 for k in quad) and len(codes) == 6
    assert set(codes) <= {'0', '1'}
    co = [F(0)]*18; rhs = F(-8)
    for (i,j), code in zip(combinations(quad, 2), codes):
        if code == '0':
            projections = ((F(1),F(0)), (F(0),F(1)))
            intervals = cartesian[i,j]; weight = F(1)
        else:
            projections = ((F(1),F(1)), (F(1),F(-1)))
            intervals = diagonal[i,j]; weight = F(1,2)
        for (x,y), (lo,hi) in zip(projections, intervals):
            rhs -= weight*lo*hi
            for axis, v in enumerate((x,y)):
                co[2*i+axis] += weight*(lo+hi)*v
                co[2*j+axis] -= weight*(lo+hi)*v
    return tuple((i,v)for i,v in enumerate(co)if v), rhs, name

def area_secant(name, differences):
    p = name.split('_')
    assert p[:4] == ['square','area','moment','secant'] and len(p) == 9
    subset = tuple(map(int, p[4].split('-')))
    assert 2 <= len(subset) <= 9 and tuple(sorted(set(subset))) == subset
    assert all(0 <= i < 9 for i in subset)
    a,b,c,d = map(F,p[5:]); k = len(subset)
    rhs = F(k*k,12)*(a*a+b*b+c*c+d*d)-F(7*k**3,44)*abs(a*d-b*c)
    co = [F(0)]*18
    for i,j in combinations(subset,2):
        for x,y in ((a,b),(c,d)):
            values = [x*u+y*v for u,v in product(*differences[i,j])]
            lo,hi = min(values),max(values); rhs -= lo*hi
            for axis,v in enumerate((x,y)):
                co[2*i+axis] += (lo+hi)*v
                co[2*j+axis] -= (lo+hi)*v
    return tuple((i,v)for i,v in enumerate(co)if v),rhs,name

def child_state(parent, tile, record, K):
    assert len(tile) in (2,4)
    positions = list(parent['positions'])
    for axis, index in enumerate(tile[:2]):
        assert type(index) is int and 0 <= index < 4
        lo,hi = parent['positions'][16+axis]
        positions[16+axis] = (lo+(hi-lo)*index/4,lo+(hi-lo)*(index+1)/4)
    assert record['rectangle'] == K.view(positions[16:18])
    if len(tile) == 4:
        for axis,index,parts in ((0,tile[2],2),(1,tile[3],4)):
            assert type(index) is int and 0 <= index < parts
            lo,hi = parent['positions'][14+axis]
            positions[14+axis] = (lo+(hi-lo)*index/parts,lo+(hi-lo)*(index+1)/parts)
        assert record['h_rectangle'] == K.view(positions[14:16])
        assert record['parts'] == [4,4,2,4] and record['originals'] == [8,7]
    else:
        assert record['parts'] == 4 and record['original'] == 8
    return dict(parent, positions=tuple(positions))

def verify_tile(record, parent, previous_diagonal, J):
    import independent_diagonal_rows as ID
    import independent_correlated_capacity as IC
    K = J.K
    assert record['id'] == parent['id'] and record['status'] == 'CANDIDATE_CLOSED'
    state = child_state(parent, record['tile'], record, K)
    terminal = record['terminal']
    eff,early = K.V.effective_boxes(state['angles'],state['choices'],K.LEGACY)
    assert early is None
    propagated,hs,gs,early = K.V.center_bounds(eff,state['positions'],state['choices'],K.LEGACY)
    if terminal['kind'] == 'exact_interval':
        label = terminal['label']
        if isinstance(label,str):
            if label == 'empty_correlated_diagonal':
                assert early is None
                base,absolute,positions,scalar,differences,guards = K.rebuild(
                    state['path'],state['angles'],state['positions'],state['choices'],
                    state['scalar'],state['differences'])
                effective = ID.intervals(differences,previous_diagonal)
                impossible = [dict(pair=list(pair),axis=axis,lower=str(lo),upper=str(hi),gap=str(lo-hi))
                              for pair,intervals in sorted(effective.items())
                              for axis,(lo,hi) in enumerate(intervals) if lo > hi]
                assert impossible, 'The declared diagonal contradiction was not independently derived.'
                return dict(tile=record['tile'],kind='exact_interval',label=label,rows=0,
                            independently_derived_empty_diagonals=impossible)
            assert early == label, ('interval terminal mismatch',early,label)
            return dict(tile=record['tile'],kind='exact_interval',label=label,rows=0)
        assert early is None and label['kind'] == 'empty_exact_pair_difference_intersection'
        pair = tuple(label['pair']); axis = label['axis']
        assert len(pair) == 2 and 0 <= pair[0] < pair[1] < 9 and axis in (0,1)
        derived = tuple(K.V.difference_bounds(pair,propagated,gs,K.LEGACY)[axis])
        prior = parent['differences'][pair][axis]
        assert list(map(str,derived)) == label['derived']
        assert list(map(str,prior)) == label['prior']
        assert max(derived[0],prior[0]) > min(derived[1],prior[1])
        return dict(tile=record['tile'],kind='exact_interval',label=label,rows=0)
    assert terminal['kind'] == 'positive_exact_reserve' and early is None
    base,absolute,positions,scalar,differences,guards = K.rebuild(
        state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
    diagonal = ID.intervals(differences,previous_diagonal)
    assert all(lo<=hi for ab in diagonal.values()for lo,hi in ab)
    assert list(map(str,absolute)) == terminal['absolute_variable_bounds']
    printed = terminal['printed_rows']; indices = [r['index']for r in printed]
    assert len(indices) == len(set(indices))
    rows = list(base)
    if max(indices,default=-1) >= len(rows):
        rows += [((),F(0),'UNUSED_UNVERIFIED')]*(max(indices)+1-len(rows))
    for entry in printed:
        index = entry['index']; name = entry['name']
        assert type(index) is int and 0 <= index < record['rows']
        if index >= len(base):
            if name.startswith(('correlated_rotated_','correlated_diagonal_altitude_')):
                row = IC.physical_row(name,differences,diagonal)
            elif name.startswith('correlated_'):
                row = ID.physical_row(name,scalar,differences,diagonal)
            elif name.startswith('four_center_energy_'):
                row = four_energy(name,differences,diagonal)
            elif name.startswith('square_area_moment_secant_'):
                row = area_secant(name,differences)
            else:
                row = J.rebuild_joint(name,scalar,differences,state['angles'],J.point_row)
            rows[index] = row
        co,rhs,nm = rows[index]
        assert name == nm and F(entry['rhs']) == rhs
        assert [(i,F(v))for i,v in entry['coefficients']if F(v)] == [(i,v)for i,v in co if v],name
    assert set(indices) == {i for i,w in terminal['weights']}
    co,rhs = K.sum_rows(rows,absolute,terminal['weights'])
    reserve = -rhs-sum(a*abs(v)for a,v in zip(absolute,co))
    assert reserve > 0 and reserve == F(terminal['reserve'])
    assert rhs == F(terminal['weighted_rhs']) and co == list(map(F,terminal['weighted_coefficients']))
    return dict(tile=record['tile'],kind='positive_exact_reserve',reserve=str(reserve),rows=len(indices))

def run(ident, data, ancestry, output, strict_root=None):
    started = time.monotonic()
    J,D,locate = install(ancestry,strict_root)
    prefix = ancestry/'cd_family/diagonal_results'/(ident+'.json')
    prefix_report,parent,diagonal = D.replay(prefix)
    assert prefix_report['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
    results=[]; remainder=[]; read_files={}; coarse_closed=0
    def read_tile(directory,tile):
        p = data/directory/(ident+'_'+'_'.join(map(str,tile))+'.json')
        record=json.loads(p.read_text());read_files[str(p)]=digest(p)
        assert record['tile']==list(tile) and record['id']==ident
        assert digest(locate(record['prior']['path']))==record['prior']['sha256']==digest(prefix)
        return record
    for ix,iy in product(range(4),repeat=2):
        record = read_tile('fixed_I_grid',(ix,iy))
        if record['status']=='CANDIDATE_CLOSED':
            results.append(verify_tile(record,parent,diagonal,J));coarse_closed+=1
        else:
            assert record['status']=='OPEN'
            for hx,hy in product(range(2),range(4)):
                tile=(ix,iy,hx,hy);child=read_tile('fixed_HI_grid',tile)
                if child['status']=='CANDIDATE_CLOSED':
                    results.append(verify_tile(child,parent,diagonal,J))
                else:
                    assert child['status']=='OPEN';remainder.append(list(tile))
        print(ident,'AFFINE COVER CHECKED',ix,iy,'terminals',len(results),'remaining',len(remainder),flush=True)
    assert not any(x in sys.modules for x in ('numpy','scipy','highspy'))
    report=dict(schema='independent_fixed_I_HI_affine_cover_v1',id=ident,
        status='PASS_AFFINE_PARTIAL_COVER_REMAINDER_EXPLICIT' if remainder else 'PASS_COMPLETE_ORIGINAL_PARENT',
        path=parent['path'],prefix_sha256=digest(prefix),prior_report=prefix_report,
        coarse_I_tiles=16,coarse_I_terminals=coarse_closed,subtile_parts=[2,4],
        terminals=results,remaining_HI_tiles=remainder,
        terminal_rows=sum(r['rows']for r in results),
        source_sha256={str(Path(__file__)):digest(__file__),str(HERE/'replay_context.py'):digest(HERE/'replay_context.py')},
        read_certificate_sha256=read_files,new_original_cells=int(not remainder),whole_masks_closed=0,
        numerical_producer_or_optimizer_imported=False,seconds=time.monotonic()-started)
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k]for k in ('status','coarse_I_terminals','remaining_HI_tiles','terminal_rows','seconds')}),flush=True)
    return report,parent,diagonal

if __name__ == '__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--id',default='positive-a4979e5f2a7e8734')
    ap.add_argument('--data',type=Path,default=HERE/'data')
    ap.add_argument('--ancestry',type=Path,default=HERE/'ancestry')
    ap.add_argument('--output',type=Path,default=HERE/'AFFINE_COVER_REPLAY.json')
    a=ap.parse_args();run(a.id,a.data,a.ancestry,a.output)
