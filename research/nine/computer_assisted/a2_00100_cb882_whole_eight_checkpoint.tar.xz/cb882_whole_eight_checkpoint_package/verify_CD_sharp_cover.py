#!/usr/bin/env python3
"""Assemble all twenty closed sharp failures on the same proved C887 I21 state.

Every order, absolute-beta, signed-height, and strict-shoulder failure remains
in the cover. Complete nested sharp covers stay conditional until attached to
their exact parent. A complete root result closes I21 only, never an original.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import copy
import hashlib
import json
import time

import verify_cd_sharp_complement_bounds_v2 as C
import independent_sharp_complement_rows as SHARP

CHECKER_SHA256='282d2e7a5f4adb5fec870d58111f0da1b3a1381714076053d2b592fd8b87dc42'
COMPLETE_SCHEMA='complete_inherited_CD_tile_sharp_guard_cover_v1'
DECLARED_SCHEMA='declared_inherited_CD_tile_sharp_guard_cover_v1'

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class SharpCoverChecker:
    def __init__(self,context=C.DEFAULT_CONTEXT,ancestry=None,strict_root=None):
        assert digest(C.__file__)==CHECKER_SHA256
        self.checker=C.Checker(context,ancestry,strict_root)
        self.active=set();self.completed={};self.bound_records={}
        self.dependencies={str(Path(__file__).resolve()):digest(__file__),
                           str(Path(C.__file__).resolve()):CHECKER_SHA256}

    def recheck(self):
        self.checker.recheck()
        for filename,expected in self.dependencies.items():
            assert digest(filename)==expected,('changed_cover_dependency',filename)

    def frozen(self,reference):
        assert isinstance(reference,dict)and 'path'in reference and 'sha256'in reference
        path=self.checker.locate(reference['path']).resolve();raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==reference['sha256']
        name=str(path);old=self.checker.touched.get(name)
        assert old is None or old==reference['sha256']
        self.checker.touched[name]=reference['sha256']
        record=json.loads(raw)
        if 'schema'in reference:assert record['schema']==reference['schema']
        return path,record

    def register_sources(self,manifest):
        for filename,expected in manifest.get('sources',{}).items():
            path=self.checker.locate(filename).resolve();name=str(path)
            old=self.checker.touched.get(name);assert old is None or old==expected
            assert digest(path)==expected;self.checker.touched[name]=expected
        if 'parent_existing_exact_replay'in manifest:
            self.frozen(manifest['parent_existing_exact_replay'])

    def register_bound_report(self,report):
        """Deduplicate actual local induction records, not historical prefix work."""
        key=report['certificate_sha256']
        descriptor={name:report[name]for name in('id','tile','original_parent_path','bound_rounds',
                    'bound_deductions','printed_rows_checked','terminal_rows','reserve','terminal_kind')}
        descriptor['certificate_sha256']=key
        descriptor['bound_premise_rows']=descriptor['printed_rows_checked']-descriptor['terminal_rows']
        assert descriptor['bound_premise_rows']>=0
        if key in self.bound_records:assert self.bound_records[key]==descriptor
        else:self.bound_records[key]=descriptor
        if 'conditional_parent_replay'in report:
            self.register_bound_report(report['conditional_parent_replay'])

    def parent_state(self,reference):
        path,literal=self.frozen(reference)
        self.checker.register_dependencies(reference['path'],reference['sha256'])
        assert literal['id']==C.TARGET_ID and literal['path']==C.TARGET_PATH
        assert literal['status']=='OPEN'and 'terminal'not in literal
        assert literal['prior']['sha256']==C.ORIGINAL_PREFIX_SHA256
        assert literal['prior']['tile']==[2,1]and literal['prior']['closed_cover_parts']==[4,4]
        assert literal['prior']['h_rectangle']is None
        assert literal['final_test']['round']==len(literal['rounds'])and literal['final_test']['proposals']==[]
        key=str(path),reference['sha256']
        if key in self.checker.parents:
            report,state,diagonal=self.checker.parents[key]
            self.recheck()
        elif literal['schema']==C.SHARP_SCHEMA:
            report,state,diagonal=self.checker.replay(path,allow_open=True,return_state=True)
            assert report['status']=='PASS_CERTIFIED_CONDITIONAL_TILE_STATE_OPEN'
            self.checker.parents[key]=(report,copy.deepcopy(state),copy.deepcopy(diagonal))
        else:
            assert literal['schema']==C.R.FIRST_SCHEMA and reference['sha256']==C.ROOT_PARENT_SHA256
            assert len(literal['rounds'])==6
            report,state,diagonal=self.checker.ancestor.replay(path,allow_open=True,return_state=True)
            assert report['status']=='PASS_CERTIFIED_TILE_STATE_OPEN'and report['bound_rounds']==6
            assert not state.get('conditional_sharp_rows')
            self.checker.parents[key]=(report,copy.deepcopy(state),copy.deepcopy(diagonal))
        expected=('PASS_CERTIFIED_CONDITIONAL_TILE_STATE_OPEN'if literal['schema']==C.SHARP_SCHEMA
                  else'PASS_CERTIFIED_TILE_STATE_OPEN')
        assert report['status']==expected and report['certificate_sha256']==reference['sha256']
        assert digest(path)==reference['sha256']
        assert literal['final']==self.checker.view(state,diagonal)
        if literal['rounds']:assert literal['final']==literal['rounds'][-1]['after']
        self.checker.reconstruct(literal['final_test'],state,diagonal)
        self.register_bound_report(report)
        self.recheck()
        return literal,report,copy.deepcopy(state),copy.deepcopy(diagonal)

    def replay(self,filename,expected=None,allow_partial=False):
        start=time.monotonic();path=Path(filename).resolve();raw=path.read_bytes()
        hashed=hashlib.sha256(raw).hexdigest()
        if expected is not None:assert hashed==expected
        if self.checker.strict_root is not None:
            assert path.is_relative_to(Path(self.checker.strict_root).resolve())
        name=str(path);old=self.checker.touched.get(name)
        assert old is None or old==hashed
        self.checker.touched[name]=hashed
        key=name,hashed,allow_partial
        self.recheck()
        if key in self.completed:return copy.deepcopy(self.completed[key])
        assert (name,hashed)not in self.active,'Cyclic sharp-cover ancestry.'
        self.active.add((name,hashed))
        try:
            manifest=json.loads(raw)
            assert manifest['schema']in(COMPLETE_SCHEMA,DECLARED_SCHEMA)
            assert manifest['schema']==COMPLETE_SCHEMA or allow_partial
            assert manifest['original_closure_credit']==0
            assert manifest['complete_closed_domains']==20 and manifest['closed_faces_retained']is True
            if 'helper_sha256'in manifest:assert manifest['helper_sha256']==C.SHARP_ROWS_SHA256
            self.register_sources(manifest)
            parent_ref=manifest['parent']
            assert set(parent_ref)=={'path','sha256','schema'}
            parent,prior,state,diagonal=self.parent_state(parent_ref)
            rows=SHARP.complete_rows(manifest['selected_row'],manifest['beta_bound'],manifest['variation_bound'])
            assert len(rows)==20
            children=manifest['children'];assert [e['index']for e in children]==list(range(20))
            reports=[];interval_count=terminal_count=nested_count=open_count=0
            for index,(entry,row)in enumerate(zip(children,rows)):
                literal=SHARP.literal(row);assert entry['row']==literal
                if entry['kind']=='interval_exclusion':
                    lower=SHARP.lower_lhs(row,state['positions'],state['scalar'],state['differences'])
                    rhs=F(row[1]);assert lower>rhs,'An equality face cannot be discarded.'
                    evidence=dict(lower_lhs=str(lower),rhs=str(rhs),positive_gap=str(lower-rhs))
                    assert entry['evidence']==evidence
                    reports.append(dict(index=index,status='PASS_STRICT_PARENT_INTERVAL_EXCLUSION',row=literal,evidence=evidence))
                    interval_count+=1;continue
                assert entry['kind']in('bound_terminal','complete_sharp_subcover','open_bound_state')
                child_ref=entry['bound'];child_path,child=self.frozen(child_ref)
                assert child['schema']==C.SHARP_SCHEMA
                expected_detail=dict(kind='sharp_row_closed_complement',parent=parent_ref,
                    selected_row=manifest['selected_row'],beta_bound=manifest['beta_bound'],
                    variation_bound=manifest['variation_bound'],branch=index,
                    complete_closed_domains=20,closed_faces_retained=True,conditional_row=literal)
                assert child['sharp_restriction']==expected_detail
                assert child['id']==parent['id']and child['path']==parent['path']and child['prior']==parent['prior']
                report,child_state,child_diagonal=self.checker.replay(child_path,allow_open=True,return_state=True)
                assert report['certificate_sha256']==child_ref['sha256']and digest(child_path)==child_ref['sha256']
                assert report['tile']==prior['tile']and report['rectangle']==prior['rectangle']
                assert report['h_rectangle']==prior['h_rectangle']and report['original_parent_path']==parent['path']
                assert child_state['conditional_sharp_rows']==tuple(state.get('conditional_sharp_rows',()))+(row,)
                self.register_bound_report(report)
                if entry['kind']=='bound_terminal':
                    assert child['status']=='CANDIDATE_CLOSED'
                    assert report['status']=='PASS_COMPLETE_CONDITIONAL_PHYSICAL_TILE'
                    reports.append(dict(index=index,status='PASS_CLOSED_FAILURE_CONDITIONAL_TERMINAL',row=literal,bound_report=report))
                    terminal_count+=1
                elif entry['kind']=='open_bound_state':
                    assert allow_partial and manifest['schema']==DECLARED_SCHEMA
                    assert child['status']=='OPEN'and report['status']=='PASS_CERTIFIED_CONDITIONAL_TILE_STATE_OPEN'
                    reports.append(dict(index=index,status='OPEN_CERTIFIED_FAILURE_DOMAIN',row=literal,bound_report=report))
                    open_count+=1
                else:
                    assert child['status']=='OPEN'and report['status']=='PASS_CERTIFIED_CONDITIONAL_TILE_STATE_OPEN'
                    cover_ref=entry['cover'];cover_path,subcover=self.frozen(cover_ref)
                    assert subcover['schema']==COMPLETE_SCHEMA and subcover['parent']==child_ref
                    proof=self.replay(cover_path,cover_ref['sha256'],allow_partial=False)
                    assert proof['status']=='PASS_COMPLETE_CONDITIONAL_PARENT_BY_SHARP_COVER'
                    assert proof['parent']==child_ref and proof['original_parent_path']==parent['path']
                    assert proof['tile']==prior['tile']and proof['rectangle']==prior['rectangle']
                    assert proof['h_rectangle']==prior['h_rectangle']
                    assert proof['inherited_conditional_sharp_rows']==[SHARP.literal(row)for row in child_state['conditional_sharp_rows']]
                    assert digest(cover_path)==cover_ref['sha256']
                    reports.append(dict(index=index,status='PASS_CLOSED_FAILURE_COMPLETE_SHARP_SUBCOVER',row=literal,
                                        bound_report=report,cover_report=proof))
                    nested_count+=1
                assert digest(child_path)==child_ref['sha256']
            assert interval_count+terminal_count+nested_count+open_count==20
            complete=open_count==0
            assert allow_partial or complete
            if manifest['schema']==COMPLETE_SCHEMA:assert complete
            conditional=parent['schema']==C.SHARP_SCHEMA
            status=('PASS_COMPLETE_CONDITIONAL_PARENT_BY_SHARP_COVER'if conditional else'PASS_COMPLETE_FIXED_TILE_BY_SHARP_COVER')if complete else'PASS_DECLARED_SHARP_COVER_WITH_OPEN_FAILURES'
            # Reports accumulated by this gate are source-hash keyed. A common
            # six-round parent or nested OPEN state contributes exactly once.
            used={}
            def collect(report):
                key=report['certificate_sha256'];used[key]=self.bound_records[key]
                if 'conditional_parent_replay'in report:collect(report['conditional_parent_replay'])
            collect(prior)
            def gather(children):
                for entry in children:
                    if 'bound_report'in entry:collect(entry['bound_report'])
                    if 'cover_report'in entry:gather(entry['cover_report']['child_reports'])
            gather(reports)
            result=dict(schema='independent_complete_CD_sharp_guard_cover_replay_v1',status=status,
                id=parent['id'],parent=parent_ref,original_parent_path=parent['path'],
                tile=prior['tile'],rectangle=prior['rectangle'],h_rectangle=prior['h_rectangle'],
                original_prefix_sha256=C.ORIGINAL_PREFIX_SHA256,
                selected_row=manifest['selected_row'],beta_bound=manifest['beta_bound'],variation_bound=manifest['variation_bound'],
                complete_closed_guard_failures=20,all_closed_faces_retained=True,
                guard_region_excluded_by_accepted_physical_theorem=True,
                interval_failure_domains=interval_count,bound_terminal_failure_domains=terminal_count,
                nested_complete_failure_domains=nested_count,open_failure_domains=open_count,
                open_failure_indices=[r['index']for r in reports if r['status']=='OPEN_CERTIFIED_FAILURE_DOMAIN'],
                inherited_conditional_sharp_rows=[SHARP.literal(row)for row in state.get('conditional_sharp_rows',())],
                original_parent_bound_replay=prior,child_reports=reports,
                distinct_bound_records=len(used),unique_bound_records=[used[k]for k in sorted(used)],
                bound_rounds=sum(r['bound_rounds']for r in used.values()),
                bound_deductions=sum(r['bound_deductions']for r in used.values()),
                bound_premise_rows=sum(r['bound_premise_rows']for r in used.values()),
                terminal_rows=sum(r['terminal_rows']for r in used.values()),
                shared_bound_states_counted_once=True,cover_sha256=hashed,
                checker_sha256=digest(__file__),inner_checker_sha256=CHECKER_SHA256,
                source_sha256=dict(self.checker.touched),
                checker_dependency_sha256=dict(self.checker.dependencies,**self.dependencies),
                complete_twenty_failure_cover_checked=complete,
                complete_fixed_tiles=int(complete and not conditional),
                whole_original_cover_checked=False,new_original_cells=0,new_masks=0,seconds=time.monotonic()-start)
            self.recheck()
            assert digest(path)==hashed
            result['all_sibling_sources_and_ancestors_rehashed_before_report']=True
            self.completed[key]=copy.deepcopy(result)
            return result
        finally:
            self.active.remove((name,hashed))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('cover',type=Path)
    ap.add_argument('--context',type=Path,default=C.DEFAULT_CONTEXT)
    ap.add_argument('--ancestry',type=Path)
    ap.add_argument('--strict-root',type=Path)
    ap.add_argument('--allow-partial',action='store_true')
    ap.add_argument('--report',type=Path,required=True)
    a=ap.parse_args();checker=SharpCoverChecker(a.context,a.ancestry,a.strict_root)
    report=checker.replay(a.cover,allow_partial=a.allow_partial)
    checker.recheck()
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k]for k in('status','complete_closed_guard_failures',
          'interval_failure_domains','bound_terminal_failure_domains','open_failure_domains',
          'bound_deductions','complete_fixed_tiles','new_original_cells','new_masks')},indent=2))

if __name__=='__main__':main()
