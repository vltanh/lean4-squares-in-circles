"""Exact terminal facts shared by fixed original-center bound checkers.

The caller must first independently prove the original state and every
preceding bound deduction. No discovery module is imported here.
"""
from fractions import Fraction as F
from itertools import combinations
import importlib

def empty_interval_witness(intervals,kind,index_offset=0):
    for index,(lo,hi)in enumerate(intervals):
        if lo>hi:
            return dict(kind=kind,index=index+index_offset,lower=str(lo),upper=str(hi),gap=str(lo-hi))
    return None

def verify_interval_terminal(terminal,state,K):
    assert terminal['kind']=='exact_interval_or_accepted_terminal'
    rr=terminal['state'];label=terminal['label']
    assert rr['angles_before']==K.view(state['angles'])
    assert rr['positions_before']==K.view(state['positions'])
    assert rr['scalar_before']==K.view(state['scalar'])
    assert rr['differences_before']==K.diffview(state['differences'])
    assert rr['proposals']==[]
    R=importlib.import_module('review_guarded_frame_bounds_independent')
    rows,bounds,actual=R.collect_guarded(state['path'],state['angles'],state['positions'],
                                       state['choices'],state['scalar'])
    if isinstance(label,str):
        assert actual is not None and actual==label
        assert rr['rows']==len(rows)
        assert rr['propagated_positions']==K.view(state['positions'])
        assert rr['physical_scalar_intersection']==K.view(state['scalar'])
        assert rr['effective_differences']==K.diffview(state['differences'])
        assert rr['three_square_guards']==[]
        # This frequent accepted terminal also receives a direct second
        # reconstruction from the original pair-inset separator cover.
        if label.startswith('all four original inset separation options impossible:'):
            effective,early=K.V.effective_boxes(state['angles'],state['choices'],K.LEGACY)
            assert early is None
            pos,hs,gs,early=K.V.center_bounds(effective,state['positions'],state['choices'],K.LEGACY)
            assert early==label
        return dict(kind='accepted_exact_physical_interval',label=label)
    assert isinstance(label,dict)and label['kind']=='certified_difference_intersection_empty'
    assert actual is None
    effective,early=K.V.effective_boxes(state['angles'],state['choices'],K.LEGACY)
    assert early is None
    pos,hs,gs,early=K.V.center_bounds(effective,state['positions'],state['choices'],K.LEGACY)
    assert early is None
    target=tuple(label['pair']);axis=label['axis']
    assert len(target)==2 and 0<=target[0]<target[1]<9 and axis in(0,1)
    derived={};witness=None
    for pair in combinations(range(9),2):
        physical=tuple(map(tuple,K.V.difference_bounds(pair,pos,gs,K.LEGACY)))
        inherited=state['differences'].get(pair,physical)
        derived[pair]=tuple((max(lo,a),min(hi,b))for(lo,hi),(a,b)in zip(physical,inherited))
        for ax,(lo,hi)in enumerate(derived[pair]):
            if lo>hi:
                witness=dict(kind='certified_difference_intersection_empty',pair=list(pair),axis=ax,
                    analytic_interval=list(map(str,physical[ax])),certified_interval=list(map(str,inherited[ax])),
                    empty_intersection=[str(lo),str(hi)])
                break
        if witness is not None:break
    assert witness==label
    assert rr['propagated_positions']==K.view(pos)
    assert rr['physical_scalar_intersection']==K.view(state['scalar'])
    assert rr['effective_differences']==K.diffview(derived)
    assert rr['three_square_guards']==[]and rr['rows']==len(rows)
    return witness
