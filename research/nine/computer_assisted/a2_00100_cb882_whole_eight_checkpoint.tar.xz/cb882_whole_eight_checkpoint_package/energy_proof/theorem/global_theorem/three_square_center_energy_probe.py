#!/usr/bin/env python3
"""Finite numerical discovery only; no lower bound is proved here."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
from pathlib import Path
import json,time
import numpy as np
from scipy.optimize import minimize
rng=np.random.default_rng(11625)
pairs=((0,1),(0,2),(1,2))
def geometry(z):
 c=np.array(((0.,0.),z[:2],z[2:4]));theta=np.array((0.,z[4],z[5]))
 u=np.stack((np.cos(theta),np.sin(theta)),axis=1)
 v=np.stack((-np.sin(theta),np.cos(theta)),axis=1)
 return c,theta,u,v
def slacks(z):
 c,t,u,v=geometry(z);out=[]
 for i,j in pairs:
  d=c[j]-c[i];support=(1+abs(np.cos(t[j]-t[i]))+abs(np.sin(t[j]-t[i])))/2
  out.append(max(abs(d@u[i]),abs(d@v[i]),abs(d@u[j]),abs(d@v[j]))-support)
 return np.array(out)
def energy(z):
 return z[:2]@z[:2]+z[2:4]@z[2:4]+(z[:2]-z[2:4])@(z[:2]-z[2:4])
best=None;records=[];start=time.monotonic()
for k in range(48):
 if k==0:z=np.array((1.,0.,.5,1.,0.,0.))
 else:
  z=np.r_[rng.normal(size=4),rng.uniform(-np.pi/4,np.pi/4,size=2)]
  c,t,u,v=geometry(z);scale=1.
  for i,j in pairs:
   d=c[j]-c[i];support=(1+abs(np.cos(t[j]-t[i]))+abs(np.sin(t[j]-t[i])))/2
   scale=max(scale,1.05*support/max(abs(d@u[i]),abs(d@v[i]),abs(d@u[j]),abs(d@v[j])))
  z[:4]*=scale
 result=minimize(energy,z,method='SLSQP',constraints=[{'type':'ineq','fun':slacks}],bounds=[(None,None)]*4+[(-np.pi/4,np.pi/4)]*2,options={'maxiter':600,'ftol':2e-11})
 slack=slacks(result.x);rec=dict(trial=k,energy=float(energy(result.x)),minimum_separation_slack=float(min(slack)),success=bool(result.success),coordinates_and_angles=result.x.tolist())
 records.append(rec)
 if min(slack)>=-1e-8 and(best is None or rec['energy']<best['energy']):best=rec;print('BEST',best,flush=True)
report=dict(scope='Numerical probe only; no universal theorem or closure',restarts=len(records),best=best,seconds=time.monotonic()-start,records=records,new_original_cells=0,new_masks=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('FINISHED',report['seconds'],best,flush=True)
