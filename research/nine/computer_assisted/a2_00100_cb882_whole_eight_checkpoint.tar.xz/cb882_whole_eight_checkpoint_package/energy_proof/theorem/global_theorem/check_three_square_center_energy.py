#!/usr/bin/env python3
"""Exact Q(sqrt(2)) check for the cyclic separator part of E >= 7/2.

The accompanying hand proof reduces every separator ownership pattern to
an elementary star argument or to this complete, fixed angular cover.
This checker imports no numerical library and proves no original cell.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent

class Q2:
    def __init__(self,a=0,b=0):self.a,self.b=F(a),F(b)
    def __add__(self,other):
        other=asq(other);return Q2(self.a+other.a,self.b+other.b)
    __radd__=__add__
    def __neg__(self):return Q2(-self.a,-self.b)
    def __sub__(self,other):return self+-asq(other)
    def __rsub__(self,other):return asq(other)+-self
    def __mul__(self,other):
        other=asq(other);return Q2(self.a*other.a+2*self.b*other.b,self.a*other.b+self.b*other.a)
    __rmul__=__mul__
    def nonnegative(self):
        a,b=self.a,self.b
        if a>=0 and b>=0:return True
        if a<0 and b<=0:return False
        if a>=0 and b<0:return a*a>=2*b*b
        assert a<0 and b>0
        return 2*b*b>=a*a
    def absolute(self):return self if self.nonnegative()else-self
    def literal(self):return[str(self.a),str(self.b)]

def asq(x):return x if isinstance(x,Q2)else Q2(x)
COS=(Q2(1),Q2(0,F(1,2)),Q2(0),Q2(0,-F(1,2)),Q2(-1),Q2(0,-F(1,2)),Q2(0),Q2(0,F(1,2)))
def cosine(k):return COS[k%8]
def sine(k):return COS[(2-k)%8]
def support(k):return F(1,2)*(1+cosine(k).absolute()+sine(k).absolute())
DUALS=((F(1),F(1),F(1)),(F(3,2),F(1),F(1)),(F(1),F(3,2),F(1)),(F(1),F(1),F(3,2)))

def value(dual,k,j):
    a,b,c=DUALS[dual]
    return 2*(a*support(k)+b*support(j-k)+c*support(j))-F(2,3)*(a*a+b*b+c*c)+F(2,3)*(a*b*cosine(k)+a*c*cosine(j)+b*c*cosine(j-k))

def vertices(k,j,half):
    assert half in(0,1)
    return((k,j),(k+1,j)if half==0 else(k,j+1),(k+1,j+1))

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def replay(certificate,report_path):
    certificate=Path(certificate).resolve();raw=certificate.read_bytes();source_hash=hashlib.sha256(raw).hexdigest()
    data=json.loads(raw)
    assert data['schema']=='three_square_cycle_energy_fixed_angular_cover_v1'
    assert data['angle_unit']=='pi/4'and data['energy_lower_bound']=='7/2'
    assert data['dual_vectors']==[[str(x)for x in l]for l in DUALS]
    entries=data['triangles']
    expected=[(k,j,h)for k,j,h in product(range(8),range(8),range(2))]
    assert [(e['k'],e['j'],e['half'])for e in entries]==expected
    assert len(entries)==128
    # For every angle term, its cosine coefficient is bounded by the
    # |cos| coefficient. Hence each trigonometric term is nonnegative
    # and concave on every fixed sine/cosine sign region.
    for l in DUALS:
        assert all(0<x<=F(3,2)for x in l)
        for i in range(3):assert F(2,3)*l[i]*l[(i+1)%3]<=l[i]
    checked=0;zero=0;use=[0]*4
    for entry in entries:
        k,j,half=entry['k'],entry['j'],entry['half'];dual=entry['dual']
        assert type(dual)is int and 0<=dual<4
        vs=vertices(k,j,half)
        assert entry['vertices']==[list(p)for p in vs]
        # Quadrant boundaries occur at even integer units. None lies
        # in the interior of any range theta,phi,phi-theta in this triangle.
        for projection in(lambda x,y:x,lambda x,y:y,lambda x,y:y-x):
            vals=[projection(x,y)for x,y in vs];lo,hi=min(vals),max(vals)
            assert hi-lo<=1
            assert not any(lo<t<hi for t in range(-16,17,2))
        gaps=[value(dual,*p)-F(7,2)for p in vs]
        assert entry['vertex_gaps']==[g.literal()for g in gaps]
        assert all(g.nonnegative()for g in gaps)
        checked+=len(gaps);zero+=sum(g.a==g.b==0 for g in gaps);use[dual]+=1
    # Exact algebra behind the two star-sector reductions.
    assert F(15,17)**2+F(8,17)**2==1
    assert F(7,25)**2+F(24,25)**2==1
    assert F(8,17)<F(24,25)
    # Polynomial identities: 1-a^2-(1-3a/5)^2=2a(15-17a)/25,
    # and 1-b^2-(1-3b/4)^2=b(24-25b)/16.
    assert (F(0),F(6,5),-F(34,25))==(F(0),F(2*15,25),-F(2*17,25))
    assert (F(0),F(3,2),-F(25,16))==(F(0),F(24,16),-F(25,16))
    assert certificate.read_bytes()==raw
    report=dict(schema='independent_three_square_center_energy_exact_cover_replay_v1',
        status='PASS_EXACT_CYCLIC_COVER_AND_STAR_ARITHMETIC',energy_lower_bound='7/2',
        original_unit_squares=3,pairwise_interior_disjoint=True,arbitrary_rotations=True,
        fixed_angular_triangles=128,exact_Q_sqrt2_vertex_inequalities=checked,
        equality_vertex_occurrences=zero,dual_triangle_counts=use,
        complete_closed_angle_domain=True,all_quadrant_sign_guards_checked=True,
        concavity_coefficient_nonnegativity_checked=True,star_sector_arithmetic_checked=True,
        certificate_sha256=source_hash,checker_sha256=digest(__file__),
        accompanying_hand_proof_required=True,numerical_optimizer_imported=False,
        whole_original_caller_checked=False,new_original_cells=0,new_masks=0)
    Path(report_path).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    assert __debug__
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--certificate',type=Path,default=HERE/'THREE_SQUARE_CYCLE_ENERGY_TABLE.json')
    p.add_argument('--report',type=Path,default=HERE/'THREE_SQUARE_CENTER_ENERGY_EXACT_REPLAY.json')
    a=p.parse_args();replay(a.certificate,a.report)
