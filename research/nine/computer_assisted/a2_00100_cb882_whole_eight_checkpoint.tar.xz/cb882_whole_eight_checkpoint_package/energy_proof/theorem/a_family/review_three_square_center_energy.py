#!/usr/bin/env python3
"""Independent arithmetic review of the three-square energy finite table.

The geometric reductions are reviewed in the accompanying Markdown file.
This evaluator does not import the proposed checker or any numerical library.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'global_theorem'
FILES = ('THREE_SQUARE_CENTER_ENERGY_HAND_PROOF.md',
         'check_three_square_center_energy.py',
         'THREE_SQUARE_CYCLE_ENERGY_TABLE.json')
raw = {name: (SOURCE / name).read_bytes() for name in FILES}
digest = lambda data: hashlib.sha256(data).hexdigest()
assert digest(raw[FILES[1]]) == '9aaeff8302d18f88992aaa5fcd29b95cf5ec5ab4eaa63b107757146fa5b5fb2e'
assert digest(raw[FILES[2]]) == 'f656277b5a003aa7dc81e4403dc7c72e0f305bcf74512865cf515cca4c66d911'

# A pair (r,s) denotes r+s*sqrt(2). All operations and signs are rational.
def scalar(value):
    return (F(value), F(0))

def add(*values):
    return tuple(sum(v[k] for v in values) for k in range(2))

def scale(value, coefficient):
    return tuple(coefficient * entry for entry in value)

def nonnegative(value):
    r, s = value
    if s == 0:
        return r >= 0
    if s > 0:
        return r >= 0 or 2 * s * s >= r * r
    return r >= 0 and r * r >= 2 * s * s

def absolute(value):
    return value if nonnegative(value) else scale(value, -1)

T = F(1, 2)
# Exact unit normal coordinates, indexed by their angle in pi/4 units.
NORMAL = (((F(1),F(0)),(F(0),F(0))),
          ((F(0),T),(F(0),T)),
          ((F(0),F(0)),(F(1),F(0))),
          ((F(0),-T),(F(0),T)),
          ((F(-1),F(0)),(F(0),F(0))),
          ((F(0),-T),(F(0),-T)),
          ((F(0),F(0)),(F(-1),F(0))),
          ((F(0),T),(F(0),-T)))

def multiply(u, v):
    r, s = u
    t, w = v
    return (r*t+2*s*w, r*w+s*t)

def dot(u, v):
    return add(*(multiply(a, b) for a, b in zip(u, v)))

for normal in NORMAL:
    assert dot(normal, normal) == scalar(1)

DUALS = ((F(1),F(1),F(1)),(F(3,2),F(1),F(1)),
         (F(1),F(3,2),F(1)),(F(1),F(1),F(3,2)))

def support(k):
    return scale(add(scalar(1), *(absolute(v) for v in NORMAL[k % 8])), T)

def vertex_gap(dual, theta, phi):
    normals = (NORMAL[0], NORMAL[theta % 8], NORMAL[phi % 8])
    thresholds = (support(theta), support(phi-theta), support(phi))
    # The exact squared norm of the projection w_i - mean(w) is
    # sum |w_i|^2 - |sum w_i|^2/3; evaluate it directly in coordinates.
    weights = tuple(tuple(scale(v, lam) for v in normal)
                    for lam, normal in zip(dual, normals))
    total = tuple(add(*(w[k] for w in weights)) for k in range(2))
    norm = add(scalar(sum(lam*lam for lam in dual)),
               scale(dot(total, total), -F(1,3)))
    return add(*(scale(s, 2*lam) for lam, s in zip(dual, thresholds)),
               scale(norm, -1), scalar(-F(7,2)))

table = json.loads(raw[FILES[2]])
assert table['schema'] == 'three_square_cycle_energy_fixed_angular_cover_v1'
assert table['angle_unit'] == 'pi/4'
assert table['energy_lower_bound'] == '7/2'
assert table['dual_vectors'] == [[str(v) for v in row] for row in DUALS]
assert [(e['k'], e['j'], e['half']) for e in table['triangles']] == list(product(range(8), range(8), range(2)))
counts = [0] * 4
zero = 0
checked = 0
for entry in table['triangles']:
    k, j, half = entry['k'], entry['j'], entry['half']
    vertices = ((k,j), (k+1,j) if half == 0 else (k,j+1), (k+1,j+1))
    assert entry['vertices'] == [list(v) for v in vertices]
    # The two triangles have positive unit determinant and share their
    # diagonal; their closed union is the entire unit square.
    v0, v1, v2 = vertices
    determinant = (v1[0]-v0[0])*(v2[1]-v0[1])-(v1[1]-v0[1])*(v2[0]-v0[0])
    assert abs(determinant) == 1
    for component in (lambda x,y:x, lambda x,y:y, lambda x,y:y-x):
        values = [component(*v) for v in vertices]
        low, high = min(values), max(values)
        assert high-low <= 1
        assert all(not low < cut < high for cut in range(-8,9,2))
    assert type(entry['dual']) is int and 0 <= entry['dual'] < 4
    dual = DUALS[entry['dual']]
    for i in range(3):
        for sign in (-1, 1):
            assert dual[i] + sign*F(2,3)*dual[i]*dual[(i+1)%3] >= 0
    values = [vertex_gap(dual,*v) for v in vertices]
    assert entry['vertex_gaps'] == [[str(x) for x in v] for v in values]
    assert all(nonnegative(v) for v in values)
    zero += sum(v == scalar(0) for v in values)
    checked += 3
    counts[entry['dual']] += 1

# Arithmetic consistency checks for the star Gram matrix at exact unit
# normals. Its general symbolic multiplication is part of the hand review,
# rather than being inferred from these finitely many samples.
Qinv = ((F(2,3),0,F(1,3),0),(0,F(2,3),0,F(1,3)),
        (F(1,3),0,F(2,3),0),(0,F(1,3),0,F(2,3)))
for p,q in ((F(1),F(0)),(F(-1),F(0)),(F(0),F(1)),(F(0),F(-1)),(F(3,5),F(4,5))):
    L = ((1,0,0,0),(0,0,0,1),(-p,-q,p,q))
    G = [[sum(L[i][a]*Qinv[a][b]*L[j][b] for a,b in product(range(4),repeat=2))
          for j in range(3)] for i in range(3)]
    assert G == [[F(2,3),F(0),-p/3],[F(0),F(2,3),q/3],[-p/3,q/3,F(2,3)]]
assert F(6,5) == F(2*15,25) and -1-F(9,25) == -F(2*17,25)
assert F(3,2) == F(24,16) and -1-F(9,16) == -F(25,16)
assert F(15,17)**2+F(8,17)**2 == 1
assert F(8,17) < F(24,25)
assert checked == 384 and zero == 54 and counts == [74,24,18,12]
for name in FILES:
    assert (SOURCE / name).read_bytes() == raw[name]
report = dict(schema='independent_three_square_center_energy_review_v1',
              status='PASS_INDEPENDENT_MATH_REVIEW_AND_EXACT_TABLE_RECONSTRUCTION',
              energy_lower_bound='7/2',
              complete_closed_angular_triangles=128,
              exact_vertex_inequalities=checked,
              zero_vertex_occurrences=zero,
              dual_counts=counts,
              evaluator_imports_proposed_checker=False,
              evaluator_uses_floating_point=False,
              hand_review_required='THREE_SQUARE_CENTER_ENERGY_INDEPENDENT_REVIEW.md',
              source_sha256={name:digest(raw[name]) for name in FILES},
              independent_evaluator_sha256=digest(Path(__file__).read_bytes()),
              original_cell_closure_credit=0,mask_closure_credit=0)
(HERE / 'THREE_SQUARE_CENTER_ENERGY_INDEPENDENT_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
