# Independent review: three-square center energy

**Result: PASS.** Three arbitrary closed unit squares with pairwise disjoint
interiors have

\[
 |A-B|^2+|B-C|^2+|C-A|^2\geq\frac72.
\]

The reviewed hand proof and literal finite table give a complete argument,
including touching configurations. This review supplies no original-cell or
mask closure. Any use as an affine row still requires an independently
checked conversion on the actual certified intervals.

## Reviewed immutable sources

The source directory is `../global_theorem`. The exact source digests are:

| Source | SHA-256 |
|---|---|
| THREE_SQUARE_CENTER_ENERGY_HAND_PROOF.md | 9bc240c0c7f1f25f434a6bc74af9ac8796990a7c44f5ce6335527ec015468c22 |
| check_three_square_center_energy.py | 9aaeff8302d18f88992aaa5fcd29b95cf5ec5ab4eaa63b107757146fa5b5fb2e |
| THREE_SQUARE_CYCLE_ENERGY_TABLE.json | f656277b5a003aa7dc81e4403dc7c72e0f305bcf74512865cf515cca4c66d911 |

The separate evaluator `review_three_square_center_energy.py` imports neither
the proposed checker nor a numerical library. It reconstructs each cyclic
dual value directly from the exact normal vectors and
\(\sum|w_i|^2-|\sum w_i|^2/3\), with arithmetic in rational pairs
representing \(r+s\sqrt2\). Its resulting report is
`THREE_SQUARE_CENTER_ENERGY_INDEPENDENT_REVIEW.json`.

## Physical separator and ownership reduction

For a pair of squares, the forbidden open center-difference region is the
interior of their Minkowski difference. Its edge normals are axes of the
two original square frames. A difference outside this open polygon
therefore satisfies at least one of its closed supporting inequalities.
The chosen normal can be signed towards the other center. Its required
projection is exactly \((1+|\cos t|+|\sin t|)/2\), where \(t\) is the
relative frame angle. This also handles equality and touching.

Selecting one owner for each of three unordered pairs produces a tournament
on three vertices. It either has a vertex of outdegree two or all three
outdegrees equal one. These are precisely the star and directed-cycle cases
used in the proof. There is no omitted arrangement and no restriction on the
rotations. The radius-one-half open disks contained in the square interiors
also show every center distance is at least one.

The support triangle law is valid. Distance to the subgroup
\((\pi/2)\mathbb Z\), reduced to \([0,\pi/4]\), obeys the triangle inequality.
The function \(g(x)=\cos x+\sin x-1\) is nonnegative, increasing and concave
on this interval, with \(g(0)=0\). Concavity gives subadditivity when the
sum stays in the interval. Reducing one argument to the complementary
endpoint and using monotonicity handles larger sums. These statements prove
\(f(u)+f(v)\geq1+f(u-v)\) for every real pair, including quotient-boundary
cases.

## Star cases and the two dual sectors

The two signed axes of the owner either agree, are opposite, or are
perpendicular. When they agree, the midpoint of the other centers has norm
at least one, and their difference has norm at least one. The identity
\(E=2|m|^2+3|d|^2/2\) yields \(7/2\). When opposite, \(|d|\geq2\) yields
the stronger bound six.

In the perpendicular case, reflection and exchange of the other two
squares let the remaining separator be owned by B without changing the
energy or support constraints. If its signed normal is \((p,q)\), write
\(a=|p|\), \(b=|q|\). Then \(a^2+b^2=1\), and the three thresholds satisfy
\(h=(1+a+b)/2\), \(s,t\geq1\), and \(s+t\geq1+h\).

Direct multiplication by
\(Q^{-1}=\frac13\left(\begin{smallmatrix}2I&I\\I&2I\end{smallmatrix}\right)\)
gives diagonal Gram entries \(2/3\), with cross entries
\(G_{12}=0\), \(G_{13}=-p/3\), \(G_{23}=q/3\). Replacing the latter two
by their upper bounds \(a/3\) and \(b/3\) is valid because all dual
coefficients are nonnegative. Completing the square gives the claimed
dual lower bound.

The first dual, \((3/2,1,1)\), gives
\(E\geq8/3+a/2+5b/6\). For \(a\leq15/17\), the exact identity
\(b^2-(1-3a/5)^2=2a(15-17a)/25\), with both comparison terms
nonnegative, implies \(3a+5b\geq5\) and hence \(E\geq7/2\).

The second dual, \((1,3/2,1)\), uses
\(2h+3s+2t\geq4h+3\) and gives
\(E\geq13/6+4a/3+b\). For \(b\leq24/25\), the exact identity
\(a^2-(1-3b/4)^2=b(24-25b)/16\) proves \(4a+3b\geq4\).
If the first sector fails, \(a>15/17\) forces
\(b<8/17<24/25\), so the second sector applies. Thus these two closed
sectors cover every possible perpendicular case.

## Cycle duals, concavity, and complete exact table

In the cycle, the outgoing owned axis is an axis of the next pair's other
square. The thresholds are consequently exactly
\(h(\theta),h(\phi-\theta),h(\phi)\); no unknown frame has been
discarded. With \(\sum d_i=0\), expanding
\(\sum|d_i-(w_i-\bar w)|^2\geq0\) yields the stated dual formula.

For each of the four declared dual vectors, every component lies in
\((0,3/2]\). On a region of fixed sine and cosine signs, each angle term
has nonnegative coefficients of \(|\cos u|\) and \(|\sin u|\), because
\(\lambda_i\pm(2/3)\lambda_i\lambda_{i+1}\geq0\).
Its second derivative is its negative, so it is concave. Composition with
the affine angle differences and summation preserve concavity.

The two triangles in every one of the 64 unit squares partition the full
\([0,8]^2\) angle domain in units of \(\pi/4\). Their boundaries are
included. Each of \(\theta,\phi,\phi-\theta\) ranges over an interval
with integer endpoints and length at most one on each triangle; the even
integer quadrant boundaries cannot occur in the interior of such a range.
The required concavity therefore holds throughout every selected triangle.

The independent evaluator checked all 128 addresses, their exact vertices,
all 384 table gaps, the quadrant guards, and the nonnegative coefficients.
It recovered dual-use counts 74, 24, 18, and 12, with 54 zero-gap vertex
occurrences. All gap signs were proved by rational squaring with explicit
sign cases. It also rehashed all three sources at return. Concavity makes
each selected dual at least the barycentric average of its three vertex
values, completing the cyclic case on the entire closed domain.

The resulting inequality is unconditional for any three retained original
physical squares. This conclusion rests on the geometric argument and the
exact finite table together; the numerical discovery history is unnecessary.
