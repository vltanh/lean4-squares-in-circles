#!/usr/bin/env python3
"""Replay the two exact arithmetic implementations for the shared theorem."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
digest=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    assert __debug__
    started=time.monotonic()
    manifest_path=HERE/'SHA256_MANIFEST.json'
    manifest_bytes=manifest_path.read_bytes()
    manifest=json.loads(manifest_bytes)
    def unchanged():
        assert manifest_path.read_bytes()==manifest_bytes
        for name,value in manifest['files'].items():
            path=(HERE/name).resolve()
            assert path.is_relative_to(HERE) and digest(path)==value,name
    unchanged()
    accepted=json.loads((HERE/'accepted_reports/INDEPENDENT_ARITHMETIC.json').read_text())
    assert accepted['status']=='PASS_INDEPENDENT_MATH_REVIEW_AND_EXACT_TABLE_RECONSTRUCTION'
    assert accepted['evaluator_imports_proposed_checker'] is False
    for name,value in accepted['source_sha256'].items():
        assert digest(HERE/'global_theorem'/name)==value,name
    evaluator=HERE/'a_family/review_three_square_center_energy.py'
    assert digest(evaluator)==accepted['independent_evaluator_sha256']
    invocations=[
        ('AUTHOR_ARITHMETIC.log',[sys.executable,'-B','-S',str(HERE/'global_theorem/check_three_square_center_energy.py'),
            '--certificate',str(HERE/'global_theorem/THREE_SQUARE_CYCLE_ENERGY_TABLE.json'),
            '--report',str(HERE/'ROOT_EXACT_REPLAY.json')]),
        ('INDEPENDENT_ARITHMETIC.log',[sys.executable,'-B','-S',str(evaluator)]),
    ]
    for log,args in invocations:
        with (HERE/log).open('w') as output:
            subprocess.run(args,cwd=HERE,stdout=output,stderr=subprocess.STDOUT,check=True)
    first=json.loads((HERE/'ROOT_EXACT_REPLAY.json').read_text())
    second_path=HERE/'a_family/THREE_SQUARE_CENTER_ENERGY_INDEPENDENT_REVIEW.json'
    second=json.loads(second_path.read_text())
    assert first==json.loads((HERE/'accepted_reports/AUTHOR_ARITHMETIC.json').read_text())
    assert second==accepted
    assert first['fixed_angular_triangles']==second['complete_closed_angular_triangles']==128
    assert first['exact_Q_sqrt2_vertex_inequalities']==second['exact_vertex_inequalities']==384
    assert first['energy_lower_bound']==second['energy_lower_bound']=='7/2'
    assert first['new_original_cells']==first['new_masks']==0
    assert second['original_cell_closure_credit']==second['mask_closure_credit']==0
    unchanged()
    report=dict(schema='shared_three_square_center_energy_complete_packet_replay_v1',
        status='PASS_SHARED_THREE_SQUARE_ENERGY_THEOREM',energy_lower_bound='7/2',
        physical_original_unit_squares=3,arbitrary_rotations=True,closed_contacts_retained=True,
        complete_hand_proof_and_independent_manual_review_included=True,
        fixed_closed_angle_triangles=128,exact_vertex_inequalities_per_evaluator=384,
        independent_exact_evaluators=2,evaluators_import_each_other=False,
        all_frozen_inputs_checked_before_and_after=True,frozen_inputs=len(manifest['files']),
        all_mathematical_input_paths_confined_to_packet=True,numerical_discovery_imported=False,
        source_manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
        archived_replay_outputs={'ROOT_EXACT_REPLAY.json':digest(HERE/'ROOT_EXACT_REPLAY.json'),
            str(second_path.relative_to(HERE)):digest(second_path)},
        new_original_cells=0,new_masks=0,whole_mask_closed=False,lean_lake_ci_run=False,
        no_new_affine_or_lifted_row_conversion_claimed=True,seconds=time.monotonic()-started)
    (HERE/'COMPLETE_REPLAY.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
