#!/usr/bin/env python3
"""Independent exact affine/secant and moment identities for triple energy.

The affine expectation is expanded as (7/2 - center energy) plus the
weighted products (projection-lower)*(projection-upper). All quadratic
terms must cancel. The moment expectation uses a centroid expansion.
This is an algebra audit; certified intervals and physical square
nonoverlap remain obligations of the original caller.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations, product
import argparse, hashlib, importlib.util, json

import independent_three_square_energy_rows as R

HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Polynomial:
    """Literal degree-two arithmetic, independently indexed by monomial tuples."""
    N = 54
    SIZE = 1539

    @staticmethod
    def number(value):
        return {(): F(value)} if value else {}

    @staticmethod
    def variable(index):
        assert 0 <= index < 54
        return {(index,): F(1)}

    @staticmethod
    def combine(*terms):
        result = {}
        for term in terms:
            for monomial, coefficient in term.items():
                result[monomial] = result.get(monomial, F(0)) + coefficient
        return {m: v for m, v in result.items() if v}

    @staticmethod
    def times_constant(term, coefficient):
        return {m: F(coefficient)*v for m, v in term.items() if coefficient*v}

    @classmethod
    def minus(cls, left, right):
        return cls.combine(left, cls.times_constant(right, -1))

    @staticmethod
    def product(left, right):
        result = {}
        for a, x in left.items():
            for b, y in right.items():
                m = tuple(sorted(a+b))
                assert len(m) <= 2
                result[m] = result.get(m, F(0)) + x*y
        return {m: v for m, v in result.items() if v}

    @staticmethod
    def inequality(term, name):
        # Enumerate the upper triangle instead of using the closed index formula.
        monomials = [(i,) for i in range(54)]
        monomials += [(i,j) for i in range(54) for j in range(i,54)]
        columns = {m: k for k, m in enumerate(monomials)}
        return tuple(sorted((columns[m], c) for m, c in term.items() if m and c)), -term.get((), F(0)), name


class LiteralLift:
    """Producer API supplied by independent literal polynomial multiplication."""
    @staticmethod
    def delta(i, j, axis):
        return {2*j+axis: F(1), 2*i+axis: F(-1)}

    @staticmethod
    def multiply(co, left, right, scale=1):
        for i, a in left.items():
            for j, b in right.items():
                monomial = tuple(sorted((i,j)))
                co[monomial] = co.get(monomial, F(0)) + scale*a*b

    @staticmethod
    def clean(co, rhs, name):
        poly = dict(co)
        poly[()] = -F(rhs)
        return Polynomial.inequality(poly, name)


P = Polynomial


def center_energy(triple):
    # E = 3 sum |center|^2 - |sum center|^2.
    energy = {}
    for axis in (0,1):
        coordinates = [P.variable(2*i+axis) for i in triple]
        total = P.combine(*coordinates)
        energy = P.minus(energy, P.product(total,total))
        for coordinate in coordinates:
            energy = P.combine(energy, P.times_constant(P.product(coordinate,coordinate),3))
    return energy


def secant_identity(name, differences, diagonal):
    fields = name.split('_')
    triple = tuple(map(int, fields[4:7]))
    poly = P.minus(P.number(F(7,2)), center_energy(triple))
    for (i,j), code in zip(combinations(triple,2), fields[7]):
        dx = P.minus(P.variable(2*j),P.variable(2*i))
        dy = P.minus(P.variable(2*j+1),P.variable(2*i+1))
        if code == '0':
            projections, bounds, weight = (dx,dy), differences[i,j], F(1)
        else:
            assert code == '1'
            projections, bounds, weight = (P.combine(dx,dy),P.minus(dx,dy)), diagonal[i,j], F(1,2)
        for projection, (lo,hi) in zip(projections,bounds):
            product_poly = P.product(P.minus(projection,P.number(lo)),P.minus(projection,P.number(hi)))
            poly = P.combine(poly,P.times_constant(product_poly,weight))
    assert all(len(m)<=1 for m in poly), 'A quadratic term failed to cancel.'
    return P.inequality(poly,name)


def expected_names(diagonal, mixed):
    result = []
    for triple in combinations(range(9),3):
        pairs = tuple(combinations(triple,2))
        options = [(0,1) if mixed and pair in diagonal else (0,) for pair in pairs]
        for codes in product(*options):
            result.append('three_square_center_energy_'+'_'.join(map(str,triple))+'_'+''.join(map(str,codes)))
    return result


def main():
    assert __debug__
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--producer',type=Path,required=True)
    parser.add_argument('--fixture',type=Path,default=HERE/'THREE_SQUARE_ROW_REPLAY_FIXTURE.json')
    parser.add_argument('--lift',type=Path)
    parser.add_argument('--report',type=Path,default=HERE/'THREE_SQUARE_ENERGY_ROW_REPLAY.json')
    args = parser.parse_args()
    source_paths = [args.producer,args.fixture,Path(R.__file__),Path(__file__)]
    if args.lift:source_paths.append(args.lift)
    hashes = {str(p.resolve()):digest(p) for p in source_paths}
    producer = load(args.producer,'triple_energy_producer_under_review')
    fixture = json.loads(args.fixture.read_text())
    assert fixture['schema']=='three_square_energy_row_algebra_fixture_v1'
    read = lambda rows: {tuple(row['pair']):tuple(tuple(map(F,box)) for box in row['intervals']) for row in rows}
    differences, diagonal = read(fixture['differences']),read(fixture['diagonal'])
    all_pairs = tuple(combinations(range(9),2))
    assert set(differences)==set(diagonal)==set(all_pairs)
    partial = {pair:diagonal[pair] for n,pair in enumerate(all_pairs) if n%3==0}
    # Degenerate and asymmetric rational ranges exercise zero coefficients,
    # both signs, and the half-weighted mixed-diagonal constants.
    synthetic, synthetic_diagonal = {},{}
    for n,pair in enumerate(all_pairs):
        lo = F(n-19,17)
        synthetic[pair] = ((lo,lo+F(n%4,13)),(-lo-F(2,7),-lo+F(n%5,11)))
        a = F(11-n,23)
        synthetic_diagonal[pair] = ((a,a+F(n%3,19)),(-a-F(3,5),-a+F(n%4,29)))
    cases = [
        ('Cartesian',differences,{},True),
        ('All Cartesian/diagonal codes',differences,diagonal,True),
        ('Diagonal present but combinations disabled',differences,diagonal,False),
        ('Partial diagonal availability',differences,partial,True),
        ('Rational asymmetric and degenerate intervals',synthetic,synthetic_diagonal,True),
    ]
    reports=[]
    for label, dd, dg, mixed in cases:
        rows = producer.linear_rows(dd,dg,all_combinations=mixed)
        assert [row[2] for row in rows]==expected_names(dg,mixed)
        for row in rows:
            name = row[2]
            assert row==R.linear_row(name,dd,dg), ('helper mismatch',label,name)
            assert row==secant_identity(name,dd,dg), ('secant polynomial mismatch',label,name)
        reports.append(dict(case=label,rows_checked=len(rows),full_original_polynomial_identities=True))
    moment_names = ['three_square_center_energy_moment_'+'_'.join(map(str,triple)) for triple in combinations(range(9),3)]
    expected = [R.moment_row(name) for name in moment_names]
    assert producer.moment_rows(LiteralLift)==expected
    for name,row in zip(moment_names,expected):
        assert row==R.moment_polynomial(name,P)
        triple=tuple(map(int,name.split('_')[-3:]))
        assert row==P.inequality(P.minus(P.number(F(7,2)),center_energy(triple)),name)
    reports.append(dict(case='Moment centroid identity and independent monomial enumeration',rows_checked=84))
    actual_lift_rows=0
    if args.lift:
        lift=load(args.lift,'actual_existing_moment_lift_under_review')
        assert lift.N==54 and lift.SIZE==1539
        assert producer.moment_rows(lift)==expected
        actual_lift_rows=84
        reports.append(dict(case='Actual existing moment-lift implementation',rows_checked=84))
    for path,sha in hashes.items():assert digest(path)==sha
    answer=dict(schema='independent_three_square_energy_row_expansion_replay_v1',
        status='PASS_ALL_EXACT_ROW_IDENTITIES',geometric_lower_bound='7/2',
        source_sha256=hashes,cases=reports,total_rows_checked=sum(x['rows_checked']for x in reports),
        affine_helper='linear_row(name, differences, diagonal=None)',
        lifted_helper='moment_row(name)',polynomial_adapter='moment_polynomial(name, independent_polynomial_module)',
        all_affine_rows_checked_against_theorem_plus_secant_products=True,
        all_quadratic_terms_cancel_in_affine_identity=True,
        actual_existing_lift_rows_checked=actual_lift_rows,
        original_variables=54,moment_variables=1539,
        pairwise_square_interior_disjointness_required=True,
        supplied_interval_guards_must_be_independently_proved_by_caller=True,
        fixture_original_ancestry_replayed=False,whole_original_cover_checked=False,
        numerical_optimizer_imported=False,new_original_cells=0,new_masks=0,lean_lake_ci_run=False)
    args.report.write_text(json.dumps(answer,indent=2)+'\n')
    print(json.dumps(answer,indent=2))


if __name__=='__main__':main()
