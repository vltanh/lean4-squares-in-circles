"""Independent reconstruction of the three-physical-square energy rows.

Premise: the three selected retained unit squares have disjoint interiors.
The reviewed geometric theorem gives their center energy at least 7/2.
For affine rows, every Cartesian or diagonal interval must already be
certified for the same original caller. This module proves no such guard.
It imports no row producer, numerical solver, or saved numerical model.
"""
from fractions import Fraction as F
from itertools import combinations

N = 54
SIZE = N + N*(N+1)//2
LOWER = F(7, 2)
PREFIX = 'three_square_center_energy_'
MOMENT_PREFIX = PREFIX + 'moment_'


def selected(values):
    result = tuple(map(int, values))
    assert len(result) == 3 and tuple(sorted(set(result))) == result
    assert all(0 <= i < 9 for i in result)
    return result


def interval(values):
    assert len(values) == 2
    lo, hi = map(F, values)
    assert lo <= hi
    return lo, hi


def linear_row(name, differences, diagonal=None):
    """Rebuild one named <= row on certified original difference intervals."""
    fields = name.split('_')
    assert fields[:4] == ['three', 'square', 'center', 'energy']
    assert len(fields) == 8 and fields[4] != 'moment'
    triple = selected(fields[4:7])
    codes = fields[7]
    assert len(codes) == 3 and set(codes) <= {'0', '1'}
    diagonal = diagonal or {}
    co = [F(0)]*18
    rhs = -LOWER
    for (i, j), code in zip(combinations(triple, 2), codes):
        source = diagonal[i, j] if code == '1' else differences[i, j]
        assert len(source) == 2
        (a, b), (c, d) = map(interval, source)
        if code == '1':
            # Half the sum of the dx+dy and dx-dy secants.
            wx, wy = (a+b+c+d)/2, (a+b-c-d)/2
            constant = (a*b+c*d)/2
        else:
            wx, wy = a+b, c+d
            constant = a*b+c*d
        co[2*i] += wx
        co[2*j] -= wx
        co[2*i+1] += wy
        co[2*j+1] -= wy
        rhs -= constant
    return tuple((k, v) for k, v in enumerate(co) if v), rhs, name


def monomial_index(i, j):
    assert type(i) is int and type(j) is int and 0 <= i <= j < N
    return N + i*N - i*(i-1)//2 + j-i


def moment_row(name):
    """Rebuild in the standard 54 + upper-triangular 1485-monomial lift."""
    assert name.startswith(MOMENT_PREFIX)
    triple = selected(name[len(MOMENT_PREFIX):].split('_'))
    co = {}
    # The centroid identity gives -E = |sum c_i|^2 - 3 sum |c_i|^2.
    # Thus every diagonal coefficient is -2 and every within-axis cross
    # coefficient is +2, independently of a pair-difference implementation.
    for axis in (0, 1):
        for i in triple:
            index = 2*i+axis
            co[monomial_index(index, index)] = F(-2)
        for i, j in combinations(triple, 2):
            co[monomial_index(2*i+axis, 2*j+axis)] = F(2)
    return tuple(sorted(co.items())), -LOWER, name


def moment_polynomial(name, independent_polynomial_module):
    """Adapter for the existing independent_moment_rows polynomial API."""
    assert name.startswith(MOMENT_PREFIX)
    triple = selected(name[len(MOMENT_PREFIX):].split('_'))
    I = independent_polynomial_module
    assert I.N == N and I.SIZE == SIZE
    poly = I.number(LOWER)
    for axis in (0, 1):
        coordinates = [I.variable(2*i+axis) for i in triple]
        total = I.combine(*coordinates)
        poly = I.combine(poly, I.product(total, total))
        for coordinate in coordinates:
            poly = I.minus(poly, I.times_constant(I.product(coordinate, coordinate), 3))
    return I.inequality(poly, name)


rebuild_affine = linear_row
rebuild_moment = moment_row
