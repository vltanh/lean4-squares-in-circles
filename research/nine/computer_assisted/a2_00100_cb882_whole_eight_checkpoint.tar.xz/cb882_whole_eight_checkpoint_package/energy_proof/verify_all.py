"""Portable replay of the geometric premise and exact energy row algebra."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
digest=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    assert __debug__
    started=time.monotonic()
    manifest_bytes=(HERE/'SHA256_MANIFEST.json').read_bytes()
    manifest=json.loads(manifest_bytes)
    def unchanged():
        assert (HERE/'SHA256_MANIFEST.json').read_bytes()==manifest_bytes
        for name,value in manifest['files'].items():
            path=(HERE/name).resolve()
            assert path.is_relative_to(HERE) and digest(path)==value,name
    unchanged()
    invocations=[
        ('THEOREM_REPLAY.log',[sys.executable,'-B','-S',str(HERE/'theorem/verify_all.py')]),
        ('ROW_ALGEBRA_REPLAY.log',[sys.executable,'-B','-S',str(HERE/'check_three_square_energy_rows.py'),
            '--producer',str(HERE/'three_square_energy_rows.py'),
            '--fixture',str(HERE/'THREE_SQUARE_ROW_REPLAY_FIXTURE.json'),
            '--lift',str(HERE/'quadratic_moment_rows.py'),
            '--report',str(HERE/'ROOT_ROW_REPLAY.json')]),
    ]
    for logfile,args in invocations:
        with (HERE/logfile).open('w')as output:
            subprocess.run(args,cwd=HERE,stdout=output,stderr=subprocess.STDOUT,check=True)
    theorem=json.loads((HERE/'theorem/COMPLETE_REPLAY.json').read_text())
    assert theorem['status']=='PASS_SHARED_THREE_SQUARE_ENERGY_THEOREM'
    assert theorem['new_original_cells']==theorem['new_masks']==0
    assert theorem['independent_exact_evaluators']==2
    row=json.loads((HERE/'ROOT_ROW_REPLAY.json').read_text())
    accepted=json.loads((HERE/'ACCEPTED_ROW_REPLAY.json').read_text())
    expected_sources={Path(name).name:value for name,value in accepted['source_sha256'].items()}
    assert len(expected_sources)==len(accepted['source_sha256'])==5
    actual_sources={str(Path(name).resolve().relative_to(HERE)):value for name,value in row['source_sha256'].items()}
    assert expected_sources==actual_sources
    for name,value in actual_sources.items():assert manifest['files'][name]==value
    assert {k:v for k,v in row.items()if k!='source_sha256'}=={k:v for k,v in accepted.items()if k!='source_sha256'}
    assert row['status']=='PASS_ALL_EXACT_ROW_IDENTITIES' and row['total_rows_checked']==1877
    assert row['all_quadratic_terms_cancel_in_affine_identity']
    assert row['new_original_cells']==row['new_masks']==0
    unchanged()
    outputs=['ROOT_ROW_REPLAY.json','theorem/COMPLETE_REPLAY.json','theorem/ROOT_EXACT_REPLAY.json',
        'theorem/a_family/THREE_SQUARE_CENTER_ENERGY_INDEPENDENT_REVIEW.json']
    report=dict(schema='shared_three_square_energy_rows_complete_packet_replay_v1',
        status='PASS_SHARED_THREE_SQUARE_ENERGY_ROWS',energy_lower_bound='7/2',
        exact_geometric_evaluators=2,geometric_angular_triangles=128,
        row_identities_checked=1877,original_variables=54,moment_variables=1539,
        caller_must_prove_all_original_interval_guards=True,
        caller_must_retain_original_physical_square_nonoverlap=True,
        coefficient_audit_imports_untrusted_producer_for_comparison=True,
        reusable_independent_helper_imports_no_producer_or_optimizer=True,
        all_mathematical_inputs_confined_to_packet=True,
        all_frozen_inputs_checked_before_and_after=True,frozen_inputs=len(manifest['files']),
        source_manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
        archived_replay_outputs={name:digest(HERE/name)for name in outputs},
        new_original_cells=0,new_masks=0,whole_mask_closed=False,lean_lake_ci_run=False,
        seconds=time.monotonic()-started)
    (HERE/'COMPLETE_REPLAY.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
