# Exact physical separating-axis covers and bound induction

This note explains `independent_physical_sat_replay.py`. It is a checker for
finite, explicitly printed deductions from an already certified physical
state. The geometry adapter reconstructs every necessary inequality, every
absolute variable bound, and the inherited unit-frame implications. The core
imports only Python's standard library and performs rational arithmetic.
Neither numerical feasibility nor a numerical primal point is proof evidence.

## 1. The physical state

A state retains the original cell identifier and its complete caller path,
nine original slope intervals, eighteen original center-coordinate intervals,
the thirty-six original frame-scalar intervals, and the certified pairwise
coordinate-difference intervals. It may additionally retain certified diagonal
difference intervals. Existing frame labels, all physical corners, all original
pair conditions, and all closed boundary faces belong to the adapter's
inherited geometric reconstruction. Appending a physical separation choice
does not replace any original frame or omit any inherited condition.

The fifty-four original variables consist of eighteen coordinates and four
nine-element frame-scalar families. A selected physical separating-axis case
may introduce additional product auxiliaries; their defining necessary rows
and absolute bounds must also be independently reconstructed. They do not
represent new squares or new freely selected frames.

## 2. A rational weighted bound

Suppose the reconstructed rows are

\[
 a_r\mathbin{\cdot}z\le b_r,\qquad |z_j|\le M_j,
\]

where every entry is rational and every \(M_j\ge0\). A certificate specifies
positive integer weights \(w_r\), interpreted as
\(\lambda_r=w_r/2^{40}\). Thus

\[
 c=\sum_r\lambda_r a_r,\qquad b=\sum_r\lambda_r b_r,
 \qquad c\mathbin{\cdot}z\le b.
\]

For a requested objective vector \(q\), put \(e=c-q\). Then

\[
 q\mathbin{\cdot}z
 =c\mathbin{\cdot}z-e\mathbin{\cdot}z
 \le b+\sum_j M_j|e_j|.
\]

The checker independently sums the printed rows, verifies the residual vector,
computes the full absolute-error payment, and checks the exact upward rounding
to the \(2^{-20}\) grid. No tolerance is used in any proof comparison. The
allowed objectives are one signed original scalar or one signed original
coordinate difference; their printed coefficient lists are checked exactly.

All deductions in a round use the same predecessor state. Their conclusions
are intersected simultaneously with the independently propagated intervals.
Only after this step are the inherited physical unit-frame identities used to
refine the original slope intervals. Analytic scalar bounds are then
intersected again. Consequently a round never uses its own unproved conclusion
as a premise. Optional diagonal intervals are retained across the round; the
adapter may recompute their justified intersection during the next rebuild.

## 3. A rational contradiction

For the same positive combination, the absolute bounds also give

\[
 c\mathbin{\cdot}z\ge-\sum_jM_j|c_j|.
\]

If the exactly computed reserve

\[
 \rho=-b-\sum_jM_j|c_j|>0,
\]

the two inequalities contradict each other. The checker verifies every printed
coefficient, the summed right-hand side, and the strictly positive reserve.
An empty certified interval or an independently reconstructed physical
unit-frame contradiction is another valid terminal. Unrecognized terminal
labels are rejected by the geometry adapter.

## 4. Complete physical separating-axis cover

For two closed convex squares whose interiors are disjoint, the planar
separating-axis theorem supplies a separating direction normal to an edge of
one of the two squares. Each square supplies two perpendicular axis directions;
each axis has two signs. Therefore the eight original alternatives are

\[
 (\text{owner},\text{axis},\text{sign})
 \in\{i,j\}\times\{0,1\}\times\{-1,1\}.
\]

The row reconstruction uses the original physical frame of the selected owner.
Equality is permitted, so side contacts, vertex contacts, coincident boundary
projections, and interval endpoints are retained. These alternatives may
overlap; disjointness of the alternatives is unnecessary. Every admissible
physical pair satisfies at least one alternative.

`sat_child` appends exactly one of these choices and reconstructs the caller
choices while retaining every certified parent bound. `check_complete_cover`
requires exactly eight distinct choices with precisely this Cartesian product.
If all eight independently replayed child domains are excluded, their union
excludes the parent. A missing child or a duplicated alternative cannot yield a
complete-cover conclusion. A finite tree follows by induction from its leaves:
each internal node requires a complete cover of its certified final state.

## 5. Adapter contract and conclusion scope

The core API is:

```python
audit, final_state = check_record(record, initial_state, adapter)
audit, open_states = check_complete_cover(parent, pair, children, adapter)
```

Here `children` is a list of `(choice, record)` pairs. `final_state` is `None`
only when the input physical domain is excluded. The adapter provides:

* `rebuild(state, printed_rows)`: independently validated rows indexed by their
  printed integer indices, exact absolute variable bounds, and the physically
  propagated state;
* `infer_angles(angles, scalar)`: exact unit-frame consequences, including their
  independently checked identities or a proved contradiction;
* `analytic(angles)`: the inherited thirty-six analytic scalar intervals;
* `choices(path)`: the complete original caller-path reconstruction;
* `verify_early_terminal(state, terminal)`: an independently proved exact
  physical interval contradiction, if one exists.

The core checks row-literal equality as well as the adapter's conclusion. Every
used multiplier index must name a validated printed row, and every printed row
must be used. It rejects altered absolute bounds, altered after-states,
negative multipliers, and mismatched physical child paths. Numerical points,
LP phases, search order, timings, and solver diagnostics are ignored.

The initial state must itself be independently replayed from the original
caller, and an original-cell conclusion requires a complete cover of that
original domain. A successful local state, local separation case, or partial
cover receives no original-cell or mask credit. The supplied B adapter replays
its original ancestor, fixed center rectangles, and slope restriction before
the new deductions. The D and C families can supply their own independently
reconstructed geometry through the same arithmetic interface.
