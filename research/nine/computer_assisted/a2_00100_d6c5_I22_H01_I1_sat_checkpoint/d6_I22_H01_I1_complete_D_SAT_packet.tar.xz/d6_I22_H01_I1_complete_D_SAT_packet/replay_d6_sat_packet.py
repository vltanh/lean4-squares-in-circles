#!/usr/bin/env python3
"""Portable exact replay of a complete D-quarter union in a fixed I/H tile.

Only file-name resolution is extended. All older mathematical checker bytes
and all raw records remain unchanged and are authenticated before replay.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,importlib,json,sys,time

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--core',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path);args=ap.parse_args()
    root=Path(__file__).resolve().parent;core=args.core.resolve();started=time.monotonic()
    manifest=json.loads((root/'INPUT_MANIFEST.json').read_text())
    assert digest(core/'SHA256_MANIFEST.json')==manifest['core_manifest_sha256']
    core_manifest=json.loads((core/'SHA256_MANIFEST.json').read_text())
    for name,h in core_manifest['files'].items():assert digest(core/name)==h,('changed frozen core',name)
    for name,h in manifest['files'].items():assert digest(root/name)==h,('changed packet input',name)
    bindings=json.loads((root/'BINDINGS.json').read_text());located={}
    for name,entry in bindings.items():
        base=core if entry['root']=='core'else root
        assert entry['root']in('core','packet')
        target=(base/entry['path']).resolve();assert target.is_relative_to(base)
        assert digest(target)==entry['sha256'];located[name]=target
    common=Path(__import__('os').path.commonpath((str(root),str(core)))).resolve()
    assert str(common)not in('/','/workspace','/workspace/scratch'),'Use a dedicated common replay directory.'
    def audit(event,values):
        if event=='open'and isinstance(values[0],str):
            p=Path(values[0])
            if p.is_absolute()and str(p).startswith('/workspace/'):
                assert p.is_relative_to(common),('external workspace read forbidden',str(p))
    sys.addaudithook(audit)
    sys.path.insert(0,str(core));sys.path.insert(0,str(root))
    import replay_context
    frozen_install=replay_context.install
    def install(ancestry,allowed_root=None):
        joint,diagonal,original_locate=frozen_install(ancestry,allowed_root)
        def locate(name):
            if str(Path(name))in located:return located[str(Path(name))]
            return original_locate(name)
        return joint,diagonal,locate
    replay_context.install=install
    import verify_coupled_d6
    verify_coupled_d6.CORE=core
    import verify_d_sat_tree
    verify_d_sat_tree.CORE=core
    checker=verify_coupled_d6.Checker(context=core,ancestry=core/'ancestry')
    cover=json.loads((root/'D_QUARTER_COVER.json').read_text())
    original_parent=located[cover['parent']['path']]
    assert digest(original_parent)==cover['parent']['sha256']
    parent_report,parent,diagonal=checker.replay(original_parent,allow_open=True,return_state=True)
    assert parent['id']==cover['original_id'] and cover['split_original']==3 and cover['parts']==4
    lo,hi=parent['angles'][3];assert lo<hi
    assert cover['parent_interval']==[str(lo),str(hi)]
    indices=[c['index']for c in cover['components']];assert sorted(indices)==list(range(4))
    args.output.mkdir(parents=True,exist_ok=True);reports=[]
    for component in sorted(cover['components'],key=lambda x:x['index']):
        index=component['index'];parent_path=root/component['bound_record']
        literal=json.loads(parent_path.read_text());restriction=literal['slope_restriction']
        interval=[str(lo+(hi-lo)*F(index,4)),str(lo+(hi-lo)*F(index+1,4))]
        assert restriction['original']==3 and restriction['parts']==4 and restriction['index']==index
        assert restriction['parent']==cover['parent'] and restriction['interval']==interval
        assert restriction['parent_interval']==cover['parent_interval']
        assert literal['id']==parent['id'] and literal['path']==parent['path']
        dest=args.output/f'D{index}_EXACT_REPLAY.json'
        verify_d_sat_tree.replay(parent_path,root/component['tree'],dest)
        report=json.loads(dest.read_text());assert report['status']=='PASS_COMPLETE_RESTRICTED_PHYSICAL_DOMAIN'
        reports.append(dict(index=index,interval=interval,report_sha256=digest(dest),report=report))
    for name,h in manifest['files'].items():assert digest(root/name)==h
    for name,h in core_manifest['files'].items():assert digest(core/name)==h
    result=dict(schema='independent_D6_fixed_IH_I_slope_complete_D_four_union_v1',
        status='PASS_COMPLETE_DECLARED_INHERITED_I_SLOPE_DOMAIN',original_id=parent['id'],
        original_parent_replay=parent_report,split_original=3,parts=4,parent_interval=cover['parent_interval'],
        all_closed_quarters_checked=True,all_shared_faces_retained=True,
        nodes=sum(r['report']['nodes']for r in reports),sat_eight_covers=sum(r['report']['complete_eight_covers']for r in reports),
        terminal_leaves=sum(r['report']['leaf_domains']for r in reports),
        sat_rounds=sum(r['report']['rounds']for r in reports),sat_deductions=sum(r['report']['deductions']for r in reports),
        sat_printed_rows=sum(r['report']['printed_rows_checked']for r in reports),components=reports,
        input_manifest_sha256=digest(root/'INPUT_MANIFEST.json'),core_manifest_sha256=manifest['core_manifest_sha256'],
        all_frozen_inputs_unchanged=True,external_old_workspace_reads_forbidden=True,
        new_original_cells=0,new_masks=0,seconds=time.monotonic()-started)
    (args.output/'COMPLETE_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in ('status','nodes','sat_eight_covers','terminal_leaves','sat_rounds','sat_deductions','sat_printed_rows','seconds')}),flush=True)

if __name__=='__main__':main()
