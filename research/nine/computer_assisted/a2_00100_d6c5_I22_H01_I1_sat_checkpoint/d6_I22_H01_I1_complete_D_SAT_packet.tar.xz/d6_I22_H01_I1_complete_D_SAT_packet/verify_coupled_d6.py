"""Replay D6 slope induction with independently validated coupled energy rows.

The inherited checker reconstructs the original caller, every ancestor,
every ordinary row and all rational weighted deductions. This extension
validates only the new coupled-energy rows by their literal coefficients,
using a separate polygon clipping proof and the accepted 7/2 theorem.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import argparse,json,sys,time

HERE=Path(__file__).resolve().parent
CORE=HERE/'i23/d6c5_I23_H_supplement_v3/core'
sys.path.insert(0,str(CORE))
import verify_d6c5_continued_derived_H_slope_bounds as BASE
sys.path.insert(0,str(HERE))
import independent_coupled_three_square_energy as COUPLED

class Checker(BASE.Checker):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.coupled_occurrences=0

    def printed_rows(self,saved,total,base,bounds,scalar,diff,diagonal,angles):
        indices=[r['index'] for r in saved]
        assert len(indices)==len(set(indices))
        ordinary=[r for r in saved if not r['name'].startswith('coupled_three_')]
        coupled=[r for r in saved if r['name'].startswith('coupled_three_')]
        rows,names=super().printed_rows(ordinary,total,base,bounds,scalar,diff,diagonal,angles)
        rows.extend([((),F(0),'UNUSED_UNVERIFIED')]*max(0,max(indices,default=-1)+1-len(rows)))
        for r in coupled:
            k=r['index'];assert type(k)is int and len(base)<=k<total
            row=(tuple((i,F(v)) for i,v in r['coefficients']),F(r['rhs']),r['name'])
            COUPLED.verify_literal(row,diff,diagonal)
            rows[k]=row;names.append(r['name']);self.coupled_occurrences+=1
        return rows,names

def main():
    ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('output',type=Path)
    args=ap.parse_args();start=time.monotonic()
    checker=Checker(context=CORE,ancestry=CORE/'ancestry')
    result=checker.replay(args.certificate,allow_open=True)
    result['coupled_energy_extension']={
        'literal_row_occurrences_checked':checker.coupled_occurrences,
        'independent_intercept_maxima':True,
        'source_sha256':{str(p):sha256(p.read_bytes()).hexdigest() for p in (Path(__file__).resolve(),Path(COUPLED.__file__).resolve())},
        'whole_original_credit':0,'whole_mask_credit':0}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'coupled_occurrences':checker.coupled_occurrences,'seconds':time.monotonic()-start}),flush=True)

if __name__=='__main__':main()
