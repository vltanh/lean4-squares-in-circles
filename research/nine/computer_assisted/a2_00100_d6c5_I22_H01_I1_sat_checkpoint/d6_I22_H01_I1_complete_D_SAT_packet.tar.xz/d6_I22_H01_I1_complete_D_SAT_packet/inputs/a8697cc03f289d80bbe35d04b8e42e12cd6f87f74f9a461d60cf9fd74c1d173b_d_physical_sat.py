"""D6 discovery: complete original separating-axis choices, no closure claim."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
import argparse,json,time
from d_runtime import M,D,C,FC,AREA,TE,QM,relocation
import coupled_three_square_energy_v2 as CT
import physical_sat_engine_snapshot as E

def stateview(state):
    return dict(id=state['id'],path=state['path'],angles=E.view(state['angles']),
        positions=E.view(state['positions']),scalar=E.view(state['scalar']),
        differences=E.diffview(state['differences']),diagonal=E.diffview(state['diagonal']))
E.stateview=stateview

class Context:
    K=M.K;V=M.V;R=M.R
    def child(self,parent,pair,choice):
        path=deepcopy(parent['path'])+[['sat',list(pair),list(choice)]]
        return dict(deepcopy(parent),path=path,choices=self.V.reconstruct(path)[2])
    def collect(self,state):
        rows,ab,term,pos,sc,diff,guards=M.collect(state,state['differences'])
        if term:return None,None,None,dict(kind='accepted_interval_terminal',label=term)
        diag=D.effective(diff,state['diagonal'])
        if any(a>b for ds in diag.values() for a,b in ds):
            return None,None,None,dict(kind='empty_correlated_diagonal')
        rows+=D.rows(sc,diff,diag)
        extra,guards=C.generate_rows(diff,diag);rows+=extra
        rows+=FC.linear_rows(diff,diag)+AREA.generate_linear(diff)+TE.linear_rows(diff,diag)
        extra,guards=CT.rows(diff,diag);rows+=extra
        return rows,ab,dict(state,positions=pos,scalar=sc,differences=diff,diagonal=diag),None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('parent',type=Path);ap.add_argument('output',type=Path)
    ap.add_argument('--pair',type=int,nargs=2,default=[5,8]);ap.add_argument('--rounds',type=int,default=0)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    state,diff,diag,binding=QM.read_prefix(args.parent)
    state.update(differences=diff,diagonal=diag);ctx=Context();children=[]
    for owner,axis,sign in product(args.pair,(0,1),(-1,1)):
        choice=(owner,axis,sign);child=ctx.child(state,args.pair,choice)
        record,_,_=E.search_node(ctx,child,args.rounds)
        dest=args.output/f'child_{owner}_{axis}_{sign}.json';assert not dest.exists()
        record.update(parent=binding,no_original_cell_or_mask_credit=True,acceptance='INDEPENDENT_REPLAY_PENDING')
        dest.write_text(json.dumps(record,indent=2)+'\n')
        result=dict(choice=list(choice),path=str(dest),sha256=E.sha(dest),status=record['status'],seconds=record['seconds'],phase=record.get('phase'))
        children.append(result);print(json.dumps(result),flush=True)
    (args.output/'cover.json').write_text(json.dumps(dict(parent=binding,pair=args.pair,children=children,complete_alternatives=True),indent=2)+'\n')
if __name__=='__main__':main()
