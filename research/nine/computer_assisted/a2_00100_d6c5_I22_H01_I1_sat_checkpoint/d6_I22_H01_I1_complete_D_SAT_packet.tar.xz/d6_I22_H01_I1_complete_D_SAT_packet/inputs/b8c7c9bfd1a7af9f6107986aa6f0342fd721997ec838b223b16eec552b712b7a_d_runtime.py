"""Relocate published, byte-verified discovery sources without editing them."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import sys

HERE=Path(__file__).resolve().parent
CORE=HERE/'i23/d6c5_I23_H_supplement_v3/core'
def digest(path): return sha256(Path(path).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    ans=importlib.util.module_from_spec(spec);sys.modules[name]=ans;spec.loader.exec_module(ans)
    return ans
PORT=module('portable_frozen_discovery_loader',next((CORE/'ancestry/exact_extension_provenance').glob('*_portable_frozen_discovery_loader.py')))
relocation=PORT.install(CORE,digest(CORE/'SHA256_MANIFEST.json'))
for p in (CORE/'ancestry/cd_family',CORE/'ancestry/new_producers',CORE/'energy_proof'):
    sys.path.insert(0,str(p))
import v3_whole_parent_pass as M
PORT.check_engine(M)
import diagonal_rows as D
import quadratic_moment_pilot as QM
import correlated_capacity_rows as C
import four_center_rows as FC
import square_area_moment_rows as AREA
import three_square_energy_rows as TE
FAST=module('active_highs_checked_warning_discovery',next((CORE/'ancestry/dc71_provenance').glob('*_active_highs_checked_warning_discovery.py')))
FAST.install(M)
relocation['source_sha256'][str(Path(__file__).resolve())]=digest(__file__)
