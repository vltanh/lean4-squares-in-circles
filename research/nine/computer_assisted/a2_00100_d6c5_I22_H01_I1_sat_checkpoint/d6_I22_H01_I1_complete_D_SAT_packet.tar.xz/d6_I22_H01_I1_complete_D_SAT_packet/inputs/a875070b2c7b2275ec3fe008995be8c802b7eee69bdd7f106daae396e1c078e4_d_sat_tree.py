"""Complete eight-way physical separation discovery, with immutable node records.

This file deliberately makes no accepted closure claim; replay is separate.
"""
from d_physical_sat import Context,E,QM,CT,stateview
from d_runtime import FAST
from pathlib import Path
from itertools import product
import argparse,json,time,hashlib

Context.AH=FAST
E.ACTIVE=FAST

def main():
    ap=argparse.ArgumentParser();ap.add_argument('parent',type=Path);ap.add_argument('output',type=Path)
    ap.add_argument('--max-depth',type=int,default=3);ap.add_argument('--rounds',type=int,default=1)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    state,diff,diag,binding=QM.read_prefix(args.parent)
    state.update(differences=diff,diagonal=diag);context=Context();nodes=[];start=time.monotonic()
    sources={str(p.resolve()):E.sha(p)for p in [Path(__file__),Path(E.__file__),Path(CT.__file__)]}
    def visit(state,depth,parent=None,choice=None):
        number=len(nodes);node=dict(index=number,depth=depth,parent=parent,choice=choice,
            initial=stateview(state),status='RUNNING',children=[])
        nodes.append(node);dest=args.output/f'node_{number:04d}.json'
        def write(record):
            dest.write_text(json.dumps(dict(node,record=record),indent=2)+'\n')
        rounds=0 if depth==0 else args.rounds
        record,after,point=E.search_node(context,state,rounds,checkpoint=write)
        node['record']=record;node['status']=record['status'];write(record)
        print('NODE',number,depth,record['status'],record.get('best_pairs',[])[:2],round(time.monotonic()-start,2),flush=True)
        if record['status']!='OPEN' or depth>=args.max_depth:return number
        pair=tuple(record['best_pairs'][0][1]);node['split_pair']=list(pair)
        for owner,axis,sign in product(pair,(0,1),(-1,1)):
            chosen=[owner,axis,sign]
            child=context.child(after,pair,chosen)
            ci=visit(child,depth+1,number,chosen);node['children'].append(ci)
            write(record)
        node['complete_eight_children']=True
        if all(nodes[i]['status'] in ('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for i in node['children']):
            node['status']='CANDIDATE_COVER_CLOSED'
        write(record);return number
    visit(state,0)
    manifest=dict(schema='D6_original_physical_sat_complete_eight_tree_discovery_v1',parent=binding,
        source_sha256=sources,status=nodes[0]['status'],nodes=[dict(index=n['index'],file=f'node_{n["index"]:04d}.json',
            sha256=E.sha(args.output/f'node_{n["index"]:04d}.json'),status=n['status'],depth=n['depth'])for n in nodes],
        seconds=time.monotonic()-start,independent_replay_pending=True,new_original_cells=0,new_masks=0)
    (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('TREE_RESULT',manifest['status'],len(nodes),'seconds',manifest['seconds'],flush=True)

if __name__=='__main__':main()
