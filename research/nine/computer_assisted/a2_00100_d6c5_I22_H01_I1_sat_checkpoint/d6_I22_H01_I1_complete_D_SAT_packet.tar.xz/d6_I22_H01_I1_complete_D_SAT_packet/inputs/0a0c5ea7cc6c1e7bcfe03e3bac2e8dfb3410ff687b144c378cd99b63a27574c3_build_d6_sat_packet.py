from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import hashlib,json,shutil

HERE=Path(__file__).resolve().parent
CORE=HERE/'i23/d6c5_I23_H_supplement_v3/core'
OUT=HERE/'d6_I22_H01_I1_complete_D_SAT_packet'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,o):p.write_text(json.dumps(o,indent=2)+'\n')

def main():
    OUT.mkdir(exist_ok=False);(OUT/'inputs').mkdir();(OUT/'original_audits').mkdir()
    bindings={};reports=[];components=[];all_rows=Counter()
    def bind(name,h):
        p=Path(name);assert sha(p)==h
        if p.is_relative_to(CORE):entry=dict(root='core',path=str(p.relative_to(CORE)),sha256=h)
        else:
            target=OUT/'inputs'/f'{h}_{p.name}'
            if not target.exists():shutil.copy2(p,target)
            entry=dict(root='packet',path=str(target.relative_to(OUT)),sha256=h)
        assert name not in bindings or bindings[name]==entry
        bindings[name]=entry;return entry
    for index in range(4):
        report_path=HERE/f'SAT_TREE_H01_I1_D{index}_EXACT_REPLAY.json'
        report=json.loads(report_path.read_text());assert report['status']=='PASS_COMPLETE_RESTRICTED_PHYSICAL_DOMAIN'
        shutil.copy2(report_path,OUT/'original_audits'/f'D{index}.json');reports.append(report)
        for name,h in report['ancestor_replay']['source_sha256'].items():bind(name,h)
        tree=HERE/f'sat_tree_H01_I1_D{index}';m=json.loads((tree/'manifest.json').read_text())
        shutil.copytree(tree,OUT/f'tree_D{index}',ignore=shutil.ignore_patterns('__pycache__'))
        parent=Path(m['parent']['path']);entry=bind(str(parent),m['parent']['sha256'])
        assert entry['root']=='packet'
        record=json.loads(parent.read_text());restriction=record['slope_restriction']
        if index==0:cover=dict(original_id=record['id'],parent=restriction['parent'],split_original=3,
            parts=4,parent_interval=restriction['parent_interval'],components=components)
        assert restriction['parent']==cover['parent'] and restriction['index']==index
        components.append(dict(index=index,bound_record=entry['path'],tree=f'tree_D{index}',
            original_report_sha256=sha(report_path)))
        for node in m['nodes']:
            r=json.loads((tree/node['file']).read_text())['record']
            for rr in r['rounds']:
                for row in rr['printed_rows']:all_rows[row['name'].split('_')[0]]+=1
            if r.get('terminal',{}).get('kind')=='positive_exact_reserve':
                for row in r['terminal']['rows']:all_rows[row['name'].split('_')[0]]+=1
    bind(cover['parent']['path'],cover['parent']['sha256'])
    for name in ('d_physical_sat.py','d_sat_tree.py','physical_sat_engine_snapshot.py','build_d6_sat_packet.py'):
        bind(str(HERE/name),sha(HERE/name))
    for name in ('verify_coupled_d6.py','verify_d_sat_tree.py','independent_coupled_three_square_energy.py','replay_d6_sat_packet.py'):
        shutil.copy2(HERE/name,OUT/name)
    for name in ('independent_physical_sat_replay.py','PHYSICAL_SAT_REPLAY_HAND_PROOF.md'):
        shutil.copy2(HERE.parent/'b_work'/name,OUT/name)
    shutil.copy2(HERE.parent/'b_work/COUPLED_THREE_SQUARE_ENERGY_HAND_PROOF.md',OUT/'COUPLED_THREE_SQUARE_ENERGY_HAND_PROOF.md')
    write(OUT/'BINDINGS.json',bindings);write(OUT/'D_QUARTER_COVER.json',cover)
    summary=dict(nodes=sum(r['nodes']for r in reports),sat_eight_covers=sum(r['complete_eight_covers']for r in reports),
        terminal_leaves=sum(r['leaf_domains']for r in reports),sat_rounds=sum(r['rounds']for r in reports),
        sat_deductions=sum(r['deductions']for r in reports),sat_printed_rows=sum(r['printed_rows_checked']for r in reports),
        printed_row_family_counts=dict(all_rows),original_cells_closed=0,masks_closed=0)
    write(OUT/'COUNT_SUMMARY.json',summary)
    lines=['# Complete physical terminal table for I22 / H01 / I-slope quarter 1','',
        'D quarters cover [0,1] including all shared endpoints. SAT choices use original indices A=0 through I=8.',
        'Every positive reserve below is a proved dyadic lower bound for the exact reserve printed in the corresponding node record.',
        'The explicit tree files contain every multiplier, original physical row and complete eight-way child union.','',
        '| D quarter | Node | Parent | Choice (owner,axis,sign) | Rounds | Deductions | Rows | Conclusion |',
        '|---|---:|---:|---|---:|---:|---:|---|']
    for d,r in enumerate(reports):
        for a in r['audits']:
            if a['reserve'] is not None:
                value=F(a['reserve']);lower=F(1)
                while lower>value:lower/=2
                conclusion=f'reserve >= {lower}'
            elif a['terminal_kind']:conclusion=a['terminal_label']or a['terminal_kind']
            else:
                c=next(x for x in r['covers']if x['index']==a['index'])
                conclusion=f'complete eight-way cover of pair {c["pair"]}'
            lines.append(f'| {d} | {a["index"]} | {a["parent"]} | {a["choice"]} | {a["rounds"]} | {a["deductions"]} | {a["printed_rows_checked"]} | {conclusion} |')
    (OUT/'COMPLETE_TERMINAL_TABLE.md').write_text('\n'.join(lines)+'\n')
    write(OUT/'INPUT_MANIFEST.json',dict(schema='D6_fixed_IH_I_slope_complete_D_SAT_packet_v1',
        core_manifest_sha256=sha(CORE/'SHA256_MANIFEST.json'),core_input_count=len(json.loads((CORE/'SHA256_MANIFEST.json').read_text())['files']),
        required_ancestry_archive='d6c5_I23_H_supplement_v3.tar.xz',
        required_ancestry_archive_sha256='c58aedd5dd0d5efc3dbc0422703ced905f31667e77de303387ce4b377c34993d',
        files={str(p.relative_to(OUT)):sha(p)for p in sorted(OUT.rglob('*'))if p.is_file()},
        new_original_cells=0,new_masks=0))
    print(json.dumps(dict(packet=str(OUT),bindings=len(bindings),**summary)),flush=True)

if __name__=='__main__':main()
