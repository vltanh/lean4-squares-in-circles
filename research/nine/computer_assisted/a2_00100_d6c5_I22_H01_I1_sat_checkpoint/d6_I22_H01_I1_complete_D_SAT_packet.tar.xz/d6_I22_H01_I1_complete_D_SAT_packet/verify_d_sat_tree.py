"""Independent D6 physical separating-axis tree replay.

Replays the original ancestor, each exact induction, every printed physical
row, and every complete eight-way union. No numerical producer is imported.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import Counter
from copy import deepcopy
import argparse,hashlib,importlib,json,sys,time
from verify_coupled_d6 import Checker,CORE
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'b_work'))
import independent_physical_sat_replay as SAT

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class Adapter:
    def __init__(self,checker):
        self.checker=checker;self.K=checker.K
        self.R=importlib.import_module('review_guarded_frame_bounds_independent')
    def choices(self,path):return self.K.V.reconstruct(path)[2]
    def analytic(self,angles):return self.K.analytic(angles)
    def infer_angles(self,angles,scalar):return self.R.infer_angles(angles,scalar)
    def rebuild(self,state,printed):
        base,bounds,pos,scalar,diff,guards=self.K.rebuild(state['path'],state['angles'],state['positions'],
            state['choices'],state['scalar'],state['differences'])
        diagonal=self.checker.ID.intervals(diff,state['diagonal'])
        assert all(a<=b for ds in diagonal.values()for a,b in ds)
        total=max(len(base),max((r['index']+1 for r in printed),default=0))
        rows,names=self.checker.printed_rows(printed,total,base,bounds,scalar,diff,diagonal,state['angles'])
        return {r['index']:rows[r['index']]for r in printed},bounds,dict(state,positions=pos,scalar=scalar,
            differences=diff,diagonal=diagonal)
    def verify_early_terminal(self,state,terminal):
        if terminal['kind']=='accepted_interval_terminal':
            _,_,label=self.R.collect_guarded(state['path'],state['angles'],state['positions'],
                state['choices'],state['scalar'])
            assert label is not None and terminal['label']==label
            return True
        if terminal['kind']=='empty_correlated_diagonal':
            _,_,pos,scalar,diff,_=self.K.rebuild(state['path'],state['angles'],state['positions'],
                state['choices'],state['scalar'],state['differences'])
            diagonal=self.checker.ID.intervals(diff,state['diagonal'])
            assert any(a>b for ds in diagonal.values()for a,b in ds)
            return True
        raise AssertionError(('unsupported exact terminal',terminal))

def replay(parent,tree,output):
    started=time.monotonic();manifest=json.loads((tree/'manifest.json').read_text())
    assert manifest['schema']=='D6_original_physical_sat_complete_eight_tree_discovery_v1'
    assert manifest['parent']['sha256']==sha(parent)
    checker=Checker(context=CORE,ancestry=CORE/'ancestry')
    ancestor,state,diagonal=checker.replay(parent,allow_open=True,return_state=True)
    state=dict(state,diagonal=diagonal);adapter=Adapter(checker)
    nodes={};bindings={str(parent.resolve()):sha(parent),str((tree/'manifest.json').resolve()):sha(tree/'manifest.json')}
    for entry in manifest['nodes']:
        i=entry['index'];assert type(i)is int and i>=0 and i not in nodes
        path=tree/entry['file'];assert path.name==f'node_{i:04d}.json' and sha(path)==entry['sha256']
        node=json.loads(path.read_text());assert node['index']==i
        nodes[i]=node;bindings[str(path.resolve())]=entry['sha256']
    visited=set();audits=[];covers=[]
    def visit(i,initial,parent_index=None,depth=0,choice=None):
        assert i not in visited;visited.add(i);node=nodes[i]
        assert node['parent']==parent_index and node['depth']==depth and node['choice']==choice
        assert node['initial']==SAT.state_view(initial)
        audit,after=SAT.check_record(node['record'],initial,adapter)
        audit.update(index=i,depth=depth,parent=parent_index,choice=choice,
            terminal_kind=node['record'].get('terminal',{}).get('kind'),
            terminal_label=node['record'].get('terminal',{}).get('label'))
        audits.append(audit)
        children=node['children']
        if after is None:
            assert children==[] and 'split_pair'not in node
            assert node['status']=='CANDIDATE_CLOSED'
            return True
        if not children:
            assert node['status']=='OPEN'
            return False
        pair=node['split_pair'];assert node['complete_eight_children']is True
        expected=set(product(tuple(pair),(0,1),(-1,1)))
        actual=[tuple(nodes[k]['choice'])for k in children]
        assert len(children)==len(set(children))==8 and len(set(actual))==8 and set(actual)==expected
        closed=[]
        for k in children:
            chosen=nodes[k]['choice'];child=SAT.sat_child(after,pair,chosen,adapter)
            closed.append(visit(k,child,i,depth+1,chosen))
        excluded=all(closed)
        assert node['status']==('CANDIDATE_COVER_CLOSED'if excluded else'OPEN')
        covers.append(dict(index=i,pair=pair,children=children,all_eight_physical_alternatives=True,
            closed_faces_retained=True,all_children_excluded=excluded))
        return excluded
    excluded=visit(0,state)
    assert visited==set(nodes)
    assert manifest['status']==('CANDIDATE_COVER_CLOSED'if excluded else'OPEN')
    assert not any(n in sys.modules for n in ('numpy','scipy','highspy','d_runtime','d_physical_sat','physical_sat_engine_snapshot'))
    for path,h in bindings.items():assert sha(path)==h
    report=dict(schema='independent_D6_complete_original_physical_sat_tree_replay_v1',
        status='PASS_COMPLETE_RESTRICTED_PHYSICAL_DOMAIN'if excluded else'PASS_PARTIAL_RESTRICTED_PHYSICAL_DOMAIN',
        original_id=state['id'],initial_original_path=state['path'],ancestor_replay=ancestor,
        nodes=len(nodes),complete_eight_covers=len(covers),leaf_domains=sum(not n['children']for n in nodes.values()),
        excluded_leaf_domains=sum(a['status']=='PASS_EXCLUDED_PHYSICAL_DOMAIN'for a in audits),
        rounds=sum(a['rounds']for a in audits),deductions=sum(a['deductions']for a in audits),
        printed_rows_checked=sum(a['printed_rows_checked']for a in audits),
        coupled_row_occurrences_checked=checker.coupled_occurrences,
        audits=audits,covers=covers,input_sha256=bindings,
        checker_sha256={str(Path(p).resolve()):sha(p)for p in (__file__,SAT.__file__)},
        numerical_producer_imported=False,numerical_fields_used=False,
        new_original_cells=0,new_masks=0,seconds=time.monotonic()-started)
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k]for k in('status','nodes','complete_eight_covers','leaf_domains','excluded_leaf_domains','rounds','deductions','printed_rows_checked','seconds')}),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('parent',type=Path);ap.add_argument('tree',type=Path);ap.add_argument('output',type=Path)
    a=ap.parse_args();replay(a.parent,a.tree,a.output)
