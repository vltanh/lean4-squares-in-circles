#!/usr/bin/env python3
"""Portable exact companion and independent controls for a local unit-height blocker."""
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
digest=lambda p:sha256(Path(p).read_bytes()).hexdigest()

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    assert Path(module.__file__).resolve()==path.resolve()
    return module

def normalized(report):
    report=dict(report)
    report['source_sha256']={Path(k).name:v for k,v in report['source_sha256'].items()}
    return report

def main():
    assert __debug__
    manifest=HERE/'SHA256_MANIFEST.json';raw=manifest.read_bytes();files=json.loads(raw)['files']
    def unchanged():
        assert manifest.read_bytes()==raw
        for name,h in files.items():
            p=(HERE/name).resolve();assert p.is_relative_to(HERE)
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            assert digest(p)==h,('changed_frozen_input',name)
    unchanged();assert files['verify_all.py']==digest(__file__)
    table=json.loads((HERE/'THEOREM_AND_BOUNDARY_TABLE.json').read_text())
    assert table['schema']=='sharp_unit_height_aligned_endpoint_blocker_table_v1'
    assert table['height_interval']==['0','1']and table['strict_CD_weakness_retained']is True
    assert table['new_original_cells']==table['new_masks']==0
    accepted=json.loads((HERE/'INDEPENDENT_REVIEW.json').read_text())
    assert accepted['status']=='PASS_CONTINUOUS_PROOF_BOUNDARY_SEAMS_AND_SHARPNESS'
    hand=HERE/'UNIT_HEIGHT_ALIGNED_ENDPOINT_BLOCKER_HAND_PROOF.md'
    author=HERE/'check_unit_height_blocker.py'
    assert files[hand.name]==accepted['hand_sha256']==table['hand_sha256']==digest(hand)
    assert files[author.name]==accepted['author_checker_sha256']==table['exact_companion_sha256']==digest(author)
    companion=load('unit_height_exact_companion',author).verify()
    assert companion['status']=='PASS_UNIT_HEIGHT_BLOCKER_EXACT_COMPANION'
    assert companion['polynomial_identities']==8 and companion['physical_pair_checks']==36
    assert companion['exact_parameter_lower_reserves']==['7/25','1/25','69/100']
    assert companion['new_original_cells']==companion['new_masks']==0
    review_path=HERE/'review_inputs/review_unit_height_blocker.py'
    assert digest(review_path)==accepted['reviewer_sha256']
    review=load('independent_unit_height_review',review_path)
    # Relocate only source/output paths. The independent evaluator's exact
    # arithmetic and physical polygon calculations remain unchanged bytes.
    output=HERE/'review_replay';output.mkdir(exist_ok=True)
    review.HERE=output;review.PACKET=HERE;review.HAND=hand;review.AUTHOR=author
    review.EXPECTED={hand:accepted['hand_sha256'],author:accepted['author_checker_sha256']}
    review.main()
    fresh=normalized(json.loads((output/'UNIT_HEIGHT_BLOCKER_INDEPENDENT_REVIEW.json').read_text()))
    assert fresh==normalized(accepted)
    assert fresh['full_height_interval']==table['height_interval']
    assert fresh['continuous_cases']==table['continuous_cases']
    assert fresh['sharpness_parameter_interval']==table['sharpness_parameter_interval']
    assert len(fresh['rational_function_identities'])==13 and fresh['distance_polynomial_identities']==2
    assert fresh['independent_physical_pair_checks']==36
    assert not any(name in sys.modules for name in('numpy','scipy','sympy','z3','highspy'))
    unchanged()
    report=dict(schema='portable_sharp_unit_height_blocker_exact_replay_v1',
        status='PASS_LOCAL_SHARP_UNIT_HEIGHT_PHYSICAL_BLOCKER',
        height_interval=['0','1'],strict_CD_weakness_retained=True,
        continuous_geometric_proof=hand.name,continuous_proof_independently_reviewed=True,
        independent_review_sha256=files['INDEPENDENT_REVIEW.json'],
        exact_companion=companion,fresh_independent_exact_controls=fresh,
        source_manifest_sha256=sha256(raw).hexdigest(),frozen_inputs=len(files),
        all_frozen_inputs_unchanged=True,all_inputs_and_outputs_inside_packet=True,
        strict_numerical_status_used=False,sharpness_family_requires_no_containing_disk=True,
        caller_requires_separate_row_and_cap_equality=True,
        scope='Local four-original physical theorem and conditional equality terminal; no global mask routing.',
        new_original_cells=0,new_masks=0,lean_lake_ci_run=False)
    (HERE/'COMPLETE_REPLAY.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k]for k in('status','height_interval','frozen_inputs','new_original_cells','new_masks')}))
    return report

if __name__=='__main__':main()
