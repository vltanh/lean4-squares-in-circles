# Sharp unit-height aligned endpoint blocker

This portable packet proves a local physical theorem: aligned unit squares
at D=(1,0), X=(0,v), G=(1/2,-1), with **0≤v≤1**, exclude every fourth
physical unit square C that satisfies the original cone C→D and its
strictly weak horizontal comparison. Both independent C frame chiralities,
all physical contact faces, and both endpoints of the height interval are
retained. An exact continuous counterfamily for v>1 proves the height
constant is sharp for these local hypotheses.

Run `python -B -S verify_all.py` from the extracted directory. It checks
all frozen input hashes, runs the author’s exact companion, reruns the
unchanged independent evaluator using packet-local paths, compares its
normalized result with the accepted review, and rehashes every input.

The continuous geometric hand proof and independent review establish the
exclusion. The exact evaluators check identities and physical boundary
controls; the finite controls are not substituted for the continuous
proof. The packet imports no numerical optimizer or external project code.

This is a separate strengthening of the published near-horizontal blocker;
the earlier packet remains unchanged. A full-nine use still requires an
independently proved row/cap equality aligning these same originals and
establishing the displayed D, X, G positions. The theorem alone does not
provide a whole-mask route or close an original cell. All credit here is
zero original cells and zero masks. No Lean, Lake or CI was run.
