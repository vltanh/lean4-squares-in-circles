#!/usr/bin/env python3
"""Exact companion for the sharp unit-height geometric blocker and its controls."""
from fractions import Fraction as F
from itertools import combinations, product
from hashlib import sha256
from pathlib import Path
import json


def add(*polys):
    out={}
    for p in polys:
        for m,c in p.items():out[m]=out.get(m,F(0))+c
    return{m:c for m,c in out.items()if c}

def scale(p,c):return{m:F(c)*q for m,q in p.items()if c*q}

def mul(p,q):
    out={}
    for m,c in p.items():
        for n,d in q.items():
            k=tuple(a+b for a,b in zip(m,n));out[k]=out.get(k,F(0))+c*d
    return{m:c for m,c in out.items()if c}

def dot(a,b):return sum(x*y for x,y in zip(a,b))

def halfwidth(frame,normal):
    u,v=frame;return (abs(dot(u,normal))+abs(dot(v,normal)))/2

def physical_margin(p,q):
    cp,fp=p;cq,fq=q;delta=tuple(y-x for x,y in zip(cp,cq))
    return max(abs(dot(delta,n))-halfwidth(fp,n)-halfwidth(fq,n)
               for n in (*fp,*fq))

def verify():
    one={(0,)*6:F(1)}
    a,b,x,h,j,e=[{tuple(int(i==k)for i in range(6)):F(1)}for k in range(6)]
    half=scale(one,F(1,2));fh=scale(add(a,b),F(1,2));fj=scale(add(a,scale(b,-1)),F(1,2))
    def equal(p,q):assert not add(p,scale(q,-1))
    equal(add(fh,fj),a)
    equal(add(fh,scale(fj,-1)),b)
    equal(add(mul(fh,fh),mul(fj,fj)),scale(add(mul(a,a),mul(b,b)),F(1,2)))
    equal(add(scale(x,2),scale(mul(x,x),-1),scale(mul(x,x),-1)),
          scale(mul(x,add(one,scale(x,-1))),2))
    equal(add(mul(x,x),mul(add(one,scale(x,-1)),add(one,scale(x,-1)))),
          add(one,scale(mul(x,add(one,scale(x,-1))),-2)))
    r=add(half,fh)
    equal(add(mul(b,add(half,scale(fj,-1))),scale(mul(r,add(one,scale(a,-1))),-1)),
          scale(add(mul(a,a),mul(b,b),scale(one,-1)),F(1,2)))
    equal(add(half,scale(fj,-1),e,r),add(one,b,e))
    equal(add(half,scale(fj,-1),e,one,scale(r,-1)),add(one,scale(a,-1),e))
    assert F(3)-17*F(2,5)**2==F(7,25)>0
    assert 1-F(2,5)**2-2*F(2,5)==F(1,25)>0
    assert F(7,10)-2*F(1,200)==F(69,100)>0
    # The D/G union covers the open rectangle on both sides of its seam.
    for xx,yy in product((F(3,5),F(3,4),F(9,10)),(F(-7,5),F(-3,4),F(-1,2),F(-1,4),F(2,5))):
        in_D=F(1,2)<xx<F(3,2)and-F(1,2)<yy<F(1,2)
        in_G=0<xx<1 and-F(3,2)<yy<-F(1,2)
        assert in_D or in_G or yy==-F(1,2)
    aligned=((F(1),F(0)),(F(0),F(1)))
    controls=[];pair_checks=0
    for t in (F(1,1000),F(1,100),F(1,10),F(1,5),F(2,5)):
        aa=(1-t*t)/(1+t*t);bb=2*t/(1+t*t)
        hh=(aa+bb)/2;jj=(aa-bb)/2;rr=F(1,2)+hh;ee=bb*bb/100
        yy=F(1,2)-jj+ee;dd=rr-bb*ee/aa;xx=1-dd;vv=yy+rr
        assert aa>bb>0 and aa*aa+bb*bb==1
        assert aa>=F(7,10) and 0<ee<=F(1,200)
        assert bb*(F(1,2)-jj)==rr*(1-aa)
        assert aa*dd+bb*yy==rr
        assert rr-dd==bb*ee/aa>0
        assert dd-yy==aa-ee*(1+bb/aa)>0
        assert vv==1+bb+ee>1
        assert vv-yy==rr and yy+1-rr==1-aa+ee>0
        units={'D':((F(1),F(0)),aligned),'X':((F(0),vv),aligned),
               'G':((F(1,2),F(-1)),aligned),
               'C':((xx,yy),((aa,-bb),(bb,aa)))}
        margins={i+j:str(physical_margin(units[i],units[j]))for i,j in combinations(units,2)}
        assert all(F(m)>=0 for m in margins.values());pair_checks+=len(margins)
        controls.append(dict(half_angle=str(t),a=str(aa),b=str(bb),epsilon=str(ee),
                             C=[str(xx),str(yy)],X_height=str(vv),strict_weak_reserve=str(rr-dd),
                             strict_cone_reserve=str(dd-yy),all_physical_pair_reserves=margins))
    # The v=1 contact face itself remains nonempty when weak CD is relaxed.
    boundary={'D':((F(1),F(0)),aligned),'X':((F(0),F(1)),aligned),
              'G':((F(1,2),F(-1)),aligned),'C':((F(0),F(0)),aligned)}
    boundary_margins={i+j:str(physical_margin(boundary[i],boundary[j]))for i,j in combinations(boundary,2)}
    assert all(F(m)>=0 for m in boundary_margins.values());pair_checks+=len(boundary_margins)
    assert boundary['D'][0][0]-boundary['C'][0][0]==1
    assert 1<=1 and not 1<1
    return dict(status='PASS_UNIT_HEIGHT_BLOCKER_EXACT_COMPANION',
        continuous_geometric_proof='UNIT_HEIGHT_ALIGNED_ENDPOINT_BLOCKER_HAND_PROOF.md',
        polynomial_identities=8,parameter_interval='0<t<=2/5',
        exact_parameter_lower_reserves=['7/25','1/25','69/100'],
        all_extreme_original_frame_and_contact_faces_retained=True,
        sharpness_controls=controls,physical_pair_checks=pair_checks,
        marked_equality_boundary_control=boundary_margins,
        sharpness_control_scope='Local four-unit theorem only; no containing Q disk claimed',
        new_original_cells=0,new_masks=0,lean_lake_ci_run=False,
        checker_sha256=sha256(Path(__file__).read_bytes()).hexdigest())

if __name__=='__main__':print(json.dumps(verify(),indent=2))
