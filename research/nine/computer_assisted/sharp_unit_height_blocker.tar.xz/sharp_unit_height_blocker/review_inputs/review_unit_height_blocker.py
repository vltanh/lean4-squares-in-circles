#!/usr/bin/env python3
"""Independent exact controls for the continuous unit-height blocker review.

No author checker is imported.  The continuous case proof is recorded in the
companion review; these identities and physical controls check its algebra and
its claimed sharp boundary without substituting samples for that proof.
"""
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent / 'a_family/other_masks/unit_height_blocker_packet'
HAND = PACKET / 'UNIT_HEIGHT_ALIGNED_ENDPOINT_BLOCKER_HAND_PROOF.md'
AUTHOR = PACKET / 'check_unit_height_blocker.py'
EXPECTED = {
    HAND: '376fdc879e70e9ed200ac1a56bdacd822e56bd2c440cb76ac41b107a2eba86d3',
    AUTHOR: 'f5ee0eef2b5a29c59007e4088e3fd059cd37cd45d1238e12f90bbd461f833da1',
}
digest = lambda p: sha256(Path(p).read_bytes()).hexdigest()


def trim(p):
    p = list(map(Q, p))
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return tuple(p)


def plus(p, q):
    return trim([(p[k] if k < len(p) else 0) +
                 (q[k] if k < len(q) else 0)
                 for k in range(max(len(p), len(q)))])


def times(p, q):
    r = [Q(0)] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            r[i + j] += a * b
    return trim(r)


class R:
    """Univariate rational expressions, with equality by cross multiplication."""
    def __init__(self, num, den=(1,)):
        self.n = trim(num if isinstance(num, (list, tuple)) else (num,))
        self.d = trim(den)
        assert self.d != (Q(0),)

    @staticmethod
    def coerce(x):
        return x if isinstance(x, R) else R(x)

    def __add__(self, other):
        other = self.coerce(other)
        return R(plus(times(self.n, other.d), times(other.n, self.d)),
                 times(self.d, other.d))
    __radd__ = __add__

    def __neg__(self):
        return R(tuple(-v for v in self.n), self.d)

    def __sub__(self, other):
        return self + -self.coerce(other)

    def __rsub__(self, other):
        return self.coerce(other) + -self

    def __mul__(self, other):
        other = self.coerce(other)
        return R(times(self.n, other.n), times(self.d, other.d))
    __rmul__ = __mul__

    def __truediv__(self, other):
        other = self.coerce(other)
        return R(times(self.n, other.d), times(self.d, other.n))

    def __eq__(self, other):
        other = self.coerce(other)
        return times(self.n, other.d) == times(other.n, self.d)


def controls(t):
    a = (1-t*t)/(1+t*t)
    b = 2*t/(1+t*t)
    h = (a+b)/2
    j = (a-b)/2
    r = Q(1,2)+h
    eps = b*b/100
    y = Q(1,2)-j+eps
    d = r-b*eps/a
    return a,b,h,j,r,eps,1-d,y,y+r,d


def vertices(center, axes):
    return tuple(tuple(center[k] + Q(s,2)*axes[0][k] +
                       Q(t,2)*axes[1][k] for k in (0,1))
                 for s,t in ((-1,-1),(1,-1),(1,1),(-1,1)))


def interval(pts, direction):
    values = [sum(x*y for x,y in zip(p,direction)) for p in pts]
    return min(values), max(values)


def separation(left, right):
    lp = vertices(*left)
    rp = vertices(*right)
    margins = []
    for polygon in (lp,rp):
        for a,b in zip(polygon,polygon[1:]+polygon[:1]):
            normal = (a[1]-b[1],b[0]-a[0])
            lo,hi = interval(lp,normal)
            otherlo,otherhi = interval(rp,normal)
            margins.append(max(otherlo-hi,lo-otherhi))
    return max(margins)


def main():
    for path, expected in EXPECTED.items():
        assert digest(path) == expected
    # All expressions are rational identities in the half-angle parameter t.
    t = R((0,1))
    a = (1-t*t)/(1+t*t)
    b = 2*t/(1+t*t)
    h = (a+b)/2
    j = (a-b)/2
    r = Q(1,2)+h
    eps = b*b/100
    y = Q(1,2)-j+eps
    d = r-b*eps/a
    v = y+r
    identities = {
        'unit_frame': a*a+b*b == 1,
        'vertex_sum': h+j == a,
        'vertex_difference': h-j == b,
        'vertex_norm': h*h+j*j == Q(1,2),
        'owned_axis_support': b*(Q(1,2)-j) == r*(1-a),
        'CD_exact_owned_contact': a*d+b*y == r,
        'strict_weak_reserve': r-d == b*eps/a,
        'strict_cone_reserve': d-y == a-eps*(1+b/a),
        'CX_exact_vertical_contact': v-y == r,
        'CG_strict_vertical_separation': y+1-r == 1-a+eps,
        'sharpness_height': v == 1+b+eps,
        'parameter_alpha_lower': a-Q(7,10) == (3-17*t*t)/(10*(1+t*t)),
        'parameter_fold': a-b == (1-t*t-2*t)/(1+t*t),
    }
    assert all(identities.values())
    # Uniform positive rational endpoint bounds used for the entire t interval.
    reserves = {
        'alpha_numerator_at_two_fifths': Q(3)-17*Q(2,5)**2,
        'fold_numerator_at_two_fifths': 1-Q(2,5)**2-2*Q(2,5),
        'cone_lower_bound': Q(7,10)-2*Q(1,200),
    }
    assert list(reserves.values()) == [Q(7,25),Q(1,25),Q(69,100)]
    assert all(q>0 for q in reserves.values())
    # The geometric upper-half contradiction uses this exact identity.
    x = R((0,1))
    assert 1-(1-x)*(1-x)-x*x == 2*x*(1-x)
    assert x*x+(1-x)*(1-x) == 1-2*x*(1-x)
    aligned = ((Q(1),Q(0)),(Q(0),Q(1)))
    examples = []
    pair_count = 0
    for tt in (Q(1,2000),Q(1,64),Q(1,16),Q(1,3),Q(2,5)):
        aa,bb,hh,jj,rr,ee,xx,yy,vv,dd = controls(tt)
        assert aa>bb>0 and aa*aa+bb*bb == 1
        assert aa>Q(7,10) and 0<ee<=Q(1,200)
        assert rr-dd>0 and dd-yy>0 and yy>0 and vv>1
        units = {
            'D': ((Q(1),Q(0)),aligned),
            'X': ((Q(0),vv),aligned),
            'G': ((Q(1,2),Q(-1)),aligned),
            'C': ((xx,yy),((aa,-bb),(bb,aa))),
        }
        margins = {u+w:str(separation(units[u],units[w]))
                   for u,w in combinations(units,2)}
        assert all(Q(q)>=0 for q in margins.values())
        pair_count += len(margins)
        examples.append(dict(t=str(tt),height=str(vv),weak_reserve=str(rr-dd),
                             cone_reserve=str(dd-yy),pair_margins=margins))
    boundary = {'D':((Q(1),Q(0)),aligned),'X':((Q(0),Q(1)),aligned),
                'G':((Q(1,2),Q(-1)),aligned),'C':((Q(0),Q(0)),aligned)}
    boundary_margins = {u+w:str(separation(boundary[u],boundary[w]))
                        for u,w in combinations(boundary,2)}
    assert all(Q(q)>=0 for q in boundary_margins.values())
    pair_count += len(boundary_margins)
    for path, expected in EXPECTED.items():
        assert digest(path) == expected
    report = dict(
        schema='independent_unit_height_aligned_endpoint_blocker_review_v1',
        status='PASS_CONTINUOUS_PROOF_BOUNDARY_SEAMS_AND_SHARPNESS',
        hand_sha256=EXPECTED[HAND],author_checker_sha256=EXPECTED[AUTHOR],
        source_sha256={str(p):s for p,s in EXPECTED.items()},
        rational_function_identities=identities,
        distance_polynomial_identities=2,
        exact_uniform_parameter_reserves={k:str(v) for k,v in reserves.items()},
        continuous_cases=['x<=0','x>0 and y>=0','x>0 and y<0'],
        closed_C_point_in_open_DG_strip_reviewed=True,
        shared_horizontal_seam_avoided_by_interior_perturbation=True,
        rightmost_vertex_x_equals_one_uses_strict_center_segment=True,
        both_original_chiralities_and_degenerate_side_faces_retained=True,
        full_height_interval=['0','1'],sharpness_parameter_interval='0<t<=2/5',
        independent_polygon_projection_controls=examples,
        independent_physical_pair_checks=pair_count,
        strict_weakness_required_boundary_control=boundary_margins,
        full_caller_requires_separate_row_and_cap_equality=True,
        no_universal_mask_routing_claim=True,author_checker_imported=False,
        solver_imported=False,manual_continuous_review_is_primary=True,
        new_original_cells=0,new_masks=0,lean_lake_ci_run=False,
        reviewer_sha256=digest(__file__))
    output=HERE/'UNIT_HEIGHT_BLOCKER_INDEPENDENT_REVIEW.json'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],digest(output))


if __name__ == '__main__':
    main()
