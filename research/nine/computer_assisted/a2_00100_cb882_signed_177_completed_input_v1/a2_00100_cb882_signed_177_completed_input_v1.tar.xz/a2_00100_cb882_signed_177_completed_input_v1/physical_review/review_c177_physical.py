from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib,json,importlib.util
ROOT=Path('/workspace/lean4-squares-in-circles/research/nine');R=ROOT/'.runs';C=R/'c_continue';OUT=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/6b34cccf3741/repo/research/nine/.runs/closure_20261104/c_runtime/code/opposite_boundary')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
a=read(C/'SIGNED_177_ATTACHMENT.json');src=Path(a['source_manifest']);recpath=C/'SIGNED_177_TERMINAL.json';rec=read(recpath);manifest=read(src);state=rec['initial']
assert sha(src)==a['source_manifest_sha256']=='de9647b32a2a138d24177e19ce4a9b414cdb143c07617b2eeb2f0f688043f25e'
assert sha(recpath)==a['record_sha256']=='67eb4ccdef2e100e41d2973b0d6bd3c7e8d855129059a9d2a0eeb79d9fc51666'
pending=next(p for p in manifest['pending']if p['index']==177);assert pending['state']==state
reg=read(ROOT/'gates/A2_00100_FIXED_FRONTIER.json');cell=next(e for e in reg['cells']if e['id']==state['id'])
assert state['id']=='negative-b882d8ade0cf9ea0'and state['path'][:len(cell['path'])]==cell['path']
assert len(state['angles'])==9 and len(state['positions'])==18 and len(state['scalar'])==36
assert{tuple(e['pair'])for e in state['differences']}==set(combinations(range(9),2))
spec=importlib.util.spec_from_file_location('c177_literal_guard_review',C/'signed_177_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
g=guard.evaluate(state);assert g['status']=='GUARD_IMPLIED'and guard.literal(state)==rec['terminal']
assert 2*F(1,16)**2<1 and F(1,4)<1 and F(46798823265,549755813888)<F(2,23)
assert (F(17,12))**2>2 and 46*2+F(27,2)==2*F(211,4)
scalar=R/'review_continue/SIGNED177_SCALAR_INDEPENDENT_REVIEW.json';literal=R/'review_continue/SIGNED177_LITERAL_ATTACHMENT_REVIEW.json'
assert sha(scalar)=='39378772e7bd04dbf0de3c5536e22f2014707a1c3475be21e91f42373584f37e'
assert sha(literal)=='5c3770abe50eba28dbfd75bd6ba81609c2ef2eef0f5104bc07a56d14d61881ec'
hand=C/'signed_177_scalar/HAND_PROOF.md';assert sha(hand)=='5ac51864d59ce7ddca77909bfc0e2cf565bd8c3ec2c1ab108036b7a3681acf6e'
inputs=[Path(__file__).resolve(),OUT/'C177_PHYSICAL_TRANSPORT_REVIEW.md',hand,scalar,literal,C/'SIGNED_177_ATTACHMENT.json',recpath,src,C/'signed_177_guard.py',OLD/'HAND_PROOF.md']
inputs +=[OLD/'inherited_hand_inputs'/n for n in ['UNIVERSAL_MAIN_ENDPOINT_TILT_TOLL.md','SHARP_SMALL_MAIN_ENDPOINT_TILT_TOLL.md','PHYSICAL_TWO_SQUARE_CAP_SUPPORT_AND_UNRESTRICTED_FOUR_PLUS_THREE_CHAINS_2026_10_31.md']]
report=dict(status='PASS_INDEPENDENT_C177_SIGNED_BI_ID_PHYSICAL_CAP_TRANSPORT_AND_ALIGNED_Q_JOIN',original_id=state['id'],scope='entire saved conditional pending177; strict q<1105/256',incoming_state_identical=True,fixed_original_root_prefix_preserved=True,
 all_nine_originals_36corners_36pairs_fivecones_actual_AB_BC_EF_FG_strict_weak_CD_retained=True,
 BI_all_actual_owners_axes_and_height_signs_retained=True,ID_all_four_signed_owned_axes_retained=True,ID_steep_zero_owner_face_physically_excluded_before_division=True,
 original_B_half_angle_bound_valid=True,unrestricted_AE_DG_endpoint_caps_used_with_same_originals=True,EF_FG_chain_telescope_valid=True,
 strict_radius_cap_contradiction=True,fully_aligned_closed_Q_CD_blocker_valid=True,exact_zero_face_to_closed_Q_join_valid_given_separate_independent_scalar_audit=True,
 frozen_manuscript_scope_unchanged=True,global_equality_classification_claimed=False,old_cap_arithmetic_reused_not_repeated=True,
 enclosing_original_ancestry_and_final_cover_integration_remain_separate=True,blocking_findings=[],new_original_cells=0,new_masks=0,
 source_sha256={str(p):sha(p)for p in inputs})
(OUT/'C177_INDEPENDENT_PHYSICAL_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],sha(OUT/'C177_INDEPENDENT_PHYSICAL_REVIEW.json'))
