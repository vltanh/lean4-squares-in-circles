"""Independent rational reconstruction of the 32 signed-177 scalar covers.

Only JSON certificate parameters are consumed; no discovery producer is imported.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import comb
from functools import lru_cache
import hashlib,json,time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'c_continue/signed_177_scalar'
ZERO=(0,0,0)
UP=(F(1,23),F(5,12),F(5,12))

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(*polys):
    out={}
    for p in polys:
        for e,c in p.items():out[e]=out.get(e,F(0))+c
    return {e:c for e,c in out.items() if c}
def scale(p,c):return {e:v*c for e,v in p.items() if v*c}
def mul(*polys):
    out={ZERO:F(1)}
    for p in polys:
        new={}
        for e,c in out.items():
            for f,d in p.items():
                k=tuple(e[i]+f[i] for i in range(3));new[k]=new.get(k,F(0))+c*d
        out={e:c for e,c in new.items() if c}
    return out

ONE={ZERO:F(1)}
X=[{tuple(int(i==j) for i in range(3)):F(1)} for j in range(3)]
X2=[mul(x,x) for x in X]
PLUS=[add(ONE,x) for x in X2]
MINUS=[add(ONE,scale(x,-1)) for x in X2]
FULL=[mul(a,b) for a,b in zip(PLUS,MINUS)]
DEN=mul(*FULL)

def without(factors,removed):
    return mul(*(p for k,p in factors if k not in removed))

def polynomial(signs,bi_owner,id_owner,id_axis,weights):
    eps_bi,eps_id,tau=weights
    z=[scale(x,s) for x,s in zip(X,signs)]
    def complement(factors):
        allf=[((i,0),MINUS[i]) for i in range(3)]+[((i,1),PLUS[i]) for i in range(3)]
        return without(allf,set(factors))
    def pair_numerator(i,j,eps):
        a=add(ONE,mul(z[i],z[j]));d=add(z[i],scale(z[j],-1))
        return add(mul(a,a),scale(mul(a,d),eps))
    # Q*(h_B + Tbase_D - h_D + tau*(Tsharp_D-Tbase_D) - 2).
    hb=scale(add(MINUS[0],scale(X[0],2)),F(1,2))
    td=scale(add(scale(ONE,-23),scale(X[2],-38),scale(X2[2],23)),F(1,46))
    dt=scale(add(scale(X[2],143),scale(X2[2],-943)),tau/F(368))
    ordinary=add(mul(hb,complement([(0,1)])),
                 mul(add(td,dt),complement([(2,1)])),scale(DEN,-2))
    # BI support over alpha of its actual owner, and unsigned transverse loss.
    other=1-bi_owner
    ordinary=add(ordinary,mul(pair_numerator(0,1,eps_bi),complement([(bi_owner,0),(other,1)])),
                 scale(mul(X[bi_owner],complement([(bi_owner,0)])),F(-1,8)))
    other=3-id_owner;s=signs[id_owner]
    if id_axis==0:
        v=F(1,4) if s>0 else F(1,16)
        ordinary=add(ordinary,mul(pair_numerator(1,2,eps_id),complement([(id_owner,0),(other,1)])),
                     scale(mul(X[id_owner],complement([(id_owner,0)])),-2*s*v))
        answer=ordinary
    else:
        # Positive denominator is 2*x_owner*Q; x_owner=0 is not a physical steep separator.
        v=F(1,4) if s<0 else F(1,16)
        answer=add(scale(mul(X[id_owner],ordinary),2),
                   mul(pair_numerator(1,2,eps_id),complement([(other,1)])),
                   scale(mul(MINUS[id_owner],DEN),s*v))
    return scale(answer,5888)

@lru_cache(None)
def transform(l,u):
    return tuple(tuple(sum((F(comb(e,m))*l**(e-m)*(u-l)**m*F(comb(k,m),comb(6,m))
                            for m in range(min(k,e)+1)),F(0)) for e in range(7)) for k in range(7))

def bernstein(poly,box):
    out=poly
    for axis,(lo,hi) in enumerate(box):
        mat=transform(lo,hi);new={}
        for e,c in out.items():
            for k in range(7):
                if mat[k][e[axis]]:
                    v=list(e);v[axis]=k;v=tuple(v)
                    new[v]=new.get(v,F(0))+c*mat[k][e[axis]]
        out={e:c for e,c in new.items() if c}
    return {e:out.get(e,F(0)) for e in product(range(7),repeat=3)}

def box_of(path):
    box=[(F(0),q) for q in UP]
    for axis,side in path:
        assert type(axis)is int and axis in range(3) and type(side)is int and side in (0,1)
        lo,hi=box[axis];mid=(lo+hi)/2
        box[axis]=(lo,mid) if side==0 else (mid,hi)
    return tuple(box)

def check_cover(paths):
    paths=[tuple(tuple(s) for s in p) for p in paths]
    assert len(paths)==len(set(paths))
    seen=0
    def visit(prefix):
        nonlocal seen;seen+=1
        below=[p for p in paths if p[:len(prefix)]==prefix]
        assert below
        if prefix in below:assert below==[prefix];return
        nexts={p[len(prefix)] for p in below};axes={a for a,_ in nexts}
        assert len(axes)==1
        axis=axes.pop();assert nexts=={(axis,0),(axis,1)}
        visit(prefix+((axis,0),));visit(prefix+((axis,1),))
    visit(())
    return seen

def zero_faces(coeffs,box,id_owner,id_axis):
    ans=[]
    for face in product((-1,0,1),repeat=3):
        # A physical half-angle is strictly below every enlarged global upper face.
        if any(f==1 and box[i][1]==UP[i] for i,f in enumerate(face)):continue
        if id_axis and face[id_owner]==-1 and box[id_owner][0]==0:continue
        active=[e for e in coeffs if all(f==0 or e[i]==(0 if f==-1 else 6) for i,f in enumerate(face))]
        if all(coeffs[e]==0 for e in active):
            ans.append(dict(face=list(face),fixed={str(i):str(box[i][0 if f==-1 else 1]) for i,f in enumerate(face) if f}))
    return ans

def main():
    start=time.monotonic();m=json.loads((ROOT/'MANIFEST.json').read_text())
    expected=set(product((-1,1),(-1,1),(0,1),(1,2),(0,1)))
    actual=set();audits=[];identities={str(ROOT/'MANIFEST.json'):sha(ROOT/'MANIFEST.json')}
    nodes=0;leaves=0
    assert list(map(F,m['root_upper']))==list(UP) and not m['open'] and m['complete']
    for item in m['domains']:
        f=ROOT/item['file'];assert f.parent==ROOT and f.name==item['file']
        d=json.loads(f.read_text());identities[str(f)]=sha(f)
        signs=d['signs'];assert len(signs)==3 and signs[2]==-1
        key=(signs[0],signs[1],d['bi_owner'],d['id_owner'],d['id_axis'])
        assert key in expected and key not in actual;actual.add(key)
        assert not d['frontier'] and d['scalar_degree']==6 and d['scale']==5888
        assert list(map(F,d['root_upper']))==list(UP)
        for k in ('signs','bi_owner','id_owner','id_axis','nodes'):assert item[k]==d[k]
        assert item['leaves']==len(d['leaves']) and item['frontier']==0
        count=check_cover([x['path'] for x in d['leaves']]);assert count==d['nodes'];nodes+=count
        for leaf in d['leaves']:
            p=leaf['weight_power'];raw=leaf['weights'];assert type(p)is int and 0<=p<=60
            assert len(raw)==3 and all(type(w)is int for w in raw)
            w=[F(v,2**p) for v in raw];assert -1<=w[0]<=1 and -1<=w[1]<=1 and 0<=w[2]<=1
            poly=polynomial(signs,d['bi_owner'],d['id_owner'],d['id_axis'],w)
            assert all(all(0<=k<=6 for k in e) for e in poly)
            assert all((c*2**p).denominator==1 for c in poly.values())
            box=box_of(leaf['path']);b=bernstein(poly,box)
            assert len(b)==343 and min(b.values())>=0, (f.name,leaf['path'],min(b.values()))
            assert max(b.values())>0
            zeros=zero_faces(b,box,d['id_owner'],d['id_axis'])
            # Every physically possible zero face must be the all-aligned origin.
            assert all(z['fixed']=={'0':'0','1':'0','2':'0'} for z in zeros),(f.name,leaf['path'],zeros)
            audits.append(dict(file=f.name,path=leaf['path'],weights=list(map(str,w)),
                box=[[str(l),str(u)] for l,u in box],minimum_bernstein=str(min(b.values())),
                zero_coefficients=sum(c==0 for c in b.values()),physical_zero_faces=zeros,
                polynomial_sha256=hashlib.sha256(json.dumps([(list(e),str(c)) for e,c in sorted(poly.items())]).encode()).hexdigest()))
            leaves+=1
    assert actual==expected and len(actual)==32 and nodes==m['nodes']==36 and leaves==34
    result=dict(status='PASS_INDEPENDENT_SIGNED177_SCALAR_RECONSTRUCTION',domains=32,nodes=nodes,leaves=leaves,
        coefficients_per_leaf=343,all_bernstein_coefficients_nonnegative=True,
        physical_zero_implies_all_three_halfangles_zero=True,zero_steep_owner_case_physically_impossible=True,
        source_identities=identities,leaf_audits=audits,producer_imported=False,physical_attachment_review_separate=True,
        original_cells_closed=0,masks_closed=0,reviewer_source_sha256=sha(__file__),seconds=time.monotonic()-start)
    (HERE/'SIGNED177_SCALAR_INDEPENDENT_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','domains','nodes','leaves','seconds']}))

if __name__=='__main__':assert __debug__;main()
