"""Complete unchanged-original Cb882 replay with ABID and difference cuts."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
sys.path.insert(0,'/workspace/scratch/6b34cccf3741/repo/research/nine/.runs/closure_20261104/c_runtime/code')
import independent_signed_177_terminal as SIGNED
import check_cb882_difference_complete_cover as CHECK
import local_c_height_transport as TRANSPORT
import independent_c_general_rows_adapter as GENERAL
import independent_c_relative_support_chord_adapter as CHORD
import independent_cb882_abid_boundary_terminal as ABID

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

ap = argparse.ArgumentParser()
ap.add_argument("manifest", type=Path)
ap.add_argument("output", type=Path)
args = ap.parse_args()
transport = TRANSPORT.install(CHECK.HEIGHT)
CHECK.Adapter = SIGNED.extend_adapter(ABID.extend_adapter(CHORD.extend_adapter(GENERAL.extend_adapter(CHECK.Adapter, allow_rotating=True))))
bindings = dict(CHORD.source_bindings(), **ABID.source_bindings(), **transport["input_sha256"], **SIGNED.source_bindings())
bindings[str(Path(__file__).resolve())] = sha(__file__)
bindings[str(Path(TRANSPORT.__file__).resolve())] = sha(TRANSPORT.__file__)
for module in tuple(sys.modules.values()):
    path = getattr(module, "__file__", None)
    if path and Path(path).is_file() and "/research/nine/.runs/" in str(Path(path).resolve()):
        bindings[str(Path(path).resolve())] = sha(path)
report = CHECK.replay(args.manifest, args.output)
GENERAL.no_producers()
CHORD.no_producers()
ABID.no_producers()
SIGNED.no_producers()
for path, expected in bindings.items():
    assert sha(path) == expected
report["exact_height_filename_transport"] = transport
report["opposite_boundary_and_relative_support_source_sha256"] = bindings
for path, expected in bindings.items():
    assert path not in report["input_sha256"] or report["input_sha256"][path] == expected
    report["input_sha256"][path] = expected
report["independently_reconstructed_new_row_counts"] = dict(GENERAL.COUNTS, **CHORD.COUNTS)
report["independent_ABID_boundary_terminal_counts"] = ABID.COUNTS
report["fresh_opposite_theorem_replay"] = ABID.THEOREM.REPLAY
report["signed_ABID_terminal_counts"] = SIGNED.COUNTS
report["fresh_signed_ABID_scalar_replay"] = SIGNED.FRESH
report["source_inputs_rehashed_after_complete_cover_replay"] = True
args.output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(dict(new_rows=report["independently_reconstructed_new_row_counts"],
                     terminals=ABID.COUNTS)), flush=True)
