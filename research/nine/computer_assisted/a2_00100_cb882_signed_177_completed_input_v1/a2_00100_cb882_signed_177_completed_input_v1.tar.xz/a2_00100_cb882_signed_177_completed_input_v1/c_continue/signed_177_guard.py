"""Literal guards only for the signed ABID quarter-height scalar theorem.

Independent theorem replay and complete original ancestry are required by the
consumer. This module grants no closure credit by evaluating a guard.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ASSETS=HERE/'signed_177_scalar'
TARGET='negative-b882d8ade0cf9ea0'
ROOT_PATH=[['angle',3,0],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[3]]]
KIND='original_signed_ABID_positive_quarter_exact_scalar'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def box(raw):
    b=tuple(tuple(map(F,p))for p in raw)
    assert all(len(p)==2 and p[0]<=p[1]for p in b)
    return b
def gaps(state,i,j,axis):
    p=box(state['positions'])
    lo=p[2*j+axis][0]-p[2*i+axis][1]
    hi=p[2*j+axis][1]-p[2*i+axis][0]
    raw=state['differences']
    ds=({tuple(d['pair']):box(d['intervals'])for d in raw}
        if isinstance(raw,list)else{tuple(k):box(v)for k,v in raw.items()})
    if i<j and(i,j)in ds:
        a,b=ds[i,j][axis];lo=max(lo,a);hi=min(hi,b)
    if i>j and(j,i)in ds:
        a,b=ds[j,i][axis];lo=max(lo,-b);hi=min(hi,-a)
    assert lo<=hi
    return lo,hi
def evaluate(state):
    assert len(state['positions'])==18 and len(state['angles'])==9 and len(state['scalar'])==36
    angles=box(state['angles'])
    bi_x=gaps(state,1,8,0);id_x=gaps(state,8,3,0)
    bi_y=gaps(state,1,8,1);id_y=gaps(state,8,3,1)
    conditions=dict(
        small_B_slope=(-F(2,23)<=angles[1][0]<=angles[1][1]<=F(2,23)),
        D_nonpositive=(angles[3][1]<=0),
        BI_horizontal_order=(bi_x[0]>=0),ID_horizontal_order=(id_x[0]>=0),
        BI_height=(F(-1,16)<=bi_y[0]<=bi_y[1]<=F(1,16)),
        ID_signed_height=(F(1,16)<=id_y[0]<=id_y[1]<=F(1,4)))
    return dict(status='GUARD_IMPLIED'if all(conditions.values())else'GUARD_NOT_IMPLIED',
                conditions=conditions,physical_row=[0,1,8,3],
                B_slope_interval=list(map(str,angles[1])),D_slope_interval=list(map(str,angles[3])),
                BI_horizontal_interval=list(map(str,bi_x)),ID_horizontal_interval=list(map(str,id_x)),
                BI_height_interval=list(map(str,bi_y)),ID_height_interval=list(map(str,id_y)),
                independent_scalar_replay_and_original_ancestry_required=True)
def literal(state):
    guard=evaluate(state)
    assert state['id']==TARGET and state['path'][:3]==ROOT_PATH
    assert guard['status']=='GUARD_IMPLIED'
    scalar=json.loads((ASSETS/'MANIFEST.json').read_text())
    assert scalar['complete']is True and scalar['open']==0 and len(scalar['domains'])==32
    bindings={'MANIFEST.json':sha(ASSETS/'MANIFEST.json'),'HAND_PROOF.md':sha(ASSETS/'HAND_PROOF.md')}
    bindings.update({d['file']:sha(ASSETS/d['file'])for d in scalar['domains']})
    return dict(kind=KIND,original_guard=guard,strict_squared_radius='1105/256',
                scalar_input_sha256=bindings,guard_source_sha256=sha(__file__),
                all_nine_originals_retained=True,all_original_pairs_corners_and_five_cones_retained=True,
                original_actual_links=['AB','BC','EF','FG'],original_strictly_weak_link='CD')
