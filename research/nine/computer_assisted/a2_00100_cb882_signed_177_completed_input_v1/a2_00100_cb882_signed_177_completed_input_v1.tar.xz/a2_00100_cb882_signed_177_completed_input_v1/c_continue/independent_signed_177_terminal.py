"""Independent scalar replay and literal attachment of the signed ABID terminal."""
from pathlib import Path
from fractions import Fraction as F
import hashlib, importlib.util, json, sys, tempfile
import signed_177_guard as GUARD
HERE=Path(__file__).resolve().parent
CHECKER=HERE.parent/'review_continue/verify_signed177_scalar_independent.py'
CHECKER_SHA='3004fff6257ada749cae024d4ab48696b544cef8af9e699203581135a37a274d'
COUNTS={'signed_ABID_positive_quarter':0}
FRESH=None

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source_bindings():
    assert sha(CHECKER)==CHECKER_SHA
    m=json.loads((GUARD.ASSETS/'MANIFEST.json').read_text())
    paths=[Path(__file__),Path(GUARD.__file__),CHECKER,GUARD.ASSETS/'MANIFEST.json',GUARD.ASSETS/'HAND_PROOF.md']
    paths.extend(GUARD.ASSETS/d['file']for d in m['domains'])
    return {str(p.resolve()):sha(p)for p in paths}
def replay_scalar():
    global FRESH
    bindings=source_bindings()
    if FRESH is None:
        spec=importlib.util.spec_from_file_location('fresh_independent_signed177_scalar',CHECKER)
        check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
        check.ROOT=GUARD.ASSETS
        check.HERE=Path(tempfile.mkdtemp(prefix='signed177_replay_',dir=HERE))
        check.main()
        output=check.HERE/'SIGNED177_SCALAR_INDEPENDENT_REVIEW.json'
        FRESH=json.loads(output.read_text())
        assert FRESH['status']=='PASS_INDEPENDENT_SIGNED177_SCALAR_RECONSTRUCTION'
        assert FRESH['domains']==32 and FRESH['nodes']==36 and FRESH['leaves']==34
        assert FRESH['all_bernstein_coefficients_nonnegative']is True
        assert FRESH['physical_zero_implies_all_three_halfangles_zero']is True
        assert FRESH['producer_imported']is False
        FRESH['fresh_report_path']=str(output)
    for p,h in bindings.items():assert sha(p)==h
    return FRESH

def extend_adapter(parent):
    class Adapter(parent):
        def verify_early_terminal(self,state,terminal):
            if terminal.get('kind')!=GUARD.KIND:return super().verify_early_terminal(state,terminal)
            assert self.K.V.Q==F(1105,256)
            assert self.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
            assert state['id']==GUARD.TARGET and state['path'][:3]==GUARD.ROOT_PATH
            assert terminal==GUARD.literal(state)
            replay_scalar()
            COUNTS['signed_ABID_positive_quarter']+=1
            return True
    return Adapter

def no_producers():
    assert not any(n in sys.modules for n in ('numpy','scipy','highspy','build_signed_177_cover'))
