"""Portable fresh scalar replay and exact frozen-domain attachment check.

This does not replay the external complete original tree. Its prior fresh
replay is explicitly reused, and original/mask closure credit stays zero.
"""
from pathlib import Path
import hashlib,json,sys,argparse

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);a=ap.parse_args()
    bundle=json.loads((HERE/'BUNDLE.json').read_text())
    for rel,item in bundle['files'].items():
        q=Path(rel);assert not q.is_absolute()and'..'not in q.parts
        p=HERE/q;assert p.stat().st_size==item['bytes']and sha(p)==item['sha256'],rel
    sys.path.insert(0,str(HERE/'c_continue'))
    import signed_177_guard as G
    import independent_signed_177_terminal as T
    record=json.loads((HERE/'c_continue/SIGNED_177_TERMINAL.json').read_text())
    source=HERE/'proof_inputs/ORIGINAL_COVER_MANIFEST.json'
    manifest=json.loads(source.read_text())
    items=[n for n in manifest['pending']if n['index']==177];assert len(items)==1
    assert record['initial']==items[0]['state']
    assert record['status']=='CANDIDATE_CLOSED'and record['rounds']==[]
    assert record['terminal']==G.literal(record['initial'])
    register=json.loads((HERE/'accepted_prior/opposite_boundary/original_register.json').read_text())
    assert register['target_mask']=='001/00'and register['target_q']=='1105/256'
    assert register['coverage_certified']is True
    cells=[c for c in register['cells']if c['id']==G.TARGET]
    assert len(cells)==1 and cells[0]['path']==G.ROOT_PATH
    assert manifest['original']['id']==G.TARGET and manifest['original']['path']==G.ROOT_PATH
    prior=json.loads((HERE/'proof_inputs/PRIOR_FRESH_CB882_REPLAY.json').read_text())
    assert prior['status']=='PASS_PARTIAL_WHOLE_ORIGINAL_CB882_COVER'
    assert prior['nodes']==138 and prior['excluded_leaves']==67 and prior['open_leaves']==25
    assert prior['manifest_snapshot_sha256']==sha(source)
    assert prior['all_nine_originals_retained']and prior['all_36_corners_and_pairs_retained']
    assert prior['all_five_cones_and_mask_bits_retained']and prior['closed_shared_faces_retained']
    fresh=T.replay_scalar();T.no_producers()
    for rel,item in bundle['files'].items():assert sha(HERE/rel)==item['sha256']
    result=dict(status='PASS_PORTABLE_SIGNED177_COMPLETE_CONDITIONAL_INPUT',
        exact_scalar_domains=fresh['domains'],exact_scalar_nodes=fresh['nodes'],
        exact_scalar_leaves=fresh['leaves'],exact_scalar_coefficient_checks=34*343,
        fresh_independent_scalar_replay=fresh,original_incoming_state_is_exact_pending177=True,
        prior_complete_original_replay_reused_explicitly=True,
        prior_original_nodes=138,prior_original_excluded=67,prior_original_open=25,
        new_terminal_complete_for_entire_pending177=True,
        new_joined_complete_original_replay_performed=False,
        original_id=G.TARGET,strict_squared_radius='1105/256',
        original_cells_closed=0,masks_closed=0,lean_lake_compilation_ci_run=False,
        immutable_inputs=len(bundle['files']),bundle_sha256=sha(HERE/'BUNDLE.json'))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in ['status','exact_scalar_domains','exact_scalar_nodes','exact_scalar_leaves','immutable_inputs']}))

if __name__=='__main__':assert __debug__;main()
