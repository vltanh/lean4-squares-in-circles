"""At most the remaining 72 phase LPs; existing complete proxy/SAT/angle covers.

This weakens the discovery row set by omitting existing costly area/energy
families. It changes no physical input or checker. Each new terminal still
requires independent reconstruction of every actually weighted row.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
import sys,json,hashlib,time
from collections import deque
from fractions import Fraction as F
from itertools import product
HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/c_family')
sys.path.insert(0,str(OLD))
import c_cached_general_runtime as A
import c_cavity_split_policy as POLICY
import ac_physical_context as PHYSICAL

OUT=HERE/'phase_only_residual';OUT.mkdir(exist_ok=False)
ctx=A.Context()
omitted={}
for module,attribute,replacement in (
    (PHYSICAL.AREA,'generate_linear',lambda *args,**kwargs:[]),
    (PHYSICAL.FC,'linear_rows',lambda *args,**kwargs:[]),
    (PHYSICAL.TE,'linear_rows',lambda *args,**kwargs:[]),
    (PHYSICAL.CT,'rows',lambda *args,**kwargs:([],[])),
):
    omitted[module.__name__+'.'+attribute]=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
    setattr(module,attribute,replacement)

source=json.loads((HERE/'GRAFTED_MANIFEST.json').read_text())
root=next(n for n in source['pending']if n['index']==42)
root_record=json.loads((HERE/'node_00042.json').read_text())
assert root_record['initial']==root['state']and root_record['status']=='OPEN'
previous=json.loads((HERE/'SWEEP_SUMMARY.json').read_text())['calls']
previous+=json.loads((HERE/'ancestor_probe/SUMMARY.json').read_text())['lp_calls']
limit=100-previous
assert 0<limit<=72

def dump(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def clear_cuts():
    before={}
    for name in ('corner_parameters','unit_parameters','frame_squares','projection_squares'):
        value=getattr(ctx,name,None)
        before[name]=len(value)if value is not None else None
        if value is not None:value.clear()
    return before

nodes={0:dict(index=0,parent=None,edge=None,state=root['state'],file='node_00000.json',status='OPEN')}
(OUT/'node_00000.json').write_text(json.dumps(root_record,indent=2)+'\n')
next_index=1
queue=deque()
calls=0
started=time.monotonic()

def split_node(index,state,record):
    global next_index
    choice=POLICY.choose(state,record['point'],record)
    if choice['kind']=='proxy':
        children=[(list(c),ctx.proxy_child(state,choice['pair'],c))for c in product((0,1),(-1,1))]
    elif choice['kind']=='sat':
        children=[(list(c),ctx.child(state,choice['pair'],c))for c in product(choice['pair'],(0,1),(-1,1))]
    else:
        children=[(side,ctx.angle_child(state,choice['owner'],F(choice['cut']),side))for side in(0,1)]
    ids=[]
    for c,s in children:
        i=next_index;next_index+=1;ids.append(i)
        nodes[i]=dict(index=i,parent=index,edge=dict(choice,choice=c),state=A.stateview(s),status='PENDING')
        queue.append(i)
    nodes[index]['split']=dict(choice,children=ids)

def save():
    for idx in sorted(nodes,reverse=True):
        n=nodes[idx];children=n.get('split',{}).get('children',[])
        if children and all(nodes[ch]['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for ch in children):
            n['status']='CANDIDATE_COVER_CLOSED'
    dump(OUT/'MANIFEST.json',dict(schema='phase_only_complete_subtree_cover_v1',
        original_id=root['state']['id'],original_parent_index=42,
        source_manifest=str(HERE/'GRAFTED_MANIFEST.json'),source_manifest_sha256=digest(HERE/'GRAFTED_MANIFEST.json'),
        nodes=[nodes[k]for k in sorted(nodes)],pending=list(queue),
        subtree_candidate_closed=nodes[0]['status']=='CANDIDATE_COVER_CLOSED',
        calls=calls,previous_lp_calls=previous,total_lp_calls=calls+previous,cap=100,
        omitted_discovery_families=omitted,no_coordinate_bound_rounds=True,
        no_new_inequality_families=True,cut_caches_cleared_at_every_state=True,
        seconds=time.monotonic()-started,no_original_or_mask_credit=True))

split_node(0,A.state_from_view(root['state']),root_record);save()
while queue and calls<limit and time.monotonic()-started<300:
    idx=queue.popleft();node=nodes[idx];state=A.state_from_view(node['state']);before=time.monotonic()
    caches=clear_cuts();rows,bounds,physical,terminal=ctx.collect(state);collect_seconds=time.monotonic()-before
    note=dict(index=idx,depth=len(state['path'])-len(root['state']['path']),
              cleared_cache_sizes=caches,collect_seconds=collect_seconds)
    record=None
    if terminal:
        record=dict(status='CANDIDATE_CLOSED',initial=node['state'],rounds=[],terminal=terminal)
        note['lp_calls']=0
    else:
        h=A.E._full_highs(rows,len(bounds),True);h.setOptionValue('time_limit',5.0)
        calls+=1;h.run();note.update(lp_calls=1,rows=len(rows),variables=len(bounds))
        if h.getModelStatus()!=A.E.H.HighsModelStatus.kOptimal:
            record=dict(status='NO_NUMERICAL_CONCLUSION',initial=node['state'],rounds=[],diagnostic=str(h.getModelStatus()))
        else:
            solution=h.getSolution();phase=float(solution.col_value[-1]);point=list(map(float,solution.col_value[:-1]))
            if phase>1e-9:
                weights=A.E.terms(solution.row_dual);co,rhs=A.E.sum_rows(rows,bounds,weights)
                reserve=-rhs-sum(m*abs(v)for m,v in zip(bounds,co))
                if reserve>0:
                    record=dict(status='CANDIDATE_CLOSED',initial=node['state'],rounds=[],terminal_state=node['state'],
                        terminal=dict(kind='positive_exact_reserve',weights=weights,
                            rows=A.E.printed(rows,{i for i,w in weights}),absolute_variable_bounds=list(map(str,bounds)),
                            weighted_coefficients=list(map(str,co)),weighted_rhs=str(rhs),reserve=str(reserve)))
            if record is None:
                record=dict(status='OPEN',initial=node['state'],rounds=[],final=node['state'],
                    phase=phase,best_pairs=A.E.best_pairs(state,point),point=point)
    record['seconds']=time.monotonic()-before
    path=OUT/f'node_{idx:05}.json';dump(path,record)
    node.update(file=path.name,sha256=digest(path),status=record['status'])
    if record['status']=='OPEN':split_node(idx,state,record)
    note.update(status=record['status'],pending=len(queue),total_lp_calls=calls+previous,seconds=record['seconds'])
    node['discovery_timing']=note
    save();print(json.dumps(note),flush=True)
save()
print('FINISHED',len(nodes),'NODES',len(queue),'PENDING',calls+previous,'TOTAL_LP_CALLS',flush=True)
