"""Freeze only eight Cd402 terminals and their ten-record ancestry union."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,shutil,tarfile

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[3]
TARGET=REPO/'research/nine/computer_assisted/a2_00100_cd402_eight_terminal_delta_v1'
OLD=Path('/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/c_family')
OLD_REPO=OLD.parents[3]
STAGE=HERE/'tracked_payload_stage'
assert not (TARGET/'ARCHIVE_MANIFEST.json').exists()
TARGET.mkdir(parents=True,exist_ok=True);STAGE.mkdir(exist_ok=True)
P=STAGE/'payload';P.mkdir(exist_ok=True)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(src,dst):
    src,dst=Path(src),Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
    data=src.read_bytes();dst.write_bytes(data);assert sha(dst)==hashlib.sha256(data).hexdigest()
    return dict(original_path=str(src.resolve()),payload_path=str(dst.relative_to(P)),
                bytes=len(data),sha256=sha(dst))

source=json.loads((HERE/'SOURCE_MANIFEST.json').read_text())
nodes={n['index']:n for n in source['nodes']};pending={n['index']:n for n in source['pending']}
targets=[40,41,471,472,478,479,486,487]
needed=set();chains={}
for idx in targets:
    cur=pending[idx]['parent'];chain=[]
    while cur is not None:
        chain.append(cur);needed.add(cur);cur=nodes[cur]['parent']
    chains[str(idx)]=list(reversed(chain))
assert needed=={0,3,4,12,14,16,52,467,470,476}
bindings=dict(schema='Cd402_eight_terminal_native_delta_inputs_v1',
    original_id='negative-d4021ade840b985c',original_mask='001/00',
    target_indices=targets,ancestral_chains=chains,terminal_inputs={},ancestral_inputs={})
for idx in targets:
    bindings['terminal_inputs'][str(idx)]=copy(HERE/f'node_{idx:05}.json',P/'terminals'/f'node_{idx:05}.json')
old_hashes=json.loads((HERE/'INHERITED_NODE_SHA256.json').read_text())
for idx in sorted(needed):
    n=nodes[idx];src=Path(n.get('source_file',OLD/'cd402_dfs_cached_cavity'/n['file']))
    assert sha(src)==old_hashes[str(src.resolve())]
    bindings['ancestral_inputs'][str(idx)]=copy(src,P/'ancestry'/f'node_{idx:05}.json')
original=OLD/'cd402_checkpoint_delta/payload/d_work/cd402_work/other_masks_whole_original_bound3.json'
assert sha(original)=='3e416f74d97c2badf6d2de427b24f62066cf96b808fea39197275373c9e5ac7f'
bindings['original_bound_input']=copy(original,P/'ancestry/cd402_original_bound3.json')
old_report=json.loads((OLD/'CD402_CACHED_CAVITY_FRESH_PARTIAL_REPLAY.json').read_text())
registers=[Path(k)for k,v in old_report['input_sha256'].items()
    if k.endswith('original_register.json')and Path(k).is_relative_to(OLD)
    and v=='ea000e84c04675fe22424e5c20d3df9d735d659065349800aef2699170bff604']
assert len(registers)==1
bindings['original_register']=copy(registers[0],P/'ancestry/original_register.json')

for name in ('SOURCE_MANIFEST.json','GRAFTED_MANIFEST.json','INHERITED_NODE_SHA256.json',
             'NEW_TERMINALS_EXACT_REPLAY.json','NODE41_HAND_CANCELLATION.json',
             'SWEEP_SUMMARY.json','NODE40_EXACT_REPLAY.json'):
    copy(HERE/name,P/'evidence'/name)
for name in ('sweep_existing_rows.py','replay_and_graft_sweep.py','probe_old_ancestors.py',
             'phase_only_residual.py','prepare_tracked_checkpoint.py'):
    copy(HERE/name,P/'discovery_sources'/name)
copy(HERE/'ancestor_probe/SUMMARY.json',P/'diagnostics/OLD_ANCESTOR_PROBE.json')
copy(HERE/'phase_only_residual/STOP_RECEIPT.json',P/'diagnostics/STOPPED_BFS_RECEIPT.json')

runtime=dict(old_report['checker_dependency_sha256'])
for name in ('check_cd402_complete_cover.py','independent_c_general_rows_adapter.py',
             'independent_c_new_rows_adapter.py','independent_general_center_cone_rows.py',
             'independent_rotating_frame_center_rows.py'):
    src=OLD/name;runtime[str(src)]=sha(src)
runtime_bindings=[]
for name,digest in sorted(runtime.items()):
    src=Path(name);assert sha(src)==digest
    relative=src.relative_to(OLD.parent)
    item=copy(src,P/'runtime_source_snapshots'/relative)
    item['relative_to_native_runs_root']=str(relative)
    runtime_bindings.append(item)
write(P/'INPUT_BINDINGS.json',bindings)
native=dict(schema='hash_bound_native_runtime_dependency_v1',
    native_c_family_root=str(OLD),native_runs_root=str(OLD.parent),
    runtime_sources=runtime_bindings,
    boundary='The archive preserves source bytes but the replay imports these exact files from the retained native runtime. Published base inventories and accepted legacy input fixtures remain external. No cold transport is implemented by this delta.')
write(TARGET/'NATIVE_DEPENDENCIES.json',native)

public=[]
for package,commit in (
    ('a2_00100_cd402_fresh_original_checkpoint_v1','6c1284bdc822ee61fb830eeaa3be90459b6f0146'),
    ('c_original_height_consequences_v1','8e842e98a4f31fa9e0a2d8ece42bc2661a2783c2'),
):
    base=REPO/'research/nine/computer_assisted'/package
    entry=dict(package=package,commit=commit,metadata={})
    for name in ('README.md','PUBLICATION_MANIFEST.json','DELTA_MANIFEST.json','ARCHIVE_MANIFEST.json'):
        if (base/name).is_file():
            item=copy(base/name,P/'published_dependencies'/package/name)
            entry['metadata'][name]=item['sha256']
    public.append(entry)
dependencies=dict(schema='Cd402_eight_terminal_external_dependencies_v1',published_packages=public,
    cd402_delta_archive_sha256='ac370a5d945796f2566263d0733ce330eaabc7c816a2043ae5128750697de650',
    cd402_assembled_input_manifest_sha256='ac8b7793e1c69242c8df85a28596e3143b1f54e605368c097198444e8002f51c',
    c_height_delta_archive_sha256='d17d9582e5ebfdde535be70dea47853d5a8d2fa4b0bddc0a287b35255caa745b',
    c_height_assembled_input_manifest_sha256='06115f494173bc344821932525d7a8522df8ea2ed80b400f735f3b68d4a1b58b',
    additional_original_specific_height_theorem_used=False,
    preserved_terminal_records=8,preserved_ancestral_records=10,
    preserved_original_bound_record=True,preserved_original_register=True,
    unbundled_native_legacy_fixture_and_import_transport=True,
    cold_standalone_proof=False,whole_original_excluded=False,new_original_cells=0,new_masks=0)
write(TARGET/'DEPENDENCIES.json',dependencies)
shutil.copyfile(HERE/'HAND_TABLE.md',TARGET/'HAND_TABLE.md')
assert sha(HERE/'HAND_TABLE.md')==sha(TARGET/'HAND_TABLE.md')
inventory={str(p.relative_to(P)):sha(p)for p in sorted(P.rglob('*'))if p.is_file()}
write(TARGET/'PAYLOAD_SHA256.json',inventory)
archive=TARGET/'cd402_eight_terminal_delta_v1.tar.xz'
with tarfile.open(archive,'w:xz',preset=6)as tar:
    for path in sorted(P.rglob('*')):
        if not path.is_file():continue
        info=tar.gettarinfo(str(path),arcname='payload/'+str(path.relative_to(P)))
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
        with path.open('rb')as f:tar.addfile(info,f)
manifest=dict(schema='Cd402_eight_terminal_delta_archive_v1',archive=archive.name,
    sha256=sha(archive),bytes=archive.stat().st_size,regular_members=len(inventory),
    uncompressed_bytes=sum(p.stat().st_size for p in P.rglob('*')if p.is_file()),
    inventory='PAYLOAD_SHA256.json',inventory_sha256=sha(TARGET/'PAYLOAD_SHA256.json'),
    new_original_cells=0,new_masks=0)
write(TARGET/'ARCHIVE_MANIFEST.json',manifest)
print(json.dumps(manifest),flush=True)
