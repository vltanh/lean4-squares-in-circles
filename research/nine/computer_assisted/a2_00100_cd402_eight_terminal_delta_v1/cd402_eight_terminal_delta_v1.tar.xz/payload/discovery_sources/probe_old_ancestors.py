"""At most seven phase-only checks of old broad internal Cd402 nodes.

The current row families are reused unchanged. A new terminal on a saved
final state is joined to that record's already-existing bound rounds.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
import sys,json,time,hashlib
HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/c_family')
sys.path.insert(0,str(OLD))
import c_cached_general_runtime as A
OUT=HERE/'ancestor_probe';OUT.mkdir(exist_ok=False)
manifest=json.loads((HERE/'SOURCE_MANIFEST.json').read_text())
nodes=[n for n in manifest['nodes'] if n['depth']<=2 and n['status']=='OPEN']
assert len(nodes)<=7
ctx=A.Context();reports=[];started=time.monotonic()
for n in nodes:
    source=Path(n.get('source_file',OLD/'cd402_dfs_cached_cavity'/n['file']))
    raw=source.read_bytes();previous=json.loads(raw)
    assert previous['status']=='OPEN'
    state=A.state_from_view(previous['final'])
    before=time.monotonic();rows,bounds,physical,terminal=ctx.collect(state)
    collect_seconds=time.monotonic()-before
    if terminal:
        record=dict(previous,status='CANDIDATE_CLOSED',terminal=terminal)
        report=dict(index=n['index'],status='CANDIDATE_CLOSED',lp_calls=0)
    else:
        h=A.E._full_highs(rows,len(bounds),True)
        h.setOptionValue('time_limit',12.0);h.run()
        report=dict(index=n['index'],lp_calls=1,rows=len(rows),
                    collect_seconds=collect_seconds,solver=str(h.getModelStatus()))
        record=None
        if h.getModelStatus()!=A.E.H.HighsModelStatus.kOptimal:
            report['status']='NO_NUMERICAL_CONCLUSION'
        else:
            sol=h.getSolution();phase=float(sol.col_value[-1]);report['phase']=phase
            report['status']='OPEN'
            if phase>1e-9:
                weights=A.E.terms(sol.row_dual);co,rhs=A.E.sum_rows(rows,bounds,weights)
                reserve=-rhs-sum(m*abs(v)for m,v in zip(bounds,co))
                if reserve>0:
                    terminal=dict(kind='positive_exact_reserve',weights=weights,
                        rows=A.E.printed(rows,{i for i,w in weights}),
                        absolute_variable_bounds=list(map(str,bounds)),
                        weighted_coefficients=list(map(str,co)),weighted_rhs=str(rhs),reserve=str(reserve))
                    record=dict(status='CANDIDATE_CLOSED',initial=previous['initial'],
                        rounds=previous['rounds'],terminal_state=previous['final'],terminal=terminal)
                    report.update(status='CANDIDATE_CLOSED',reserve=str(reserve))
            if record is None:
                point=list(map(float,sol.col_value[:-1]));record=dict(previous,
                    phase=phase,best_pairs=A.E.best_pairs(state,point),point=point)
    report.update(source_record=str(source),source_sha256=hashlib.sha256(raw).hexdigest(),
                  seconds=time.monotonic()-before)
    if record is not None:
        dest=OUT/f"node_{n['index']:05}.json"
        dest.write_text(json.dumps(record,indent=2)+'\n')
        report.update(file=dest.name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
    reports.append(report)
    (OUT/'SUMMARY.json').write_text(json.dumps(dict(results=reports,
        lp_calls=sum(r['lp_calls']for r in reports),seconds=time.monotonic()-started,
        no_original_or_mask_credit=True),indent=2)+'\n')
    print(json.dumps(report),flush=True)
print('FINISHED',flush=True)
