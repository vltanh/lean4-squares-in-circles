"""Exact local terminal replay and complete-frontier graft of phase sweep.

All inherited old nodes and every unfinished sibling remain present. This
performs fresh independent arithmetic on newly excluded leaves only; it does
not describe inherited arithmetic as freshly replayed.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from copy import deepcopy
from itertools import product
import sys,json,hashlib,time
HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/c_family')
sys.path.insert(0,str(OLD));sys.path.insert(0,str(OLD/'source/ac_work/tree'))
import independent_c_general_rows_adapter as EXT
import check_cd402_complete_cover as CHECK

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')

started=time.monotonic()
source_raw=(HERE/'SOURCE_MANIFEST.json').read_bytes()
source=json.loads(source_raw)
summary=json.loads((HERE/'SWEEP_SUMMARY.json').read_text())
assert summary['source_manifest_sha256']==hashlib.sha256(source_raw).hexdigest()
checker=CHECK.BASE.Checker()
adapter=EXT.extend_adapter(CHECK.Adapter,allow_rotating=True)(checker)
CHECK.BASE.verify_all_bindings()
box=lambda v:tuple(tuple(map(F,ab))for ab in v)
def state_from_view(v):
    return dict(id=v['id'],path=v['path'],choices=adapter.choices(v['path']),
        angles=box(v['angles']),positions=box(v['positions']),scalar=box(v['scalar']),
        differences={tuple(r['pair']):box(r['intervals'])for r in v['differences']},
        diagonal={tuple(r['pair']):box(r['intervals'])for r in v['diagonal']})

pending={n['index']:n for n in source['pending']}
nodes={n['index']:deepcopy(n)for n in source['nodes']}
assert len(pending)==len(source['pending'])and len(nodes)==len(source['nodes'])
assert not(set(pending)&set(nodes))
inherited={}
for n in nodes.values():
    path=Path(n.get('source_file',OLD/'cd402_dfs_cached_cavity'/n['file'])).resolve()
    n['source_file']=str(path)
    inherited[str(path)]=sha(path)
audits=[]
for result in summary['results']:
    if result['status']!='CANDIDATE_CLOSED':continue
    idx=result['index'];item=pending[idx]
    path=HERE/result['file'];raw=path.read_bytes();record=json.loads(raw)
    assert sha(path)==result['sha256']
    assert record['initial']==item['state']
    audit,after=CHECK.CORE.check_record(record,state_from_view(item['state']),adapter)
    assert after is None
    audits.append(dict(index=idx,record=path.name,sha256=sha(path),audit=audit))
    nodes[idx]=dict(index=idx,parent=item['parent'],edge=item['edge'],
        depth=len(item['state']['path'])-3,file=path.name,source_file=str(path),status='CANDIDATE_CLOSED')
    del pending[idx]
    print('REPLAYED',idx,audit['status'],audit['printed_rows_checked'],flush=True)

CLOSED={'CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED'}
for idx in sorted(nodes,key=lambda k:nodes[k]['depth'],reverse=True):
    n=nodes[idx];children=n.get('split',{}).get('children',[])
    if children and all(ch in nodes and nodes[ch]['status']in CLOSED for ch in children):
        n['status']='CANDIDATE_COVER_CLOSED'

# Structural identity and exact complete child alternatives are verified here.
# Inherited arithmetic remains explicitly reused, not freshly rerun.
visited=set();frontier=set();covered=[]
stopped={n['index']:n for n in source['stopped']}
def edge_key(e):
    if e is None:return None
    if e['kind']in('proxy','sat'):return e['kind'],tuple(e['pair']),tuple(e['choice'])
    return 'angle',e['owner'],F(e['cut']),e['choice']
def visit(idx,parent=None,edge=None):
    if idx in pending:
        n=pending[idx];assert idx not in frontier
        assert n['parent']==parent and edge_key(n['edge'])==edge_key(edge)
        frontier.add(idx);return
    assert idx in nodes and idx not in visited
    n=nodes[idx];visited.add(idx)
    assert n['parent']==parent and edge_key(n['edge'])==edge_key(edge)
    children=n.get('split',{}).get('children',[])
    if not children:
        assert n['status']=='CANDIDATE_CLOSED' or idx in stopped
        return
    split=n['split'];entries=[nodes.get(ch,pending.get(ch))for ch in children]
    assert len(children)==len(set(children))and all(entries)
    edges=[e['edge']for e in entries];kind=split['kind']
    if kind in('sat','proxy'):
        pair=tuple(split['pair'])
        expect=set(product(pair,(0,1),(-1,1)))if kind=='sat'else set(product((0,1),(-1,1)))
        actual=[tuple(e['choice'])for e in edges]
        assert len(actual)==len(set(actual))==len(expect)and set(actual)==expect
        assert all(e['kind']==kind and tuple(e['pair'])==pair for e in edges)
    else:
        assert kind=='angle'and len(edges)==2
        assert {e['choice']for e in edges}=={0,1}
        assert all(e['kind']==kind and e['owner']==split['owner']and F(e['cut'])==F(split['cut'])for e in edges)
    covered.append(idx)
    for child,e in zip(children,edges):visit(child,idx,e)
visit(0)
assert visited==set(nodes)and frontier==set(pending)
assert set(nodes)==set(n['index']for n in source['nodes'])|set(a['index']for a in audits)
assert set(pending)==set(n['index']for n in source['pending'])-set(a['index']for a in audits)
for path,digest in inherited.items():assert sha(path)==digest
EXT.no_producers()
out=dict(source,source_manifest=dict(path=str(HERE/'SOURCE_MANIFEST.json'),
    sha256=hashlib.sha256(source_raw).hexdigest()),nodes=sorted(nodes.values(),key=lambda n:n['index']),
    pending=sorted(pending.values(),key=lambda n:n['index']),
    whole_candidate_closed=nodes[0]['status']in CLOSED,
    closed_leaves=sum(n['status']=='CANDIDATE_CLOSED'for n in nodes.values()),
    phase_only_graft=dict(new_excluded_indices=[a['index']for a in audits],
        no_new_splits=True,all_old_nodes_retained=True,all_unfinished_alternatives_retained=True))
dump(HERE/'GRAFTED_MANIFEST.json',out)
dump(HERE/'INHERITED_NODE_SHA256.json',inherited)
report=dict(status='PASS_NEW_TERMINALS_AND_COMPLETE_FRONTIER_GRAFT',
    source_manifest_sha256=hashlib.sha256(source_raw).hexdigest(),
    grafted_manifest_sha256=sha(HERE/'GRAFTED_MANIFEST.json'),
    new_excluded=len(audits),new_exact_terminal_audits=audits,
    new_printed_rows_checked=sum(a['audit']['printed_rows_checked']for a in audits),
    inherited_nodes=len(source['nodes']),inherited_arithmetic_replayed=False,
    complete_child_covers_checked=len(covered),pending_before=len(source['pending']),
    pending_after=len(pending),original_ancestry_replayed=False,
    whole_original_closed=False,new_original_cells=0,new_masks=0,
    numerical_producers_imported=False,seconds=time.monotonic()-started)
dump(HERE/'NEW_TERMINALS_EXACT_REPLAY.json',report)
print(json.dumps({k:v for k,v in report.items()if k!='new_exact_terminal_audits'}),flush=True)
