"""Bounded, phase-only discovery on broad Cd402 siblings.

Imports the existing immutable mathematical row code read-only. No coordinate
bound rounds, no background continuation, no new inequality families, and no
modification of the concurrently running old tree. Each solve uses the full
existing static row list rather than an adaptive ActiveHighs loop, so the
printed LP count is the actual solver invocation count.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import sys, json, time, hashlib
from fractions import Fraction as F
from itertools import combinations, product
from math import hypot

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/c_family')
sys.path.insert(0, str(SOURCE))
import c_cached_general_runtime as A
import c_cavity_split_policy as POLICY

MAX_CALLS = 100
LP_SECONDS = 12
TOTAL_SECONDS = 600

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)

def diagnostics(state, point, record):
    corners = []
    frames = []
    for i, (lo, hi) in enumerate(state['angles']):
        a, b = point[18+i], point[27+i]
        norm = hypot(a, b)
        if norm <= 1e-12:
            continue
        x, y = point[2*i], point[2*i+1]
        an, bn = a/norm, b/norm
        excess = max((x+(e*an-t*bn)/2)**2+(y+(e*bn+t*an)/2)**2-1105/256
                     for e, t in product((-1,1), repeat=2))
        corners.append(dict(owner=i, excess=excess, angle_width=float(hi-lo)))
        frames.append(dict(owner=i, norm_defect=1-a*a-b*b,
                           abs_defect=point[36+i]-abs(b),
                           angle_width=float(hi-lo)))
    corners.sort(key=lambda r: -r['excess'])
    frames.sort(key=lambda r: -max(r['norm_defect'], r['abs_defect']))
    return dict(corners=corners[:4], frames=frames[:4],
                pair_gaps=A.E.best_pairs(state, point, 8),
                existing_policy=POLICY.choose(state, point, record))

source_manifest = SOURCE/'cd402_dfs_cached_cavity/MANIFEST.json'
raw = source_manifest.read_bytes()
manifest = json.loads(raw)
assert manifest['original']['id'] == 'negative-d4021ade840b985c'
(HERE/'SOURCE_MANIFEST.json').write_bytes(raw)
pending = manifest['pending']
assert pending
# The live DFS pops the end. Leave its current continuation branch untouched.
excluded_current = pending[-1]['index']
candidates = sorted(pending[:-1], key=lambda n:(len(n['state']['path']), n['index']))
ctx = A.Context()
started = time.monotonic()
calls = 0
results = []
inputs = dict(A.sources())
inputs[str(Path(__file__).resolve())] = sha(__file__)

def save_summary():
    dump(HERE/'SWEEP_SUMMARY.json', dict(
        schema='cd402_broad_sibling_existing_row_phase_sweep_v1',
        original_id=manifest['original']['id'],
        source_manifest=str(source_manifest),
        source_manifest_sha256=hashlib.sha256(raw).hexdigest(),
        skipped_current_dfs_index=excluded_current,
        initial_pending=len(pending), calls=calls, call_cap=MAX_CALLS,
        elapsed_seconds=time.monotonic()-started, results=results,
        source_sha256=inputs, whole_original_closed=False,
        exact_original_replay_pending=True, no_original_or_mask_credit=True))

save_summary()
for item in candidates:
    if calls >= MAX_CALLS or time.monotonic()-started > TOTAL_SECONDS:
        break
    index = item['index']
    state = A.state_from_view(item['state'])
    initial = A.stateview(state)
    node_started = time.monotonic()
    rows, bounds, physical, terminal = ctx.collect(state)
    if terminal:
        record = dict(status='CANDIDATE_CLOSED', initial=initial, rounds=[],
                      terminal=terminal, seconds=time.monotonic()-node_started)
        result = dict(index=index, status=record['status'], lp_calls=0,
                      terminal_kind=terminal['kind'], depth=len(state['path'])-3)
    else:
        h = A.E._full_highs(rows, len(bounds), True)
        h.setOptionValue('time_limit', LP_SECONDS)
        calls += 1
        h.run()
        result = dict(index=index, depth=len(state['path'])-3,
                      lp_calls=1, rows=len(rows), variables=len(bounds),
                      solver_status=str(h.getModelStatus()))
        if h.getModelStatus() != A.E.H.HighsModelStatus.kOptimal:
            record = dict(status='NO_NUMERICAL_CONCLUSION', initial=initial,
                          rounds=[], diagnostic=result['solver_status'])
            result['status'] = record['status']
        else:
            sol = h.getSolution()
            phase = float(sol.col_value[-1])
            point = list(map(float,sol.col_value[:-1]))
            terminal = None
            if phase > 1e-9:
                weights = A.E.terms(sol.row_dual)
                co, rhs = A.E.sum_rows(rows,bounds,weights)
                correction = sum(m*abs(v) for m,v in zip(bounds,co))
                reserve = -rhs-correction
                if reserve > 0:
                    terminal = dict(kind='positive_exact_reserve',weights=weights,
                        rows=A.E.printed(rows,{i for i,w in weights}),
                        absolute_variable_bounds=list(map(str,bounds)),
                        weighted_coefficients=list(map(str,co)),
                        weighted_rhs=str(rhs),reserve=str(reserve))
            if terminal:
                record = dict(status='CANDIDATE_CLOSED',initial=initial,rounds=[],
                              terminal_state=initial,terminal=terminal)
                result.update(status=record['status'],phase=phase,
                              terminal_kind=terminal['kind'], reserve=terminal['reserve'])
            else:
                record = dict(status='OPEN',initial=initial,rounds=[],final=initial,
                              phase=phase,best_pairs=A.E.best_pairs(state,point),point=point)
                result.update(status='OPEN',phase=phase,
                              diagnostics=diagnostics(state,point,record))
    record['seconds'] = time.monotonic()-node_started
    filename = f'node_{index:05}.json'
    dump(HERE/filename,record)
    result.update(file=filename,sha256=sha(HERE/filename),seconds=record['seconds'])
    results.append(result)
    save_summary()
    print(json.dumps({k:v for k,v in result.items() if k not in ('diagnostics','sha256')}),flush=True)
print('FINISHED',calls,'LP_CALLS',len(results),'SIBLINGS',round(time.monotonic()-started,2),'SECONDS',flush=True)
