#!/usr/bin/env python3
"""Independent Gram-tree replay with both accepted sharp row terminal families."""
from pathlib import Path
from fractions import Fraction as F
from contextlib import redirect_stdout
import argparse,importlib.util,io,json,sys
import verify_c887_gram_physical_tree as GRAM
import independent_shared_sharp_terminal as SHARP
import accepted_oriented_cap as CAP

OLD=GRAM.CAPTREE.OLD
PKG=OLD.PKG
FULL=CAP.PACKET
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod);return mod
FULLGUARD=load('ac_checked_full_angle_guard',FULL/'full_angle_common_side_four_row_guard.py')
_checker=None

class Checker(GRAM.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.sharp_binding=SHARP.verify_binding(PKG)
        self.sharp_terminal_occurrences=0;self.full_angle_terminal_occurrences=0
        self.full_angle_theorem=None;_checker=self

class Adapter(GRAM.Adapter):
    def verify_early_terminal(self,state,terminal):
        if terminal['kind']not in('accepted_shared_sharp_boundary_terminal','accepted_full_angle_AHID_terminal'):
            return super().verify_early_terminal(state,terminal)
        assert self.K.V.Q==F(1105,256)
        assert self.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
        _,_,pos,scalar,diff,_=self.K.rebuild(state['path'],state['angles'],state['positions'],
            state['choices'],state['scalar'],state['differences'])
        physical=dict(state,positions=pos,scalar=scalar,differences=diff)
        if terminal['kind']=='accepted_shared_sharp_boundary_terminal':
            SHARP.verify_literal(terminal['guard'],physical)
            self.checker.sharp_terminal_occurrences+=1
            return True
        actual=FULLGUARD.evaluate(physical)
        assert actual['status']=='PASS_FULL_ANGLE_AHID_TERMINAL'and actual==terminal['guard']
        CAP.verify_binding()
        if self.checker.full_angle_theorem is None:
            # The accepted physical lifting uses this exact same-sign scalar
            # cover, the old opposite-sign scalar cover, and the endpoint toll.
            same=load('ac_exact_same_sign_row_cover',FULL/'same_sign_row/check_same_sign_cover.py')
            opp=load('ac_exact_opposite_row_cover',PKG/'opposite_tilt_theorem/verify_chiral_cover.py')
            with redirect_stdout(io.StringIO()):
                s=same.run(FULL/'same_sign_row/cover');o=opp.run(PKG/'opposite_tilt_theorem/cover')
            assert (s['complete_domains'],s['leaves'],s['coefficient_checks'],s['frontier'])==(80,892,557500,0)
            assert (o['complete_domains'],o['leaves'],o['coefficient_checks'],o['frontier'])==(80,1405,878125,0)
            self.checker.full_angle_theorem=dict(same_sign=s,opposite_sign=o,endpoint_toll=CAP.ensure_proof(),
                accepted_binding_sha256=CAP.BINDING_SHA)
        self.checker.full_angle_terminal_occurrences+=1
        return True

OLD.Checker=Checker;OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=GRAM.replay(parent,tree,output);assert _checker is not None
    report.update(shared_sharp_terminal_occurrences_checked=_checker.sharp_terminal_occurrences,
        shared_sharp_terminal_binding=_checker.sharp_binding,
        full_angle_terminal_occurrences_checked=_checker.full_angle_terminal_occurrences,
        full_angle_terminal_theorem_replay=_checker.full_angle_theorem)
    for p in(__file__,SHARP.__file__,FULLGUARD.__file__):
        report['checker_dependency_sha256'][str(Path(p).resolve())]=OLD.sha(p)
    SHARP.verify_binding(PKG);CAP.verify_binding()
    assert 'ac_physical_all_guards_runtime'not in sys.modules
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('tree',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.parent,a.tree,a.output)
