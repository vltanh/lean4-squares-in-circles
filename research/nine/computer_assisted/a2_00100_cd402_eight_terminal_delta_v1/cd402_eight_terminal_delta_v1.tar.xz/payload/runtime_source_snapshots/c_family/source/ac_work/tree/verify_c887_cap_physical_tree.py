#!/usr/bin/env python3
"""Extend the independent C887 cover replay by the reviewed pair-cap rows."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys
import verify_c887_ownerfree_physical_tree as OLD
import accepted_oriented_cap as CAP

_checker=None
class Checker(OLD.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.cap_occurrences=0;self.cap_theorem=None
        self.cap_binding=CAP.verify_binding();_checker=self

class Adapter(OLD.Adapter):
    def rebuild(self,state,printed):
        ordinary=[r for r in printed if not r['name'].startswith('oriented_good_pair_cap_')]
        answer,bounds,propagated=super().rebuild(state,ordinary)
        extra=[r for r in printed if r['name'].startswith('oriented_good_pair_cap_')]
        if extra:
            self.checker.cap_theorem=CAP.ensure_proof()
            allowed={r[2]:r for r in CAP.rows(propagated['angles'],propagated['scalar'],propagated['differences'])[0]}
            for r in extra:
                literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name'])
                assert r['name']in allowed and literal==allowed[r['name']]
                assert r['index']not in answer
                answer[r['index']]=literal;self.checker.cap_occurrences+=1
        return answer,bounds,propagated

OLD.Checker=Checker;OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=OLD.replay(parent,tree,output)
    assert _checker is not None
    report['oriented_cap_occurrences_checked']=_checker.cap_occurrences
    report['oriented_cap_theorem_replay']=_checker.cap_theorem
    CAP.verify_binding()
    for p in(__file__,CAP.__file__,CAP.LITERAL.__file__,CAP.TOLL.__file__):
        report['checker_dependency_sha256'][str(Path(p).resolve())]=OLD.sha(p)
    report['accepted_oriented_cap_premise_binding_sha256']=CAP.BINDING_SHA
    assert not any(n in sys.modules for n in('ac_physical_context_caps','ac_oriented_cap_discovery','physical_preflight'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('tree',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.parent,a.tree,a.output)
