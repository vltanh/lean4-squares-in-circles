#!/usr/bin/env python3
"""Independent original-C cover replay including accepted literal ABID."""
from pathlib import Path
from fractions import Fraction as F
from contextlib import redirect_stdout
import argparse,io,json,sys
import verify_c887_all_guards_physical_tree as BASE
import independent_opposite_abid_row_guard as ABID

HERE=Path(__file__).resolve().parent
BINDING=HERE/'OPPOSITE_ABID_PREMISE_BINDINGS.json'
BINDING_SHA='f03bf03f9ef8941c93c3999f8076cb7e4a4b7eb66e9b00c0de289c6f7c5cb78d'
_checker=None

def verify_binding():
    assert BASE.OLD.sha(BINDING)==BINDING_SHA
    binding=json.loads(BINDING.read_text())
    assert binding['q']=='1105/256'and binding['physical_row']==[0,1,8,3]
    assert binding['selected_distinct_originals']==[0,1,8,3,4,5,6]
    assert len(set(binding['selected_distinct_originals']))==7
    assert binding['unchanged_originals']==list(range(9))and binding['original_mask']=='001/00'
    assert binding['original_edges']==[[0,1,0],[1,2,0],[2,3,1],[4,5,0],[5,6,0]]
    for name,h in binding['files'].items():assert BASE.OLD.sha(HERE/name)==h
    return dict(ABID.verify_binding(BASE.PKG),binding_sha256=BINDING_SHA)

class Checker(BASE.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.opposite_abid_binding=verify_binding()
        self.opposite_abid_terminal_occurrences=0;_checker=self

class Adapter(BASE.Adapter):
    def verify_early_terminal(self,state,terminal):
        if terminal['kind']!='accepted_opposite_tilt_ABID_terminal':
            return super().verify_early_terminal(state,terminal)
        assert self.K.V.Q==F(1105,256)
        assert self.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
        _,_,pos,scalar,diff,_=self.K.rebuild(state['path'],state['angles'],state['positions'],
            state['choices'],state['scalar'],state['differences'])
        ABID.verify_literal(terminal['guard'],dict(state,positions=pos,scalar=scalar,differences=diff))
        verify_binding()
        if self.checker.opposite_theorem_report is None:
            root=BASE.PKG/'opposite_tilt_theorem'
            module=BASE.load('ac_opposite_abid_complete_scalar_replay',root/'verify_chiral_cover.py')
            with redirect_stdout(io.StringIO()):report=module.run(root/'cover')
            assert (report['complete_domains'],report['leaves'],report['coefficient_checks'],report['frontier'])==(80,1405,878125,0)
            self.checker.opposite_theorem_report=report
        self.checker.opposite_abid_terminal_occurrences+=1
        return True

BASE.OLD.Checker=Checker;BASE.OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=BASE.replay(parent,tree,output);assert _checker is not None
    report.update(opposite_ABID_terminal_occurrences_checked=_checker.opposite_abid_terminal_occurrences,
        opposite_ABID_terminal_binding=_checker.opposite_abid_binding)
    for p in(__file__,ABID.__file__,BINDING):report['checker_dependency_sha256'][str(Path(p).resolve())]=BASE.OLD.sha(p)
    verify_binding();assert not any(n in sys.modules for n in('ac_physical_all_guards_v2','opposite_abid_row_guard'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('tree',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.parent,a.tree,a.output)
