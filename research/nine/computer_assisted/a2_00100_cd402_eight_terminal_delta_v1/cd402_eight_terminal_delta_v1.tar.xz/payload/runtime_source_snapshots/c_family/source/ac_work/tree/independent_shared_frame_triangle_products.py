"""Independent literal reconstruction of same-frame SAT triangle products."""
from fractions import Fraction as F

def decode(choices,ordinal,coordinate):
    selected=[(tuple(pair),tuple(choice))for pair,kind,choice in choices if kind=='sat']
    assert 0<=ordinal<len(selected)and coordinate in(0,1)
    (i,j),(owner,axis,sign)=selected[ordinal]
    assert 0<=i<j<9 and owner in(i,j)and axis in(0,1)and sign in(-1,1)
    # Reconstruct the actual normal component independently as a signed
    # original frame scalar. The stored product is this component*(cj-ci).
    normal=(((18+owner,sign),(27+owner,sign))if axis==0 else
            ((27+owner,-sign),(18+owner,sign)))[coordinate]
    frame,multiplier=normal
    other=(i+j-owner);orientation=1 if other>owner else-1
    return owner,other,frame,multiplier*orientation,54+6*ordinal+coordinate

def rebuild(name,choices,scalar,differences,diagonal=None):
    tokens=name.split('_');assert tokens[:3]==['sat','triangle','product']and len(tokens)==7
    first,second,coordinate,case=map(int,tokens[3:]);assert first!=second and 0<=case<8
    a=decode(choices,first,coordinate);b=decode(choices,second,coordinate)
    assert a[0]==b[0]and a[2]==b[2]and (a[1],first)<(b[1],second)
    # w = scalar*(c_other_b-c_other_a), using the original product identities.
    w={b[4]:F(b[3]),a[4]:-F(a[3])}
    if a[1]==b[1]:
        assert case in(6,7);sg=1 if case==6 else-1
        return tuple(sorted((k,sg*v)for k,v in w.items()if v)),F(0),name
    assert case<6
    lo_x,hi_x=map(F,scalar[a[2]-18]);lo_y,hi_y=map(F,differences[a[1],b[1]][coordinate])
    assert lo_x<=hi_x and lo_y<=hi_y
    if case in(4,5):
        products=(lo_x*lo_y,lo_x*hi_y,hi_x*lo_y,hi_x*hi_y)
        sg=1 if case==4 else-1;rhs=max(products)if case==4 else-min(products)
        return tuple(sorted((k,sg*v)for k,v in w.items()if v)),rhs,name
    # Expand one of four manifestly nonnegative products:
    # (x-lx)(y-ly), (ux-x)(uy-y), (ux-x)(y-ly), (x-lx)(uy-y).
    endpoint_x=(lo_x,hi_x,hi_x,lo_x)[case]
    endpoint_y=(lo_y,hi_y,lo_y,hi_y)[case]
    wsign=-1 if case<2 else 1
    coefficients={k:wsign*v for k,v in w.items()}
    coefficients[a[2]]=coefficients.get(a[2],F(0))-wsign*endpoint_y
    for k,v in((2*b[1]+coordinate,F(1)),(2*a[1]+coordinate,F(-1))):
        coefficients[k]=coefficients.get(k,F(0))-wsign*endpoint_x*v
    rhs=-wsign*endpoint_x*endpoint_y
    return tuple((k,v)for k,v in sorted(coefficients.items())if v),rhs,name

def verify_literal(row,choices,scalar,differences,diagonal=None):
    actual=rebuild(row[2],choices,scalar,differences,diagonal)
    coefficients={}
    for k,v in row[0]:coefficients[k]=coefficients.get(k,F(0))+F(v)
    claimed=tuple((k,v)for k,v in sorted(coefficients.items())if v),F(row[1]),row[2]
    assert claimed==actual
    return True
