#!/usr/bin/env python3
"""Independent replay of physical trees with either-extra actual-AB terminal."""
from pathlib import Path
from fractions import Fraction as F
import argparse,importlib.util,json,sys
import verify_c887_all_guards_v2 as BASE
import verify_ac_two_link_complement as TWO

PACKET=Path(__file__).resolve().parent.parent/'actual_ab_extra_guard'
BINDING_SHA='1217223d16f854c8f97b15befa954e9465d5ff943b7f87037c87bae766d5bf68'
OLD=BASE.BASE.OLD
spec=importlib.util.spec_from_file_location('ac_independent_actual_AB_any_extra',PACKET/'independent_actual_ab_any_extra_guard.py')
GUARD=importlib.util.module_from_spec(spec);spec.loader.exec_module(GUARD)
_checker=None

def verify_binding():
    assert OLD.sha(PACKET/'PREMISE_BINDINGS.json')==BINDING_SHA
    b=json.loads((PACKET/'PREMISE_BINDINGS.json').read_text())
    assert b['source_premise_binding_sha256']==TWO.BINDING_SHA
    assert b['permitted_extra_originals']==[7,8]and b['original_mask']=='001/00'
    for name,h in b['source_sha256'].items():assert OLD.sha(PACKET/name)==h
    TWO.binding()
    return dict(binding_sha256=BINDING_SHA,source_theorem_binding_sha256=TWO.BINDING_SHA,
        selected_extra_originals=[7,8],all_nine_originals_retained=True,strict_CD_closed_Q_blocker_retained=True)

class Checker(BASE.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.actual_ab_extra_binding=verify_binding()
        self.actual_ab_extra_terminal_occurrences=0;self.actual_ab_scalar_report=None;_checker=self

class Adapter(BASE.Adapter):
    def verify_early_terminal(self,state,terminal):
        if terminal['kind']!='accepted_actual_AB_any_extra_terminal':
            return super().verify_early_terminal(state,terminal)
        assert self.K.V.Q==F(1105,256)
        assert self.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
        _,_,pos,scalar,diff,_=self.K.rebuild(state['path'],state['angles'],state['positions'],
            state['choices'],state['scalar'],state['differences'])
        GUARD.verify_literal(terminal['guard'],dict(state,positions=pos,scalar=scalar,differences=diff))
        verify_binding()
        if self.checker.actual_ab_scalar_report is None:self.checker.actual_ab_scalar_report=TWO.scalar_proof()
        self.checker.actual_ab_extra_terminal_occurrences+=1
        return True

OLD.Checker=Checker;OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=BASE.replay(parent,tree,output);assert _checker is not None
    report.update(actual_AB_either_extra_terminal_occurrences_checked=_checker.actual_ab_extra_terminal_occurrences,
        actual_AB_either_extra_binding=_checker.actual_ab_extra_binding,
        actual_AB_either_extra_scalar_replay=_checker.actual_ab_scalar_report)
    for p in(__file__,GUARD.__file__,TWO.__file__,PACKET/'PREMISE_BINDINGS.json'):
        report['checker_dependency_sha256'][str(Path(p).resolve())]=OLD.sha(p)
    verify_binding();assert not any(n in sys.modules for n in('ac_physical_all_guards_v3','actual_ab_any_extra_guard','accepted_actual_ab_guard'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('tree',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.parent,a.tree,a.output)
