#!/usr/bin/env python3
"""Independent direct expansion of accepted original-corner support planes."""
from pathlib import Path
from fractions import Fraction as F
import argparse,importlib.util,json,sys
import verify_c887_all_guards_v3 as BASE

PACKET=Path(__file__).resolve().parent.parent/'adaptive_corner_disk'
BINDING_SHA='413cec6bd90907e25002a0a08a34924c7de79e8179ac733ddb45b16a6f1d2271'
OLD=BASE.OLD
spec=importlib.util.spec_from_file_location('ac_independent_corner_disk_literal',PACKET/'independent_physical_corner_disk_rows.py')
RULE=importlib.util.module_from_spec(spec);spec.loader.exec_module(RULE)
_checker=None

def verify_binding():
    assert OLD.sha(PACKET/'PREMISE_BINDINGS.json')==BINDING_SHA
    b=json.loads((PACKET/'PREMISE_BINDINGS.json').read_text())
    assert b['q']=='1105/256'and b['number_of_originals']==9 and b['number_of_original_corners']==36
    assert b['original_variables']==54 and b['new_auxiliary_variables']==0 and b['additional_interval_or_separator_premises']is False
    for name,h in b['source_sha256'].items():assert OLD.sha(PACKET/name)==h
    return dict(binding_sha256=BINDING_SHA,original_corners=36,no_extra_hypotheses=True)

class Checker(BASE.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.corner_binding=verify_binding();self.corner_row_occurrences=0;_checker=self

class Adapter(BASE.Adapter):
    def rebuild(self,state,printed):
        ordinary=[r for r in printed if not r['name'].startswith(RULE.PREFIX)]
        answer,bounds,physical=super().rebuild(state,ordinary)
        assert self.K.V.Q==F(1105,256)
        for r in printed:
            if not r['name'].startswith(RULE.PREFIX):continue
            literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name'])
            RULE.verify_literal(literal);assert r['index']not in answer
            answer[r['index']]=literal;self.checker.corner_row_occurrences+=1
        return answer,bounds,physical

OLD.Checker=Checker;OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=BASE.replay(parent,tree,output);assert _checker is not None
    report.update(original_corner_disk_row_occurrences_checked=_checker.corner_row_occurrences,
        original_corner_disk_binding=_checker.corner_binding)
    for p in(__file__,RULE.__file__,PACKET/'PREMISE_BINDINGS.json'):
        report['checker_dependency_sha256'][str(Path(p).resolve())]=OLD.sha(p)
    verify_binding();assert not any(n in sys.modules for n in('ac_physical_corner_runtime','physical_corner_disk_rows','physical_corner_disk_separation'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('tree',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.parent,a.tree,a.output)
