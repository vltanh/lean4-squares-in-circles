"""Fresh original ancestry and exact complete-cover replay with new row families."""
from pathlib import Path
import sys,json,argparse,importlib
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import independent_c_general_rows_adapter as EXT
ap=argparse.ArgumentParser();ap.add_argument('family',choices=['cd402','cb882']);ap.add_argument('manifest',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--rotating',action='store_true');a=ap.parse_args()
CHECK=importlib.import_module('check_'+a.family+'_complete_cover')
transport=None
if a.family=='cb882':
 import local_c_height_transport as TRANSPORT
 transport=TRANSPORT.install(CHECK.HEIGHT)
CHECK.Adapter=EXT.extend_adapter(CHECK.Adapter,allow_rotating=a.rotating)
report=CHECK.replay(a.manifest,a.output);EXT.no_producers();report['independently_reconstructed_new_row_counts']=EXT.COUNTS;report['rotating_family_review_required']=a.rotating
report['incircle_guards_use_independently_propagated_same_pair_differences']=True
report['rotating_guards_use_independently_propagated_original_boxes']=True
if transport is not None:
 for path,digest in transport['input_sha256'].items():assert TRANSPORT.sha(path)==digest
 assert TRANSPORT.sha(TRANSPORT.__file__)==transport['transport_source_sha256']
 report['height_archive_filename_transport']=transport
a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(EXT.COUNTS),flush=True)
