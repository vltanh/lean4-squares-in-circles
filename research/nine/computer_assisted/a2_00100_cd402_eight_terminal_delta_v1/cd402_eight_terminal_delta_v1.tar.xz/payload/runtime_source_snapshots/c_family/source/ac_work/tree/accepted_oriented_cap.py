"""Pinned independent replay of the reviewed original-pair cap theorem."""
from pathlib import Path
import hashlib,importlib.util,json

HERE=Path(__file__).resolve().parent
PACKET=HERE.parent/'full_angle_common_side_row_v1'
BINDING_SHA='b462689a9a20b1ef6324a56487c9b4d039c83a8f2387726fcae98060f3c89558'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result

LITERAL=module('ac_independent_oriented_cap_literal',PACKET/'check_oriented_good_cap_rows.py')
TOLL=module('ac_independent_oriented_cap_toll',PACKET/'check_one_sided_good_toll.py')
_REPORT=None

def verify_binding():
    assert sha(PACKET/'PREMISE_BINDINGS.json')==BINDING_SHA
    binding=json.loads((PACKET/'PREMISE_BINDINGS.json').read_text())
    assert binding['status']=='ACCEPTED_CONDITIONAL_PHYSICAL_INPUTS'
    for name,h in binding['files'].items():assert sha(PACKET/name)==h
    return binding

def ensure_proof():
    global _REPORT
    binding=verify_binding()
    if _REPORT is None:
        result=TOLL.check(json.loads((PACKET/'ORIENTED_GOOD_ENDPOINT_TOLL_COVER.json').read_text()))
        assert result['status']=='PASS_COMPLETE_ORIENTED_ENDPOINT_TOLL_COVER'
        assert result['leaves']==6170 and result['frontier']==0 and result['maxdepth']==20
        assert result['analytic_rational_checks']==13
        _REPORT=dict(result,physical_review_sha256=binding['files']['ROOT_PHYSICAL_REVIEW.md'],
            premise_binding_sha256=BINDING_SHA,original_pair_physical_theorem=True)
    return _REPORT

def rows(angles,scalar,differences):
    return LITERAL.rows(angles,scalar,differences)
