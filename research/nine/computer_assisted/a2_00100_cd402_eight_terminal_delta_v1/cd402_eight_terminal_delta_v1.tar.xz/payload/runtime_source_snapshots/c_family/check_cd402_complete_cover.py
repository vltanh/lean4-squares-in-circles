"""Independent exact replay of the current unchanged-original Cd402 cover.

The numerical search may leave a frontier. Every processed record and every
4/8/2 closed cover edge is checked, and every unprocessed frontier domain is
accounted for. The original initializer and three-round bound source are
replayed afresh. Only standard-library and independent modules are imported.
No original or mask credit is emitted while even one frontier domain remains.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
from collections import Counter
import sys,json,argparse,hashlib,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source/ac_work/tree'))
sys.path.insert(0,str(HERE.parent/'b_family/source/universal_center_disk'))
import verify_c887_unit_four_corner_tree as BASE
import independent_physical_sat_diagonal_replay as CORE
import independent_physical_proxy_cover as PROXY
import independent_physical_center_disk_rows as CENTER
TARGET='negative-d4021ade840b985c'
ROOT_PATH=[['angle',3,0],['angle_cut',[0,'0'],1],['alternate_four_escape',[1,7],[2]]]
ORIGINAL=HERE/'cd402_checkpoint_delta/payload/d_work/cd402_work/other_masks_whole_original_bound3.json'
ORIGINAL_SHA='3e416f74d97c2badf6d2de427b24f62066cf96b808fea39197275373c9e5ac7f'
REGISTER_SHA='ea000e84c04675fe22424e5c20d3df9d735d659065349800aef2699170bff604'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class Adapter(BASE.Adapter):
 def rebuild(self,state,printed):
  assert state['id']==TARGET and state['path'][:3]==ROOT_PATH
  assert not any(r['name'].startswith('c_original_closed_height_consequence_')for r in printed)
  ordinary=[r for r in printed if not r['name'].startswith(CENTER.PREFIX)]
  answer,bounds,physical=super().rebuild(state,ordinary)
  for r in printed:
   if not r['name'].startswith(CENTER.PREFIX):continue
   literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name'])
   CENTER.verify_literal(literal)
   assert r['index']not in answer;answer[r['index']]=literal
  return answer,bounds,physical


def resolve_source(name,digest):
 candidates=[Path(name)]
 old=Path('/workspace/scratch/f9f48fcfb253')
 p=Path(name)
 if p.is_relative_to(old):
  relative=p.relative_to(old)
  candidates += [HERE/'source'/relative,HERE/'cd402_checkpoint_delta/payload'/relative]
  if p.is_relative_to(old/'ac_work/c887/c887_whole_eight_checkpoint_package'):
   candidates.append(HERE/'c887_whole_eight_checkpoint_package'/p.relative_to(old/'ac_work/c887/c887_whole_eight_checkpoint_package'))
 for candidate in candidates:
  if candidate.is_file()and sha(candidate)==digest:return candidate.resolve()
 raise AssertionError(('missing exact source',name,digest))


def original_state(adapter,bindings):
 assert sha(ORIGINAL)==ORIGINAL_SHA;bindings[str(ORIGINAL)]=ORIGINAL_SHA
 register=BASE.OLD.PKG/'ancestry/legacy/current_proof/original_register.json'
 assert sha(register)==REGISTER_SHA;bindings[str(register)]=REGISTER_SHA
 cells=json.loads(register.read_text());assert cells['target_mask']=='001/00'and cells['target_q']=='1105/256'and cells['coverage_certified']is True
 selected=[c for c in cells['cells']if c['id']==TARGET];assert len(selected)==1
 c=selected[0];assert c['path']==ROOT_PATH and c['sign']=='negative'and c['baseline_frontier_index']==30
 assert TARGET=='negative-'+hashlib.sha256(json.dumps(ROOT_PATH,separators=(',',':')).encode()).hexdigest()[:16]
 assert adapter.K.V.Q==F(1105,256)and adapter.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
 angles,positions,choices=adapter.K.V.reconstruct(ROOT_PATH)
 angles=tuple(map(tuple,angles));positions=tuple(map(tuple,positions))
 state=dict(id=TARGET,path=ROOT_PATH,angles=angles,positions=positions,choices=choices,scalar=adapter.analytic(angles),differences={},diagonal={})
 CORE.valid_state(state)
 saved=json.loads(ORIGINAL.read_text())
 assert saved['schema']=='Cd402_fresh_original_physical_bound_discovery_v1'
 assert saved['id']==TARGET and saved['original_path']==ROOT_PATH and saved['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'
 assert saved['original_mask']=='001/00'and saved['squared_radius']=='1105/256'
 assert saved['original_register']['sha256']==REGISTER_SHA
 assert saved['all_nine_original_squares_retained']is True
 assert saved['original_corner_predicates']==saved['original_pair_predicates']==36 and saved['marked_cones']==5
 assert saved['closed_shared_faces_retained']is True and saved['no_other_original_consequence_imported']is True
 assert saved['new_original_cells']==saved['new_masks']==0
 assert saved['initial']==CORE.state_view(state)
 relocated={}
 for name,digest in saved['source_sha256'].items():
  p=resolve_source(name,digest);bindings[str(p)]=digest;relocated[name]=str(p)
 audit,after=CORE.check_record(saved['record'],state,adapter)
 assert after is not None and after['path']==ROOT_PATH
 return audit,after,relocated


def angle_child(parent,owner,cut,side,adapter):
 assert type(owner)is int and 0<=owner<9 and type(side)is int and side in(0,1)
 cut=F(cut);lo,hi=parent['angles'][owner];assert lo<cut<hi
 child=deepcopy(parent);angles=list(child['angles']);angles[owner]=(lo,cut)if side==0 else(cut,hi)
 child['angles']=tuple(angles);child['path']=deepcopy(parent['path'])+[['angle_cut',[owner,str(cut)],side]]
 child['choices']=adapter.choices(child['path']);CORE.valid_state(child);return child


def replay(manifest_path,output):
 assert __debug__;started=time.monotonic();manifest_path=Path(manifest_path).resolve();output=Path(output).resolve()
 manifest_bytes=manifest_path.read_bytes();manifest=json.loads(manifest_bytes)
 snapshot_path=output.with_suffix('.manifest.json');snapshot_path.parent.mkdir(parents=True,exist_ok=True);snapshot_path.write_bytes(manifest_bytes)
 assert manifest['schema']=='whole_c_selective_dfs_continuation_v1'
 assert manifest['original']['id']==TARGET and manifest['original']['path']==ROOT_PATH
 bindings={};checker=BASE.Checker();adapter=Adapter(checker);BASE.verify_all_bindings()
 parent_audit,state,source_map=original_state(adapter,bindings)
 assert CORE.state_view(state)==manifest['original']
 source=Path(manifest['source_manifest']['path']);assert sha(source)==manifest['source_manifest']['sha256'];bindings[str(source)]=sha(source)
 entries=manifest['nodes'];nodes={n['index']:n for n in entries}
 assert len(nodes)==len(entries)and 0 in nodes
 pending={n['index']:n for n in manifest['pending']};assert len(pending)==len(manifest['pending'])and not(set(nodes)&set(pending))
 stopped={n['index']:n for n in manifest['stopped']};assert len(stopped)==len(manifest['stopped'])and set(stopped)<=set(nodes)
 records={}
 for idx,n in nodes.items():
  assert type(idx)is int and idx>=0 and n['file']==f'node_{idx:05}.json'
  path=Path(n['source_file'])if 'source_file'in n else manifest_path.parent/n['file']
  assert path.is_file();digest=sha(path);bindings[str(path)]=digest;records[idx]=(path,digest)
 visited=set();frontier=set();audits=[];covers=[];leaves=[];recomputed_closed=[]
 def edge_key(e):
  if e is None:return None
  if e['kind']in('proxy','sat'):
   assert len(e['pair'])==2 and all(type(x)is int for x in e['pair'])and 0<=e['pair'][0]<e['pair'][1]<9
   assert all(type(x)is int for x in e['choice'])
   return e['kind'],tuple(e['pair']),tuple(e['choice'])
  assert e['kind']=='angle'and type(e['owner'])is int and type(e['choice'])is int
  return 'angle',e['owner'],F(e['cut']),e['choice']
 def visit(idx,initial,parent=None,edge=None):
  assert type(idx)is int and idx>=0 and idx not in visited and idx not in frontier
  if idx in pending:
   n=pending[idx];assert n['parent']==parent and edge_key(n['edge'])==edge_key(edge)
   assert n['state']==CORE.state_view(initial);frontier.add(idx);leaves.append(dict(index=idx,excluded=False,unprocessed=True));return False
  assert idx in nodes;visited.add(idx);n=nodes[idx]
  assert n['parent']==parent and edge_key(n['edge'])==edge_key(edge)
  assert n['depth']==len(initial['path'])-3
  path,digest=records[idx];assert sha(path)==digest;record=json.loads(path.read_text())
  audit,after=CORE.check_record(record,initial,adapter);audit.update(index=idx,depth=n['depth'],sha256=digest)
  audits.append(audit);split=n.get('split');children=split['children']if split else[]
  assert isinstance(children,list)and len(children)==len(set(children))
  if after is None:
   assert not children and split is None and n['status']=='CANDIDATE_CLOSED'and idx not in stopped
   leaves.append(dict(index=idx,excluded=True,terminal=record['terminal']['kind']));return True
  assert n['status']in('OPEN','CANDIDATE_COVER_CLOSED')
  if not children:
   assert split is None and idx in stopped
   assert stopped[idx]['state']==CORE.state_view(initial)
   leaves.append(dict(index=idx,excluded=False,stopped=True));return False
  assert idx not in stopped
  child_entries=[nodes.get(i,pending.get(i))for i in children];assert all(x is not None for x in child_entries)
  restrictions=[x['edge']for x in child_entries];outcomes=[]
  kind=split['kind']
  if kind in('proxy','sat'):
   pair=tuple(split['pair']);expected=set(product((0,1),(-1,1)))if kind=='proxy'else set(product(pair,(0,1),(-1,1)))
   actual=[tuple(e['choice'])for e in restrictions]
   assert len(actual)==len(set(actual))==len(expected)and set(actual)==expected
   assert all(e['kind']==kind and e['pair']==list(pair)for e in restrictions)
   if kind=='proxy':PROXY.check_choices(actual)
   for child_idx,e in zip(children,restrictions):
    child=PROXY.proxy_child(after,pair,e['choice'],adapter)if kind=='proxy'else CORE.sat_child(after,pair,e['choice'],adapter)
    outcomes.append(visit(child_idx,child,idx,e))
  else:
   assert kind=='angle'and len(children)==2
   assert sorted(e['choice']for e in restrictions)==[0,1]
   owner=split['owner'];cut=F(split['cut'])
   assert all(e['kind']=='angle'and e['owner']==owner and F(e['cut'])==cut for e in restrictions)
   for child_idx,e in zip(children,restrictions):outcomes.append(visit(child_idx,angle_child(after,owner,cut,e['choice'],adapter),idx,e))
  closed=all(outcomes)
  if n['status']=='CANDIDATE_COVER_CLOSED':assert closed
  if closed:recomputed_closed.append(idx)
  covers.append(dict(index=idx,kind=kind,children=children,all_alternatives_present=True,shared_closed_faces_retained=True,excluded=closed))
  if len(audits)%20==0:print('CHECKED',len(audits),'NODES',len(leaves),'LEAVES',round(time.monotonic()-started,2),flush=True)
  return closed
 excluded=visit(0,state)
 assert visited==set(nodes)and frontier==set(pending)
 assert not manifest['whole_candidate_closed']or excluded
 for path,digest in bindings.items():assert sha(path)==digest
 BASE.verify_all_bindings()
 for name,digest in checker.frozen_inventory.items():assert sha(BASE.OLD.PKG/name)==digest
 forbidden=('numpy','scipy','highspy','c_center_runtime','physical_center_disk_rows','ac_objective_unit_four_corner_runtime','physical_sat_engine_snapshot','physical_sat_diagonal_engine','c_height_exclusion_consequence_rows','independent_c_height_exclusion_consequences')
 assert not any(name in sys.modules for name in forbidden)
 dependencies={str(Path(m.__file__).resolve()):sha(m.__file__)for m in tuple(sys.modules.values())if getattr(m,'__file__',None)and Path(m.__file__).is_file()and '/research/nine/.runs/'in str(Path(m.__file__).resolve())}
 report=dict(status='PASS_COMPLETE_WHOLE_ORIGINAL_CD402'if excluded else'PASS_PARTIAL_WHOLE_ORIGINAL_CD402_COVER',original_id=TARGET,original_path=ROOT_PATH,original_mask='001/00',squared_radius='1105/256',whole_original_excluded=excluded,nodes=len(nodes),leaves=len(leaves),excluded_leaves=sum(v['excluded']for v in leaves),open_leaves=sum(not v['excluded']for v in leaves),unprocessed_leaves=len(frontier),stopped_leaves=len(stopped),complete_covers=dict(Counter(c['kind']for c in covers)),complete_excluded_subtrees=recomputed_closed,rounds=sum(v['rounds']for v in audits),deductions=sum(v['deductions']for v in audits),printed_rows_checked=sum(v['printed_rows_checked']for v in audits),fresh_original_ancestor=parent_audit,node_audits=audits,leaf_table=leaves,cover_audits=covers,input_sha256=bindings,checker_dependency_sha256=dependencies,original_source_relocation=source_map,manifest_snapshot_path=str(snapshot_path),manifest_snapshot_sha256=hashlib.sha256(manifest_bytes).hexdigest(),all_nine_originals_retained=True,all_36_corners_and_pairs_retained=True,all_five_cones_and_mask_bits_retained=True,no_other_original_consequence_imported=True,closed_shared_faces_retained=True,numerical_producer_imported=False,hand_review_and_publication_acceptance_separate=True,new_original_cells=0,new_masks=0,lean_lake_ci_run=False,seconds=time.monotonic()-started)
 output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k]for k in('status','nodes','excluded_leaves','open_leaves','deductions','printed_rows_checked','seconds')}),flush=True)
 return report

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('manifest',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();replay(a.manifest,a.output)
