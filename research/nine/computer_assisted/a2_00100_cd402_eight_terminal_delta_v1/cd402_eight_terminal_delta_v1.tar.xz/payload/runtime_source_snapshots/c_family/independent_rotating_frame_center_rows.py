"""Independent literal reconstruction; no producer or numerical imports."""
from fractions import Fraction as F
TANGENT='physical_rotating_frame_corner_tangent_'
CONE='physical_rotating_frame_center_cone_'

def verify_literal(literal,state):
 terms,rhs,name=literal;rhs=F(rhs);co={}
 def add(j,x):co[j]=co.get(j,F(0))+x
 if name.startswith(TANGENT):
  fields=name[len(TANGENT):].split('_');assert len(fields)==6
  owner,e,t=int(fields[0]),int(fields[1]),int(fields[2]);pu,pv=map(F,fields[3:5]);code=fields[5]
  assert 0<=owner<9 and e in(-1,1)and t in(-1,1)and len(code)==4 and all(c in'01'for c in code)
  blocks=[(2*owner,owner,2*pu+e),(2*owner+1,9+owner,2*pu+e),(2*owner,9+owner,-2*pv-t),(2*owner+1,owner,2*pv+t)]
  expected=F(977,256)+pu*pu+pv*pv
  for (x,frame,w),c in zip(blocks,code):
   xlo,xhi=map(F,state['positions'][x]);flo,fhi=map(F,state['scalar'][frame]);assert xlo<=xhi and flo<=fhi
   index=int(c);xe=(xlo,xhi)[index]
   fe=((flo,fhi)if w>=0 else(fhi,flo))[index]
   add(x,w*fe);add(18+frame,w*xe);expected+=w*xe*fe
 elif name.startswith(CONE):
  fields=name[len(CONE):].split('_');assert len(fields)==5
  owner,axis,sign=map(int,fields[:3]);a,b=map(F,fields[3:])
  assert 0<=owner<9 and axis in(0,1)and sign in(-1,1)and(a,b)!=(0,0)
  lo,hi=map(F,state['angles'][owner]);assert -1<=lo<=hi<=1
  A,B=(sign*a,sign*b)if axis==0 else(sign*b,-sign*a)
  C,D=(b,-a)if axis==0 else(a,b)
  for slope in(lo,hi):
   major=A+B*slope;minor=C+D*slope
   assert major>0 and F(121)*abs(minor)<=F(30)*major
  # Tangent to s^2+t^2+s+t at (91/60,0).
  cap=(F(977,256)+F(8281,3600))*F(30,121)
  add(2*owner,a);add(2*owner+1,b);add(18+owner,-cap*A);add(27+owner,-cap*B);expected=F(0)
 else:raise AssertionError(('unsupported rotating-frame row',name))
 expected_terms=tuple((j,x)for j,x in sorted(co.items())if x)
 assert(tuple(terms),rhs)==(expected_terms,expected)
 return expected_terms,expected,name
