#!/usr/bin/env python3
"""Independent four-product original-corner expansion on proved caller boxes."""
from pathlib import Path
from fractions import Fraction as F
import argparse,importlib.util,json,sys
import verify_c887_unit_corner_tree as BASE

PACKET=Path(__file__).resolve().parent.parent/'four_product_corner_rows_v1'
BINDING_SHA='de2a53541969a1083aa002b4d663a6010deacbdbca53fd4e80b01b8094a892f1'
OLD=BASE.OLD
spec=importlib.util.spec_from_file_location('ac_independent_four_product_corner_literal',PACKET/'independent_physical_unit_four_corner_rows.py')
RULE=importlib.util.module_from_spec(spec);spec.loader.exec_module(RULE)
_checker=None

def verify_binding():
    assert OLD.sha(PACKET/'PREMISE_BINDINGS.json')==BINDING_SHA
    binding=json.loads((PACKET/'PREMISE_BINDINGS.json').read_text())
    assert binding['schema']=='four_product_corner_rows_proof_packet_v1'
    assert binding['status']=='PHYSICAL_PROOF_AND_ROOT_INDEPENDENT_REVIEW_PASS'
    assert binding['original_variables']==54 and binding['new_auxiliary_variables']==0
    assert binding['simultaneously_valid_plane_patterns']==16
    assert binding['source_binding_sha256']=='5fcef62cb21b38dcd42ed3c2bc1e913ff5f9125093eae4be557d92c0a56c2da1'
    for name,h in binding['immutable_inputs'].items():assert OLD.sha(PACKET/name)==h
    return dict(binding_sha256=BINDING_SHA,original_variables=54,new_auxiliary_variables=0,
        exact_caller_position_and_signed_frame_intervals_required=True)

def verify_all_bindings():
    BASE.verify_all_bindings();verify_binding()

class Checker(BASE.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.unit_four_corner_binding=verify_binding()
        self.unit_four_corner_row_occurrences=0;_checker=self

class Adapter(BASE.Adapter):
    def rebuild(self,state,printed):
        ordinary=[row for row in printed if not row['name'].startswith(RULE.PREFIX)]
        answer,bounds,physical=super().rebuild(state,ordinary)
        assert self.K.V.Q==F(1105,256)
        for row in printed:
            if not row['name'].startswith(RULE.PREFIX):continue
            literal=(tuple((i,F(v))for i,v in row['coefficients']),F(row['rhs']),row['name'])
            RULE.verify_literal(literal,physical['positions'],physical['scalar'])
            assert row['index']not in answer
            answer[row['index']]=literal;self.checker.unit_four_corner_row_occurrences+=1
        return answer,bounds,physical

OLD.Checker=Checker;OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=BASE.replay(parent,tree,output);assert _checker is not None
    report.update(unit_four_corner_row_occurrences_checked=_checker.unit_four_corner_row_occurrences,
        unit_four_corner_binding=_checker.unit_four_corner_binding)
    for path in(__file__,RULE.__file__,PACKET/'PREMISE_BINDINGS.json'):
        report['checker_dependency_sha256'][str(Path(path).resolve())]=OLD.sha(path)
    verify_all_bindings()
    assert not any(name in sys.modules for name in('ac_objective_unit_four_corner_runtime','physical_unit_four_corner_rows',
        'fast_unit_four_corner_separation_snapshot','numpy','scipy','highspy'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('parent',type=Path)
    parser.add_argument('tree',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();replay(args.parent,args.tree,args.output)
