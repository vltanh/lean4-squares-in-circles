#!/usr/bin/env python3
"""Full original ancestry and all five closed complements, exact replay only."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse,hashlib,importlib.util,json,sys,time
import verify_c887_gram_physical_tree as G
import verify_ac_original_bound_pass as ROOT
from verify_c887_ownerfree_physical_tree import SAT

HERE=Path(__file__).resolve().parent;PACKET=HERE.parent/'actual_AB_two_link_row_v1'
BINDING_SHA='3261f48cec76aae54ee9a920dbf0176cadfa3d90194f9cd2dd6c54d4a143e6ac'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
GUARD=load('ac_independent_two_link_guard',PACKET/'check_two_link_actual_ab_guard.py')
SCALAR=load('ac_independent_two_link_scalar',PACKET/'check_three_angle_cover.py')

def binding():
    assert sha(PACKET/'PREMISE_BINDINGS.json')==BINDING_SHA
    d=json.loads((PACKET/'PREMISE_BINDINGS.json').read_text())
    assert d['status']=='ACCEPTED_CONDITIONAL_PHYSICAL_TWO_LINK_THEOREM'
    for name,h in d['files'].items():assert sha(PACKET/name)==h
    return d

def scalar_proof():
    audits=[]
    for u,v in product((-1,1),repeat=2):
        signs=[1,u,v]
        for t,s in product((0,1),repeat=2):
            owners=[t,1+s]
            for k in sorted(set(owners)):
                name='s'+''.join('p'if x>0 else'm'for x in signs)+'_o'+''.join(map(str,owners))+'_k'+str(k)+'.json'
                audits.append(SCALAR.check_file(PACKET/'cover_0601'/name,(signs,owners,k)))
    assert len(audits)==28 and sum(x['leaves']for x in audits)==103
    assert sum(x['bernstein_coefficients']for x in audits)==12875
    return dict(domains=28,leaves=103,bernstein_coefficients=12875,frontier=0,strict_except_all_zero=True)

class Adapter(G.Adapter):
    def __init__(self,checker,parent,component):
        super().__init__(checker);assert type(component)is int and 0<=component<5
        rows,self.guard=GUARD.reduced_complement(parent);self.escape=rows[component]
    def rebuild(self,state,printed):
        ordinary=[r for r in printed if not r['name'].startswith('two_link_actual_AB_escape_')]
        answer,bounds,propagated=super().rebuild(state,ordinary)
        for r in printed:
            if not r['name'].startswith('two_link_actual_AB_escape_'):continue
            literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name'])
            assert literal==self.escape and r['index']not in answer;answer[r['index']]=literal
        return answer,bounds,propagated

def parent_state(path,checker):
    raw=json.loads(Path(path).read_text());assert raw['schema']=='same_original_verified_prefix_bound_discovery_v1'
    prefix=Path(raw['prefix']['path']);assert sha(prefix)==raw['prefix']['sha256']
    adapter=G.Adapter(checker);prior,state,extra=ROOT.ancestor(prefix,checker,adapter)
    assert state['id']==raw['id']and state['path']==raw['original_path']
    for p,h in raw['sources'].items():assert sha(p)==h
    audit,after=SAT.check_record(raw['record'],state,adapter);assert after is not None
    return dict(ancestor=prior,whole_parent=audit,certificate_sha256=sha(path)),after

def main():
    p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('output',type=Path);a=p.parse_args();started=time.monotonic()
    premise=binding();theorem=scalar_proof();m=json.loads((a.folder/'manifest.json').read_text())
    assert m['schema']=='AC_actual_AB_complete_five_complement_discovery_v1'
    assert m['components']==list(range(5))and m['complete_closed_complement_declaration']is True
    assert m['all_nine_originals']is True and m['mask']=='001/00'and m['new_original_cells']==m['new_masks']==0
    parent=Path(m['parent']['path']);assert sha(parent)==m['parent']['sha256']
    checker=G.Checker();prior,state=parent_state(parent,checker)
    assert state['id']==m['original_id']and state['path']==m['original_path']
    assert checker.K.V.Q==F(1105,256)and checker.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
    assert [e['component']for e in m['results']]==list(range(5))
    audits=[];finals=[];inputs={str(parent):sha(parent),str(a.folder/'manifest.json'):sha(a.folder/'manifest.json')}
    for e in m['results']:
        component=e['component'];path=a.folder/e['file'];assert e['file']==f'component_{component}.json'and sha(path)==e['sha256']
        r=json.loads(path.read_text());assert r['parent']==m['parent']and r['component']==component
        assert r['schema']=='AC_named_closed_two_link_complement_bound_discovery_v1'
        assert r['initial']==SAT.state_view(state)
        adapter=Adapter(checker,state,component);co,rhs,name=adapter.escape
        assert r['closed_domain']==dict(name=name,coefficients=[[k,str(v)]for k,v in co],rhs=str(rhs))
        assert r['complement_guard']==adapter.guard and r['record']['status']==e['status']
        for file,h in r['source_sha256'].items():assert sha(file)==h
        audit,after=SAT.check_record(r['record'],state,adapter);audit.update(component=component,closed_domain=r['closed_domain'])
        audits.append(audit);finals.append(SAT.state_view(after)if after is not None else None);inputs[str(path)]=sha(path)
    for p,h in m['sources'].items():assert sha(p)==h
    binding();excluded=sum(x is None for x in finals)
    assert not any(n in sys.modules for n in('numpy','scipy','highspy','ac_two_link_complement_runtime','ac_physical_gram_runtime'))
    dependencies={str(Path(p).resolve()):sha(p)for p in(__file__,G.__file__,ROOT.__file__,SAT.__file__,GUARD.__file__,SCALAR.__file__)}
    result=dict(status='PASS_COMPLETE_WHOLE_ORIGINAL_VIA_FIVE_TWO_LINK_COMPLEMENTS'if excluded==5 else'PASS_COMPLETE_DECLARATION_WITH_OPEN_COMPLEMENTS',
        original_id=state['id'],original_path=state['path'],excluded_complement_domains=excluded,open_complement_domains=5-excluded,
        all_five_closed_complements_present=True,all_shared_faces_retained=True,ancestor_replay=prior,component_audits=audits,
        final_states=finals,two_link_scalar_replay=theorem,accepted_physical_premise_binding_sha256=BINDING_SHA,
        source_sha256=m['sources'],input_sha256=inputs,checker_dependency_sha256=dependencies,
        owner_free_occurrences=checker.owner_free_occurrences,oriented_cap_occurrences=checker.cap_occurrences,
        frame_square_occurrences=checker.frame_square_occurrences,projection_square_occurrences=checker.projection_square_occurrences,
        all_nine_original_squares_retained=True,original_corner_predicates=36,original_pair_predicates=36,original_mask='001/00',
        new_original_cells=int(excluded==5),new_masks=0,numerical_producer_imported=False,lean_lake_ci_run=False,seconds=time.monotonic()-started)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in('status','excluded_complement_domains','open_complement_domains','owner_free_occurrences','oriented_cap_occurrences','seconds')}),flush=True)

if __name__=='__main__':main()
