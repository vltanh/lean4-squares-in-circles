#!/usr/bin/env python3
"""Independent unit-frame corner expansion from each exact propagated box."""
from pathlib import Path
from fractions import Fraction as F
import argparse,importlib.util,json,sys
import verify_c887_corner_tree as BASE
import verify_c887_all_guards_v3 as EXTRA
import verify_c887_all_guards_v2 as OPPOSITE
import verify_c887_all_guards_physical_tree as SHARED

PACKET=Path(__file__).resolve().parent.parent/'unit_frame_corner'
BINDING_SHA='c49138469a346f35281023548bcf66a50eb3690ba84296478d206fb7bd25409d'
OLD=BASE.OLD
spec=importlib.util.spec_from_file_location('ac_independent_unit_frame_corner_literal',PACKET/'independent_physical_unit_corner_rows.py')
RULE=importlib.util.module_from_spec(spec);spec.loader.exec_module(RULE)
_checker=None

def verify_binding():
    assert OLD.sha(PACKET/'PREMISE_BINDINGS.json')==BINDING_SHA
    binding=json.loads((PACKET/'PREMISE_BINDINGS.json').read_text())
    assert binding['schema']=='physical_unit_frame_expanded_corner_rows_v1'
    assert binding['q']=='1105/256'and binding['original_variables']==54
    assert binding['new_auxiliary_variables']==0
    for name,h in binding['source_sha256'].items():assert OLD.sha(PACKET/name)==h
    return dict(binding_sha256=BINDING_SHA,original_variables=54,new_auxiliary_variables=0,
        exact_caller_position_and_signed_frame_intervals_required=True)

def verify_all_bindings():
    SHARED.SHARP.verify_binding(SHARED.PKG);SHARED.CAP.verify_binding()
    OPPOSITE.verify_binding();EXTRA.verify_binding();BASE.verify_binding();verify_binding()

class Checker(BASE.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.unit_corner_binding=verify_binding()
        self.unit_corner_row_occurrences=0;_checker=self

class Adapter(BASE.Adapter):
    def rebuild(self,state,printed):
        ordinary=[r for r in printed if not r['name'].startswith(RULE.PREFIX)]
        answer,bounds,physical=super().rebuild(state,ordinary)
        assert self.K.V.Q==F(1105,256)
        for r in printed:
            if not r['name'].startswith(RULE.PREFIX):continue
            literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name'])
            RULE.verify_literal(literal,physical['positions'],physical['scalar'])
            assert r['index']not in answer
            answer[r['index']]=literal;self.checker.unit_corner_row_occurrences+=1
        return answer,bounds,physical

OLD.Checker=Checker;OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=BASE.replay(parent,tree,output);assert _checker is not None
    report.update(unit_frame_corner_row_occurrences_checked=_checker.unit_corner_row_occurrences,
        unit_frame_corner_binding=_checker.unit_corner_binding)
    for p in(__file__,RULE.__file__,PACKET/'PREMISE_BINDINGS.json'):
        report['checker_dependency_sha256'][str(Path(p).resolve())]=OLD.sha(p)
    verify_all_bindings()
    assert not any(n in sys.modules for n in('ac_objective_unit_corner_runtime','physical_unit_corner_rows',
        'physical_unit_corner_separation','fast_unit_corner_separation_snapshot','numpy','scipy','highspy'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('parent',type=Path)
    parser.add_argument('tree',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();replay(args.parent,args.tree,args.output)
