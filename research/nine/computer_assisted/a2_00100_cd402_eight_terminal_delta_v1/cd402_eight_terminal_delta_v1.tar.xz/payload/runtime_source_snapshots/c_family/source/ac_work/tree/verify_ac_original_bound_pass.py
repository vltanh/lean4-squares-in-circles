#!/usr/bin/env python3
"""Independent whole-original arithmetic, including a fresh archived-prefix replay."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,subprocess,sys,tempfile,time
import verify_c887_cap_physical_tree as CAPTREE
from verify_c887_ownerfree_physical_tree import SAT

HERE=Path(__file__).resolve().parent
TARGETS={
    'positive-c744bc031d40ee64':('replay_a_c744_prefix.py','ccd730436715dff158a6d99fad5c9b55729c26d111c9b7ba25a78b24808e4638'),
    'negative-b882d8ade0cf9ea0':('replay_cb882_prefix.py','1c6eb1e62f496889f392338a485c004adfdfd1d1b99f9cec847ac1aa9c11af03'),
}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(v):return tuple(tuple(map(F,ab))for ab in v)

def parse_state(v,adapter):
    result=dict(id=v['id'],path=v['path'],choices=adapter.choices(v['path']),
        angles=box(v['angles']),positions=box(v['positions']),scalar=box(v['scalar']),
        differences={tuple(x['pair']):box(x['intervals'])for x in v['differences']},
        diagonal={tuple(x['pair']):box(x['intervals'])for x in v['diagonal']})
    SAT.valid_state(result);return result

def ancestor(prefix,checker,adapter):
    prefix=Path(prefix);saved=json.loads(prefix.read_text())
    if saved['schema']=='correlated_diagonal_whole_parent_v1':
        assert saved['id']=='negative-887236b78100baf3'
        assert sha(prefix)=='9a5c4af1e23964ee661e4e1ae427265a29303b2a6f6bd5a65c5ece14177040a3'
        report,state,diagonal=checker.D.replay(prefix)
        assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
        return report,dict(state,diagonal=diagonal),{}
    assert saved['schema']=='independently_replayed_same_original_state_v1'
    target=saved['state']['id'];script,digest=TARGETS[target]
    loader=HERE/script;loader_hash=sha(loader)
    with tempfile.TemporaryDirectory(prefix='ac_exact_prefix_')as temporary:
        output=Path(temporary)/'replayed.json'
        run=subprocess.run([sys.executable,'-B','-S',str(loader),str(output)],capture_output=True,text=True)
        assert run.returncode==0,run.stdout+'\n'+run.stderr
        fresh=json.loads(output.read_text())
    assert sha(loader)==loader_hash
    assert fresh['state']==saved['state']and fresh['certificate_sha256']==saved['certificate_sha256']==digest
    state=parse_state(fresh['state'],adapter)
    return fresh,state,{str(loader):loader_hash}

def replay(source,output):
    started=time.monotonic();source=Path(source);r=json.loads(source.read_text())
    assert r['schema']=='same_original_verified_prefix_bound_discovery_v1'
    assert r['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and r['new_original_cells']==r['new_masks']==0
    prefix=Path(r['prefix']['path']);assert sha(prefix)==r['prefix']['sha256']
    checker=CAPTREE.Checker();adapter=CAPTREE.Adapter(checker)
    prior,state,extra=ancestor(prefix,checker,adapter)
    assert state['id']==r['id']and state['path']==r['original_path']
    for p,h in r['sources'].items():assert sha(p)==h
    audit,after=SAT.check_record(r['record'],state,adapter)
    for p,h in r['sources'].items():assert sha(p)==h
    CAPTREE.CAP.verify_binding()
    assert not any(n in sys.modules for n in('numpy','scipy','highspy','ac_original_bound_pass','ac_physical_context_caps'))
    dependencies={str(Path(p).resolve()):sha(p)for p in(__file__,CAPTREE.__file__,CAPTREE.OLD.__file__,SAT.__file__,CAPTREE.CAP.__file__,CAPTREE.CAP.LITERAL.__file__,CAPTREE.CAP.TOLL.__file__)}
    dependencies.update(extra)
    report=dict(audit,status='PASS_COMPLETE_WHOLE_ORIGINAL_DOMAIN'if after is None else'PASS_CERTIFIED_WHOLE_ORIGINAL_STATE_OPEN',
        original_id=state['id'],original_path=state['path'],ancestor_replay=prior,
        final=SAT.state_view(after)if after is not None else None,
        certificate_sha256=sha(source),prefix_sha256=sha(prefix),source_sha256=r['sources'],checker_dependency_sha256=dependencies,
        owner_free_occurrences=checker.owner_free_occurrences,oriented_cap_occurrences=checker.cap_occurrences,
        oriented_cap_theorem=checker.cap_theorem,all_nine_original_squares_retained=True,
        original_corner_predicates=36,original_pair_predicates=36,original_mask='001/00',
        new_original_cells=int(after is None),new_masks=0,numerical_producer_imported=False,lean_lake_ci_run=False,
        seconds=time.monotonic()-started)
    Path(output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in('ancestor_replay','final','source_sha256','checker_dependency_sha256','oriented_cap_theorem')}),flush=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.source,a.output)
