"""Verify relative-frame arc rows by exact signed square comparisons.

No producer or square-root approximation is imported or reproduced. Each
claimed endpoint bound is proved directly against its algebraic radical.
"""
from fractions import Fraction as F

def below_radical(value,numerator,denominator):
    """Prove value <= numerator/sqrt(denominator) without computing a root."""
    assert denominator>0
    if numerator>=0:return value<=0 or value*value*denominator<=numerator*numerator
    return value<0 and value*value*denominator>=numerator*numerator

def verify_literal(row,choices,angles):
    terms,rhs,name=row;rhs=F(rhs);tokens=name.split('_')
    assert tokens[:2]==['sat','relative']
    family=tokens[2];assert family in('arc','sine','cosine')
    ordinal,i,j=map(int,tokens[3:6])
    chosen=[(tuple(pair),tuple(choice))for pair,kind,choice in choices if kind=='sat']
    assert 0<=ordinal<len(chosen)and chosen[ordinal][0]==(i,j)
    assert 0<=i<j<9 and len(angles)==9
    owner,axis,sign=chosen[ordinal][1]
    assert owner in(i,j)and axis in(0,1)and sign in(-1,1)
    ai,bi=map(F,angles[i]);aj,bj=map(F,angles[j])
    assert -1<=ai<=bi<=1 and -1<=aj<=bj<=1
    lower=(bi,aj);upper=(ai,bj);start=54+6*ordinal
    cos={start+2:F(1),start+3:F(1)};sin={start+4:F(1),start+5:F(-1)}
    actual={}
    for k,v in terms:
        assert type(k)is int
        actual[k]=actual.get(k,F(0))+F(v)
    actual={k:v for k,v in actual.items()if v}
    if family=='arc':
        assert len(tokens)==10
        pn,pd,qn,qd=map(int,tokens[6:]);assert pd>0 and qd>0
        p,q=F(pn,pd),F(qn,qd);assert p>=0 and(p or q)
        expected={k:-p*v for k,v in cos.items()if p*v}
        expected.update({k:-q*v for k,v in sin.items()if q*v})
        assert actual==expected
        for t,u in(lower,upper):
            numerator=p*(1+t*u)+q*(u-t);denominator=(1+t*t)*(1+u*u)
            assert below_radical(-rhs,numerator,denominator)
    elif family=='sine':
        assert len(tokens)==7 and tokens[6]in('lower','upper')
        low=tokens[6]=='lower';expected={k:(-v if low else v)for k,v in sin.items()}
        assert actual==expected
        t,u=lower if low else upper;numerator=u-t;denominator=(1+t*t)*(1+u*u)
        assert below_radical(-rhs,numerator if low else-numerator,denominator)
    else:
        assert len(tokens)==7 and tokens[6]=='upper'and actual==cos
        if max(ai,aj)<=min(bi,bj):assert rhs>=1
        else:
            for t,u in(lower,upper):assert below_radical(-rhs,-(1+t*u),(1+t*t)*(1+u*u))
    return True
