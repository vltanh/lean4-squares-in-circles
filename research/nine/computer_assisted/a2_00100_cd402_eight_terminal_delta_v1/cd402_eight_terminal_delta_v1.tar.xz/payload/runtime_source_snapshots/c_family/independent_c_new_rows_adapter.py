"""Independent verifier extension for original-pair and original-frame rows.
The inherited verifier reconstructs the physical interval state first. The
new literals are checked only against those independently propagated boxes.
No producer or numerical module is imported.
"""
from pathlib import Path
from fractions import Fraction as F
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source/incircle_distance_chords'))
import independent_incircle_chords as INC
import independent_rotating_frame_center_rows as ROT
COUNTS={'incircle':0,'rotating_tangent':0,'rotating_cone':0}

def extend_adapter(parent,allow_rotating=False):
 class Adapter(parent):
  def rebuild(self,state,printed):
   prefixes=(INC.PREFIX,ROT.TANGENT,ROT.CONE)
   ordinary=[r for r in printed if not r['name'].startswith(prefixes)]
   answer,bounds,physical=super().rebuild(state,ordinary)
   for row in printed:
    name=row['name']
    if not name.startswith(prefixes):continue
    literal=(tuple((k,F(v))for k,v in row['coefficients']),F(row['rhs']),name)
    if name.startswith(INC.PREFIX):INC.verify_literal(literal,physical['differences']);kind='incircle'
    else:
     assert allow_rotating,'rotating-frame family not enabled for this certificate'
     ROT.verify_literal(literal,physical);kind='rotating_tangent'if name.startswith(ROT.TANGENT)else'rotating_cone'
    assert row['index']not in answer
    answer[row['index']]=literal;COUNTS[kind]+=1
   return answer,bounds,physical
 return Adapter

def no_producers():
 forbidden=('numpy','scipy','highspy','c_center_runtime','c_rotating_runtime','c_incircle_runtime','c_rotating_incircle_runtime','physical_incircle_chords','physical_rotating_frame_center_rows','ac_objective_unit_four_corner_runtime')
 assert not any(name in sys.modules for name in forbidden)
