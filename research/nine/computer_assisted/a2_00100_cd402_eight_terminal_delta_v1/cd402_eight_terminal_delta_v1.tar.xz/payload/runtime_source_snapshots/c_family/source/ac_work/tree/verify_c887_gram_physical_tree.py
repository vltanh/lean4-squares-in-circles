#!/usr/bin/env python3
"""Independent C887 cover replay with literal physical norm-square rows."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,sys
import verify_c887_cap_physical_tree as CAPTREE
import independent_physical_pair_frame_squares as FRAME
import independent_physical_projection_squares as PROJECTION

_checker=None
class Checker(CAPTREE.Checker):
    def __init__(self):
        global _checker
        super().__init__();self.frame_square_occurrences=0;self.projection_square_occurrences=0;_checker=self

class Adapter(CAPTREE.Adapter):
    def rebuild(self,state,printed):
        prefixes=('physical_pair_square_','physical_projection_square_')
        ordinary=[r for r in printed if not r['name'].startswith(prefixes)]
        answer,bounds,propagated=super().rebuild(state,ordinary)
        for r in printed:
            if not r['name'].startswith(prefixes):continue
            literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name'])
            if r['name'].startswith('physical_pair_square_'):
                FRAME.verify_literal(literal,propagated['choices']);self.checker.frame_square_occurrences+=1
            else:
                PROJECTION.verify_literal(literal,propagated['choices'],propagated['differences']);self.checker.projection_square_occurrences+=1
            assert r['index']not in answer;answer[r['index']]=literal
        return answer,bounds,propagated

CAPTREE.OLD.Checker=Checker;CAPTREE.OLD.Adapter=Adapter

def replay(parent,tree,output):
    report=CAPTREE.replay(parent,tree,output);assert _checker is not None
    report['physical_frame_square_occurrences_checked']=_checker.frame_square_occurrences
    report['physical_projection_square_occurrences_checked']=_checker.projection_square_occurrences
    for p in(__file__,FRAME.__file__,PROJECTION.__file__):
        report['checker_dependency_sha256'][str(Path(p).resolve())]=CAPTREE.OLD.sha(p)
    assert not any(n in sys.modules for n in('ac_physical_gram_runtime','physical_pair_frame_squares',
        'physical_projection_squares','physical_frame_square_separation','physical_projection_square_separation'))
    Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('tree',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();replay(a.parent,a.tree,a.output)
