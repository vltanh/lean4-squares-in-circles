"""Independent reconstruction of same-auxiliary tightened SAT products.

The six auxiliary identities are read from the physical owner/axis/sign path.
Each product plane is an expansion of the sign of a product of two closed
interval slacks. Only Fractions and ordinary Python are used.
"""
from fractions import Fraction as Q
from itertools import product

def plus(*summands):
 result={}
 for terms,multiplier in summands:
  for variable,value in terms.items():result[variable]=result.get(variable,Q(0))+Q(multiplier)*value
 return {variable:value for variable,value in result.items()if value}

def row(poly,constant,name):
 return tuple((k,v)for k,v in sorted(poly.items())if v),Q(constant),name

def enclose(terms,scalar):
 terms=[(Q(c),scalar[k-18])for k,c in terms.items()]
 return tuple(sum(min(c*a,c*b)if endpoint==0 else max(c*a,c*b)for c,(a,b)in terms)for endpoint in(0,1))

def parse(name,choices):
 fields=name.split('_');assert fields[:2]==['tight','sat']
 family=fields[2];assert family in('product','interval','diagonal')
 number,i,j,owner,axis,sign=map(int,fields[3:9])
 selected=[(tuple(pair),tuple(choice))for pair,kind,choice in choices if kind=='sat']
 assert 0<=number<len(selected)and selected[number]==((i,j),(owner,axis,sign))
 assert 0<=i<j<9 and owner in(i,j)and axis in(0,1)and sign in(-1,1)
 return family,number,i,j,owner,axis,sign,fields[9:]

def normal(owner,axis,sign):
 if axis==0:return {18+owner:Q(sign)},{27+owner:Q(sign)}
 return {27+owner:Q(-sign)},{18+owner:Q(sign)}

def rebuild(name,choices,scalar,differences,diagonal=None):
 assert len(scalar)==36 and all(a<=b for a,b in scalar)
 family,number,i,j,owner,axis,sign,tail=parse(name,choices)
 nx,ny=normal(owner,axis,sign)
 dx={2*j:Q(1),2*i:Q(-1)};dy={2*j+1:Q(1),2*i+1:Q(-1)}
 first=54+6*number
 if family in('product','interval'):
  assert len(tail)==2;tag,mode=tail
  data={'nx':(0,nx,dx,enclose(nx,scalar),differences[i,j][0]),
        'ny':(1,ny,dy,enclose(ny,scalar),differences[i,j][1]),
        'aa':(2,{18+i:Q(1)},{18+j:Q(1)},scalar[i],scalar[j]),
        'bb':(3,{27+i:Q(1)},{27+j:Q(1)},scalar[9+i],scalar[9+j]),
        'ab':(4,{18+i:Q(1)},{27+j:Q(1)},scalar[i],scalar[9+j]),
        'ba':(5,{27+i:Q(1)},{18+j:Q(1)},scalar[9+i],scalar[j])}
  offset,u,v,(l,h),(a,b)=data[tag];assert l<=h and a<=b;z=first+offset
  if family=='interval':
   assert mode in('upper','lower');values=(l*a,l*b,h*a,h*b)
   return row({z:Q(1)},max(values),name)if mode=='upper'else row({z:Q(-1)},-min(values),name)
  assert mode in('ll','uu','ul','lu')
  if mode in('ll','uu'):
   endpoint_u,endpoint_v=(l,a)if mode=='ll'else(h,b)
   # -(U-endpoint_u)(V-endpoint_v) <= 0.
   return row(plus(({z:Q(-1)},1),(u,endpoint_v),(v,endpoint_u)),endpoint_u*endpoint_v,name)
  endpoint_u,endpoint_v=(h,a)if mode=='ul'else(l,b)
  # (U-endpoint_u)(V-endpoint_v) <= 0.
  return row(plus(({z:Q(1)},1),(u,-endpoint_v),(v,-endpoint_u)),-endpoint_u*endpoint_v,name)
 assert len(tail)==3 and diagonal is not None and(i,j)in diagonal
 sense=tail[0];options=list(map(int,tail[1:]));assert sense in('upper','lower')and all(k in(0,1)for k in options)
 signed=Q(1)if sense=='upper'else Q(-1)
 coefficients={first:signed,first+1:signed};rhs=Q(0)
 for tilt,option in zip((Q(1),Q(-1)),options):
  nf=plus((nx,1),(ny,tilt));df=plus((dx,1),(dy,tilt))
  lo,hi=enclose(nf,scalar)
  alpha=[c for k,c in nf.items()if 18<=k<27];assert len(alpha)==1 and alpha[0]in(-1,1)
  if alpha[0]>0:lo,hi=max(lo,Q(0)),min(hi,Q(17,12))
  else:lo,hi=max(lo,Q(-17,12)),min(hi,Q(0))
  assert lo<=hi and Q(17,12)**2>2
  dl,dh=diagonal[i,j][0 if tilt==1 else 1];assert dl<=dh
  if sense=='upper':a,b=(hi,dl)if option==0 else(lo,dh)
  else:a,b=(lo,dl)if option==0 else(hi,dh)
  coefficients=plus((coefficients,1),(nf,-signed*b/2),(df,-signed*a/2))
  rhs-=signed*a*b/2
 return row(coefficients,rhs,name)

def verify_literal(literal,choices,scalar,differences,diagonal=None):
 terms,rhs,name=literal;expected=rebuild(name,choices,scalar,differences,diagonal)
 actual={}
 for k,c in terms:
  assert type(k)is int and k>=0
  actual[k]=actual.get(k,Q(0))+Q(c)
 assert row(actual,Q(rhs),name)==expected,name
 return True
