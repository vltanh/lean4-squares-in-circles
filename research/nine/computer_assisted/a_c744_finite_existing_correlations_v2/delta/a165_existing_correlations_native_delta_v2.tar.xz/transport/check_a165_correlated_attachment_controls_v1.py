#!/usr/bin/env python3
"""Small source/topology controls only; no constructor, arithmetic gate, or solver."""
if not __debug__:raise RuntimeError('Assertions required.')
from pathlib import Path
from copy import deepcopy
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
CODE=HERE/'a165_correlated_existing_rows_v1'
sys.path.insert(0,str(CODE))
import verify_continuation as V
S=V.S
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    freeze=S.read(CODE/'SOURCE_BINDINGS.json')
    assert sha(CODE/'SOURCE_BINDINGS.json')=='f15fe302462cbf7b4b92e8559aadbc8044ff6b829acf53b84949ae8ad8182205'
    for name,h in freeze['files'].items():assert sha(CODE/name)==h
    first=HERE/'a165_first_height_record_v1/SUFFIX_RECORD.json'
    assert sha(first)=='7ad5cf680503f7d80a24f0885966bc1c6a5a0fc53132c9b28399441a94a3483e'
    rr=deepcopy(S.read(first)['rounds'][0]);rr['exact_existing_correlated_row_isolation']=True
    V.round_shape(rr)
    rejected=[]
    for name,damage in (
        ('wrong_row_family',lambda x:x['printed_rows'][0].__setitem__('name','unaccepted')),
        ('unproved_auxiliary_objective',lambda x:x['proposals'][0].__setitem__('key',54)),
        ('wrong_objective_schema',lambda x:x['proposals'][0].__setitem__('kind','diagonal')),
        ('nonzero_residual',lambda x:x['proposals'][0].__setitem__('residual_correction','1/1000')),
        ('negative_multiplier',lambda x:x['proposals'][0]['weights'][0].__setitem__(1,-1)),
        ('unplanned_multiplier',lambda x:x['proposals'][0]['weights'][0].__setitem__(1,3)),
        ('numerical_solve_claim',lambda x:x.__setitem__('numerical_solves',1)),
        ('missing_exact_round_tag',lambda x:x.__setitem__('exact_existing_correlated_row_isolation',False))):
        bad=deepcopy(rr);damage(bad)
        try:V.round_shape(bad)
        except(AssertionError,KeyError,ValueError,TypeError):rejected.append(name)
        else:raise AssertionError(('accepted malformed round shape',name))
    manifest=S.read(S.TREE/'manifest.json');nodes=deepcopy(manifest['nodes'])
    assert sha(S.TREE/'manifest.json')==S.MANIFEST_SHA
    closed,leaves,covers=S.statuses(nodes);assert not closed and nodes==manifest['nodes']
    assert(len(leaves),len(covers))==(132,33)
    for name,damage in (
        ('omitted_root_alternative',lambda x:x[0]['children'].pop()),
        ('duplicate_root_alternative',lambda x:x[0]['children'].append(x[0]['children'][0])),
        ('root_cycle',lambda x:x[0]['children'].__setitem__(0,0)),
        ('invalid_leaf_status',lambda x:x[144].__setitem__('status','MISSING'))):
        bad=deepcopy(manifest['nodes']);damage(bad)
        try:S.statuses(bad)
        except(AssertionError,KeyError,ValueError,TypeError,IndexError):rejected.append(name)
        else:raise AssertionError(('accepted malformed cover',name))
    for name,h in freeze['files'].items():assert sha(CODE/name)==h
    assert not any(n in sys.modules for n in('ordinary_isolation','original_i64_bound_rows','numpy','scipy','highspy'))
    result=dict(status='PASS_A165_EXISTING_ROW_ATTACHMENT_PREPARATION_CONTROLS',
        source_binding_sha256=sha(CODE/'SOURCE_BINDINGS.json'),controls_source_sha256=sha(__file__),
        accepted_first_height_shape_checked=True,accepted_source_topology_checked=True,
        retained_nodes=165,retained_complete_unions=33,retained_leaves=132,
        damaged_cases_rejected=rejected,damaged_case_count=len(rejected),
        new_candidate_constructed=False,weighted_arithmetic_replayed=False,full14_gate_run=False,
        numerical_solves=0,new_original_cells=0,new_masks=0)
    p=HERE/'A165_CORRELATED_ATTACHMENT_PREPARATION_CONTROLS_V1.json';assert not p.exists()
    p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],controls=len(rejected),report_sha256=sha(p))))
if __name__=='__main__':main()
