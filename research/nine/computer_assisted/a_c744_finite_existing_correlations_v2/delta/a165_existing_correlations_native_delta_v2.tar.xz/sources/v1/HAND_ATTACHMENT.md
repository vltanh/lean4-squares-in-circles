# Finite exact use of existing correlated rows on the complete retained A cover

The source is the successful165-node consumer report98bc7f28… and manifest
4469ce8…. It covers the original closed component3 predicate with118 excluded
and14 OPEN leaves. The complete old source proof is reused by exact published
identity, including all165 payloads. No unavailable later tree is used.

This candidate construction processes only those14 leaf final states. It
preserves every original initial state and old round prefix. Nonleaf and
already excluded payloads remain byte-identical. No child, split, or path
predicate is created. Each leaf receives at most four ordinary exact rounds.

The only possible non-bound premise rows in a new round are the already
accepted whole-original height inequality

    y_B+y_D−2y_I <= −16/25

and the existing independently reconstructed Cartesian pair-difference bounds.
Original coordinate endpoint rows cancel the other coefficients of a selected
row. For a necessary row Σa_j x_j<=b, isolating coordinate i uses multiplier
1/|a_i| on that row. For each j≠i it adds the appropriate signed endpoint row
with multiplier|a_j|/|a_i|. The sum is exactly sign(a_i)x_i. No residual is
discarded. All coefficients here are±1 or±2, so the nonnegative multipliers
are exactly representable with the unchanged denominator2^40. Bounds round
upwards on the usual2^-20 grid, and only improvements of at least1/2000 become
proposals. All proposals in one round use the same untouched propagated box;
later rounds may use the previous independently certified endpoints.

This consumes correlations that the ordinary interval propagator need not
project into separate coordinates. It does not add a new geometry lemma,
bound family, optimization method, auxiliary or terminal. The narrow first
height use already passed the independent unchanged CORE and root review;
this separate version extends the candidate row selection to existing pair
differences. An exact row-isolation computation is proposal construction,
not an acceptance decision.

The independent entry imports neither that constructor nor the row producer.
It verifies the entire old165 source identity, all unchanged node metadata,
every old initial/prefix, and the exact appended-suffix annotation. Each new
suffix starts at the precise old certified final state and is replayed by the
unchanged arithmetic CORE with the accepted I64 adapter. Printed names are
restricted to the existing height, pair-difference and coordinate-bound rows.
All positive weights, coefficients, indices, residuals, rounding, propagated
boxes and ordinary terminal conditions are reconstructed normally.

Every old nonleaf payload and each child initial state is unchanged. Hence the
old accepted complete parent-child domain equalities remain available by byte
identity. The new wrapper traverses all165 nodes without short-circuiting and
recomputes every internal status from every retained child. A complete result
must retain all33 unions and132 leaf domains; OPEN siblings cannot disappear.
The report distinguishes historical old-prefix arithmetic from the freshly
replayed suffix arithmetic. No full165 re-arithmetic or cold replay is claimed.

Construction and replay are held for review of this immutable source version.
Even a successful finite continuation is only the complete retained component
cover unless the remaining physical leaves are all excluded and the original
five-component attachment is separately completed. No original or mask ledger
credit is awarded by this wrapper.
