"""Fixed accepted A165 source and unchanged ordinary exact adapter."""
if not __debug__:raise RuntimeError('Assertions required.')
from pathlib import Path
from copy import deepcopy
from contextlib import contextmanager
from fractions import Fraction as F
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
CODE=WORK/'a165_i64_exact_continuation_v1'
sys.path.insert(0,str(CODE))
import i64_retained_cover_adapter as ACCEPTED
import independent_physical_sat_diagonal_replay as CORE
ROWS=ACCEPTED.ROWS
TREE=WORK/'a165_i64_exact_continued_tree_v1'
REPORT=WORK/'A165_I64_EXACT_CONTINUATION_REPLAY_V1.json'
REPORT_SHA='98bc7f287f1eb62e0a132437d808c48121a017317adde4ea9083f83364d2ad8f'
MANIFEST_SHA='4469ce8ceda7692f49faa58ece25872c0448fbd8fc86447acb6facf0cd4e2283'
LEAVES=(144,145,146,148,149,151,152,154,156,157,159,161,163,164)
MAX_ROUNDS=4
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def parse(value,choices):
    s=dict(id=value['id'],path=deepcopy(value['path']),choices=choices(value['path']))
    for key in('angles','positions','scalar'):s[key]=tuple(tuple(map(F,v))for v in value[key])
    for key in('differences','diagonal'):s[key]={tuple(v['pair']):tuple(tuple(map(F,x))for x in v['intervals'])for v in value[key]}
    CORE.valid_state(s);return s
def source():
    assert sha(REPORT)==REPORT_SHA and sha(TREE/'manifest.json')==MANIFEST_SHA
    r,m=read(REPORT),read(TREE/'manifest.json')
    assert r['status']=='PASS_A165_I64_COMPLETE_RETAINED_COVER_OPEN'and r['all165_nodes_freshly_replayed']is True
    assert(r['nodes'],r['leaf_domains'],r['excluded_leaves'],r['open_leaves'])==(165,132,118,14)
    assert r['component']==m['component']==3 and r['closed_domain']==m['closed_domain']
    assert m['closed_domain']['rhs']=='-3/5'and r['continued_manifest_sha256']==MANIFEST_SHA
    assert sha(r['inherited_complete_arithmetic_report']['path'])==r['inherited_complete_arithmetic_report']['sha256']
    assert tuple(n['index']for n in m['nodes']if not n['children']and n['status']=='OPEN')==LEAVES
    for n in m['nodes']:assert sha(TREE/n['file'])==n['sha256']
    freeze=read(HERE/'SOURCE_BINDINGS.json')
    for name,h in freeze['files'].items():assert sha(HERE/name)==h
    for path,h in freeze['external_input_sha256'].items():assert sha(path)==h
    return m
@contextmanager
def environment():
    manifest=source();binding=ROWS.verify_binding();historical,cache=ROWS.HISTORY.validate()
    before=ACCEPTED.CONSEQUENCE._source_report
    ACCEPTED.CONSEQUENCE._source_report=deepcopy(cache['complements'])
    instances=[];Checker,Adapter=ACCEPTED.classes(binding,instances)
    try:
        checker=Checker();whole=parse(read(binding['whole_original_parent']['path'])['record']['final'],
            lambda path:checker.K.V.reconstruct(path)[2]);adapter=Adapter(checker,whole,3)
        yield dict(manifest=manifest,binding=binding,checker=checker,adapter=adapter,historical_source_reuse=historical)
        source();ROWS.verify_binding()
    finally:ACCEPTED.CONSEQUENCE._source_report=before
def write(path,value):
    import os
    path=Path(path);assert not path.exists()
    with path.open('x')as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def statuses(nodes):
    visited=set();leaves=[];covers=[]
    def walk(index):
        assert index not in visited;visited.add(index);n=nodes[index];assert n['index']==index
        if not n['children']:
            assert n['status']in('OPEN','CANDIDATE_CLOSED');leaves.append(index)
            return n['status']=='CANDIDATE_CLOSED'
        assert len(n['children'])==len(set(n['children']))
        results=[walk(k)for k in n['children']]
        closed=all(results);n['status']='CANDIDATE_COVER_CLOSED'if closed else'OPEN';covers.append(index)
        return closed
    complete=walk(0);assert visited==set(range(165))and len(leaves)==132 and len(covers)==33
    return complete,leaves,covers
