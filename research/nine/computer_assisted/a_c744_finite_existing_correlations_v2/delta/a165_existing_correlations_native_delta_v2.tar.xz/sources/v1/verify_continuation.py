#!/usr/bin/env python3
"""Fresh unchanged-CORE suffix replay, exact topology, and historical prefix composition."""
if not __debug__:raise RuntimeError('Assertions required.')
from pathlib import Path
from copy import deepcopy
import argparse,json,sys
import scope as S

TERMINALS={'accepted_effective_angle_terminal','accepted_center_interval_terminal','empty_propagated_scalar',
    'empty_propagated_difference','empty_correlated_diagonal','proved_empty_scalar','proved_frame_contradiction','proved_empty_analytic_frame'}
def round_shape(rr):
    assert rr['exact_existing_correlated_row_isolation']is True and rr['numerical_solves']==rr['numeric_failures']==0
    for r in rr['printed_rows']:
        name=r['name'];allowed=name in(S.ROWS.HEIGHT_NAME,'certified_difference_upper','certified_difference_lower')
        allowed=allowed or name in{prefix+str(k)for prefix in('bound_lo_','bound_hi_')for k in range(18)}
        assert allowed,name
    for p in rr['proposals']:
        assert p['kind']=='scalar'and type(p['key'])is int and 0<=p['key']<18
        assert p['objective']==[[p['key'],p['sign']]]
        assert p['residual_coefficients']==[]and p['residual_correction']=='0'
        assert all(type(w)is int and w in(1<<39,1<<40,1<<41)for k,w in p['weights'])

def run(folder,output):
    folder=Path(folder).resolve();output=Path(output).resolve();assert not output.exists()and folder!=S.TREE
    with S.environment()as e:
        old=e['manifest'];m=S.read(folder/'manifest.json');mh=S.sha(folder/'manifest.json')
        assert set(m)==set(old)|{'existing_correlated_row_continuation'}
        skip={'nodes','status','source_sha256','existing_correlated_row_continuation'}
        assert {k:v for k,v in m.items()if k not in skip}=={k:v for k,v in old.items()if k not in skip}
        attach=m['existing_correlated_row_continuation']
        assert attach['source_manifest_sha256']==S.MANIFEST_SHA and attach['source_full_report_sha256']==S.REPORT_SHA
        assert attach['processed_open_leaf_indices']==list(S.LEAVES)
        assert attach['source_binding_sha256']==S.sha(S.HERE/'SOURCE_BINDINGS.json')and attach['maximum_rounds_per_leaf']==S.MAX_ROUNDS
        assert attach['all_original_initials_and_round_prefixes_retained']is True
        assert attach['new_nodes']==attach['new_path_predicates']==attach['new_row_families']==attach['numerical_solves']==0
        for p,h in old['source_sha256'].items():assert m['source_sha256'][p]==h
        for p,h in m['source_sha256'].items():assert S.sha(p)==h
        assert len(m['nodes'])==len(old['nodes'])==165
        changes=[];audits=[];unchanged=0;height_uses=0;difference_uses=0
        for before,after in zip(old['nodes'],m['nodes']):
            i=before['index'];assert after['index']==i
            assert {k:v for k,v in before.items()if k not in('status','sha256')}=={k:v for k,v in after.items()if k not in('status','sha256')}
            p=folder/after['file'];assert S.sha(p)==after['sha256']
            if after['sha256']==before['sha256']:
                assert before['children']or after['status']==before['status'];unchanged+=1;continue
            assert i in S.LEAVES and before['children']==after['children']==[]
            prior=S.read(S.TREE/before['file']);record=S.read(p);old_count=len(prior['rounds'])
            assert record['initial']==prior['initial']and record['rounds'][:old_count]==prior['rounds']
            prefix_skip={'status','rounds','final','terminal','existing_correlated_row_suffix'}
            assert {k:v for k,v in record.items()if k not in prefix_skip}=={k:v for k,v in prior.items()if k not in prefix_skip}
            assert set(record)<=set(prior)|{'terminal','existing_correlated_row_suffix'}
            rounds=record['rounds'][old_count:];assert 0<=len(rounds)<=S.MAX_ROUNDS
            suffix_meta=record['existing_correlated_row_suffix']
            assert suffix_meta==dict(source_node_sha256=before['sha256'],old_rounds=old_count,appended_rounds=len(rounds),
                maximum_rounds=S.MAX_ROUNDS,source_final_before=prior['final'],unchanged_initial=True,
                source_family_binding_sha256=S.ROWS.BINDING_SHA,new_row_families=0,new_splits=0,numerical_solves=0)
            for rr in rounds:
                round_shape(rr)
                height_uses+=sum(row['name']==S.ROWS.HEIGHT_NAME for row in rr['printed_rows'])
                difference_uses+=sum(row['name'].startswith('certified_difference_')for row in rr['printed_rows'])
            suffix=dict(status=record['status'],initial=prior['final'],rounds=rounds)
            if record['status']=='OPEN':suffix['final']=record['final']
            else:
                assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']in TERMINALS
                suffix['terminal']=record['terminal']
            initial=S.parse(prior['final'],e['adapter'].choices)
            audit,state=S.CORE.check_record(suffix,initial,e['adapter'])
            assert after['status']==record['status']
            change=dict(index=i,old_sha256=before['sha256'],new_sha256=after['sha256'],appended_rounds=len(rounds),
                appended_deductions=audit['deductions'],status=record['status'])
            changes.append(change);audits.append(dict(index=i,arithmetic=audit,final=S.CORE.state_view(state)if state is not None else None))
        assert [{k:v for k,v in x.items()if k!='fixed_point_reached'}for x in attach['changes']]==changes
        expected=deepcopy(m['nodes']);complete,leaves,covers=S.statuses(expected)
        assert expected==m['nodes']and m['status']==('CANDIDATE_COVER_CLOSED'if complete else'OPEN')
        assert len(covers)==33 and len(leaves)==132
        for n in m['nodes']:assert S.sha(folder/n['file'])==n['sha256']
        assert S.sha(folder/'manifest.json')==mh
        assert not any(n in sys.modules for n in('ordinary_isolation','original_i64_bound_rows','numpy','scipy','highspy'))
        report=dict(status='PASS_COMPLETE_RETAINED_A165_EXISTING_ROW_CONTINUATION_OPEN'if not complete else'PASS_COMPLETE_RETAINED_A165_CLOSED',
            original_id=m['id'],component=3,closed_domain=m['closed_domain'],source_manifest_sha256=S.MANIFEST_SHA,
            source_full_consumer_report_sha256=S.REPORT_SHA,source_binding_sha256=S.sha(S.HERE/'SOURCE_BINDINGS.json'),
            continued_manifest_sha256=mh,nodes=165,leaf_domains=132,complete_closed_unions=33,
            excluded_leaves=sum(m['nodes'][i]['status']=='CANDIDATE_CLOSED'for i in leaves),open_leaves=sum(m['nodes'][i]['status']=='OPEN'for i in leaves),
            changed_payloads=len(changes),unchanged_payloads=unchanged,changes=changes,fresh_suffix_audits=audits,
            fresh_rounds=sum(x['arithmetic']['rounds']for x in audits),fresh_deductions=sum(x['arithmetic']['deductions']for x in audits),
            fresh_printed_rows_checked=sum(x['arithmetic']['printed_rows_checked']for x in audits),
            positive_height_literal_occurrences=height_uses,positive_pair_difference_occurrences=difference_uses,
            old165_consumer_arithmetic_reused_not_repeated=True,old_parent_child_state_identities_unchanged=True,
            all_old_initials_and_round_prefixes_retained=True,historical_source_reuse=e['historical_source_reuse'],
            new_predicates=0,new_splits=0,new_row_families=0,numerical_solves=0,new_original_cells=0,new_masks=0,
            cold_portable_replay_claimed=False)
        S.write(output,report);print(json.dumps({k:report[k]for k in('status','nodes','excluded_leaves','open_leaves','changed_payloads','fresh_rounds','fresh_deductions','positive_height_literal_occurrences','positive_pair_difference_occurrences')}),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('output',type=Path);a=p.parse_args();run(a.folder,a.output)
