#!/usr/bin/env python3
"""Finite candidate continuation of only the14 retained OPEN leaf records."""
if not __debug__:raise RuntimeError('Assertions required.')
from pathlib import Path
from copy import deepcopy
import argparse,json,os,sys
import scope as S
import ordinary_isolation as P
import extend_retained_cover as OLD

def run(output):
    output=Path(output).resolve();assert not output.exists()and not output.is_relative_to(S.TREE)
    with S.environment()as e:
        source=e['manifest'];manifest=deepcopy(source);output.mkdir(parents=True,exist_ok=False);changes=[]
        for node in manifest['nodes']:
            index=node['index'];p=S.TREE/node['file'];target=output/node['file']
            if index not in S.LEAVES:os.link(p,target);continue
            old=S.read(p);current=S.parse(old['final'],e['adapter'].choices);rounds=[];terminal=None;fixed=False
            for _ in range(S.MAX_ROUNDS):
                after,rr,terminal=P.round_(current,e['adapter'])
                if rr is not None:rounds.append(rr)
                if terminal is not None:break
                current=after
                if rr is None:fixed=True;break
            if terminal is None:terminal=OLD.propagation_terminal(e['adapter'],current)
            if not rounds and terminal is None:os.link(p,target);continue
            new=deepcopy(old);new['rounds']=old['rounds']+rounds
            if terminal is None:new.update(status='OPEN',final=S.CORE.state_view(current))
            else:new.update(status='CANDIDATE_CLOSED',terminal=terminal);new.pop('final')
            new['existing_correlated_row_suffix']=dict(source_node_sha256=node['sha256'],old_rounds=len(old['rounds']),
                appended_rounds=len(rounds),maximum_rounds=S.MAX_ROUNDS,source_final_before=old['final'],
                unchanged_initial=True,source_family_binding_sha256=S.ROWS.BINDING_SHA,new_row_families=0,new_splits=0,numerical_solves=0)
            assert new['initial']==old['initial']and new['rounds'][:len(old['rounds'])]==old['rounds']
            S.write(target,new);old_sha=node['sha256'];node['sha256']=S.sha(target);node['status']=new['status']
            entry=dict(index=index,old_sha256=old_sha,new_sha256=node['sha256'],appended_rounds=len(rounds),
                appended_deductions=sum(len(r['proposals'])for r in rounds),fixed_point_reached=fixed,status=new['status'])
            changes.append(entry);print(json.dumps(entry),flush=True)
        complete,leaves,covers=S.statuses(manifest['nodes'])
        manifest['status']='CANDIDATE_COVER_CLOSED'if complete else'OPEN'
        manifest['existing_correlated_row_continuation']=dict(source_manifest_sha256=S.MANIFEST_SHA,
            source_full_report_sha256=S.REPORT_SHA,processed_open_leaf_indices=list(S.LEAVES),changes=changes,
            source_binding_sha256=S.sha(S.HERE/'SOURCE_BINDINGS.json'),maximum_rounds_per_leaf=S.MAX_ROUNDS,
            all_original_initials_and_round_prefixes_retained=True,new_nodes=0,new_path_predicates=0,new_row_families=0,numerical_solves=0)
        freeze=S.read(S.HERE/'SOURCE_BINDINGS.json')
        for name,h in freeze['files'].items():manifest['source_sha256'][str(S.HERE/name)]=h
        manifest['source_sha256'][str(S.HERE/'SOURCE_BINDINGS.json')]=S.sha(S.HERE/'SOURCE_BINDINGS.json')
        S.write(output/'manifest.json',manifest)
        assert not any(n in sys.modules for n in('numpy','scipy','highspy'))
        S.write(output/'CONSTRUCTION_RECEIPT.json',dict(status='CANDIDATE_FINITE_A165_EXISTING_ROW_CONTINUATION',
            manifest_sha256=S.sha(output/'manifest.json'),changes=changes,full_cover_gate_pending=True,
            new_original_cells=0,new_masks=0,numerical_solves=0))
        print(json.dumps(dict(status='CANDIDATE_FINITE_A165_EXISTING_ROW_CONTINUATION',manifest_sha256=S.sha(output/'manifest.json'),
            changed_payloads=len(changes),open_leaves=sum(manifest['nodes'][i]['status']=='OPEN'for i in leaves))),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();run(a.output)
