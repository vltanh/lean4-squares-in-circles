"""Proposal-only coordinate isolation of accepted rows; no solver or new family."""
from fractions import Fraction as F
from copy import deepcopy
import scope as S
import original_i64_bound_rows as PRODUCER
import extend_retained_cover as OLD

def canon(row):
    co={}
    for k,v in row:co[k]=co.get(k,F(0))+F(v)
    return tuple((k,v)for k,v in sorted(co.items())if v)

def round_(state,adapter,eps=F(1,2000)):
    terminal=OLD.propagation_terminal(adapter,state)
    if terminal is not None:return None,None,terminal
    K=adapter.K
    base,bounds,pos,scalar,diffs,guards=K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
    _,actual_bounds,physical=adapter.rebuild(state,[])
    assert tuple(bounds)==tuple(actual_bounds)
    assert tuple(pos)==physical['positions']and tuple(scalar)==physical['scalar']and diffs==physical['differences']
    height=PRODUCER.necessary_height_row(state)
    assert height==(((3,F(1)),(7,F(1)),(17,F(-2))),F(-16,25),S.ROWS.HEIGHT_NAME)
    rows=list(base)+[height];height_index=len(base);endpoints={};candidates=[]
    for index,(co,rhs,name)in enumerate(rows):
        co=canon(co)
        if name.startswith(('bound_lo_','bound_up_'))and len(co)==1:
            k,sign=co[0]
            if 0<=k<18 and sign in(-1,1):
                assert name==('bound_up_'if sign>0 else'bound_lo_')+str(k)
                candidate=(F(rhs),index)
                if(k,sign)not in endpoints or candidate<endpoints[k,sign]:endpoints[k,sign]=candidate
        if name in('certified_difference_upper','certified_difference_lower'):
            assert len(co)==2 and all(0<=k<18 for k,v in co)and sorted(v for k,v in co)==[-1,1]
            candidates.append(index)
    candidates.append(height_index)
    assert len(candidates)==145 and len(endpoints)==36
    best={}
    for index in candidates:
        co,rhs,name=rows[index];co=canon(co)
        for target,a in co:
            multiplier=1/abs(a);weights={index:multiplier}
            for k,c in co:
                if k==target:continue
                sign=-1 if c>0 else 1
                _,endpoint=endpoints[k,F(sign)]
                weights[endpoint]=weights.get(endpoint,F(0))+abs(c)*multiplier
            summed={};total_rhs=F(0);integer_weights=[]
            for k,lam in sorted(weights.items()):
                integer=lam*S.CORE.DENOMINATOR;assert integer.denominator==1 and integer>0
                integer_weights.append([k,integer.numerator]);terms,bound,_=rows[k];total_rhs+=lam*bound
                for column,c in terms:summed[column]=summed.get(column,F(0))+lam*c
            sign=1 if a>0 else-1
            assert {k:v for k,v in summed.items()if v}=={target:F(sign)}
            upper=S.CORE.ceiling_grid(total_rhs)
            old=physical['positions'][target][1]if sign>0 else-physical['positions'][target][0]
            if old-upper<eps:continue
            candidate=(upper,total_rhs,integer_weights)
            key=target,sign
            if key not in best or candidate<best[key]:best[key]=candidate
    positions=[list(x)for x in physical['positions']];proposals=[];used=set()
    for(target,sign),(upper,rhs,weights)in sorted(best.items()):
        proposals.append(dict(kind='scalar',key=target,sign=sign,objective=[[target,sign]],upper=str(upper),proved_upper=str(rhs),
            weights=weights,summed_rhs=str(rhs),residual_coefficients=[],residual_correction='0'))
        used.update(k for k,w in weights)
        if sign>0:positions[target][1]=min(positions[target][1],upper)
        else:positions[target][0]=max(positions[target][0],-upper)
    printed=[dict(index=k,coefficients=[[i,str(v)]for i,v in rows[k][0]],rhs=str(rows[k][1]),name=rows[k][2])for k in sorted(used)]
    rr=dict(before=S.CORE.state_view(state),propagated=S.CORE.state_view(physical),proposals=proposals,
        printed_rows=printed,absolute_variable_bounds=list(map(str,bounds)),numeric_failures=0,
        exact_existing_correlated_row_isolation=True,numerical_solves=0)
    positions=tuple(map(tuple,positions));scalar=physical['scalar']
    for k,(lo,hi)in enumerate(positions):
        if lo>hi:return None,rr,dict(kind='proved_empty_scalar',index=k,lower=str(lo),upper=str(hi))
    angles,term,identities=adapter.infer_angles(state['angles'],scalar);rr['physical_frame_inferences']=identities
    if term:return None,rr,dict(kind='proved_frame_contradiction',label=term)
    scalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(scalar,adapter.analytic(angles)))
    for k,(lo,hi)in enumerate(scalar):
        if lo>hi:return None,rr,dict(kind='proved_empty_analytic_frame',index=k,lower=str(lo),upper=str(hi))
    after=dict(deepcopy(physical),positions=positions,scalar=scalar,angles=angles)
    rr['after']=S.CORE.state_view(after)
    if not proposals and rr['before']==rr['after']:return state,None,None
    return after,rr,None
