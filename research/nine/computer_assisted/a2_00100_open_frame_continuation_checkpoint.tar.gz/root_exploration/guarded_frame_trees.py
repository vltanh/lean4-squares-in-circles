#!/usr/bin/env python3
"""Physical tree discovery under proved original-parent frame and position bounds."""
import argparse
import concurrent.futures
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import time
import warnings
import guarded_frame_bounds as G
from frontier_bounded_cells import children, verify_cell_union

V, np, linprog = G.V, G.np, G.linprog
ROOT=Path(__file__).resolve().parent
VERSION='exact_guarded_frame_physical_tree_v1'

def state(path, parent):
    assert path[:len(parent['path'])] == parent['path']
    angles,positions,choices=V.reconstruct(path)
    angles=tuple((max(l,F(a)),min(u,F(b))) for (l,u),(a,b) in zip(angles,parent['final_angles']))
    positions=tuple((max(l,F(a)),min(u,F(b))) for (l,u),(a,b) in zip(positions,parent['final_positions']))
    if any(l>u for l,u in angles+positions):
        return angles,positions,choices,None,'empty_inherited_interval'
    scalar=tuple((max(l,F(a)),min(u,F(b))) for (l,u),(a,b) in zip(G.base_frame_intervals(angles),parent['final_scalar']))
    if any(l>u for l,u in scalar):
        return angles,positions,choices,scalar,'empty_inherited_frame_interval'
    return angles,positions,choices,scalar,None

def solve(path,parent):
    angles,positions,choices,scalar,terminal=state(path,parent)
    if terminal:
        return {'path':path,'context_version':VERSION,'terminal':terminal},None,choices
    cuts=[]
    for rr in parent['rounds']:
        for cut in rr['circle_cuts']:
            if cut not in cuts:cuts.append(cut)
    assert len(cuts)<=48
    seen={tuple(c) for c in cuts}
    for attempt in range(3):
        rows,bounds,terminal=G.collect(path,angles,positions,choices,scalar,cuts)
        if terminal:
            return {'path':path,'context_version':VERSION,'terminal':terminal,'circle_cuts':cuts},None,choices
        a,b=G.matrix(rows,len(bounds));n=len(bounds)
        phase=linprog(np.r_[np.zeros(n),1.],A_ub=np.c_[a,-np.ones(len(b))],b_ub=b,
                      bounds=[(None,None)]*(n+1),method='highs',options={'threads':1,'time_limit':5})
        if not phase.success:return None,None,choices
        if phase.x[-1]>1e-8:
            weights=G.terms(phase.ineqlin.marginals)
            co,rhs=G.weighted_sum(rows,bounds,weights)
            reserve=-rhs-sum(m*abs(c) for m,c in zip(bounds,co))
            if reserve>0:
                return {'path':path,'context_version':VERSION,'weights':weights,
                        'circle_cuts':cuts,'checked_reserve':str(reserve)},None,choices
        z=phase.x[:-1]
        candidates=[]
        if len(cuts)>=48:break
        for i in range(9):
            for ss in (-1,1):
                for tt in (-1,1):
                    x=z[2*i]+(ss*z[18+i]-tt*z[27+i])/2
                    y=z[2*i+1]+(ss*z[27+i]+tt*z[18+i])/2
                    norm=math.hypot(x,y)
                    if norm*norm<=float(V.Q)+1e-7:continue
                    cut=(i,ss,tt,round((1<<20)*x/norm),round((1<<20)*y/norm),20)
                    if cut not in seen:candidates.append((norm*norm-float(V.Q),cut))
        if not candidates:break
        for _,cut in sorted(candidates,reverse=True)[:min(4,48-len(cuts))]:
            seen.add(cut);cuts.append(list(cut))
    return None,z,choices

def choose(z,choices):
    seen={(pair,kind) for pair,kind,ch in choices}
    proxy=[];sat=[]
    for i in range(9):
        for j in range(i+1,9):
            pair=(i,j)
            if (pair,'sat') in seen:continue
            dx,dy=z[2*j]-z[2*i],z[2*j+1]-z[2*i+1]
            gap=z[45+i]+z[45+j]-max(abs(dx),abs(dy))
            if (pair,'proxy') not in seen and gap>1e-7:proxy.append((float(gap),pair))
            ai,bi,aj,bj=z[18+i],z[27+i],z[18+j],z[27+j]
            support=.5*(1+abs(ai*aj+bi*bj)+abs(ai*bj-bi*aj))
            projection=max(abs(ai*dx+bi*dy),abs(-bi*dx+ai*dy),abs(aj*dx+bj*dy),abs(-bj*dx+aj*dy))
            sat.append((float(support-projection),pair))
    if proxy:return 'proxy',max(proxy)[1]
    if sat:return 'sat',max(sat)[1]
    return None

def run(file,limit):
    warnings.filterwarnings('ignore');raw=Path(file).read_bytes();parent=json.loads(raw)
    assert parent['status']=='OPEN' and parent['schema']==G.VERSION
    start=time.monotonic();prefix=parent['path'];pending=[prefix];leaves=[];frontier=[];decisions=[];nodes=0
    while pending and nodes<limit:
        path=pending.pop();nodes+=1
        leaf,z,choices=solve(path,parent)
        if leaf is not None:leaves.append(leaf);continue
        if z is None:
            frontier.append({'path':path,'reason':'NO_LP_POINT'});continue
        query=choose(z,choices)
        if query is None:
            frontier.append({'path':path,'reason':'ALL_PHYSICAL_PAIR_CHOICES_RETAINED','relaxed_variables':list(map(float,z))});continue
        decisions.append({'path':path,'query':[query[0],list(query[1])]})
        for step in reversed(children(query)):pending.append(path+[step])
    frontier.extend({'path':p,'reason':'NODE_LIMIT'} for p in pending)
    # This checks the full union even for partial trees; frontier is explicit.
    verify_cell_union(prefix,leaves+[{'path':f['path']} for f in frontier])
    record={'schema':VERSION,'id':parent['id'],'path':prefix,'parent_bound_sha256':hashlib.sha256(raw).hexdigest(),
            'parent_bound_certificate':str(file),'status':'CANDIDATE_CLOSED' if not frontier else 'OPEN',
            'nodes':nodes,'leaves':leaves,'frontier':frontier,'decisions':decisions,
            'seconds':time.monotonic()-start,'whole_mask_closed':False}
    out=ROOT/'guarded_trees';out.mkdir(exist_ok=True)
    (out/(parent['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(parent['id'],record['status'],'nodes',nodes,'leaves',len(leaves),'frontier',len(frontier),'seconds',round(record['seconds'],1),flush=True)
    return record

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--nodes',type=int,default=64);ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--limit',type=int,default=3);ap.add_argument('--offset',type=int,default=0);ap.add_argument('--ids',nargs='*')
    args=ap.parse_args()
    files=sorted((ROOT/'guarded_bounds').glob('*.json'))
    files=[f for f in files if f.stem!='positive-2c719a20ef7510de']
    if args.ids:files=[f for f in files if f.stem in args.ids]
    files=files[args.offset:]
    if args.limit:files=files[:args.limit]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run,str(p),args.nodes) for p in files]
        for f in concurrent.futures.as_completed(futures):f.result()

if __name__=='__main__':main()
