#!/usr/bin/env python3
"""Discovery of complete-parent certificates with acyclic physical frame bounds.

All numerical proposals are checked by exact rational row sums before the
next state is used. A separate reviewer is required for any accepted closure.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import argparse
import concurrent.futures
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import warnings

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
PREFIXES = BASE / 'physical_pilots/combined_bounds/prefixes'
sys.path.insert(0, str(BASE / 'physical_pilots/combined_bounds'))
sys.path.insert(0, str(BASE / 'physical_pilots/combined_bounds/whole_cell_payload'))
from bound_prefix import replay_prefix
from review_tight_bounds_independent import collect_rows, weighted_sum, printed_rows, VERIFIER_SHA256
import weak_outer_numeric_strict_bulk_v14_verify as V
import numpy as np
from scipy.optimize import linprog

SCALE = 1 << 40
ROUNDING = 1 << 20
VERSION = 'exact_guarded_frame_bound_induction_v1'

def guard_rows(path):
    xs = sorted({s[1][1] for s in path if s[0] == 'alternate_four_escape'
                 and s[1] in ([1, 7], [1, 8]) and s[2][0] in (6, 7)})
    rows = []
    for x in xs:
        rows.extend([
            (((2*x,F(1)),(2,F(-1)),(19,-F(1,2)),(37,-F(1,2)),(18+x,-F(1,2)),(36+x,-F(1,2))),F(0),f'guard_B{x}_weak'),
            (((2,F(1)),(2*x,F(-1)),(46,F(1)),(45+x,F(1))),F(0),f'guard_B{x}_inset'),
            (((2*x,F(1)),(6,F(-1)),(45+x,F(1)),(48,F(1))),F(0),f'guard_{x}D_inset'),
            (((5,F(1)),(2*x+1,F(-1)),(47,F(1)),(45+x,F(1))),F(0),f'guard_C{x}_vertical'),
        ])
    return rows

def base_frame_intervals(angles):
    frames = [V.normal_bounds(t) for t in angles]
    al = [a for a, b in frames]
    be = [b for a, b in frames]
    ab = [(V.beta_lower(t), max(abs(b[0]), abs(b[1]))) for t, (a,b) in zip(angles, frames)]
    gi = [(V.down(F(1,4)/V.h_bounds(t)[1]), V.up(F(1,4)/V.h_bounds(t)[0])) for t in angles]
    return al + be + ab + gi

def inverse_sine_interval(b):
    assert -1 < b < 1
    lower, upper = V.roots(1-b*b)
    assert lower > 0
    values = (b/lower, b/upper)
    return V.down(min(values)), V.up(max(values))

def narrow_angles(angles, scalar):
    result = []
    for i, (lo,hi) in enumerate(angles):
        al,be,ab = scalar[i], scalar[9+i], scalar[18+i]
        assert al[0] > 0 and al[1] > 0 and ab[0] >= 0
        if al[0] > 1 or ab[0] >= 1:
            return None, 'unit_frame_scalar_outside_range'
        # alpha=1/sqrt(1+t^2), beta=t/sqrt(1+t^2).
        limit = V.roots(1/(al[0]*al[0])-1)[1]
        lo,hi = max(lo,-limit), min(hi,limit)
        if not (-1 < be[0] <= be[1] < 1):
            return None, 'beta_interval_outside_unit_frame'
        lo = max(lo, inverse_sine_interval(be[0])[0])
        hi = min(hi, inverse_sine_interval(be[1])[1])
        if ab[1] < 1:
            limit = inverse_sine_interval(ab[1])[1]
            lo,hi = max(lo,-limit),min(hi,limit)
        if lo >= 0 or hi <= 0:
            lower_abs = inverse_sine_interval(ab[0])[0]
            if al[1] < 1:
                lower_abs = max(lower_abs,V.roots(1/(al[1]*al[1])-1)[0])
            if lo >= 0: lo = max(lo,lower_abs)
            if hi <= 0: hi = min(hi,-lower_abs)
        if lo > hi:
            return None, 'proved_empty_original_angle_interval'
        result.append((lo,hi))
    return tuple(result), None

def collect(path, angles, positions, choices, scalar, cuts):
    rows,bounds,terminal = collect_rows(V,path,angles,positions,choices,cuts)
    if terminal:
        return rows,bounds,terminal
    rows.extend(guard_rows(path))
    for j,(lo,hi) in enumerate(scalar):
        rows.append((((18+j,F(1)),),hi,f'certified_scalar_upper_{18+j}'))
        rows.append((((18+j,F(-1)),),-lo,f'certified_scalar_lower_{18+j}'))
    return rows,bounds,None

def matrix(rows,n):
    a=np.zeros((len(rows),n));b=np.zeros(len(rows))
    for j,(entries,rhs,name) in enumerate(rows):
        for k,c in entries: a[j,k]+=float(c)
        b[j]=float(rhs)
    return a,b

def terms(marginals):
    return [[i,int(round(-v*SCALE))] for i,v in enumerate(marginals) if int(round(-v*SCALE))>0]

def round_up(value):
    return F(-((-value*ROUNDING).numerator//(-value*ROUNDING).denominator),ROUNDING)

def save(record, suffix=''):
    (ROOT/'guarded_bounds').mkdir(exist_ok=True)
    (ROOT/'guarded_bounds'/(record['id']+suffix+'.json')).write_text(json.dumps(record,indent=2)+'\n')

def run(cell,max_rounds,frame_bounds):
    warnings.filterwarnings('ignore')
    start=time.monotonic();path=cell['path'];angles,positions,choices=V.reconstruct(path)
    prefix=PREFIXES/(cell['id']+'.json')
    record={'schema':VERSION,'id':cell['id'],'path':path,'status':'OPEN','rounds':[],
            'frame_bounds':frame_bounds,'whole_mask_closed':False,'guard_originals':len(guard_rows(path))//4}
    if prefix.exists():
        prefix_data=json.loads(prefix.read_text());assert prefix_data['path']==path
        positions,number=replay_prefix(prefix_data)
        record.update(prefix_sha256=hashlib.sha256(prefix.read_bytes()).hexdigest(),prefix_deductions=number)
    else:
        record.update(prefix_sha256=None,prefix_deductions=0)
    positions=tuple(map(tuple,positions));scalar=tuple(base_frame_intervals(angles));cuts=[];cut_seen=set()
    record['initial_angles']=[[str(v) for v in p] for p in angles]
    for ri in range(max_rounds+1):
        rows,bounds,terminal=collect(path,angles,positions,choices,scalar,cuts)
        state={'round':ri,'angles_before':[[str(v) for v in p] for p in angles],
               'positions_before':[[str(v) for v in p] for p in positions],
               'scalar_before':[[str(v) for v in p] for p in scalar], 'circle_cuts':list(cuts)}
        if terminal:
            record.update(status='CANDIDATE_CLOSED',terminal={'kind':'native_analytic','label':terminal,'state':state});break
        a,b=matrix(rows,len(bounds));n=len(bounds)
        # Floating discovery never changes a state without an exact sum.
        phase=linprog(np.r_[np.zeros(n),1.],A_ub=np.c_[a,-np.ones(len(b))],b_ub=b,
                      bounds=[(None,None)]*(n+1),method='highs',options={'threads':1,'time_limit':8})
        if not phase.success:
            record['solver_status']=int(phase.status);break
        state['phase1']=float(phase.x[-1])
        if phase.x[-1]>1e-8:
            weights=terms(phase.ineqlin.marginals);co,rhs=weighted_sum(rows,bounds,weights)
            reserve=-rhs-sum(m*abs(c) for m,c in zip(bounds,co))
            if reserve>0:
                record.update(status='CANDIDATE_CLOSED',terminal={'kind':'positive_rational_reserve','weights':weights,
                    'reserve':str(reserve),'state':state});break
            record.setdefault('rejected_numeric_terminals',[]).append(str(reserve))
        # Valid original-corner support cuts, independent of the LP point's feasibility.
        extra_cuts=[];z=phase.x[:-1]
        for i in range(9):
            for ss in (-1,1):
                for tt in (-1,1):
                    x=z[2*i]+(ss*z[18+i]-tt*z[27+i])/2
                    y=z[2*i+1]+(ss*z[27+i]+tt*z[18+i])/2
                    norm=math.hypot(x,y)
                    if norm*norm<=float(V.Q)+1e-7:continue
                    cut=(i,ss,tt,round((1<<20)*x/norm),round((1<<20)*y/norm),20)
                    if cut not in cut_seen:extra_cuts.append((norm*norm-float(V.Q),cut))
        nextpos=[list(p) for p in positions];nextscalar=[list(p) for p in scalar];proposals=[]
        if ri==max_rounds:break
        for k in range(54 if frame_bounds else 18):
            for sign in (-1,1):
                objective=np.zeros(n);objective[k]=-sign
                optimum=linprog(objective,A_ub=a,b_ub=b,bounds=[(None,None)]*n,method='highs',
                                options={'threads':1,'time_limit':3})
                if not optimum.success:continue
                previous=positions[k] if k<18 else scalar[k-18]
                old=previous[1] if sign==1 else -previous[0]
                if float(old)+optimum.fun<0.0005:continue
                weights=terms(optimum.ineqlin.marginals);co,rhs=weighted_sum(rows,bounds,weights);co[k]-=sign
                proved=rhs+sum(m*abs(c) for m,c in zip(bounds,co));upper=round_up(proved)
                if old-upper < F(1,2000):continue
                proposals.append({'objective':[[k,sign]],'upper':str(upper),'weights':weights,'proved_upper':str(proved)})
                target=nextpos[k] if k<18 else nextscalar[k-18]
                if sign==1:target[1]=min(target[1],upper)
                else:target[0]=max(target[0],-upper)
        state['proposals']=proposals
        positions=tuple(map(tuple,nextpos));scalar=tuple(map(tuple,nextscalar))
        if any(lo>hi for lo,hi in positions+scalar):
            record['rounds'].append(state);record.update(status='CANDIDATE_CLOSED',terminal={'kind':'proved_empty_scalar_interval'});break
        new_angles,contradiction=narrow_angles(angles,scalar)
        if contradiction:
            record['rounds'].append(state);record.update(status='CANDIDATE_CLOSED',terminal={'kind':contradiction});break
        angles=new_angles
        # Intersect analytic frame intervals only after all old-round deductions.
        frame_now=base_frame_intervals(angles)
        scalar=tuple((max(l,a),min(u,b)) for (l,u),(a,b) in zip(scalar,frame_now))
        if any(l>u for l,u in scalar):
            record['rounds'].append(state);record.update(status='CANDIDATE_CLOSED',terminal={'kind':'proved_empty_analytic_frame_interval'});break
        state['angles_after']=[[str(v) for v in p] for p in angles]
        record['rounds'].append(state)
        for _,cut in sorted(extra_cuts,reverse=True)[:min(8,48-len(cuts))]:cut_seen.add(cut);cuts.append(list(cut))
        record.update(seconds=time.monotonic()-start,
                      final_angles=[[str(v) for v in p] for p in angles],
                      final_positions=[[str(v) for v in p] for p in positions],
                      final_scalar=[[str(v) for v in p] for p in scalar])
        save(record)
        print(cell['id'],'round',ri,'exact_deductions',len(proposals),'cuts',len(cuts),'seconds',round(record['seconds'],1),flush=True)
        if not proposals and not extra_cuts:break
    record['seconds']=time.monotonic()-start
    save(record)
    print(cell['id'],record['status'],'rounds',len(record['rounds']),'seconds',round(record['seconds'],1),flush=True)
    return record

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--rounds',type=int,default=4);ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--limit',type=int,default=3);ap.add_argument('--offset',type=int,default=0);ap.add_argument('--no-frame',action='store_true')
    args=ap.parse_args()
    data=json.loads((BASE/'global_masks/guarded_original_parent_report.json').read_text())
    ids={r['id'] for r in data['results']}
    cells=[c for c in json.loads((BASE/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json').read_text())['cells'] if c['status']=='OPEN' and c['id'] in ids]
    cells=cells[args.offset:]
    if args.limit:cells=cells[:args.limit]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run,c,args.rounds,not args.no_frame) for c in cells]
        for fut in concurrent.futures.as_completed(futures):fut.result()

if __name__=='__main__':main()
