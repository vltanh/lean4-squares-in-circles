#!/usr/bin/env python3
"""Independent acyclic bound induction, complete child union, and leaf sums.

This reviewer does not import run_combined or the discovery solver. It uses
the accepted exact v14 row formulas and the earlier independent unweighted
row collector, sums every rational multiplier itself, and reconstructs each
whole-parent physical branch trie independently.
"""
import argparse,hashlib,json,sys,time
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from review_tight_bounds_independent import collect_rows,weighted_sum,printed_rows,VERIFIER_SHA256

def check_union(prefix,leaves):
 root={}
 for leaf in leaves:
  path=leaf['path'];assert path[:len(prefix)]==prefix
  V.reconstruct(path)
  node=root
  for step in path[len(prefix):]:
   assert len(step)==3 and step[0] in ('proxy','sat')
   kind,pair,choice=step;pair=tuple(pair);choice=tuple(choice)
   assert len(pair)==2 and 0<=pair[0]<pair[1]<9
   assert not node.get('terminal')
   query=(kind,pair)
   if 'query' in node:assert node['query']==query
   else:node['query']=query;node['children']={}
   node=node['children'].setdefault(choice,{})
  assert not node;node['terminal']=True
 def visit(node):
  if node.get('terminal'):assert set(node)=={'terminal'};return
  kind,pair=node['query']
  choices={(axis,sign) for axis in (0,1) for sign in (-1,1)} if kind=='proxy' else {(owner,axis,sign) for owner in pair for axis in (0,1) for sign in (-1,1)}
  assert set(node['children'])==choices
  for child in node['children'].values():visit(child)
 visit(root)

def verify(record,register,prefix_record):
 assert record['status']=='CLOSED' and not record['frontier'] and not record.get('errors')
 original=register[record['id']];assert original['status']=='OPEN'
 path=record['path'];assert path==original['path']==prefix_record['path']
 identity=original['sign']+'-'+hashlib.sha256(json.dumps(path,separators=(',',':')).encode()).hexdigest()[:16]
 assert identity==record['id']==prefix_record['id']
 assert hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest()==VERIFIER_SHA256
 box,positions,choices=V.reconstruct(path);positions=tuple(map(tuple,positions));deductions=0;prefix_tables=[]
 for ri,rr in enumerate(prefix_record['rounds']):
  rows,bounds,terminal=collect_rows(V,path,box,positions,choices)
  assert terminal is None
  changed=[list(p) for p in positions];prints=[];used=set()
  for proposal in rr['proposals']:
   assert type(proposal['objective'])is list and len(proposal['objective'])==1
   k,sg=proposal['objective'][0];assert type(k)is int and 0<=k<18 and type(sg)is int and sg in (-1,1)
   upper=F(proposal['upper']);co,rhs=weighted_sum(rows,bounds,proposal['weights']);co[k]-=sg
   proved=rhs+sum(m*abs(c) for m,c in zip(bounds,co));assert proved<=upper
   if sg==1:changed[k][1]=min(changed[k][1],upper)
   else:changed[k][0]=max(changed[k][0],-upper)
   deductions+=1;used.update(index for index,_ in proposal['weights'])
   prints.append({'coordinate':k,'sign':sg,'upper':str(upper),'proved_upper':str(proved),'weights':proposal['weights'],'residual':list(map(str,co)),'rhs':str(rhs)})
  prefix_tables.append({'round':ri,'positions_before':[[str(a),str(b)] for a,b in positions],'rows':printed_rows(rows,used),'absolute_variable_bounds':list(map(str,bounds)),'deductions':prints,'positions_after':[[str(a),str(b)] for a,b in changed]})
  positions=tuple(map(tuple,changed));assert all(a<=b for a,b in positions)
 assert deductions==record['verified_bound_deductions']
 assert positions==tuple(tuple(F(x) for x in p) for p in record['proved_parent_positions'])
 check_union(path,record['leaves'])
 leaf_tables=[];weighted=0;least=None
 for li,leaf in enumerate(record['leaves']):
  angles,pos,ch=V.reconstruct(leaf['path'])
  if leaf.get('uses_inherited_bounds'):
   assert leaf['uses_inherited_bounds']is True
   pos=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(pos,positions));assert all(a<=b for a,b in pos)
  rows,bounds,terminal=collect_rows(V,leaf['path'],angles,pos,ch,leaf.get('circle_cuts',()),leaf if leaf.get('analytic_terminal') else None)
  entry={'leaf_index':li,'path':leaf['path'],'uses_inherited_bounds':bool(leaf.get('uses_inherited_bounds')),'positions':[[str(a),str(b)] for a,b in pos],'terminal':terminal}
  if terminal is None:
   co,rhs=weighted_sum(rows,bounds,leaf['weights']);reserve=-rhs-sum(m*abs(c) for m,c in zip(bounds,co));assert reserve>0
   if leaf.get('checked_reserve'):assert reserve==F(leaf['checked_reserve'])
   entry.update(rows=printed_rows(rows,{index for index,_ in leaf['weights']}),weights=leaf['weights'],coefficient_sum=list(map(str,co)),rhs_sum=str(rhs),absolute_variable_bounds=list(map(str,bounds)),positive_reserve=str(reserve))
   weighted+=1;least=reserve if least is None else min(least,reserve)
  leaf_tables.append(entry)
 return {'id':record['id'],'status':'PASS_COMPLETE_ORIGINAL_PARENT','bound_deductions':deductions,'leaves':len(record['leaves']),'weighted_leaves':weighted,'least_reserve':str(least)}, {'id':record['id'],'parent_path':path,'prefix_tables':prefix_tables,'leaf_tables':leaf_tables}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('report');ap.add_argument('--name',default='combined_exact_review');args=ap.parse_args()
 raw=Path(args.report).read_bytes();data=json.loads(raw);reg=json.loads((HERE/'whole_cell_payload/fixed_231_register.json').read_text());register={r['id']:r for r in reg['cells']};records=[r for r in data['results'] if r['status']=='CLOSED'];reviews=[];tables=[];start=time.monotonic()
 for record in records:
  file=HERE/'prefixes'/(record['id']+'.json');assert hashlib.sha256(file.read_bytes()).hexdigest()==record['prefix_sha256']
  review,table=verify(record,register,json.loads(file.read_text()));reviews.append(review);tables.append(table);print(review,flush=True)
 output={'status':'PASS','original_parents':len(records),'source_report_sha256':hashlib.sha256(raw).hexdigest(),'verified_bound_deductions':sum(r['bound_deductions'] for r in reviews),'leaves':sum(r['leaves'] for r in reviews),'weighted_leaves':sum(r['weighted_leaves'] for r in reviews),'reviews':reviews,'seconds':time.monotonic()-start,'whole_mask_closed':False}
 (HERE/(args.name+'.json')).write_text(json.dumps(output,indent=2)+'\n');(HERE/(args.name+'_tables.json')).write_text(json.dumps({'parents':tables,'whole_mask_closed':False},indent=2)+'\n');print(output,flush=True)
if __name__=='__main__':main()
