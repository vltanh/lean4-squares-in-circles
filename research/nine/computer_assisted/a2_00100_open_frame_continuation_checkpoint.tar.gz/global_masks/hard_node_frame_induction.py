#!/usr/bin/env python3
"""Two bounded local-induction rounds on retained original-parent children."""
import argparse,json,math,sys,time,warnings
from pathlib import Path
from fractions import Fraction as F
import review_guarded_frame_bounds_independent as R
import numpy as np
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent
VERSION='exact_guarded_frame_node_induction_v1';SCALE=1<<40;ROUNDING=1<<20
warnings.filterwarnings('ignore')

def matrix(rows,n):
 a=np.zeros((len(rows),n));b=np.zeros(len(rows))
 for i,(entries,rhs,name)in enumerate(rows):
  for k,c in entries:a[i,k]+=float(c)
  b[i]=float(rhs)
 return a,b

def weights(marginals):return [[i,int(round(-v*SCALE))]for i,v in enumerate(marginals)if int(round(-v*SCALE))>0]
def ceil_bound(value):return F(-((-value*ROUNDING).numerator//(-value*ROUNDING).denominator),ROUNDING)

def run(parent,path,maximum_rounds,index,resume=False):
 angles,pos,ch,scalar,terminal=R.child_state(parent,path);start=time.monotonic()
 record={'schema':VERSION,'id':parent['id'],'path':path,'node_index':index,'status':'OPEN','rounds':[],
         'initial_angles':R.render(angles),'initial_positions':R.render(pos),'initial_scalar':None if scalar is None else R.render(scalar)}
 if terminal:
  record.update(status='CANDIDATE_CLOSED',terminal={'kind':terminal});return record
 cuts=[];first_round=0
 previous_file=ROOT/'node_frame_certificates'/f'node_{index:02d}.json'
 if resume and previous_file.exists():
  record=json.loads(previous_file.read_text());assert record['path']==path and record['status']=='OPEN'
  resumed,review,table=R.verify_node_induction(parent,record)
  angles,pos,scalar=resumed['angles'],resumed['positions'],resumed['scalar'];first_round=len(record['rounds'])
  if record['rounds']:cuts=[list(c)for c in record['rounds'][-1]['circle_cuts']]
 seen={tuple(c)for c in cuts}
 for ri in range(first_round,maximum_rounds+1):
  state={'round':ri,'angles_before':R.render(angles),'positions_before':R.render(pos),'scalar_before':R.render(scalar),'circle_cuts':cuts[:]}
  rows,bounds,terminal=R.collect_guarded(path,angles,pos,ch,scalar,cuts)
  if terminal:
   record.update(status='CANDIDATE_CLOSED',terminal={'kind':'native_analytic','label':terminal,'state':state});break
  a,b=matrix(rows,len(bounds));n=len(bounds)
  phase=linprog(np.r_[np.zeros(n),1.],A_ub=np.c_[a,-np.ones(len(b))],b_ub=b,bounds=[(None,None)]*(n+1),method='highs',options={'threads':1,'time_limit':6})
  if not phase.success:record['solver_status']=int(phase.status);break
  if phase.x[-1]>1e-8:
   terms=weights(phase.ineqlin.marginals);co,rhs=R.weighted_sum(rows,bounds,terms);reserve=-rhs-sum(m*abs(c)for m,c in zip(bounds,co))
   if reserve>0:
    record.update(status='CANDIDATE_CLOSED',terminal={'kind':'positive_rational_reserve','weights':terms,'reserve':str(reserve),'state':state});break
  if ri==maximum_rounds:
   record['relaxed_variables']=list(map(float,phase.x[:-1]));break
  candidates=[];z=phase.x[:-1]
  for i in range(9):
   for s in (-1,1):
    for t in (-1,1):
     x=z[2*i]+(s*z[18+i]-t*z[27+i])/2;y=z[2*i+1]+(s*z[27+i]+t*z[18+i])/2
     norm=math.hypot(x,y)
     if norm*norm<=float(R.V.Q)+1e-7:continue
     cut=(i,s,t,round((1<<20)*x/norm),round((1<<20)*y/norm),20)
     if cut not in seen:candidates.append((norm*norm-float(R.V.Q),cut))
  changed=[list(p)for p in pos+scalar];proposals=[]
  for k in range(54):
   for sign in (-1,1):
    objective=np.zeros(n);objective[k]=-sign
    fit=linprog(objective,A_ub=a,b_ub=b,bounds=[(None,None)]*n,method='highs',options={'threads':1,'time_limit':3})
    if not fit.success:continue
    old=(pos+scalar)[k][1]if sign==1 else-(pos+scalar)[k][0]
    if float(old)+fit.fun<.0005:continue
    terms=weights(fit.ineqlin.marginals);co,rhs=R.weighted_sum(rows,bounds,terms);co[k]-=sign
    proved=rhs+sum(m*abs(c)for m,c in zip(bounds,co));upper=ceil_bound(proved)
    if old-upper<F(1,2000):continue
    proposals.append({'objective':[[k,sign]],'upper':str(upper),'proved_upper':str(proved),'weights':terms})
    if sign==1:changed[k][1]=min(changed[k][1],upper)
    else:changed[k][0]=max(changed[k][0],-upper)
  state['proposals']=proposals;record['rounds'].append(state);changed=tuple(map(tuple,changed));pos,scalar=changed[:18],changed[18:]
  if any(l>u for l,u in changed):
   record.update(status='CANDIDATE_CLOSED',terminal={'kind':'proved_empty_scalar_interval'});break
  new_angles,terminal,identities=R.infer_angles(angles,scalar)
  if terminal:
   record.update(status='CANDIDATE_CLOSED',terminal={'kind':terminal});break
  angles=new_angles;frame=R.analytic_frames(angles);scalar=tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(scalar,frame))
  if any(l>u for l,u in scalar):
   record.update(status='CANDIDATE_CLOSED',terminal={'kind':'proved_empty_analytic_frame_interval'});break
  state['angles_after']=R.render(angles)
  for _,cut in sorted(candidates,reverse=True)[:min(8,48-len(cuts))]:seen.add(cut);cuts.append(list(cut))
  record.update(final_angles=R.render(angles),final_positions=R.render(pos),final_scalar=R.render(scalar),seconds=time.monotonic()-start)
  out=ROOT/'node_frame_certificates';out.mkdir(exist_ok=True);(out/f'node_{index:02d}.json').write_text(json.dumps(record,indent=2)+'\n')
  print('node',index,'round',ri,'deductions',len(proposals),'seconds',round(record['seconds'],1),flush=True)
 record.update(final_angles=R.render(angles),final_positions=R.render(pos),final_scalar=R.render(scalar),seconds=time.monotonic()-start)
 out=ROOT/'node_frame_certificates';out.mkdir(exist_ok=True);(out/f'node_{index:02d}.json').write_text(json.dumps(record,indent=2)+'\n')
 print('node',index,record['status'],'rounds',len(record['rounds']),'seconds',round(record['seconds'],1),flush=True)
 return record

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int,default=3);ap.add_argument('--offset',type=int,default=0);ap.add_argument('--rounds',type=int,default=2);ap.add_argument('--resume',action='store_true');args=ap.parse_args()
 parentfile=ROOT.parent/'root_exploration/guarded_bounds/positive-2c719a20ef7510de.json';parent,review,table=R.load_parent(parentfile)
 source=json.loads((ROOT/'hard_guarded_frame_filter_report.json').read_text());results=[]
 for index,f in enumerate(source['frontier'][args.offset:args.offset+args.limit],args.offset):results.append(run(parent,f['path'],args.rounds,index,args.resume))
 report={'id':source['id'],'parent_bound_sha256':R.sha(parentfile),'parent_bound_certificate':str(parentfile),'results':results,'whole_mask_closed':False}
 (ROOT/f'node_frame_report_{args.offset}_{args.limit}.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
