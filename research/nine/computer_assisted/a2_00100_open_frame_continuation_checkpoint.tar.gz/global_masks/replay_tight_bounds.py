#!/usr/bin/env python3
"""Exact proof replay of an acyclic sequence of derived center bounds.

The frozen v14 source is used only to regenerate the physical scalar rows.
Each successive box restriction is first deduced by a nonnegative rational
row sum, with residual coefficients bounded explicitly. No LP is imported.
"""
import argparse,hashlib,json,sys,time
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent;PAYLOAD=ROOT/'whole_cell_payload'
sys.path.insert(0,str(PAYLOAD))
import weak_outer_numeric_strict_bulk_v14_verify as V
VERSION='strict_bulk_2026_11_03_v14'

def frozen_sum(path,box,pos,choices,weights,cuts=(),terminal=None):
    """Regenerate the exact row sum on already certified intervals."""
    saved_reconstruct=V.reconstruct;captured={}
    def certified_reconstruct(requested):
        assert requested==path
        return box,pos,choices
    def profile(frame,event,arg):
        if event=='return' and frame.f_code.co_filename==V.__file__ and frame.f_code.co_name=='replay_current_leaf':
            local=frame.f_locals
            if all(k in local for k in ('rr','bb','bounds','index')):
                captured.update(residual=tuple(local['rr']),rhs=local['bb'],bounds=tuple(local['bounds']),row_count=local['index'])
    leaf={'path':path,'weights':weights,'power':40,'circle_cuts':list(cuts),'context_version':VERSION}
    if terminal:leaf.update(terminal)
    V.reconstruct=certified_reconstruct;sys.setprofile(profile)
    try:
        try:result=V.replay_current_leaf(leaf)
        except AssertionError as error:
            payload=error.args[0] if error.args else None
            if not (isinstance(payload,tuple) and payload[0]=='nonpositive exact rational leaf' and captured):raise
            result=None
    finally:
        sys.setprofile(None);V.reconstruct=saved_reconstruct
    return captured,result

def replay(record):
    path=record['path'];box,pos,choices=V.reconstruct(path)
    pos=[list(v) for v in pos];deductions=[];least=None
    for ri,round_record in enumerate(record['rounds']):
        # Every row in one round uses the same previous certified box.
        # Restrictions from this round are applied only after all checks.
        nextpos=[v[:] for v in pos]
        for pi,p in enumerate(round_record['proposals']):
            c={}
            assert isinstance(p['objective'],list) and len(p['objective'])==1
            k,sg=p['objective'][0]
            assert type(k) is int and 0<=k<18 and type(sg) is int and sg in (-1,1)
            c[k]=F(sg);upper=F(p['upper'])
            total,result=frozen_sum(path,box,tuple(tuple(v) for v in pos),choices,p['weights'])
            if result is not None:
                return {'status':'CLOSED','id':record['id'],'rounds':ri,'bounds_verified':len(deductions),'early_terminal':str(result),'deductions':deductions}
            scale=1<<40
            residual=[v/scale-c.get(i,F(0)) for i,v in enumerate(total['residual'])]
            proven=total['rhs']/scale+sum(m*abs(r) for m,r in zip(total['bounds'],residual))
            assert proven<=upper,('unproved center bound',record['id'],ri,pi,str(proven),str(upper))
            margin=upper-proven;least=margin if least is None else min(least,margin)
            if sg==1:nextpos[k][1]=min(nextpos[k][1],upper)
            else:nextpos[k][0]=max(nextpos[k][0],-upper)
            deductions.append({'round':ri,'index':pi,'coordinate':k,'sign':sg,'upper':str(upper),'proved_upper':str(proven),'slack':str(margin)})
        pos=nextpos
        if any(lo>hi for lo,hi in pos):
            return {'status':'CLOSED','id':record['id'],'rounds':ri+1,'bounds_verified':len(deductions),'empty_interval':True,'deductions':deductions}
    assert record.get('candidate_terminal'), 'No claimed terminal'
    final=record['candidate_terminal']
    _,result=frozen_sum(path,box,tuple(tuple(v) for v in pos),choices,final.get('weights',[]),final.get('circle_cuts',[]),final)
    assert result is not None, 'Final original-cell contradiction failed'
    reserve,terminal=result
    return {'status':'CLOSED','id':record['id'],'rounds':len(record['rounds']),'bounds_verified':len(deductions),'least_bound_slack':str(least),'final_reserve':str(reserve),'final_terminal':terminal,'deductions':deductions}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('file',type=Path);ap.add_argument('--out',type=Path);args=ap.parse_args();start=time.monotonic()
    record=json.loads(args.file.read_text());report=replay(record)
    report.update(source_sha256=hashlib.sha256(args.file.read_bytes()).hexdigest(),verifier_sha256=hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest(),seconds=time.monotonic()-start)
    if args.out:args.out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='deductions'},indent=2))
if __name__=='__main__':main()
