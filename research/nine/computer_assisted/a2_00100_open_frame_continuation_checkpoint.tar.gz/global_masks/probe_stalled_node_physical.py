#!/usr/bin/env python3
"""Bounded physical/sign probe on two retained children with reviewed bounds."""
import concurrent.futures,json,sys,time,warnings
from pathlib import Path
import review_guarded_frame_bounds_independent as R
from audit_guarded_continuation import union
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'root_exploration'))
import guarded_frame_trees as T
from frontier_bounded_cells import children
warnings.filterwarnings('ignore')

def run(index,limit=32):
 parent,_,_=R.load_parent(ROOT.parent/'root_exploration/guarded_bounds/positive-2c719a20ef7510de.json')
 file=ROOT/'node_frame_certificates'/f'node_{index:02d}.json';node=json.loads(file.read_text())
 local,review,table=R.verify_node_induction(parent,node);assert review['status']=='PASS_CERTIFIED_CHILD_STATE'
 pending=[node['path']];leaves=[];frontier=[];decisions=[];count=0;start=time.monotonic()
 while pending and count<limit:
  path=pending.pop();count+=1;leaf,z,ch=T.solve(path,node)
  if leaf:
   checked,_=R.verify_tree_leaf(local,leaf);leaf['independent_replay']=checked;leaves.append(leaf);continue
  if z is None:frontier.append({'path':path,'reason':'NO_POINT'});continue
  original_angles,_,_=R.V.reconstruct(path)
  defects=[(z[36+i]-abs(z[27+i]),i)for i,(lo,hi)in enumerate(original_angles)if lo<0<hi and z[36+i]-abs(z[27+i])>.003]
  query=('angle_cut',(max(defects)[1],'0'))if defects else T.choose(z,ch)
  if query is None:frontier.append({'path':path,'reason':'NO_QUERY'});continue
  decisions.append({'path':path,'query':query})
  for step in reversed(children(query)):pending.append(path+[step])
 frontier.extend({'path':path,'reason':'NODE_LIMIT'}for path in pending)
 union(node['path'],leaves+frontier)
 out={'schema':'exact_guarded_local_frame_physical_probe_v1','id':parent['id'],'node_index':index,'path':node['path'],
      'node_bound_sha256':R.sha(file),'status':'CLOSED_CHILD'if not frontier else'OPEN','nodes':count,
      'leaves':leaves,'frontier':frontier,'decisions':decisions,'seconds':time.monotonic()-start,'whole_mask_closed':False}
 (ROOT/f'node_{index:02d}_physical_probe.json').write_text(json.dumps(out,indent=2)+'\n')
 print('NODE',index,out['status'],'nodes',count,'leaves',len(leaves),'pending',len(frontier),'seconds',round(out['seconds'],1),flush=True)
 return out

if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(max_workers=2)as pool:
  for result in pool.map(run,(0,2)):pass
