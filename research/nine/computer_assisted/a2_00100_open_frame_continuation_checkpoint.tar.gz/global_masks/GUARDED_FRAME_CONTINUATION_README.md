# Guarded original-frame continuation checkpoint

This checkpoint preserves unfinished work on the immutable original
`positive-2c719a20ef7510de` cell of the `001/00` cover. **The original cell
remains OPEN.** It supplies no whole-mask closure and no replacement gate.
Its current complete split cover contains 4,034 proved terminal paths and
10 explicit unresolved paths.

## Exact contents and scope

The mixed checkpoint retains all 3,787 native v14 proof leaves, 208 leaves
using the proved unique-penultimate guarded rows, 11 leaves using certified
parent frame and center bounds, three complete node-local induction proofs,
and one complete 25-leaf physical subtree under a certified node state.
Earlier contexts are retained; old midpoint and sign splits are decoded
against their original intervals before any new proved bounds are intersected.

The new geometric input is the separately reviewed hand theorem
`WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md`. On the original
normalized `001/00` caller, any center-cone main chain A',B',X,D disjoint
from the same actual E,F,G and having its first two links actual must have
X=C. For an A,B,X,D center-cone caller with X distinct from C, this gives
strictly weak BX and, together with the original C bottom exclusion,
vertical separation of C and X by their physical aligned insets.

The frame induction is an independent reusable step. A nonnegative exact
row sum first proves bounds on the actual original coordinates, alpha,
beta, absolute beta, and inset halfwidth. Every bound in one round uses
the same previous state. The physical identities
alpha²+beta²=1, alpha>0, and slope=beta/alpha then narrow the original slope
interval. Analytic frame bounds are intersected only after that round.
No LP point, floating solver status, or reported box supplies a premise.
The same procedure works when there are no qualifying geometric guards;
in that case it inserts zero guarded rows.

The first 14 original-parent frame certificates have independent printed
row-sum reviews: 405 older coordinate deductions and 823 new original-variable
deductions. All 14 node-local certificates for this hard parent were also
independently replayed, totaling 874 deductions. Nodes 1, 3, and 13 close
by that induction; node 0 closes with its subsequent complete physical
subtree. Node 2's incomplete 32-node physical probe is preserved separately
and does not remove its unresolved path from the top-level checkpoint.

The packet also retains the independently verified complete original-parent
certificate for `negative-547e512df0c949e9`: 99 older and 128 new deductions,
followed by a positive rational reserve. That distinct original-parent
closure is reported separately from this unfinished hard-cell checkpoint.

## Replay

Extract the archive and retain its relative folder layout. From its root,
run:

```sh
python global_masks/audit_guarded_continuation.py
```

This independently verifies the exact unfinished child union, the certified
parent state, all 208 guarded leaves, the 11 parent-frame leaves, the three
node-induction terminal proofs, and the complete local physical subtree.
It prints the unresolved count and explicitly keeps the original cell OPEN.
The optional `--replay-native` flag also repeats all 3,787 native exact
v14 leaf checks. Those native leaves were already replayed during discovery;
the default checkpoint audit does not claim to repeat that older work.

The independent reviewer imports no producer or optimizer. Its public APIs
are `load_parent`, `verify_parent`, `collect_guarded`, `child_state`,
`verify_tree_leaf`, `verify_tree_record`, and `verify_node_induction`.
The packet contains the frozen, hash-bound physical verifier and its
standard-library dependencies, the old certified coordinate prefixes,
the parent and node certificates, printed proof tables, and discovery code
for continuation. SciPy and NumPy are needed only for new discovery.

All files are listed with SHA-256 hashes in the packet manifest. The
immutable 231-cell register is included for identity and original-path
checks. Neither that register nor the main project closure ledgers are
changed by this continuation packet.
