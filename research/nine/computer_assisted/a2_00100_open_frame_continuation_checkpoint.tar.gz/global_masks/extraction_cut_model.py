#!/usr/bin/env python3
"""Guarded hand-theorem rows, unchanged v14 physical rows, exact rational replay.
The extra theorem is proved in WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md.
"""
import sys,json,hashlib
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from replay_tight_bounds import frozen_sum
VERSION='unique_penultimate_guarded_rows_v1'

def extra_specs(path):
 box,pos,ch=V.reconstruct(path)
 originals=sorted({p[1]for p,kind,choice in ch if kind=='alternate_four_escape'and p in ((1,7),(1,8))and choice[0]>=6})
 rows=[]
 for x in originals:
  rows.extend([
   (f'B{x}_strictly_weak',[(2*x,F(1)),(2,F(-1)),(19,F(-1,2)),(37,F(-1,2)),(18+x,F(-1,2)),(36+x,F(-1,2))],F(0)),
   (f'B{x}_cone_inset',[(2,F(1)),(2*x,F(-1)),(46,F(1)),(45+x,F(1))],F(0)),
   (f'{x}D_cone_inset',[(2*x,F(1)),(6,F(-1)),(45+x,F(1)),(48,F(1))],F(0)),
   (f'C{x}_vertical_inset',[(5,F(1)),(2*x+1,F(-1)),(47,F(1)),(45+x,F(1))],F(0)),
  ])
 return rows

def replay(leaf,certified_positions=None):
 assert leaf['context_version']==VERSION
 path=leaf['path'];box,pos,ch=V.reconstruct(path)
 if certified_positions is not None:
  assert len(certified_positions)==18
  pos=tuple((max(a,F(c)),min(b,F(d)))for (a,b),(c,d)in zip(pos,certified_positions))
  assert all(a<=b for a,b in pos)
 specs=extra_specs(path);assert specs and leaf['extra_row_names']==[x[0]for x in specs]
 assert type(leaf['native_row_count'])is int and leaf['native_row_count']>0
 native=leaf['native_weights'];extra=leaf['extra_weights']
 for index,weight in native:
  assert type(index)is int and 0<=index<leaf['native_row_count'] and type(weight)is int and weight>0
 for index,weight in extra:
  assert type(index)is int and 0<=index<len(specs)and type(weight)is int and weight>0
 total,previous=frozen_sum(path,box,pos,ch,native,leaf.get('circle_cuts',()))
 if previous is not None and not total:
  return {'status':'PASS','terminal':'native analytic contradiction','reserve':None,'extra_rows_used':0}
 assert total['row_count']==leaf['native_row_count'],('rowcount',total['row_count'],leaf['native_row_count'])
 rr=list(total['residual']);bb=total['rhs'];scale=1<<40
 for index,weight in extra:
  _,entries,rhs=specs[index];bb+=weight*rhs
  for k,c in entries:rr[k]+=weight*c
 reserve=(-bb-sum(m*abs(r)for m,r in zip(total['bounds'],rr)))/scale
 assert reserve>0,('nonpositive guarded extraction reserve',str(reserve))
 return {'status':'PASS','reserve':str(reserve),'extra_rows_used':len(extra),'extra_row_names':leaf['extra_row_names'],'native_rows':leaf['native_row_count']}

def discover(path,certified_positions=None,adaptive=True):
 import numpy as np
 from math import sqrt
 from scipy.optimize import linprog
 import weak_outer_numeric_strict_bulk_v14_lp as M
 box,pos,ch=V.reconstruct(path)
 if certified_positions is not None:pos=tuple((max(a,F(c)),min(b,F(d)))for(a,b),(c,d)in zip(pos,certified_positions))
 fl=lambda a:tuple(tuple(map(float,z))for z in a)
 cuts=[];seen=set();specs=extra_specs(path);assert specs
 for iteration in range(13 if adaptive else 1):
  A,B,names,cb,hs,gs=M.matrix(fl(box),fl(pos),ch,cuts);native_count=len(B)
  N=A.shape[1];extra=[];rhs=[]
  for name,entries,b in specs:
   row=np.zeros(N)
   for k,c in entries:row[k]+=float(c)
   extra.append(row);rhs.append(float(b))
  A=np.vstack((A,*extra));B=np.r_[B,rhs]
  fit=linprog(np.r_[np.zeros(N),1.],A_ub=np.c_[A,-np.ones(len(B))],b_ub=B,bounds=[(None,None)]*(N+1),method='highs',options={'threads':1,'time_limit':8.})
  if not fit.success:return None,None,{'solver_status':int(fit.status)}
  if fit.x[-1]>1e-7:
   weights=[[i,int(round(-v*(1<<40)))]for i,v in enumerate(fit.ineqlin.marginals)if int(round(-v*(1<<40)))>0]
   leaf={'path':path,'context_version':VERSION,'native_row_count':native_count,'extra_row_names':[s[0]for s in specs],
         'native_weights':[[i,w]for i,w in weights if i<native_count],'extra_weights':[[i-native_count,w]for i,w in weights if i>=native_count],
         'power':40,'circle_cuts':cuts,'discovery_phase1':float(fit.x[-1])}
   checked=replay(leaf,certified_positions);leaf['author_replay']=checked
   return leaf,fit.x[:-1],{'phase1':float(fit.x[-1])}
  if not adaptive or iteration==12:break
  candidates=[];power=20;scale=1<<power
  for i in range(9):
   alpha,beta=fit.x[18+i],fit.x[27+i]
   for ss in (-1,1):
    for tt in (-1,1):
     xx=fit.x[2*i]+(ss*alpha-tt*beta)/2;yy=fit.x[2*i+1]+(ss*beta+tt*alpha)/2
     norm=sqrt(xx*xx+yy*yy)
     if norm*norm<=M.Q+1e-8:continue
     cut=(i,ss,tt,int(round(scale*xx/norm)),int(round(scale*yy/norm)),power)
     if cut not in seen:candidates.append((norm*norm-M.Q,cut))
  if not candidates:break
  for _,cut in sorted(candidates,reverse=True)[:4]:seen.add(cut);cuts.append(cut)
 return None,fit.x[:-1],{'phase1':float(fit.x[-1]),'native_rows':native_count,'circle_cuts':len(cuts)}
