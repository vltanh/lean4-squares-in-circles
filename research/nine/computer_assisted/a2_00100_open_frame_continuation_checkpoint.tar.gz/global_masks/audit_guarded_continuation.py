#!/usr/bin/env python3
"""Audit the explicit unfinished hard-parent tree and its new exact contexts.

Native leaves were checked on discovery; --replay-native checks them again.
An unfinished frontier always leaves the original parent OPEN.
"""
import argparse,json,sys,time
from pathlib import Path
from fractions import Fraction as F
import review_guarded_frame_bounds_independent as R
ROOT=Path(__file__).resolve().parent

def union(prefix,leaves):
 tree={}
 for leaf in leaves:
  path=leaf['path'];assert path[:len(prefix)]==prefix;R.V.reconstruct(path)
  node=tree
  for step in path[len(prefix):]:
   assert len(step)==3 and 'leaf'not in node
   query=step[:2]
   if 'query'in node:assert node['query']==query
   else:node['query']=query;node['children']={}
   node=node['children'].setdefault(json.dumps(step[2],separators=(',',':')),{})
  assert not node;node['leaf']=True
 def visit(node):
  if 'leaf'in node:assert node=={'leaf':True};return
  assert set(node)=={'query','children'};kind,key=node['query']
  if kind in ('angle','angle_cut','position','position_cut'):values=(0,1)
  elif kind=='proxy':values=([axis,sign]for axis in (0,1)for sign in (-1,1))
  elif kind=='sat':values=([owner,axis,sign]for owner in key for axis in (0,1)for sign in (-1,1))
  else:
   counts={'lower_escape':2,'row_escape':6,'asymmetric_escape':6,'positive_row_escape':6,'inward_row_escape':10}
   count=counts.get(kind,4 if kind.startswith('cap_')else 8)
   if kind.startswith('column_'):
    assert len(key)==2 and key[0]==0 and 1<=key[1]<=3528
    count=7 if key[1]<=504 else 12
   values=([k]for k in range(count))
  assert set(node['children'])=={json.dumps(v,separators=(',',':'))for v in values}
  for child in node['children'].values():visit(child)
 visit(tree)

def guarded_leaf(leaf):
 assert leaf['context_version']=='unique_penultimate_guarded_rows_v1'and leaf['power']==40
 path=leaf['path'];angles,pos,ch=R.V.reconstruct(path)
 rows,bounds,terminal=R.collect_rows(R.V,path,angles,pos,ch,leaf.get('circle_cuts',()))
 if terminal:return terminal,None
 native=len(rows);assert native==leaf['native_row_count'];extra=R.guard_rows(path);assert extra
 xs=sorted({p[1]for p,k,c in ch if k=='alternate_four_escape'and p in ((1,7),(1,8))and c[0]in (6,7)})
 names=[name for x in xs for name in (f'B{x}_strictly_weak',f'B{x}_cone_inset',f'{x}D_cone_inset',f'C{x}_vertical_inset')]
 assert names==leaf['extra_row_names']and len(extra)==len(names)
 assert all(type(i)is int and 0<=i<native for i,w in leaf['native_weights'])
 assert all(type(i)is int and 0<=i<len(extra)for i,w in leaf['extra_weights'])
 rows.extend(extra);terms=leaf['native_weights']+[[native+i,w]for i,w in leaf['extra_weights']]
 co,rhs=R.weighted_sum(rows,bounds,terms);reserve=-rhs-sum(m*abs(c)for m,c in zip(bounds,co));assert reserve>0
 return None,reserve

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',default=str(ROOT/'hard2c_guarded_continuation_checkpoint.json'));ap.add_argument('--replay-native',action='store_true');args=ap.parse_args()
 started=time.monotonic();file=Path(args.checkpoint);record=json.loads(file.read_text());assert record['status']=='OPEN'
 assert record['schema']=='mixed_native_guarded_frame_checkpoint_v1'and record['frontier']
 parentfile=ROOT.parent/'root_exploration/guarded_bounds'/(record['id']+'.json')
 assert R.sha(parentfile)==record['parent_bound_sha256'];parent,review,table=R.load_parent(parentfile)
 assert parent['path']==record['path']and review['status']=='PASS_CERTIFIED_PARENT_STATE'
 local_subtrees=record.get('local_physical_subtrees',[])
 all_leaves=record['inherited_native_leaves']+record['inherited_guarded_leaves']+record['leaves']+record['node_induction_leaves']
 all_leaves += [leaf for subtree in local_subtrees for leaf in subtree['physical_tree']['leaves']]
 union(record['path'],all_leaves+record['frontier'])
 if args.replay_native:
  for leaf in record['inherited_native_leaves']:R.V.replay_leaf(leaf)
  print('native exact leaves',len(record['inherited_native_leaves']),flush=True)
 for leaf in record['inherited_guarded_leaves']:guarded_leaf(leaf)
 print('independent guarded leaves',len(record['inherited_guarded_leaves']),flush=True)
 for leaf in record['leaves']:R.verify_tree_leaf(parent,leaf)
 for node in record['node_induction_leaves']:
  _,checked,_=R.verify_node_induction(parent,node);assert checked['status']=='PASS_COMPLETE_CHILD'
 for subtree in local_subtrees:
  local,checked,_=R.verify_node_induction(parent,subtree['node_induction_record'])
  assert checked['status']=='PASS_CERTIFIED_CHILD_STATE'
  proof=subtree['physical_tree'];assert proof['status']=='CLOSED_CHILD'and not proof['frontier']
  assert proof['path']==local['path'];union(local['path'],proof['leaves'])
  for leaf in proof['leaves']:R.verify_tree_leaf(local,leaf)
 out={'status':'PASS_CHECKPOINT_STRUCTURE_AND_NEW_EXACT_CONTEXTS','id':record['id'],'original_parent_status':'OPEN',
      'whole_mask_closed':False,'new_whole_parents_closed':0,'native_leaves':len(record['inherited_native_leaves']),
      'native_leaves_replayed_now':len(record['inherited_native_leaves'])if args.replay_native else 0,
      'independent_guarded_leaves':len(record['inherited_guarded_leaves']),'independent_parent_frame_leaves':len(record['leaves']),
      'independent_node_induction_leaves':len(record['node_induction_leaves']),'explicit_pending_paths':len(record['frontier']),
      'independent_local_physical_subtrees':len(local_subtrees),
      'independent_local_physical_leaves':sum(len(s['physical_tree']['leaves'])for s in local_subtrees),
      'checkpoint_sha256':R.sha(file),'seconds':time.monotonic()-started}
 (ROOT/'guarded_continuation_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
