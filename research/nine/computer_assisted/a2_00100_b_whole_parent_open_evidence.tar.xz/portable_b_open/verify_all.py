#!/usr/bin/env python3
"""Standard-library exact OPEN-state replay; never launches discovery."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def box(v):return tuple(tuple(map(F,p))for p in v)
def compare(row,saved):
 co,rhs,name=row
 assert name==saved['name']and rhs==F(saved['rhs'])
 assert co==tuple((k,F(v))for k,v in saved['coefficients'])

def main():
 assert __debug__
 inventory=read(HERE/'SHA256_MANIFEST.json')
 for name,h in inventory['files'].items():
  p=HERE/name;assert p.resolve().is_relative_to(HERE)and p.is_file()and sha(p)==h,('immutable_file_changed',name)
 index=read(HERE/'index.json');assert index['new_original_closures']==index['new_mask_closures']==0
 def audit(event,args):
  if event=='open'and args and isinstance(args[0],(str,bytes)):
   name=args[0].decode()if isinstance(args[0],bytes)else args[0]
   path=Path(name).resolve()
   if str(path).startswith('/workspace/'):
    assert path.is_relative_to(HERE),('unbound_external_workspace_read',str(path))
 sys.addaudithook(audit)
 # Preload this exact local polynomial checker before historical-path helpers.
 import independent_moment_rows as M
 assert Path(M.__file__).resolve().is_relative_to(HERE)
 import verify_joint_original as J
 J.REG=HERE/'original_register.json'
 registry=read(J.REG);assert len(registry['cells'])==231
 states={};prefix_reports=[]
 for name in index['exact_prefixes']:
  report,state=J.replay(HERE/name,allow_open=True,return_state=True)
  assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'and not report['whole_original_parent_closed']
  states[state['id']]=state;prefix_reports.append({k:report[k]for k in['id','status','prior_coordinate_deductions','new_deductions','printed_rows_checked','certificate_sha256']})
 import verify_complete_union_portable as C
 union=C.replay_bound(HERE/index['union_bound_record'])
 assert union['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'and union['complete_union_replay']['cuts']==24
 import independent_owned_axis_union as O
 import independent_fixed_sat_moment_rows as S
 import independent_nine_cardinality_global_review as G
 import independent_moment_rows as M
 tables={r['id']:r for r in read(HERE/'combined_literal_rows.json')};combined=[]
 for name in index['final_combined_records']:
  obj=read(HERE/name);assert obj['status']=='OPEN'and obj['new_branch_nodes']==obj['new_square_cut_rounds']==0
  state=states[obj['id']];assert obj['path']==state['path']
  base,ab,pos,scalar,diff,guards=J.K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
  f=obj['physical_state'];assert box(f['angles'])==state['angles']and box(f['positions'])==pos and box(f['scalar'])==scalar
  assert f['differences']==J.K.diffview(diff)and f['diagonal']==[]
  owned=O.Replay(state['angles'],diff,{},obj['owned_axis_guards'])
  assert obj['all_nine_guards']==G.expected_guards(pos)
  names=set(owned.rows)|set(G.expected_names(pos))|set(obj['original_sat_rows'])
  literal=tables[obj['id']]['rows'];assert {r['name']for r in literal}==names and len(names)==len(literal)
  for row in literal:
   name=row['name']
   if name.startswith('owned_axis_'):actual=owned.rebuild(name)
   elif name.startswith('all_nine_'):actual=G.physical_row(name,pos)
   else:actual=S.rebuild(name,state['path'])
   compare(actual,row)
  moments=M.Rebuilder(pos,scalar,state['angles'],diff,squares=obj['inherited_squares'])
  assert [s['index']for s in obj['inherited_squares']]==list(range(len(obj['inherited_squares'])))
  for s in obj['inherited_squares']:moments.rebuild('moment_psd_square_'+str(s['index']))
  combined.append({'id':obj['id'],'new_necessary_rows_rebuilt':len(literal),'complete_owned_alternatives':owned.alternative_count,'rational_squares_rebuilt':len(obj['inherited_squares']),'status':'PASS_NECESSARY_ROWS_ORIGINAL_REMAINS_OPEN'})
 coverage=[]
 for ident in ['negative-0e4fa3209b6f7b12','negative-6ad5eef3b91c1fbd']:
  folder=HERE/'records/fixed_h_grid_v3'/ident;manifest=read(folder/'manifest.json');summary=read(folder/'summary.json');p=states[ident]['positions']
  xa,xb=p[14];ya,yb=p[15];assert box(manifest['center_box'])==((xa,xb),(ya,yb))
  assert manifest['grid_size']==[8,8]and manifest['adaptive_splits']==0
  unresolved=[]
  for k in range(64):
   t=read(folder/f'tile_{k:02d}.json');ix,iy=divmod(k,8)
   expected=((xa+(xb-xa)*ix/8,xa+(xb-xa)*(ix+1)/8),(ya+(yb-ya)*iy/8,ya+(yb-ya)*(iy+1)/8))
   assert t['tile']==k and t['parent_id']==ident and t['target_original']==7 and box(t['center_box'])==expected
   if t['status']!='CANDIDATE_CLOSED':unresolved.append(k)
  assert unresolved and summary['open']==unresolved and summary['status']=='OPEN_PARENT_NO_CLOSURE'
  coverage.append({'id':ident,'closed_face_cover_tiles':64,'unresolved_tiles':len(unresolved),'terminal_arithmetic_replayed':False,'whole_original_closed':False})
 report={'status':'PASS_PORTABLE_B_OPEN_STOPPING_EVIDENCE','exact_original_prefixes':prefix_reports,'complete_union_cuts':24,'complete_union_physical_alternatives':union['complete_union_replay']['physical_alternatives'],'union_bound_original_status':union['status'],'combined_model_necessary_rows':combined,'fixed_cover_accounting_only':coverage,'new_original_closures':0,'new_mask_closures':0,'accepted_cells':{'closed':197,'open':34},'accepted_masks':{'closed':8,'open':24},'solver_required':False,'lean_lake_ci_run':False}
 dest=HERE/'new_reviews';dest.mkdir(exist_ok=True);(dest/'portable_summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
