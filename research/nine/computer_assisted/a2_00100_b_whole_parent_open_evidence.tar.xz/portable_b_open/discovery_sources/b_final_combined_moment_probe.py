#!/usr/bin/env python3
"""Final static B full-parent test of shared moments and all-nine cardinality.

Retains each complete original domain. No branch or new square-cut round.
Any numerical terminal is only a candidate pending independent full replay.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/cd_family')
import quadratic_moment_pilot as T
import quadratic_owned_axis_union as U
import quadratic_global_nine_cardinality as G
import fixed_sat_moment_rows as S
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(id):
 start=time.monotonic();oldfile=HERE/'moment_results'/(id+'-fixed-sat-ipm.json');old=json.loads(oldfile.read_text())
 assert old['status']=='OPEN'and old['stop_reason']=='bounded_square_budget_exhausted'
 state,dd,dg,prior=T.read_prefix(old['prior']['path']);assert not dg and prior==old['prior']
 allrows,ab,term,pos,sc,diffs,guards=T.P.M.collect(state,dd);assert term is None
 rows0=[r for r in allrows if all(k<54 for k,v in r[0])]
 rows,absolute,meta=T.L.collect(rows0,pos,sc,state['angles'],diffs,None,old['metadata']['rlt_mode'])
 rows+=S.rows(state['path'])
 extra,unionguards=U.generate(state['angles'],diffs);rows+=extra
 nine,nineguards=G.generate(pos);rows+=nine
 for sq in old['squares']:rows.append(T.L.psd_square_row(tuple(map(F,sq['coefficients'])),sq['index']))
 f=dict(angles=T.P.M.render(state['angles']),positions=T.P.M.render(pos),scalar=T.P.M.render(sc),differences=T.P.M.render_diff(diffs),diagonal=[])
 record={'schema':'n9_final_static_B_combined_moment_probe_v1','id':id,'path':state['path'],'scope':'WHOLE_UNCHANGED_ORIGINAL_PARENT','status':'OPEN','new_branch_nodes':0,'new_square_cut_rounds':0,'prior':prior,'prior_moment':{'file':str(oldfile),'sha256':sha(oldfile)},'physical_state':f,'inherited_squares':old['squares'],'original_sat_rows':[r[2]for r in S.rows(state['path'])],'owned_axis_guards':unionguards,'all_nine_guards':nineguards,'metadata':meta,'full_rows':len(rows),'all_nine_rows':len(nine),'owned_axis_rows':len(extra),'sources':{str(Path(p)):sha(p)for p in[__file__,T.__file__,T.L.__file__,U.__file__,G.__file__,S.__file__]},'independent_review_status':'PENDING_ONLY_IF_TERMINAL_CANDIDATE'}
 out=HERE/'combined_moment';out.mkdir(exist_ok=True);dest=out/(id+'.json')
 def save():record['seconds']=time.monotonic()-start;dest.write_text(json.dumps(record,indent=2)+'\n')
 save();print(id,'INITIAL_COMBINED',len(rows),'allnine',len(nine),'owned',len(extra),'squares',len(old['squares']),flush=True)
 h=T.P.M.highs(rows,T.L.SIZE);h.setOptionValue('solver','ipm');h.setOptionValue('time_limit',90.);h.run();status=h.getModelStatus();record['solver_status']=str(status)
 if status==T.P.M.H.HighsModelStatus.kOptimal:
  sol=h.getSolution();record['phase_margin']=float(sol.col_value[-1]);terminal=T.exact_terminal(rows,absolute,sol)
  if terminal and terminal['kind']=='positive_exact_reserve':
   sources={int(x['name'].split('_')[3])for x in terminal['printed_rows']if x['name'].startswith(('moment_rlt_lower_','moment_rlt_upper_'))}
   terminal['rlt_source_rows']=T.P.M.R.printed_rows(rows0,sources);record.update(status='CANDIDATE_CLOSED',terminal=terminal)
  elif terminal:record['rejected_terminal']=terminal
  record['relaxed_original_variables']=list(map(float,sol.col_value[:54]))
 record['stop_reason']='ONE_STATIC_COMBINED_TEST_COMPLETED';save();print(id,'RESULT',record['status'],'phase',record.get('phase_margin'),'seconds',record['seconds'],flush=True)

if __name__=='__main__':
 for id in ['negative-0e4fa3209b6f7b12','negative-6ad5eef3b91c1fbd']:run(id)
