#!/usr/bin/env python3
"""Two bounded whole-original pilots preserving all fixed SAT choices exactly."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,hashlib,argparse
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/cd_family')
import quadratic_moment_pilot as T
import fixed_sat_moment_rows as S
HERE=Path(__file__).resolve().parent;T.HERE=HERE
BASE=T.P.M.highs

def highs(rows,n):
 h=BASE(rows,n);h.setOptionValue('solver','ipm');return h
T.P.M.highs=highs

def collect(state,dd,dg,rlt):
 assert not dg
 rows,ab,term,pos,sc,dt,guards=T.P.M.collect(state,dd)
 if term:raise RuntimeError('Unreviewed physical terminal '+str(term))
 retained=[r for r in rows if all(k<T.L.N for k,c in r[0])]
 lifted,absolute,meta=T.L.collect(retained,pos,sc,state['angles'],dt,None,rlt)
 extra=S.rows(state['path']);lifted+=extra
 meta.update(original_linear_rows=len(rows),removed_auxiliary_linear_rows=len(rows)-len(retained),original_auxiliary_variables=len(ab)-T.L.N,fixed_original_sat_rows=len(extra),solver='ipm',run_crossover='default',wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),sat_module_sha256=hashlib.sha256(Path(S.__file__).read_bytes()).hexdigest())
 physical=dict(angles=T.P.M.render(state['angles']),positions=T.P.M.render(pos),scalar=T.P.M.render(sc),differences=T.P.M.render_diff(dt),diagonal=[],capacity_guards=[],original_sat_rows=[r[2]for r in extra])
 return lifted,absolute,meta,physical
T.collect=collect
ap=argparse.ArgumentParser();ap.add_argument('--id',choices=['negative-0e4fa3209b6f7b12','negative-6ad5eef3b91c1fbd'],required=True);a=ap.parse_args()
p=HERE/'continued'/(a.id+'.json')
r=T.run(p,rounds=8,cuts=20,rlt='core',lp_seconds=90,tag='fixed-sat-ipm')
for source in [__file__,S.__file__]:r['sources'][str(Path(source))]=hashlib.sha256(Path(source).read_bytes()).hexdigest()
(HERE/'moment_results'/(a.id+'-fixed-sat-ipm.json')).write_text(json.dumps(r,indent=2)+'\n')
