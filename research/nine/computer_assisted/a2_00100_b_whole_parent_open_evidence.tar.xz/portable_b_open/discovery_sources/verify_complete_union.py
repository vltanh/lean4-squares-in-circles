#!/usr/bin/env python3
"""Independent exact complete-union replay; imports no discovery producer.

The new geometric rule is proved from the complete four-way disjoint-inset
cover. Every printed base row is independently regenerated. Every reused
cut has a lower index, so the proof is acyclic. Numerical LP output is unused.
"""
import sys,json,time,re,hashlib
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof')
sys.path.insert(0,str(OLD))
import verify_joint_original as J
K=J.K
J.HERE=HERE
J.REG=HERE.parent/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def union_replay(filename):
    started=time.monotonic();path=Path(filename);o=json.loads(path.read_text())
    assert o['schema']=='whole_original_complete_union_cut_v1'
    prior=Path(o['prior']);assert sha(prior)==o['prior_sha256']
    report,state=J.replay(prior,allow_open=True,return_state=True)
    assert state['id']==o['id']and state['path']==o['path']
    base,bounds,pos,scalar,diffs,guards=K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
    accepted=[];printed_count=0;upper_cases=0;excluded_cases=0
    for index,cut in enumerate(o['cuts']):
        i,j=cut['pair'];assert type(i)is int and type(j)is int and 0<=i<j<9
        assert cut['round']==index
        normal=[Q(0)]*len(bounds);seen=set()
        for k,v in cut['normal']:
            assert type(k)is int and 0<=k<len(bounds)and k not in seen;seen.add(k);normal[k]=Q(v);assert normal[k]
        assert len(cut['alternatives'])==4
        keys={(a['axis'],a['sign'])for a in cut['alternatives']}
        assert keys=={(0,-1),(0,1),(1,-1),(1,1)}
        uppers=[]
        for part in cut['alternatives']:
            ax,sg=part['axis'],part['sign']
            indices=[x['index']for x in part['printed_rows']]
            assert len(indices)==len(set(indices))
            rows=list(base)+[((),Q(0),'UNUSED')]*max(0,max(indices,default=-1)+1-len(base))
            for printed in part['printed_rows']:
                k=printed['index'];assert type(k)is int and k>=0
                name=printed['name']
                if k>=len(base):
                    if name.startswith('complete_physical_union_cut_'):
                        m=re.fullmatch(r'complete_physical_union_cut_(\d+)',name);assert m
                        dependency=int(m.group(1));assert 0<=dependency<index
                        row=accepted[dependency]
                    elif name.startswith('complete_inset_alternative_'):
                        assert name==f'complete_inset_alternative_{i}_{j}_{ax}_{sg}'
                        co={2*i+ax:Q(sg),2*j+ax:Q(-sg),45+i:Q(1),45+j:Q(1)}
                        row=tuple(sorted(co.items())),Q(0),name
                    else:
                        row=J.rebuild_joint(name,scalar,diffs,state['angles'],J.point_row)
                    rows[k]=row
                co,rhs,actual_name=rows[k]
                assert name==actual_name and Q(printed['rhs'])==rhs
                assert [(k,Q(v))for k,v in printed['coefficients']if Q(v)]==[(k,v)for k,v in co if v]
            used={k for k,w in part['weights']};assert used==set(indices)
            co,rhs=K.sum_rows(rows,bounds,part['weights'])
            if part['kind']=='impossible':
                reserve=-rhs-sum(m*abs(v)for m,v in zip(bounds,co))
                assert reserve>0 and reserve==Q(part['reserve']);excluded_cases+=1
            else:
                assert part['kind']=='upper'
                residual=sum(m*abs(a-c)for m,a,c in zip(bounds,co,normal))
                exact=rhs+residual;upper=Q(part['upper'])
                assert residual==Q(part['residual_correction'])and exact==Q(part['proved_upper'])and exact<=upper
                uppers.append(upper);upper_cases+=1
            printed_count+=len(indices)
        assert uppers,'All four alternatives impossible would be a terminal, not a stored cut'
        upper=Q(cut['upper']);assert upper==max(uppers)
        accepted.append((tuple((k,v)for k,v in enumerate(normal)if v),upper,f'complete_physical_union_cut_{index}'))
        print(o['id'],'PASS COMPLETE UNION',index,flush=True)
    report={'schema':'independent_complete_union_replay_v1','status':'PASS_COMPLETE_PARENT_VALID_CUTS',
        'id':o['id'],'cuts':len(accepted),'physical_alternatives':4*len(accepted),
        'upper_cases':upper_cases,'excluded_cases':excluded_cases,'printed_rows_checked':printed_count,
        'prefix_report':report,'source_sha256':sha(path),'checker_sha256':sha(__file__),
        'full_original_closed':False,'new_originals_closed':0,'seconds':time.monotonic()-started}
    dest=HERE/'union_reviews';dest.mkdir(exist_ok=True)
    (dest/(o['id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    return accepted,report

def replay_bound(filename):
    path=Path(filename);record=json.loads(path.read_text());source=record['complete_union_input']
    assert sha(source['file'])==source['sha256']
    rows,report=union_replay(source['file']);assert len(rows)==source['cuts']
    assert report['id']==record['id']
    original_rebuild=J.rebuild_joint
    def rebuild(name,scalar,diffs,angles,point_rule):
        if name.startswith('complete_physical_union_cut_'):
            m=re.fullmatch(r'complete_physical_union_cut_(\d+)',name);assert m
            k=int(m.group(1));assert 0<=k<len(rows)
            return rows[k]
        return original_rebuild(name,scalar,diffs,angles,point_rule)
    J.rebuild_joint=rebuild
    try:result=J.replay(path,allow_open=record['status']=='OPEN')
    finally:J.rebuild_joint=original_rebuild
    result['complete_union_replay']=report
    (HERE/'union_reviews'/(record['id']+'_with_bounds.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('independently_rebuilt_new_rules','complete_union_replay')}),flush=True)
    return result

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('certificate');ap.add_argument('--bounds',action='store_true');a=ap.parse_args()
    if a.bounds:replay_bound(a.certificate)
    else:
        _,r=union_replay(a.certificate);print(json.dumps({k:v for k,v in r.items()if k!='prefix_report'}))
