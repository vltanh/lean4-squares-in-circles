#!/usr/bin/env python3
"""Bounded whole-original disjunction discovery; numerical screening only.

Each original is tested using complete four-way physical inset separation.
No descendant is promoted, and no partial tree is constructed.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import sys,json,time,argparse,hashlib
from pathlib import Path
from fractions import Fraction as Q
import numpy as np

OLD=Path('/workspace/scratch/29af4f6e10bf')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(OLD/'current_proof'))
import v3_whole_parent_pass as M
REG=HERE.parent/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'

def load_state(cell):
    source=OLD/'b_macro/v2/results'/(cell['id']+'.json')
    o=json.loads(source.read_text())
    assert o['id']==cell['id'] and o['path']==cell['path'] and o['status']=='OPEN'
    _,_,choices=M.V.reconstruct(o['path'])
    state={'id':o['id'],'path':o['path'],'angles':M.K.box(o['final_angles']),
           'positions':M.K.box(o['final_positions']),'scalar':M.K.box(o['final_scalar']),
           'choices':choices}
    diffs={tuple(d['pair']):M.K.box(d['intervals']) for d in o['final_differences']}
    return state,diffs,source

def branch_row(i,j,axis,sign):
    # Disjoint aligned insets: sign*(c_j-c_i)_axis >= g_i+g_j.
    return tuple(sorted(((2*i+axis,Q(sign)),(2*j+axis,Q(-sign)),
                        (45+i,Q(1)),(45+j,Q(1))))),Q(0),f'complete_inset_alternative_{i}_{j}_{axis}_{sign}'

def phase_record(rows,ab,h):
    h.run()
    if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:
        return {'status':str(h.getModelStatus())}
    sol=h.getSolution();phase=sol.col_value[-1]
    if phase>1e-8:
        ws=M.terms(sol.row_dual);co,rhs=M.R.weighted_sum(rows,ab,ws)
        reserve=-rhs-sum(a*abs(v) for a,v in zip(ab,co))
        if reserve>0:
            return {'status':'EXACT_POSITIVE_CANDIDATE','phase':phase,'weights':ws,
                    'reserve':str(reserve),'weighted_rhs':str(rhs),
                    'weighted_coefficients':list(map(str,co)),
                    'absolute_variable_bounds':list(map(str,ab)),
                    'printed_rows':M.R.printed_rows(rows,{k for k,w in ws})}
    return {'status':'OPEN_RELAXATION','phase':phase,'relaxed_point':list(sol.col_value[:-1])}

def run(cell):
    started=time.monotonic();state,diffs,source=load_state(cell)
    rows,ab,tm,pos,sca,dif,guards=M.collect(state,diffs)
    rec={'schema':'whole_parent_four_way_inset_screen_v1','id':cell['id'],'path':cell['path'],
         'prior':str(source),'prior_sha256':M.sha(source),'parent_induction_replayed':False,
         'status':'OPEN','pairs':[],'row_count':len(rows),'new_originals_accepted':0}
    if tm:rec.update(status='INTERVAL_CANDIDATE',terminal=tm)
    else:
        h=M.highs(rows,len(ab));base=phase_record(rows,ab,h)
        rec['base']=base
        if base['status']=='EXACT_POSITIVE_CANDIDATE':rec['status']='WHOLE_PARENT_CANDIDATE'
        else:
            p=base.get('relaxed_point',[0]*len(ab))
            pairs=[]
            for i in range(9):
                for j in range(i+1,9):
                    gap=max(abs(p[2*j]-p[2*i]),abs(p[2*j+1]-p[2*i+1]))-(p[45+i]+p[45+j])
                    pairs.append((gap,i,j))
            pairs.sort()
            # One mutable last row; every case includes full unmodified parent.
            n=len(ab);rowindex=len(rows)
            h.addRow(-np.inf,0.,1,np.array([n],dtype=np.int32),np.array([-1.]))
            active=[]
            for gap,i,j in pairs:
                test={'pair':[i,j],'alternatives':[]}
                for axis,sign in ((0,-1),(0,1),(1,-1),(1,1)):
                    for k in active:h.changeCoeff(rowindex,k,0.)
                    row=branch_row(i,j,axis,sign);active=[k for k,v in row[0]]
                    for k,v in row[0]:h.changeCoeff(rowindex,k,float(v))
                    h.setOptionValue('time_limit',h.getRunTime()+4.)
                    rr=phase_record(rows+[row],ab,h)
                    rr.update(axis=axis,sign=sign)
                    test['alternatives'].append(rr)
                rec['pairs'].append(test)
                if all(x['status']=='EXACT_POSITIVE_CANDIDATE' for x in test['alternatives']):
                    rec['status']='COMPLETE_FOUR_WAY_PARENT_CANDIDATE';rec['closing_pair']=[i,j]
                    print(cell['id'],'CANDIDATE COMPLETE',i,j,flush=True)
                    break
                if len(rec['pairs'])%9==0:print(cell['id'],'PAIR_SCREEN',len(rec['pairs']),round(time.monotonic()-started,1),flush=True)
    rec['seconds']=time.monotonic()-started
    dest=HERE/'pair_screen';dest.mkdir(exist_ok=True)
    (dest/(cell['id']+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
    print(cell['id'],rec['status'],round(rec['seconds'],1),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--id');ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=19);a=ap.parse_args()
    cells=[c for c in json.loads(REG.read_text())['cells'] if c['status']=='OPEN' and c['sign']=='negative' and c['path'][1][-1]==0]
    if a.id:cells=[c for c in cells if c['id']==a.id]
    else:cells=cells[a.start:a.stop]
    for c in cells:
        if not (HERE/'pair_screen'/(c['id']+'.json')).exists():run(c)
