from pathlib import Path
import sys,json,shutil
OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(OLD))
import verify_joint_original as J
# Preserve the unchanged checker's original source resolver while directing
# only new report files into this work directory.
J.local_source=lambda name:OLD/J.BINDINGS[name] if name in J.BINDINGS else Path(name)
J.HERE=HERE/'prefix_reviews';J.HERE.mkdir(exist_ok=True)
shutil.copy2(OLD/'independent_all_rules.py',J.HERE/'independent_all_rules.py')
reports=[]
for folder,id in [('continued','negative-0e4fa3209b6f7b12'),('continued','negative-6ad5eef3b91c1fbd'),('resumed','negative-2652afcd308ef1ea')]:
 report=J.replay(HERE/folder/(id+'.json'),allow_open=True)
 assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN';reports.append(report)
(J.HERE/'summary.json').write_text(json.dumps({'status':'PASS_THREE_COMPLETE_ORIGINAL_PREFIXES_REMAIN_OPEN','reports':reports},indent=2)+'\n')
