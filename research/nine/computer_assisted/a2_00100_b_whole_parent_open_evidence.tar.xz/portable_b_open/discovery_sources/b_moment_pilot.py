#!/usr/bin/env python3
"""One bounded B265 same-original moment pilot; no new subdivisions."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/cd_family')
import quadratic_moment_pilot as T
HERE=Path(__file__).resolve().parent
T.HERE=HERE
BASE=T.P.M.highs

def highs(rows,n):
 h=BASE(rows,n);h.setOptionValue('solver','ipm');h.setOptionValue('run_crossover','off');return h
T.P.M.highs=highs

def collect(state,dd,dg,rlt):
 assert not dg
 rows,ab,term,pos,sc,dt,guards=T.P.M.collect(state,dd)
 if term:raise RuntimeError('Unreviewed physical terminal '+str(term))
 retained=[r for r in rows if all(k<T.L.N for k,c in r[0])]
 lifted,absolute,meta=T.L.collect(retained,pos,sc,state['angles'],dt,None,rlt)
 meta.update(original_linear_rows=len(rows),removed_auxiliary_linear_rows=len(rows)-len(retained),original_auxiliary_variables=len(ab)-T.L.N,solver='ipm',run_crossover='off',wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 physical=dict(angles=T.P.M.render(state['angles']),positions=T.P.M.render(pos),scalar=T.P.M.render(sc),differences=T.P.M.render_diff(dt),diagonal=[],capacity_guards=[])
 return lifted,absolute,meta,physical
T.collect=collect
p=HERE/'resumed/negative-2652afcd308ef1ea.json'
r=T.run(p,rounds=8,cuts=20,rlt='core',lp_seconds=60,tag='ipm')
r['sources'][str(Path(__file__))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(HERE/'moment_results/negative-2652afcd308ef1ea-ipm.json').write_text(json.dumps(r,indent=2)+'\n')
