#!/usr/bin/env python3
"""Exact complete-inset-union cuts for a whole original parent.

Discovery chooses a separating normal numerically. A cut is retained only
with four exact rational upper-bound certificates, one per physical inset
alternative, or an exact contradiction for that entire alternative.
No recursive region subdivision and no partial-parent closure claims.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,argparse,copy
from pathlib import Path
from fractions import Fraction as Q
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize import linprog
import pair_disjunction_probe as P
M=P.M;HERE=Path(__file__).resolve().parent

def separate_normal(rows,bounds,p,pair,limit=1800):
    n=len(bounds);choices=[P.branch_row(*pair,ax,sg)for ax,sg in((0,-1),(0,1),(1,-1),(1,1))]
    ranking=[]
    for idx,(terms,b,name) in enumerate(rows):
        norm=sum(abs(float(v))for k,v in terms)
        slack=float(b)-sum(float(v)*p[k]for k,v in terms)
        ranking.append((slack/max(norm,1e-12),idx))
    subset=[rows[idx]for _,idx in sorted(ranking)[:limit]]
    # Explicit valid absolute bounds prevent a nonzero recession at lambda=0.
    for k,b in enumerate(bounds):
        subset.extend([(((k,Q(1)),),b,'absolute_upper'),(((k,Q(-1)),),b,'absolute_lower')])
    width=4*(n+1)+2*n;rr=[];cc=[];vv=[];rhs=[]
    r=0
    for case in range(4):
        offset=case*(n+1)
        for co,b,name in subset+[choices[case]]:
            for k,v in co:rr.append(r);cc.append(offset+k);vv.append(float(v))
            rr.append(r);cc.append(offset+n);vv.append(-float(b));rhs.append(0.);r+=1
    aub=csr_matrix((vv,(rr,cc)),shape=(r,width))
    er=[];ec=[];ev=[]
    for k in range(n):
        for case in range(4):er.append(k);ec.append(case*(n+1)+k);ev.append(1.)
        er.extend((k,k));ec.extend((4*(n+1)+k,4*(n+1)+n+k));ev.extend((1.,-1.))
    for case in range(4):er.append(n);ec.append(case*(n+1)+n);ev.append(1.)
    aeq=csr_matrix((ev,(er,ec)),shape=(n+1,width))
    objective=np.r_[np.zeros(4*(n+1)),np.ones(2*n)]
    bs=[]
    for case in range(4):bs.extend([(None,None)]*n+[(0,None)])
    bs.extend([(0,None)]*(2*n))
    result=linprog(objective,A_ub=aub,b_ub=np.array(rhs),A_eq=aeq,b_eq=np.r_[p,1.],bounds=bs,method='highs',options={'time_limit':12.,'presolve':True})
    if result.status!=0 or result.fun<1e-7:return None,{'status':int(result.status),'distance':float(result.fun)if result.fun is not None else None}
    vec=[Q(round(float(v)*(1<<20)),1<<20)for v in result.eqlin.marginals[:n]]
    return vec,{'status':0,'distance':float(result.fun),'restricted_rows':len(subset)}

def union_certificate(rows,bounds,pair,normal):
    n=len(bounds);parts=[]
    for ax,sg in((0,-1),(0,1),(1,-1),(1,1)):
        row=P.branch_row(*pair,ax,sg);r=rows+[row];h=M.highs(r,n);h.run()
        if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:return None
        phase=h.getSolution().col_value[-1]
        if phase>1e-8:
            ws=M.terms(h.getSolution().row_dual);co,b=M.R.weighted_sum(r,bounds,ws)
            reserve=-b-sum(m*abs(v)for m,v in zip(bounds,co))
            if reserve>0:
                parts.append({'axis':ax,'sign':sg,'kind':'impossible','weights':ws,'reserve':str(reserve),
                    'printed_rows':M.R.printed_rows(r,{i for i,w in ws})})
                continue
        h.changeColCost(n,0.);h.changeColBounds(n,0.,0.)
        for k,v in enumerate(normal):
            if v:h.changeColCost(k,-float(v))
        h.setOptionValue('time_limit',h.getRunTime()+8.);h.run()
        if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:return None
        ws=M.terms(h.getSolution().row_dual);co,b=M.R.weighted_sum(r,bounds,ws)
        resid=[v-w for v,w in zip(co,normal)];err=sum(m*abs(v)for m,v in zip(bounds,resid))
        upper=M.ceil_grid(b+err)
        parts.append({'axis':ax,'sign':sg,'kind':'upper','weights':ws,'proved_upper':str(b+err),
            'upper':str(upper),'residual_correction':str(err),
            'printed_rows':M.R.printed_rows(r,{i for i,w in ws})})
    upper=max((Q(x['upper'])for x in parts if x['kind']=='upper'),default=None)
    return {'pair':list(pair),'normal':[[k,str(v)]for k,v in enumerate(normal)if v],
            'alternatives':parts,'upper':str(upper)if upper is not None else None}

def run(cell,maxcuts=24):
    state,diffs,source=P.load_state(cell)
    rows,bounds,terminal,pos,sca,dif,guards=M.collect(state,diffs)
    assert not terminal
    rec={'schema':'whole_original_complete_union_cut_v1','id':cell['id'],'path':cell['path'],
         'prior':str(source),'prior_sha256':M.sha(source),'cuts':[],'status':'OPEN',
         'acceptance':'REQUIRES_INDEPENDENT_FULL_PARENT_AND_UNION_REPLAY','originals_accepted':0}
    outdir=HERE/'union_cuts';outdir.mkdir(exist_ok=True)
    original_rows=len(rows);started=time.monotonic();rejected=set()
    for roundno in range(maxcuts+1):
        h=M.highs(rows,len(bounds));test=P.phase_record(rows,bounds,h)
        if test['status']=='EXACT_POSITIVE_CANDIDATE':
            rec.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal=test);break
        assert test['status']=='OPEN_RELAXATION',test
        if roundno==maxcuts:break
        p=test['relaxed_point']
        candidates=[]
        for i in range(9):
            for j in range(i+1,9):
                deficit=max(abs(p[2*j]-p[2*i]),abs(p[2*j+1]-p[2*i+1]))-p[45+i]-p[45+j]
                if deficit<-1e-6:candidates.append((deficit,i,j))
        added=False
        for deficit,i,j in sorted(candidates):
            normal,info=separate_normal(rows,bounds,p,(i,j))
            if normal is None:continue
            cert=union_certificate(rows,bounds,(i,j),normal)
            if cert is None:continue
            if cert['upper'] is None:
                rec.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal_union=cert);added=True;break
            violation=sum(float(v)*p[k]for k,v in enumerate(normal))-float(Q(cert['upper']))
            if violation<1e-6:continue
            cert.update(discovery=info,round=roundno,violation=violation,base_rows=len(rows))
            co=tuple((k,Q(v))for k,v in cert['normal']);upper=Q(cert['upper'])
            rows.append((co,upper,f'complete_physical_union_cut_{len(rec["cuts"])}'))
            rec['cuts'].append(cert);added=True
            print(cell['id'],'UNION_CUT',roundno,(i,j),round(violation,6),round(time.monotonic()-started,1),flush=True)
            break
        rec['seconds']=time.monotonic()-started
        (outdir/(cell['id']+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
        if rec['status']!='OPEN' or not added:break
    rec['seconds']=time.monotonic()-started;rec['base_rows']=original_rows
    (outdir/(cell['id']+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
    print(cell['id'],'FINAL',rec['status'],len(rec['cuts']),round(rec['seconds'],1),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--maxcuts',type=int,default=24);a=ap.parse_args()
    cell=next(c for c in json.loads(P.REG.read_text())['cells']if c['id']==a.id and c['status']=='OPEN')
    run(cell,a.maxcuts)
