#!/usr/bin/env python3
"""Feed a complete-union certificate into a whole-original bound induction.

Discovery only until the whole prefix, every union cut, and every round
are independently replayed. Each cut is valid over the entire parent.
"""
import json,sys,argparse
from pathlib import Path
from fractions import Fraction as Q
import continue_bound_pass as C
M=C.M
HOME=Path(__file__).resolve().parent

def run(ident,rounds):
    source=HOME/'union_cuts'/(ident+'.json')
    cutfile=json.loads(source.read_text());assert cutfile['id']==ident
    rows=[]
    for k,c in enumerate(cutfile['cuts']):
        assert c['upper'] is not None
        rows.append((tuple((i,Q(x))for i,x in c['normal']),Q(c['upper']),f'complete_physical_union_cut_{k}'))
    oldcollect=C.BASE_COLLECT
    def collect(state,diffs):
        rr,ab,tm,pos,sca,dif,g=oldcollect(state,diffs)
        if not tm:rr+=rows
        return rr,ab,tm,pos,sca,dif,g
    C.BASE_COLLECT=collect
    C.HERE=HOME/'with_union_cuts';C.HERE.mkdir(exist_ok=True)
    cell=next(c for c in json.loads(C.REG.read_text())['cells']if c['id']==ident and c['status']=='OPEN')
    assert cell['path']==cutfile['path']
    C.run(cell,rounds)
    dest=C.HERE/'continued'/(ident+'.json')
    rec=json.loads(dest.read_text())
    rec['additional_sources'][str(source)]=M.sha(source)
    rec['additional_sources'][str(Path(__file__))]=M.sha(__file__)
    rec['complete_union_input']={'file':str(source),'sha256':M.sha(source),'cuts':len(rows),
         'scope':'Every cut applies to the entire original parent, after full exact union replay.'}
    rec['independent_review_status']='PENDING_FULL_PARENT_UNION_AND_INDUCTION_REPLAY'
    dest.write_text(json.dumps(rec,indent=2)+'\n')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--rounds',type=int,default=6);a=ap.parse_args();run(a.id,a.rounds)
