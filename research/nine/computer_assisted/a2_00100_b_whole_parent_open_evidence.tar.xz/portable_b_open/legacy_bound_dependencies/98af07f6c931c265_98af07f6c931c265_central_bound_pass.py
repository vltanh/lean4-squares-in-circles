#!/usr/bin/env python3
"""Whole-parent B induction with unconditional all-nine central-capacity rows.

The complete old Bv2 state/prefix is retained. No split, no selected central
pair, and no unresolved own-axis case is installed as a global premise.
This is discovery; all outputs require full independent exact replay.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import sys,json,argparse,copy
from pathlib import Path
OLD=Path('/workspace/scratch/29af4f6e10bf')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(OLD/'current_proof'))
import v3_whole_parent_pass as M
sys.path.insert(0,str(HERE))
import central_nine_rows as N
BASE_COLLECT=M.collect
REG=HERE.parent/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
IDS=('negative-1a0e5a68ae364a5e','negative-f14f5bc4eafdf50d',
     'negative-7c60be8b07a358e9','negative-4ce055f43b28d796',
     'negative-462e78d2e2d8be05','negative-34029ea8b047982f',
     'negative-16a2fc93c8d133f0','negative-580db3624cf4c2e2')

def run(cell,rounds,source=None,outdir=None):
    source=Path(source)if source else OLD/'b_macro/v2/results'/(cell['id']+'.json')
    prefix=json.loads(source.read_text())
    assert prefix['status']=='OPEN'and prefix['path']==cell['path']and prefix['id']==cell['id']
    before={tuple(d['pair']):M.K.box(d['intervals'])for d in prefix['final_differences']}
    dest=Path(outdir)if outdir else HERE/'central_bounds'
    dest.mkdir(exist_ok=True,parents=True)
    def initial(c):
        assert c['id']==prefix['id']and c['path']==prefix['path']
        _,_,choices=M.V.reconstruct(c['path'])
        return {'id':c['id'],'path':c['path'],'angles':M.K.box(prefix['final_angles']),
                'positions':M.K.box(prefix['final_positions']),'scalar':M.K.box(prefix['final_scalar']),
                'choices':choices},prefix['prior'],None
    def collect(state,diffs):
        merged=dict(before)
        for pair,intervals in diffs.items():
            merged[pair]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(merged[pair],intervals))
        rows,absolute,terminal,pos,scalar,effective,guards=BASE_COLLECT(state,merged)
        if terminal:return rows,absolute,terminal,pos,scalar,effective,guards
        extra,central=N.generate_rows(pos,scalar)
        rows+=extra
        guards.append({'extension_rule':'central_nine_capacity','guards':central})
        return rows,absolute,None,pos,scalar,effective,guards
    def save(record):
        out=copy.deepcopy(record)
        for field in('sources','additional_sources'):
            combined=dict(prefix.get(field,{}))
            for key,val in out.get(field,{}).items():
                assert key not in combined or combined[key]==val
                combined[key]=val
            out[field]=combined
        for p in(Path(__file__),Path(N.__file__),HERE/'GLOBAL_NINE_CENTRAL_CAPACITY_ROWS.md',
                 HERE.parent/'pr11/research/nine/SMALLER_CENTRAL_DISKS_NINE_UNIT_CAPACITY.md'):
            out['additional_sources'][str(p)]=M.sha(p)
        out['continuation_input']={'file':str(source),'sha256':M.sha(source),
            'inherited_rounds':len(prefix['rounds']),'additional_round_limit':rounds}
        out['global_nine_rows']='unconditional_radial_forced_own_escape_forced_near_pair_only'
        out['prior']=prefix['prior']
        for k,rr in enumerate(out['rounds']):
            if k==0:rr['differences_before']=prefix['final_differences']
            rr['round']+=len(prefix['rounds'])
        for field in('final_test','terminal'):
            rr=out.get(field)
            if field=='terminal'and rr:rr=rr.get('state')
            if rr:
                if rr['round']==0:rr['differences_before']=prefix['final_differences']
                rr['round']+=len(prefix['rounds'])
        out['rounds']=copy.deepcopy(prefix['rounds'])+out['rounds']
        if not record['rounds']:out['final_differences']=prefix['final_differences']
        out['independent_review_status']='PENDING_FULL_REPLAY'
        (dest/(cell['id']+'.json')).write_text(json.dumps(out,indent=2)+'\n')
    M.initial=initial;M.collect=collect;M.save=save;M.HERE=HERE;M.VERSION=prefix['schema']
    return M.run(cell,rounds)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--id',required=True);p.add_argument('--rounds',type=int,default=8)
    p.add_argument('--source');p.add_argument('--outdir');a=p.parse_args()
    assert a.id in IDS and 0<=a.rounds<=8
    cell=next(c for c in json.loads(REG.read_text())['cells']if c['id']==a.id and c['status']=='OPEN')
    run(cell,a.rounds,a.source,a.outdir)
