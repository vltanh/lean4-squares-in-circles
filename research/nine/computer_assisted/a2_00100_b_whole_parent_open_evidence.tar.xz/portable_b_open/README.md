# B whole-parent stopping evidence — OPEN

This package adds zero original-cell and zero mask closures. The accepted
PR checkpoint remains197/231 original cells and8/32 masks CLOSED.

Run `python -B -S verify_all.py` from this directory. Standard-library
Python replays the three whole-original prefixes used by the final tests,
the24 complete-union cuts and subsequent f14 bound induction, and the
new exact owned-axis, cardinality and original-SAT algebra. Original
source files and source-bound raw records are preserved without edits;
only a clearly named path-resolution adapter is used for portable replay.

All nine remaining deep-B bounded passes finished OPEN. Two fixed8x8
H-center covers remained incomplete; no recursive refinements followed.
The two final combined moment tests retained all original frames and all
nine restrictions and remained numerically feasible. Those numerical
states may mix incompatible physical poses. They are not packings,
proofs of feasibility, exact optimality results, or new closures.

Raw partial/intermediate records are retained as provenance. Only the
explicit exact-replay inputs listed in index.json have that replay scope.
The two complete B proofs already published in3c1f752 are separate and
are not duplicated in this OPEN package. No Lean, Lake or CI.
