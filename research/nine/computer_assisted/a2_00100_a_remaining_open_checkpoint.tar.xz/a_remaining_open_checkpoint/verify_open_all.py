#!/usr/bin/env python3
"""Portable exact replay of completed remaining-A OPEN work; no closure credit."""
from pathlib import Path as RealPath
from fractions import Fraction as Q
import json,hashlib,copy,sys,os,importlib.util
HERE=RealPath(__file__).resolve().parent
IDS=['positive-2d5aba857f2f7602','positive-768264ad71bc8152','positive-7cdbd39e7dd162bf','positive-8b53ccaa15bad220','positive-c744bc031d40ee64']
def sha(p):return hashlib.sha256(RealPath(p).read_bytes()).hexdigest()
def file(name):
 p=RealPath(name);assert not p.is_absolute()and '..'not in p.parts
 q=HERE/p;assert q.is_file()and q.resolve().is_relative_to(HERE);return q
def read(name):return json.loads(file(name).read_text())
def local_module(name):
 """Load the packaged copy even when an immutable helper prepends old paths."""
 source=file(name+'.py')
 if name in sys.modules:
  module=sys.modules[name]
  assert RealPath(module.__file__).resolve()==source.resolve(),('ambient_module',name,module.__file__)
  return module
 spec=importlib.util.spec_from_file_location(name,source)
 assert spec is not None and spec.loader is not None
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module
 spec.loader.exec_module(module)
 assert RealPath(module.__file__).resolve()==source.resolve()
 return module
def main():
 assert __debug__,'Assertions are required for exact replay.'
 # Reject ambient workspace reads as well as auditing imported module paths.
 # Historical absolute paths remain in raw snapshots as source provenance.
 def audit(event,args):
  if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
   p=RealPath(os.fsdecode(args[0])).resolve()
   assert not p.is_relative_to('/workspace')or p.is_relative_to(HERE),('outside_packet_workspace_read',str(p))
 sys.addaudithook(audit)
 (HERE/'new_reviews').mkdir(exist_ok=True)
 frozen=read('SHA256_MANIFEST.json')
 for name,h in frozen['files'].items():assert sha(file(name))==h,('changed_payload',name)
 bindings=read('source_bindings.json');index=read('open_index.json')
 assert index['status']=='OPEN_NO_ORIGINAL_CLOSURES'and index['new_originals_closed']==0 and index['ids']==IDS
 old=read('original_register.json');current=read('input_current_register.json');om={c['id']:c for c in old['cells']};cm={c['id']:c for c in current['cells']}
 assert len(om)==len(cm)==231 and set(om)==set(cm)
 for ident in om:assert om[ident]['path']==cm[ident]['path']
 assert sum(c['status']=='CLOSED'for c in current['cells'])==197 and sum(c['status']=='OPEN'for c in current['cells'])==34
 assert all(cm[i]['status']==om[i]['status']=='OPEN'for i in IDS)
 for name,rel in bindings.items():assert sha(file(rel))==index['source_hashes'][name]
 # Preload local immutable modules before the unmodified adapters insert their
 # historical module-search paths. The modules themselves remain byte-exact.
 IM=local_module('independent_moment_rows')
 local_module('independent_all_rules')
 J=local_module('verify_joint_original')
 C=local_module('independent_central_rows')
 CB=local_module('verify_central_bounds')
 CC=local_module('verify_central_cover_bounds')
 J.REG=HERE/'original_register.json';J.HERE=HERE;assert J.BINDINGS==bindings
 def boundpath(name):
  p=RealPath(name)
  if str(p)in bindings:return file(bindings[str(p)])
  if p.is_absolute()and not p.resolve().is_relative_to(HERE):
   assert str(p)in bindings,('unbound_absolute_source',str(p))
   return file(bindings[str(p)])
  return p
 CC.Path=boundpath
 def local_source(name):
  p=RealPath(name)
  assert str(p)in bindings or(p.is_absolute()and p.resolve().is_relative_to(HERE)),('unbound_arithmetic_source',str(p))
  return boundpath(p)
 J.local_source=local_source
 cache={};base_replay=CB.replay
 def cached_replay(path,return_state=False):
  p=boundpath(path);key=sha(p)
  if key not in cache:cache[key]=base_replay(p,return_state=True)
  report,state=cache[key]
  return(copy.deepcopy(report),copy.deepcopy(state))if return_state else copy.deepcopy(report)
 CB.replay=cached_replay
 reports=[];prefix_deductions=coordinate=cover_deductions=0
 for entry in index['final_states']:
  p=file(entry['certificate']);record=json.loads(p.read_text());assert record['id']==entry['id']and record['path']==cm[entry['id']]['path']and record['status']=='OPEN'
  if entry['kind']=='canonical_global':
   report,state=CB.replay(p,return_state=True);prefix=report;extra=0
   assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
  else:
   report=CC.replay(p);assert report['status']=='PASS_CERTIFIED_COMPLETE_COVER_PARENT_STATE_OPEN';prefix=report['prior_report'];extra=report['new_deductions']
  assert prefix['prior_coordinate_deductions']==entry['coordinate_prior']and prefix['new_deductions']==entry['canonical_deductions']and extra==entry['complete_cover_deductions']
  assert report['whole_original_parent_closed']is False
  coordinate+=prefix['prior_coordinate_deductions'];prefix_deductions+=prefix['new_deductions'];cover_deductions+=extra;reports.append(report)
 # The zero-deduction A2d5 complete near cover remains explicitly open.
 zero=CC.replay(file(index['zero_bound_central_cover']));assert zero['new_deductions']==0 and zero['whole_original_parent_closed']is False
 a2=read(index['final_states'][0]['certificate']);a2prefix=read(index['a2_canonical_eleven'])
 assert a2['rounds'][:11]==a2prefix['rounds']and len(a2prefix['rounds'])==11
 a768=read(index['final_states'][1]['certificate']);a768first=read(index['a768_central_first_two'])
 assert a768['rounds'][:2]==a768first['rounds']and len(a768['rounds'])==6
 assert a768['continuation']['sha256']==sha(file(index['a768_central_first_two']))
 verify_grid=local_module('verify_open_h_grid').verify
 grid=verify_grid(file(index['final_states'][1]['certificate']),HERE/index['h_grid'],file(index['h_remainder']),J)
 assert grid['status']=='PASS_PARTIAL_FIXED_GRID_AND_CONDITIONAL_REMAINDER_STATE_OPEN'and grid['unresolved_exception_tiles']==[2,10]
 # Every rational negative-square row is independently reconstructed. There
 # is no terminal or accepted physical feasibility claim in these raw pilots.
 Rebuilder,lifted_absolute_bounds=IM.Rebuilder,IM.lifted_absolute_bounds
 moment=read(index['frozen_moment']);p=moment['physical_state'];box=lambda z:tuple(tuple(Q(t)for t in x)for x in z)
 pos=box(p['positions']);scalar=box(p['scalar']);angles=box(p['angles']);diff={tuple(d['pair']):box(d['intervals'])for d in p['differences']}
 assert moment['status']=='OPEN'and 'terminal'not in moment and moment['maximum_rounds']==12 and len(moment['squares'])==140
 rebuilder=Rebuilder(pos,scalar,angles,diff,squares=moment['squares']);assert len(lifted_absolute_bounds(pos,scalar))==1539
 for i,s in enumerate(moment['squares']):
  assert s['index']==i and len(s['coefficients'])==55
  co,rhs,name=rebuilder.rebuild(f'moment_psd_square_{i}')
  assert rhs==Q(s['coefficients'][0])**2 and name==f'moment_psd_square_{i}'
 direct=read(index['direct_psd']);assert direct['status']=='OPEN_NUMERICAL_DISCOVERY'and direct['originals_accepted']==0 and direct['stop_reason']=='declared_iteration_budget'
 assert direct['best_numerical_paid_reserve']<0 and len(direct['iterations'])==51 and direct['iterations'][-1]['iteration']==2500
 assert sha(file(index['direct_psd_arrays']))==direct['complete_numerical_state_sha256']
 assert sha(file(index['frozen_moment']))==direct['frozen_model_sha256']
 inspection=read(index['cd_row_inspection']);assert inspection['status']=='VALID_NECESSARY_ROW_WITH_NO_WHOLE_ORIGINAL_CLOSURE'and inspection['new_originals_closed']==0
 assert len(inspection['all_eight_projection_intervals'])==8
 survivors=[a for a in inspection['all_eight_projection_intervals']if not a['excluded_by_unit_projection_upper']]
 assert len(survivors)==1 and(survivors[0]['owner'],survivors[0]['axis'],survivors[0]['sign'])==(3,0,1)
 # Independently derive all eight projection intervals from the proved state.
 def mul(a,b):v=[x*y for x in a for y in b];return min(v),max(v)
 def plus(a,b):return a[0]+b[0],a[1]+b[1]
 def neg(a):return -a[1],-a[0]
 for a in inspection['all_eight_projection_intervals']:
  owner,axis,sign=a['owner'],a['axis'],a['sign'];dx,dy=diff[2,3];alpha,beta=scalar[owner],scalar[9+owner]
  value=plus(mul(alpha,dx),mul(beta,dy))if axis==0 else plus(mul(alpha,dy),neg(mul(beta,dx)))
  if sign<0:value=neg(value)
  assert value==tuple(map(Q,a['projection_interval']))and a['excluded_by_unit_projection_upper']==(value[1]<1)
 # Rebuild the unscaled forced SAT row using the separate polynomial checker.
 FS=local_module('independent_fixed_sat_moment_rows')
 assert FS.P is IM
 temporary_path=[['sat',[2,3],[3,0,1]]]
 co,rhs,_=FS.rebuild('moment_original_sat_0_2_3_3_0_1_1',temporary_path)
 assert [[k,str(v)]for k,v in co]==inspection['unscaled_row']['coefficients']and str(rhs)==inspection['unscaled_row']['rhs']
 assert coordinate==155 and prefix_deductions==3552 and cover_deductions==123
 module_paths={}
 for name,module in sorted(sys.modules.items()):
  origin=getattr(module,'__file__',None)
  if not origin:continue
  origin=RealPath(origin).resolve()
  if origin.is_relative_to('/workspace'):
   assert origin.is_relative_to(HERE),('outside_packet_workspace_module',name,str(origin))
   module_paths[name]=str(origin.relative_to(HERE))
 summary={'status':'PASS_PRESERVED_OPEN_WORK_NO_NEW_ORIGINAL_CLOSURE','new_originals_closed':0,'ids':IDS,'register_before':{'closed':197,'open':34},'register_after':{'closed':197,'open':34},'whole_masks':{'closed':8,'open':24},
  'coordinate_prior_deductions':coordinate,'canonical_parent_deductions':prefix_deductions,'complete_cover_parent_deductions':cover_deductions,
  'conditional_grid_remainder_deductions':grid['remainder_deductions'],'checked_static_grid_terminals':grid['static_closed_tiles_checked'],'unresolved_grid_tiles':25,'unresolved_grid_exception_tiles':[2,10],
  'independent_rational_square_rows':140,'direct_psd_proof_status':'NUMERICAL_ONLY_NO_POSITIVE_RESERVE','whole_original_closure_claimed':False,'whole_mask_closed':False,'lean_lake_ci_run':False,'all_source_snapshots_portable':True,'outside_packet_workspace_reads':0,'local_module_import_audit':module_paths}
 out=HERE/'new_reviews';out.mkdir(exist_ok=True);(out/'open_grid_report.json').write_text(json.dumps(grid,indent=2)+'\n');(out/'portable_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
