# Remaining five A originals: bounded work and exact stopping evidence

November 3, 2026. This packet preserves completed work after the four accepted
original closures published at `3c1f752`. It closes **zero additional original
cells**. The fixed original register remains **197 CLOSED / 34 OPEN**; the A
family has **five OPEN originals**. The 32-mask ledger remains 8 CLOSED / 24 OPEN.
No A8 or B2 closure archive is duplicated here.

Every proved bound below concerns the unchanged original path, all nine physical
squares, all 36 original pairs and 36 corners, the marked comparisons and actual
bits, and the original strict CD bit. Closed-Q necessary inequalities enlarge
the original `q < 1105/256` caller. An OPEN relaxation is never called a physical
packing, and a numerical solver limit is never called feasibility.

## Complete original-bound states

The fresh portable replay reconstructs the original paths and coordinate priors,
then checks every printed physical row, every rational weighted bound, every
unit-frame inference, and every complete near-original cover.

| Unchanged original | Coordinate prior deductions | Canonical whole-parent deductions | Further complete-cover deductions | Final status |
| --- | ---: | ---: | ---: | --- |
| `positive-2d5aba857f2f7602` | 33 | 1,280 in 17 rounds | 0 | OPEN |
| `positive-768264ad71bc8152` | 31 | 609 in 11 rounds | 73 in 6 rounds | OPEN |
| `positive-7cdbd39e7dd162bf` | 30 | 528 in 11 rounds | 16 in 2 rounds | OPEN |
| `positive-8b53ccaa15bad220` | 30 | 587 in 11 rounds | 16 in 2 rounds | OPEN |
| `positive-c744bc031d40ee64` | 31 | 548 in 11 rounds | 18 in 2 rounds | OPEN |

Thus the five final states contain 155 replayed coordinate deductions, 3,552
canonical deductions and 123 additional complete-cover deductions. These are
proved necessary bounds, not exclusions of the five original cells.

For A2d5, the final six canonical rounds use the reviewed all-nine central-disk
capacity theorem. They prove

\[
y_F\ge\frac{275915}{1048576}>0.26313,
\]

where the preceding lower bound was negative. The E slope interval contracts
from approximately `[-0.21523,0.14069]` to `[-0.20278,0.11867]`. Only B, F, H and I
remain eligible to meet the open disk of radius 23/100, so all six unordered
near pairs are retained. Their complete convex-hull probe produced no cut; the
complete coordinate/difference support-max pass produced no new bound.

For A768, F is proved near that disk. The exact cover retains F paired with each
of B, C, H and I. Every installed support bound is the maximum of independently
certified bounds over all four alternatives. In particular,

\[
y_I-y_F\le\frac{1466515}{1048576}<1.39858,
\]

an improvement of more than 0.303 over the preceding relational bound. All five
A originals remain OPEN after their declared passes. No incomplete alternative is discarded.

## The one fixed H-center cover attempted on A768

After all six complete-cover rounds, one fixed 8 by 8 cover of the entire
proved H-center rectangle was tested. Each tile is a closed Cartesian product
of consecutive exact eighths. All 64 tiles and every shared face are recorded.
The static pass supplied 39 terminal records and left 25 unresolved records.

Two unresolved records, tiles 2 and 10, contain an unhandled empty-difference
intersection assertion. They are preserved as unresolved exceptions; neither
feasibility nor an accepted terminal is inferred from the exception. The other
23 unresolved records are numerical LP outputs without an exclusion proof.

The single predeclared complete Cartesian remainder contains all 25 unresolved
tiles, including the two exceptions. It consists of 48 grid tiles and is

\[
X_H=\left[-\frac{479183}{524288},\frac{17}{64}\right],\qquad
Y_H=\left[\frac{30908899}{62914560},\frac{91}{60}\right].
\]

All six allotted whole-rectangle rounds completed, proving 145 conditional
bounds. The remainder remains OPEN. Its final state applies only under this
explicit H-center predicate. It is not substituted for the unchanged original
parent state. The exact replay checks all 39 recorded static terminals, the
complete tile map and all 145 conditional bounds. No new grid, recursive
subdivision or further optimization pass follows this result.

## Same-original quadratic moment pilot

The A2d5 pilot uses the independently replayed 17-round parent. It retains all
54 original variables and adds their 1,485 shared pair products. Its 77,908
initial necessary rows include actual corner-circle and point/incircle
quadratics, the exact original unit and absolute-frame identities, the reciprocal
inset identity, pair capacities, bound-product inequalities and 49,140 products
of certified affine slacks with original interval slacks.

A physical configuration embeds with each formal product equal to the product
of those same original variables. A feasible lifted vector is not asserted to
be a physical configuration. The numerical LP and eigenvectors only propose
rational inequalities of the form

\[
-\left(q_0+\sum_{i=1}^{54}q_i w_i\right)^2\le0.
\]

The bounded simplex pass completed six solves and installed 140 such rational
squares, then reached its 40-second LP limit. A solver-only IPM continuation on
the same frozen 140-cut model reached its 60-second limit without a new
completed round. Both raw records are retained. No positive exact terminal was
obtained.

The independent polynomial reconstructor imports no producer or solver. It
matched all 57,267 newly generated initial moment rows and all 140 rational
square rows on the actual A2 state, for 57,407 exact reconstructions. The separate
fixed-SAT moment reconstructor and all-nine cardinality reconstructor are also
preserved for review. No unexecuted terminal checker is represented as an
accepted original proof.

## One bounded direct PSD diagnostic

One direct semidefinite discovery run used exactly the same frozen model. Its
predeclared budget was 2,500 ADMM iterations or 180 wall seconds, with at most
one 60-second LP certificate attempt conditional on a positive paid numerical
dual. It stopped at 2,500 iterations in about 28 seconds. No final certificate
attempt was triggered because no paid dual became positive.

The final numerical phase was approximately `-6.1e-6`, the minimum normalized
moment eigenvalue approximately `-9e-7`, and the primal residual about `0.00171`.
The best numerical dual reserve after paying its full coefficient residual was
negative, about `-0.000893`. These diagnostics suggest a nearly feasible PSD
relaxation. They prove neither exact feasibility nor a physical packing.

Complete numerical primal and dual arrays, original row normalizers, exact
normalization intervals, frozen source bindings and per-iteration residuals are
retained. H and I have center variance traces approximately 0.673 and 0.659 in
this relaxed state. The large variances show explicitly why its mean centers
cannot be treated as a proposed packing.

## Inspection of the C-D owned-axis row

The reviewed coordinate and frame intervals exclude seven of the eight signed
owned-axis separation alternatives for C and D. A separate rational interval
calculation confirms that positive `u_D` is the only surviving physical normal.
Consequently the entire original parent necessarily satisfies

\[
2(c_D-c_C)\cdot u_D
-\cos(\theta_D-\theta_C)-\sin(\theta_D-\theta_C)\ge1.
\]

This inequality is necessary; it is not a contradiction. The optimized interval
used by the discovery generator spans approximately `[0.9869103,1.0144499]`.
The generated union row multiplies this inequality by approximately 76.396.
Its reported numerical violation `0.0007538` is therefore an unscaled deficit
of only about `9.87e-6`, comparable to the direct run's residuals. The other 521
owned-axis rows and all 23 new radial/cardinality rows are satisfied by the saved
numerical moment state to the recorded tolerance. There is no material paid
contradiction warranting another combined-model optimization run.

## Replay and scope

Run `python -B -S a_remaining_open_checkpoint/verify_open_all.py` after extraction.
The script requires only Python's standard library. It checks every immutable
payload hash and source binding, replays the five final original-bound states,
checks complete-cover provenance and the fixed-grid stopping evidence, and
reconstructs every stored rational square identity. Numerical arrays and logs
are preserved and hashed as discovery evidence; their floating point contents
have no proof authority.

The portable launcher explicitly loads the packaged independent polynomial
reconstructor before any historical helper. It checks every imported workspace
module's location and rejects all workspace file reads outside the extracted
packet. The historical sources themselves remain byte-exact. Generated review
reports are excluded from the immutable manifest so repeated replay leaves all
frozen payload hashes unchanged.

The packet also retains the completed zero-cut union probes, the bounded
four-original own-axis screen and a static retest of the previously named
21 historical pending A2 paths. These are diagnostic records only. The old
partial forest is not promoted, enlarged or counted as an original closure.

No Lean, Lake or CI was run. No additional original cell, whole mask, positional
root, roadmap gate or equality-classification result is closed by this packet.
