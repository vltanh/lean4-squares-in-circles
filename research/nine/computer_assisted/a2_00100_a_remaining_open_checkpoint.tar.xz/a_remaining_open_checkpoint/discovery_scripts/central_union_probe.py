#!/usr/bin/env python3
"""Bounded exact discovery for complete global central disjunctions.
All retained alternatives are included. No split predicate is persisted.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import sys,json,time,argparse
from fractions import Fraction as Q
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import continue_global_capacity as M
C=M.GC

def load(ident):
 source=HERE/'global_capacity/continued'/(ident+'.json')
 if not source.exists():source=HERE/'continued'/(ident+'.json')
 r=json.loads(source.read_text());assert r['status']=='OPEN';_,_,ch=M.V.reconstruct(r['path'])
 st={'id':r['id'],'path':r['path'],'angles':M.K.box(r['final_angles']),'positions':M.K.box(r['final_positions']),'scalar':M.K.box(r['final_scalar']),'choices':ch}
 ds={tuple(x['pair']):M.K.box(x['intervals'])for x in r['final_differences']}
 return st,ds,source

def phase(rows,bounds):
 h=M.highs(rows,len(bounds));h.run();assert h.getModelStatus()==M.H.HighsModelStatus.kOptimal
 sol=h.getSolution();v=sol.col_value[-1]
 if v>1e-8:
  ws=M.terms(sol.row_dual);co,b=M.R.weighted_sum(rows,bounds,ws);margin=-b-sum(m*abs(a)for m,a in zip(bounds,co))
  if margin>0:return h,{'kind':'impossible','weights':ws,'reserve':str(margin),'printed_rows':M.R.printed_rows(rows,{i for i,w in ws})}
 return h,{'kind':'open','phase':float(v),'point':list(sol.col_value[:-1])}

def normal(rows,bounds,p,cases,limit=1800):
 n=len(bounds);c=len(cases);rank=[]
 for idx,(co,b,name)in enumerate(rows):
  norm=sum(abs(float(v))for k,v in co);slack=float(b)-sum(float(v)*p[k]for k,v in co)
  rank.append((slack/max(norm,1e-12),idx))
 subset=[rows[k]for _,k in sorted(rank)[:limit]]
 for k,b in enumerate(bounds):subset.extend([(((k,Q(1)),),b,'absolute_upper'),(((k,Q(-1)),),b,'absolute_lower')])
 width=c*(n+1)+2*n;rr=[];cc=[];vv=[];rhs=[];r=0
 for case in range(c):
  offset=case*(n+1)
  for co,b,name in subset+cases[case]['rows']:
   for k,v in co:rr.append(r);cc.append(offset+k);vv.append(float(v))
   rr.append(r);cc.append(offset+n);vv.append(-float(b));rhs.append(0.);r+=1
 aub=csr_matrix((vv,(rr,cc)),shape=(r,width));er=[];ec=[];ev=[]
 for k in range(n):
  for case in range(c):er.append(k);ec.append(case*(n+1)+k);ev.append(1.)
  er.extend((k,k));ec.extend((c*(n+1)+k,c*(n+1)+n+k));ev.extend((1.,-1.))
 for case in range(c):er.append(n);ec.append(case*(n+1)+n);ev.append(1.)
 aeq=csr_matrix((ev,(er,ec)),shape=(n+1,width));bs=[]
 for case in range(c):bs.extend([(None,None)]*n+[(0,None)])
 bs.extend([(0,None)]*(2*n))
 res=linprog(np.r_[np.zeros(c*(n+1)),np.ones(2*n)],A_ub=aub,b_ub=rhs,A_eq=aeq,b_eq=np.r_[p,1.],bounds=bs,method='highs',options={'time_limit':15.,'presolve':True})
 if res.status!=0 or res.fun<1e-7:return None,{'status':int(res.status),'distance':float(res.fun)if res.fun is not None else None}
 return [Q(round(float(x)*(1<<20)),1<<20)for x in res.eqlin.marginals[:n]],{'status':0,'distance':float(res.fun),'restricted_rows':len(subset)}

def certify(rows,bounds,cases,vec):
 parts=[];n=len(bounds)
 for case in cases:
  rr=rows+case['rows'];h,record=phase(rr,bounds);entry={k:v for k,v in case.items()if k!='rows'}
  if record['kind']=='impossible':entry.update(record);parts.append(entry);continue
  h.changeColCost(n,0.);h.changeColBounds(n,0.,0.)
  for k,v in enumerate(vec):
   if v:h.changeColCost(k,-float(v))
  h.setOptionValue('time_limit',h.getRunTime()+8.);h.run()
  if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:return None
  ws=M.terms(h.getSolution().row_dual);co,b=M.R.weighted_sum(rr,bounds,ws);res=[v-w for v,w in zip(co,vec)];err=sum(m*abs(v)for m,v in zip(bounds,res));upper=M.ceil_grid(b+err)
  entry.update(kind='upper',weights=ws,proved_upper=str(b+err),upper=str(upper),residual_correction=str(err),printed_rows=M.R.printed_rows(rr,{i for i,w in ws}));parts.append(entry)
 upper=max((Q(x['upper'])for x in parts if x['kind']=='upper'),default=None)
 return {'normal':[[k,str(v)]for k,v in enumerate(vec)if v],'alternatives':parts,'upper':str(upper)if upper is not None else None}

def run(ident,maxcuts=12):
 st,ds,source=load(ident);rows,bounds,terminal,pos,sca,diff,guards=M.collect(st,ds);assert not terminal
 cases,excluded=C.central_pair_cases(pos,sca)
 disjunctions=[{'kind':'two_central_originals','cases':cases,'excluded':excluded}]
 for i in range(9):
  own,exc=C.own_escape_cases(i,pos,sca)
  if len(own)>1:disjunctions.append({'kind':'own_axis_escape','original':i,'cases':own,'excluded':exc})
 rec={'schema':'whole_original_complete_central_union_discovery_v1','id':ident,'path':st['path'],'prior':str(source),'prior_sha256':M.sha(source),'cuts':[],'status':'OPEN','acceptance':'REQUIRES_INDEPENDENT_FULL_PARENT_AND_UNION_REPLAY','new_internal_splits':0,'base_rows':len(rows),'central_candidates':[x['pair']for x in cases]}
 out=HERE/'central_union';out.mkdir(exist_ok=True);start=time.monotonic()
 # Exact phase records diagnose all six central cases before hull discovery.
 rec['initial_central_cases']=[]
 for c in cases:
  h,p=phase(rows+c['rows'],bounds);p.update(pair=c['pair']);rec['initial_central_cases'].append(p)
  print(ident,'CENTRAL_PAIR',c['pair'],p['kind'],p.get('phase',p.get('reserve')),flush=True)
 for ri in range(maxcuts+1):
  h,test=phase(rows,bounds)
  if test['kind']=='impossible':rec.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal=test);break
  if ri==maxcuts:break
  p=test['point'];added=False
  for dis in disjunctions:
   vec,info=normal(rows,bounds,p,dis['cases'])
   if vec is None:continue
   proof=certify(rows,bounds,dis['cases'],vec)
   if proof is None:continue
   proof.update(disjunction={k:v for k,v in dis.items()if k!='cases'},discovery=info,round=ri,base_rows=len(rows))
   if proof['upper']is None:rec.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal_union=proof);added=True;break
   viol=sum(float(v)*p[k]for k,v in enumerate(vec))-float(Q(proof['upper']))
   if viol<1e-6:continue
   proof['violation']=viol;rows.append((tuple((k,Q(v))for k,v in proof['normal']),Q(proof['upper']),f'central_complete_union_cut_{len(rec["cuts"])}'));rec['cuts'].append(proof);added=True
   print(ident,'CENTRAL_UNION_CUT',ri,dis['kind'],dis.get('original'),round(viol,7),round(time.monotonic()-start,1),flush=True);break
  rec['seconds']=time.monotonic()-start;(out/(ident+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
  if rec['status']!='OPEN'or not added:break
 rec['seconds']=time.monotonic()-start;(out/(ident+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
 print(ident,'FINAL',rec['status'],len(rec['cuts']),round(rec['seconds'],2),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--cuts',type=int,default=12);a=ap.parse_args();run(a.id,a.cuts)
