from pathlib import Path
import central_cover_A as A
HERE=Path(__file__).resolve().parent
ids=['positive-7cdbd39e7dd162bf','positive-8b53ccaa15bad220','positive-c744bc031d40ee64']
for ident in ids:A.B.run(HERE/'continued'/(ident+'.json'),2)
