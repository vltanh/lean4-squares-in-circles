from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
import independent_moment_rows as P
HERE=Path(__file__).resolve().parent
f=HERE/'moment_results/positive-2d5aba857f2f7602-global17-ipm-resume.json';r=json.loads(f.read_text());p=r['physical_state']
box=lambda z:tuple(tuple(Q(t)for t in a)for a in z)
scalar=box(p['scalar']);diff={tuple(x['pair']):box(x['intervals'])for x in p['differences']};dx,dy=diff[2,3]
def prod(a,b):
 v=[x*y for x in a for y in b];return min(v),max(v)
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
cover=[]
for owner in(2,3):
 alpha,beta=scalar[owner],scalar[9+owner]
 projections=[add(prod(alpha,dx),prod(beta,dy)),add(prod(alpha,dy),neg(prod(beta,dx)))]
 for axis,interval in enumerate(projections):
  for sign in(-1,1):
   lo,hi=interval if sign==1 else neg(interval)
   cover.append({'owner':owner,'axis':axis,'sign':sign,'projection_interval':[str(lo),str(hi)],'excluded_by_unit_projection_upper':hi<1})
alive=[x for x in cover if not x['excluded_by_unit_projection_upper']]
assert len(alive)==1 and(alive[0]['owner'],alive[0]['axis'],alive[0]['sign'])==(3,0,1)
a,b,c,d=map(P.variable,(20,29,21,30));DX=P.minus(P.variable(6),P.variable(4));DY=P.minus(P.variable(7),P.variable(5))
cos=P.combine(P.product(a,c),P.product(b,d));sin=P.minus(P.product(a,d),P.product(b,c));projection=P.combine(P.product(DX,c),P.product(DY,d))
row=P.inequality(P.combine(P.number(1),cos,sin,P.times_constant(projection,-2)),'forced_CD_positive_D_u_actual_separator')
numeric=json.loads((HERE/'direct_moment_admm/physical_numerical_moments.json').read_text())['physical_variables_and_moments'];gap=sum(float(v)*numeric[k]for k,v in row[0])-float(row[1])
record={'status':'VALID_NECESSARY_ROW_WITH_NO_WHOLE_ORIGINAL_CLOSURE','id':r['id'],'prior_parent':r['prior'],'physical_state_source':str(f),'physical_state_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'all_eight_projection_intervals':cover,'unique_survivor':alive[0],'unscaled_row':{'name':row[2],'coefficients':[[k,str(v)]for k,v in row[0]],'rhs':str(row[1])},'numerical_unscaled_violation':gap,'numerical_point_is_a_relaxation_only':True,'exact_negative_reserve_obtained':False,'additional_optimization_run':False,'new_originals_closed':0}
(HERE/'direct_moment_admm/cd_row_inspection.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'survivor':alive[0],'unscaled_violation':gap,'new_originals_closed':0},indent=2))
