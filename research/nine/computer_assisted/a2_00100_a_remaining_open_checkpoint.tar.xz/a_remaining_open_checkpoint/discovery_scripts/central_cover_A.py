#!/usr/bin/env python3
from pathlib import Path
import sys,argparse
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'global_masks'))
import central_cover_bound_pass as B
B.HERE=HERE
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('--rounds',type=int,default=2);a=ap.parse_args();assert 0<=a.rounds<=4
 B.run(a.source,a.rounds)
