#!/usr/bin/env python3
"""Complete four-way inset union pilot for the five remaining A parents."""
from pathlib import Path
import sys,json,argparse
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'b_family'))
import complete_union_cuts as U
P=U.P;M=U.M

def load_state(cell):
 source=HERE/'continued'/(cell['id']+'.json');o=json.loads(source.read_text())
 assert o['id']==cell['id']and o['path']==cell['path']and o['status']=='OPEN'
 _,_,ch=M.V.reconstruct(o['path'])
 st={'id':o['id'],'path':o['path'],'angles':M.K.box(o['final_angles']),'positions':M.K.box(o['final_positions']),'scalar':M.K.box(o['final_scalar']),'choices':ch}
 ds={tuple(d['pair']):M.K.box(d['intervals'])for d in o['final_differences']}
 return st,ds,source
P.load_state=load_state;U.HERE=HERE
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('id');a.add_argument('--cuts',type=int,default=16);args=a.parse_args()
 c=next(x for x in json.loads(P.REG.read_text())['cells']if x['id']==args.id and x['status']=='OPEN')
 U.run(c,args.cuts)
