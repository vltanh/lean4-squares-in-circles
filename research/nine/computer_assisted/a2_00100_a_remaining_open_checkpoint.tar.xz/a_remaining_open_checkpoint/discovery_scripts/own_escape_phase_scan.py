from pathlib import Path
import json
from fractions import Fraction as Q
import central_union_probe as U
HERE=Path(__file__).resolve().parent
ids=['positive-768264ad71bc8152','positive-7cdbd39e7dd162bf','positive-8b53ccaa15bad220','positive-c744bc031d40ee64']
result=[]
for ident in ids:
 st,d,source=U.load(ident);rows,bounds,term,pos,sca,diff,guards=U.M.collect(st,d);assert not term
 for i in (4,5,7,8):
  cases,exc=U.C.own_escape_cases(i,pos,sca)
  for case in cases:
   _,rec=U.phase(rows+case['rows'],bounds)
   r={'id':ident,'original':i,'axis':case['axis'],'sign':case['sign'],'prior':str(source),'prior_sha256':U.M.sha(source),'kind':rec['kind'],'case':rec}
   result.append(r);print(ident,i,case['axis'],case['sign'],rec['kind'],rec.get('reserve',rec.get('phase')),flush=True)
 (HERE/'own_escape_phase_scan.json').write_text(json.dumps(result,indent=2)+'\n')
