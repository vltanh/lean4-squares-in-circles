#!/usr/bin/env python3
"""One static pass on the unchanged 21 pending A paths, no new branches."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
from fractions import Fraction as Q
import sys,json,time
HERE=Path(__file__).resolve().parent;OLD=Path('/workspace/scratch/29af4f6e10bf/current_proof');B=OLD/'pair_support_open_checkpoint'
sys.path.insert(0,str(OLD));import v3_whole_parent_pass as M
sys.path.insert(0,str(B/'sharp_frame'));import octagon_unit_frame_producer as D
O=D.O
ident='positive-2d5aba857f2f7602';source=HERE/'continued'/(ident+'.json');r=json.loads(source.read_text());parentpath=r['path'];p=M.K.box(r['final_positions']);a=M.K.box(r['final_angles']);s=M.K.box(r['final_scalar']);diffs={tuple(d['pair']):M.K.box(d['intervals'])for d in r['final_differences']}
old=B/'global_masks/clipped_disk_review/A_819_21_overlay.json';pending=json.loads(old.read_text())['pending'];results=[]
out=HERE/'old_pending_static';out.mkdir(exist_ok=True)
for item in pending:
 started=time.monotonic();legacy,angles,pos,ch,extra=O.decode(item['path'],parentpath,p)
 angles=tuple((max(l,la),min(u,ua))for(l,u),(la,ua)in zip(angles,a));frame=M.K.analytic(angles);scalar=tuple((max(l,la),min(u,ua))for(l,u),(la,ua)in zip(s,frame))
 st={'id':ident,'path':legacy,'angles':angles,'positions':pos,'scalar':scalar,'choices':ch}
 rec={'id':ident,'full_path':item['path'],'legacy_path':legacy,'source_index':item['source_index'],'status':'OPEN','scope':'NAMED_EXISTING_DESCENDANT_ONLY','parent_source':str(source),'parent_sha256':M.sha(source),'new_branch_nodes':0}
 try:
  rows,ab,tm,pp,ss,dd,g=M.collect(st,diffs);rows += [O.disk_row(marker,choice)for marker,choice in extra]
  rec.update(row_count=len(rows),parent_state={'angles':M.render(angles),'positions':M.render(pos),'scalar':M.render(scalar)},effective_differences=M.render_diff(dd))
  if tm:rec.update(status='CANDIDATE_CLOSED',terminal={'kind':'exact_interval','label':tm})
  else:
   h=M.highs(rows,len(ab));h.run()
   if h.getModelStatus()==M.H.HighsModelStatus.kOptimal:
    sl=h.getSolution();rec['phase_margin']=sl.col_value[-1]
    if sl.col_value[-1]>1e-8:
     ws=M.terms(sl.row_dual);co,b=M.R.weighted_sum(rows,ab,ws);reserve=-b-sum(x*abs(c)for x,c in zip(ab,co))
     if reserve>0:rec.update(status='CANDIDATE_CLOSED',terminal={'kind':'positive_exact_reserve','weights':ws,'reserve':str(reserve),'rows':M.R.printed_rows(rows,{i for i,w in ws}),'absolute_variable_bounds':list(map(str,ab))})
 except Exception as e:
  import traceback;rec.update(error=traceback.format_exc())
 rec['seconds']=time.monotonic()-started;(out/('child_%03d.json'%item['source_index'])).write_text(json.dumps(rec,indent=2)+'\n');results.append({k:rec.get(k)for k in ['source_index','status','phase_margin','seconds','error']});print(results[-1],flush=True)
 summary={'status':'COMPLETE_CANDIDATE'if all(x['status']=='CANDIDATE_CLOSED'for x in results)and len(results)==21else'OPEN_PARENT','results':results,'originals_accepted':0,'new_branch_nodes':0};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
