from pathlib import Path
import json,time
import quadratic_moment_A as D
import independent_moment_rows as I
source=Path('a_family/global_capacity/continued/positive-2d5aba857f2f7602.json')
st,dd,dg,prior=D.read_prefix(source);base,ab,t,pos,sc,diffs,guards=D.G.collect(st,dd);assert t is None
rows,absolute,meta=D.L.collect(base,pos,sc,st['angles'],diffs,{},'core')
assert tuple(absolute)==I.lifted_absolute_bounds(pos,sc)
r=I.Rebuilder(pos,sc,st['angles'],diffs,linear_source=lambda k:base[k],linear_count=len(base))
began=time.monotonic();count=0
for row in rows[len(base):]:
 actual=r.rebuild(row[2]);assert actual==row,('MISMATCH',row,actual);count+=1
result=Path('a_family/moment_results/positive-2d5aba857f2f7602-global17.json')
if result.exists():
 data=json.loads(result.read_text());r.squares={x['index']:tuple(map(I.Q,x['coefficients']))for x in data['squares']}
 for square in data['squares']:
  expected=D.L.psd_square_row(tuple(map(I.Q,square['coefficients'])),square['index'])
  assert r.rebuild(expected[2])==expected;count+=1
print('PASS_INDEPENDENT_MOMENT_ROW_RECONSTRUCTION',count,'exact rows',round(time.monotonic()-began,3),'seconds')
