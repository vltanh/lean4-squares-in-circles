"""Independently rebuild a path's owned-axis quadratic SAT rows."""
from pathlib import Path
import sys,re
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/a_family')
import independent_moment_rows as P

def frame(i):
 return (P.variable(18+i),P.variable(27+i)),(P.times_constant(P.variable(27+i),-1),P.variable(18+i))
def dot(v,w):return P.combine(P.product(v[0],w[0]),P.product(v[1],w[1]))
def determinant(v,w):return P.minus(P.product(v[0],w[1]),P.product(v[1],w[0]))
def rebuild(name,path):
 m=re.fullmatch(r'moment_original_sat_(\d+)_(\d+)_(\d+)_(\d+)_([01])_(-?1)_(-?1)',name);assert m
 k,i,j,owner,axis,sign,eps=map(int,m.groups())
 assert 0<=i<j<9 and owner in(i,j)
 assert path[k]==['sat',[i,j],[owner,axis,sign]]
 u,_=frame(i);w,_=frame(j);n=frame(owner)[axis]
 displacement=tuple(P.minus(P.variable(2*j+a),P.variable(2*i+a))for a in(0,1))
 lhs=P.combine(P.number(1),dot(u,w),P.times_constant(determinant(u,w),eps),P.times_constant(dot(displacement,n),-2*sign))
 return P.inequality(lhs,name)
