# Remaining A originals: completed OPEN work

This is a stopping-evidence and exact-bound packet. It closes zero original
cells. All five remaining A originals remain OPEN; the register stays 197/231
CLOSED and 34 OPEN, with 8/32 whole masks CLOSED. No Lean, Lake or CI was run.

Run: `python -B -S a_remaining_open_checkpoint/verify_open_all.py`.

The verifier requires Python standard library only. It checks real source
snapshots and exact original-bound/complete-cover arithmetic, all 39 recorded
static H-grid terminals and 145 conditional remainder deductions. The 25
unresolved grid records include exceptions 2 and 10; the complete remainder is
OPEN. Neither an exception nor an optimizer status proves feasibility.

The launcher loads packaged independent modules before historical helpers,
checks every workspace module origin, and rejects reads outside the packet
from other workspace locations. Historical source files remain byte-exact.

The raw moment and direct-PSD outputs are diagnostic only. Every stored rational
square is independently reconstructed, but no positive exact terminal exists.
Complete numerical primal/dual arrays and residual logs are preserved and
hashed. See proofs/A_REMAINING_FIVE_BOUNDED_STOPPING_EVIDENCE.md for scope,
results and the reasons the bounded attempts stopped.

No A8 or B2 closure archive or original certificate is included in this packet.
