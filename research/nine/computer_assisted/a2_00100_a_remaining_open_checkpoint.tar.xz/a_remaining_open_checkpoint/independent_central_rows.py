"""Independent physical reconstruction of unconditional all-nine arc rows.

No producer/generator is imported. The premise is exactly nine original
unit squares in closed Q, with disjoint interiors. The accepted arc theorem
implies: each own-axis max is >27/100, and at least two squares meet open
D_(23/100). Conditional branch rows are deliberately rejected here.
"""
from fractions import Fraction as Q
from math import isqrt
from itertools import product

R=Q(27,100);H=Q(23,100)

def clean(co,b,name):return tuple((k,v)for k,v in sorted(co.items())if v),b,name
def rootdown(x):
    assert x>=0;d=1<<48;n=isqrt(x.numerator*d*d//x.denominator)
    v=Q(n,d);assert v*v<=x<(v+Q(1,d))**2;return v
def minnorm(box,i):
    return sum(Q(0)if l<=0<=u else min(l*l,u*u)for l,u in box[2*i:2*i+2])
def eligible(box):
    upper=Q(1,2)+H*H+Q(99,70)*H
    assert Q(99,70)**2>2
    return [i for i in range(9)if minnorm(box,i)<upper]
def own_terms(i,axis,sg):
    return [(18+i,2*i,sg),(27+i,2*i+1,sg)]if axis==0 else[(18+i,2*i+1,sg),(27+i,2*i,-sg)]
def own_candidates(i,box,scalar):
    intervals=tuple(box)+tuple(scalar);ans=[]
    for axis,sg in product((0,1),(-1,1)):
        upper=sum(max(Q(sign)*a*b for a in intervals[j]for b in intervals[k])for j,k,sign in own_terms(i,axis,sg))
        if upper>R:ans.append((axis,sg))
    return ans

def rebuild(name,positions,scalar):
    assert len(positions)==18 and len(scalar)==36
    assert all(l<=u for l,u in tuple(positions)+tuple(scalar))
    p=name.split('_')
    if name=='central_nine_two_near_impossible':
        assert len(eligible(positions))<2
        return (),Q(-1),name
    assert p[:2]==['central','nine']
    if p[2:4]==['radial','secant']:
        assert len(p)==5;i=int(p[4]);assert 0<=i<9
        a,b=positions[2*i];c,d=positions[2*i+1]
        return clean({2*i:-a-b,2*i+1:-c-d},-R*R-a*b-c*d,name)
    if p[2:4]==['radial','axis']:
        assert len(p)==7 and p[4]in('lower','upper')
        i,axis=map(int,p[5:]);assert 0<=i<9 and axis in(0,1)
        l,u=positions[2*i+axis];a,b=positions[2*i+1-axis]
        delta=R*R-max(a*a,b*b);assert delta>0
        if p[4]=='lower':
            assert l>=0 or l*l<delta
            return clean({2*i+axis:Q(-1)},-rootdown(delta),name)
        assert u<=0 or u*u<delta
        return clean({2*i+axis:Q(1)},-rootdown(delta),name)
    if p[2:5]==['own','escape','empty']:
        assert len(p)==6;i=int(p[5]);assert 0<=i<9
        assert not own_candidates(i,positions,scalar)
        return (),Q(-1),name
    if p[2:4]==['own','escape']:
        assert len(p)==9;i,axis,sg,first,second=map(int,p[4:])
        assert 0<=i<9 and axis in(0,1)and sg in(-1,1)and first in(0,1)and second in(0,1)
        assert own_candidates(i,positions,scalar)==[(axis,sg)]
        bounds=tuple(positions)+tuple(scalar);co={};constant=Q(0)
        for (j,k,sign),choice in zip(own_terms(i,axis,sg),(first,second)):
            a,b=bounds[j];c,d=bounds[k]
            if sign==1:
                # Both upper secants of the bilinear function.
                ja,kb,shift=(c,b,-b*c)if choice==0 else(d,a,-a*d)
            else:
                # Negatives of its two lower planes.
                ja,kb,shift=(-c,-a,a*c)if choice==0 else(-d,-b,b*d)
            co[j]=co.get(j,Q(0))-ja;co[k]=co.get(k,Q(0))-kb;constant+=shift
        return clean(co,constant-R,name)
    if p[2]=='near':
        assert p[3]in('axis','support')and len(p)==7
        i=int(p[4]);assert 0<=i<9
        near=eligible(positions);assert len(near)==2 and i in near
        sign=int(p[6]);assert sign in(-1,1)
        if p[3]=='axis':
            axis=int(p[5]);assert axis in(0,1)
            return clean({2*i+axis:Q(sign),18+i:Q(-1,2),36+i:Q(-1,2)},H,name)
        raw=[(1,0),(0,1),(Q(3,5),Q(4,5)),(Q(4,5),Q(3,5)),
             (Q(5,13),Q(12,13)),(Q(12,13),Q(5,13)),(Q(8,17),Q(15,17)),
             (Q(15,17),Q(8,17)),(Q(7,25),Q(24,25)),(Q(24,25),Q(7,25))]
        directions=[]
        for x,y in raw:
            for s in(-1,1):
                point=(Q(x),Q(s*y))
                if point not in directions:directions.append(point)
        direction=int(p[5]);assert 0<=direction<len(directions)
        x,y=directions[direction];assert x*x+y*y==1
        def chord(a,b):
            values=[a*alpha+b*beta for alpha in scalar[i]for beta in scalar[9+i]]
            l,u=min(values),max(values)
            if l>=0:return a,b,Q(0)
            if u<=0:return -a,-b,Q(0)
            slope=(u+l)/(u-l);intercept=-2*l*u/(u-l)
            return a*slope,b*slope,intercept
        first=chord(x,y);second=chord(y,-x)
        ca,cb,offset=[(a+b)/2 for a,b in zip(first,second)]
        return clean({2*i:sign*x,2*i+1:sign*y,18+i:-ca,27+i:-cb},H+offset,name)
    raise AssertionError(('unreviewed_global_nine_rule',name))
