#!/usr/bin/env python3
"""Exact support maxima over a complete near-original cover, then global induction.

Every accepted objective bound is the maximum of exact upper bounds on
ALL viable physical cases. Every omitted case has an exact contradiction.
All installed bounds concern the whole unchanged original parent. Solver
output is used only to discover positive rational weighted certificates.
"""
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,argparse,copy
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(Path('/workspace/scratch/29af4f6e10bf/current_proof')))
import v3_whole_parent_pass as M
sys.path.insert(0,str(HERE))
import central_nine_rows as N
import central_cover_rows as C
from central_union_cuts import phase,sha


def support_maxima(rows,bounds,cases,targets,eps=M.EPS):
    """Reusable exact-max primitive; targets=(kind,key,sign,objective,old)."""
    active=[];excluded=[];used={};allrows={};began=time.monotonic()
    for case in cases:
        key=tuple(case['pair']);rr=rows+case['rows'];test,h=phase(rr,bounds)
        allrows[key]=rr;used[key]=set()
        if test['status']=='EXACT_POSITIVE_CANDIDATE':
            excluded.append({'pair':list(key),**{k:v for k,v in test.items()if k not in('phase','status')}})
            used[key].update(i for i,w in test['weights'])
        elif test['status']=='OPEN_RELAXATION':
            h.changeColCost(len(bounds),0.);h.changeColBounds(len(bounds),0.,0.)
            active.append({'pair':key,'h':h,'previous':[],'rows':rr})
        else:
            return {'status':'SOLVER_LIMIT_NO_BOUND','reason':test['status']}
    print('COMPLETE_COVER_SUPPORT_CASES',len(active),'viable',len(excluded),'exactly impossible',flush=True)
    result={'status':'COMPLETE_COVER_IMPOSSIBLE'if not active else'COMPLETE_COVER_BOUNDS',
        'excluded_cases':excluded,'viable_pairs':[list(a['pair'])for a in active],'proposals':[],
        'complete_pairs':[list(c['pair'])for c in cases]}
    attempts=0
    for kind,key,sign,objective,old in targets:
        if not active:break
        parts=[];successful=True
        for a in active:
            h=a['h']
            for k,v in a['previous']:h.changeColCost(k,0.)
            for k,v in objective:h.changeColCost(k,-float(v))
            a['previous']=objective;h.setOptionValue('time_limit',h.getRunTime()+3.);h.run();attempts+=1
            if h.getModelStatus()!=M.H.HighsModelStatus.kOptimal:
                successful=False;break
            if float(old)+h.getObjectiveValue()<float(eps):
                successful=False;break
            weights=M.terms(h.getSolution().row_dual)
            co,rhs=M.R.weighted_sum(a['rows'],bounds,weights)
            for k,v in objective:co[k]-=Q(v)
            residual=sum(m*abs(v)for m,v in zip(bounds,co));proved=rhs+residual;upper=M.ceil_grid(proved)
            if old-upper<eps:
                successful=False;break
            parts.append({'pair':list(a['pair']),'upper':str(upper),'proved_upper':str(proved),
                'weights':weights,'summed_rhs':str(rhs),'residual_correction':str(residual),
                'residual_coefficients':[[k,str(v)]for k,v in enumerate(co)if v]})
        if not successful:continue
        assert len(parts)==len(active)
        upper=max(Q(p['upper'])for p in parts)
        assert old-upper>=eps
        proposal={'kind':kind,'key':list(key)if isinstance(key,tuple)else key,'sign':sign,
            'objective':[[k,v]for k,v in objective],'old':str(old),'upper':str(upper),'alternatives':parts}
        result['proposals'].append(proposal)
        for a in parts:used[tuple(a['pair'])].update(i for i,w in a['weights'])
    result['printed_rows_by_pair']=[{'pair':list(c['pair']),
        'rows':M.R.printed_rows(allrows[tuple(c['pair'])],used[tuple(c['pair'])])}for c in cases]
    result['objective_attempts']=attempts;result['seconds']=time.monotonic()-began
    print('COMPLETE_COVER_SUPPORT_MAXIMA',len(result['proposals']),'deductions',attempts,'objectives',round(result['seconds'],1),'seconds',flush=True)
    return result


def load_state(source):
    d=json.loads(Path(source).read_text())
    assert d['status']=='OPEN'and d['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'
    _,_,choices=M.V.reconstruct(d['path'])
    state={'id':d['id'],'path':d['path'],'angles':M.K.box(d['final_angles']),
        'positions':M.K.box(d['final_positions']),'scalar':M.K.box(d['final_scalar']),'choices':choices}
    diffs={tuple(v['pair']):M.K.box(v['intervals'])for v in d['final_differences']}
    return d,state,diffs


def collect(state,diffs):
    rows,bounds,terminal,pos,scalar,effective,guards=M.collect(state,diffs)
    assert terminal is None,terminal
    extra,central=N.generate_rows(pos,scalar);rows+=extra
    cases,cover=C.complete_cases(pos,scalar)
    return rows,bounds,pos,scalar,effective,guards,central,cases,cover


def targets(pos,scalar,diffs,only_centers=False):
    result=[]
    for k,(lo,hi)in enumerate(tuple(pos)+tuple(scalar)):
        if only_centers and k>=18:break
        for sign in(-1,1):result.append(('scalar',k,sign,[(k,sign)],hi if sign==1 else-lo))
    if not only_centers:
        for(i,j),ds in sorted(diffs.items()):
            for axis,(lo,hi)in enumerate(ds):
                for sign in(-1,1):
                    result.append(('difference',(i,j,axis),sign,[(2*j+axis,sign),(2*i+axis,-sign)],hi if sign==1 else-lo))
    return result


def run(source,rounds=2,only_centers=False):
    started=time.monotonic();source=Path(source);prior,state,diffs=load_state(source)
    output={'schema':'whole_original_complete_central_cover_bounds_v1','id':state['id'],'path':state['path'],
        'scope':'WHOLE_UNCHANGED_ORIGINAL_PARENT','new_refinement_nodes':0,
        'prior':{'file':str(source),'sha256':sha(source)},'status':'OPEN','rounds':[],
        'sources':{str(p):sha(p)for p in(Path(__file__),Path(N.__file__),Path(C.__file__),Path(M.__file__))},
        'acceptance':'PENDING_INDEPENDENT_FULL_PREFIX_COMPLETE_COVER_AND_ARITHMETIC_REPLAY',
        'new_originals_closed':0,'maximum_new_rounds':rounds}
    dest=HERE/'central_cover_bounds';dest.mkdir(exist_ok=True)
    def save():
        output.update(seconds=time.monotonic()-started,final_angles=M.render(state['angles']),
            final_positions=M.render(state['positions']),final_scalar=M.render(state['scalar']),
            final_differences=M.render_diff(diffs))
        (dest/(state['id']+'.json')).write_text(json.dumps(output,indent=2)+'\n')
    for roundno in range(rounds+1):
        rows,bounds,pos,scalar,effective,guards,central,cases,cover=collect(state,diffs)
        rr={'round':roundno,'angles_before':M.render(state['angles']),
            'positions_before':M.render(state['positions']),'scalar_before':M.render(state['scalar']),
            'differences_before':M.render_diff(diffs),'propagated_positions':M.render(pos),
            'physical_scalar_intersection':M.render(scalar),'effective_differences':M.render_diff(effective),
            'absolute_variable_bounds':list(map(str,bounds)),'rows':len(rows),
            'three_square_guards':guards,'central_guards':central,'central_cover':cover}
        if not cases:
            output.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal={'kind':'empty_complete_central_cover','state':rr});break
        test,h=phase(rows,bounds)
        if test['status']=='EXACT_POSITIVE_CANDIDATE':
            output.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal={'kind':'positive_exact_reserve','state':rr,**test});break
        if test['status']!='OPEN_RELAXATION':output['stopped_reason']=test['status'];break
        if roundno==rounds:output['final_test']=rr;break
        answer=support_maxima(rows,bounds,cases,targets(pos,scalar,effective,only_centers))
        rr['complete_support']=answer
        if answer['status']=='SOLVER_LIMIT_NO_BOUND':output['stopped_reason']=answer;break
        if answer['status']=='COMPLETE_COVER_IMPOSSIBLE':
            output.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal={'kind':'complete_central_cover_contradiction','state':rr});break
        newpos=[list(ab)for ab in pos];newscalar=[list(ab)for ab in scalar]
        newdiff={p:[list(ab)for ab in ds]for p,ds in effective.items()}
        for proposal in answer['proposals']:
            key=proposal['key'];sign=proposal['sign'];upper=Q(proposal['upper'])
            if proposal['kind']=='scalar':target=newpos[key]if key<18 else newscalar[key-18]
            else:target=newdiff[key[0],key[1]][key[2]]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
        pos=tuple(map(tuple,newpos));scalar=tuple(map(tuple,newscalar));newdiff={p:tuple(map(tuple,ds))for p,ds in newdiff.items()}
        if any(a>b for a,b in pos+scalar)or any(a>b for ds in newdiff.values()for a,b in ds):
            output.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal={'kind':'proved_empty_interval','state':rr});break
        angles,contradiction,identities=M.R.infer_angles(state['angles'],scalar)
        rr['physical_frame_inferences']=identities
        if contradiction:
            output.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal={'kind':contradiction,'state':rr});break
        analytic=M.R.analytic_frames(angles)
        scalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(scalar,analytic))
        if any(a>b for a,b in scalar):
            output.update(status='COMPLETE_ORIGINAL_CANDIDATE',terminal={'kind':'proved_empty_analytic_frame','state':rr});break
        state.update(angles=angles,positions=pos,scalar=scalar);diffs=newdiff
        rr.update(angles_after=M.render(angles),positions_after=M.render(pos),
            scalar_after=M.render(scalar),differences_after=M.render_diff(diffs))
        output['rounds'].append(rr);save()
        print(state['id'],'WHOLE_PARENT_COMPLETE_COVER_ROUND',roundno,len(answer['proposals']),flush=True)
        if not answer['proposals']:break
    save();print(state['id'],'FINAL',output['status'],len(output['rounds']),round(output['seconds'],1),flush=True)
    return output

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('--rounds',type=int,default=2)
    ap.add_argument('--centers-only',action='store_true');a=ap.parse_args();assert 0<=a.rounds<=4
    run(a.source,a.rounds,a.centers_only)
