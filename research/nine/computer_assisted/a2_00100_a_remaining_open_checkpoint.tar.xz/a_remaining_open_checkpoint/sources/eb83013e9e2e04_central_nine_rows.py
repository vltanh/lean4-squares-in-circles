"""Exact global nine-original central-capacity consequences.

Input premise: nine disjoint unit squares, all corners in ||p||^2<=1105/256.
Uses SMALLER_CENTRAL_DISKS_NINE_UNIT_CAPACITY.md, independently accepted
2026-10-27. No selected-chain, mask, angle-sign, or contact premise.

Rows are tuples (sparse rational coefficients, rational rhs, rule name)
for the existing 54 original variables. No solver is imported.
"""
from fractions import Fraction as Q
from itertools import product, combinations
from math import isqrt

H=Q(23,100)
R=Q(27,100)
ROOT_DEN=1<<48
# Rational upper bound for (H+1/sqrt(2))^2, using sqrt(2)<99/70.
NEAR_NORM_SQUARED_UPPER=Q(1,2)+H*H+H*Q(99,70)
DIRECTIONS=((Q(1),Q(0)),(Q(0),Q(1)),
 (Q(3,5),Q(4,5)),(Q(4,5),Q(3,5)),
 (Q(5,13),Q(12,13)),(Q(12,13),Q(5,13)),
 (Q(8,17),Q(15,17)),(Q(15,17),Q(8,17)),
 (Q(7,25),Q(24,25)),(Q(24,25),Q(7,25)))
DIRECTIONS=tuple(dict.fromkeys((p,s*q)for p,q in DIRECTIONS for s in(-1,1)))


def clean(co,rhs,name):
    return tuple((k,v)for k,v in sorted(co.items())if v),rhs,name


def sqrt_lower(x):
    assert x>=0
    z=isqrt(x.numerator*ROOT_DEN*ROOT_DEN//x.denominator)
    lo=Q(z,ROOT_DEN)
    assert lo*lo<=x<(lo+Q(1,ROOT_DEN))**2
    return lo


def box_min_norm2(positions,i):
    return sum(Q(0)if a<=0<=b else min(a*a,b*b)for a,b in positions[2*i:2*i+2])


def radial_rows(positions):
    """Unconditional all-nine norm exclusions and one-axis implications.

    All inequalities are weakened from strict to non-strict. Dropping
    strictness enlarges the feasible set and cannot invent a closure.
    """
    rows=[];inferences=[]
    for i in range(9):
        x,y=positions[2*i:2*i+2]
        rows.append(clean({2*i:-sum(x),2*i+1:-sum(y)},
            -R*R-x[0]*x[1]-y[0]*y[1],f'central_nine_radial_secant_{i}'))
        for axis in(0,1):
            own=positions[2*i+axis];other=positions[2*i+1-axis]
            needed=R*R-max(a*a for a in other)
            if needed<=0:continue
            lo,hi=own
            # y^2>needed. Rule out the negative or positive component only
            # with a certified coordinate interval, including zero/ties.
            if lo>=0 or lo*lo<needed:
                floor=sqrt_lower(needed)
                rows.append(clean({2*i+axis:Q(-1)},-floor,
                    f'central_nine_radial_axis_lower_{i}_{axis}'))
                inferences.append({'original':i,'axis':axis,'sign':1,
                    'square_floor':str(needed),'proved_floor':str(floor)})
            if hi<=0 or hi*hi<needed:
                floor=sqrt_lower(needed)
                rows.append(clean({2*i+axis:Q(1)},-floor,
                    f'central_nine_radial_axis_upper_{i}_{axis}'))
                inferences.append({'original':i,'axis':axis,'sign':-1,
                    'square_floor':str(needed),'proved_floor':str(floor)})
    return rows,inferences


def own_expression(i,axis,sign):
    assert axis in(0,1)and sign in(-1,1)
    if axis==0:return ((18+i,2*i,Q(sign)),(27+i,2*i+1,Q(sign)))
    return ((18+i,2*i+1,Q(sign)),(27+i,2*i,Q(-sign)))


def product_bounds(interval_a,interval_b):
    vals=[a*b for a,b in product(interval_a,interval_b)]
    return min(vals),max(vals)


def expression_interval(expr,allbounds):
    lo=hi=Q(0)
    for a,b,c in expr:
        mn,mx=product_bounds(allbounds[a],allbounds[b])
        lo+=min(c*mn,c*mx);hi+=max(c*mn,c*mx)
    return lo,hi


def product_upper_planes(ia,ib,sign,allbounds):
    al,au=allbounds[ia];bl,bu=allbounds[ib]
    if sign==1:
        return (({ia:bl,ib:au},-au*bl),({ia:bu,ib:al},-al*bu))
    assert sign==-1
    return (({ia:-bl,ib:-al},al*bl),({ia:-bu,ib:-au},au*bu))


def own_escape_cases(i,positions,scalar):
    """Complete remaining cover of max(|c.u|,|c.v|)>27/100.

    Excluded cases have an independently checkable interval upper<=27/100.
    Each retained case carries four necessary affine rows (all products use
    the same original's actual alpha and beta). A singleton case is global.
    """
    allbounds=tuple(positions)+tuple(scalar)
    cases=[];excluded=[]
    for axis,sign in product((0,1),(-1,1)):
        expr=own_expression(i,axis,sign)
        lo,hi=expression_interval(expr,allbounds)
        if hi<=R:
            excluded.append({'axis':axis,'sign':sign,'upper':str(hi)})
            continue
        planes=[product_upper_planes(a,b,c,allbounds)for a,b,c in expr]
        rows=[]
        for ap,bp in product((0,1),repeat=2):
            co={};constant=Q(0)
            for table,k in zip(planes,(ap,bp)):
                terms,c=table[k];constant+=c
                for j,v in terms.items():co[j]=co.get(j,Q(0))-v
            rows.append(clean(co,constant-R,
                f'central_nine_own_escape_{i}_{axis}_{sign}_{ap}_{bp}'))
        cases.append({'axis':axis,'sign':sign,'rows':rows})
    return cases,excluded


def universal_rows(positions,scalar):
    rows,guards=radial_rows(positions);disjunctions=[]
    for i in range(9):
        cases,excluded=own_escape_cases(i,positions,scalar)
        disjunctions.append({'original':i,'cases':cases,'excluded':excluded})
        if not cases:
            # All four exact interval bounds <=R contradict the strict
            # all-nine exclusion. The empty row records this global fact.
            rows.append(((),Q(-1),f'central_nine_own_escape_empty_{i}'))
        elif len(cases)==1:
            rows+=cases[0]['rows']
    return rows,guards,disjunctions


def abs_upper(ca,cb,i,scalar):
    aa,bb=scalar[i],scalar[9+i]
    lo=sum(min(c*x for x in ab)for c,ab in((ca,aa),(cb,bb)))
    hi=sum(max(c*x for x in ab)for c,ab in((ca,aa),(cb,bb)))
    if lo>=0:return ca,cb,Q(0)
    if hi<=0:return -ca,-cb,Q(0)
    slope=(hi+lo)/(hi-lo);shift=-2*hi*lo/(hi-lo)
    return slope*ca,slope*cb,shift


def near_support_rows(i,scalar):
    """Necessary same-frame rows when square i meets open D_(23/100)."""
    rows=[]
    # Axis directions have exact h=(alpha+absbeta)/2, stronger than a
    # chord of abs(beta) when the current scalar box contains zero.
    for axis,sign in product((0,1),(-1,1)):
        rows.append(clean({2*i+axis:Q(sign),18+i:Q(-1,2),36+i:Q(-1,2)},H,
            f'central_nine_near_axis_{i}_{axis}_{sign}'))
    for di,(p,q)in enumerate(DIRECTIONS):
        assert p*p+q*q==1
        a=abs_upper(p,q,i,scalar);b=abs_upper(q,-p,i,scalar)
        ca,cb,cc=((x+y)/2 for x,y in zip(a,b))
        for sign in(-1,1):
            co={2*i:sign*p,2*i+1:sign*q,18+i:-ca,27+i:-cb}
            rows.append(clean(co,H+cc,
                f'central_nine_near_support_{i}_{di}_{sign}'))
    return rows


def central_pair_cases(positions,scalar):
    """Complete cover: some two of the nine originals meet the small disk.

    Radial exclusion only removes impossible near-originals. All remaining
    pairs are retained; a pair is never selected from a relaxed point.
    Each case adds support necessities, not sufficient intersection tests.
    """
    candidates=[i for i in range(9)if box_min_norm2(positions,i)<NEAR_NORM_SQUARED_UPPER]
    excluded=[{'original':i,'norm_lower_squared':str(box_min_norm2(positions,i)),
               'near_norm_upper_squared':str(NEAR_NORM_SQUARED_UPPER)}
              for i in range(9)if i not in candidates]
    return [{'pair':(i,j),'rows':near_support_rows(i,scalar)+near_support_rows(j,scalar)}
            for i,j in combinations(candidates,2)],excluded


def generate_rows(positions,scalar):
    """Drop-in global rows; unresolved finite alternatives stay metadata.

    Returns (rows, guards). Only rows valid on the whole current original
    parent are emitted. The finite pair/own-axis cases may separately be
    convexified, but are never silently promoted to whole-parent premises.
    """
    rows,radial,own=universal_rows(positions,scalar)
    pairs,excluded=central_pair_cases(positions,scalar)
    forced=[]
    if not pairs:
        rows.append(((),Q(-1),'central_nine_two_near_impossible'))
    elif len(pairs)==1:
        rows+=pairs[0]['rows'];forced=list(pairs[0]['pair'])
    guards={'radial':radial,'own_escape':[
        {'original':d['original'],'excluded':d['excluded'],
         'remaining':[{k:c[k]for k in('axis','sign')}for c in d['cases']]}
         for d in own],
        'central_excluded':excluded,'central_pair_count':len(pairs),
        'forced_central_originals':forced}
    return rows,guards
