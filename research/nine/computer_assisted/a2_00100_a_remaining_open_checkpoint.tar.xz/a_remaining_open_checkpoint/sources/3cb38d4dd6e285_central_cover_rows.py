"""Exact complete near-original covers from the global nine-square theorem.

Keeps central_nine_rows.py unchanged while current bound pilots run.
All classifications below concern each original square in its own actual
frame. No conditional row is promoted without an explicit complete cover.
"""
from fractions import Fraction as Q
from itertools import combinations
import central_nine_rows as N


def own_projection_bounds(i,positions,scalar):
    bounds=tuple(positions)+tuple(scalar)
    return tuple(N.expression_interval(N.own_expression(i,axis,1),bounds)for axis in(0,1))


def abs_bounds(ab):
    a,b=ab
    return (Q(0)if a<=0<=b else min(abs(a),abs(b)),max(abs(a),abs(b)))


def classifications(positions,scalar):
    """Return exact whole-parent proofs of near, non-near, or undecided.

    A square is near iff its distance from the origin is strictly <23/100.
    Lower and upper own-coordinate distances are separately conservative.
    Center incircle/circumcircle bounds are independent of orientation.
    """
    answers=[]
    for i in range(9):
        center_min=N.box_min_norm2(positions,i)
        center_max=sum(max(a*a,b*b)for a,b in positions[2*i:2*i+2])
        projected=own_projection_bounds(i,positions,scalar)
        absolute=tuple(abs_bounds(ab)for ab in projected)
        distance_lower=sum(max(lo-Q(1,2),Q(0))**2 for lo,hi in absolute)
        distance_upper=sum(max(hi-Q(1,2),Q(0))**2 for lo,hi in absolute)
        near=[];far=[]
        if center_max<(N.H+Q(1,2))**2:near.append('incircle_center_upper')
        if distance_upper<N.H*N.H:near.append('own_projection_distance_upper')
        if center_min>=N.NEAR_NORM_SQUARED_UPPER:far.append('circumcircle_center_lower')
        if distance_lower>=N.H*N.H:far.append('own_projection_distance_lower')
        answers.append({'original':i,'near_rules':near,'far_rules':far,
            'center_min_squared':str(center_min),'center_max_squared':str(center_max),
            'own_projection_intervals':[[str(x)for x in ab]for ab in projected],
            'own_distance_lower_squared':str(distance_lower),
            'own_distance_upper_squared':str(distance_upper)})
    return answers


def complete_cases(positions,scalar):
    """A complete cover of the whole original parent, using 0 to36 cases.

    If a known-near original exists, fix its least label and retain all
    other eligible second originals. If two are known near, one fixed pair
    suffices. Otherwise retain every unordered eligible pair.
    Each case contains necessary support inequalities for its two originals.
    The actual near conditions themselves remain case premises, and the
    support relaxation may therefore only enlarge the covered set.
    """
    proofs=classifications(positions,scalar)
    near=[d['original']for d in proofs if d['near_rules']]
    eligible=[d['original']for d in proofs if not d['far_rules']]
    contradiction=any(d['near_rules']and d['far_rules']for d in proofs)
    if contradiction or len(eligible)<2:
        pairs=[]
    elif len(near)>=2:
        pairs=[tuple(near[:2])]
    elif near:
        pairs=[tuple(sorted((near[0],j)))for j in eligible if j!=near[0]]
    else:
        pairs=list(combinations(eligible,2))
    cases=[{'pair':pair,'rows':N.near_support_rows(pair[0],scalar)+N.near_support_rows(pair[1],scalar)}for pair in pairs]
    report={'classifications':proofs,'known_near':near,'eligible_near':eligible,
            'contradictory_classification':contradiction,'complete_pairs':[list(p)for p in pairs]}
    return cases,report
