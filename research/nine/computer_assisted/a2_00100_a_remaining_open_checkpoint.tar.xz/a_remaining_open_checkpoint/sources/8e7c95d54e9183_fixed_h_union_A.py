#!/usr/bin/env python3
"""One five-round H bounding-rectangle proof from a complete canonical parent.

The unchanged fixed 8x8 H-center cover is never subdivided.  The rectangle may
overlap already closed tiles.  This is discovery until independently replayed.
"""
import os
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[key] = '1'

import json
import sys
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0,'/workspace/scratch/29af4f6e10bf/current_proof')
import v3_whole_parent_pass as M
import continue_global_capacity as G
TARGET_ORIGINAL = 7
PARENT = sys.argv[1]
assert len(sys.argv) == 3, 'Pass the canonical parent ID and complete source record explicitly'
SOURCE = Path(sys.argv[2]).resolve()
OBJ = json.loads(SOURCE.read_text())
assert OBJ['id'] == PARENT and OBJ['status'] == 'OPEN'
assert 'final_test' in OBJ
assert OBJ['scope'] == 'WHOLE_UNCHANGED_ORIGINAL_PARENT' and OBJ['new_refinement_nodes'] == 0
PATH = OBJ['path']
REGISTRY_PATH = HERE.parent / 'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
REGISTRY = json.loads(REGISTRY_PATH.read_text())
CANONICAL = [cell for cell in REGISTRY['cells'] if cell['id'] == PARENT]
assert len(CANONICAL) == 1 and CANONICAL[0]['path'] == PATH


def box(value):
    return tuple(tuple(Q(v) for v in interval) for interval in value)


ANGLES = box(OBJ['final_angles'])
POS = box(OBJ['final_positions'])
SCALAR = box(OBJ['final_scalar'])
DIFF = {tuple(d['pair']): box(d['intervals']) for d in OBJ['final_differences']}
_, _, CHOICES = M.V.reconstruct(PATH)
GRID = HERE / 'fixed_h_grid_generic' / PARENT
MANIFEST = json.loads((GRID / 'manifest.json').read_text())
SUMMARY = json.loads((GRID / 'summary.json').read_text())
assert MANIFEST['target_original'] == TARGET_ORIGINAL
assert MANIFEST['parent_sha256'] == M.sha(SOURCE)
assert MANIFEST['path'] == PATH
assert MANIFEST['canonical_parent_id'] == PARENT and MANIFEST['canonical_path'] == PATH
assert MANIFEST['parent_schema'] == OBJ['schema']
assert SUMMARY['target_original'] == TARGET_ORIGINAL and SUMMARY['tiles_tested'] == 64
PENDING = SUMMARY['open']
assert PENDING
IX, IY = [t // 8 for t in PENDING], [t % 8 for t in PENDING]
XMIN, XMAX, YMIN, YMAX = min(IX), max(IX), min(IY), max(IY)
X_INDEX, Y_INDEX = 2 * TARGET_ORIGINAL, 2 * TARGET_ORIGINAL + 1
xa, xb = POS[X_INDEX]
ya, yb = POS[Y_INDEX]
UNION = (
    (xa + (xb - xa) * XMIN / 8, xa + (xb - xa) * (XMAX + 1) / 8),
    (ya + (yb - ya) * YMIN / 8, ya + (yb - ya) * (YMAX + 1) / 8),
)
COVERED = [ix * 8 + iy for ix in range(XMIN, XMAX + 1) for iy in range(YMIN, YMAX + 1)]
for tile in PENDING:
    r = json.loads((GRID / f'tile_{tile:02d}.json').read_text())
    assert r['status'] == 'OPEN' and r['target_original'] == TARGET_ORIGINAL
    assert all(a <= c <= d <= b for (a, b), (c, d) in zip(UNION, box(r['center_box'])))


def initial(cell):
    positions = list(POS)
    positions[X_INDEX], positions[Y_INDEX] = UNION
    state = {
        'id': cell['id'], 'path': PATH, 'angles': ANGLES,
        'positions': tuple(positions), 'choices': CHOICES, 'scalar': SCALAR,
    }
    prior = {
        'kind': 'SOURCE_BOUND_PARENT_PLUS_FROZEN_GRID_COVERING_RECTANGLE',
        'file': str(SOURCE), 'sha256': M.sha(SOURCE),
        'deductions': 'requires complete actual-schema canonical-parent replay',
        'parent_source_kind': 'COMPLETE_CANONICAL_PARENT_STATE',
        'parent_schema': OBJ['schema'], 'parent_state_scope': OBJ['scope'],
        'canonical_parent_id': PARENT, 'canonical_path': PATH,
        'parent_id': PARENT, 'target_original': TARGET_ORIGINAL,
        'original': 'H', 'center_box': M.render(UNION),
        'pending_tiles': PENDING, 'covered_tiles': COVERED,
        'grid_manifest': str(GRID / 'manifest.json'),
        'grid_manifest_sha256': M.sha(GRID / 'manifest.json'),
        'grid_summary_sha256': M.sha(GRID / 'summary.json'),
    }
    return state, prior, None


def collect(state, differences):
    merged = dict(DIFF)
    for pair, vals in differences.items():
        prior = merged[pair]
        merged[pair] = tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(prior, vals))
    return G.collect(state, merged)


BASE_SAVE = M.save


def save(record):
    record['scope'] = 'COMPLETE_CANONICAL_PARENT_FROZEN_GRID_COVERING_RECTANGLE_ONLY; NOT_WHOLE_PARENT_BY_ITSELF'
    record['parent_schema'] = OBJ['schema']
    record['parent_source_kind'] = 'COMPLETE_CANONICAL_PARENT_STATE'
    record['canonical_parent_id'] = PARENT
    record['canonical_path'] = PATH
    record['original_parent'] = PARENT
    record['target_original'] = TARGET_ORIGINAL
    record['center_box'] = M.render(UNION)
    record['additional_predicate'] = {
        'original': 'H', 'target_original': TARGET_ORIGINAL,
        'center_rectangle': M.render(UNION),
        'covered_tiles': COVERED, 'pending_tiles': PENDING,
    }
    record['grid_status'] = 'Frozen 8x8 H-center cover unchanged; no further subdivision'
    record['accepted_new_cells'] = 0
    record['independent_replay_status'] = 'PENDING_NOT_ACCEPTED'
    record['additional_sources'] = {
        str(p): M.sha(p) for p in [Path(__file__),Path(G.__file__),Path(G.GC.__file__),HERE/'fixed_h_grid_A.py']
    }
    BASE_SAVE(record)


if __name__ == '__main__':
    M.initial = initial
    M.collect = collect
    M.save = save
    M.HERE = HERE / 'fixed_h_A_unions'
    M.HERE.mkdir(exist_ok=True)
    M.VERSION = 'n9_frozen_h_grid_complete_central_cover_parent_rectangle_six_round_v1'
    cell = {'id': PARENT + '_covering_H_rectangle', 'path': PATH}
    dest = M.HERE / 'v3_results' / (cell['id'] + '.json')
    assert not dest.exists(), 'Frozen rectangle record already exists'
    M.run(cell, 6)
    record = json.loads(dest.read_text())
    assert record['target_original'] == TARGET_ORIGINAL
    print('COMPLETE_FIXED_H_RECTANGLE_RESULT', PARENT, record['status'], flush=True)
