"""Independent exact replay of a completed, still-OPEN fixed H-grid attempt.

This does not assert whole-original closure. All39 reported static exclusions
and all six conditional remainder rounds are checked. The25 unresolved grid
tiles and the complete remainder remain explicitly OPEN.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def box(x):return tuple(tuple(Q(v)for v in ab)for ab in x)

def verify(parent_path,grid,union_path,J):
    parent_path,grid,union_path=map(Path,(parent_path,grid,union_path));parent=json.loads(parent_path.read_text())
    K=J.K;ident=parent['id'];path=parent['path'];_,_,choices=K.V.reconstruct(path)
    angles=box(parent['final_angles']);positions=box(parent['final_positions']);scalar=box(parent['final_scalar'])
    diffs={tuple(d['pair']):box(d['intervals'])for d in parent['final_differences']}
    manifest=json.loads((grid/'manifest.json').read_text());summary=json.loads((grid/'summary.json').read_text());rec=json.loads(union_path.read_text())
    assert manifest['parent_sha256']==sha(parent_path)and manifest['canonical_parent_id']==ident and manifest['path']==path
    assert manifest['grid_size']==[8,8]and manifest['target_original']==7 and manifest['adaptive_splits']==0
    assert manifest['additional_bound_rounds_per_tile']==0 and manifest['static_dual_tests_per_tile']==1
    assert summary['status']=='OPEN_PARENT_NO_CLOSURE'and summary['tiles_tested']==64 and summary['all_64_candidate_closed']is False
    assert {p.name for p in grid.glob('tile_*.json')}=={f'tile_{i:02d}.json'for i in range(64)}
    for name,h in manifest['sources'].items():assert sha(J.local_source(name))==h
    xa,xb=positions[14];ya,yb=positions[15];assert box(manifest['center_box'])==((xa,xb),(ya,yb))
    def physical(pos,sca,ang,delta):
        _,_,early=K.collect_rows(K.V,path,ang,pos,choices)
        if early:return None,None,early,None,None,None,None
        base,bounds,prop,sc,df,guards=K.rebuild(path,ang,pos,choices,sca,delta)
        return base,bounds,None,prop,sc,df,guards
    def check(saved,prop,sc,df,guards):
        assert box(saved['propagated_positions'])==prop and box(saved['physical_scalar_intersection'])==sc
        assert saved['effective_differences']==K.diffview(df)and saved['three_square_guards'][:len(guards)]==guards
    closed=[];pending=[];exceptions=[];static_printed=0;early_count=0;reserves=[]
    for tile in range(64):
        s=json.loads((grid/f'tile_{tile:02d}.json').read_text());ix,iy=divmod(tile,8)
        rect=((xa+(xb-xa)*ix/8,xa+(xb-xa)*(ix+1)/8),(ya+(yb-ya)*iy/8,ya+(yb-ya)*(iy+1)/8))
        assert s['tile']==tile and s['ix']==ix and s['iy']==iy and s['parent_id']==ident and s['target_original']==7 and box(s['center_box'])==rect
        assert s['status']in('OPEN','CANDIDATE_CLOSED')
        if s['status']=='OPEN':
            pending.append(tile)
            if 'error'in s:exceptions.append(tile)
            continue
        assert 'error'not in s
        pos=list(positions);pos[14],pos[15]=rect
        base,bounds,early,prop,sc,df,guards=physical(tuple(pos),scalar,angles,diffs);term=s['terminal']
        if early:
            assert term=={'kind':'exact_interval_or_accepted_terminal','label':early};early_count+=1
        else:
            assert term['kind']=='positive_exact_reserve';check(s,prop,sc,df,guards)
            rows,_=J.rows_for_record(dict(s,printed_rows=term['rows']),base,sc,df,angles)
            assert {k for k,w in term['weights']}=={x['index']for x in term['rows']}
            co,rhs=K.sum_rows(rows,bounds,term['weights']);reserve=-rhs-sum(m*abs(v)for m,v in zip(bounds,co))
            assert reserve>0 and reserve==Q(term['reserve'])and rhs==Q(term['weighted_rhs'])and co==list(map(Q,term['weighted_coefficients']))
            assert term['absolute_variable_bounds']==list(map(str,bounds));reserves.append(reserve);static_printed+=len(term['rows'])
        closed.append(tile)
    assert closed==summary['candidate_closed']and pending==summary['open']and len(closed)==39 and len(pending)==25
    assert rec['status']=='OPEN'and rec['new_branch_nodes']==0 and rec['maximum_new_rounds']==6 and len(rec['rounds'])==6
    assert rec['id']==ident+'_covering_H_rectangle'and rec['original_parent']==ident and rec['path']==path and rec['target_original']==7
    assert rec['scope']=='COMPLETE_CANONICAL_PARENT_FROZEN_GRID_COVERING_RECTANGLE_ONLY; NOT_WHOLE_PARENT_BY_ITSELF'
    assert rec['prior']['sha256']==sha(parent_path)and rec['prior']['pending_tiles']==pending
    assert rec['prior']['grid_manifest_sha256']==sha(grid/'manifest.json')and rec['prior']['grid_summary_sha256']==sha(grid/'summary.json')
    xs=[t//8 for t in pending];ys=[t%8 for t in pending];xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys)
    covered=[8*i+j for i in range(xmin,xmax+1)for j in range(ymin,ymax+1)]
    rectangle=((xa+(xb-xa)*xmin/8,xa+(xb-xa)*(xmax+1)/8),(ya+(yb-ya)*ymin/8,ya+(yb-ya)*(ymax+1)/8))
    assert covered==rec['prior']['covered_tiles']==rec['additional_predicate']['covered_tiles']and len(covered)==48
    assert box(rec['center_box'])==box(rec['prior']['center_box'])==box(rec['additional_predicate']['center_rectangle'])==rectangle
    for key in('sources','additional_sources'):
        for name,h in rec.get(key,{}).items():assert sha(J.local_source(name))==h
    pos=list(positions);pos[14],pos[15]=rectangle;pos=tuple(pos);sca=scalar;ang=angles;delta={};deductions=printed=0
    def merged(delta):
        r=dict(diffs)
        for pair,ds in delta.items():r[pair]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(r[pair],ds))
        assert all(a<=b for ds in r.values()for a,b in ds);return r
    for ri,s in enumerate(rec['rounds']):
        assert s['round']==ri and box(s['angles_before'])==ang and box(s['positions_before'])==pos and box(s['scalar_before'])==sca and s['differences_before']==K.diffview(delta)
        base,bounds,early,prop,sc,df,guards=physical(pos,sca,ang,merged(delta));assert early is None;check(s,prop,sc,df,guards)
        assert s['absolute_variable_bounds']==list(map(str,bounds));rows,_=J.rows_for_record(s,base,sc,df,ang)
        newpos=[list(ab)for ab in prop];newsc=[list(ab)for ab in sc];newdf={p:[list(ab)for ab in ds]for p,ds in df.items()};used=set()
        for p in s['proposals']:
            upper=K.audit_bound(rows,bounds,p);sign=p['sign'];key=p['key'];assert sign in(-1,1)
            if p['kind']=='scalar':
                assert type(key)is int and 0<=key<54 and p['objective']==[[key,sign]];target=newpos[key]if key<18 else newsc[key-18]
            else:
                assert p['kind']=='difference';i,j,axis=key;assert 0<=i<j<9 and axis in(0,1)and p['objective']==[[2*j+axis,sign],[2*i+axis,-sign]];target=newdf[i,j][axis]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
            used.update(k for k,w in p['weights']);deductions+=1
        assert used=={x['index']for x in s['printed_rows']};printed+=len(used)
        pos=tuple(map(tuple,newpos));sca=tuple(map(tuple,newsc));delta={p:tuple(map(tuple,ds))for p,ds in newdf.items()}
        assert all(a<=b for a,b in pos+sca)and all(a<=b for ds in delta.values()for a,b in ds)
        ang=K.angles_from_scalar(ang,sca,s['physical_frame_inferences']);physical_scalar=K.analytic(ang)
        sca=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(sca,physical_scalar));assert all(a<=b for a,b in sca)
        assert box(s['angles_after'])==ang and box(s['positions_after'])==pos and box(s['scalar_after'])==sca and s['differences_after']==K.diffview(delta)
    assert deductions==145 and box(rec['final_angles'])==ang and box(rec['final_positions'])==pos and box(rec['final_scalar'])==sca and rec['final_differences']==K.diffview(delta)
    s=rec['final_test'];assert s['round']==6 and box(s['angles_before'])==ang and box(s['positions_before'])==pos and box(s['scalar_before'])==sca and s['differences_before']==K.diffview(delta)
    base,bounds,early,prop,sc,df,guards=physical(pos,sca,ang,merged(delta));assert early is None;check(s,prop,sc,df,guards)
    return {'status':'PASS_PARTIAL_FIXED_GRID_AND_CONDITIONAL_REMAINDER_STATE_OPEN','id':ident,'whole_original_parent_closed':False,'new_originals_closed':0,
        'all_64_closed_rectangles_mapped':True,'static_closed_tiles_checked':len(closed),'static_interval_terminals':early_count,'static_positive_terminals':len(reserves),
        'static_printed_rows':static_printed,'unresolved_static_tiles':pending,'unresolved_exception_tiles':exceptions,'complete_remainder_tiles':covered,'remainder_status':'OPEN','remainder_rounds':6,
        'remainder_deductions':deductions,'remainder_printed_rows':printed,'parent_sha256':sha(parent_path),'union_sha256':sha(union_path),'checker_sha256':sha(__file__)}
