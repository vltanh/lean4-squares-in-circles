# Independent source review of the accepted-center B runtime

The new immutable driver/runtime/adapter attachment passes this source
review. The separately completed 448-deduction weighted fixture and eleven
dispatch/storage controls are acknowledged and hash-bound; their arithmetic
and execution are not repeated in this review. No worker or proof input was
changed.

The driver differs from the previously reviewed atomic driver by exactly
one runtime import. Reversing that one change reproduces the old bytes.
Thus complete proxy/SAT/closed-angle covers, explicit engine selection,
incoming-round merging, old source checks, and atomic checkpoint behavior
are unchanged. The driver has no handler that could swallow an OSError.

The new Context is identical to the accepted external center Context after
removing its added startup source-verification call. The startup code pins
the new accepted-family binding and each contained source/review before
constructing the inherited Context. It does not recreate a missing source
under an old hash. Center supports append to the old row space and introduce
no variables or conditional hypotheses. Direction selection is an untrusted
numerical proposal. The independent decoder still checks the exact physical
support inequality `3600*s*s >= 8281*(a*a+b*b)` with nonnegative s and exactly
the two coordinates of one original center.

The exact adapter's row-rebuild function is AST-identical to the published
accepted adapter. It excludes only the center prefix from the inherited
decoder, directly checks each center literal, rejects row-index collisions,
and returns the unchanged independently propagated state and absolute
bounds. Its other changes require an explicit accepted cap-proof directory
and pin the new local family. The original registered-domain verifier is
unchanged, including its rejection of an unrelated relocated register path.

The local weighted fixture reattaches the unchanged accepted five-round
record to a freshly reconstructed local B580 root whose entire literal
initial state is equal. The one-node tree checker obtains its initial state
from that independent local root; the foreign parent filename inside the
retained record is not an arithmetic premise. The paired review script
checks the whole initial-state equality and unchanged record object. The
separate fresh report has one OPEN node, five rounds, 448 deductions, 1,032
premises and 78 center occurrences, and explicitly retains the entire
registered original. It grants no original exclusion.

The eleven recorded storage/dispatch controls exercise the actual callback
and explicit engine route while replacing only the numerical solves by
clearly labeled software fixtures. These synthetic rounds are not proof
records. The controls preserve previous completed rounds, report the
one-file atomicity boundary, and test ENOSPC propagation. The earlier
missing-index harness failure is retained separately; only its new harness
version supplies the ordinary closure index, with driver bytes unchanged.

No mathematical or domain-attachment issue was found. The paired JSON binds
the exact sources, confirms the stated AST/byte comparisons, and records
the already completed evidence at its actual partial scope.
