# Independent review of five B16a quarter attachments

The reviewed attachment is sound at its stated scope: five complete original
quarter domains, with no additional original-cell or mask credit. This is a
source and literal-domain review. It acknowledges the separately completed
fresh arithmetic report; it does not repeat that arithmetic.

The assembler preserves each published terminal record byte for byte as
`SOURCE_RECORD.json` and embeds the same JSON record object in a new one-node
tree. For each of I00, I01, I02, I03 and I30, the record's complete initial
state equals the independently reconstructed quarter document's final state.
The new tree's parent is that exact quarter document. The reviewed replay
script repeats these equalities before invoking the frozen partition-piece
checker with `require_complete=True`.

The frozen quarter adapter independently replays the whole-original bound
parent and the exact closed grid restriction. The partition-piece checker
requires preservation of the entire quarter domain. The lazy tree checker
then starts from the adapter's independently replayed parent state, checks
the node's complete initial state against it, and passes that state to the
frozen rational core. A terminal is accepted only when the core independently
returns exclusion and the node has no children. Final source rehashing remains
in force. Thus neither the discovery status nor a matching original ID alone
can substitute for a proof of the entire quarter.

I30's retained record mentions an unavailable historical zero-round parent.
That metadata stays in the unchanged record but supplies no premise to the
new attachment. Its saved round is checked from the complete, exactly equal
quarter state. No unavailable file is reconstructed from a remembered hash,
and no unstated intermediate bound is used. This direct reattachment is a
valid way to reuse a proof whose initial hypotheses have been independently
re-established.

All five source records, all five quarter-state identities, and their new
one-node manifests were rehashed and checked in this review. The separate
fresh arithmetic receipt reports complete exclusions of all five quarters:
I00 uses four terminal premises; I01/I02/I03 use the accepted center-interval
terminal; I30 checks one round with 181 deductions and 246 premises before
its empty proved pair-difference interval. The receipt explicitly gives no
whole-original result. This review introduces no row, terminal, state
inference or cover rule and changes no proof input or running worker.

The paired JSON receipt binds the exact reviewed source and data files.
