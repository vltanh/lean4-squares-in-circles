# Accepted center supports in a new immutable B runtime

The new driver is `resume_b_five_proxy_round_atomic_center_tree_v1.py`. Replacing
its one import of `b_accepted_center_disk_runtime_v1` with the previous
`b_four_complete_guards_runtime` import reproduces the reviewed 12ff1d2b driver
byte-for-byte. Its complete proxy/SAT/closed-angle covers, explicit engine
callback, merge logic, source rehashes, and atomic checkpoint writer are
unchanged. The currently running B16a process retains the old source.

The new runtime preserves the reviewed external center Context implementation.
The only changes outside that implementation are the explicit accepted-family
location, startup source checks, and local source binding. The center Context
adds 64 rational seed directions for each of nine original centers and proposes
further radial directions through the same append-only solver row interface.
It adds no variable and changes no physical predicate, interval deduction,
terminal, or branching rule. The rational producer is unchanged; floating
direction selection and violation tests remain untrusted discovery choices.

The source binding is a new file with its own identity. It copies the accepted
mathematical sources, physical/weighted-use reviews, and exact gate evidence
from the published packet. It does not recreate any missing historical binding
or install a different file under an old expected hash. All 31 inherited runtime
bindings and all 42 resulting runtime bindings are present and hash-checked.

The independent local checker likewise preserves the published row dispatch.
It requires an explicit accepted cap-proof directory and checks the new local
accepted-family binding. Every center literal still passes the independent
two-column squared-support decoder; all ordinary rows and exact arithmetic
remain with the inherited checker. It imports no numerical runtime.

## Actual local caller attachment

The external fixture's parent refers to a foreign relocated register filename.
A direct replay through the local packet correctly rejected that filename at
the unchanged registered-root identity check. That check was not weakened.

The new one-node fixture instead uses our freshly reconstructed whole B580
registered root, whose state is literally identical to the saved record's
initial state. Its node contains the unchanged accepted five-round record
object; the byte-exact raw record remains separately bound. The old parent
filename inside that object is historical metadata and is not used as a
premise. The unchanged lazy checker obtains the initial state from the freshly
replayed local registered root, and the unchanged arithmetic core checks exact
initial equality and every following round.

This new local caller passed fresh exact replay: one OPEN node, five rounds,
448 deductions, 1,032 checked premise rows, and 78 center-row occurrences, with
the entire registered original retained. The original foreign weighted-use
gate is retained separately. No local or foreign original has been excluded by
this fixture, and no missing path or source hash has been fabricated.

## Dispatch and checkpoint controls

The driver smoke suite checks the unchanged atomic JSON bytes, donor hardlink
preservation, file-fsync and directory-fsync ENOSPC behavior, and source-pin
rejection before publication. It also constructs the actual new B462 Context
without solving and independently checks its 576 appended seed rows.

The callback control executes the actual driver's nested merge, checkpoint,
and adaptive-search functions with the actual explicit-engine search loop and
selector. It uses a retained physical B16a state and its saved LP point. Only
the phase and bound solves are replaced with explicitly labeled software
fixtures; those artificial rounds are not certificates and never enter a proof
tree. It checks the engine identity, the first completed-round angle callback,
retention of preceding rounds, and propagation of ENOSPC through the actual
callback/search path while preserving the preceding destination.

The first callback harness omitted the enclosing `index` variable and failed
with NameError after reaching the actual callback. Its source and failure
receipt are preserved. A new v2 harness supplies that existing closure value;
no driver or runtime source changed in response. The final freeze identifies
the observed results and their exact source hashes.

No optimization search was launched by these preparations or controls. Future
use requires a separately authorized lane and the normal complete ancestry,
exact full-tree, physical attachment, terminal-table, and portable gates. The
already running B16a source and the external B580, Bf14, and B7c workers remain
unchanged.
