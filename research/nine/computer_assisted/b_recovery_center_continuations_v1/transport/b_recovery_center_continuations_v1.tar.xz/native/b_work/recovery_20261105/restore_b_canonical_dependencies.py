#!/usr/bin/env python3
"""Restore exact B sources and published dependencies, never overwrite drift."""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
from pathlib import Path
import hashlib
import json
import os
import tempfile

BASE = Path('/workspace/scratch/f9f48fcfb253')
OWN = BASE / 'b_work'
HERE = Path(__file__).resolve().parent
SOURCE = BASE / 'd_work/reset_sources_d989c83'
SOURCE_MAP_SHA = '87fa02855665f17f0375788b8d8a0f9372929fc34b695f01beb65d2d51045b05'
B340 = HERE / 'extracted_b340/unpacked/b340_complete_original_package'
PRIOR = HERE / 'extracted_i32/unpacked/b16a_I32_complete_H_checkpoint'
POLICY = HERE / 'extracted_policy/unpacked/b_angle_policy_checkpoint'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def main():
    assert sha(SOURCE / 'PATHS.json') == SOURCE_MAP_SHA
    assert sha(B340 / 'RELEASE_MANIFEST.json') == '56c5d87c3dfd13b156cc7ce2c49ff6b2fdaccbf64bde4db46f544d59b49440b9'
    assert sha(POLICY / 'RELEASE_MANIFEST.json') == 'd69755253cec8fb6ec6809907d220d80dafcfc4768355baea45f465cbd7df9e6'
    assert sha(PRIOR / 'ARCHIVE_INPUTS.json') == '13f64ff3d6accebd81e30195c7074ebef7f713a2988ff317ad115a96929973a5'
    plan = {}
    def add(destination, source, digest, authority):
        destination = Path(destination)
        source = Path(source)
        assert destination.is_absolute() and destination.is_relative_to(OWN)
        assert not destination.is_symlink()
        assert sha(source) == digest
        name = str(destination)
        if name in plan:
            assert plan[name]['sha256'] == digest, ('conflicting exact sources', name)
            plan[name]['authorities'].append(authority)
            return
        plan[name] = dict(source=str(source), sha256=digest, bytes=source.stat().st_size, authorities=[authority])
    for entry in json.loads((SOURCE / 'PATHS.json').read_text())['files']:
        path = Path(entry['path'])
        if path.is_relative_to(OWN):
            source = SOURCE / 'sources' / entry['sha256']
            assert source.stat().st_size == entry['bytes']
            add(path, source, entry['sha256'], 'committed_reset_source_archive')
    prior_inventory = json.loads((PRIOR / 'ARCHIVE_INPUTS.json').read_text())['files']
    for name, digest in prior_inventory.items():
        add(OWN / 'b16a_I32_complete_H_checkpoint' / name, PRIOR / name, digest, 'published_I32_archive_inventory')
    add(OWN / 'b16a_I32_complete_H_checkpoint/ARCHIVE_INPUTS.json', PRIOR / 'ARCHIVE_INPUTS.json', sha(PRIOR / 'ARCHIVE_INPUTS.json'), 'published_I32_archive_inventory_self_pin')
    for packet, roots in [(B340, dict(packet=B340, prior=PRIOR)), (POLICY, dict(delta=POLICY, b340=B340, prior=PRIOR))]:
        bindings = json.loads((packet / 'BINDINGS.json').read_text())
        for old, entry in bindings.items():
            dest = Path(old)
            if not dest.is_relative_to(OWN):
                continue
            if packet == B340 and entry['root'] != 'prior' and not entry['path'].startswith('code/'):
                continue
            add(dest, roots[entry['root']] / entry['path'], entry['sha256'], packet.name + '_published_alias')
    # Preflight the entire union before publishing even one recovered path.
    for name, entry in plan.items():
        path = Path(name)
        if os.path.lexists(path):
            assert path.is_file() and not path.is_symlink() and sha(path) == entry['sha256'], ('existing drift', name)
    plan_file = HERE / 'B_CANONICAL_RESTORATION_PLAN.json'
    write_json(plan_file, dict(schema='exact_B_source_and_published_dependency_restoration_v1', source_map_sha256=SOURCE_MAP_SHA, files=plan))
    stage = HERE / 'canonical_stage'
    stage.mkdir()
    installed = []
    retained = []
    for name, entry in plan.items():
        path = Path(name)
        if path.exists():
            assert sha(path) == entry['sha256']
            retained.append(name)
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, tmp_name = tempfile.mkstemp(prefix='verified-', dir=stage)
        temporary = Path(tmp_name)
        with os.fdopen(descriptor, 'wb') as output, Path(entry['source']).open('rb') as source:
            for chunk in iter(lambda: source.read(1 << 20), b''):
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        assert sha(temporary) == entry['sha256']
        os.chmod(temporary, 0o644)
        try:
            os.link(temporary, path)
            installed.append(name)
        except FileExistsError:
            assert path.is_file() and not path.is_symlink() and sha(path) == entry['sha256']
            retained.append(name)
        temporary.unlink()
    for name, entry in plan.items():
        assert sha(name) == entry['sha256'] and sha(entry['source']) == entry['sha256']
    result = dict(status='PASS_EXACT_B_CANONICAL_DEPENDENCIES_RESTORED', file_count=len(plan), newly_installed=len(installed), existing_identical_retained=len(retained), installed=installed, retained=retained, plan_sha256=sha(plan_file), source_sha256=sha(Path(__file__)), all_sources_and_destinations_rehashed=True, existing_inputs_overwritten=False, mathematical_replay_performed=False, solver_started=False, lost_numerical_suffix_reconstructed=False)
    write_json(HERE / 'B_CANONICAL_RESTORATION_RECEIPT.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'file_count', 'newly_installed', 'existing_identical_retained', 'plan_sha256')}), flush=True)

if __name__ == '__main__':
    main()
