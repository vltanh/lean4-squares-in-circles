# Complete OPEN covers reconstructed from published B prefixes

This attachment concerns the two newly assembled, exact-replayed continuation
seeds in `reassembled_B16a_published_prefix_v1` and
`reassembled_B7c_published_prefix_v1`. It grants no original-cell or mask closure.

The published policy packet retained an exact weighted ancestor prefix and a
complete two-child closed-angle exclusion at its final node. It did not retain
the full later numerical search trees. The new assembler preserves the retained
weighted records and reconstructs every alternative at each prefix step using
the existing independent child constructors. Every unavailable off-path
alternative receives a zero-round OPEN identity record. The two retained final
angle children remain excluded only after their full exact replay. Thus no
unavailable search suffix, omitted sibling, or remembered hash supplies proof
credit.

For a proxy step, both Cartesian axes and both signs give all four alternatives.
For an owned square separation step, both original owners, both axes, and both
signs give all eight alternatives. An angle step uses the two closed intervals
ending and beginning at the same rational cut. The unchanged independent tree
checker checks every child state against its parent, every retained bound
deduction and terminal, and the complete union. All shared faces are retained.

The B16a seed covers exactly the merged original I21/I22 rectangle, with x_I in
[-163627/2097152, 2457813/4194304] and y_I in [-91/120, 91/120]. Its certified
stronger whole-parent bounds are inherited before this restriction. The exact
parent attachment checks the original partition and the complete implication
chain. This seed is not a proof or cover of the other fourteen I quarters.
Its 45 nodes contain seven complete proxy unions, eight complete angle unions,
two excluded leaves, and twenty-eight OPEN leaves.

The B7c seed starts at the complete F/H union hull of the unchanged registered
original. The parent proof replays all eight alternatives before projecting
only common original-coordinate and frame bounds back to the unsplit parent.
No selected F/H owner or auxiliary product is inherited across that union.
The new 37-node cover therefore retains the whole registered B7c original. It
has five proxy unions, four angle unions, one owned-separation union, two excluded
leaves, and twenty-five OPEN leaves.

Both exact replays preserve all nine physical originals, their 36 corners and
36 pairs, the five original cones, the actual required edges, the strict CD
predicate, and the unchanged original ID and path. The numerical selector and
its early-angle policy only choose the next complete cover. The launch driver
uses the reviewed one-file atomic JSON writer; it does not claim a multi-file
node-and-manifest transaction. A future original closure still requires a full
fresh exact replay, physical attachment, literal terminal table, and portable
packet verification.

The companion launch freezes bind the assembler, published prefix inputs,
new node files, independent exact reports, all recorded exact dependencies,
the numerical runtime, and the atomic driver. The unavailable later trees have
not been reconstructed and are not credited.
