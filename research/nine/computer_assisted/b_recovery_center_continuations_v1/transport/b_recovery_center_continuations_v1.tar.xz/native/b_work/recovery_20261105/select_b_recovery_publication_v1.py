#!/usr/bin/env python3
"""Select immutable B recovery/gate files; no copy, Git operation, or live tree."""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
B=ROOT/'b_work'
R=B/'recovery_20261105'

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as stream:
        for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()

def main():
    out=R/'publication_selection_v1';out.mkdir(exist_ok=False)
    selected={}
    def add(path,category):
        path=Path(path).resolve()
        assert path.is_file() and path.is_relative_to(ROOT)
        relative=path.relative_to(ROOT)
        assert '.runs'not in relative.parts and '__pycache__'not in relative.parts
        assert not path.name.endswith(('.log','.tmp')) and '.atomic-'not in path.name
        assert not any('fixtures'in part for part in relative.parts)
        entry=dict(source=str(path),member='native/'+str(relative),sha256=sha(path),
                   bytes=path.stat().st_size,category=category)
        if entry['member']in selected:assert selected[entry['member']]['sha256']==entry['sha256']
        else:selected[entry['member']]=entry
    for name in [
        'reconstruct_b_published_prefix_frontier_v1.py',
        'prepare_b16a_missing_i_quarters.py',
        'assemble_b16a_five_published_quarter_records_v1.py',
        'replay_b16a_five_reattached_quarters_v1.py',
        'replay_b16a_merged_anchor_only_v1.py',
        'audit_b16a_fourteen_plus_open_availability_v1.py',
        'prepare_center_local_weighted_fixture_v1.py',
        'b_accepted_center_disk_runtime_v1.py',
        'resume_b_five_proxy_round_atomic_center_tree_v1.py',
        'verify_b_accepted_center_disk_tree_v1.py',
        'resume_b_five_proxy_round_atomic_tree_v1.py',
        'atomic_json_checkpoint_snapshot.py']:
        add(B/name,'source')
    for name in [
        'B_PUBLISHED_PREFIX_COMPLETE_OPEN_COVERS_HAND_ATTACHMENT.md',
        'B16A_RECOVERED_FOURTEEN_PLUS_OPEN.md',
        'B16A_FIVE_REATTACHED_QUARTERS_HAND_ATTACHMENT.md',
        'B16A_FIVE_REATTACHED_QUARTERS_BINDING.json',
        'B16A_FIVE_REATTACHED_QUARTERS_FRESH_EXACT_REPLAY.json',
        'B16A_MERGED_ANCHOR_DOMAIN_PRESERVATION_FRESH_REPLAY.json',
        'B16A_FOURTEEN_PLUS_OPEN_COMPLETE_EVIDENCE_INVENTORY.json',
        'B16A_MERGED_RECOVERED_ATOMIC_LAUNCH_FREEZE.json',
        'REASSEMBLED_B16A_COMPLETE_OPEN_COVER_EXACT_REPLAY.json',
        'REASSEMBLED_B7C_COMPLETE_OPEN_COVER_EXACT_REPLAY.json',
        'B7C_RECOVERED_COMPLETE_OPEN_COVER_FREEZE.json',
        'B_ATOMIC_ACCEPTED_CENTER_RUNTIME_SOURCE_FREEZE.json',
        'B_ATOMIC_ACCEPTED_CENTER_RUNTIME_ATTACHMENT.md',
        'B_ACCEPTED_CENTER_RUNTIME_FROM_PUBLISHED.diff',
        'B_ATOMIC_CENTER_DRIVER_FROM_12FF.diff',
        'B_ACCEPTED_CENTER_EXACT_ADAPTER_FROM_PUBLISHED.diff',
        'B_ACCEPTED_CENTER_LOCAL_CALLER_WEIGHTED_REPLAY.json',
        'B_CENTER_LOCAL_CALLER_FOREIGN_PATH_REJECTION_RECEIPT.json',
        'B_CENTER_DRIVER_SMOKE_V1_FAILURE_RECEIPT.json',
        'B_ATOMIC_CENTER_DRIVER_DISPATCH_CONTROLS_V2.json',
        'check_b_atomic_center_driver_dispatch_v1.py',
        'check_b_atomic_center_driver_dispatch_v2.py',
        'B_ATOMIC_DRIVER_DISPATCH_CONTROLS.json',
        'B_ATOMIC_DRIVER_FROM_PUBLISHED.diff',
        'check_b_atomic_driver_dispatch_v1.py',
        'B_PUBLISHED_ARCHIVE_RECOVERY_SUMMARY_V2.json',
        'B_CANONICAL_RESTORATION_PLAN.json',
        'B_CANONICAL_RESTORATION_RECEIPT.json',
        'restore_b_archives_v2.py',
        'verify_and_finish_b_recovery_v2.py',
        'restore_b_canonical_dependencies.py']:
        add(R/name,'source'if name.endswith('.py')else'evidence_or_binding')
    add(Path(__file__),'source')
    for name in [
        'reassembled_B16a_published_prefix_v1',
        'reassembled_B7c_published_prefix_v1',
        'accepted_center_local_caller_v1']:
        folder=R/name
        manifest=json.loads((folder/'manifest.json').read_text())
        assert manifest['completed']is True
        add(folder/'manifest.json','immutable_new_cover')
        if(folder/'ASSEMBLY.json').exists():add(folder/'ASSEMBLY.json','immutable_new_cover')
        for entry in manifest['nodes']:
            path=folder/entry['file'];assert sha(path)==entry['sha256']
            add(path,'immutable_new_cover')
    folder=R/'five_reattached_original_quarters_v1'
    add(folder/'ASSEMBLY.json','immutable_new_cover')
    for name in('I00','I01','I02','I03','I30'):
        for item in('manifest.json','node_0000.json','SOURCE_RECORD.json'):
            add(folder/name/item,'immutable_new_cover')
    for path in sorted((B/'b16a_missing_eight_i_domains').glob('*.json')):add(path,'small_exact_domain_copy')
    add(R/'registered_B_initial_states/negative-580db3624cf4c2e2.json','small_exact_domain_copy')
    for path in sorted((B/'accepted_center_disk_v1').iterdir()):
        if path.is_file():add(path,'small_accepted_family_copy')
    for relative in [
        'd_work/B16A_MERGED_ATOMIC_LAUNCH_ROOT_REVIEW.json',
        'ac_work/tree/B_ATOMIC_DRIVER_INDEPENDENT_REVIEW.json',
        'ac_work/tree/B_ATOMIC_DRIVER_INDEPENDENT_REVIEW.md',
        'ac_work/tree/B16A_FIVE_QUARTER_REATTACHMENT_INDEPENDENT_REVIEW.json',
        'ac_work/tree/B16A_FIVE_QUARTER_REATTACHMENT_INDEPENDENT_REVIEW.md']:
        add(ROOT/relative,'independent_or_root_review')
    recovery=json.loads((R/'B_PUBLISHED_ARCHIVE_RECOVERY_SUMMARY_V2.json').read_text())
    archives={label:value for label,value in recovery['archives'].items()if label!='old_b_open'}
    for entry in archives.values():add(R/entry['receipt'],'recovered_archive_byte_audit')
    git_receipt=R/'committed_b/GIT_RESTORATION_RECEIPT.json';add(git_receipt,'git_source_identity')
    git=json.loads(git_receipt.read_text())
    source_metadata=ROOT/'d_work/reset_sources_d989c83/PATHS.json'
    required=dict(
        status='EXISTING_PUBLISHED_BULK_ANCESTRY_REFERENCED_NOT_COPIED',
        committed_B_recovery_commit=recovery['commit'],archives=archives,
        committed_blob_inventory=dict(path=str(git_receipt),sha256=sha(git_receipt)),
        reset_source_archive=dict(commit='d989c83',repository_path='research/nine/recovered_source/2026_11_04_reset/sources.tar.xz',
            sha256='157bbd24c778cef8f44e0e357ac47322bbd527aac0dbc6c751b66d5b0eb7546d',
            paths_sha256=sha(source_metadata)),
        accepted_center_publication=dict(commit='dbe204881898cb41ec19fdd4696f7898d8d91d53',
            repository_path='research/nine/computer_assisted/universal_center_disk_weighted_gate_v1',
            publication_manifest_sha256='e2f0ddcd2a4930725afe53d076f214e10b6cf0ad889f7851fa29dc2c9c279dee'),
        current_definition_comparison_register=dict(commit='dbe204881898cb41ec19fdd4696f7898d8d91d53',
            repository_path='research/nine/gates/A2_00100_FIXED_FRONTIER.json',
            sha256='3dfaff7a880ab358930fb0ea835a1fdbe9959711f3c08ac47ee9817e7c693dde'),
        standalone_portable_proof=False,new_original_cells=0,new_masks=0)
    req=out/'REQUIRED_PUBLISHED_ANCESTRY.json';req.write_text(json.dumps(required,indent=2)+'\n');add(req,'published_ancestry_reference')
    # Every selected byte and every new source freeze remains unchanged.
    for name in ['B16A_FIVE_REATTACHED_QUARTERS_BINDING.json','B_ATOMIC_ACCEPTED_CENTER_RUNTIME_SOURCE_FREEZE.json']:
        freeze=json.loads((R/name).read_text())
        for path,digest in freeze['files'].items():assert sha(path)==digest
    for entry in selected.values():assert sha(entry['source'])==entry['sha256']
    files=[selected[k]for k in sorted(selected)]
    categories=Counter(e['category']for e in files)
    result=dict(schema='immutable_B_recovery_and_accepted_center_publication_selection_v1',
        status='READY_FOR_ROOT_REVIEW_NO_GIT_OR_DOC_MUTATION',files=files,file_count=len(files),
        bytes=sum(e['bytes']for e in files),categories=dict(categories),
        required_published_ancestry=dict(path=str(req),sha256=sha(req)),
        live_tree_or_log_files=0,proof_ancestors_copied_in_bulk=False,
        exact_new_B16_cover_nodes=45,exact_new_B7_cover_nodes=37,
        exact_new_quarter_wrapper_nodes=5,exact_new_center_caller_nodes=1,
        closed_B16_quarters_available=14,open_B16_quarters=2,
        standalone_portable_proof=False,new_original_cells=0,new_masks=0)
    p=out/'PUBLICATION_FILE_SELECTION.json';p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],path=str(p),sha256=sha(p),files=len(files),bytes=result['bytes'],categories=dict(categories))),flush=True)

if __name__=='__main__':main()
