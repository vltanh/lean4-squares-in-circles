#!/usr/bin/env python3
"""Read-only archive/member audit, plus extraction of one committed old packet.

This proves recovered byte identity only. It runs no mathematical checker.
"""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
COMMITTED = HERE / 'committed_b'
OUTER = COMMITTED / 'research/nine/computer_assisted'
RECIPES = {
    'b340': 'a2_00100_b340_complete_original/ARCHIVE_READY.json',
    'policy': 'a2_00100_b_angle_policy_checkpoint_v1/ARCHIVE_READY.json',
    'i32': 'a2_00100_b16a_I32_complete_H_manifest.json',
    'i10': 'a2_00100_b16a_I10_complete_H_manifest.json',
    'i11': 'a2_00100_b16a_I11_complete_H_manifest.json',
    'three_i': 'a2_00100_b16a_three_I_complete_H_manifest.json',
    'complementary': 'a2_00100_b16a_three_complementary_quarters_v1/ARCHIVE_PARTS.json',
    'availability': 'a2_00100_b16a_replayable_cover_availability_v1/ARCHIVE_READY.json',
}

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def safe(name):
    p = PurePosixPath(name)
    assert p.parts and not p.is_absolute() and '..' not in p.parts
    assert str(p) == name.rstrip('/')
    return str(p)

def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def compare_archive(archive_path, unpacked):
    seen = {}
    with tarfile.open(archive_path, 'r:xz') as archive:
        for member in archive:
            name = safe(member.name)
            if member.isdir():
                assert (unpacked / name).is_dir()
                continue
            assert member.isfile() or member.islnk()
            assert name not in seen
            if member.islnk():
                safe(member.linkname)
            path = unpacked / name
            assert path.is_file() and not path.is_symlink()
            h = hashlib.sha256()
            length = 0
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1 << 20), b''):
                    h.update(block)
                    length += len(block)
            assert path.stat().st_size == length
            assert digest(path) == h.hexdigest()
            seen[name] = {'bytes': length, 'sha256': h.hexdigest(), 'archive_hardlink': member.islnk()}
    actual = {str(p.relative_to(unpacked)) for p in unpacked.rglob('*') if p.is_file()}
    assert set(seen) <= actual
    return seen, sorted(actual - set(seen))

def check_inventory(packet, path, expected_sha, member_map):
    assert digest(path) == expected_sha
    doc = json.loads(path.read_text())
    files = doc['files']
    actual = {str(p.relative_to(packet)) for p in packet.rglob('*') if p.is_file()}
    assert set(files) | {str(path.relative_to(packet))} <= actual
    for name, h in files.items():
        safe(name)
        assert digest(packet / name) == h
    return {'file': str(path.relative_to(packet)), 'sha256': expected_sha, 'listed_files_verified': len(files), 'all_listed_inventory_files_verified': True}

def main():
    git_path = COMMITTED / 'GIT_RESTORATION_RECEIPT.json'
    assert digest(git_path) == 'b45bdd8d0dbd789504e44e3f31714b0b9caeac280a46965782f8b0b64918c9be'
    git = json.loads(git_path.read_text())
    summaries = {}
    for key, relative in RECIPES.items():
        metadata = OUTER / relative
        assert digest(metadata) == git['files'][str(metadata.relative_to(COMMITTED))]['sha256']
        spec = json.loads(metadata.read_text())
        target = HERE / ('extracted_' + key)
        archive = target / Path(spec['archive']).name
        assert archive.stat().st_size == spec['archive_bytes'] and digest(archive) == spec['archive_sha256']
        members, extra = compare_archive(archive, target / 'unpacked')
        roots = {PurePosixPath(name).parts[0] for name in members}
        assert len(roots) == 1
        packet = target / 'unpacked' / next(iter(roots))
        inventories = []
        if 'release_manifest_sha256' in spec:
            inventories.append(check_inventory(packet, packet / 'RELEASE_MANIFEST.json', spec['release_manifest_sha256'], members))
        if 'archive_inventory_sha256' in spec:
            paths = [p for p in packet.glob('*.json') if digest(p) == spec['archive_inventory_sha256']]
            assert len(paths) == 1
            inventories.append(check_inventory(packet, paths[0], spec['archive_inventory_sha256'], members))
        if 'member_manifest_sha256' in spec:
            path = packet / 'MEMBER_MANIFEST.json'
            assert digest(path) == spec['member_manifest_sha256']
            doc = json.loads(path.read_text())
            assert set(members) == set(doc['members']) | {packet.name + '/MEMBER_MANIFEST.json'}
            for name, item in doc['members'].items():
                assert members[name]['sha256'] == item['sha256'] and members[name]['bytes'] == item['bytes']
            inventories.append({'file': 'MEMBER_MANIFEST.json', 'sha256': digest(path), 'listed_files_verified': len(doc['members']), 'all_listed_inventory_files_verified': True})
        count = spec.get('all_archive_members_verified', spec.get('all_regular_members_verified', spec.get('archive_members', spec.get('members'))))
        if isinstance(count, int):
            assert len(members) == count
        result = {'status': 'PASS_ARCHIVE_AND_ALL_EXTRACTED_MEMBERS_MATCH', 'packet': str(packet), 'archive_metadata': relative, 'archive_metadata_sha256': digest(metadata), 'archive_sha256': digest(archive), 'member_count': len(members), 'member_bytes': sum(v['bytes'] for v in members.values()), 'unbound_extra_paths_retained': extra, 'inventory_checks': inventories, 'members': members, 'arithmetic_replayed': False, 'lost_uncommitted_suffix_reconstructed': False, 'new_proof_credit': 0}
        receipt = target / 'V2_READ_ONLY_ARCHIVE_MEMBER_VERIFICATION.json'
        write_json(receipt, result)
        summaries[key] = {k: result[k] for k in ('packet', 'archive_sha256', 'member_count', 'member_bytes')}
        summaries[key].update(receipt=str(receipt.relative_to(HERE)), receipt_sha256=digest(receipt))
        print(key, len(members), 'all exact archive bytes and inventories PASS', flush=True)
    # The older whole-B packet has a committed Git blob and an internal manifest,
    # but no separate publication-level compressed hash. Record that distinction.
    archive = OUTER / 'a2_00100_b_whole_parent_open_evidence.tar.xz'
    pin = git['files'][str(archive.relative_to(COMMITTED))]
    assert digest(archive) == pin['sha256'] and archive.stat().st_size == pin['bytes']
    target = HERE / 'extracted_old_b_open'
    assert not target.exists()
    unpacked = target / 'unpacked'
    unpacked.mkdir(parents=True)
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar:
            name = safe(member.name)
            path = unpacked / name
            if member.isdir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            assert member.isfile() or member.islnk()
            if member.islnk():
                safe(member.linkname)
            path.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as stream, path.open('xb') as dest:
                shutil.copyfileobj(stream, dest, 1 << 20)
            os.chmod(path, member.mode & 0o777)
    members, extra = compare_archive(archive, unpacked)
    packet = unpacked / 'portable_b_open'
    manifest = json.loads((packet / 'SHA256_MANIFEST.json').read_text())
    files = manifest.get('files', manifest)
    assert isinstance(files, dict)
    for name, h in files.items():
        safe(name)
        assert digest(packet / name) == h
    result = {'status': 'PASS_COMMITTED_OLD_B_PACKET_AND_INTERNAL_MANIFEST_RECOVERED', 'git_archive_pin': pin, 'packet': str(packet), 'member_count': len(members), 'unbound_extra_paths_retained': extra, 'internal_manifest_sha256': digest(packet / 'SHA256_MANIFEST.json'), 'internal_manifest_files_checked': len(files), 'members': members, 'arithmetic_replayed': False, 'lost_uncommitted_suffix_reconstructed': False, 'new_proof_credit': 0}
    receipt = target / 'V2_READ_ONLY_ARCHIVE_MEMBER_VERIFICATION.json'
    write_json(receipt, result)
    summaries['old_b_open'] = {'packet': str(packet), 'archive_sha256': pin['sha256'], 'member_count': len(members), 'receipt': str(receipt.relative_to(HERE)), 'receipt_sha256': digest(receipt)}
    summary = {'status': 'PASS_NINE_GIT_BOUND_B_ARCHIVES_RECOVERED', 'commit': git['commit'], 'archives': summaries, 'all_member_count': sum(x['member_count'] for x in summaries.values()), 'source_sha256': digest(Path(__file__)), 'arithmetic_replayed': False, 'new_original_cells': 0, 'new_masks': 0, 'lost_uncommitted_suffix_reconstructed': False}
    write_json(HERE / 'B_PUBLISHED_ARCHIVE_RECOVERY_SUMMARY_V2.json', summary)
    print(json.dumps({k: summary[k] for k in ('status', 'all_member_count', 'source_sha256')}), flush=True)

if __name__ == '__main__':
    main()
