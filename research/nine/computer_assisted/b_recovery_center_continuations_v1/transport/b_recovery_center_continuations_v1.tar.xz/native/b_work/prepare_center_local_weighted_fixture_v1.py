#!/usr/bin/env python3
"""Reattach the unchanged accepted center fixture to the identical local root."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json

HERE=Path(__file__).resolve().parent
RECOVERY=HERE/'recovery_20261105'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    if not __debug__:
        raise RuntimeError('Exact assertions must be enabled')
    source=RECOVERY/'reviewed_external_center_v1/B580_CENTER_FIRST_WEIGHTED_USE.json'
    root=RECOVERY/'registered_B_initial_states/negative-580db3624cf4c2e2.json'
    assert sha(source)=='95b79efadc22737b852d813b5d8d2fcd3a73fdd89cb1e433d594e5e21a703a78'
    assert sha(root)=='520cad33f8a70df7e56770667f0be3c18ab9986d3797d7027098ebf8f6926004'
    record=json.loads(source.read_text());initial=json.loads(root.read_text())
    assert initial['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'
    assert initial['schema']=='B_registered_original_initial_state_v1'
    assert record['initial']==initial['final']
    assert record['status']=='OPEN' and len(record['rounds'])==5
    out=RECOVERY/'accepted_center_local_caller_v1';out.mkdir(exist_ok=False)
    node=dict(index=0,parent=None,depth=0,choice=None,initial=deepcopy(record['initial']),
        status='OPEN',children=[],record=deepcopy(record))
    (out/'node_0000.json').write_text(json.dumps(node,indent=2)+'\n')
    files={str(p):sha(p)for p in (source,root,Path(__file__).resolve(),HERE/'verify_b_accepted_center_disk_tree_v1.py',HERE/'accepted_center_disk_v1/BINDING.json')}
    manifest=dict(schema='B_proxy_first_complete_physical_tree_discovery_v1',
        parent=dict(path=str(root),sha256=sha(root)),sources=files,accepted_geometric_sources={},
        completed=True,status='OPEN',original_cells_closed=0,masks_closed=0,
        nodes=[dict(index=0,file='node_0000.json',sha256=sha(out/'node_0000.json'),status='OPEN',depth=0)],
        attachment=dict(kind='UNCHANGED_ACCEPTED_WEIGHTED_RECORD_ON_IDENTICAL_LOCAL_REGISTERED_ROOT',
            exact_record_initial_equals_local_root_final=True,source_record_sha256=sha(source),
            old_parent_filename_used_as_proof=False,no_new_numerical_search=True))
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(sha(out/'manifest.json'),flush=True)

if __name__=='__main__':
    main()
