#!/usr/bin/env python3
"""Fresh unchanged complete-piece replay of five explicit quarter attachments."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time
import verify_b16a_partition_piece as PIECE

HERE = Path(__file__).resolve().parent
FROZEN = {
    'verify_b_original_i_quarters.py': '8bf9de12bd25dc5dd1aef7e68d2362261a3af8d8f27a641cad32dd13f0329f1e',
    'verify_b16a_partition_piece.py': '8579f10fadf706d72ba836bc51023127770e04de24ac17a88549990e90f412c1',
    'independent_b_lazy_tree_replay.py': 'e4f2f78b0c405a2d7dcff0b9e23d908774f159ed7eaef235c20ff88d76d48c78',
    'independent_physical_sat_replay.py': '1d069c90f289dce136e41afeb5d564ec7016ac06f58eeb733ca7552801b6fafc',
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    if not __debug__:
        raise RuntimeError('Exact assertions must be enabled')
    parser = argparse.ArgumentParser()
    parser.add_argument('assembly', type=Path)
    parser.add_argument('report', type=Path)
    parser.add_argument('--packet', type=Path, default=HERE / 'b16a_I32_complete_H_checkpoint')
    parser.add_argument('--cap-proof-dir', type=Path, required=True)
    args = parser.parse_args()
    start = time.monotonic()
    assert not args.report.exists()
    assembly = json.loads(args.assembly.read_text())
    assert assembly['schema'] == 'B16a_five_published_record_exact_quarter_attachments_v1'
    assert assembly['original_id'] == PIECE.Q.ORIGINAL_ID
    assert {e['label'] for e in assembly['pieces']} == {'I00', 'I01', 'I02', 'I03', 'I30'}
    assert len(assembly['pieces']) == 5
    adapter = PIECE.Adapter(args.packet, args.cap_proof_dir)
    adapter.retain(__file__)
    adapter.retain(args.assembly)
    for name, digest in FROZEN.items():
        adapter.retain(HERE / name, digest)
    for path, digest in assembly['inputs'].items():
        adapter.retain(path, digest)
    results = []
    for entry in assembly['pieces']:
        domain = adapter.retain(entry['domain']['path'], entry['domain']['sha256'])
        proof = adapter.retain(entry['proof']['path'], entry['proof']['sha256'])
        source = adapter.retain(entry['original_published_record']['path'], entry['original_published_record']['sha256'])
        manifest = json.loads(proof.read_text())
        assert len(manifest['nodes']) == 1
        node = json.loads((proof.parent / manifest['nodes'][0]['file']).read_text())
        assert node['record'] == json.loads(source.read_text())
        assert node['record']['initial'] == json.loads(domain.read_text())['final']
        report = PIECE.replay_piece(domain, proof, 'tree', adapter, require_complete=True)
        assert report['covered_original_I_tiles'] == entry['tiles']
        results.append(dict(label=entry['label'], report=report))
        print('FRESH_REATTACHED_QUARTER_PASS', entry['label'], flush=True)
    report = PIECE.finalize(dict(status='PASS_FIVE_COMPLETE_ORIGINAL_I_QUARTERS_FROM_UNCHANGED_PUBLISHED_RECORDS',
        original_id=PIECE.Q.ORIGINAL_ID, complete_quarters=[e['report']['covered_original_I_tiles'][0] for e in results],
        pieces=results, exact_literal_initial_identity=True, unchanged_original_record_objects=True,
        unavailable_zero_round_parent_used=False, lost_search_suffix_recovered=False,
        numerical_discovery_fields_used=False, whole_original_proved=False,
        new_original_cells=0, new_masks=0), adapter)
    report['seconds'] = time.monotonic() - start
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy'))
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(report['status'], report['seconds'], flush=True)

if __name__ == '__main__':
    main()
