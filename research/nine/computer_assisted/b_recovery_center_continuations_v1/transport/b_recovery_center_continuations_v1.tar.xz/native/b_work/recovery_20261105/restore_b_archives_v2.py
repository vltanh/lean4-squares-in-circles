#!/usr/bin/env python3
"""Recover committed B archive bytes into new directories; no proof replay."""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile
import time

HERE = Path(__file__).resolve().parent
COMMITTED = HERE / 'committed_b'
OUTER = COMMITTED / 'research/nine/computer_assisted'
GIT_RECEIPT_SHA = 'b45bdd8d0dbd789504e44e3f31714b0b9caeac280a46965782f8b0b64918c9be'
RECIPES = {
    'b340': 'a2_00100_b340_complete_original/ARCHIVE_READY.json',
    'policy': 'a2_00100_b_angle_policy_checkpoint_v1/ARCHIVE_READY.json',
    'i32': 'a2_00100_b16a_I32_complete_H_manifest.json',
    'i10': 'a2_00100_b16a_I10_complete_H_manifest.json',
    'i11': 'a2_00100_b16a_I11_complete_H_manifest.json',
    'three_i': 'a2_00100_b16a_three_I_complete_H_manifest.json',
    'complementary': 'a2_00100_b16a_three_complementary_quarters_v1/ARCHIVE_PARTS.json',
    'availability': 'a2_00100_b16a_replayable_cover_availability_v1/ARCHIVE_READY.json',
}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def safe_name(name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and p.parts
    assert str(p) == name.rstrip('/')
    return p

def restore(which):
    start = time.monotonic()
    assert sha(COMMITTED / 'GIT_RESTORATION_RECEIPT.json') == GIT_RECEIPT_SHA
    git = json.loads((COMMITTED / 'GIT_RESTORATION_RECEIPT.json').read_text())
    def committed(path):
        rel = str(path.relative_to(COMMITTED))
        expected = git['files'][rel]
        assert path.stat().st_size == expected['bytes']
        assert sha(path) == expected['sha256']
        return expected
    metadata = OUTER / RECIPES[which]
    committed(metadata)
    spec = json.loads(metadata.read_text())
    target = HERE / ('extracted_' + which)
    assert not target.exists()
    target.mkdir()
    compressed = target / Path(spec['archive']).name
    combined = hashlib.sha256()
    part_records = []
    with compressed.open('xb') as dest:
        for item in spec['parts']:
            part = metadata.parent / item['file']
            pin = committed(part)
            assert pin['sha256'] == item['sha256'] and pin['bytes'] == item['bytes']
            with part.open('rb') as stream:
                for block in iter(lambda: stream.read(1 << 20), b''):
                    combined.update(block)
                    dest.write(block)
            part_records.append({'path': str(part.relative_to(HERE)), **item})
    assert compressed.stat().st_size == spec['archive_bytes']
    assert combined.hexdigest() == spec['archive_sha256']
    assert sha(compressed) == spec['archive_sha256']
    unpacked = target / 'unpacked'
    unpacked.mkdir()
    members = {}
    pending_links = []
    with tarfile.open(compressed, 'r:xz') as archive:
        for member in archive:
            name = str(safe_name(member.name))
            if member.isdir():
                (unpacked / name).mkdir(parents=True, exist_ok=True)
                continue
            assert name not in members, 'Duplicate archive member'
            assert member.isfile() or member.islnk(), 'Unsupported archive member type'
            dest = unpacked / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            assert not dest.exists()
            if member.islnk():
                link = str(safe_name(member.linkname))
                pending_links.append((name, link, member.mode))
                members[name] = {'kind': 'hardlink', 'linkname': link}
                continue
            h = hashlib.sha256()
            count = 0
            with archive.extractfile(member) as stream, dest.open('xb') as output:
                for block in iter(lambda: stream.read(1 << 20), b''):
                    h.update(block)
                    output.write(block)
                    count += len(block)
            assert count == member.size
            os.chmod(dest, member.mode & 0o777)
            assert sha(dest) == h.hexdigest()
            members[name] = {'kind': 'regular', 'bytes': count, 'sha256': h.hexdigest()}
    while pending_links:
        later = []
        progress = False
        for name, source, mode in pending_links:
            assert source in members
            src = unpacked / source
            if not src.is_file():
                later.append((name, source, mode))
                continue
            dest = unpacked / name
            with src.open('rb') as stream, dest.open('xb') as output:
                shutil.copyfileobj(stream, output, 1 << 20)
            os.chmod(dest, mode & 0o777)
            digest = sha(dest)
            assert digest == members[source]['sha256']
            members[name].update(bytes=dest.stat().st_size, sha256=digest)
            progress = True
        assert progress, 'Unresolvable or cyclic archive hardlink'
        pending_links = later
    roots = {PurePosixPath(name).parts[0] for name in members}
    assert len(roots) == 1
    packet = unpacked / next(iter(roots))
    if 'packet_directory' in spec:
        assert packet.name == spec['packet_directory']
    expected_count = spec.get('all_archive_members_verified', spec.get('all_regular_members_verified', spec.get('archive_members', spec.get('members'))))
    if isinstance(expected_count, int):
        assert len(members) == expected_count, (len(members), expected_count)
    inventory_checks = []
    if 'release_manifest_sha256' in spec:
        release = packet / 'RELEASE_MANIFEST.json'
        assert sha(release) == spec['release_manifest_sha256']
        doc = json.loads(release.read_text())
        files = doc['files']
        actual = {str(p.relative_to(packet)) for p in packet.rglob('*') if p.is_file()}
        assert actual == set(files) | {'RELEASE_MANIFEST.json'}
        for name, digest in files.items():
            safe_name(name)
            assert sha(packet / name) == digest
        inventory_checks.append({'file': 'RELEASE_MANIFEST.json', 'sha256': sha(release), 'files_checked': len(files), 'complete_member_set': True})
    if 'member_manifest_sha256' in spec:
        path = packet / 'MEMBER_MANIFEST.json'
        assert sha(path) == spec['member_manifest_sha256']
        doc = json.loads(path.read_text())
        assert set(members) == set(doc['members']) | {packet.name + '/MEMBER_MANIFEST.json'}
        for name, item in doc['members'].items():
            assert members[name]['sha256'] == item['sha256']
            assert members[name]['bytes'] == item['bytes']
        inventory_checks.append({'file': 'MEMBER_MANIFEST.json', 'sha256': sha(path), 'files_checked': len(doc['members']), 'complete_member_set': True})
    if 'archive_inventory_sha256' in spec:
        matches = [p for p in packet.rglob('*.json') if sha(p) == spec['archive_inventory_sha256']]
        assert len(matches) == 1, 'Published archive inventory must be present uniquely'
        inventory = matches[0]
        doc = json.loads(inventory.read_text())
        actual = {str(p.relative_to(packet)) for p in packet.rglob('*') if p.is_file()}
        assert actual == set(doc['files']) | {str(inventory.relative_to(packet))}
        for name, digest in doc['files'].items():
            safe_name(name)
            assert sha(packet / name) == digest
        inventory_checks.append({'file': str(inventory.relative_to(packet)), 'sha256': sha(inventory), 'files_checked': len(doc['files']), 'complete_member_set': True})
    result = {
        'status': 'PASS_PUBLISHED_ARCHIVE_BYTES_RECOVERED',
        'commit': git['commit'],
        'archive_metadata': str(metadata.relative_to(HERE)),
        'archive_metadata_sha256': sha(metadata),
        'archive_sha256': sha(compressed),
        'archive_bytes': compressed.stat().st_size,
        'parts': part_records,
        'packet': str(packet),
        'member_count': len(members),
        'members': members,
        'inventory_checks': inventory_checks,
        'arithmetic_replayed': False,
        'lost_uncommitted_suffix_reconstructed': False,
        'new_original_cells': 0,
        'new_masks': 0,
        'raw_tar_intermediate_created': False,
        'restorer_sha256': sha(Path(__file__)),
        'elapsed_seconds': time.monotonic() - start,
    }
    write_json(target / 'ARCHIVE_RECOVERY_RECEIPT.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'packet', 'member_count', 'archive_sha256', 'elapsed_seconds')}), flush=True)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('packages', nargs='+', choices=sorted(RECIPES))
    args = p.parse_args()
    for package in args.packages:
        restore(package)
