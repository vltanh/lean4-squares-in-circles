#!/usr/bin/env python3
"""Small discovery storage controls; no numerical search or proof credit."""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
from pathlib import Path
import errno
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import ast
from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
B = HERE.parent
sys.path.insert(0, str(B))
import resume_b_five_proxy_round_atomic_center_tree_v1 as DRIVER

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def check_new_center_runtime_and_actual_callbacks(fixtures):
    """Exercise real new Context, actual driver callbacks, and atomic writes.

    The callback flow uses the retained exact physical state and saved LP point
    from B16a node17. Only phase/bound solves are replaced with explicit software
    fixtures. Their artificial rounds are not certificates and never enter a
    proof tree or accepted manifest.
    """
    controls=[]
    baseline=(B/'resume_b_five_proxy_round_atomic_tree_v1.py').read_text()
    changed=Path(DRIVER.__file__).read_text()
    assert changed.replace('import b_accepted_center_disk_runtime_v1 as RT',
                           'import b_four_complete_guards_runtime as RT',1)==baseline
    assert not any(isinstance(node,ast.Try)for node in ast.walk(ast.parse(changed)))
    assert DRIVER.E is DRIVER.RT.E and DRIVER.E is DRIVER.RT.BASE.E
    controls.append('exact one-import driver delta; same actual runtime E; no exception handler')
    pins=DRIVER.RT.source_bindings()
    assert len(pins)==42
    for path,digest in pins.items():assert sha(path)==digest
    controls.append('all42 runtime and accepted-family source pins verified; no missing binding fabricated')
    # A changed accepted binding must fail before the inherited Context starts.
    bad=fixtures/'bad_center_binding.json';bad.write_text('{}\n')
    with patch.object(DRIVER.RT,'BINDING',bad),patch.object(DRIVER.RT.BASE.Context,'__init__',side_effect=RuntimeError('parent constructor must not run')):
        try:DRIVER.RT.Context(B/'b16a_I32_complete_H_checkpoint')
        except AssertionError:pass
        else:raise AssertionError('Incorrect accepted binding was allowed')
    controls.append('changed center binding rejected before inherited Context construction')
    ctx=DRIVER.RT.Context(B/'b16a_I32_complete_H_checkpoint')
    initial=json.loads((HERE/'registered_B_initial_states/negative-462e78d2e2d8be05.json').read_text())
    state=DRIVER.restore(ctx,initial)
    def no_solver(*args,**kwargs):raise AssertionError('A numerical solve was not authorized by this control')
    with patch.object(DRIVER.E,'phase_solve',side_effect=no_solver),patch.object(DRIVER.E,'bound_round',side_effect=no_solver):
        rows,bounds,physical,terminal=ctx.collect(state)
    assert terminal is None
    count=len(ctx.center_parameters);assert count==576
    assert all(not row[2].startswith(DRIVER.RT.CENTER.PREFIX)for row in rows[:-count])
    assert all(row[2].startswith(DRIVER.RT.CENTER.PREFIX)for row in rows[-count:])
    spec=importlib.util.spec_from_file_location('center_control_independent',DRIVER.RT.FAMILY/'independent_physical_center_disk_rows.py')
    decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
    for row in rows[-count:]:decoder.verify_literal(row)
    controls.append('actual B462 Context.collect appends576 independently valid center rows; no solve')
    del rows,bounds,physical,state
    # Execute the actual nested callbacks extracted unchanged from the driver.
    tree=ast.parse(changed)
    functions={name:next(node for node in ast.walk(tree)if isinstance(node,ast.FunctionDef)and node.name==name)
               for name in ('merge','checkpoint','adaptive_search')}
    payload=json.loads((HERE/'reassembled_B16a_published_prefix_v1/node_0017.json').read_text())
    old=payload['record'];state=DRIVER.restore(ctx,old);point=old['point']
    selected=DRIVER.SPLIT.split_choice(state,point,old)
    assert selected['kind']=='angle'and selected['owner']==4 and selected['cut']=='0'
    assert selected['normalized_corner_excess']>=.1
    assert sum(kind=='proxy'for pair,kind,choice in state['choices'])>=5
    class TinyContext:
        AH=SimpleNamespace(SEED_NAMES=set())
        def collect(self,state):return [],[],state,None
    def run_callback(target,fail_fsync):
        calls=dict(phase=0,bound=0,engine_dispatch=0,writes=0)
        def phase(rows,bounds):
            calls['phase']+=1
            return None,0.0,point,None
        def bound(context,current,rows,bounds,physical,h):
            calls['bound']+=1
            view=DRIVER.E.stateview(current)
            return deepcopy(current),dict(before=view,after=deepcopy(view),
                proposals=[dict(software_dispatch_fixture_only=True)],printed_rows=[]),None
        def write_record(node,record):
            calls['writes']+=1
            DRIVER.dump(target,record)
        environment=dict(deepcopy=deepcopy,state=deepcopy(state),old=deepcopy(old),
            n={k:deepcopy(v)for k,v in payload.items()if k!='record'},
            ctx=TinyContext(),budget=3,a=SimpleNamespace(max_depth=24),
            E=DRIVER.E,SEARCH=DRIVER.SEARCH,SPLIT=DRIVER.SPLIT,F=DRIVER.F,
            write_record=write_record)
        module=ast.Module(body=[deepcopy(functions[name])for name in ('merge','checkpoint','adaptive_search')],type_ignores=[])
        exec(compile(ast.fix_missing_locations(module),DRIVER.__file__,'exec'),environment)
        original_search=DRIVER.SEARCH.search_node
        def explicit_engine(engine,*args,**kwargs):
            calls['engine_dispatch']+=1
            assert engine is DRIVER.E is DRIVER.RT.E
            return original_search(engine,*args,**kwargs)
        target.write_bytes(b'{"prior_checkpoint":true}\n')
        with patch.object(DRIVER.E,'phase_solve',side_effect=phase),patch.object(DRIVER.E,'bound_round',side_effect=bound),patch.object(DRIVER.SEARCH,'search_node',side_effect=explicit_engine):
            if fail_fsync:
                with patch.object(DRIVER.ATOMIC.os,'fsync',side_effect=OSError(errno.ENOSPC,'actual callback control disk full')):
                    try:environment['adaptive_search']()
                    except OSError as error:assert error.errno==errno.ENOSPC
                    else:raise AssertionError('Actual checkpoint callback swallowed ENOSPC')
                assert target.read_bytes()==b'{"prior_checkpoint":true}\n'
                assert calls==dict(phase=1,bound=1,engine_dispatch=1,writes=1)
            else:
                answer,after,returned_point=environment['adaptive_search']()
                assert answer['status']=='OPEN'and returned_point==point
                assert answer['discovery_early_angle']['completed_rounds']==1
                assert answer['discovery_early_angle']['split']['owner']==4
                assert answer['discovery_early_angle']['split']['cut']=='0'
                assert calls==dict(phase=2,bound=1,engine_dispatch=1,writes=1)
                saved=json.loads(target.read_text())
                assert saved['status']=='OPEN'and saved['initial']==old['initial']
                assert saved['rounds'][:-1]==old['rounds'] and saved['final']==old['final']
                assert saved['continued_completed_rounds']==len(old['rounds'])
        return calls
    run_callback(fixtures/'actual_callback_success.json',False)
    controls.append('actual explicit-E search/driver callbacks use saved B16point and stop at first completed-round angle; old rounds retained')
    run_callback(fixtures/'actual_callback_enospc.json',True)
    controls.append('ENOSPC escapes actual checkpoint callback and search loop; old destination remains exact')
    return controls

def main():
    assert sha(DRIVER.__file__) == '02334833b824a58d49fcd316d154a59bc61866b0b3428f8fe7dcac12799af786'
    assert sha(DRIVER.ATOMIC.__file__) == '2f17219f8689b343f7f1c29e7a314272bd5ace8d25fbee11f58cd20b44543eb3'
    fixtures = HERE / 'atomic_center_driver_dispatch_fixtures'
    fixtures.mkdir()
    old = b'{"old": true}\n'
    value = {'status': 'OPEN', 'rounds': [], 'unicode': '\u03b1'}
    expected = (json.dumps(value, indent=2) + '\n').encode()
    controls = []
    # Exact ordinary bytes and source-hardlink preservation on replacement.
    source = fixtures / 'immutable_source.json'
    target = fixtures / 'linked_target.json'
    source.write_bytes(old)
    source.chmod(0o640)
    os.link(source, target)
    DRIVER.dump(target, value)
    assert source.read_bytes() == old and target.read_bytes() == expected
    assert (source.stat().st_dev, source.stat().st_ino) != (target.stat().st_dev, target.stat().st_ino)
    assert target.stat().st_mode & 0o777 == 0o640
    controls.append('ordinary JSON bytes, permissions, and immutable hardlink donor preserved')
    # Disk-full at file fsync propagates out of the driver and keeps old target.
    target = fixtures / 'file_fsync_failure.json'
    target.write_bytes(old)
    with patch.object(DRIVER.ATOMIC.os, 'fsync', side_effect=OSError(errno.ENOSPC, 'fixture disk full')):
        try:
            DRIVER.dump(target, value)
        except OSError as error:
            assert error.errno == errno.ENOSPC
        else:
            raise AssertionError('Driver swallowed checkpoint write failure')
    assert target.read_bytes() == old
    assert len(list(fixtures.glob(target.name + '.atomic-*.tmp'))) == 1
    controls.append('file-fsync ENOSPC propagated; prior destination and diagnostic retained')
    # A post-replacement directory failure truthfully leaves the new destination.
    target = fixtures / 'directory_fsync_failure.json'
    target.write_bytes(old)
    original_fsync = DRIVER.ATOMIC.os.fsync
    calls = 0
    def fsync(fd):
        nonlocal calls
        calls += 1
        if calls == 2:
            raise OSError(errno.ENOSPC, 'fixture directory full')
        return original_fsync(fd)
    with patch.object(DRIVER.ATOMIC.os, 'fsync', side_effect=fsync):
        try:
            DRIVER.dump(target, value)
        except OSError as error:
            assert error.errno == errno.ENOSPC
            assert any('destination_replaced=True' in note for note in error.__notes__)
        else:
            raise AssertionError('Driver swallowed directory durability failure')
    assert target.read_bytes() == expected
    diagnostic = list(fixtures.glob(target.name + '.atomic-*.tmp'))
    assert len(diagnostic) == 1 and diagnostic[0].stat().st_ino == target.stat().st_ino
    controls.append('directory-fsync ENOSPC propagated with truthful replaced status and exact inode diagnostic')
    # An invalid source pin must fail before Context/search or node publication.
    seed = json.loads((HERE / 'prepared_B580_complete_frontier/manifest.json').read_text())
    for group in ('sources', 'accepted_geometric_sources'):
        damaged = json.loads(json.dumps(seed))
        first = next(iter(damaged[group]))
        damaged[group][first] = '0' * 64
        folder = fixtures / ('bad_' + group)
        folder.mkdir()
        (folder / 'manifest.json').write_text(json.dumps(damaged, indent=2) + '\n')
        output = fixtures / ('rejected_' + group)
        run = subprocess.run([sys.executable, '-B', str(Path(DRIVER.__file__).resolve()), str(folder), str(output), '--prepare-only'], capture_output=True, text=True)
        assert run.returncode != 0 and 'AssertionError' in run.stderr
        assert not list(output.glob('node_*.json'))
        controls.append(group + ' wrong pin rejected before node/search publication')
    controls.extend(check_new_center_runtime_and_actual_callbacks(fixtures))
    result = {'status': 'PASS_B_ATOMIC_CENTER_DRIVER_DISPATCH_AND_FAIL_FAST_CONTROLS', 'controls': controls, 'control_count': len(controls), 'driver_sha256': sha(DRIVER.__file__), 'atomic_helper_sha256': sha(DRIVER.ATOMIC.__file__), 'control_source_sha256': sha(Path(__file__)), 'mathematical_or_cover_rules_changed': False, 'accepted_universal_center_rows_added': True, 'runtime_sha256': sha(DRIVER.RT.__file__), 'family_binding_sha256': sha(DRIVER.RT.BINDING), 'numerical_search_run': False, 'whole_original_credit': 0, 'whole_mask_credit': 0, 'one_file_atomicity_only': True, 'node_plus_manifest_transaction_claimed': False}
    destination = HERE / 'B_ATOMIC_CENTER_DRIVER_DISPATCH_CONTROLS.json'
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)

if __name__ == '__main__':
    main()
