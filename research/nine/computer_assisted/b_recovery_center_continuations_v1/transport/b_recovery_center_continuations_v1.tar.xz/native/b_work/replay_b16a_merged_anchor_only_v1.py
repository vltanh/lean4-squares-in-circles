#!/usr/bin/env python3
"""Check the full-original implication chain behind the merged I21/I22 anchor.

The already freshly replayed 45-node continuation is not replayed here again.
This gate specifically checks the stronger-parent domain-preservation walk.
"""
from pathlib import Path
import argparse
import json
import time
import verify_b16a_partition_piece as PIECE

HERE = Path(__file__).resolve().parent

def main():
    if not __debug__:
        raise RuntimeError('Exact assertions must be enabled')
    parser = argparse.ArgumentParser()
    parser.add_argument('report', type=Path)
    parser.add_argument('--cap-proof-dir', type=Path, required=True)
    args = parser.parse_args()
    assert not args.report.exists()
    start = time.monotonic()
    adapter = PIECE.Adapter(HERE / 'b16a_I32_complete_H_checkpoint', args.cap_proof_dir)
    adapter.retain(__file__)
    report, state = PIECE.anchor_domain(HERE / 'B16A_MERGED_I21_I22_RESTRICTION.json', adapter)
    assert state is not None and report['tiles'] == [[2, 1], [2, 2]]
    assert report['stronger_whole_parent_attachment']['exact_unconditional_parent_domain_preservation_checked'] is True
    result = PIECE.finalize(report, adapter)
    result['seconds'] = time.monotonic() - start
    args.report.write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'], result['tiles'], result['seconds'], flush=True)

if __name__ == '__main__':
    main()
