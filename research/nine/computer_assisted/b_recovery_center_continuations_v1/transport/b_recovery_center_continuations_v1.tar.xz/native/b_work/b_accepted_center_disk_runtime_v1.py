"""Universal center supports over the unchanged B four-corner runtime.

Search directions are untrusted; every weighted literal is checked by the
independent center-row decoder. Rows append only, preserving prior indices.
"""
from pathlib import Path
from fractions import Fraction as F
from math import cos, sin, pi
import sys
import json
import hashlib
import b_four_complete_guards_runtime as BASE
HERE=Path(__file__).resolve().parent
FAMILY=HERE/'accepted_center_disk_v1'
BINDING=FAMILY/'BINDING.json'
BINDING_SHA='8fb0b5dda2d0bb892236dac5825bec3c8824d4ba6f1440aee967c9b5aa1e1a82'
sys.path.insert(0,str(FAMILY))
import physical_center_disk_rows as CENTER
import physical_center_disk_separation as CSEARCH
E=BASE.E

def verify_premise_sources():
    if not __debug__:
        raise RuntimeError('Exact source assertions must be enabled')
    assert hashlib.sha256(BINDING.read_bytes()).hexdigest()==BINDING_SHA
    binding=json.loads(BINDING.read_text())
    assert binding['status']=='PUBLISHED_PHYSICAL_AND_ACTUAL_WEIGHTED_USE_GATE_ACCEPTED'
    assert binding['squared_radius']=='1105/256' and binding['center_radius_enclosure']=='91/60'
    for name,digest in binding['files'].items():
        path=FAMILY/name
        assert path.resolve().is_relative_to(FAMILY.resolve())
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    assert E.sha(CENTER.__file__)==binding['files']['physical_center_disk_rows.py']
    assert E.sha(CSEARCH.__file__)==binding['files']['physical_center_disk_separation.py']
    return binding

class Context(BASE.Context):
    def __init__(self,packet):
        verify_premise_sources()
        super().__init__(packet)
        context=self
        directions={(F(round(4096*cos(2*pi*k/64)),4096),F(round(4096*sin(2*pi*k/64)),4096))for k in range(64)}
        self.center_parameters={(i,a,b)for i in range(9)for a,b in directions}
        previous=self.AH.ActiveHighs
        class DynamicCenterHighs(previous):
            def run(self):
                for cycle in range(4):
                    answer=super().run()
                    if not context.gram_active or cycle==3 or self.inner.getModelStatus()!=self.H.HighsModelStatus.kOptimal:
                        return answer
                    point=list(map(float,self.inner.getSolution().col_value[:-1]))
                    rows=[]
                    for parameters,violation in CSEARCH.violated_parameters(point,tolerance=1e-7):
                        if parameters not in context.center_parameters:
                            context.center_parameters.add(parameters)
                            rows.append(CENTER.row(*parameters))
                    if not rows:return answer
                    self.append_rows(rows)
                raise AssertionError('unreachable')
        self.AH.ActiveHighs=DynamicCenterHighs
    def collect(self,state):
        rows,bounds,physical,terminal=super().collect(state)
        if terminal is not None:return rows,bounds,physical,terminal
        rows.extend(CENTER.row(*parameters)for parameters in sorted(self.center_parameters))
        return rows,bounds,physical,None

def source_bindings():
    binding=verify_premise_sources()
    result=BASE.source_bindings()
    for p in(__file__,BINDING,*(FAMILY/name for name in binding['files'])):
        result[str(Path(p).resolve())]=E.sha(p)
    return result
