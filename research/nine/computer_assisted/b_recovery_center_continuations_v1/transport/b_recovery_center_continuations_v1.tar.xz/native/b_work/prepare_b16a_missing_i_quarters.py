#!/usr/bin/env python3
"""Prepare the eight unrecovered closed I-quarter domains, without LP work."""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
import hashlib,json

HERE = Path(__file__).resolve().parent
PARENT = HERE / 'b16a_I32_complete_H_checkpoint/ancestry/parent/negative-16a2fc93c8d133f0.json'
GRID = HERE / 'b16a_I32_complete_H_checkpoint/ancestry/provenance/5f3da1873c074eee_manifest.json'
PARENT_SHA = '69ddd2dcc5383c3259187588a890ddadb4a6545e8bdcc11e653bdfb8bb6b3886'
GRID_SHA = '5f3da1873c074eeee6a3343bc2aa5406b41e6376cce8b708694f30024edfda2d'
MISSING = ((0,0),(0,1),(0,2),(0,3),(2,0),(3,0),(3,1),(3,3))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sha(PARENT) == PARENT_SHA and sha(GRID) == GRID_SHA
    parent, grid = json.loads(PARENT.read_text()), json.loads(GRID.read_text())
    assert parent['scope'] == 'WHOLE_UNCHANGED_ORIGINAL_PARENT' and parent['status'] == 'OPEN'
    assert grid['center_box'] == parent['final_positions'][16:18]
    out = HERE / 'b16a_missing_eight_i_domains'
    out.mkdir(exist_ok=False)
    records = []
    view = dict(id=parent['id'], path=parent['path'], angles=parent['final_angles'],
                positions=parent['final_positions'], scalar=parent['final_scalar'],
                differences=parent['final_differences'])
    for ix, iy in MISSING:
        final = deepcopy(view)
        rectangle = []
        for axis, k in enumerate((ix, iy)):
            lo, hi = map(F, grid['center_box'][axis])
            interval = [str(lo + (hi-lo)*F(k,4)), str(lo + (hi-lo)*F(k+1,4))]
            final['positions'][16+axis] = interval
            rectangle.append(interval)
        record = dict(schema='B_original_I_quarter_restriction_v1',
            scope='ONE_CLOSED_I_QUARTER_OF_REGISTERED_B16A_ORIGINAL',
            parent=dict(path=str(PARENT),sha256=PARENT_SHA), grid=dict(path=str(GRID),sha256=GRID_SHA),
            original=8, tile=[ix,iy], tile_index=4*ix+iy, grid_size=[4,4], rectangle=rectangle,
            closed_shared_faces_retained=True, all_other_inherited_bounds_retained=True,
            all_nine_originals_retained=True, all_original_corners_and_pairs_retained=True,
            strict_CD_retained=True, status='OPEN', final=final, original_cells_closed=0,masks_closed=0)
        dest = out / f'I{ix}{iy}.json'
        dest.write_text(json.dumps(record,indent=2)+'\n')
        records.append(dict(tile=[ix,iy], tile_index=4*ix+iy, file=dest.name, sha256=sha(dest)))
    manifest = dict(status='EIGHT_MISSING_ORIGINAL_I_QUARTERS_PREPARED_NO_EXCLUSION_CREDIT',
        original_id=parent['id'],parent_sha256=PARENT_SHA,grid_sha256=GRID_SHA,records=records,
        producer_sha256=sha(Path(__file__)),original_cells_closed=0,masks_closed=0)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest),flush=True)


if __name__ == '__main__':
    main()
