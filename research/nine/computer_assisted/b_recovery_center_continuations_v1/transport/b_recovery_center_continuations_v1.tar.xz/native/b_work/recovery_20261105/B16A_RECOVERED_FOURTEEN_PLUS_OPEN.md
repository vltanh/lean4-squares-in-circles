# Recovered B16a evidence: fourteen complete quarters and one OPEN merged pair

This is a recovery and availability checkpoint for the unchanged original
`negative-16a2fc93c8d133f0`. It adds no original-cell or mask closure.

The whole-original bound parent remains
`69ddd2dcc5383c3259187588a890ddadb4a6545e8bdcc11e653bdfb8bb6b3886`,
and the original I-center grid remains
`5f3da1873c074eeee6a3343bc2aa5406b41e6376cce8b708694f30024edfda2d`.
Its center box is
[-1474347/1048576,5/4] times [-91/60,91/60]. Interpolating each interval into
four closed parts gives the original sixteen quarters. All shared edges and
vertices belong to the cover.

| x-part | y-part 0 | y-part 1 | y-part 2 | y-part 3 |
|---|---|---|---|---|
| 0 | I00 complete, retained record | I01 complete, retained record | I02 complete, retained record | I03 complete, retained record |
| 1 | I10 complete, published master | I11 complete, published master | I12 complete, published master | I13 complete, published master |
| 2 | I20 complete, restored complementary packet | I21 OPEN, merged cover | I22 OPEN, merged cover | I23 complete, published master |
| 3 | I30 complete, retained record | I31 complete, restored complementary packet | I32 complete, published master | I33 complete, restored complementary packet |

## Retained complete evidence

The four older master packets cover I10, I11, I12/I13/I23, and I32. Their exact
archive inventories, checkers, original reports, hand attachments, and all input
bytes are recovered. The restored complementary packet proves I20, I31, and
I33 with 31 nodes and no OPEN leaf. That packet retains its own portable entry
point and the exact published I32 prerequisite. No deferred reconstruction of
those three quarters is needed.

The availability packet retained the complete terminal records for I00,
I01, I02, I03, and I30. The frozen quarter constructor reproduced all eight
domain records and the entire published domain manifest exactly. A new direct
one-node attachment for each of the five records has passed fresh exact replay
through the unchanged original-quarter, partition-piece, lazy-tree, and rational
arithmetic checkers. I30's unavailable historical zero-round intermediary is
not used: its retained terminal record starts at literally the same state as
the exact original I30 quarter. The source record remains unchanged and its
old metadata remains identified as historical.

`B16A_FIVE_REATTACHED_QUARTERS_FRESH_EXACT_REPLAY.json` records that fresh gate
and `B16A_FIVE_REATTACHED_QUARTERS_HAND_ATTACHMENT.md` explains the direct
attachment. The process was observed to exit 0. The five records provide one
positive-reserve terminal, three accepted center-interval terminals, and one
181-deduction empty-difference terminal.

## Remaining complete domain

Only the exact closed rectangle

[-163627/2097152,2457813/4194304] times [-91/120,91/120]

remains. It is precisely I21 union I22. Its stronger starting bounds follow
from a whole-original proof before the rectangle restriction. The fresh
`B16A_MERGED_ANCHOR_DOMAIN_PRESERVATION_FRESH_REPLAY.json` separately checks
that full-original implication chain with the existing domain-preservation
checker. It does not transfer a selected child or product auxiliary back to
the parent.

The reconstructed continuation seed contains 45 nodes, seven complete inset
unions, eight complete closed-angle unions, two excluded leaves, and 28 OPEN
leaves. Each retained weighted record comes from the published policy prefix.
Every unavailable sibling is explicitly a zero-round OPEN domain. The full
cover and all its retained arithmetic were freshly replayed. The later lost
search tree is not claimed to have been recovered. The root-owned atomic
continuation begins from this exact seed; its live progress is not part of the
immutable evidence inventory.

## Scope of the inventory and final gate

`B16A_FOURTEEN_PLUS_OPEN_COMPLETE_EVIDENCE_INVENTORY.json` freshly hashes 2,074
files, binds every complete quarter to its exact packet/report/hand source,
and checks the sixteen-quarter cover. It also compares all 231 original
definition tuples with the current register. The frozen original-definition
register and present closure-status register are distinguished explicitly.

That inventory is an availability and exact-byte audit. It does not rerun the
nine previously published complete quarter proofs, replace their accepted
arithmetic with a saved PASS label, or claim a self-contained portable proof.
The independent fresh gates for the five new attachments and the merged OPEN
cover are listed separately. A complete B16a result still requires the entire
merged rectangle to close, then fresh exact composition of all sixteen closed
quarters, the final physical/terminal table attachment, and portable replay.

All records retain the same nine physical originals, 36 corners and 36 pairs,
five cones, actual AB/BC/EF/FG, strict CD, exact 001/00 mask, and radius scope.
No ledger entry is changed by this checkpoint.
