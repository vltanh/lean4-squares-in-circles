#!/usr/bin/env python3
"""Hash and compose recovered evidence for 14 quarters plus an OPEN pair.

This is an availability/coverage audit, not a substitute for the old master
arithmetic replays or a complete original proof. It binds both the published
masters and the fresh five-piece/merged-domain gates by exact source hashes.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
RECOVERY = HERE / 'recovery_20261105'
PARENT_SHA = '69ddd2dcc5383c3259187588a890ddadb4a6545e8bdcc11e653bdfb8bb6b3886'
GRID_SHA = '5f3da1873c074eeee6a3343bc2aa5406b41e6376cce8b708694f30024edfda2d'
OLD = [
    ('I10', 'extracted_i10/unpacked/b16a_I10_complete_H_checkpoint_v2',
     '138b7b8bbb5decbcad4cd19dea73ed4d7bc94acd1a06818b0e024c695cb94df4',
     'B16A_I10_COMPLETE_H_REPLAY.json', '3ece1bd114c1478bac555a8685adbaa0ea690919884d4d03926eb786ceebfbaa',
     [[1, 0]], 'verify_b16a_complete_H_with_slope_covers_v2.py', 'I10_COMPLETE_H_COVER.json'),
    ('I11', 'extracted_i11/unpacked/b16a_I11_complete_fixed_rectangle_checkpoint',
     '6c837b105f197c7d5ef816d3faae1c0093d724d757dae7995ea0768035b6a26a',
     'B16A_I11_COMPLETE_H_REPLAY.json', '1f25175fe32e5df0e36e059ada6eeb6f1d4bbd3c94430a28164fbab50007509c',
     [[1, 1]], 'verify_b16a_I11_complete_H_cover.py', None),
    ('I12_I13_I23', 'extracted_three_i/unpacked/b16a_three_complete_H_checkpoint',
     '532f86a780800c472fd745ca5bbf27078140a7cca36602c58cc9fb97f1e9577f',
     'B16A_THREE_COMPLETE_H_REPLAY.json', 'ec8a8496b0415cb9e84a691f3601a11c442f8188c11dd7ca9d3a9884fb0f7618',
     [[1, 2], [1, 3], [2, 3]], 'verify_b16a_three_complete_H_covers.py', 'THREE_COMPLETE_H_COVERS.json'),
    ('I32', 'extracted_i32/unpacked/b16a_I32_complete_H_checkpoint',
     '13f64ff3d6accebd81e30195c7074ebef7f713a2988ff317ad115a96929973a5',
     'B16A_I32_COMPLETE_H_REPLAY.json', '69f12c27e86f13f37d02373eecce5834b0601db84f741efa6aee74a9c083a977',
     [[3, 2]], 'verify_b16a_complete_H_with_slope_covers_v2.py', 'I32_COMPLETE_H_COVER.json'),
]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    if not __debug__:
        raise RuntimeError('Exact assertions must be enabled')
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    files = {}
    def retain(path, expected=None):
        path = Path(path).resolve()
        digest = sha(path)
        if expected is not None:
            assert digest == expected, path
        if str(path) in files:
            assert files[str(path)] == digest
        files[str(path)] = digest
        return dict(path=str(path), sha256=digest)
    def inventory(root, name, expected):
        inv = root / name
        reference = retain(inv, expected)
        data = json.loads(inv.read_text())
        for relative, digest in data['files'].items():
            rel = Path(relative)
            assert not rel.is_absolute() and '..' not in rel.parts
            retain(root / rel, digest)
        return reference, len(data['files'])
    prior = HERE / 'b16a_I32_complete_H_checkpoint'
    parent = prior / 'ancestry/parent/negative-16a2fc93c8d133f0.json'
    grid = prior / 'ancestry/provenance/5f3da1873c074eee_manifest.json'
    parent_ref, grid_ref = retain(parent, PARENT_SHA), retain(grid, GRID_SHA)
    p, g = json.loads(parent.read_text()), json.loads(grid.read_text())
    assert p['id'] == 'negative-16a2fc93c8d133f0' and p['scope'] == 'WHOLE_UNCHANGED_ORIGINAL_PARENT'
    assert g['id'] == p['id'] and g['path'] == p['path'] and g['parent_sha256'] == PARENT_SHA
    assert g['center_box'] == p['final_positions'][16:18]
    axes = []
    for interval in g['center_box']:
        lo, hi = map(F, interval)
        assert lo < hi
        axes.append([lo + (hi - lo) * F(i, 4) for i in range(5)])
    rectangles = {(i, j): [[str(axes[0][i]), str(axes[0][i + 1])],
                           [str(axes[1][j]), str(axes[1][j + 1])]]
                  for i, j in product(range(4), repeat=2)}
    pieces, table = [], {}
    def add(label, tiles, status, evidence):
        for tile in tiles:
            key = tuple(tile)
            assert key in rectangles and key not in table
            table[key] = dict(tile=tile, rectangle=rectangles[key], status=status, evidence=label)
        pieces.append(dict(label=label, tiles=tiles, status=status, evidence=evidence))
    for label, relative, inv_sha, report_name, report_sha, tiles, checker, specification in OLD:
        root = RECOVERY / relative
        inv, count = inventory(root, 'ARCHIVE_INPUTS.json', inv_sha)
        report_ref = retain(root / report_name, report_sha)
        report = json.loads((root / report_name).read_text())
        assert report['id'] == p['id'] and report['original_prefix_sha256'] == PARENT_SHA
        assert report['I_parts'] == [4, 4] and report['all_frozen_inputs_rehashed_at_end'] is True
        assert report.get('I_tiles', [report.get('I_tile')]) == tiles
        add(label, tiles, 'COMPLETE_PUBLISHED_PROOF_AVAILABLE', dict(packet=str(root),
            inventory=inv, inventory_files_rehashed=count, accepted_report=report_ref,
            checker=retain(root / checker), specification=None if specification is None else retain(root / specification),
            hand=retain(root / 'HAND_PROOF.md'), arithmetic_replayed_by_this_audit=False))
    root = RECOVERY / 'extracted_complementary/unpacked/b16a_complementary_package_v2'
    inv, count = inventory(root, 'INPUT_MANIFEST.json', '99719914e99ca5aaf455adbd82936b73ab88f4ab3a70eda5ab56073e7d4af707')
    declaration = retain(root / 'COMPLEMENTARY_PROOF.json')
    comp = json.loads((root / 'COMPLEMENTARY_PROOF.json').read_text())
    assert comp['parent_sha256'] == PARENT_SHA and comp['grid_sha256'] == GRID_SHA
    assert comp['original_id'] == p['id'] and comp['original_path'] == p['path']
    for e in comp['pieces']:
        assert e['complete_tree_counts']['open_leaves'] == 0
        evidence = dict(packet=str(root), inventory=inv, inventory_files_rehashed=count,
            declaration=declaration, checker=retain(root / 'code/replay_b16a_complementary_packet.py'),
            hand=retain(root / 'HAND_PROOF.md'), required_published_prior_archive_sha256=comp['prior_archive_sha256'],
            required_prior_input_inventory_sha256=comp['prior_manifest_sha256'],
            arithmetic_replayed_by_this_audit=False)
        for key in ('domain', 'tree', 'native_exact_report'):
            ref = e[key]
            assert ref['root'] == 'packet'
            evidence[key] = retain(root / ref['path'], ref['sha256'])
        assert e['rectangle'] == rectangles[tuple(e['tile'])]
        add(e['label'], [e['tile']], 'COMPLETE_PUBLISHED_PROOF_AVAILABLE', evidence)
    fresh_path = RECOVERY / 'B16A_FIVE_REATTACHED_QUARTERS_FRESH_EXACT_REPLAY.json'
    fresh_ref = retain(fresh_path, 'dda1e399411d0cb2d1d2de7eb252ac2e99f1624f168da1a2b72df1b8dfdb1f71')
    fresh = json.loads(fresh_path.read_text())
    assert fresh['status'] == 'PASS_FIVE_COMPLETE_ORIGINAL_I_QUARTERS_FROM_UNCHANGED_PUBLISHED_RECORDS'
    for path, digest in fresh['source_sha256'].items():
        retain(path, digest)
    for e in fresh['pieces']:
        r = e['report']
        assert r['complete'] is True and r['all_physical_configurations_of_anchor_retained'] is True
        add(e['label'], r['covered_original_I_tiles'], 'COMPLETE_FRESH_REATTACHED_PROOF_AVAILABLE',
            dict(fresh_exact_report=fresh_ref, proof=retain(r['proof_path'], r['proof_sha256']),
                 hand=retain(RECOVERY / 'B16A_FIVE_REATTACHED_QUARTERS_HAND_ATTACHMENT.md'),
                 arithmetic_replayed_by_this_audit=False, separate_fresh_exact_observed_exit_code=0))
    anchor_path = RECOVERY / 'B16A_MERGED_ANCHOR_DOMAIN_PRESERVATION_FRESH_REPLAY.json'
    anchor = json.loads(anchor_path.read_text())
    assert anchor['tiles'] == [[2, 1], [2, 2]]
    assert anchor['stronger_whole_parent_attachment']['exact_unconditional_parent_domain_preservation_checked'] is True
    for path, digest in anchor['source_sha256'].items():
        retain(path, digest)
    open_path = RECOVERY / 'REASSEMBLED_B16A_COMPLETE_OPEN_COVER_EXACT_REPLAY.json'
    open_ref = retain(open_path, 'd8f302db860302a9169fc027703543a0d8b44f70b53253df2271108c8a82cf44')
    open_report = json.loads(open_path.read_text())
    assert open_report['nodes'] == 45 and open_report['open_leaves'] == 28 and open_report['excluded_leaves'] == 2
    assert open_report['parent_certificate_sha256'] == anchor['domain_sha256']
    merged_rectangle = [rectangles[(2, 1)][0], [rectangles[(2, 1)][1][0], rectangles[(2, 2)][1][1]]]
    assert anchor['rectangle'] == merged_rectangle
    for path, digest in open_report['source_sha256'].items():
        retain(path, digest)
    add('I21_I22', [[2, 1], [2, 2]], 'OPEN_COMPLETE_COVER_AVAILABLE',
        dict(fresh_cover_report=open_ref, fresh_domain_preservation_report=retain(anchor_path),
             manifest=retain(RECOVERY / 'reassembled_B16a_published_prefix_v1/manifest.json', open_report['certificate_sha256']),
             launch_freeze=retain(RECOVERY / 'B16A_MERGED_RECOVERED_ATOMIC_LAUNCH_FREEZE.json'),
             merged_rectangle=merged_rectangle, arithmetic_replayed_by_this_audit=False))
    assert set(table) == set(product(range(4), repeat=2))
    closed = [entry for entry in table.values() if entry['status'].startswith('COMPLETE_')]
    assert len(closed) == 14 and [k for k in sorted(table) if table[k]['status'].startswith('OPEN_')] == [(2, 1), (2, 2)]
    current = HERE.parent / 'repo/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
    frozen = prior / 'ancestry/legacy/current_proof/original_register.json'
    current_ref, frozen_ref = retain(current), retain(frozen, 'ea000e84c04675fe22424e5c20d3df9d735d659065349800aef2699170bff604')
    cc, ff = json.loads(current.read_text())['cells'], json.loads(frozen.read_text())['cells']
    fields = ('id', 'sign', 'baseline_frontier_index', 'path')
    assert len(cc) == len(ff) == 231 and [[e[k] for k in fields] for e in cc] == [[e[k] for k in fields] for e in ff]
    retain(__file__)
    result = dict(schema='B16a_fourteen_complete_quarter_evidence_plus_complete_OPEN_merged_cover_v1',
        status='PASS_EXACT_BYTES_DEFINITIONS_AND_COMPLETE_GRID_AVAILABILITY_AUDIT',
        original_id=p['id'], original_path=p['path'], parent=parent_ref, grid=grid_ref,
        current_register=current_ref, frozen_definition_register=frozen_ref,
        all_231_original_definitions_unchanged=True, closed_quarters_available=14, open_quarters=2,
        quarter_table=[table[k] for k in sorted(table)], pieces=pieces, exact_files=files,
        all_listed_file_hashes_freshly_checked=True, old_master_arithmetic_rerun=False,
        standalone_portable_proof=False, whole_original_proved=False,
        entire_grid_and_all_closed_shared_faces_covered=True, lost_search_suffix_recovered=False,
        new_original_cells=0, new_masks=0)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=result['status'], sha256=sha(args.output),
        closed_quarters=14, open_quarters=2, exact_files=len(files))), flush=True)

if __name__ == '__main__':
    main()
