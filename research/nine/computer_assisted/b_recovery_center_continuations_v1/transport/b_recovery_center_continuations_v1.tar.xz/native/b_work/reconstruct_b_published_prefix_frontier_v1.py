#!/usr/bin/env python3
"""Reassemble a complete OPEN cover around one published conditional subtree.

All retained weighted records are copied from the committed policy packet.
Every unavailable sibling is newly represented by a zero-round OPEN record.
This reconstructs a new complete covering frontier, not the lost search tree.
The unchanged independent full-tree checker remains the acceptance gate.
"""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
from itertools import product
import argparse
import hashlib
import json
import sys
import independent_physical_sat_replay as CORE
import independent_physical_proxy_cover as PROXY
import verify_b_mixed_tree as MIX
import verify_b_four_corner_trees as EXACT

HERE = Path(__file__).resolve().parent
RECOVERY = HERE / 'recovery_20261105'
PACKET = RECOVERY / 'extracted_policy/unpacked/b_angle_policy_checkpoint'
POLICY_INPUT_SHA = '54ec1091fd63c5f9ae7f8fafc268d5a10a8bbad1fdf81aab6fbee84f856ce972'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def semantic_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def dump(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def from_view(view, adapter):
    box = lambda xs: tuple(tuple(F(x) for x in pair) for pair in xs)
    state = dict(id=view['id'], path=deepcopy(view['path']), choices=adapter.choices(view['path']),
        angles=box(view['angles']), positions=box(view['positions']), scalar=box(view['scalar']),
        differences={tuple(x['pair']): box(x['intervals']) for x in view['differences']})
    if 'diagonal' in view:
        state['diagonal'] = {tuple(x['pair']): box(x['intervals']) for x in view['diagonal']}
    CORE.valid_state(state)
    assert CORE.state_view(state) == view
    return state

def alternatives(state, split, adapter):
    if split['kind'] == 'proxy':
        for choice in product((0, 1), (-1, 1)):
            choice = list(choice)
            yield choice, PROXY.proxy_child(state, split['pair'], choice, adapter)
    elif split['kind'] == 'sat':
        for choice in product(tuple(split['pair']), (0, 1), (-1, 1)):
            choice = list(choice)
            yield choice, CORE.sat_child(state, split['pair'], choice, adapter)
    else:
        assert split['kind'] == 'angle'
        for side in (0, 1):
            yield side, MIX.angle_child(state, split['owner'], split['cut'], side, adapter)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('case', choices=['b16a_after_round_two', 'b7c_five_proxy'])
    ap.add_argument('output', type=Path)
    args = ap.parse_args()
    assert sha(PACKET / 'INPUT_MANIFEST.json') == POLICY_INPUT_SHA
    inventory = json.loads((PACKET / 'INPUT_MANIFEST.json').read_text())['files']
    source_dir = PACKET / 'certificates' / args.case
    prefix_path, local_manifest_path = source_dir / 'PREFIX.json', source_dir / 'manifest.json'
    for path in (prefix_path, local_manifest_path):
        assert sha(path) == inventory[str(path.relative_to(PACKET))]
    prefix = json.loads(prefix_path.read_text())
    local_manifest = json.loads(local_manifest_path.read_text())
    assert prefix['conditional_branch_only'] is True and prefix['status'] == 'OPEN'
    assert prefix['original_cells_closed'] == prefix['masks_closed'] == 0
    old_nodes = {}
    for entry in local_manifest['nodes']:
        path = source_dir / entry['file']
        assert sha(path) == entry['sha256'] == inventory[str(path.relative_to(PACKET))]
        old_nodes[entry['index']] = json.loads(path.read_text())
    assert set(old_nodes) == {0, 1, 2}
    local_root = old_nodes[0]
    assert local_root['children'] == [1, 2] and local_root['split']['kind'] == 'angle'
    assert local_root['record']['rounds'] == [] and local_root['record']['status'] == 'OPEN'
    assert local_root['record']['initial'] == local_root['record']['final'] == prefix['final']
    assert [old_nodes[i]['choice'] for i in (1, 2)] == [0, 1]
    assert all(old_nodes[i]['status'] == 'CANDIDATE_CLOSED' and not old_nodes[i]['children'] for i in (1, 2))
    args.output.mkdir(parents=True, exist_ok=False)
    adapter = EXACT.Adapter(HERE / 'b16a_I32_complete_H_checkpoint')
    nodes = []
    retained = []
    fresh_open = []
    steps = prefix['steps']
    assert steps and steps[0]['restriction'] is None
    def create(state, record, parent, choice, depth):
        view = CORE.state_view(state)
        assert record['initial'] == view
        index = len(nodes)
        node = dict(index=index, parent=parent, depth=depth, choice=deepcopy(choice), initial=deepcopy(view),
            status=record['status'], children=[], record=deepcopy(record))
        nodes.append(node)
        return index
    def open_leaf(state, parent, choice, depth):
        view = CORE.state_view(state)
        record = dict(status='OPEN', initial=deepcopy(view), rounds=[], final=deepcopy(view), unsearched_closed_domain=True)
        index = create(state, record, parent, choice, depth)
        fresh_open.append(index)
        return index
    def keep_step(number, state, parent=None, choice=None, depth=0):
        step = steps[number]
        record = step['record']
        assert record['status'] == 'OPEN'
        index = create(state, record, parent, choice, depth)
        node = nodes[index]
        retained.append(dict(new_index=index, prefix_step=number, historical_tree_index=step['original_tree_index'], record_semantic_sha256=semantic_sha(record)))
        after = from_view(record['final'], adapter)
        if number + 1 < len(steps):
            restriction = steps[number + 1]['restriction']
            split, selected = restriction['split'], restriction['choice']
        else:
            assert record['final'] == prefix['final']
            split, selected = local_root['split'], None
        node['split'] = deepcopy(split)
        node['complete_closed_children'] = True
        selected_count = 0
        for ch, child in alternatives(after, split, adapter):
            if number + 1 == len(steps):
                original_node = old_nodes[1 + ch]
                assert original_node['initial'] == CORE.state_view(child)
                child_index = create(child, original_node['record'], index, ch, depth + 1)
                retained.append(dict(new_index=child_index, published_local_index=1 + ch, record_semantic_sha256=semantic_sha(original_node['record'])))
            elif ch == selected:
                selected_count += 1
                child_index = keep_step(number + 1, child, index, ch, depth + 1)
            else:
                child_index = open_leaf(child, index, ch, depth + 1)
            node['children'].append(child_index)
        if number + 1 < len(steps):
            assert selected_count == 1
        node['status'] = 'CANDIDATE_COVER_CLOSED' if all(nodes[k]['status'] in ('CANDIDATE_CLOSED', 'CANDIDATE_COVER_CLOSED') for k in node['children']) else 'OPEN'
        return index
    keep_step(0, from_view(steps[0]['record']['initial'], adapter))
    seed = json.loads((RECOVERY / 'prepared_B580_complete_frontier/manifest.json').read_text())
    sources = deepcopy(seed['sources'])
    for path in [Path(__file__), Path(CORE.__file__), Path(PROXY.__file__), Path(MIX.__file__), Path(EXACT.__file__), prefix_path, local_manifest_path] + [source_dir / e['file'] for e in local_manifest['nodes']]:
        sources[str(path.resolve())] = sha(path)
    for path, digest in sources.items():
        assert sha(path) == digest
    entries = []
    for node in nodes:
        path = args.output / f"node_{node['index']:04d}.json"
        dump(path, node)
        entries.append(dict(index=node['index'], file=path.name, sha256=sha(path), status=node['status'], depth=node['depth']))
    manifest = dict(schema='B_proxy_first_complete_physical_tree_discovery_v1', parent=deepcopy(prefix['parent']),
        sources=sources, accepted_geometric_sources=deepcopy(seed['accepted_geometric_sources']), completed=True,
        status=nodes[0]['status'], original_cells_closed=0, masks_closed=0, acceptance_status='INDEPENDENT_REPLAY_PENDING', nodes=entries,
        recovery=dict(kind='NEW_COMPLETE_OPEN_COMPLEMENT_ASSEMBLY_FROM_PUBLISHED_CONDITIONAL_RECORDS',
            published_prefix_sha256=sha(prefix_path), published_conditional_tree_sha256=sha(local_manifest_path),
            retained_weighted_records=retained, newly_constructed_zero_round_open_indices=fresh_open,
            lost_full_search_checkpoint_recovered=False, unavailable_sibling_exclusions_claimed=False))
    dump(args.output / 'manifest.json', manifest)
    report = dict(status='CANDIDATE_COMPLETE_OPEN_FRONTIER_ASSEMBLED_EXACT_REPLAY_PENDING', case=args.case,
        manifest_sha256=sha(args.output / 'manifest.json'), nodes=len(nodes), retained_prefix_records=len(steps),
        retained_published_excluded_leaves=2, newly_constructed_zero_round_open_leaves=len(fresh_open),
        all_cover_alternatives_explicit=True, source_prefix_sha256=sha(prefix_path), source_local_tree_sha256=sha(local_manifest_path),
        source_sha256=sha(Path(__file__)), no_numerical_search=True, new_original_cells=0, new_masks=0,
        lost_full_search_checkpoint_recovered=False)
    dump(args.output / 'ASSEMBLY.json', report)
    assert not any(x in sys.modules for x in ('numpy', 'scipy', 'highspy'))
    print(json.dumps(report, indent=2), flush=True)

if __name__ == '__main__':
    main()
