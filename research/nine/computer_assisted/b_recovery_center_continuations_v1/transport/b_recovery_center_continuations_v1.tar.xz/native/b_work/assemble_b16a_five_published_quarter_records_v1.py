#!/usr/bin/env python3
"""Attach five unchanged published records to exact original quarter states.

No numerical solve or arithmetic acceptance occurs here. In particular the
unavailable old I30 zero-round parent is not recreated or used as authority:
the saved terminal's literal initial state must equal the exact quarter state.
The unchanged complete-piece checker is the acceptance gate.
"""
from pathlib import Path
from copy import deepcopy
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
RECOVERY = HERE / 'recovery_20261105'
PAYLOAD = RECOVERY / 'extracted_availability/unpacked/b16a_replayable_cover_availability_v1/payload/b_work'
DOMAIN_MANIFEST_SHA = 'd1347f13c6056ff83b6c94ddcd6ab5c6fa43ada5d91f7c1f18f7a20493eea9cc'
RECORDS = {
    'I00': ('b16a_missing_eight_direct_reconstruction/I00/result.json', '096e3c70f51f5f7f4644281397c0d686f7d9fe0dde3984a24a402b416fd62766'),
    'I01': ('b16a_missing_eight_direct_reconstruction/I01/result.json', '00593a46f0db0a9ee0d9143470e9aed37f73f25e3936fbaca3f4b2a04c2b5cf1'),
    'I02': ('b16a_missing_eight_direct_reconstruction/I02/result.json', '276f5eccc73a6dd27ebe1b1f2bc61aa6528c5fdd71cf9bd79d3fbf17f9261981'),
    'I03': ('b16a_missing_eight_direct_reconstruction/I03/result.json', 'd8283d0dbb389ec3dba187b0d6bac3603170160eaab9f8dd4b8d6682e99aafa1'),
    'I30': ('b16a_missing_four_bound3/I30/result.json', 'be0096a706c0b8d57bd4e5ab0cb43cb86390823799f875a85ed3963b61a49355'),
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def main():
    if not __debug__:
        raise RuntimeError('Exact assertions must be enabled')
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    declaration = HERE / 'b16a_missing_eight_i_domains/manifest.json'
    assert sha(declaration) == DOMAIN_MANIFEST_SHA
    domains = json.loads(declaration.read_text())
    domain_hashes = {entry['file']: entry['sha256'] for entry in domains['records']}
    args.output.mkdir(parents=True, exist_ok=False)
    pieces = []
    inputs = {str(declaration): DOMAIN_MANIFEST_SHA, str(Path(__file__).resolve()): sha(__file__)}
    for label, (relative, digest) in RECORDS.items():
        source = PAYLOAD / relative
        assert sha(source) == digest
        record = json.loads(source.read_text())
        domain = declaration.parent / (label + '.json')
        assert sha(domain) == domain_hashes[domain.name]
        domain_literal = json.loads(domain.read_text())
        assert domain_literal['schema'] == 'B_original_I_quarter_restriction_v1'
        assert record['initial'] == domain_literal['final']
        assert record['status'] == 'CANDIDATE_CLOSED' and 'final' not in record
        target = args.output / label
        target.mkdir()
        (target / 'SOURCE_RECORD.json').write_bytes(source.read_bytes())
        assert sha(target / 'SOURCE_RECORD.json') == digest
        node = dict(index=0, parent=None, depth=0, choice=None,
                    initial=deepcopy(record['initial']), status='CANDIDATE_CLOSED',
                    children=[], record=deepcopy(record))
        dump(target / 'node_0000.json', node)
        assert json.loads((target / 'node_0000.json').read_text())['record'] == record
        sources = {str(source): digest, str(target.resolve() / 'SOURCE_RECORD.json'): digest,
                   str(declaration): DOMAIN_MANIFEST_SHA, str(Path(__file__).resolve()): sha(__file__)}
        manifest = dict(schema='B_proxy_first_complete_physical_tree_discovery_v1',
            parent=dict(path=str(domain), sha256=sha(domain)), sources=sources,
            accepted_geometric_sources={}, completed=True, status='CANDIDATE_CLOSED',
            original_cells_closed=0, masks_closed=0,
            nodes=[dict(index=0, file='node_0000.json', sha256=sha(target / 'node_0000.json'),
                        status='CANDIDATE_CLOSED', depth=0)],
            attachment=dict(kind='EXACT_PUBLISHED_RECORD_ON_IDENTICAL_RECONSTRUCTED_QUARTER_STATE',
                published_record_sha256=digest, exact_initial_state_identity_checked=True,
                old_parent_metadata_used_as_arithmetic=False,
                unavailable_zero_round_parent_recreated=False,
                independent_complete_piece_replay_required=True))
        dump(target / 'manifest.json', manifest)
        pieces.append(dict(label=label, tiles=[domain_literal['tile']],
            domain=dict(path=str(domain), sha256=sha(domain)),
            proof=dict(path=str((target / 'manifest.json').resolve()), sha256=sha(target / 'manifest.json')),
            kind='tree', original_published_record=dict(path=str(source), sha256=digest),
            exact_record_initial_equals_domain_final=True))
        for path in [domain, source, target / 'SOURCE_RECORD.json', target / 'node_0000.json', target / 'manifest.json']:
            inputs[str(path.resolve())] = sha(path)
    result = dict(schema='B16a_five_published_record_exact_quarter_attachments_v1',
        status='CANDIDATE_EXACT_ATTACHMENTS_FRESH_REPLAY_REQUIRED', original_id='negative-16a2fc93c8d133f0',
        pieces=pieces, inputs=inputs, lost_zero_round_parent_not_recreated=True,
        no_numerical_search=True, new_original_cells=0, new_masks=0)
    dump(args.output / 'ASSEMBLY.json', result)
    print(json.dumps(dict(status=result['status'], pieces=len(pieces),
        assembly_sha256=sha(args.output / 'ASSEMBLY.json'))), flush=True)

if __name__ == '__main__':
    main()
