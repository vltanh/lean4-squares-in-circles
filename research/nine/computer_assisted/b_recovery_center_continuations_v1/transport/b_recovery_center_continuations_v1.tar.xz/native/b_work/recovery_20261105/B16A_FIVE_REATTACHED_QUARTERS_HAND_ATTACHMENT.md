# Five retained B16a quarter proofs after exact parent reattachment

The original I-center domain is partitioned by the unchanged four-by-four
closed grid with SHA256
`5f3da1873c074eeee6a3343bc2aa5406b41e6376cce8b708694f30024edfda2d`.
Its whole-original bound parent has SHA256
`69ddd2dcc5383c3259187588a890ddadb4a6545e8bdcc11e653bdfb8bb6b3886`.
The original ID remains `negative-16a2fc93c8d133f0`; the original path and all
physical predicates are unchanged.

The frozen old quarter constructor reproduces every one of the eight domain
records and the entire domain manifest byte-for-byte, including the published
manifest hash `d1347f13c6056ff83b6c94ddcd6ab5c6fa43ada5d91f7c1f18f7a20493eea9cc`.
This deterministic reconstruction uses only rational interpolation between the
certified grid endpoints. It does not infer or reconstruct numerical search
history.

The availability archive retained complete terminal records for I00, I01,
I02, I03, and I30. Each retained record's literal initial state equals its
reconstructed quarter's entire state, including the ID/path, all nine angles,
eighteen positions, thirty-six scalar bounds, and all recorded pair differences.
Each new one-node tree is attached directly to that exact quarter anchor and
contains the unchanged published record as its record object. The original
record file is preserved byte-for-byte separately and hash-bound.

For I30 the old metadata named an unavailable zero-round OPEN intermediary.
That historical filename and hash remain in the unchanged source record, but
they supply no premise in the new attachment. The exact arithmetic core takes
its initial state from the independently replayed quarter anchor and requires
literal equality with the saved record. It then replays the one saved round.
Thus no bound from the unavailable intermediary is assumed, and no file with
its remembered hash is fabricated. This is a new direct attachment of an old
proof, not a claim to have recovered the old intermediary.

The unchanged original-quarter adapter freshly reconstructs the old parent
proof and quarter restriction. The unchanged partition-piece checker proves
that each one-node tree covers its entire anchor; the unchanged lazy tree and
rational arithmetic checkers replay each record. No new row family, terminal
rule, state inference, or cover rule is introduced.

| Quarter | Retained bound rounds | Deductions | Checked premise rows | Exact terminal |
|---|---:|---:|---:|---|
| I00 | 0 | 0 | 4 | Positive exact reserve |
| I01 | 0 | 0 | 0 | Accepted center-interval exclusion |
| I02 | 0 | 0 | 0 | Accepted center-interval exclusion |
| I03 | 0 | 0 | 0 | Accepted center-interval exclusion |
| I30 | 1 | 181 | 246 | Empty proved pair-difference interval |

The fresh exact process exited 0 and excluded all five entire quarter domains.
All closed grid edges and vertices, all nine originals, their 36 original
corners and pairs, the five original cones, actual AB/BC/EF/FG, strict CD, and
the original radius and mask conditions remain attached. These are the same
five quarter exclusions previously preserved in the availability packet. They
add no original-cell or mask credit. Combined with the six old complete quarter
masters and the three restored complementary-quarter proofs, fourteen of the
sixteen quarters have complete proof evidence. The merged I21/I22 domain is
still OPEN and is being searched separately.
