#!/usr/bin/env python3
"""Exact complete fixed-I cover using independently checked affine induction."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import sys
import time

HERE=Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    assert __debug__
    started=time.monotonic()
    manifest=json.loads((HERE/'SHA256_MANIFEST.json').read_text())
    for name,expected in manifest['files'].items():
        target=(HERE/name).resolve()
        assert target.is_relative_to(HERE) and digest(target)==expected,('changed_frozen_file',name)
    index=json.loads((HERE/'INDEX.json').read_text())
    assert index['schema']=='B_fixed_I_bound_packet_index_v1'
    assert index['target_original']==8 and index['parts']==[4,4]
    assert index['new_original_cells']==1 and index['new_masks']==0
    from verify_b_fixed_tile_bound_terminals import Checker
    checker=Checker(HERE,HERE/'ancestry',HERE)
    from verify_b_bounded_active_psd_tiles import Checker as PSDChecker
    psd_checker=PSDChecker(HERE,HERE/'ancestry',HERE)
    import verify_b_affine_cover as affine
    affine_report,parent=affine.run(index['id'])
    assert affine_report['status']=='PASS_AFFINE_PARTIAL_COVER_REMAINDER_EXPLICIT'
    expected=[list(divmod(t,4))for t in affine_report['remaining_I_tiles']]
    addressed=[entry['tile']for entry in index['bound_tiles']]+[entry['tile']for entry in index['bounded_psd_tiles']]
    assert sorted(addressed)==expected
    assert len(addressed)==len({tuple(t)for t in addressed})
    assert len(expected)==len({tuple(t)for t in expected})
    outcomes={tuple(divmod(e['tile'],4)):dict(e)for e in affine_report['tiles']}
    assert set(outcomes)=={(i,j)for i in range(4)for j in range(4)}
    reports=[]
    psd_reports=[]
    for entry in index['bound_tiles']:
        tile=tuple(entry['tile']);assert outcomes[tile]['status']=='OPEN'
        path=(HERE/entry['certificate']).resolve()
        assert path.is_relative_to(HERE/'data/bounds')
        result=checker.replay(path)
        assert result['status']=='PASS_COMPLETE_PHYSICAL_TILE'
        assert result['id']==index['id'] and result['full_tile']==list(tile) and result['h_tile']is None
        assert result['original_parent_path']==parent['path']
        assert result['original_prefix_replay']['certificate_sha256']==affine_report['prefix_sha256']
        reports.append(result)
        if result['terminal_kind']=='positive_exact_reserve':
            assert F(result['reserve'])>0
            outcomes[tile]=dict(status='PASS_EXACT_BOUND_RESERVE',reserve=result['reserve'],
                               rows=result['terminal_rows'])
        else:
            assert result['terminal_kind']in('exact_interval_or_accepted_terminal','proved_empty_analytic_frame')
            assert result['terminal_rows']==0
            outcomes[tile]=dict(status='PASS_EXACT_BOUND_INTERVAL',rows=0,
                               terminal_kind=result['terminal_kind'])
    for entry in index['bounded_psd_tiles']:
        tile=tuple(entry['tile']);assert outcomes[tile]['status']=='OPEN'
        path=(HERE/entry['certificate']).resolve()
        assert path.is_relative_to(HERE/'data/psd')
        result=psd_checker.replay(path)
        assert result['status']=='PASS_COMPLETE_PHYSICAL_TILE'
        assert result['id']==index['id'] and result['full_tile']==list(tile) and result['h_tile']is None
        assert result['original_parent_path']==parent['path']
        assert result['prior_report']['certificate_sha256']==affine_report['prefix_sha256']
        state_report=result['bound_state_replay']
        assert state_report['status']=='PASS_CERTIFIED_TILE_STATE_OPEN'
        assert state_report['id']==index['id'] and state_report['full_tile']==list(tile)
        assert state_report['original_prefix_replay']['certificate_sha256']==affine_report['prefix_sha256']
        reports.append(state_report);psd_reports.append(result)
        outcomes[tile]=dict(status='PASS_EXACT_PSD_RESERVE',reserve=result['reserve'],
                           rows=result['terminal_rows'])
    table=json.loads((HERE/'COVER_TABLE.json').read_text())
    assert table['id']==index['id'] and table['target_original']==8 and table['parts']==[4,4]
    assert [tuple(e['tile'])for e in table['entries']]==sorted(outcomes)
    for entry in table['entries']:
        actual=outcomes[tuple(entry['tile'])]
        assert entry['status']==actual['status'] and entry['rows']==actual['rows']
        if 'reserve_floor'in entry:
            assert F(actual['reserve'])>=F(entry['reserve_floor'])>0
        elif actual['status']=='PASS_EXACT_BOUND_INTERVAL':
            assert entry['terminal_kind']==actual['terminal_kind']
        else:
            assert entry['label']==actual['label']
    assert all(e['status'].startswith('PASS_EXACT_')for e in outcomes.values())
    assert not any(name in sys.modules for name in('numpy','scipy','highspy'))
    result=dict(schema='complete_B_original_I_bound_cover_v1',id=index['id'],path=parent['path'],
        status='PASS_COMPLETE_ORIGINAL_PARENT',cover_rectangles=16,
        original_physical_squares=9,original_corners=36,original_pairs=36,
        strict_CD_original_path_retained=True,fixed_closed_rectangle_cover=[4,4],
        terminal_rows=sum(e['rows']for e in outcomes.values()),
        bound_induction_rows=sum(r['printed_rows_checked']-r['terminal_rows']for r in reports),
        bound_induction_deductions=sum(r['bound_deductions']for r in reports),
        bound_induction_rounds=sum(r['bound_rounds']for r in reports),
        direct_affine_terminals=sum(e['status']=='PASS_EXACT_POSITIVE_RESERVE'for e in outcomes.values()),
        direct_interval_terminals=sum(e['status']=='PASS_EXACT_INTERVAL'for e in outcomes.values()),
        bound_reserve_terminals=sum(e['status']=='PASS_EXACT_BOUND_RESERVE'for e in outcomes.values()),
        bound_interval_terminals=sum(e['status']=='PASS_EXACT_BOUND_INTERVAL'for e in outcomes.values()),
        quadratic_terminals=len(psd_reports),affine_report=affine_report,
        bound_reports=reports,psd_reports=psd_reports,table_sha256=digest(HERE/'COVER_TABLE.json'),
        source_bound_original_ancestor_replayed=True,all_workspace_reads_confined_to_packet=True,
        numerical_producer_or_optimizer_imported=False,new_original_cells=1,new_masks=0,
        whole_mask_closed=False,lean_lake_ci_run=False,seconds=time.monotonic()-started)
    (HERE/'COMPLETE_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in('id','status','cover_rectangles','terminal_rows',
        'bound_induction_rows','new_original_cells','new_masks','seconds')}),flush=True)
    return result

if __name__=='__main__':main()
