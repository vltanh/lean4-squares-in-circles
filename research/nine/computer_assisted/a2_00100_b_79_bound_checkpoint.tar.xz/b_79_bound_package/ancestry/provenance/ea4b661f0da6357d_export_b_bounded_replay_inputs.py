#!/usr/bin/env python3
"""Export literal antecedents; every exported statement remains untrusted."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
from fractions import Fraction as Q
from pathlib import Path
import json
import sys
import b_bounded_tile_model as BM


def printed(rows, indices):
    return [dict(index=i, name=rows[i][2], coefficients=[[k, str(v)] for k, v in rows[i][0]],
                 rhs=str(rows[i][1])) for i in sorted(indices)]


def export(folder):
    folder = Path(folder)
    candidate_path = folder / 'active_box_exact_candidate.json'
    diagnostic_path = folder / 'diagnostics.json'
    candidate = json.loads(candidate_path.read_text())
    diagnostic = json.loads(diagnostic_path.read_text())
    rows, absolute, state, details, frozen = BM.collect(
        candidate['id'], tuple(candidate['tile']),
        None if candidate['h_tile'] is None else tuple(candidate['h_tile']))
    assert details['physical_state'] == candidate['physical_state'] == diagnostic['physical_state']
    assert frozen['sources'] == diagnostic['sources']
    linear_count = details['metadata']['initial_linear_rows']
    linear = rows[:linear_count]
    rlt_indices = set()
    affine_indices = set()
    mapping = []
    source_indices = candidate['source_indices']
    for entry in candidate['terminal']['printed_rows']:
        if entry['name'].startswith('moment_rlt_'):
            rlt_indices.add(int(entry['name'].split('_')[3]))
        active = entry['index']
        if active < len(source_indices) and source_indices[active] < linear_count:
            source = source_indices[active]
            affine_indices.add(source)
            mapping.append(dict(active_index=active, source_index=source))
            assert entry['name'] == linear[source][2]
            assert [(k, Q(v)) for k, v in entry['coefficients']] == list(linear[source][0])
            assert Q(entry['rhs']) == linear[source][1]
    assert all(0 <= i < linear_count for i in rlt_indices)
    result = dict(schema='untrusted_active_psd_replay_inputs_v1', id=candidate['id'], tile=candidate['tile'],
                  candidate_sha256=BM.J.sha(candidate_path), diagnostics_sha256=BM.J.sha(diagnostic_path),
                  linear_row_count=linear_count, rlt_antecedents=printed(linear, rlt_indices),
                  affine_sources=printed(linear, affine_indices), active_affine_source_mapping=mapping,
                  inherited_squares=frozen['squares'], source_sha256={__file__: BM.J.sha(__file__)},
                  original_closure_credit=0)
    (folder / 'independent_replay_inputs.json').write_text(json.dumps(result, indent=2) + '\n')
    print(candidate['id'], candidate['tile'], 'EXPORTED', len(rlt_indices), 'RLT',
          len(affine_indices), 'AFFINE', len(frozen['squares']), 'INHERITED SQUARES', flush=True)


if __name__ == '__main__':
    for path in sys.argv[1:]:
        export(path)
