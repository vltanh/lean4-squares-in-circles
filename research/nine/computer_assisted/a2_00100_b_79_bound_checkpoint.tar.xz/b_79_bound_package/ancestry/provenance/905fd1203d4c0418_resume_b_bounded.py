#!/usr/bin/env python3
"""Finish only previously declared B induction limits from fully saved states."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,copy
from pathlib import Path
HERE=Path(__file__).resolve().parent;OLD=Path('/workspace/scratch/29af4f6e10bf')
sys.path.insert(0,str(OLD/'current_proof'))
import v3_whole_parent_pass as M
BASE_COLLECT=M.collect
CELLS={c['id']:c for c in json.loads((HERE.parent/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json').read_text())['cells']}

def run(id):
 cell=CELLS[id];assert cell['status']=='OPEN'
 source=HERE/'continued'/(id+'.json')
 if not source.exists():source=OLD/'b_macro/v2/results'/(id+'.json')
 prefix=json.loads(source.read_text());assert prefix['status']=='OPEN'and prefix['path']==cell['path']
 for field in ['sources','additional_sources']:
  for path,h in prefix.get(field,{}).items():assert M.sha(path)==h,(path,'changed source')
 inherited=len(prefix['rounds']);limit=13-inherited;assert limit>0
 final=prefix['rounds'][-1]
 if 'final_angles' not in prefix:
  for target,key in [('final_angles','angles_after'),('final_positions','positions_after'),('final_scalar','scalar_after'),('final_differences','differences_after')]:prefix[target]=final[key]
  completion='resumed_from_last_fully_saved_round_no_unsaved_state_used'
 else:completion='resumed_from_explicit_final_state'
 before={tuple(d['pair']):M.K.box(d['intervals'])for d in prefix['final_differences']}
 def initial(c):
  _,_,choices=M.V.reconstruct(c['path'])
  return {'id':c['id'],'path':c['path'],'angles':M.K.box(prefix['final_angles']),'positions':M.K.box(prefix['final_positions']),'scalar':M.K.box(prefix['final_scalar']),'choices':choices},prefix['prior'],None
 def collect(state,diffs):
  merged=dict(before)
  for p,v in diffs.items():merged[p]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(merged[p],v))
  return BASE_COLLECT(state,merged)
 def save(record):
  out=copy.deepcopy(record)
  for field in ['sources','additional_sources']:
   combined=dict(prefix.get(field,{}))
   for k,v in out.get(field,{}).items():assert k not in combined or combined[k]==v;combined[k]=v
   out[field]=combined
  out['additional_sources'][str(Path(__file__))]=M.sha(__file__)
  out['prior']=prefix['prior'];out['resume_input']={'file':str(source),'sha256':M.sha(source),'state_convention':completion,'inherited_rounds':inherited,'remaining_declared_rounds':limit}
  for k,rr in enumerate(out['rounds']):
   if k==0:rr['differences_before']=prefix['final_differences']
   rr['round']+=inherited
  for field in ['terminal','final_test']:
   rr=out.get(field)
   if field=='terminal'and rr:rr=rr.get('state')
   if rr:
    if rr['round']==0:rr['differences_before']=prefix['final_differences']
    rr['round']+=inherited
  out['rounds']=copy.deepcopy(prefix['rounds'])+out['rounds']
  if not record['rounds']:out['final_differences']=prefix['final_differences']
  out['independent_review_status']='PENDING_FULL_REPLAY'
  dest=HERE/'resumed';dest.mkdir(exist_ok=True);(dest/(id+'.json')).write_text(json.dumps(out,indent=2)+'\n')
 M.initial=initial;M.collect=collect;M.save=save;M.HERE=HERE;M.VERSION=prefix['schema']
 return M.run(cell,limit)

if __name__=='__main__':
 for id in ['negative-79cdbfcbed2f1fac','negative-d09093538801d014','negative-2652afcd308ef1ea']:
  if not(HERE/'resumed'/(id+'.json')).exists():run(id)
