#!/usr/bin/env python3
"""Bounded affine bound induction inside one explicitly guarded I/H tile.

This is discovery only. A whole-parent claim requires every cover member and
independent reconstruction of each nonnegative weighted bound proof.
"""
import os
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"):os.environ[key]="1"
from pathlib import Path
from fractions import Fraction as Q
import json,sys
import b_tile_model as BM
HERE=Path(__file__).resolve().parent
IDENT=sys.argv[1];TILE=tuple(map(int,sys.argv[2:4]));H_TILE=tuple(map(int,sys.argv[4:6])) if len(sys.argv)>=6 else None
ROUNDS=int(sys.argv[6]) if len(sys.argv)>=7 else 3
assert 0<=ROUNDS<=3
D=BM.D;M=D.P.M
rows,absolute,initial_state,details,frozen=BM.collect(IDENT,TILE,H_TILE)
manifest=json.loads((HERE/"fixed_i_grid_capacity"/IDENT/"manifest.json").read_text())
original,dd,dg,prior=D.read_prefix(Path(manifest["parent_source"]))
assert not dg
OUT=HERE/("bounded_tile_B_"+IDENT+"_"+"_".join(map(str,TILE+(H_TILE or ()))))
OUT.mkdir(exist_ok=True)
matrices=[tuple(tuple(map(Q,row))for row in matrix) for matrix in details["area_matrices"]]
original_collect=M.collect

def guarded_collect(state,differences):
    rr,aa,terminal,pos,scalar,diffs,guards=original_collect(state,differences)
    if terminal is None:
        rr += BM.FC.rows(diffs)
        rr += BM.AREA.generate_linear(diffs,matrices=matrices)
    return rr,aa,terminal,pos,scalar,diffs,guards

def save(record):
    record["schema"]="B_fixed_tile_affine_bound_induction_discovery_v1"
    record["scope"]="ONE_CLOSED_RECTANGLE_OF_DECLARED_COMPLETE_PARENT_COVER"
    record["originals_closed"]=0
    record["tile_context"]=details
    record["initial_differences"]=M.render_diff(dd)
    record["additional_sources"]={str(Path(p).resolve()):BM.J.sha(p) for p in (__file__,BM.__file__,BM.FC.__file__,BM.AREA.__file__)}
    (OUT/"bound_rounds.json").write_text(json.dumps(record,indent=2)+"\n")

M.initial=lambda cell:(dict(initial_state),dict(kind="explicit_frozen_I_H_tile",source=prior,manifest=manifest),None)
M.collect=guarded_collect
M.save=save
# M.run begins its local difference dictionary empty; preserve the entire
# source-bound inherited difference state in its first collection.
first=[True]
def inherited_collect(state,differences):
    if first[0]:
        assert not differences
        differences.update(dd)
        first[0]=False
    return guarded_collect(state,differences)
M.collect=inherited_collect
M.run(dict(id=IDENT,path=initial_state["path"]),rounds=ROUNDS)
