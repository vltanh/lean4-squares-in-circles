#!/usr/bin/env python3
"""Independent extended exact affine induction in an original B I/HI tile.

The original prefix, exact closed cover rectangle, every printed physical
row, every nonnegative weighted bound proof, and the final contradiction
are reconstructed independently. No producer or optimizer is imported.
This checker certifies one fixed tile, never an entire original-cell cover.
"""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

from verify_b_hi_active_psd_tiles import four_affine, area_affine
from independent_fixed_bound_terminals import empty_interval_witness, verify_interval_terminal

HERE=Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def box(values):
    result=tuple(tuple(map(F,ab))for ab in values)
    assert all(len(ab)==2 and ab[0]<=ab[1]for ab in result)
    return result

def canonical(row,n):
    terms,rhs,name=row
    coefficients={}
    for k,v in terms:
        assert type(k)is int and 0<=k<n
        coefficients[k]=coefficients.get(k,F(0))+F(v)
    return tuple((k,v)for k,v in sorted(coefficients.items())if v),F(rhs),name

class Checker:
    def __init__(self,context=None,ancestry=None,strict_root=None):
        if context is None:
            assert ancestry is None and strict_root is None
            sys.path.insert(0,'/workspace/scratch/fee12ff81cbd/b_family')
            import verify_b_affine_cover as V
            self.J=V.install()
            self.locate=lambda p:Path(p)
        else:
            assert ancestry is not None
            sys.path.insert(0,str(Path(context).resolve()))
            from b_replay_context import install
            self.J,self.locate=install(Path(ancestry).resolve(),strict_root)
        self.K=self.J.K
        self.priors={}

    def source_checks(self,record):
        sources={}
        for group in(record['sources'],record['additional_sources'],record['prior']['manifest']['sources']):
            for name,h in group.items():
                assert name not in sources or sources[name]==h
                sources[name]=h
        for name,h in sources.items():
            assert digest(self.locate(name))==h,('changed_source',name)
        return sources

    def original_and_tile(self,record):
        K=self.K
        prior=record['prior'];details=record['tile_context']
        assert prior['kind']=='explicit_frozen_I_H_tile'
        assert prior['source']==details['prior']
        source=prior['source'];prefix=self.locate(source['path'])
        assert digest(prefix)==source['sha256']
        frozen=json.loads(prefix.read_text())
        assert frozen['schema']==source['schema']
        assert frozen['id']==record['id']
        assert frozen['path']==record['path']==details['original_parent_path']
        key=(str(prefix),digest(prefix))
        if key not in self.priors:
            report,parent=self.J.replay(prefix,allow_open=True,return_state=True)
            assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
            self.priors[key]=(report,parent)
        prior_report,parent=self.priors[key]
        assert parent['id']==record['id'] and parent['path']==record['path']
        manifest_path=self.locate(details['manifest_path'])
        assert digest(manifest_path)==details['manifest_sha256']
        manifest=json.loads(manifest_path.read_text())
        assert manifest==prior['manifest']
        assert manifest['id']==parent['id'] and manifest['path']==parent['path']
        assert manifest['target_original']==8 and manifest['original_count']==9
        assert manifest['grid_size']==[4,4] and manifest['adaptive_splits']==0
        assert manifest['parent_source']==source['path'] and manifest['parent_sha256']==source['sha256']
        assert manifest['center_box']==K.view(parent['positions'][16:18])
        tile=details['tile'];h_tile=details['h_tile']
        assert isinstance(tile,list)and len(tile)==2 and details['parts']==4
        pos=list(parent['positions'])
        for axis,index in enumerate(tile):
            assert type(index)is int and 0<=index<4
            lo,hi=parent['positions'][16+axis]
            pos[16+axis]=(lo+(hi-lo)*F(index,4),lo+(hi-lo)*F(index+1,4))
        assert details['rectangle']==K.view(pos[16:18])
        if h_tile is None:
            assert details['h_parts']is None and details['h_rectangle']==[]
        else:
            assert isinstance(h_tile,list)and len(h_tile)==2 and details['h_parts']==[2,4]
            for axis,(index,parts)in enumerate(zip(h_tile,(2,4))):
                assert type(index)is int and 0<=index<parts
                lo,hi=parent['positions'][14+axis]
                pos[14+axis]=(lo+(hi-lo)*F(index,parts),lo+(hi-lo)*F(index+1,parts))
            assert details['h_rectangle']==K.view(pos[14:16])
        assert record['initial_differences']==K.diffview(parent['differences'])
        return dict(parent,positions=tuple(pos)),prior_report

    def rebuild_state(self,rr,state):
        K=self.K
        assert box(rr['angles_before'])==state['angles']
        assert box(rr['positions_before'])==state['positions']
        assert box(rr['scalar_before'])==state['scalar']
        assert rr['differences_before']==K.diffview(state['differences'])
        base,bounds,pos,scalar,diffs,guards=K.rebuild(state['path'],state['angles'],state['positions'],
                                                  state['choices'],state['scalar'],state['differences'])
        assert box(rr['propagated_positions'])==pos
        assert box(rr['physical_scalar_intersection'])==scalar
        assert rr['effective_differences']==K.diffview(diffs)
        assert rr['three_square_guards'][:len(guards)]==guards
        assert isinstance(rr['rows'],int)and len(base)<=rr['rows']
        assert all(v>=0 for v in bounds)
        return base,bounds,pos,scalar,diffs

    def printed_rows(self,saved,total,base,bounds,scalar,diffs,angles):
        J=self.J
        indices=[e['index']for e in saved]
        assert len(indices)==len(set(indices))
        assert all(type(k)is int and 0<=k<total for k in indices)
        rows=list(base)
        rows.extend([((),F(0),'UNUSED_UNVERIFIED')]*max(0,max(indices,default=-1)+1-len(rows)))
        newnames=[]
        for entry in saved:
            k,name=entry['index'],entry['name']
            if k>=len(base):
                if name.startswith('planar_four_center_sum_'):
                    rebuilt=four_affine(name,diffs)
                elif name.startswith('square_area_moment_secant_'):
                    rebuilt=area_affine(name,diffs)
                else:
                    rebuilt=J.rebuild_joint(name,scalar,diffs,angles,J.point_row)
                rows[k]=rebuilt
                newnames.append(name)
            assert canonical(rows[k],len(bounds))==canonical((entry['coefficients'],entry['rhs'],name),len(bounds)),name
        return rows,newnames

    def replay(self,filename,allow_open=False,return_state=False):
        started=time.monotonic();path=Path(filename).resolve();record=json.loads(path.read_text())
        assert record['schema']=='B_fixed_tile_affine_bound_induction_discovery_v1'
        assert record['scope']=='ONE_CLOSED_RECTANGLE_OF_DECLARED_COMPLETE_PARENT_COVER'
        assert record['status']in('OPEN','CANDIDATE_CLOSED')
        assert record['new_branch_nodes']==0 and record['originals_closed']==0
        assert type(record['maximum_new_rounds'])is int and 0<=record['maximum_new_rounds']<=3
        assert len(record['rounds'])<=record['maximum_new_rounds']
        sources=self.source_checks(record)
        state,prior_report=self.original_and_tile(record)
        K=self.K;printed=0;deductions=0;newrules=[];variable_counts=set()
        early_closed=False;terminal_evidence=None
        round_reports=[]
        for ri,rr in enumerate(record['rounds']):
            assert rr['round']==ri
            base,bounds,pos,scalar,diffs=self.rebuild_state(rr,state)
            if ri==0:
                physical=record['tile_context']['physical_state']
                assert physical==dict(angles=K.view(state['angles']),positions=K.view(pos),
                                      scalar=K.view(scalar),differences=K.diffview(diffs))
            assert rr['absolute_variable_bounds']==list(map(str,bounds))
            rows,names=self.printed_rows(rr['printed_rows'],rr['rows'],base,bounds,scalar,diffs,state['angles'])
            newrules+=names;variable_counts.add(len(bounds))
            nextpos=[list(ab)for ab in pos];nextscalar=[list(ab)for ab in scalar]
            nextdiff={pair:[list(ab)for ab in ds]for pair,ds in diffs.items()}
            used=set();objectives=set()
            for proposal in rr['proposals']:
                sign,key=proposal['sign'],proposal['key']
                assert type(sign)is int and sign in(-1,1)
                if proposal['kind']=='scalar':
                    assert type(key)is int and 0<=key<54
                    assert proposal['objective']==[[key,sign]]
                    target=nextpos[key]if key<18 else nextscalar[key-18]
                else:
                    assert proposal['kind']=='difference'and isinstance(key,list)and len(key)==3
                    i,j,axis=key;assert all(type(v)is int for v in key)
                    assert 0<=i<j<9 and axis in(0,1)
                    assert proposal['objective']==[[2*j+axis,sign],[2*i+axis,-sign]]
                    target=nextdiff[i,j][axis]
                objective=tuple(map(tuple,proposal['objective']));assert objective not in objectives
                objectives.add(objective)
                upper=K.audit_bound(rows,bounds,proposal)
                if sign==1:target[1]=min(target[1],upper)
                else:target[0]=max(target[0],-upper)
                used.update(k for k,w in proposal['weights']);deductions+=1
            assert used=={entry['index']for entry in rr['printed_rows']}
            printed+=len(used)
            pos=tuple(map(tuple,nextpos));scalar=tuple(map(tuple,nextscalar))
            diffs={pair:tuple(map(tuple,ds))for pair,ds in nextdiff.items()}
            witness=empty_interval_witness(pos+scalar,'proved_empty_original_variable_interval')
            if witness is None:
                for pair,ds in diffs.items():
                    witness=empty_interval_witness(ds,'proved_empty_difference_interval')
                    if witness is not None:witness['pair']=list(pair);break
            if witness is not None:
                assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='proved_empty_interval'
                assert ri==len(record['rounds'])-1 and 'angles_after'not in rr
                early_closed=True;terminal_evidence=witness
            if early_closed:
                # M.run saves the preceding state after this early exit;
                # only its local difference dictionary has already advanced.
                assert box(record['final_angles'])==state['angles']
                assert box(record['final_positions'])==state['positions']
                assert box(record['final_scalar'])==state['scalar']
                assert record['final_differences']==K.diffview(diffs)
                round_reports.append(dict(round=ri,deductions=len(rr['proposals']),printed_rows=len(used),physical_frame_inferences=0))
                break
            angles=K.angles_from_scalar(state['angles'],scalar,rr['physical_frame_inferences'])
            analytic=K.analytic(angles)
            intersection=tuple((max(lo,a),min(hi,b))for(lo,hi),(a,b)in zip(scalar,analytic))
            witness=empty_interval_witness(intersection,'proved_empty_analytic_frame',18)
            if witness is not None:
                assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='proved_empty_analytic_frame'
                assert ri==len(record['rounds'])-1 and 'angles_after'not in rr
                index=witness['index']-18
                witness.update(certified_interval=list(map(str,scalar[index])),
                    analytic_interval=list(map(str,analytic[index])),derived_slope_interval=list(map(str,angles[index%9])))
                terminal_evidence=witness;early_closed=True
                assert box(record['final_angles'])==state['angles']
                assert box(record['final_positions'])==state['positions']
                assert box(record['final_scalar'])==state['scalar']
                assert record['final_differences']==K.diffview(diffs)
                round_reports.append(dict(round=ri,deductions=len(rr['proposals']),printed_rows=len(used),physical_frame_inferences=9))
                break
            scalar=box(intersection)
            assert box(rr['angles_after'])==angles and box(rr['positions_after'])==pos
            assert box(rr['scalar_after'])==scalar and rr['differences_after']==K.diffview(diffs)
            state=dict(state,angles=angles,positions=pos,scalar=scalar,differences=diffs)
            round_reports.append(dict(round=ri,deductions=len(rr['proposals']),printed_rows=len(used),
                                      physical_frame_inferences=9))
            print(record['id'],'PASS FIXED-TILE ROUND',ri,len(rr['proposals']),flush=True)
        if not early_closed:
            assert box(record['final_angles'])==state['angles']
            assert box(record['final_positions'])==state['positions']
            assert box(record['final_scalar'])==state['scalar']
            assert record['final_differences']==K.diffview(state['differences'])
        terminal_rows=0;reserve=None;complete=early_closed
        terminal_kind=record.get('terminal',{}).get('kind')
        if record['status']=='CANDIDATE_CLOSED'and not early_closed and terminal_kind=='exact_interval_or_accepted_terminal':
            terminal=record['terminal'];assert terminal['state']['round']==len(record['rounds'])
            terminal_evidence=verify_interval_terminal(terminal,state,K)
            complete=True
        elif record['status']=='CANDIDATE_CLOSED'and not early_closed:
            terminal=record['terminal'];assert terminal['kind']=='positive_exact_reserve'
            rr=terminal['state'];assert rr['round']==len(record['rounds'])
            base,bounds,pos,scalar,diffs=self.rebuild_state(rr,state)
            rows,names=self.printed_rows(terminal['rows'],rr['rows'],base,bounds,scalar,diffs,state['angles'])
            newrules+=names;variable_counts.add(len(bounds))
            assert terminal['absolute_variable_bounds']==list(map(str,bounds))
            used={k for k,w in terminal['weights']}
            assert used=={entry['index']for entry in terminal['rows']}
            co,rhs=K.sum_rows(rows,bounds,terminal['weights'])
            reserve=-rhs-sum(bound*abs(c)for bound,c in zip(bounds,co))
            assert reserve>0 and reserve==F(terminal['reserve'])
            assert terminal['weighted_coefficients']==list(map(str,co))and terminal['weighted_rhs']==str(rhs)
            terminal_rows=len(used);printed+=terminal_rows;complete=True
        elif record['status']=='OPEN':
            assert allow_open,'An OPEN bound record certifies a state only; explicit --allow-open required.'
        detail=record['tile_context']
        report=dict(schema='independent_B_extended_fixed_tile_affine_bound_replay_v1',id=record['id'],
            status='PASS_COMPLETE_PHYSICAL_TILE'if complete else'PASS_CERTIFIED_TILE_STATE_OPEN',
            tile=detail['tile'],h_tile=detail['h_tile'],full_tile=detail['tile']+(detail['h_tile']or[]),
            rectangle=detail['rectangle'],h_rectangle=detail['h_rectangle'],
            original_parent_path=record['path'],original_prefix_replay=prior_report,
            inherited_difference_intervals=2*len(state['differences']),
            original_variables=54,affine_variable_counts=sorted(variable_counts),
            bound_rounds=len(round_reports),bound_deductions=deductions,round_reports=round_reports,
            printed_rows_checked=printed,terminal_rows=terminal_rows,reserve=str(reserve)if reserve is not None else None,
            terminal_kind=terminal_kind,terminal_label=record.get('terminal',{}).get('label',terminal_kind),
            terminal_evidence=terminal_evidence,early_exit_stale_final_fields_used_as_derived_state=False,
            independently_rebuilt_new_rule_counts=dict(Counter(name.split('_')[0]for name in newrules)),
            independently_rebuilt_four_center_rows=sum(name.startswith('planar_four_center_sum_')for name in newrules),
            independently_rebuilt_area_rows=sum(name.startswith('square_area_moment_secant_')for name in newrules),
            certificate_sha256=digest(path),checker_sha256=digest(__file__),verified_source_bindings=len(sources),
            unsupported_rules_accepted=False,producer_or_optimizer_imported=False,
            unused_moment_discovery_metadata_is_not_a_premise=True,
            seconds=time.monotonic()-started,whole_parent_cover_checked=False,new_original_cells=0,new_masks=0)
        print(record['id'],'FIXED-TILE BOUND REPLAY',report['status'],'rows',printed,flush=True)
        return(report,state)if return_state else report

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('certificates',type=Path,nargs='+')
    ap.add_argument('--context',type=Path)
    ap.add_argument('--ancestry',type=Path)
    ap.add_argument('--strict-root',type=Path)
    ap.add_argument('--allow-open',action='store_true')
    ap.add_argument('--report',type=Path,required=True)
    args=ap.parse_args();checker=Checker(args.context,args.ancestry,args.strict_root)
    results=[checker.replay(path,args.allow_open)for path in args.certificates]
    keys=[(r['id'],tuple(r['full_tile']))for r in results];assert len(set(keys))==len(keys)
    answer=dict(schema='independent_B_extended_fixed_tile_affine_bound_batch_v1',
        status='PASS_ALL_LISTED_PHYSICAL_TILES'if all(r['status']=='PASS_COMPLETE_PHYSICAL_TILE'for r in results)else'PASS_LISTED_BOUND_STATES',
        tiles=len(results),bound_deductions=sum(r['bound_deductions']for r in results),
        printed_rows_checked=sum(r['printed_rows_checked']for r in results),tile_reports=results,
        whole_parent_cover_checked=False,new_original_cells=0,new_masks=0)
    args.report.write_text(json.dumps(answer,indent=2)+'\n')
    print(json.dumps({k:v for k,v in answer.items()if k!='tile_reports'},indent=2))

if __name__=='__main__':main()
