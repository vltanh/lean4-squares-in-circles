#!/usr/bin/env python3
"""Independent exact replay of fixed B I or HI original-center tiles.

The replay imports only standard-library independent physical checkers.
Producer-exported affine antecedents are untrusted literal data. Every used
row is reconstructed, all RLT antecedents are proved in the same tile, every
PSD row is an explicit negative rational square, and the final sum is exact.
No floating-point state, eigenvalue, solver status, or discovery row count is
a mathematical premise. A tile check does not claim a whole-parent closure.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import argparse
import hashlib
import importlib
import json
import re
import sys
import time

N = 54
SIZE = N+N*(N+1)//2
WEIGHT_SCALE = 1 << 40
HERE = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def canonical(row):
    terms, rhs, name = row
    co = {}
    for k, value in terms:
        assert type(k) is int and 0 <= k < SIZE
        co[k] = co.get(k, F(0))+F(value)
    return tuple((k, v) for k, v in sorted(co.items()) if v), F(rhs), name

def literal(entry):
    return canonical((entry['coefficients'], entry['rhs'], entry['name']))

def box(values):
    return tuple(tuple(map(F, ab)) for ab in values)

def named_box_rows(bounds):
    """Independent enumeration for the appended full McCormick box block."""
    names = []
    for i in range(N):
        names += [f'moment_variable_upper_{i}', f'moment_variable_lower_{i}']
    for i in range(N):
        for j in range(i, N):
            a, b = bounds[i]
            c, d = bounds[j]
            names += [f'moment_mccormick_lower_{i}_{j}_{x}_{y}' for x, y in ((a,c),(b,d))]
            names += [f'moment_mccormick_upper_{i}_{j}_{x}_{y}' for x, y in ((a,d),(b,c))]
            if i == j:
                names += [f'moment_square_nonnegative_{i}', f'moment_square_midpoint_{i}_{(a+b)/2}']
    assert len(names) == 6156
    return names

def subset(values):
    answer = tuple(map(int, values))
    assert tuple(sorted(set(answer))) == answer
    assert all(0 <= i < 9 for i in answer)
    return answer

def energy_polynomial(name, I):
    parts = name.split('_')
    assert parts[:4] == ['planar','four','center','moment'] and len(parts) == 8
    selected = subset(parts[4:])
    assert len(selected) == 4
    poly = I.number(8)
    for i, j in combinations(selected, 2):
        for axis in (0, 1):
            delta = I.minus(I.variable(2*j+axis), I.variable(2*i+axis))
            poly = I.minus(poly, I.product(delta, delta))
    return canonical(I.inequality(poly, name))

def area_polynomial(name, I):
    parts = name.split('_')
    assert parts[:4] == ['square','area','moment','quadratic'] and len(parts) == 9
    selected = subset(parts[4].split('-'))
    assert 2 <= len(selected) <= 9
    a, b, c, d = map(F, parts[5:])
    k = len(selected)
    lower = F(7*k**3,44)*abs(a*d-b*c)-F(k*k,12)*(a*a+b*b+c*c+d*d)
    poly = I.number(lower)
    for i, j in combinations(selected, 2):
        dx = I.minus(I.variable(2*j), I.variable(2*i))
        dy = I.minus(I.variable(2*j+1), I.variable(2*i+1))
        for x, y in ((a,b),(c,d)):
            projected = I.combine(I.times_constant(dx,x), I.times_constant(dy,y))
            poly = I.minus(poly, I.product(projected, projected))
    return canonical(I.inequality(poly, name))

def four_affine(name, differences):
    parts = name.split('_')
    assert parts[:4] == ['planar','four','center','sum'] and len(parts) == 8
    selected = subset(parts[4:])
    assert len(selected) == 4
    terms, rhs = {}, F(-8)
    for i, j in combinations(selected, 2):
        for axis, (lo, hi) in enumerate(differences[i,j]):
            rhs -= lo*hi
            for k, scale in ((2*i+axis,1),(2*j+axis,-1)):
                terms[k] = terms.get(k,F(0))+scale*(lo+hi)
    return canonical((list(terms.items()),rhs,name))

def area_affine(name, differences):
    parts = name.split('_')
    assert parts[:4] == ['square','area','moment','secant'] and len(parts) == 9
    selected = subset(parts[4].split('-'))
    assert 2 <= len(selected) <= 9
    a,b,c,d = map(F,parts[5:])
    k = len(selected)
    rhs = F(k*k,12)*(a*a+b*b+c*c+d*d)-F(7*k**3,44)*abs(a*d-b*c)
    terms = {}
    for i,j in combinations(selected,2):
        for x,y in ((a,b),(c,d)):
            endpoints = [x*u+y*v for u,v in product(*differences[i,j])]
            lo,hi = min(endpoints),max(endpoints)
            rhs -= lo*hi
            for axis,scale in enumerate((x,y)):
                for variable,sign in ((2*i+axis,1),(2*j+axis,-1)):
                    terms[variable] = terms.get(variable,F(0))+sign*scale*(lo+hi)
    return canonical((list(terms.items()),rhs,name))

def fixed_sat(name, path, I):
    """Actual owner-axis separation implies each signed relative-support row.

    2 sign*(c_j-c_i).n >= 1+|u_i.u_j|+|det(u_i,u_j)|
    >= 1+(u_i.u_j)+eps*det(u_i,u_j), eps in {-1,1}.
    The original path must actually fix this owner, axis and sign.
    """
    match = re.fullmatch(r'moment_original_sat_(\d+)_(\d+)_(\d+)_(\d+)_([01])_(-?1)_(-?1)',name)
    assert match is not None
    k,i,j,owner,axis,sign,eps = map(int,match.groups())
    assert 0 <= i < j < 9 and owner in (i,j) and 0 <= k < len(path)
    assert path[k] == ['sat',[i,j],[owner,axis,sign]]
    def dot(v,w):
        return I.combine(*(I.product(x,y) for x,y in zip(v,w)))
    u=(I.variable(18+i),I.variable(27+i))
    v=(I.variable(18+j),I.variable(27+j))
    a,b=I.variable(18+owner),I.variable(27+owner)
    normal=(a,b) if axis==0 else (I.times_constant(b,-1),a)
    displacement=tuple(I.minus(I.variable(2*j+ax),I.variable(2*i+ax)) for ax in (0,1))
    determinant=I.minus(I.product(u[0],v[1]),I.product(u[1],v[0]))
    poly=I.combine(I.number(1),dot(u,v),I.times_constant(determinant,eps),
                   I.times_constant(dot(displacement,normal),-2*sign))
    return canonical(I.inequality(poly,name))

def tile_state(parent, candidate, diagnostic, K):
    tile = candidate['tile']
    assert tile == diagnostic['tile'] and len(tile) == 2
    assert candidate['parts'] == diagnostic['parts'] == 4
    assert diagnostic['schema'] == 'fixed_original_B_I_tile_full_psd_discovery_v1'
    h_tile=candidate['h_tile']
    assert h_tile==diagnostic['h_tile']
    if h_tile is None:
        for record in (candidate,diagnostic):
            assert record['h_parts'] is None and record['h_rectangle']==[]
    else:
        assert isinstance(h_tile,list) and len(h_tile)==2
        assert candidate['h_parts']==diagnostic['h_parts']==[2,4]
    pos = list(parent['positions'])
    for axis,index in enumerate(tile):
        assert type(index) is int and 0 <= index < 4
        lo,hi=parent['positions'][16+axis]
        pos[16+axis]=(lo+(hi-lo)*F(index,4),lo+(hi-lo)*F(index+1,4))
    assert candidate['rectangle'] == diagnostic['rectangle'] == K.view(pos[16:18])
    if h_tile is not None:
        for axis,(index,count)in enumerate(zip(h_tile,(2,4))):
            assert type(index) is int and 0<=index<count
            lo,hi=parent['positions'][14+axis]
            pos[14+axis]=(lo+(hi-lo)*F(index,count),lo+(hi-lo)*F(index+1,count))
        assert candidate['h_rectangle']==diagnostic['h_rectangle']==K.view(pos[14:16])
    assert all(lo <= hi for lo,hi in pos)
    return dict(parent,positions=tuple(pos))

class Checker:
    def __init__(self, context, ancestry, strict_root=None):
        context = Path(context).resolve()
        sys.path.insert(0, str(context))
        from b_replay_context import install
        self.J, self.locate = install(Path(ancestry).resolve(), strict_root)
        self.K = self.J.K
        self.I = importlib.import_module('independent_moment_rows')
        self.G = importlib.import_module('independent_nine_cardinality_global_review')
        self.O = importlib.import_module('independent_owned_axis_union')
        self.priors = {}
        self.context = context
        self.ancestry = Path(ancestry).resolve()
        from verify_b_fixed_tile_bounds import Checker as BoundChecker
        self.bound_checker=BoundChecker(context,ancestry,strict_root)
        self.bound_checker.priors=self.priors

    def replay(self, filename):
        started = time.monotonic()
        path = Path(filename).resolve()
        diagnostic_path = path.with_name('diagnostics.json')
        inputs_path = path.with_name('independent_replay_inputs.json')
        c = json.loads(path.read_text())
        d = json.loads(diagnostic_path.read_text())
        hints = json.loads(inputs_path.read_text())
        assert c['schema'] == 'fixed_B_tile_active_psd_exact_candidate_v1'
        assert c['status'] == 'CANDIDATE_COMPLETE_TILE' and c['originals_closed'] == 0
        assert c['input_diagnostics_sha256'] == digest(diagnostic_path)
        assert hints['schema'] == 'untrusted_active_psd_replay_inputs_v1'
        assert hints['candidate_sha256'] == digest(path)
        assert hints['diagnostics_sha256'] == digest(diagnostic_path)
        assert hints['id'] == c['id'] == d['id'] and hints['tile'] == c['tile']
        assert hints['original_closure_credit'] == 0

        prefix_path = self.locate(d['frozen_model'])
        assert digest(prefix_path) == d['frozen_model_sha256']
        frozen_path = prefix_path
        frozen = json.loads(prefix_path.read_text())
        assert frozen['id'] == c['id'] and frozen['path'] == c['original_parent_path'] == d['path']
        assert c['prior'] == d['prior']
        assert c['prior']['path'] == d['frozen_model']
        assert c['prior']['sha256'] == digest(prefix_path) and c['prior']['schema'] == frozen['schema']
        assert d['original_parent_path'] == frozen['path']
        key = (str(prefix_path),digest(prefix_path))
        if key not in self.priors:
            prior_report,parent = self.J.replay(prefix_path,allow_open=True,return_state=True)
            assert prior_report['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
            self.priors[key] = prior_report,parent
        prior_report,parent = self.priors[key]
        assert parent['id'] == c['id'] and parent['path'] == d['path']
        state = tile_state(parent,c,d,self.K)
        bound_source=c['tile_bound_record']
        assert bound_source==d['tile_bound_record']
        assert set(bound_source)=={'path','sha256'}
        bound_path=self.locate(bound_source['path'])
        assert digest(bound_path)==bound_source['sha256']
        bound_literal=json.loads(bound_path.read_text())
        assert bound_literal['id']==c['id'] and bound_literal['path']==parent['path']
        assert bound_literal['status']=='OPEN'
        assert bound_literal['prior']['source']==c['prior']
        bound_context=bound_literal['tile_context']
        for field in('tile','parts','rectangle','h_tile','h_parts','h_rectangle'):
            assert bound_context[field]==c[field]
        bound_report,bounded_state=self.bound_checker.replay(bound_path,allow_open=True,return_state=True)
        assert bound_report['status']=='PASS_CERTIFIED_TILE_STATE_OPEN'
        assert bounded_state['id']==state['id'] and bounded_state['path']==state['path']
        assert bounded_state['choices']==state['choices']
        for old,new in zip(state['positions']+state['scalar'],bounded_state['positions']+bounded_state['scalar']):
            assert old[0]<=new[0]<=new[1]<=old[1]
        state=bounded_state

        base, affine_absolute, positions, scalar, differences, base_guards = self.K.rebuild(
            state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],state['differences'])
        base = [row for row in base if all(k < N for k,value in row[0])]
        diagonal = {}
        assert c['physical_state'] == d['physical_state']
        physical = c['physical_state']
        assert physical['angles'] == self.K.view(state['angles'])
        assert physical['positions'] == self.K.view(positions)
        assert physical['scalar'] == self.K.view(scalar)
        assert physical['differences'] == self.K.diffview(differences)
        assert 'diagonal' not in physical
        bounds = self.I.lifted_absolute_bounds(positions,scalar)
        assert len(bounds) == SIZE
        terminal = c['terminal']
        assert terminal['kind'] == 'positive_exact_reserve'
        assert terminal['absolute_variable_bounds'] == list(map(str,bounds))
        assert c['metadata'] == d['metadata']
        meta = c['metadata']
        linear_count = meta['initial_linear_rows']
        assert hints['linear_row_count'] == linear_count
        assert meta['original_variables'] == N and meta['moment_variables'] == SIZE
        assert d['variables'] == SIZE and d['sign_code'] == '' and d['four_center_energy'] is True
        midpoint = tuple((a+b)/2 for a,b in positions+scalar)
        radius = tuple(max(F(1,20),(b-a)/2) for a,b in positions+scalar)
        assert d['normalization_midpoint'] == list(map(str,midpoint))
        assert d['normalization_radius'] == list(map(str,radius))

        def row_dictionary(entries):
            indices = [e['index'] for e in entries]
            assert all(type(i) is int and 0 <= i < linear_count for i in indices)
            assert len(indices) == len(set(indices))
            return {e['index']:e for e in entries}
        antecedents = row_dictionary(hints['rlt_antecedents'])
        affine_literals = row_dictionary(hints['affine_sources'])
        checked_affine = {}
        def affine_source(index, entry=None):
            assert type(index) is int and 0 <= index < linear_count
            if entry is None:
                assert index in antecedents
                entry = antecedents[index]
            assert entry['index'] == index
            if index not in checked_affine:
                name = entry['name']
                if index < len(base):
                    correct = base[index]
                elif name.startswith('planar_four_center_sum_'):
                    correct = four_affine(name,differences)
                elif name.startswith('square_area_moment_secant_'):
                    correct = area_affine(name,differences)
                else:
                    correct = self.J.rebuild_joint(name,scalar,differences,state['angles'],self.J.point_row)
                assert all(k < N for k,v in correct[0]), ('non-affine RLT premise',name)
                checked_affine[index] = canonical(correct)
            assert literal(entry) == checked_affine[index], ('affine antecedent mismatch',index,entry['name'])
            return checked_affine[index]

        used_entries = terminal['printed_rows']
        active_indices = [entry['index'] for entry in used_entries]
        assert len(active_indices) == len(set(active_indices))
        selected = c['source_indices']
        assert all(type(i) is int and 0 <= i < d['initial_rows'] for i in selected)
        assert selected == sorted(set(selected))
        fresh_squares = c['new_squares']
        assert fresh_squares == d['new_rational_squares']
        # All rational negative squares are universal inequalities; no solver
        # eigenvalue or historical provenance is needed for their validity.
        all_squares = hints['inherited_squares']+fresh_squares
        moment = self.I.Rebuilder(positions,scalar,state['angles'],differences,diagonal,
                                  all_squares,affine_source,linear_count)
        box_names = named_box_rows(positions+scalar)
        assert c['box_rows_added'] == len(box_names)
        total_active_rows = len(selected)+len(fresh_squares)+len(box_names)
        assert all(type(i) is int and 0 <= i < total_active_rows for i in active_indices)
        map_entries = hints['active_affine_source_mapping']
        affine_map = {r['active_index']:r['source_index'] for r in map_entries}
        assert len(affine_map) == len(map_entries)
        expected_affine_map = {entry['index']:selected[entry['index']] for entry in used_entries
                               if entry['index'] < len(selected) and selected[entry['index']] < linear_count}
        assert affine_map == expected_affine_map
        assert set(affine_literals) == set(affine_map.values())
        required_antecedents = {int(entry['name'].split('_')[3]) for entry in used_entries
                                if entry['name'].startswith('moment_rlt_')}
        assert set(antecedents) == required_antecedents
        assert required_antecedents <= set(meta['rlt_source_indices'])

        owned = None
        if any(e['name'].startswith('owned_axis_') for e in used_entries):
            owned = self.O.Replay(state['angles'],differences,diagonal,d['owned_axis_guards'])
        if any(e['name'].startswith('all_nine_') for e in used_entries):
            assert d['all_nine_guards'] == self.G.expected_guards(positions)

        checked = {}
        families = Counter()
        psd_used = set()
        for entry in used_entries:
            active = entry['index']
            name = entry['name']
            if active >= len(selected)+len(fresh_squares):
                assert name == box_names[active-len(selected)-len(fresh_squares)]
            elif active >= len(selected):
                square = fresh_squares[active-len(selected)]
                assert name == 'moment_psd_square_'+str(square['index'])
            if active in affine_map:
                source = affine_map[active]
                correct = affine_source(source,affine_literals[source])
                families['affine'] += 1
            elif name.startswith('moment_original_sat_'):
                correct = fixed_sat(name,state['path'],self.I)
                families['moment_original_sat'] += 1
            elif name.startswith('moment_'):
                correct = canonical(moment.rebuild(name))
                families['_'.join(name.split('_')[:3])] += 1
                if name.startswith('moment_psd_square_'):
                    psd_used.add(int(name.split('_')[3]))
            elif name.startswith('owned_axis_'):
                assert owned is not None
                correct = canonical(owned.rebuild(name))
                families['owned_axis'] += 1
            elif name.startswith('all_nine_'):
                correct = canonical(self.G.physical_row(name,positions))
                families['all_nine'] += 1
            elif name.startswith('planar_four_center_moment_'):
                correct = energy_polynomial(name,self.I)
                families['four_center_energy'] += 1
            elif name.startswith('square_area_moment_quadratic_'):
                correct = area_polynomial(name,self.I)
                families['square_area_moment'] += 1
            else:
                raise AssertionError(('unsupported active physical rule',active,name))
            assert literal(entry) == correct, ('active row mismatch',active,name)
            checked[active] = correct
        assert required_antecedents <= set(checked_affine)

        weights = terminal['weights']
        weight_indices = [item[0] for item in weights]
        assert len(weight_indices) == len(set(weight_indices))
        assert set(weight_indices) == set(checked)
        coefficients = [F(0)]*SIZE
        rhs = F(0)
        for active, numerator in weights:
            assert type(active) is int and type(numerator) is int and numerator > 0
            terms, bound, name = checked[active]
            weight = F(numerator,WEIGHT_SCALE)
            rhs += weight*bound
            for index,value in terms:
                coefficients[index] += weight*value
        residual = sum(a*abs(v) for a,v in zip(bounds,coefficients))
        reserve = -rhs-residual
        assert reserve > 0
        assert reserve == F(terminal['reserve'])
        assert rhs == F(terminal['weighted_rhs'])
        assert coefficients == list(map(F,terminal['weighted_coefficients']))

        forbidden = ('numpy','scipy','highspy','quadratic_moment_pilot','quadratic_moment_rows',
                     'quadratic_owned_axis_union','quadratic_global_nine_cardinality',
                     'square_area_moment_rows','four_center_rows','planar_four_center_rows','fixed_sat_moment_rows',
                     'b_tile_model','joint_owned_axis_probe','v3_whole_parent_pass','diagonal_pass')
        assert not any(name in sys.modules for name in forbidden), ('producer or optimizer imported',
            [name for name in forbidden if name in sys.modules])
        report = dict(schema='independent_B_bounded_I_HI_active_psd_tile_replay_v1',id=c['id'],tile=c['tile'],
            status='PASS_COMPLETE_PHYSICAL_TILE',original_parent_path=parent['path'],
            h_tile=c['h_tile'],full_tile=c['tile']+(c['h_tile'] or []),
            rectangle=c['rectangle'],h_rectangle=c.get('h_rectangle'),
            coordinate_divisions=[4,4,2,4] if c['h_tile'] is not None else [4,4],
            reserve=str(reserve),weighted_rhs=str(rhs),residual_correction=str(residual),
            terminal_rows=len(checked),row_families=dict(sorted(families.items())),
            rlt_affine_antecedents=len(required_antecedents),all_distinct_affine_premises=len(checked_affine),
            negative_rational_squares_used=len(psd_used),original_variables=N,moment_variables=SIZE,
            exact_original_variable_expansion=True,numerical_normalization_not_a_proof_premise=True,
            original_physical_ancestor_replayed=True,prior_report=prior_report,
            bound_state_replay=bound_report,tile_bound_record_sha256=digest(bound_path),
            independently_checked_owned_axis_alternatives=owned.alternative_count if owned else 0,
            source_sha256={str(path):digest(path),str(diagnostic_path):digest(diagnostic_path),
                str(inputs_path):digest(inputs_path),str(prefix_path):digest(prefix_path),str(frozen_path):digest(frozen_path)},
            checker_sha256={str(Path(__file__).resolve()):digest(__file__),
                str(self.context/'b_replay_context.py'):digest(self.context/'b_replay_context.py'),
                str(Path(self.I.__file__)):digest(self.I.__file__),str(Path(self.G.__file__)):digest(self.G.__file__)},
            numerical_producer_or_optimizer_imported=False,new_original_cells=0,new_masks=0,
            lean_lake_ci_run=False,seconds=time.monotonic()-started)
        print(c['id'],'PSD_TILE_PASS',c['tile']+(c['h_tile'] or []),'used',len(checked),'RLT',len(required_antecedents),
              'rational_squares',len(psd_used),'reserve',float(reserve),'seconds',round(report['seconds'],3),flush=True)
        return report

def run(filenames,context,ancestry,output,strict_root=None):
    started=time.monotonic()
    checker=Checker(context,ancestry,strict_root)
    reports=[checker.replay(path) for path in filenames]
    keys=[(r['id'],tuple(r['full_tile'])) for r in reports]
    assert len(keys)==len(set(keys))
    result=dict(schema='independent_B_bounded_I_HI_active_psd_tile_batch_v1',status='PASS_ALL_LISTED_PHYSICAL_TILES',
        tiles=len(reports),terminal_rows=sum(r['terminal_rows'] for r in reports),
        rlt_antecedents=sum(r['rlt_affine_antecedents'] for r in reports),
        negative_rational_squares_used=sum(r['negative_rational_squares_used'] for r in reports),
        tile_reports=reports,new_original_cells=0,new_masks=0,complete_parent_cover_checked=False,
        numerical_producer_or_optimizer_imported=False,lean_lake_ci_run=False,seconds=time.monotonic()-started)
    Path(output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='tile_reports'}),flush=True)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificates',nargs='+',type=Path)
    parser.add_argument('--context',type=Path,default=HERE)
    parser.add_argument('--ancestry',type=Path)
    parser.add_argument('--output',type=Path,default=HERE/'B_I_HI_PSD_TILE_REPLAY.json')
    parser.add_argument('--strict-root',type=Path)
    args=parser.parse_args()
    run(args.certificates,args.context,args.ancestry or args.context/'ancestry',args.output,args.strict_root)
