# Complete B79 original-cell packet

The complete original cell negative-79cdbfcbed2f1fac is covered by sixteen
closed I-center rectangles, with every shared face retained.
Nine rectangles have direct affine/interval terminals. Six more close
after exact affine bound induction; the last has one exact quadratic
certificate on an independently proved affine bound state.

Run: python -B -S verify_all.py

The portable standard-library replay checks the original ancestor, all
sixteen rectangles, 1,776 local bound deductions, all terminal
rows, all rational reserve floors, and both explicit interval/frame
terminal kinds. Final weighted contradictions use 1,723 rows;
the bound inductions add 3,173 printed premise rows.

HAND_PROOF.md explains the same original frames and derived products,
complete cover, exact bound induction, empty G frame witness, final
quadratic argument, and positive rational sums.

A successful COMPLETE_REPLAY.json grants one original-cell closure and
zero mask closures. All source bytes are frozen and external workspace
reads are rejected. No numerical producer or optimizer is imported;
no Lean, Lake or CI was run.
