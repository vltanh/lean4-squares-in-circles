"""Literal affine-bound expansion; caller separately certifies the whole hull."""
from fractions import Fraction as F

PREFIX='certified_original_union_bound_'

def verify_literal(literal,state,binding_sha):
    co,rhs,name=literal
    assert len(binding_sha)==64 and all(x in'0123456789abcdef'for x in binding_sha)
    prefix=PREFIX+binding_sha+'_';assert name.startswith(prefix)
    parts=name[len(prefix):].split('_');field=parts[0];direction=parts[-1]
    assert direction in('upper','lower');sign=1 if direction=='upper'else-1
    exact={};bound=F(0)
    if field in('positions','scalar'):
        assert len(parts)==3;k=int(parts[1]);limit=18 if field=='positions' else 36
        assert 0<=k<limit;lo,hi=map(F,state[field][k]);assert lo<=hi
        exact[k+(0 if field=='positions' else 18)]=F(sign);bound=hi if sign>0 else-lo
    elif field=='angle':
        assert len(parts)==3;i=int(parts[1]);assert 0<=i<9
        lo,hi=map(F,state['angles'][i]);assert -1<=lo<=hi<=1
        exact[27+i]=F(sign);exact[18+i]=-hi if sign>0 else lo
    else:
        assert field in('differences','diagonal')and len(parts)==5
        i,j,axis=map(int,parts[1:4]);assert 0<=i<j<9 and axis in(0,1)
        raw=state.get(field,{})
        table={tuple(p['pair']):p['intervals']for p in raw}if isinstance(raw,list)else raw
        lo,hi=map(F,table[i,j][axis]);assert lo<=hi
        if field=='differences':exact={2*j+axis:F(sign),2*i+axis:F(-sign)}
        else:
            vertical=sign if axis==0 else-sign
            exact={2*i:F(-sign),2*j:F(sign),2*i+1:F(-vertical),2*j+1:F(vertical)}
        bound=hi if sign>0 else-lo
    expected=tuple((k,v)for k,v in sorted(exact.items())if v)
    assert co==expected and rhs==bound
    return literal
