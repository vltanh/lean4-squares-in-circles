# A-c744 I64 source recovery checkpoint

This is a small recovery checkpoint for the unchanged A-c744 original of mask
001/00. It preserves the exact seven-round source record (813 deductions), the
complete availability map of its old proof ancestry, and a new explicit
original-wide I64 hand attachment. It does not install a runtime, close a new
original, or change any mask/ledger status.

The earlier native seven-round replay was observed to pass, but its report
bytes were removed during the later workspace interruption. That unavailable
report is listed as historical evidence only. The interrupted235-node consumer
replay is incomplete. This checkpoint does not recreate either receipt or the
lost235-node snapshot.

## Included exact evidence

* `RECOVERED_SEVEN_ROUND_SOURCE.json`: unchanged raw record with SHA256
  `858f627dd6ab4ed6efbd6f57614787d037fe1482997eca4313a3a9eaa1e25244`.
* `EXTERNAL_SOURCE_MANIFEST.json`: unchanged manifest from the surviving
  external discovery directory. Its I64 premise is interpreted on the explicit
  narrowed source domain; its old3/5 component header is not silently promoted.
* `SOURCE_AVAILABILITY.json`: a fresh read-only hash audit of all2249 surviving
  A1 materialization files, all2238 native aliases, and all193 external source
  references. Complete old0/1 proof trees have41/757 nodes. The two one-node
  conditional A3 bound sources are also available.
* `ORIGINAL_WIDE_I64_IMPLICATION.md`: new recovery write-up of the full physical
  implication using complete old0/1/2/4 exclusions, whole-original D/G and order
  guards, the published16/25 theorem, and the unchanged strict-CD equality blocker.
* `sources/`: small byte-identical independent source helpers, old source
  bindings, and the historical native-cache wrapper. The wrapper is retained
  as source only; its lost cache and235-node input are not available here.

The large old proof payloads remain in the published A-base/A1 packages; they
are referenced by exact hashes instead of copied again. `CHECKPOINT.json`
records their archive and materialization identities. The current native donor
paths in `SOURCE_AVAILABILITY.json` are an availability map, not a portable
permission to read arbitrary external files.

## Check the recovered attachment

The checker below verifies exact input bytes, the whole-parent interval guards,
the four old consequence literals, all saved old0/1 leaf payload hashes, exact
first-five-round prefix identity, the two I64 literals,131 universal center
literals,125 exact height-identity fixtures and12 damaged caller/guard/row
controls. It repeats no weighted proof and no scalar certificate; its report
states those limits explicitly.

    python -B -S check_checkpoint.py \
      --a1-packet /tmp/recovered_a1_packet_064e4aa \
      --five-round-source /workspace/scratch/8446ce74729c/pr11/research/nine/.runs/closure_route/runtime/d_work/A_c744_component3_post_a1_bound_whole_probe/node_00000.json \
      --repository /workspace/scratch/f9f48fcfb253/repo \
      --report /tmp/i64_source_recovery_fresh_check.json

A relocated five-round source is acceptable only with the fixed expected hash.
The A1 materialization can be reconstructed from the two published archives
identified in `CHECKPOINT.json`. Nothing in this checker changes their inputs.

## Remaining gates

A new independent weighted replay of the recovered seven-round record is needed
before using its endpoints again. Its old complete sources and literal-row
families must all remain attached; any explicit reuse of previously accepted
source evidence must be source-complete and reviewed. The complete portable
protocol still requires the full prior source replay. After that, a new
original-wide endpoint binding and actual consumer replay can be prepared.
No numerical process is launched by this checkpoint. No Lean, Lake or CI is run.

All five physical dependencies named by the published16/25 premise binding are
included as exact local byte aliases in `published_premises/`. This avoids
relying on their presence in a sparse checkout. The checker hashes all five;
no broad path translation or omitted premise is permitted. V2 preparation was
not executed or accepted and remains preserved separately.
