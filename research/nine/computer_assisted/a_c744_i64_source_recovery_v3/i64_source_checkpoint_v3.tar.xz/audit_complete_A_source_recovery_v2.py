#!/usr/bin/env python3
"""Read-only exact availability audit; never regenerates proof records or receipts."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,time

OUT=Path('/tmp/ac_exact_recovery_20261105_0945')
BASE=Path('/tmp/recovered_a1_packet_064e4aa')
FOREIGN=Path('/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/closure_route')
OLD='/workspace/scratch/f9f48fcfb253/'
INPUT=BASE/'INPUT_MANIFEST.json'
BINDINGS=BASE/'BINDINGS.json'
MANIFEST=OUT/'external_exact_seven_round_source/EXTERNAL_MANIFEST.json'
EXPECTED_NODE='858f627dd6ab4ed6efbd6f57614787d037fe1482997eca4313a3a9eaa1e25244'

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        while True:
            chunk=f.read(1<<20)
            if not chunk:break
            h.update(chunk)
    return h.hexdigest()

def get_json(path):return json.loads(Path(path).read_text())

def main():
    started=time.monotonic();checked={};by_hash=defaultdict(list);errors=[]
    input_hash=sha(INPUT);bindings_hash=sha(BINDINGS);manifest_hash=sha(MANIFEST)
    inv=get_json(INPUT);bind=get_json(BINDINGS);manifest=get_json(MANIFEST)
    assert inv['files']['BINDINGS.json']==bindings_hash
    for rel,expected in sorted(inv['files'].items()):
        p=BASE/rel
        assert p.resolve().is_relative_to(BASE.resolve())
        try:
            actual=sha(p)
            if actual!=expected:raise AssertionError((actual,expected))
            item=dict(path=str(p),sha256=actual,bytes=p.stat().st_size)
            checked[str(p)]=item;by_hash[actual].append(str(p))
        except Exception as e:errors.append(dict(path=str(p),expected=expected,error=repr(e)))
    aliases={}
    for original,entry in sorted(bind['files'].items()):
        p=BASE/entry['path'];expected=entry['sha256']
        assert inv['files'][entry['path']]==expected
        if str(p) in checked:
            aliases[original]=dict(sha256=expected,donor=str(p),bytes=checked[str(p)]['bytes'],source='SURVIVING_PUBLISHED_A1_MATERIALIZATION')
        else:aliases[original]=dict(sha256=expected,available=False)
    def resolve(path,expected):
        candidates=[Path(path)]
        if path in aliases and aliases[path].get('donor'):candidates.append(Path(aliases[path]['donor']))
        if path.startswith(OLD):candidates.append(FOREIGN/'runtime'/path[len(OLD):])
        candidates.extend(Path(p)for p in by_hash.get(expected,[]))
        seen=set()
        for p in candidates:
            if str(p)in seen:continue
            seen.add(str(p))
            if not p.is_file():continue
            try:
                actual=checked.get(str(p),{}).get('sha256')or sha(p)
                if actual==expected:
                    item=dict(path=str(p),sha256=expected,bytes=p.stat().st_size)
                    checked[str(p)]=item
                    if str(p)not in by_hash[expected]:by_hash[expected].append(str(p))
                    return item
            except OSError:pass
        return None
    requirements={**manifest['source_sha256']}
    for field in('parent','conditional_parent','component3_shared_bound_state','component1_closed_consequence','component3_post_a1_bound_state'):
        ref=manifest[field];requirements[ref['path']]=ref['sha256']
    external=[];missing=[]
    for original,expected in sorted(requirements.items()):
        donor=resolve(original,expected)
        item=dict(original_path=original,sha256=expected,available=donor is not None,donor=donor)
        external.append(item)
        if donor is None:missing.append(item)
    node=OUT/'external_exact_seven_round_source/node_00000.json'
    assert sha(node)==EXPECTED_NODE
    raw_node=get_json(node)
    assert len(raw_node['rounds'])==7
    assert sum(len(r['proposals'])for r in raw_node['rounds'])==813
    binding_names={
      'old_components_0_2_4':'A_C744_COMPLEMENT_CONSEQUENCES_BINDING.json',
      'complete_component1':'A_C744_COMPONENT1_CLOSED_CONSEQUENCE_BINDING.json',
      'conditional_component3_first_four_rounds':'A_C744_COMPONENT3_SHARED_BOUND_STATE_BINDING.json',
      'conditional_component3_post_A1_seven_rounds':'A_C744_COMPONENT3_POST_A1_BOUND_STATE_BINDING.json'}
    ancestry={}
    for key,name in binding_names.items():
        original=OLD+'ac_work/tree/'+name
        expected=requirements.get(original)or aliases.get(original,{}).get('sha256')
        donor=resolve(original,expected)if expected else None
        if donor is None:
            ancestry[key]=dict(binding_original_path=original,expected_sha256=expected,available=False)
            continue
        ref=dict(sha256=expected,donor=donor['path'],bytes=donor['bytes'])
        b=get_json(ref['donor']);item=dict(binding=ref,available=True)
        tree=b.get('source_tree')or b.get('component0_proof')
        if tree:
            mpath=tree['folder']+'/manifest.json';mref=resolve(mpath,tree['manifest_sha256'])
            if mref is None:
                item['missing_tree_manifest']=dict(path=mpath,sha256=tree['manifest_sha256'])
                ancestry[key]=item
                continue
            m=get_json(mref['path']);payloads=[]
            for n in m['nodes']:
                p=tree['folder']+'/'+n['file'];r=resolve(p,n['sha256'])
                payloads.append(dict(original_path=p,sha256=n['sha256'],available=r is not None,donor=r))
            item['complete_saved_tree']=dict(manifest=mref,nodes=len(payloads),payloads=payloads,
                candidate_excluded_leaves=sum(n['status']=='CANDIDATE_CLOSED'and not n['children']for n in m['nodes']),
                open_leaves=sum(n['status']=='OPEN'and not n['children']for n in m['nodes']))
        for field in('whole_original_parent','component_parent','conditional_parent','proof_declaration','source_checker'):
            x=b.get(field)
            if isinstance(x,dict)and 'path'in x and 'sha256'in x:
                found=resolve(x['path'],x['sha256'])
                item[field]=dict(original_reference=x,available=found is not None,donor=found)
        ancestry[key]=item
    known_lost={
      'fresh_narrowed_seven_round_gate_receipt':'29c8ecf7386d80fbcece2ff1ea93066ce3cdbeb902052b61a5f0f83648320c6d',
      'narrowed_gate_binding':'0997aadb95ef1fad254623901ce39b626dfc46a61d5f0a5c1324d07a25ba02e1',
      'narrowed_gate_source_freeze':'af87b533b2316c4db3919913f325db30582fd172a70fd4bf4364d1b54d00c058',
      'narrowed_gate_relocated_manifest':'f6795301481bfdeeb035a02ed72b766e06f522fbe50451e5138c75edf843a951',
      'original_wide_I64_bound_binding':'7d96e66f6b91192781b7cfce7395ce8fb49927eabae0d42355a3666a001aed75',
      'original_wide_I64_source_freeze':'345d1612a8ec32feed770281cdb46d04a941c7d6ad8e12121544873a12fad0dc',
      'retained_235_node_snapshot_manifest':'e8a64502970e6c2da9cd3e6bfcc9605f3cc64b4c6c27565b25ba4fba8f0e8382',
      'first_direct_268_bound_record':'e100d53d70bfb11a89cae903d9f4efcc5950725edb164488ccddd7ef1df53126',
      'first_direct_268_exact_report':'91284196f753a001c4e6a45628975d819683709ab332dc4d5d54796dc15300e2',
      'native_source_cache_ready_receipt':'d619f6f0a13f1d7484dac0b159117a9431d347e9094d312f90454ebdbebe9101'}
    lost=[dict(label=k,expected_sha256=v,available_in_audited_donors=bool(by_hash.get(v)),donors=by_hash.get(v,[]))for k,v in known_lost.items()]
    assert sha(INPUT)==input_hash and sha(BINDINGS)==bindings_hash and sha(MANIFEST)==manifest_hash
    report=dict(schema='complete_A_source_availability_inventory_v1',
      status='PASS_BASE_ANCESTRY_BYTES_AVAILABLE_WITH_EXPLICIT_NEW_RECEIPT_GAPS'if not errors else'FAIL_BASE_PAYLOAD_HASHES',
      read_only_source_audit=True,arithmetic_replayed=False,new_records_generated=False,
      base_input_manifest=dict(path=str(INPUT),sha256=input_hash,files=len(inv['files'])),
      base_alias_binding=dict(path=str(BINDINGS),sha256=bindings_hash,aliases=len(aliases)),
      external_seven_round_manifest=dict(path=str(MANIFEST),sha256=manifest_hash),
      recovered_seven_round_record=dict(path=str(node),sha256=EXPECTED_NODE,rounds=7,deductions=813),
      base_errors=errors,native_aliases=aliases,external_source_requirements=external,
      external_missing_requirements=missing,source_ancestry=ancestry,
      lost_new_proof_and_transport_outputs=lost,checked_regular_files=len(checked),
      unique_checked_contents=len(by_hash),seconds=time.monotonic()-started,
      scope_note='Availability and exact hashes only. Lost reports are not recreated; no native-cache use or numerical restart is authorized by this inventory.',
      proof_credit=dict(originals=0,masks=0))
    out=OUT/'COMPLETE_A_SOURCE_AVAILABILITY_V2.json'
    assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],path=str(out),sha256=sha(out),
      base_files=len(inv['files']),native_aliases=len(aliases),external_requirements=len(external),
      external_missing=len(missing),ancestry_trees={k:len(v.get('complete_saved_tree',{}).get('payloads',[]))for k,v in ancestry.items()},seconds=report['seconds'])),flush=True)

if __name__=='__main__':main()
