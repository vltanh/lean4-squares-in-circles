#!/usr/bin/env python3
"""Exact byte/domain/literal recovery audit; does not replay weighted proofs."""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
from itertools import product
import argparse,hashlib,importlib.util,json

if not __debug__:
    raise RuntimeError('Recovery checks require assertions.')
HERE=Path(__file__).resolve().parent
TARGET='positive-c744bc031d40ee64'
ORIGINAL_PATH=[['angle',3,1],['angle_cut',[0,'0'],0],['inward_row_escape',[7,8],[4]]]
OLD='/workspace/scratch/f9f48fcfb253/'
I64_NAME='stronger_actual_ab_064_A_c744_I_high'
I64_CO=((3,F(1)),(7,F(1)),(17,F(-2)))
I64_RHS=F(-16,25)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def literal(row):return tuple((i,F(v))for i,v in row['coefficients']),F(row['rhs']),row['name']

def check_guard_state(state):
    assert state['id']==TARGET and state['path']==ORIGINAL_PATH
    assert len(state['angles'])==9 and len(state['positions'])==18 and len(state['scalar'])==36
    assert F(state['angles'][3][0])>=0
    differences={tuple(x['pair']):x['intervals']for x in state['differences']}
    dg=differences[3,6];di=differences[3,8]
    assert F(-1)<F(dg[0][0])<=F(dg[0][1])<F(1)
    assert F(dg[1][0])>=0
    assert F(di[0][1])<0
    return True

def check_I64(value):
    co,rhs,name=value
    assert tuple(co)==I64_CO and F(rhs)==I64_RHS and name==I64_NAME
    return True

def rejected(call):
    try:call()
    except (AssertionError,KeyError,ValueError,TypeError):return
    raise AssertionError('Damaged input was accepted.')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--a1-packet',type=Path,required=True)
    ap.add_argument('--five-round-source',type=Path,required=True);ap.add_argument('--report',type=Path,required=True)
    ap.add_argument('--repository',type=Path,required=True)
    a=ap.parse_args();assert not a.report.exists()
    freeze=load(HERE/'SOURCE_BINDINGS.json')
    for name,h in freeze['files'].items():assert sha(HERE/name)==h,name
    checkpoint=load(HERE/'CHECKPOINT.json')
    assert checkpoint['new_original_cells']==checkpoint['new_masks']==0
    assert checkpoint['weighted_arithmetic_freshly_replayed']is False
    assert checkpoint['original_id']==TARGET and checkpoint['original_path']==ORIGINAL_PATH
    aliases=checkpoint['published_theorem_local_aliases']
    for rel,h in checkpoint['published_theorem_files'].items():
        if rel in aliases:
            p=HERE/aliases[rel];assert p.resolve().is_relative_to(HERE)
        else:
            p=a.repository/rel;assert p.resolve().is_relative_to(a.repository.resolve())
        assert sha(p)==h,rel
    base=a.a1_packet.resolve();manifest=load(base/'INPUT_MANIFEST.json');binding=load(base/'BINDINGS.json')
    assert sha(base/'INPUT_MANIFEST.json')==checkpoint['base']['assembled_input_manifest_sha256']
    assert sha(base/'BINDINGS.json')==manifest['files']['BINDINGS.json']
    for rel,h in manifest['files'].items():
        p=base/rel;assert p.resolve().is_relative_to(base)
        assert sha(p)==h,rel
    def native(relative,expected=None):
        key=OLD+relative;item=binding['files'][key];p=base/item['path']
        assert manifest['files'][item['path']]==item['sha256']
        if expected:assert item['sha256']==expected
        return load(p)
    whole=native('ac_work/tree/a_c744_whole_support_caps/record.json',checkpoint['whole_parent']['sha256'])
    state=whole['record']['final'];check_guard_state(state)
    seven=load(HERE/'RECOVERED_SEVEN_ROUND_SOURCE.json')
    assert sha(HERE/'RECOVERED_SEVEN_ROUND_SOURCE.json')==checkpoint['seven_round_source']['sha256']
    assert sha(a.five_round_source)==checkpoint['five_round_prefix_source']['sha256']
    five=load(a.five_round_source)
    assert seven['initial']==five['initial']and seven['rounds'][:5]==five['rounds']
    assert seven['id']==TARGET and seven['original_path']==ORIGINAL_PATH
    assert seven['initial']['id']==TARGET and seven['initial']['path']==ORIGINAL_PATH
    assert seven['status']=='OPEN'and len(seven['rounds'])==7
    assert sum(len(r['proposals'])for r in seven['rounds'])==813
    assert sum(len(r['printed_rows'])for r in seven['rounds'])==1941
    spec=importlib.util.spec_from_file_location('recovered_independent_center',HERE/'sources/independent_physical_center_disk_rows.py')
    center=importlib.util.module_from_spec(spec);spec.loader.exec_module(center)
    I_count=C_count=0
    for r in seven['rounds']:
        for row in r['printed_rows']:
            if row['name']==I64_NAME:check_I64(literal(row));I_count+=1
            if row['name'].startswith(center.PREFIX):center.verify_literal(literal(row));C_count+=1
    assert (I_count,C_count)==(2,131)
    old024=native('ac_work/tree/A_C744_COMPLEMENT_CONSEQUENCES_BINDING.json',checkpoint['old_exclusion_bindings']['0_2_4'])
    old1=native('ac_work/tree/A_C744_COMPONENT1_CLOSED_CONSEQUENCE_BINDING.json',checkpoint['old_exclusion_bindings']['1'])
    assert [x['component']for x in old024['consequences']]==[0,2,4]
    expected={0:([[2,'1'],[16,'-1']],'0'),1:([[3,'-1'],[7,'1']],'3/5'),
              2:([[3,'1'],[7,'-1']],'3/5'),4:([[3,'1'],[7,'1'],[17,'-2']],'3/5')}
    for c in old024['consequences']:
        row=c['necessary_weak_row'];assert (row['coefficients'],row['rhs'])==expected[c['component']]
    row=old1['necessary_weak_row'];assert (row['coefficients'],row['rhs'])==expected[1]
    for b in(old024,old1):
        assert b['original_id']==TARGET and b['original_path']==ORIGINAL_PATH
        assert b['new_original_cells']==b['new_masks']==0
    inventories=[]
    for label,tree in ((0,old024['component0_proof']),(1,old1['source_tree'])):
        rel=tree['folder'][len(OLD):]+'/manifest.json';m=native(rel,tree['manifest_sha256'])
        count=0
        for n in m['nodes']:
            native(tree['folder'][len(OLD):]+'/'+n['file'],n['sha256'])
            if not n['children']:
                assert n['status']=='CANDIDATE_CLOSED';count+=1
        assert (len(m['nodes']),count)==((41,31)if label==0 else(757,566))
        inventories.append(dict(component=label,nodes=len(m['nodes']),saved_candidate_exclusions=count))
    for i in(2,4):
        c=native(f'ac_work/tree/a_c744_five_complements/component_{i}.json')
        assert c['component']==i and c['record']['status']=='CANDIDATE_CLOSED'
    # Exact finite controls exercise the signs in the universally proved identity.
    cases=0
    for b,d,i in product((F(-1),F(-3,5),F(0),F(16,25),F(1)),repeat=3):
        t=2*i-b-d
        assert abs(i-b)+abs(d-i)==max(d-b,b-d,t,-t)
        cases+=1
    bad=[]
    s=deepcopy(state);s['id']='negative-887236b78100baf3';bad.append(s)
    s=deepcopy(state);s['path'][0][2]=0;bad.append(s)
    s=deepcopy(state);s['angles'][3][0]='-1/100';bad.append(s)
    for axis,end,value in((0,0,'-1'),(0,1,'1'),(1,0,'-1/100')):
        s=deepcopy(state);next(x for x in s['differences']if x['pair']==[3,6])['intervals'][axis][end]=value;bad.append(s)
    s=deepcopy(state);next(x for x in s['differences']if x['pair']==[3,8])['intervals'][0][1]='0';bad.append(s)
    s=deepcopy(state);s['angles'].pop();bad.append(s)
    for s in bad:rejected(lambda s=s:check_guard_state(s))
    for value in((I64_CO,F(-3,5),I64_NAME),(I64_CO,-I64_RHS,I64_NAME),
                  (((3,F(-1)),(7,F(1)),(17,F(-2))),I64_RHS,I64_NAME),(I64_CO,I64_RHS,I64_NAME+'_wrong')):
        rejected(lambda value=value:check_I64(value))
    for name,h in freeze['files'].items():assert sha(HERE/name)==h,name
    report=dict(status='PASS_RECOVERED_I64_BYTES_GUARDS_AND_LITERAL_ATTACHMENT_ONLY',
      original_id=TARGET,original_path=ORIGINAL_PATH,base_files_rehashed=len(manifest['files']),
      complete_saved_source_inventories=inventories,seven_rounds=7,saved_deductions=813,
      saved_printed_rows=1941,I64_literals_checked=I_count,universal_center_literals_checked=C_count,
      exact_height_identity_controls=cases,damaged_scope_guard_or_row_controls=12,
      weighted_arithmetic_freshly_replayed=False,old_source_arithmetic_replayed=False,
      recovered_235_node_tree_claimed=False,old_lost_receipts_recreated=False,
      scalar_certificate_replayed=False,published_theorem_files_rehashed=len(checkpoint['published_theorem_files']),
      all_nine_originals_retained=True,original_corners=36,original_pairs=36,marked_cones=5,
      closed_shared_faces_retained=True,new_original_cells=0,new_masks=0,lean_lake_ci_run=False,
      source_binding_sha256=sha(HERE/'SOURCE_BINDINGS.json'),checkpoint_sha256=sha(HERE/'CHECKPOINT.json'))
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
