#!/usr/bin/env python3
"""Portable exact replay of the complete existing inward-row child 5."""
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
IDENT = "positive-b819223a03e89ec7"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def local(relative):
    path = Path(relative)
    assert not path.is_absolute() and ".." not in path.parts
    result = HERE / path
    assert result.resolve().is_relative_to(HERE) and result.is_file()
    return result


def main():
    if not __debug__:
        raise RuntimeError("Exact checks require Python without optimization.")
    frozen = json.loads(local("SHA256_MANIFEST.json").read_text())
    assert frozen["schema"] == "n9_inward_child5_immutable_files_v1"
    for name, expected in frozen["files"].items():
        assert sha(local(name)) == expected, ("payload_file_changed", name)
    index = json.loads(local("portfolio_index.json").read_text())
    assert index["schema"] == "n9_inward_child5_portfolio_v1"
    register = json.loads(local("original_register.json").read_text())
    assert sha(local("original_register.json")) == index["original_register_sha256"]
    assert len(register["cells"]) == 231
    assert sum(cell["status"] == "CLOSED" for cell in register["cells"]) == 174
    assert sum(cell["status"] == "OPEN" for cell in register["cells"]) == 57
    assert index["target_mask"] == "001/00"
    assert index["reversal_partner"] == "100/00"
    assert index["strict_q"] == "1105/256"
    assert index["whole_masks"] == {"closed": 8, "open": 24}

    earlier_ids, earlier_after = [], {"closed": 174, "open": 57}
    for dependency in index["previous_checkpoints"]:
        file = local(dependency["manifest"])
        assert sha(file) == dependency["manifest_sha256"]
        previous = json.loads(file.read_text())
        assert previous["status"] == "PASS_ALL_COMPLETE_ORIGINAL_PARENTS"
        assert previous["archive_sha256"] == dependency["archive_sha256"]
        assert previous["before"] == dependency["before"] == earlier_after
        assert previous["after"] == dependency["after"]
        assert previous["whole_masks"] == index["whole_masks"]
        register_key = ("baseline_register_sha256"
                        if previous["schema"] == "n9_original_center_capacity_delivery_v1"
                        else "original_register_sha256")
        assert previous[register_key] == index["original_register_sha256"]
        ids = [item["id"] for item in previous["complete_originals"]]
        assert len(ids) == previous["complete_original_count"] == len(set(ids))
        assert not set(ids).intersection(earlier_ids)
        assert previous["after"] == {
            "closed": previous["before"]["closed"] + len(ids),
            "open": previous["before"]["open"] - len(ids),
        }
        earlier_ids += ids
        earlier_after = previous["after"]
    assert len(index["previous_checkpoints"]) == 3
    assert earlier_after == index["before"] == {"closed": 191, "open": 40}
    assert earlier_ids == index["previously_closed_original_ids"]
    assert len(earlier_ids) == len(set(earlier_ids)) == 17
    assert IDENT not in earlier_ids
    original_status = {cell["id"]: cell["status"] for cell in register["cells"]}
    assert len(original_status) == 231
    assert all(original_status[ident] == "OPEN" for ident in earlier_ids)
    assert index["after"] == {"closed": 192, "open": 39}
    entries = index["entries"]
    assert len(entries) == 1
    entry = entries[0]
    assert entry["id"] == IDENT and entry["kind"] == "whole_parent_dual"
    certificate = local(entry["certificate"])
    assert sha(certificate) == entry["certificate_sha256"]
    assert sha(local(entry["checker"])) == entry["checker_sha256"]
    assert entry["checker"] == "verify_joint_original.py"
    record = json.loads(certificate.read_text())
    assert record["scope"] == "WHOLE_UNCHANGED_ORIGINAL_PARENT"
    assert record["status"] == "CANDIDATE_CLOSED"
    assert record["new_branch_nodes"] == 0
    assert record["maximum_new_rounds"] == 5 and len(record["rounds"]) == 3
    assert record["terminal"]["kind"] == "positive_exact_reserve"
    assert record["path"] == [
        ["angle", 3, 1],
        ["angle_cut", [0, "0"], 0],
        ["inward_row_escape", [7, 8], [5]],
    ]
    sources = dict(record["sources"])
    for name, expected in record.get("additional_sources", {}).items():
        assert name not in sources or sources[name] == expected
        sources[name] = expected
    prior = record["prior"]
    assert prior["kind"] == "fresh_replayed_coordinate_prefix"
    assert prior["deductions"] == 47 and prior["file"] not in sources
    bindings = json.loads(local("source_bindings.json").read_text())
    assert set(bindings) == set(sources) | {prior["file"]}
    for name, expected in sources.items():
        assert sha(local(bindings[name])) == expected
        assert bindings[name] in frozen["files"]
    assert sha(local(bindings[prior["file"]])) == prior["sha256"]
    assert bindings[prior["file"]] in frozen["files"]

    # The accepted/root reports record prior reviews. The arithmetic below
    # is replayed anew and never accepts those report statuses as premises.
    accepted = []
    for name, hash_name in [
        ("accepted_report", "accepted_report_sha256"),
        ("root_report", "root_report_sha256"),
    ]:
        file = local(entry[name])
        assert sha(file) == entry[hash_name]
        accepted.append(json.loads(file.read_text()))

    from verify_joint_original import replay
    report = replay(certificate)
    assert report["status"] == "PASS_COMPLETE_ORIGINAL_PARENT"
    assert report["id"] == IDENT and report["whole_original_parent_closed"] is True
    assert report["bound_induction_branch_nodes"] == 0 and report["center_cover"] is None
    expected_fields = {
        "prior_coordinate_deductions": 47,
        "new_deductions": 506,
        "rounds": 3,
        "printed_rows_checked": 767,
        "terminal_rows": 26,
        "certificate_sha256": entry["certificate_sha256"],
        "reviewer_sha256": entry["checker_sha256"],
        "independent_rules_sha256": sha(local("independent_all_rules.py")),
        "unsupported_rules_accepted": False,
        "whole_mask_closed": False,
    }
    for key, expected in expected_fields.items():
        assert report[key] == expected
        assert all(previous[key] == expected for previous in accepted)
    assert Q(report["reserve"]) == Q(record["terminal"]["reserve"]) > Q(1, 80)
    assert all(previous["reserve"] == report["reserve"] for previous in accepted)

    # Bind the exact existing prefix to the unchanged fixed-register cover.
    # Its sole registered original is the one just replayed in full.
    scope_file = local(entry["scope_audit"])
    assert sha(scope_file) == entry["scope_audit_sha256"]
    audit = json.loads(scope_file.read_text())
    assert audit["schema"] == "n9_exact_existing_a_inward_child5_scope_audit_v1"
    assert audit["register_sha256"] == index["original_register_sha256"]
    assert audit["certificate_sha256"] == entry["certificate_sha256"]
    assert audit["prefix"] == record["path"]
    descendants = [
        cell for cell in register["cells"]
        if cell["path"][:len(audit["prefix"])] == audit["prefix"]
    ]
    assert len(descendants) == audit["original_count"] == 1
    assert [cell["id"] for cell in descendants] == audit["original_ids"] == [IDENT]
    assert [cell["status"] for cell in descendants] == audit["prior_statuses"] == ["OPEN"]
    assert audit["new_original_cells"] == 1 and audit["new_descendants"] == 0
    assert audit["whole_mask_closed"] is False
    assert descendants[0]["path"] == record["path"]
    assert IDENT.split("-")[1] == hashlib.sha256(
        json.dumps(record["path"], separators=(",", ":")).encode()
    ).hexdigest()[:16]
    scope_report = {
        "schema": "n9_complete_existing_inward_child5_replay_v1",
        "status": "PASS_COMPLETE_EXISTING_PREFIX",
        "prefix": record["path"],
        "original_ids": [IDENT],
        "complete_original_count": 1,
        "new_original_predicates": 0,
        "new_descendants": 0,
        "whole_mask_closed": False,
        "registered_prefix_cover_inherited_from_baseline": True,
    }
    out = HERE / "new_reviews"
    out.mkdir(exist_ok=True)
    (out / "inward_child5_scope.json").write_text(json.dumps(scope_report, indent=2) + "\n")
    totals = {
        "prior_coordinate_deductions": 47,
        "whole_parent_new_deductions": 506,
        "rectangle_new_deductions": 0,
        "new_exact_deductions": 506,
        "printed_rows_checked": 767,
        "complete_terminal_domains": 1,
        "whole_parent_terminal_domains": 1,
        "fixed_grid_tiles": 0,
        "static_terminal_domains": 0,
        "complete_rectangle_domains": 0,
    }
    summary = {
        "schema": "n9_inward_child5_complete_replay_v1",
        "status": "PASS_ALL_COMPLETE_ORIGINAL_PARENTS",
        "complete_original_ids": [IDENT],
        "complete_original_count": 1,
        "before": index["before"],
        "after": index["after"],
        "whole_masks": index["whole_masks"],
        "previously_closed_original_count": 17,
        "totals": totals,
        "completed_existing_domain_assemblies": 1,
        "scope_report": "new_reviews/inward_child5_scope.json",
        "reports": [{
            "id": IDENT,
            "kind": "whole_parent_dual",
            "status": report["status"],
            "report": "new_reviews/" + IDENT + ".json",
        }],
        "relocated_producer_sources": len(sources),
        "relocated_coordinate_priors": 1,
        "source_bindings_complete_and_relative": True,
        "unsupported_rules_accepted": False,
        "lean_lake_ci_run": False,
        "proof_kernel_verification": False,
        "whole_mask_closed": False,
    }
    (out / "portable_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)
    return summary


if __name__ == "__main__":
    main()
