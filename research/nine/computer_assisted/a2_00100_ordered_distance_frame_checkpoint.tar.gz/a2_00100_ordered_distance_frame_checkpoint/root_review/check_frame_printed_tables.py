#!/usr/bin/env python3
"""Second arithmetic implementation for printed original-frame bound tables.

This checks rational sums and simultaneous scalar interval updates. The
physical frame identities and source-row validity have independent replay.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
from check_combined_tables import combine

def intervals(values):
    return [[F(v) for v in pair] for pair in values]

def check_parent(parent):
    deductions=rows_count=weighted=0
    for frame,steps in ((False,parent['old_prefix']),(True,parent['frame_rounds'])):
        for step in steps:
            before=intervals(step['positions_before'])
            if frame:before+=intervals(step['scalar_before'])
            after=[p[:] for p in before]
            bounds=list(map(F,step['absolute_variable_bounds']))
            rows_count+=len(step['rows'])
            for d in step['deductions']:
                k,sign=d['coordinate'],d['sign'];assert 0<=k<len(after) and sign in (-1,1)
                co,rhs=combine(step['rows'],d['weights'],len(bounds));co[k]-=sign
                residual=[[i,str(c)] for i,c in enumerate(co) if c]
                correction=sum(m*abs(c) for m,c in zip(bounds,co))
                assert residual==d['residual_coefficients'] and rhs==F(d['summed_rhs'])
                assert correction==F(d['residual_correction'])
                assert rhs+correction==F(d['proved_upper'])<=F(d['upper'])
                assert F(d['slack'])==F(d['upper'])-rhs-correction
                if sign==1:after[k][1]=min(after[k][1],F(d['upper']))
                else:after[k][0]=max(after[k][0],-F(d['upper']))
                deductions+=1
            expected=intervals(step['positions_after'])
            if frame:expected+=intervals(step['scalar_after_proposals'])
            assert after==expected
    terminal=parent.get('terminal')
    if terminal and 'positive_reserve' in terminal:
        terminal_sum(terminal);rows_count+=len(terminal['rows']);weighted+=1
    return deductions,rows_count,weighted

def terminal_sum(leaf):
    bounds=list(map(F,leaf['absolute_variable_bounds']))
    co,rhs=combine(leaf['rows'],leaf['weights'],len(bounds))
    correction=sum(m*abs(c) for m,c in zip(bounds,co))
    assert co==list(map(F,leaf['summed_coefficients'])) and rhs==F(leaf['summed_rhs'])
    assert correction==F(leaf['residual_correction'])
    assert -rhs-correction==F(leaf['positive_reserve'])>0

def check(data):
    if 'parent_proof' in data:
        parents=[data['parent_proof']];leaves=data['leaf_tables']
    else:
        parents=data['parents'];leaves=[]
    deductions=rows_count=weighted=0
    for parent in parents:
        ds,rs,ws=check_parent(parent);deductions+=ds;rows_count+=rs;weighted+=ws
    for leaf in leaves:
        if 'positive_reserve' not in leaf:continue
        terminal_sum(leaf);rows_count+=len(leaf['rows']);weighted+=1
    return {'status':'PASS_PRINTED_RATIONAL_FRAME_ARITHMETIC','parents':len(parents),
        'deductions':deductions,'printed_rows':rows_count,'weighted_terminal_sums':weighted,
        'physical_frame_identities':'SEPARATE_INDEPENDENT_SOURCE_REPLAY', 'whole_mask_closed':False}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('input',type=Path);ap.add_argument('--report',type=Path);a=ap.parse_args()
    result=check(json.loads(a.input.read_text()));result['table_sha256']=hashlib.sha256(a.input.read_bytes()).hexdigest()
    if a.report:a.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
