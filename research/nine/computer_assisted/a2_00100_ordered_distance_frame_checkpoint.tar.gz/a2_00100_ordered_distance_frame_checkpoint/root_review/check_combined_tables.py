#!/usr/bin/env python3
"""Independent arithmetic of printed bound-prefix/physical-tree tables."""
from fractions import Fraction as F
import argparse,json,hashlib
from pathlib import Path

def combine(rows,terms,n):
    index={r['index']:r for r in rows};assert len(index)==len(rows)
    co=[F(0)]*n;rhs=F(0);seen=set()
    for k,w in terms:
        assert type(k)is int and type(w)is int and w>0 and k not in seen
        seen.add(k);r=index[k];lam=F(w,1<<40)
        rhs+=lam*F(r['rhs'])
        for j,a in r['coefficients']:
            assert type(j)is int and 0<=j<n;co[j]+=lam*F(a)
    return co,rhs

def check(data):
    parents=set();deductions=leaves=weighted=rows_count=0;least=None
    for parent in data['parents']:
        assert parent['id'] not in parents;parents.add(parent['id'])
        previous=None
        for step in parent['prefix_tables']:
            before=[[F(v) for v in p] for p in step['positions_before']]
            if previous is not None:assert previous==before
            after=[p[:] for p in before]
            bounds=list(map(F,step['absolute_variable_bounds']))
            rows_count+=len(step['rows'])
            for d in step['deductions']:
                k,s=d['coordinate'],d['sign'];assert 0<=k<18 and s in(-1,1)
                co,rhs=combine(step['rows'],d['weights'],len(bounds));co[k]-=s
                proved=rhs+sum(m*abs(c) for m,c in zip(bounds,co))
                assert rhs==F(d['rhs']) and co==list(map(F,d['residual']))
                assert proved==F(d['proved_upper'])<=F(d['upper'])
                if s==1:after[k][1]=min(after[k][1],F(d['upper']))
                else:after[k][0]=max(after[k][0],-F(d['upper']))
                deductions+=1
            assert after==[[F(v) for v in p] for p in step['positions_after']]
            assert all(a<=b for a,b in after);previous=after
        for leaf in parent['leaf_tables']:
            leaves+=1
            if leaf['terminal'] is not None:continue
            bounds=list(map(F,leaf['absolute_variable_bounds']))
            co,rhs=combine(leaf['rows'],leaf['weights'],len(bounds))
            assert co==list(map(F,leaf['coefficient_sum'])) and rhs==F(leaf['rhs_sum'])
            reserve=-rhs-sum(m*abs(c) for m,c in zip(bounds,co))
            assert reserve==F(leaf['positive_reserve'])>0
            least=reserve if least is None else min(least,reserve)
            rows_count+=len(leaf['rows']);weighted+=1
    return {'status':'PASS_PRINTED_ARITHMETIC','parents':len(parents),
        'bound_deductions':deductions,'terminal_leaves':leaves,'weighted_leaves':weighted,
        'printed_rows_across_rounds_and_leaves':rows_count,'least_positive_reserve':str(least),
        'scope':'Printed rational sums and acyclic interval updates only; physical source and full parent coverage have separate exact replay.','whole_mask_closed':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('table',type=Path);p.add_argument('--report',type=Path);a=p.parse_args()
    data=json.loads(a.table.read_text());r=check(data);r['table_sha256']=hashlib.sha256(a.table.read_bytes()).hexdigest()
    if a.report:a.report.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r,indent=2))
