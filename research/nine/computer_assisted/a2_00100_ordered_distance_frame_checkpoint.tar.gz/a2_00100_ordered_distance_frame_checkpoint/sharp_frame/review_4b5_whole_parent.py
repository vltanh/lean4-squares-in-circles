#!/usr/bin/env python3
"""Independent composition audit: old 106 leaves and all 17 local terminals.

Imports the independent rational checker only; no numerical producer or
optimizer is imported. The reviewed paths are the complete original parent.
"""
import json
import sys
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
OUT=HERE/'4b5'
sys.path.insert(0,str(HERE.parent/'global_masks'))
import review_guarded_frame_bounds_independent as R


def main():
    started=time.monotonic()
    record=json.loads((OUT/'local_induction_report.json').read_text())
    source=json.loads((OUT/'source_physical_tree.json').read_text())
    parent_file=OUT/'parent_bounds.json'
    assert record['status']=='CLOSED' and not record['not_yet_processed']
    assert R.sha(parent_file)==record['parent_bound_sha256']==source['parent_bound_sha256']
    assert R.sha(OUT/'source_physical_tree.json')==record['source_tree_sha256']
    assert source['id']==record['id'] and source['path']==record['path']
    assert len(source['leaves'])==record['preserved_old_leaf_count']==106
    assert len(source['frontier'])==record['source_frontier_count']==17
    assert len(record['results'])==17
    assert {r['index']for r in record['results']}==set(range(17))
    parent,parent_review,parent_table=R.load_parent(parent_file)
    assert parent_review['status']=='PASS_CERTIFIED_PARENT_STATE'
    assert parent['id']==source['id'] and parent['path']==source['path']
    old_reviews=[];old_tables=[]
    for leaf in source['leaves']:
        review,table=R.verify_tree_leaf(parent,leaf)
        assert review['status']=='PASS'
        old_reviews.append(review);old_tables.append(table)
    new_reviews=[];new_tables=[];new_leaves=[]
    for item in sorted(record['results'],key=lambda r:r['index']):
        local=item['record']
        assert local['path']==source['frontier'][item['index']]['path']
        assert local['id']==source['id'] and local['status']=='CANDIDATE_CLOSED'
        state,review,table=R.verify_node_induction(parent,local)
        assert review['status']=='PASS_COMPLETE_CHILD'
        new_reviews.append({'index':item['index'],**review})
        new_tables.append(table);new_leaves.append(local)
    R.check_physical_union(parent['path'],source['leaves']+new_leaves)
    result={
        'id':parent['id'],'path':parent['path'],
        'status':'PASS_COMPLETE_ORIGINAL_PARENT',
        'preserved_old_leaves':len(old_reviews),'new_node_terminals':len(new_reviews),
        'total_terminal_paths':len(old_reviews)+len(new_reviews),
        'new_exact_variable_deductions':sum(r['deductions']for r in new_reviews),
        'new_physical_splits':0,'frontier':[],
        'parent_review':parent_review,'old_leaf_reviews':old_reviews,'new_node_reviews':new_reviews,
        'source_report_sha256':R.sha(OUT/'local_induction_report.json'),
        'source_tree_sha256':R.sha(OUT/'source_physical_tree.json'),
        'parent_certificate_sha256':R.sha(parent_file),
        'composition_checker_sha256':R.sha(__file__),
        'rational_checker_sha256':R.sha(R.__file__),
        'seconds':time.monotonic()-started,'whole_mask_closed':False,
    }
    (OUT/'whole_parent_independent_review.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT/'old_leaf_tables.json').write_text(json.dumps(old_tables,indent=2)+'\n')
    print({k:v for k,v in result.items()if k not in ('path','parent_review','old_leaf_reviews','new_node_reviews')},flush=True)


if __name__=='__main__':
    main()
