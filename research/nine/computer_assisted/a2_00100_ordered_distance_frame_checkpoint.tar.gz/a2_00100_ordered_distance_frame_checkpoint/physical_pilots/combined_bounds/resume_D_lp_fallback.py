#!/usr/bin/env python3
"""Discovery-only numerical fallback for one recorded NO_LP_POINT domain.

All mathematical rows and exact proof semantics stay at structural_v3.
"""
import json,sys
from pathlib import Path
import scipy.optimize as opt
sys.path.insert(0,'/workspace/scratch/f694a78df3e7/sharp_frame')
import octagon_guarded_producer as G
O=G.O
attempts=[]

def reliable_lp(*args,**kwargs):
 result=opt.linprog(*args,**kwargs)
 if not result.success:
  first={'status':int(result.status),'message':str(result.message)}
  retry=dict(kwargs);retry['method']='highs-ds';retry['options']={**kwargs.get('options',{}),'presolve':False,'time_limit':30.0}
  result=opt.linprog(*args,**retry)
  attempts.append({'original':first,'retry_status':int(result.status),'retry_message':str(result.message)})
 O.B._last=result.x[:-1] if result.success else None
 return result

O.M.linprog=reliable_lp
base=Path(__file__).resolve().parent
record=G.run(base/'prefixes/positive-3622c4448973035b.json',1024,
             base/'positive_D_reliable_lp_resume1024.json',base/'positive_D_guarded_priority_resume1024.json')
(base/'positive_D_lp_failure_diagnostic.json').write_text(json.dumps({'fallbacks':attempts,'scope':'Numerical discovery only; every proof leaf still needs exact rational replay'},indent=2)+'\n')
print('fallbacks',len(attempts),'status',record['status'],flush=True)
