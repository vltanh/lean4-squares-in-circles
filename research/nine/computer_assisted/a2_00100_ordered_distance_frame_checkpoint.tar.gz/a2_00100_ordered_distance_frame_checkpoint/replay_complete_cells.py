#!/usr/bin/env python3
"""Portable exact replay of the nine complete original-cell additions."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'physical_pilots/combined_bounds'))
sys.path.insert(0,str(HERE/'global_masks'))
import review_octagon as O
import review_guarded_frame_bounds_independent as F

def read(path):return json.loads(path.read_text())

def verify_composed():
    folder=HERE/'sharp_frame/4b5'
    report=read(folder/'local_induction_report.json')
    old=read(folder/'source_physical_tree.json')
    assert report['status']=='CLOSED' and not report['not_yet_processed']
    assert F.sha(folder/'source_physical_tree.json')==report['source_tree_sha256']
    assert F.sha(folder/'parent_bounds.json')==report['parent_bound_sha256']==old['parent_bound_sha256']
    assert len(old['leaves'])==106 and len(old['frontier'])==17
    assert len(report['results'])==17 and {r['index'] for r in report['results']}==set(range(17))
    state,parent_review,parent_table=F.load_parent(folder/'parent_bounds.json')
    assert state['id']==old['id']==report['id'] and state['path']==old['path']==report['path']
    assert parent_review['status']=='PASS_CERTIFIED_PARENT_STATE'
    leaves=list(old['leaves']);weighted=0;least=None;deductions=0
    for leaf in old['leaves']:
        review,table=F.verify_tree_leaf(state,leaf)
        if review['reserve'] is not None:
            reserve=F.F(review['reserve']);weighted+=1;least=reserve if least is None else min(least,reserve)
    for item in report['results']:
        local=item['record']
        assert local['path']==old['frontier'][item['index']]['path']
        assert local['id']==state['id'] and local['status']=='CANDIDATE_CLOSED'
        _,review,table=F.verify_node_induction(state,local)
        assert review['status']=='PASS_COMPLETE_CHILD'
        deductions+=review['deductions'];leaves.append(local)
        if review['reserve'] not in (None,'None'):
            reserve=F.F(review['reserve']);weighted+=1;least=reserve if least is None else min(least,reserve)
    F.check_physical_union(state['path'],leaves)
    return {'id':state['id'],'status':'PASS_COMPLETE_ORIGINAL_PARENT',
        'terminal_leaves':len(leaves),'weighted_leaves':weighted,'least_reserve':str(least),
        'bound_deductions':parent_review['old_coordinate_deductions']+parent_review['new_original_variable_deductions']+deductions,
        'whole_mask_closed':False}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--ids',nargs='*');ap.add_argument('--report',default='fresh_complete_review.json');args=ap.parse_args()
    manifest=read(HERE/'manifest.json')
    for name,expected in manifest['files_sha256'].items():
        assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==expected,('source hash',name)
    index=read(HERE/'cell_index.json');wanted=set(args.ids or [x['id'] for x in index['new_cells']]);reviews=[]
    registry={c['id']:c for c in read(HERE/'previous_fixed_register.json')['cells']}
    started=time.monotonic()
    for record_file in sorted((HERE/'octagon_cells').glob('*.json')):
        record=read(record_file)
        if record['id'] not in wanted:continue
        prefix=HERE/'physical_pilots/combined_bounds/prefixes'/(record['id']+'.json')
        review,_=O.review_parent(record,prefix.read_bytes(),registry)
        assert review['status']=='PASS_COMPLETE_ORIGINAL_PARENT';reviews.append(review)
        print(record['id'],'PASS',review['leaves_checked'],'complete leaves',flush=True)
    ident='negative-547e512df0c949e9'
    if ident in wanted:
        _,review,_=F.load_parent(HERE/'root_exploration/guarded_bounds'/(ident+'.json'))
        assert review['status']=='PASS_COMPLETE_ORIGINAL_PARENT';reviews.append(review);print(ident,'PASS',flush=True)
    ident='negative-685477c369fdc445'
    if ident in wanted:
        review,_=F.verify_tree_record(read(HERE/'root_exploration/guarded_trees'/(ident+'.json')),
                                    HERE/'root_exploration/guarded_bounds'/(ident+'.json'))
        assert review['status']=='PASS_COMPLETE_ORIGINAL_PARENT';reviews.append(review);print(ident,'PASS',flush=True)
    if 'negative-4b5e7ea05e82b9ac' in wanted:
        review=verify_composed();reviews.append(review);print(review['id'],'PASS',flush=True)
    assert {r['id'] for r in reviews}==wanted
    result={'status':'PASS_ALL_REQUESTED_COMPLETE_ORIGINAL_PARENTS','parents':len(reviews),
            'reviews':reviews,'seconds':time.monotonic()-started,'whole_mask_closed':False}
    (HERE/args.report).write_text(json.dumps(result,indent=2)+'\n')
    print('PASS',len(reviews),'complete original parents; whole mask remains OPEN',flush=True)

if __name__=='__main__':main()
