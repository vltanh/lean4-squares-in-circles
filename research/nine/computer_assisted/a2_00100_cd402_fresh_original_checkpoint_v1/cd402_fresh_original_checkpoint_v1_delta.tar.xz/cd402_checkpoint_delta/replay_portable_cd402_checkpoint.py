"""Fresh Cd402 exact replay through the unchanged published C transport."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import time

TRANSPORT_SHA = 'd7d9b17da9091cb7920e5964618303c93ae2689a8528381091b35f3ee4c2cb28'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--packet', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert __debug__
    started = time.monotonic()
    packet, output = args.packet.resolve(), args.output.resolve()
    assert not output.exists() and not output.is_relative_to(packet)
    assert not str(packet).startswith('/workspace/') and not str(output).startswith('/workspace/')
    manifest = json.loads((packet / 'INPUT_MANIFEST.json').read_text())
    for name, digest in manifest['files'].items():
        assert sha(packet / name) == digest
    proof = json.loads((packet / 'CD402_CHECKPOINT_PROOF.json').read_text())
    assert proof['original_id'] == 'negative-d4021ade840b985c'
    assert proof['original_mask'] == '001/00' and proof['original_status'] == 'OPEN'
    assert proof['new_original_cells'] == proof['new_masks'] == 0
    transport = packet / 'replay_portable_c_height_packet_v3.py'
    assert sha(transport) == TRANSPORT_SHA
    code = packet / 'payload/d_work/cd402_work'
    output.mkdir(parents=True)
    jobs = (
        ('bound', code / 'verify_cd402_original_bound.py',
         code / 'other_masks_whole_original_bound3.json', 'WHOLE_ORIGINAL_BOUND_REPLAY.json'),
        ('seed', code / 'verify_cd402_whole_original_tree.py',
         code / 'whole_original_complete_cover_seed', 'COMPLETE_OPEN_SEED_REPLAY.json'),
    )
    reports = {}
    for label, script, source, filename in jobs:
        result_folder = output / label
        report_path = result_folder / filename
        with (output / (label + '.log')).open('w') as log:
            result = subprocess.run([sys.executable, '-B', '-S', str(transport),
                '--packet', str(packet), '--output', str(result_folder),
                '--worker-script', str(script), '--', str(source), str(report_path)],
                check=False, stdout=log, stderr=subprocess.STDOUT)
        assert result.returncode == 0, ('exact isolated child failed', label, result.returncode)
        report = json.loads(report_path.read_text())
        assert report['original_id'] == proof['original_id']
        assert report['original_path'] == proof['original_path']
        assert report['numerical_producer_imported'] is False
        assert report['closed_shared_faces_retained'] is True
        assert report['new_original_cells'] == report['new_masks'] == 0
        for key, expected in proof['expected'][label].items():
            assert report[key] == expected, (label, key, report[key], expected)
        reports[label] = dict(path=str(report_path.relative_to(output)), sha256=sha(report_path),
            status=report['status'])
    for name, digest in manifest['files'].items():
        assert sha(packet / name) == digest
    receipt = dict(status='PASS_FRESH_PORTABLE_CD402_WHOLE_ORIGINAL_OPEN_CHECKPOINT',
        original_id=proof['original_id'], original_path=proof['original_path'],
        original_status='OPEN', original_mask='001/00',
        packet_manifest_sha256=sha(packet / 'INPUT_MANIFEST.json'),
        base_C_manifest_sha256=manifest['base_C_manifest_sha256'],
        unchanged_transport_sha256=TRANSPORT_SHA, exact_reports=reports,
        fresh_original_reconstruction=True, certified_bound_deductions=556,
        printed_bound_rows=948, seed_open_leaves=1, all_nine_originals_retained=True,
        saved_reports_used_as_premises=False, C887_or_Cb882_consequences_used=False,
        all_inputs_rehashed_at_completion=True, old_workspace_reads_forbidden=True,
        numerical_imports_forbidden=True, new_original_cells=0, new_masks=0,
        lean_lake_ci_run=False, seconds=time.monotonic() - started)
    (output / 'PORTABLE_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
