"""Freeze the Cd402 checkpoint as a thin addition to published C inputs."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
BASE = Path('/tmp/c_height_portable_packet_v7_20261105')
DEST = HERE / 'delta'
EXPECTED_BASE_SHA = '06115f494173bc344821932525d7a8522df8ea2ed80b400f735f3b68d4a1b58b'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert not DEST.exists()
    assert sha(BASE / 'INPUT_MANIFEST.json') == EXPECTED_BASE_SHA
    base_inventory = json.loads((BASE / 'INPUT_MANIFEST.json').read_text())['files']
    binding = deepcopy(json.loads((BASE / 'BINDINGS.json').read_text()))
    native = WORK / 'd_work/cd402_work'
    selected = {path.resolve() for path in native.iterdir() if path.is_file()}
    selected.update(path.resolve() for path in (native / 'whole_original_complete_cover_seed').iterdir() if path.is_file())
    selected.update((native / 'complete_cover_attachment_controls' / name).resolve()
        for name in ('SEED_EXACT_REPLAY.json', 'PROXY_EXACT_REPLAY.json',
                     'SAT_EXACT_REPLAY.json', 'ANGLE_EXACT_REPLAY.json'))
    for filename in ('other_masks_whole_original_bound3.json',
                     'OTHER_MASKS_WHOLE_ORIGINAL_BOUND3_EXACT_REPLAY.json'):
        saved = json.loads((native / filename).read_text())
        for field in ('source_sha256', 'checker_dependency_sha256'):
            for path, digest in saved.get(field, {}).items():
                assert sha(path) == digest
                selected.add(Path(path).resolve())
    selected.add(WORK / 'd_work/ac_completed_round_angle_search_v3.py')
    selected.update(path.resolve() for path in (WORK / 'global_work/cd402_complete_cover_review').iterdir() if path.is_file())
    selected.update((WORK / 'ac_work/tree' / name).resolve() for name in (
        'CD402_FRESH_ORIGINAL_ATTACHMENT_INDEPENDENT_REVIEW.md',
        'CD402_FRESH_ORIGINAL_ATTACHMENT_INDEPENDENT_REVIEW.json'))
    DEST.mkdir(parents=True)
    added, reused = [], []
    for path in sorted(selected):
        assert path.is_file() and not path.is_symlink() and path.is_relative_to(WORK)
        digest = sha(path)
        old = str(path)
        if old in binding['files']:
            entry = binding['files'][old]
            assert entry['sha256'] == digest
            assert base_inventory[entry['path']] == digest
            assert sha(BASE / entry['path']) == digest
            reused.append(old)
            continue
        relative = Path('payload') / path.relative_to(WORK)
        assert str(relative) not in base_inventory
        target = DEST / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        binding['files'][old] = dict(path=str(relative), sha256=digest)
        added.append(old)
        parent, destination = path.parent, relative.parent
        while parent.is_relative_to(WORK):
            if str(parent) in binding['directories']:
                assert binding['directories'][str(parent)] == str(destination)
            else:
                binding['directories'][str(parent)] = str(destination)
            if parent == WORK:
                break
            parent, destination = parent.parent, destination.parent
    assert len(set(e['path'] for e in binding['files'].values())) == len(binding['files'])
    dump(DEST / 'BINDINGS.json', binding)
    for name in ('materialize_cd402_checkpoint.py', 'replay_portable_cd402_checkpoint.py',
                 'build_cd402_checkpoint_delta.py'):
        shutil.copyfile(HERE / name, DEST / name)
    parent = json.loads((native / 'other_masks_whole_original_bound3.json').read_text())
    proof = dict(schema='Cd402_fresh_original_certified_OPEN_checkpoint_v1',
        original_id=parent['id'], original_path=parent['original_path'],
        original_mask='001/00', original_status='OPEN', squared_radius='1105/256',
        all_nine_originals_retained=True, original_corners=36, original_pairs=36,
        original_cones=5, no_other_original_consequences=True,
        expected=dict(bound=dict(status='PASS_CERTIFIED_CD402_WHOLE_ORIGINAL_STATE_OPEN',
            rounds=3, deductions=556, printed_rows_checked=948,
            unit_four_corner_row_occurrences_checked=64),
            seed=dict(status='PASS_PARTIAL_WHOLE_ORIGINAL_CD402_COVER',
                nodes=1, excluded_leaves=0, open_leaves=1, rounds=0,
                deductions=0, printed_rows_checked=0)),
        new_original_cells=0, new_masks=0)
    dump(DEST / 'CD402_CHECKPOINT_PROOF.json', proof)
    files = {str(path.relative_to(DEST)): sha(path) for path in sorted(DEST.rglob('*')) if path.is_file()}
    dump(DEST / 'DELTA_MANIFEST.json', dict(schema='Cd402_checkpoint_thin_delta_v1',
        base_C_commit='8e842e98a4f31fa9e0a2d8ece42bc2661a2783c2',
        base_manifest_sha256=EXPECTED_BASE_SHA, files=files,
        new_native_files=len(added), reused_native_files=len(reused),
        mathematical_source_bytes_unchanged=True, new_original_cells=0, new_masks=0))
    print(json.dumps(dict(status='FROZEN_CD402_OPEN_CHECKPOINT_DELTA', files=len(files),
        new_native_files=len(added), reused_native_files=len(reused),
        delta_manifest_sha256=sha(DEST / 'DELTA_MANIFEST.json'))), flush=True)


if __name__ == '__main__':
    main()
