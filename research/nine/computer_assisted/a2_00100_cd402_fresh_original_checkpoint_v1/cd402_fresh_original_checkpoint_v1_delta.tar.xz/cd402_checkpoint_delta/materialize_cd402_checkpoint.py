"""Add byte-preserved Cd402 inputs to the published C source packet."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

BASE_MANIFEST_SHA = '06115f494173bc344821932525d7a8522df8ea2ed80b400f735f3b68d4a1b58b'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--delta', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base, delta, output = args.base.resolve(), args.delta.resolve(), args.output.resolve()
    assert not output.exists()
    assert sha(base / 'INPUT_MANIFEST.json') == BASE_MANIFEST_SHA
    before = json.loads((base / 'INPUT_MANIFEST.json').read_text())['files']
    change = json.loads((delta / 'DELTA_MANIFEST.json').read_text())
    assert change['base_manifest_sha256'] == BASE_MANIFEST_SHA
    for name, digest in before.items():
        path = base / name
        assert path.resolve().is_relative_to(base) and sha(path) == digest
    for name, digest in change['files'].items():
        path = delta / name
        assert path.resolve().is_relative_to(delta) and sha(path) == digest
    output.mkdir(parents=True)
    for name, digest in before.items():
        if name in ('BINDINGS.json',):
            continue
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        # Hard links only reuse immutable bytes; no inherited file is modified.
        try:
            target.hardlink_to(base / name)
        except OSError:
            shutil.copyfile(base / name, target)
        assert sha(target) == digest
    shutil.copyfile(base / 'INPUT_MANIFEST.json', output / 'C_BASE_INPUT_MANIFEST.json')
    for name, digest in change['files'].items():
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert sha(target) == digest
        else:
            shutil.copyfile(delta / name, target)
        assert sha(target) == digest
    files = {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
    (output / 'INPUT_MANIFEST.json').write_text(json.dumps(dict(
        schema='Cd402_whole_original_checkpoint_inputs_v1', files=files,
        base_C_manifest_sha256=BASE_MANIFEST_SHA, mathematical_source_bytes_unchanged=True,
        new_original_cells=0, new_masks=0), indent=2) + '\n')
    for name, digest in before.items():
        assert sha(base / name) == digest
    print(json.dumps(dict(status='MATERIALIZED_CD402_WHOLE_ORIGINAL_OPEN_CHECKPOINT',
        base_inputs=len(before), new_delta_files=len(change['files']), inputs=len(files),
        input_manifest_sha256=sha(output / 'INPUT_MANIFEST.json'),
        input_bytes=sum((output / name).stat().st_size for name in files),
        original_status='OPEN', new_original_cells=0, new_masks=0)), flush=True)


if __name__ == '__main__':
    main()
