"""Prepare a one-node whole-original tree after fresh exact parent replay."""
from pathlib import Path
from copy import deepcopy
import argparse
import json
import sys
import verify_cd402_whole_original_tree as CHECK


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    assert not output.exists()
    checker = CHECK.ALL.Checker()
    adapter = CHECK.ALL.Adapter(checker)
    reference = dict(path=str(CHECK.PARENT), sha256=CHECK.PARENT_SHA)
    audit, state, bindings = CHECK.parent_state(reference, adapter)
    CHECK.ALL.verify_all_bindings()
    for path, digest in bindings.items():
        assert CHECK.sha(path) == digest
    parent = json.loads(CHECK.PARENT.read_text())
    view = CHECK.SAT.state_view(state)
    record = dict(id=CHECK.ORIGINAL.TARGET, original_path=CHECK.ORIGINAL.ORIGINAL_PATH,
        status='OPEN', initial=view, rounds=[], final=deepcopy(view),
        unsearched_closed_domain=True)
    for key in ('point', 'phase'):
        if key in parent['record']:
            record[key] = deepcopy(parent['record'][key])
    output.mkdir(parents=True)
    node_path = output / 'node_00000.json'
    node_path.write_text(json.dumps(record, indent=2) + '\n')
    manifest = dict(schema=CHECK.SCHEMA, id=CHECK.ORIGINAL.TARGET,
        original_path=CHECK.ORIGINAL.ORIGINAL_PATH, original_mask='001/00',
        squared_radius='1105/256', scope='WHOLE_UNCHANGED_ORIGINAL_PARENT',
        parent=reference, status='OPEN',
        source_sha256={str(Path(__file__).resolve()): CHECK.sha(__file__),
            str(Path(CHECK.__file__).resolve()): CHECK.sha(CHECK.__file__)},
        nodes=[dict(index=0, parent=None, depth=0, restriction=None,
            file='node_00000.json', sha256=CHECK.sha(node_path), children=[], status='OPEN')],
        new_original_cells=0, new_masks=0)
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy',
        'cd402_original_runtime', 'ac_objective_unit_four_corner_runtime'))
    print(json.dumps(dict(status='PREPARED_CD402_WHOLE_ORIGINAL_COMPLETE_OPEN_COVER',
        parent_rounds=audit['rounds'], parent_deductions=audit['deductions'],
        parent_printed_rows=audit['printed_rows_checked'],
        manifest_sha256=CHECK.sha(output / 'manifest.json'),
        numerical_optimizer_called=False, new_original_cells=0, new_masks=0)), flush=True)


if __name__ == '__main__':
    main()
