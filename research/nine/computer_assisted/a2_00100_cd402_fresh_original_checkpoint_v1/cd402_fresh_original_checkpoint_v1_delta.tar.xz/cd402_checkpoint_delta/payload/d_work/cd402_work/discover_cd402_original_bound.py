"""Bound the fresh complete Cd402 original, or prepare without an LP solve."""
from pathlib import Path
from copy import deepcopy
import argparse
import json
import time
from cd402_original_runtime import Context, E, source_bindings, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--static-model', type=Path)
    args = parser.parse_args()
    assert not args.output.exists() and args.rounds >= 0
    started = time.monotonic()
    context = Context()
    state, declaration = context.original()
    source = deepcopy(declaration)
    source['source_sha256'].update(source_bindings())
    source['source_sha256'][str(Path(__file__).resolve())] = sha(__file__)
    source['discovery_engine'] = dict(path=str(Path(E.__file__).resolve()), sha256=sha(E.__file__))
    if args.static_model:
        assert not args.static_model.exists()
        rows, bounds, propagated, terminal = context.collect(state)
        static = dict(original_id=state['id'], original_path=state['path'],
            original_initial=E.stateview(state), terminal=terminal,
            numerical_optimizer_called=False, new_original_cells=0, new_masks=0)
        if terminal is None:
            static['printed_rows'] = E.printed(rows, range(len(rows)))
            static['absolute_variable_bounds'] = list(map(str, bounds))
            static['propagated'] = E.stateview(propagated)
        args.static_model.parent.mkdir(parents=True, exist_ok=True)
        args.static_model.write_text(json.dumps(static, indent=2) + '\n')
    def write(record):
        value = dict(source, record=record)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.output.with_suffix('.tmp.json')
        temporary.write_text(json.dumps(value, indent=2) + '\n')
        temporary.replace(args.output)
    if args.prepare_only:
        record = deepcopy(source['record'])
    else:
        record, after, point = E.search_node(context, state, args.rounds, checkpoint=write)
    write(record)
    for name, digest in source['source_sha256'].items():
        assert sha(name) == digest
    print(json.dumps(dict(status=record['status'], rounds=len(record['rounds']),
        deductions=sum(len(r['proposals']) for r in record['rounds']),
        prepare_only=args.prepare_only, numerical_optimizer_called=not args.prepare_only,
        output_sha256=sha(args.output), seconds=time.monotonic() - started,
        new_original_cells=0, new_masks=0)), flush=True)


if __name__ == '__main__':
    main()
