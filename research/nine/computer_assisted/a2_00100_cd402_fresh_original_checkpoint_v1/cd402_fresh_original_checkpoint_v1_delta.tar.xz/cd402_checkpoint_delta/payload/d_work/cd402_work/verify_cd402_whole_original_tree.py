"""Exact complete Cd402 tree from a freshly replayed whole-original bound.

The original initializer, physical row adapters and rational arithmetic are
frozen. This adds only their explicit whole-original 4/8/2 cover traversal.
Node payloads are read lazily and every referenced input is rehashed.
"""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
from itertools import product
from collections import Counter
import argparse
import json
import sys
import time
import verify_cd402_original_bound as ORIGINAL
from verify_cd402_original_bound import ALL, SAT, sha
import independent_physical_proxy_cover as PROXY

BOUND_CHECKER_SHA = 'e658d2aa3b464fd457e7bb3a9e11b5dd5c62b27de20f508f635a1e2ef22aff77'
PARENT = ORIGINAL.HERE / 'other_masks_whole_original_bound3.json'
PARENT_SHA = '3e416f74d97c2badf6d2de427b24f62066cf96b808fea39197275373c9e5ac7f'
PROXY_SHA = '3b46b8a966c712e23894ae4cd7964355730f2bfe3c58a04871ade9d35ddf1277'
SCHEMA = 'Cd402_whole_original_complete_physical_tree_v1'


def parent_state(reference, adapter):
    assert sha(ORIGINAL.__file__) == BOUND_CHECKER_SHA
    assert sha(ALL.__file__) == ORIGINAL.ADAPTER_SHA
    assert sha(SAT.__file__) == ORIGINAL.CORE_SHA
    assert sha(PROXY.__file__) == PROXY_SHA
    assert reference == dict(path=str(PARENT), sha256=PARENT_SHA)
    assert sha(PARENT) == PARENT_SHA
    saved = json.loads(PARENT.read_text())
    state = ORIGINAL.check_declaration(saved, adapter)
    bindings = {str(PARENT): PARENT_SHA}
    for path, digest in saved['source_sha256'].items():
        assert sha(path) == digest
        bindings[path] = digest
    audit, after = SAT.check_record(saved['record'], state, adapter)
    assert after is not None and after['id'] == ORIGINAL.TARGET
    assert after['path'] == ORIGINAL.ORIGINAL_PATH
    return audit, after, bindings


def angle_child(parent, owner, cut, side, adapter):
    assert type(owner) is int and 0 <= owner < 9
    assert type(side) is int and side in (0, 1)
    cut = F(cut)
    lo, hi = parent['angles'][owner]
    assert lo < cut < hi
    child = deepcopy(parent)
    angles = list(child['angles'])
    angles[owner] = (lo, cut) if side == 0 else (cut, hi)
    child['angles'] = tuple(angles)
    child['path'] = deepcopy(parent['path']) + [['angle_cut', [owner, str(cut)], side]]
    child['choices'] = adapter.choices(child['path'])
    SAT.valid_state(child)
    return child


def replay(folder, output):
    assert __debug__
    started = time.monotonic()
    folder, output = Path(folder).resolve(), Path(output).resolve()
    manifest_path = folder / 'manifest.json'
    manifest_sha = sha(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    assert manifest['schema'] == SCHEMA
    assert manifest['scope'] == 'WHOLE_UNCHANGED_ORIGINAL_PARENT'
    assert manifest['id'] == ORIGINAL.TARGET
    assert manifest['original_path'] == ORIGINAL.ORIGINAL_PATH
    assert manifest['original_mask'] == '001/00'
    assert manifest['squared_radius'] == '1105/256'
    assert manifest['new_original_cells'] == manifest['new_masks'] == 0
    assert not any(key in manifest for key in ('component', 'closed_domain',
        'global_original_union', 'whole_original_height_exclusion_consequences',
        'whole_original_height_bound_state', 'component3_shared_bound_state'))
    checker = ALL.Checker()
    adapter = ALL.Adapter(checker)
    ancestor, state, bindings = parent_state(manifest['parent'], adapter)
    bindings[str(manifest_path)] = manifest_sha
    for path, digest in manifest['source_sha256'].items():
        assert sha(path) == digest
        bindings[path] = digest
    entries = manifest['nodes']
    assert entries and [node['index'] for node in entries] == list(range(len(entries)))
    assert all(type(node['index']) is int for node in entries)
    nodes = {node['index']: node for node in entries}
    for index, node in nodes.items():
        assert node['file'] == f'node_{index:05d}.json'
        path = folder / node['file']
        assert sha(path) == node['sha256']
        bindings[str(path)] = node['sha256']
    visited, audits, covers, leaves = set(), [], [], []

    def visit(index, initial, parent_index=None, depth=0, restriction=None):
        assert type(index) is int and index in nodes and index not in visited
        visited.add(index)
        node = nodes[index]
        assert (node['parent'], node['depth'], node['restriction']) == (parent_index, depth, restriction)
        path = folder / node['file']
        assert sha(path) == node['sha256']
        record = json.loads(path.read_text())
        assert record['id'] == ORIGINAL.TARGET
        assert record['original_path'] == ORIGINAL.ORIGINAL_PATH
        audit, after = SAT.check_record(record, initial, adapter)
        audit.update(index=index, parent=parent_index, depth=depth, restriction=restriction,
            terminal_kind=record.get('terminal', {}).get('kind'))
        audits.append(audit)
        children = node['children']
        assert isinstance(children, list) and len(children) == len(set(children))
        assert all(type(child) is int and child in nodes for child in children)
        if after is None:
            assert children == [] and 'split' not in node
            assert node['status'] == 'CANDIDATE_CLOSED'
            leaves.append(dict(index=index, excluded=True,
                terminal_kind=record['terminal']['kind']))
            return True
        if not children:
            assert node['status'] in ('OPEN', 'OPEN_NO_SPLIT_SELECTED') and 'split' not in node
            leaves.append(dict(index=index, excluded=False))
            return False
        del record
        assert node['complete_children'] is True
        split = node['split']
        outcomes = []
        restrictions = [nodes[child]['restriction'] for child in children]
        if split['kind'] in ('complete_physical_proxy', 'complete_physical_sat'):
            pair = tuple(split['pair'])
            assert len(pair) == 2 and all(type(k) is int for k in pair)
            assert 0 <= pair[0] < pair[1] < 9
            is_sat = split['kind'] == 'complete_physical_sat'
            kind = 'physical_sat' if is_sat else 'physical_proxy'
            expected = set(product(pair, (0, 1), (-1, 1))) if is_sat else set(product((0, 1), (-1, 1)))
            assert all(set(r) == {'kind', 'pair', 'choice'} and r['kind'] == kind
                and r['pair'] == list(pair) for r in restrictions)
            actual = [tuple(r['choice']) for r in restrictions]
            assert all(all(type(k) is int for k in choice) for choice in actual)
            assert len(actual) == len(set(actual)) == len(expected) and set(actual) == expected
            if not is_sat:
                PROXY.check_choices([r['choice'] for r in restrictions])
            for child_index, child_restriction in zip(children, restrictions):
                if is_sat:
                    child = SAT.sat_child(after, pair, child_restriction['choice'], adapter)
                else:
                    child = PROXY.proxy_child(after, pair, child_restriction['choice'], adapter)
                outcomes.append(visit(child_index, child, index, depth + 1, child_restriction))
        else:
            assert split['kind'] == 'closed_angle_bisection'
            owner, cut = split['owner'], F(split['cut'])
            assert len(children) == 2 and sorted(r['side'] for r in restrictions) == [0, 1]
            assert all(set(r) == {'kind', 'owner', 'cut', 'side'}
                and r['kind'] == 'closed_angle' and type(r['owner']) is int
                and r['owner'] == owner and F(r['cut']) == cut for r in restrictions)
            for child_index, child_restriction in zip(children, restrictions):
                child = angle_child(after, owner, cut, child_restriction['side'], adapter)
                outcomes.append(visit(child_index, child, index, depth + 1, child_restriction))
        excluded = all(outcomes)
        assert node['status'] == ('CANDIDATE_COVER_CLOSED' if excluded else 'OPEN')
        covers.append(dict(index=index, kind=split['kind'], children=children,
            all_closed_alternatives_present=True, all_children_excluded=excluded,
            shared_closed_faces_retained=True))
        return excluded

    closed = visit(0, state)
    assert visited == set(nodes)
    assert manifest['status'] == ('CANDIDATE_COVER_CLOSED' if closed else 'OPEN')
    for path, digest in bindings.items():
        assert sha(path) == digest
    ALL.verify_all_bindings()
    assert sha(ORIGINAL.REGISTER) == ORIGINAL.REGISTER_SHA
    for name, digest in checker.frozen_inventory.items():
        assert sha(ALL.OLD.PKG / name) == digest
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy',
        'cd402_original_runtime', 'ac_objective_unit_four_corner_runtime',
        'physical_sat_engine_snapshot', 'physical_sat_diagonal_engine',
        'c887_whole_height_bound_rows', 'c_height_exclusion_consequence_rows',
        'cb882_whole_height_bound_rows'))
    report = dict(schema='independent_Cd402_whole_original_complete_tree_replay_v1',
        status='PASS_COMPLETE_WHOLE_ORIGINAL_CD402' if closed else 'PASS_PARTIAL_WHOLE_ORIGINAL_CD402_COVER',
        original_id=ORIGINAL.TARGET, original_path=ORIGINAL.ORIGINAL_PATH,
        original_mask='001/00', squared_radius='1105/256',
        parent=manifest['parent'], manifest_sha256=manifest_sha,
        whole_original_excluded=closed, nodes=len(nodes), leaf_domains=len(leaves),
        excluded_leaves=sum(leaf['excluded'] for leaf in leaves),
        open_leaves=sum(not leaf['excluded'] for leaf in leaves),
        closed_unions=dict(Counter(cover['kind'] for cover in covers)),
        rounds=sum(audit['rounds'] for audit in audits),
        deductions=sum(audit['deductions'] for audit in audits),
        printed_rows_checked=sum(audit['printed_rows_checked'] for audit in audits),
        fresh_whole_original_ancestor=ancestor, node_audits=audits,
        leaf_table=leaves, complete_closed_covers=covers,
        input_sha256=bindings, checker_dependency_sha256=ORIGINAL.source_bindings(),
        unit_four_corner_row_occurrences_checked=checker.unit_four_corner_row_occurrences,
        original_corner_disk_row_occurrences_checked=checker.corner_row_occurrences,
        owner_free_row_occurrences_checked=checker.owner_free_occurrences,
        all_nine_originals_retained=True, original_corners=36, original_pairs=36,
        original_cones=5, exact_mask_bits_retained=True,
        no_other_original_consequence_imported=True, closed_shared_faces_retained=True,
        node_payloads_replayed_lazily=True, numerical_producer_imported=False,
        hand_table_and_publication_acceptance_separate=True,
        new_original_cells=0, new_masks=0, lean_lake_ci_run=False,
        seconds=time.monotonic() - started)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'nodes', 'excluded_leaves',
        'open_leaves', 'deductions', 'printed_rows_checked', 'seconds')}), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('folder', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    replay(args.folder, args.output)
