"""Exact complete-cover attachment controls; no optimizer or search."""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
from itertools import product
import json
import shutil
import sys
import time
import verify_cd402_whole_original_tree as CHECK

HERE = Path(__file__).resolve().parent
OUT = HERE / 'complete_cover_attachment_controls'
SEED = HERE / 'whole_original_complete_cover_seed'


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def modify_record(folder, index, change):
    manifest = json.loads((folder / 'manifest.json').read_text())
    node = manifest['nodes'][index]
    path = folder / node['file']
    record = json.loads(path.read_text())
    change(record)
    dump(path, record)
    node['sha256'] = CHECK.sha(path)
    dump(folder / 'manifest.json', manifest)


def main():
    started = time.monotonic()
    assert not OUT.exists()
    OUT.mkdir()
    manifest = json.loads((SEED / 'manifest.json').read_text())
    checker = CHECK.ALL.Checker()
    adapter = CHECK.ALL.Adapter(checker)
    _, state, _ = CHECK.parent_state(manifest['parent'], adapter)
    fixture_reports = {}
    fixture_reports['seed'] = CHECK.replay(SEED, OUT / 'SEED_EXACT_REPLAY.json')
    for kind in ('proxy', 'sat', 'angle'):
        folder = OUT / kind
        shutil.copytree(SEED, folder)
        m = deepcopy(manifest)
        root = m['nodes'][0]
        if kind == 'angle':
            cut = F(-1, 2)
            assert state['angles'][3][0] < cut < state['angles'][3][1]
            split = dict(kind='closed_angle_bisection', owner=3, cut=str(cut))
            restrictions = [dict(kind='closed_angle', owner=3, cut=str(cut), side=side)
                for side in (0, 1)]
            states = [CHECK.angle_child(state, 3, cut, r['side'], adapter) for r in restrictions]
        else:
            pair = (7, 8)
            choices = product(pair, (0, 1), (-1, 1)) if kind == 'sat' else product((0, 1), (-1, 1))
            split = dict(kind='complete_physical_' + kind, pair=list(pair))
            restrictions = [dict(kind='physical_' + kind, pair=list(pair), choice=list(choice))
                for choice in choices]
            child = CHECK.SAT.sat_child if kind == 'sat' else CHECK.PROXY.proxy_child
            states = [child(state, pair, r['choice'], adapter) for r in restrictions]
        root.update(split=split, complete_children=True, children=list(range(1, len(states) + 1)))
        for index, (restriction, child_state) in enumerate(zip(restrictions, states), 1):
            view = CHECK.SAT.state_view(child_state)
            record = dict(id=CHECK.ORIGINAL.TARGET, original_path=CHECK.ORIGINAL.ORIGINAL_PATH,
                status='OPEN', initial=view, rounds=[], final=deepcopy(view))
            path = folder / f'node_{index:05d}.json'
            dump(path, record)
            m['nodes'].append(dict(index=index, parent=0, depth=1, restriction=restriction,
                file=path.name, sha256=CHECK.sha(path), children=[], status='OPEN'))
        dump(folder / 'manifest.json', m)
        report = CHECK.replay(folder, OUT / (kind.upper() + '_EXACT_REPLAY.json'))
        assert report['status'] == 'PASS_PARTIAL_WHOLE_ORIGINAL_CD402_COVER'
        assert report['excluded_leaves'] == 0 and report['open_leaves'] == len(states)
        assert report['closed_unions'] == {split['kind']: 1}
        fixture_reports[kind] = report

    cases = [
        ('wrong_original_mask', 'proxy', lambda m: m.update(original_mask='011/00'), None),
        ('wrong_parent_hash', 'proxy', lambda m: m['parent'].update(sha256='0' * 64), None),
        ('foreign_C_height_consequence', 'proxy', lambda m: m.update(whole_original_height_bound_state={}), None),
        ('changed_root_state', 'proxy', None,
            lambda r: r['initial']['positions'][0].__setitem__(0, '-2')),
        ('missing_proxy_alternative', 'proxy', lambda m: m['nodes'][0]['children'].pop(), None),
        ('duplicate_proxy_choice', 'proxy',
            lambda m: m['nodes'][2]['restriction'].update(choice=m['nodes'][1]['restriction']['choice']), None),
        ('missing_SAT_alternative', 'sat', lambda m: m['nodes'][0]['children'].pop(), None),
        ('duplicate_SAT_child', 'sat', lambda m: m['nodes'][0]['children'].__setitem__(1, 1), None),
        ('different_angle_cut', 'angle', lambda m: m['nodes'][1]['restriction'].update(cut='-1/3'), None),
        ('boolean_angle_side', 'angle', lambda m: m['nodes'][2]['restriction'].update(side=True), None),
        ('wrong_original_path', 'proxy', lambda m: m.update(original_path=[]), None),
        ('OPEN_as_complete', 'proxy', lambda m: m.update(status='CANDIDATE_COVER_CLOSED'), None),
    ]
    rejected = []
    for name, base, mutate, record_mutation in cases:
        folder = OUT / ('damaged_' + name)
        shutil.copytree(OUT / base, folder)
        if mutate is not None:
            m = json.loads((folder / 'manifest.json').read_text())
            mutate(m)
            dump(folder / 'manifest.json', m)
        if record_mutation is not None:
            modify_record(folder, 0, record_mutation)
        report_path = OUT / (name + '_UNEXPECTED_PASS.json')
        try:
            CHECK.replay(folder, report_path)
        except AssertionError:
            assert not report_path.exists()
            rejected.append(name)
        else:
            raise AssertionError(('damaged cover unexpectedly accepted', name))
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy',
        'cd402_original_runtime', 'ac_objective_unit_four_corner_runtime'))
    result = dict(status='PASS_CD402_FRESH_ORIGINAL_COMPLETE_COVER_ATTACHMENT_CONTROLS',
        independent_checker_sha256=CHECK.sha(CHECK.__file__),
        parent_sha256=CHECK.PARENT_SHA, fixture_original_id=CHECK.ORIGINAL.TARGET,
        valid_fixtures={key: dict(nodes=r['nodes'], open_leaves=r['open_leaves'],
            closed_unions=r['closed_unions']) for key, r in fixture_reports.items()},
        rejected_damaged_covers=rejected, rejected_count=len(rejected),
        numerical_optimizer_called=False, new_original_cells=0, new_masks=0,
        seconds=time.monotonic() - started)
    dump(HERE / 'CD402_COMPLETE_COVER_ATTACHMENT_CONTROLS.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
