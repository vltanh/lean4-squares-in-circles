"""Create the exact unstrengthened Cd402 starting record, with no optimizer."""
from pathlib import Path
import json
import sys
import verify_cd402_original_bound as CHECK


def main():
    output = Path(sys.argv[1]).resolve()
    assert not output.exists()
    checker = CHECK.ALL.Checker()
    adapter = CHECK.ALL.Adapter(checker)
    state = CHECK.fresh_original(adapter)
    initial = CHECK.SAT.state_view(state)
    declaration = dict(schema='Cd402_fresh_original_physical_bound_discovery_v1',
        id=CHECK.TARGET, original_path=CHECK.ORIGINAL_PATH,
        scope='WHOLE_UNCHANGED_ORIGINAL_PARENT', original_mask='001/00',
        squared_radius='1105/256',
        original_register=dict(path=str(CHECK.REGISTER), sha256=CHECK.REGISTER_SHA),
        initial=initial, record=dict(status='OPEN', initial=initial, rounds=[], final=initial),
        source_sha256=CHECK.source_bindings(), all_nine_original_squares_retained=True,
        original_corner_predicates=36, original_pair_predicates=36, marked_cones=5,
        closed_shared_faces_retained=True, no_other_original_consequence_imported=True,
        new_original_cells=0, new_masks=0)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(declaration, indent=2) + '\n')
    print(json.dumps(dict(status='FRESH_CD402_ORIGINAL_DECLARED_WITHOUT_OPTIMIZER',
        path=str(output), sha256=CHECK.sha(output), initial_choices=repr(state['choices']),
        new_original_cells=0, new_masks=0)), flush=True)


if __name__ == '__main__':
    main()
