"""Independent original-Cd402 initialization and exact bound-record replay.

Only the fresh-original entry point is new. All physical row and arithmetic
checking uses the frozen general 001/00 exact adapters, without C887 or
Cb882 consequence attachments.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
AC = WORK / 'ac_work/tree'
sys.path.insert(0, str(AC))
import verify_c887_unit_four_corner_tree as ALL
import independent_physical_sat_diagonal_replay as SAT

TARGET = 'negative-d4021ade840b985c'
ORIGINAL_PATH = [['angle', 3, 0], ['angle_cut', [0, '0'], 1],
                 ['alternate_four_escape', [1, 7], [2]]]
REGISTER = ALL.OLD.PKG / 'ancestry/legacy/current_proof/original_register.json'
REGISTER_SHA = 'ea000e84c04675fe22424e5c20d3df9d735d659065349800aef2699170bff604'
ADAPTER_SHA = 'b06b754193bdab0f01e250cd4378e751337ef6039a40db27b97e6aba3e82eb87'
CORE_SHA = 'a96a5ea5890553a7db6a0d22fb6245ec5b9b98851d5afc039d154989aab21301'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_bindings():
    answer = {str(Path(__file__).resolve()): sha(__file__), str(REGISTER): REGISTER_SHA}
    for module in tuple(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name is None:
            continue
        path = Path(name).resolve()
        if path.is_relative_to(WORK) and path.is_file():
            answer[str(path)] = sha(path)
    return answer


def fresh_original(adapter):
    assert sha(REGISTER) == REGISTER_SHA
    register = json.loads(REGISTER.read_text())
    assert register['target_mask'] == '001/00' and register['target_q'] == '1105/256'
    assert register['coverage_certified'] is True
    found = [cell for cell in register['cells'] if cell['id'] == TARGET]
    assert len(found) == 1
    cell = found[0]
    assert cell['path'] == ORIGINAL_PATH and cell['sign'] == 'negative'
    assert cell['baseline_frontier_index'] == 30
    encoded = json.dumps(ORIGINAL_PATH, separators=(',', ':')).encode()
    assert TARGET == 'negative-' + hashlib.sha256(encoded).hexdigest()[:16]
    assert adapter.K.V.Q == F(1105, 256)
    assert adapter.K.V.EDGES == ((0, 1, 0), (1, 2, 0), (2, 3, 1), (4, 5, 0), (5, 6, 0))
    angles, positions, choices = adapter.K.V.reconstruct(ORIGINAL_PATH)
    angles = tuple(map(tuple, angles))
    positions = tuple(map(tuple, positions))
    state = dict(id=TARGET, path=ORIGINAL_PATH, angles=angles, positions=positions,
        choices=choices, scalar=adapter.analytic(angles), differences={}, diagonal={})
    SAT.valid_state(state)
    assert len(state['angles']) == 9 and len(state['positions']) == 18
    assert len(state['scalar']) == 36
    return state


def check_declaration(saved, adapter):
    assert saved['schema'] == 'Cd402_fresh_original_physical_bound_discovery_v1'
    assert saved['id'] == TARGET and saved['original_path'] == ORIGINAL_PATH
    assert saved['scope'] == 'WHOLE_UNCHANGED_ORIGINAL_PARENT'
    assert saved['original_register'] == dict(path=str(REGISTER), sha256=REGISTER_SHA)
    assert saved['original_mask'] == '001/00' and saved['squared_radius'] == '1105/256'
    assert saved['all_nine_original_squares_retained'] is True
    assert saved['original_corner_predicates'] == saved['original_pair_predicates'] == 36
    assert saved['marked_cones'] == 5 and saved['closed_shared_faces_retained'] is True
    assert saved['no_other_original_consequence_imported'] is True
    assert saved['new_original_cells'] == saved['new_masks'] == 0
    state = fresh_original(adapter)
    assert saved['initial'] == SAT.state_view(state)
    return state


def replay(source, output):
    started = time.monotonic()
    assert __debug__
    source, output = Path(source).resolve(), Path(output).resolve()
    source_sha = sha(source)
    assert sha(ALL.__file__) == ADAPTER_SHA and sha(SAT.__file__) == CORE_SHA
    checker = ALL.Checker()
    adapter = ALL.Adapter(checker)
    saved = json.loads(source.read_text())
    state = check_declaration(saved, adapter)
    for name, digest in saved['source_sha256'].items():
        assert sha(name) == digest
    audit, final = SAT.check_record(saved['record'], state, adapter)
    ALL.verify_all_bindings()
    for name, digest in saved['source_sha256'].items():
        assert sha(name) == digest
    assert sha(source) == source_sha and sha(REGISTER) == REGISTER_SHA
    for name, digest in checker.frozen_inventory.items():
        assert sha(ALL.OLD.PKG / name) == digest
    forbidden = ('numpy', 'scipy', 'highspy', 'ac_physical_context',
        'ac_objective_unit_four_corner_runtime', 'physical_sat_engine_snapshot',
        'cd402_original_runtime', 'c887_whole_height_bound_rows',
        'c_height_exclusion_consequence_rows', 'cb882_whole_height_bound_rows')
    assert not any(name in sys.modules for name in forbidden)
    result = dict(audit,
        status='PASS_CERTIFIED_CD402_WHOLE_ORIGINAL_STATE_OPEN' if final is not None
               else 'PASS_EXACT_CD402_WHOLE_ORIGINAL_EXCLUSION',
        original_id=TARGET, original_path=ORIGINAL_PATH, original_mask='001/00',
        squared_radius='1105/256', original_register_sha256=REGISTER_SHA,
        all_nine_original_squares_retained=True, original_corner_predicates=36,
        original_pair_predicates=36, marked_cones=5, closed_shared_faces_retained=True,
        no_other_original_consequence_imported=True,
        final=SAT.state_view(final) if final is not None else None,
        source_sha256=saved['source_sha256'], certificate_sha256=source_sha,
        checker_dependency_sha256=source_bindings(),
        unit_four_corner_row_occurrences_checked=checker.unit_four_corner_row_occurrences,
        original_corner_disk_row_occurrences_checked=checker.corner_row_occurrences,
        owner_free_row_occurrences_checked=checker.owner_free_occurrences,
        numerical_producer_imported=False, new_original_cells=0, new_masks=0,
        hand_table_and_publication_acceptance_separate=True,
        lean_lake_ci_run=False, seconds=time.monotonic() - started)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'rounds', 'deductions',
        'printed_rows_checked', 'unit_four_corner_row_occurrences_checked', 'seconds')}), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    replay(args.source, args.output)
