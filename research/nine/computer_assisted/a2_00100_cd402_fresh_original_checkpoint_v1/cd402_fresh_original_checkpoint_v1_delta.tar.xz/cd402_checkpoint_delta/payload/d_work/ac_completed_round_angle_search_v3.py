"""Discovery-only early angle selection at already-computed phase points.

The physical row builder, LP calls, rational certificate format, arithmetic
and terminal construction remain those of the explicitly supplied runtime engine object.
"""
import time


def search_node(E, context, state, rounds=0, checkpoint=None, early_angle=None):
    initial = E.stateview(state)
    records = []
    started = time.monotonic()
    for ri in range(rounds + 1):
        rows, bounds, propagated, terminal = context.collect(state)
        if terminal:
            return dict(status='CANDIDATE_CLOSED', initial=initial,
                rounds=records, terminal=terminal,
                seconds=time.monotonic() - started), None, None
        h, phase, point, terminal = E.phase_solve(rows, bounds)
        if terminal and terminal['kind'] != 'solver_no_conclusion':
            return dict(status='CANDIDATE_CLOSED', initial=initial,
                rounds=records, terminal_state=E.stateview(state),
                terminal=terminal, seconds=time.monotonic() - started), None, None
        if terminal:
            return dict(status='NO_NUMERICAL_CONCLUSION', initial=initial,
                rounds=records, diagnostic=terminal,
                seconds=time.monotonic() - started), state, None
        selected = None
        if early_angle is not None and 0 < ri < rounds:
            selected = early_angle(state, point, ri)
        if ri == rounds or selected is not None:
            result = dict(status='OPEN', initial=initial, rounds=records,
                final=E.stateview(state), phase=phase,
                best_pairs=E.best_pairs(state, point), point=point,
                seconds=time.monotonic() - started)
            if selected is not None:
                result['discovery_early_angle'] = dict(requested_rounds=rounds,
                    completed_rounds=ri, split=selected,
                    checked_after_each_completed_round=True)
            return result, state, point
        after, record, terminal = E.bound_round(context, state, rows, bounds, propagated, h)
        record['phase'] = phase
        records.append(record)
        context.AH.SEED_NAMES.update(row['name'] for row in record['printed_rows'])
        print('BOUND_ROUND', ri, 'deductions', len(record['proposals']),
              'seconds', round(time.monotonic() - started, 2), flush=True)
        if checkpoint is not None:
            checkpoint(dict(status='RUNNING', initial=initial, rounds=records,
                terminal=terminal, latest=E.stateview(after) if after is not None else None,
                seconds=time.monotonic() - started))
        if terminal:
            return dict(status='CANDIDATE_CLOSED', initial=initial,
                rounds=records, terminal=terminal,
                seconds=time.monotonic() - started), None, None
        state = after
    raise AssertionError('unreachable')
