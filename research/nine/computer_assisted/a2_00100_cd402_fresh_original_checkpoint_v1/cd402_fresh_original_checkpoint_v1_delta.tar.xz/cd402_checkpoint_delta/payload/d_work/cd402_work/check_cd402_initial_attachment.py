"""Exact initial-state, static-row and damaged-caller checks; no LP solve."""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
import json
import sys
import time
import verify_cd402_original_bound as CHECK


def main():
    started = time.monotonic()
    root = Path(__file__).resolve().parent
    source = root / 'CD402_NUMERICAL_PREPARED_ORIGINAL.json'
    model = root / 'CD402_INITIAL_STATIC_MODEL.json'
    before = {str(path): CHECK.sha(path) for path in (source, model)}
    declaration = json.loads(source.read_text())
    static = json.loads(model.read_text())
    checker = CHECK.ALL.Checker()
    adapter = CHECK.ALL.Adapter(checker)
    state = CHECK.check_declaration(declaration, adapter)
    assert static['original_id'] == CHECK.TARGET
    assert static['original_path'] == CHECK.ORIGINAL_PATH
    assert static['original_initial'] == CHECK.SAT.state_view(state)
    assert static['numerical_optimizer_called'] is False
    if static['terminal'] is not None:
        assert adapter.verify_early_terminal(state, static['terminal']) is True
        count = 0
    else:
        rows = static['printed_rows']
        assert [row['index'] for row in rows] == list(range(len(rows)))
        answer, bounds, propagated = adapter.rebuild(state, rows)
        assert set(answer) == set(range(len(rows)))
        for row in rows:
            assert answer[row['index']] == (
                tuple((index, F(value)) for index, value in row['coefficients']),
                F(row['rhs']), row['name'])
        assert static['absolute_variable_bounds'] == list(map(str, bounds))
        assert static['propagated'] == CHECK.SAT.state_view(propagated)
        count = len(rows)
    rejected = []
    def rejects(label, candidate):
        try:
            CHECK.check_declaration(candidate, adapter)
        except AssertionError:
            rejected.append(label)
        else:
            raise AssertionError(('invalid caller accepted', label))
    for key, value in (
        ('id', 'negative-887236b78100baf3'),
        ('original_path', [['angle', 3, 0], ['angle_cut', [0, '0'], 1], ['alternate_four_escape', [1, 7], [1]]]),
        ('original_mask', '011/00'), ('squared_radius', '17/4'),
        ('scope', 'SELECTED_CHILD'), ('all_nine_original_squares_retained', False),
        ('original_pair_predicates', 35), ('marked_cones', 4),
        ('no_other_original_consequence_imported', False)):
        candidate = deepcopy(declaration)
        candidate[key] = value
        rejects(key, candidate)
    candidate = deepcopy(declaration)
    candidate['initial']['positions'][0][0] = '0'
    rejects('unproved_position_interval', candidate)
    candidate = deepcopy(declaration)
    candidate['initial']['diagonal'] = [{'pair': [0, 1], 'intervals': [['0', '1'], ['0', '1']]}]
    rejects('unproved_diagonal_interval', candidate)
    candidate = deepcopy(declaration)
    candidate['initial']['path'].append(['angle_cut', [8, '0'], 0])
    rejects('undeclared_child_restriction', candidate)
    CHECK.ALL.verify_all_bindings()
    for name, digest in before.items():
        assert CHECK.sha(name) == digest
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy',
        'cd402_original_runtime', 'ac_objective_unit_four_corner_runtime'))
    report = dict(status='PASS_CD402_FRESH_ORIGINAL_STATIC_ATTACHMENT',
        original_id=CHECK.TARGET, original_path=CHECK.ORIGINAL_PATH,
        original_register_sha256=CHECK.REGISTER_SHA,
        static_printed_rows_checked=count, static_terminal_checked=static['terminal'],
        rejected_damaged_callers=rejected, input_sha256=before,
        independent_source_sha256=CHECK.source_bindings(),
        initial_original_differences_empty=True, initial_original_diagonal_empty=True,
        numerical_optimizer_called=False, new_original_cells=0, new_masks=0,
        original_status='OPEN', seconds=time.monotonic() - started)
    output = root / 'CD402_INITIAL_STATIC_ATTACHMENT_REPLAY.json'
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'static_printed_rows_checked',
        'rejected_damaged_callers', 'seconds')}, indent=2), flush=True)


if __name__ == '__main__':
    main()
