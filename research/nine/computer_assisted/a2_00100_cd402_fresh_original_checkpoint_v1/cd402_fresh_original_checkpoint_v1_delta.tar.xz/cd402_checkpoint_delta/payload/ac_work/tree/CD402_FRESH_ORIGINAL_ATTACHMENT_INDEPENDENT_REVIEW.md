# Cd402 fresh-original attachment review

The fresh initialization and static attachment preserve the complete registered original `negative-d4021ade840b985c` of mask `001/00` at squared radius `1105/256`. This review grants no exclusion credit.

The fixed register entry is index 160, baseline frontier index 30. Its path is exactly `angle D negative; angle_cut A at 0, side 1; alternate_four_escape (B,H), branch 2`. The independent initializer obtains all angle, position and choice data directly from the original path parser, sets the 36 scalar bounds analytically, and begins with empty Cartesian and diagonal difference records. The numerical initializer reconstructs this same state and requires literal equality with the independent declaration.

The reused checker classes provide general physical row reconstruction. Their C887-specific ancestry entry point is not called. The new entry point binds the Cd402 register record, radius and five marked edges, then calls the unchanged exact record core on that fresh state. No C887 or Cb882 coordinate prefix, selected height domain, D/G union, or later consequence is transported.

I inspected the static model's 46,584 row names and the three literal alternate escape rows. The branch-2 primary and both closed predecessor inequalities are retained. There are no C887/Cb882 height or shared-bound prefixes, and no selected-height complement row. The attached JSON records the three actual literals and hashes of every directly reviewed input.

The root's static replay checks all 46,584 rows using the existing canonical validator and reports a pass; its earlier raw-tuple mismatch concerned explicit zero coefficients only. This review reads and binds that report but does not claim another arithmetic execution. I inspected the initializer, discovery driver, exact verifier, static control script and relevant generic adapters. No optimizer ran for this review. The original remains OPEN; a future bound record and any complete exclusion require their ordinary exact replay.
