#!/usr/bin/env python3
"""Replay exactly six complete original cells and their existing-domain unions."""
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    frozen = json.loads((HERE / 'SHA256_MANIFEST.json').read_text())
    assert frozen['schema'] == 'n9_shared_center_remainder_immutable_files_v1'
    for name, expected in frozen['files'].items():
        assert sha(HERE / name) == expected, ('payload_file_changed', name)
    index = json.loads((HERE / 'portfolio_index.json').read_text())
    assert index['schema'] == 'n9_shared_center_remainder_portfolio_v1'
    assert sha(HERE / 'original_register.json') == index['original_register_sha256']
    prior_ids = []
    prior_after = None
    for dependency in index['previous_checkpoints']:
        file = HERE / dependency['manifest']
        assert sha(file) == dependency['manifest_sha256']
        prior = json.loads(file.read_text())
        assert prior['archive_sha256'] == dependency['archive_sha256']
        assert prior['before'] == dependency['before'] and prior['after'] == dependency['after']
        if prior_after is not None:
            assert prior['before'] == prior_after
        prior_after = prior['after']
        prior_ids += [entry['id'] for entry in prior['complete_originals']]
    assert prior_after == index['before'] == {'closed': 185, 'open': 46}
    assert prior_ids == index['previously_closed_original_ids'] and len(set(prior_ids)) == 11
    entries = index['entries']
    ids = [entry['id'] for entry in entries]
    assert len(ids) == len(set(ids)) == 6 and not set(ids).intersection(prior_ids)
    out = HERE / 'new_reviews'
    out.mkdir(exist_ok=True)
    totals = {'prior_coordinate_deductions': 0, 'whole_parent_new_deductions': 0,
              'rectangle_new_deductions': 0, 'new_exact_deductions': 0,
              'printed_rows_checked': 0, 'complete_terminal_domains': 0,
              'fixed_grid_tiles': 0, 'static_terminal_domains': 0,
              'complete_rectangle_domains': 0, 'whole_parent_terminal_domains': 0}
    reports = []
    from verify_joint_original import replay
    for entry in entries:
        certificate = HERE / entry['certificate']
        assert sha(certificate) == entry['certificate_sha256']
        destination = out / Path(entry['accepted_report']).name
        kind = entry['kind']
        if kind == 'whole_parent_dual':
            report = replay(certificate)
            destination.write_text(json.dumps(report, indent=2) + '\n')
            parent = report
            extra = 0
            printed = report['printed_rows_checked']
            totals['whole_parent_terminal_domains'] += 1
            totals['complete_terminal_domains'] += 1
        else:
            assert sha(HERE / entry['checker']) == entry['checker_sha256']
            if kind == 'static_i_grid':
                assert entry['target_original'] == 8 and entry['checker'] == 'verify_fixed_i_static_parent.py'
                assert sha(HERE / entry['supplement']) == entry['supplement_sha256']
                from verify_fixed_i_static_parent import verify
                report = verify(certificate, HERE / entry['tiles'], HERE / entry['supplement'], HERE, destination)
                assert report['new_bound_rounds'] == 0 and report['static_tiles_checked'] == 64
                extra = 0
                totals['complete_terminal_domains'] += 64
            else:
                assert kind == 'h_grid_rectangle' and entry['target_original'] == 7
                assert entry['checker'] == 'verify_fixed_h_parent.py'
                assert sha(HERE / entry['union']) == entry['union_sha256']
                from verify_fixed_h_parent import verify
                report = verify(certificate, HERE / entry['tiles'], HERE / entry['union'], HERE, destination)
                assert report['target_original'] == 7
                extra = report['rectangle_deductions']
                totals['complete_rectangle_domains'] += 1
                totals['complete_terminal_domains'] += report['static_tiles_checked'] + 1
            parent = report['parent_proof']
            printed = parent['printed_rows_checked'] + report['new_printed_rows_checked']
            assert report['all_64_tiles_accounted_for'] is True
            totals['fixed_grid_tiles'] += 64
            totals['static_terminal_domains'] += report['static_tiles_checked']
        assert report['status'] == 'PASS_COMPLETE_ORIGINAL_PARENT' and report['id'] == entry['id']
        assert report['whole_original_parent_closed'] is True
        totals['prior_coordinate_deductions'] += parent['prior_coordinate_deductions']
        totals['whole_parent_new_deductions'] += parent['new_deductions']
        totals['rectangle_new_deductions'] += extra
        totals['new_exact_deductions'] += parent['new_deductions'] + extra
        totals['printed_rows_checked'] += printed
        reports.append({'id': entry['id'], 'kind': kind, 'status': report['status'], 'report': str(destination.relative_to(HERE))})

    # This exact cancellation reuses rows already independently rebuilt in
    # the complete daf proof above; it does not substitute for that proof.
    table = json.loads((HERE / 'hand_tables/daf_nineteen_row_exact_terminal_v2.json').read_text())
    daf = next(entry for entry in entries if entry['id'] == table['parent_id'])
    union_path = HERE / daf['union']
    assert sha(union_path) == table['source_sha256']
    union = json.loads(union_path.read_text())
    assert table['target_original'] == union['target_original'] == 7
    assert table['center_box'] == union['center_box']
    rows = {row['index']: row for row in union['terminal']['rows']}
    assert len(rows) == len(table['weights']) == 19
    assert {item['row_index'] for item in table['weights']} == set(rows)
    coefficients, rhs = {}, Q(0)
    for item in table['weights']:
        row, weight = rows[item['row_index']], Q(item['weight'])
        assert row['name'] == item['name'] and weight > 0
        for variable, value in row['coefficients']:
            coefficients[variable] = coefficients.get(variable, Q(0)) + weight * Q(value)
        rhs += weight * Q(row['rhs'])
    assert len(coefficients) == 21 and all(value == 0 for value in coefficients.values())
    assert rhs == Q(table['weighted_rhs']) and rhs < -Q(29, 50)
    from verify_scope_assemblies import verify as verify_scopes
    scope_report = verify_scopes(index, ids)
    (out / 'scope_assemblies.json').write_text(json.dumps(scope_report, indent=2) + '\n')
    expected = {'prior_coordinate_deductions': 200, 'whole_parent_new_deductions': 2906,
                'rectangle_new_deductions': 822, 'new_exact_deductions': 3728,
                'printed_rows_checked': 8003, 'complete_terminal_domains': 315,
                'fixed_grid_tiles': 320, 'static_terminal_domains': 312,
                'complete_rectangle_domains': 2, 'whole_parent_terminal_domains': 1}
    assert totals == expected
    summary = {'schema': 'n9_shared_center_remainder_complete_replay_v1',
        'status': 'PASS_ALL_COMPLETE_ORIGINAL_PARENTS', 'complete_original_ids': ids,
        'complete_original_count': 6, 'before': index['before'],
        'after': {'closed': 191, 'open': 40}, 'whole_masks': index['whole_masks'],
        'totals': totals, 'reports': reports,
        'completed_existing_domain_assemblies': 3,
        'daf_auxiliary_exact_positive_weights': 19,
        'daf_auxiliary_cancelled_variables': 21,
        'daf_auxiliary_exact_rhs': str(rhs),
        'unsupported_rules_accepted': False, 'lean_lake_ci_run': False,
        'proof_kernel_verification': False, 'whole_mask_closed': False}
    (out / 'portable_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
    return summary


if __name__ == '__main__':
    main()
