#!/usr/bin/env python3
"""Exact original-ID maps for completed existing prefixes, not new gates."""
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def assemble(index, verified_current_ids):
    registry_path = HERE / 'original_register.json'
    registry = json.loads(registry_path.read_text())
    assert digest(registry_path) == index['original_register_sha256']
    cells = registry['cells']
    by_id = {cell['id']: cell for cell in cells}
    assert len(cells) == len(by_id) == 231
    baseline = {cell['id'] for cell in cells if cell['status'] == 'CLOSED'}
    assert len(baseline) == 174
    previous = set(index['previously_closed_original_ids'])
    current = set(verified_current_ids)
    assert current == {entry['id'] for entry in index['entries']}
    assert len(current) == 6 and len(previous) == 11
    assert not current.intersection(previous | baseline)
    assert not previous.intersection(baseline)
    accepted = baseline | previous | current
    assert len(accepted) == 191

    def prefix_map(name, prefix, expected_baseline, expected_previous, expected_current):
        descendants = [cell for cell in cells if cell['path'][:len(prefix)] == prefix]
        ids = {cell['id'] for cell in descendants}
        assert len(ids & baseline) == expected_baseline
        assert ids & previous == set(expected_previous)
        assert ids & current == set(expected_current)
        assert ids <= accepted
        return {'name': name, 'kind': 'complete_existing_prefix', 'prefix': prefix,
                'baseline_closed_ids': sorted(ids & baseline),
                'previous_checkpoint_closed_ids': sorted(ids & previous),
                'current_checkpoint_closed_ids': sorted(ids & current),
                'all_original_descendant_ids': sorted(ids), 'complete': True}

    b4 = 'positive-b4a9a3bc15e37620'
    d9 = 'positive-d9e959003493b8f1'
    child7 = prefix_map('A inward-row child 7', by_id[b4]['path'][:3], 15, [], [b4])
    low_fh6 = prefix_map('A inward-row child 6, low F, F-H child 6',
        by_id[d9]['path'][:5], 29,
        ['positive-3da90694b58b6ef7', 'positive-8f760b2d708ad21d'],
        ['positive-8e41311b61c89e61', d9])
    broader_prefix = by_id[d9]['path'][:4]
    broader_ids = {cell['id'] for cell in cells if cell['path'][:4] == broader_prefix}
    remaining = broader_ids - accepted
    assert remaining == {'positive-768264ad71bc8152'}
    broader = {'name': 'A inward-row child 6, low F', 'prefix': broader_prefix,
               'all_original_descendant_ids': sorted(broader_ids),
               'remaining_open_ids': sorted(remaining), 'complete': False}

    daf, high = 'negative-daf08b7f35b70b9a', 'negative-99f578b7bbedf013'
    common = [['angle', 3, 0], ['angle_cut', [0, '0'], 0]]
    route = ['f_side_escape', [5, 7], [5]]
    for ident, side in [(daf, 0), (high, 1)]:
        assert by_id[ident]['path'] == common + [['position_cut', [11, '1/2'], side], route]
        assert ident in current
    selected = [cell for cell in cells if len(cell['path']) >= 4
                and cell['path'][:2] == common and cell['path'][3] == route
                and cell['path'][2][:2] == ['position_cut', [11, '1/2']]]
    assert {cell['id'] for cell in selected} == {daf, high}
    from verify_joint_original import K
    actual = K.V.f_side_escape_rows((5, 7), 5, Q(3, 5))
    normalized = []
    for coefficients, rhs in actual:
        combined = {}
        for variable, coefficient in coefficients:
            combined[variable] = combined.get(variable, Q(0)) + coefficient
        normalized.append({'coefficients': [[k, str(v)] for k, v in sorted(combined.items()) if v],
                           'rhs': str(rhs)})
    expected_rows = [
        {'coefficients': [[10, '1'], [14, '-1']], 'rhs': '0'},
        {'coefficients': [[7, '-1'], [11, '-1'], [15, '2']], 'rhs': '-3/5'},
        {'coefficients': [[7, '-1'], [11, '1']], 'rhs': '3/5'},
    ]
    assert normalized == expected_rows
    h_macro = {'name': 'F-H routing child 5 across every F height',
        'kind': 'complete_union_of_closed_height_children', 'common_prefix': common,
        'shared_routing_step': route, 'routing_rows': normalized,
        'fixed_original_ids': [daf, high], 'height_variable': 11, 'cut': '1/2',
        'children': ['y_F <= 1/2', 'y_F >= 1/2'], 'shared_face_retained': True,
        'H_target_original': 7, 'H_position_indices': [14, 15],
        'H_I_exchange_used': False, 'complete': True}
    return {'schema': 'n9_shared_center_remainder_exact_scope_maps_v1',
            'status': 'PASS_EXACT_EXISTING_PREFIX_ASSEMBLIES',
            'original_register_sha256': digest(registry_path),
            'baseline_closed_count': 174, 'previous_checkpoint_closed_count': 11,
            'current_checkpoint_closed_count': 6, 'resulting_closed_count': 191,
            'completed_existing_domains': [child7, low_fh6, h_macro],
            'explicitly_open_broader_domain': broader,
            'coverage_premise': 'The accepted unchanged 231-cell original coverage contract and literal path predicates.',
            'new_original_ids_created': 0, 'new_masks_created': 0,
            'whole_A_family_closed': False, 'whole_B_family_closed': False,
            'whole_mask_closed': False}


def verify(index, verified_current_ids):
    report = assemble(index, verified_current_ids)
    expected = json.loads((HERE / 'scope_entailment_maps.json').read_text())
    assert report == expected
    return report


if __name__ == '__main__':
    index = json.loads((HERE / 'portfolio_index.json').read_text())
    print(json.dumps(verify(index, [entry['id'] for entry in index['entries']]), indent=2))
