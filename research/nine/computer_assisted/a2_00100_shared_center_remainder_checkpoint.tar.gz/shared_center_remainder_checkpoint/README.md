# Six complete original cells: shared center remainder

This separately frozen packet proves the six original IDs in
`portfolio_index.json`, with complete exact replay. It advances the fixed
original-cell register from 185 CLOSED / 46 OPEN to 191 CLOSED / 40 OPEN.
The all-mask count stays 8 CLOSED / 24 OPEN.

Run with standard-library Python after extraction:

    python shared_center_remainder_checkpoint/verify_all.py

The proofs are three complete I-center grids, one whole-parent exact
contradiction, and two complete H-center grids with full remainder
rectangles. All 320 closed tiles are covered. The checker rebuilds all
parent premises, used physical rows, bounds, guards, frame refinements,
static terminals and rectangle inductions independently of the discovery
producers. All original frames, corners, pairs, marked predicates,
strict-radius conditions and H/I order remain attached to the originals.

`proofs/A2_00100_SHARED_CENTER_REMAINDER_CLOSURE.md` explains the full
assembly and links the detailed hand proofs. `scope_entailment_maps.json`
records three completed existing domains and the broader A domain that
explicitly remains open because original 768 is unresolved. These maps
enumerate the remaining fixed-register descendants. The prefix assemblies
also inherit the certified baseline tree's already excluded terminal
descendants outside that register; they do not replace the accepted
original coverage contract.

The two preceding checkpoint manifests bind eleven distinct prior
closures. This packet contains exactly six additional distinct IDs. Both
earlier archive and manifest pairs remain unchanged. The complete six
proofs use 200 prior deductions, 3,728 new exact deductions, 8,003 checked
printed rows and 315 terminal domains. No new original gate is created.

`SHA256_MANIFEST.json` binds all immutable sources, certificates, proofs,
source mappings and accepted reports. New replay outputs go to
`new_reviews/`. `source_bindings.json` relocates historical producer and
coordinate-prefix paths to the delivered immutable files. New discovery
producers and optimizers are never imported by the independent replay.

No Lean, Lake, CI, proof-kernel verification, or whole-mask closure is
claimed. The optional exact daf cancellation uses only the corrected v2
hand table, and is checked after the complete H proof.
