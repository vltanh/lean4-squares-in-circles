#!/usr/bin/env python3
"""Record exact physical difference contradictions on frozen grid tiles.

Discovery/recording only. No producer source or existing tile is changed.
Acceptance requires complete independent parent and all-64-tile replay.
"""
import argparse
from fractions import Fraction as Q
import hashlib
from itertools import combinations
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'current_proof/shared_capacity_three_b_v4'))
import verify_shared_bound as K


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def boxes(values):
    return tuple(tuple(Q(v) for v in pair) for pair in values)


def render(values):
    return [[str(v) for v in pair] for pair in values]


def run(parent_path):
    parent_path = Path(parent_path).resolve()
    parent = json.loads(parent_path.read_text())
    ident = parent['id']
    assert parent['status'] == 'OPEN' and 'final_angles' in parent
    grid = HERE / 'fixed_i_grid' / ident
    manifest = json.loads((grid / 'manifest.json').read_text())
    assert manifest['id'] == ident and manifest['parent_sha256'] == digest(parent_path)
    summary = json.loads((grid / 'summary.json').read_text())
    assert summary['tiles_tested'] == 64
    pending = summary['open']
    assert pending and pending == sorted(set(pending))
    angles = boxes(parent['final_angles'])
    parentpos = boxes(parent['final_positions'])
    difference = {tuple(d['pair']): boxes(d['intervals']) for d in parent['final_differences']}
    _, _, choices = K.V.reconstruct(parent['path'])
    effective, terminal = K.V.effective_boxes(angles, choices, K.LEGACY)
    assert terminal is None
    tiles = []
    for tile in pending:
        saved = json.loads((grid / f'tile_{tile:02d}.json').read_text())
        assert saved['parent_id'] == ident and saved['tile'] == tile and saved['status'] == 'OPEN'
        positions = list(parentpos)
        positions[16:18] = boxes(saved['I_box'])
        propagated, heights, insets, terminal = K.V.center_bounds(effective, positions, choices, K.LEGACY)
        assert terminal is None
        witnesses = []
        for pair in combinations(range(9), 2):
            physical = K.V.difference_bounds(pair, propagated, insets, K.LEGACY)
            for axis in (0, 1):
                old, fresh = difference[pair][axis], physical[axis]
                lo, hi = max(old[0], fresh[0]), min(old[1], fresh[1])
                if lo > hi:
                    witnesses.append({'pair': list(pair), 'axis': axis,
                                      'parent_interval': list(map(str, old)),
                                      'physical_interval': list(map(str, fresh)),
                                      'intersection': list(map(str, (lo, hi))), 'gap': str(lo-hi)})
        assert witnesses, ('No physical empty difference on frozen pending tile', ident, tile)
        tiles.append({'tile': tile, 'terminal': {
            'kind': 'proved_empty_parent_difference_intersection',
            'effective_angles': render(effective),
            'propagated_positions': render(propagated), 'witnesses': witnesses}})
    record = {
        'schema': 'n9_frozen_grid_physical_difference_supplement_v1',
        'id': ident, 'path': parent['path'], 'status': 'CANDIDATE_COMPLETE_FIXED_GRID',
        'scope': 'EXPLICIT_PHYSICAL_TERMINALS_ON_FROZEN_GRID_TILES_ONLY',
        'parent_file': str(parent_path), 'parent_sha256': digest(parent_path),
        'grid_manifest_sha256': digest(grid / 'manifest.json'),
        'new_branch_nodes': 0, 'new_bound_rounds': 0, 'pending_tiles': pending,
        'tiles': tiles,
        'sources': {str(p): digest(p) for p in (Path(__file__), Path(K.__file__), Path(K.V.__file__))},
        'accepted_new_cells': 0, 'lean_lake_ci_run': False,
    }
    out = HERE / 'fixed_grid_interval_supplements' / (ident + '.json')
    out.parent.mkdir(exist_ok=True)
    assert not out.exists(), 'Preserve immutable supplementary records.'
    out.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'id': ident, 'certificate': str(out), 'sha256': digest(out),
                      'explicit_interval_tiles': pending,
                      'witness_count': sum(len(x['terminal']['witnesses']) for x in tiles),
                      'accepted_new_cells': 0}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('parent')
    run(parser.parse_args().parent)
