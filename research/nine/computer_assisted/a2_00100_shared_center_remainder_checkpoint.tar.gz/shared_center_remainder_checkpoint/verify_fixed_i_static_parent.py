#!/usr/bin/env python3
"""Independent exact whole-original proof from the complete frozen 8x8 grid.

The optional supplement gives explicit physical empty-difference terminals
for old diagnostic construction exceptions. No producer or optimizer is
imported; every parent premise, tile, physical row and terminal is rebuilt.
"""
import argparse
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import sys
import time


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def boxes(values):
    return tuple(tuple(Q(v) for v in pair) for pair in values)


def verify(parent_path, tiles_dir, supplement_path, joint_root, out_path=None):
    start = time.monotonic()
    parent_path, tiles_dir, joint_root = map(Path, (parent_path, tiles_dir, joint_root))
    sys.path.insert(0, str(joint_root))
    import verify_joint_original as J
    K = J.K
    parent_report, parent = J.replay(parent_path, allow_open=True, return_state=True)
    assert parent_report['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
    ident, path = parent['id'], parent['path']
    angles, scalar, basepos = parent['angles'], parent['scalar'], parent['positions']
    choices, parentdiff = parent['choices'], parent['differences']
    manifest = json.loads((tiles_dir / 'manifest.json').read_text())
    assert manifest['schema'] == 'n9_fixed_i_center_8x8_diagnostic_v1'
    assert manifest['id'] == ident and manifest['path'] == path
    assert manifest['parent_sha256'] == digest(parent_path)
    assert manifest['grid_size'] == [8, 8] and manifest['adaptive_splits'] == 0
    assert manifest['additional_bound_rounds_per_tile'] == 0 and manifest['static_dual_tests_per_tile'] == 1
    xa, xb = basepos[16]
    ya, yb = basepos[17]
    assert xa < xb and ya < yb
    assert boxes(manifest['covered_box']) == ((xa, xb), (ya, yb))
    for source, expected in manifest['sources'].items():
        assert digest(J.local_source(source)) == expected, ('grid_source_changed', source)
    assert {p.name for p in tiles_dir.glob('tile_*.json')} == {f'tile_{i:02d}.json' for i in range(64)}
    supplements = {}
    supplement_hash = None
    if supplement_path is not None:
        supplement_path = Path(supplement_path)
        record = json.loads(supplement_path.read_text())
        assert record['schema'] == 'n9_frozen_grid_physical_difference_supplement_v1'
        assert record['id'] == ident and record['path'] == path
        assert record['status'] == 'CANDIDATE_COMPLETE_FIXED_GRID'
        assert record['scope'] == 'EXPLICIT_PHYSICAL_TERMINALS_ON_FROZEN_GRID_TILES_ONLY'
        assert record['parent_sha256'] == digest(parent_path)
        assert record['grid_manifest_sha256'] == digest(tiles_dir / 'manifest.json')
        assert record['new_branch_nodes'] == 0 and record['new_bound_rounds'] == 0
        pending = record['pending_tiles']
        assert pending and all(type(i) is int and 0 <= i < 64 for i in pending)
        assert pending == sorted(set(pending))
        assert [item['tile'] for item in record['tiles']] == pending
        for item in record['tiles']:
            assert set(item) == {'tile', 'terminal'}
            supplements[item['tile']] = item['terminal']
        for source, expected in record['sources'].items():
            assert digest(J.local_source(source)) == expected, ('supplement_source_changed', source)
        supplement_hash = digest(supplement_path)

    tile_hashes, tile_reports, reserves, used_rules = {}, [], [], []
    terminal_counts = Counter()
    printed_count = 0
    observed_pending = []
    for i in range(64):
        file = tiles_dir / f'tile_{i:02d}.json'
        saved = json.loads(file.read_text())
        tile_hashes[file.name] = digest(file)
        ix, iy = divmod(i, 8)
        x = (xa+(xb-xa)*ix/8, xa+(xb-xa)*(ix+1)/8)
        y = (ya+(yb-ya)*iy/8, ya+(yb-ya)*(iy+1)/8)
        assert saved['parent_id'] == ident and saved['tile'] == i
        assert saved['ix'] == ix and saved['iy'] == iy and boxes(saved['I_box']) == (x, y)
        pos = list(basepos)
        pos[16:18] = (x, y)
        pos = tuple(pos)
        if saved['status'] == 'OPEN':
            observed_pending.append(i)
            assert i in supplements
            terminal = supplements[i]
            assert set(terminal) == {'kind', 'effective_angles', 'propagated_positions', 'witnesses'}
            assert terminal['kind'] == 'proved_empty_parent_difference_intersection'
            effective, early = K.V.effective_boxes(angles, choices, K.LEGACY)
            assert early is None
            assert boxes(terminal['effective_angles']) == tuple(map(tuple, effective))
            propagated, heights, insets, early = K.V.center_bounds(effective, pos, choices, K.LEGACY)
            assert early is None
            assert boxes(terminal['propagated_positions']) == tuple(map(tuple, propagated))
            witnesses = []
            for left in range(9):
                for right in range(left+1, 9):
                    physical = K.V.difference_bounds((left, right), propagated, insets, K.LEGACY)
                    inherited = parentdiff[left, right]
                    for axis in (0, 1):
                        lo = max(inherited[axis][0], physical[axis][0])
                        hi = min(inherited[axis][1], physical[axis][1])
                        if lo > hi:
                            witnesses.append({'pair': [left, right], 'axis': axis,
                                'parent_interval': list(map(str, inherited[axis])),
                                'physical_interval': list(map(str, physical[axis])),
                                'intersection': list(map(str, (lo, hi))), 'gap': str(lo-hi)})
            assert witnesses and terminal['witnesses'] == witnesses
            terminal_counts['physical_parent_difference_intersection'] += 1
            tile_reports.append({'tile': i, 'kind': terminal['kind'], 'witnesses': witnesses})
        else:
            assert saved['status'] == 'CANDIDATE_CLOSED' and i not in supplements
            _, _, early = K.collect_rows(K.V, path, angles, pos, choices)
            terminal = saved['terminal']
            if early:
                assert terminal['kind'] == 'exact_interval_or_accepted_terminal' and terminal['label'] == early
                terminal_counts[early] += 1
                tile_reports.append({'tile': i, 'kind': 'frozen_original_geometric_terminal', 'label': early})
            else:
                assert terminal['kind'] == 'positive_exact_reserve'
                base, bounds, prop, phys, diffs, guards = K.rebuild(path, angles, pos, choices, scalar, parentdiff)
                assert boxes(saved['propagated_positions']) == prop
                assert boxes(saved['physical_scalar_intersection']) == phys
                assert saved['effective_differences'] == K.diffview(diffs)
                assert saved['three_square_guards'][:len(guards)] == guards
                printed = terminal['rows']
                rows, names = J.rows_for_record(dict(saved, printed_rows=printed), base, phys, diffs, angles)
                used = {k for k, w in terminal['weights']}
                assert used == {row['index'] for row in printed}
                co, rhs = K.sum_rows(rows, bounds, terminal['weights'])
                reserve = -rhs-sum(m*abs(c) for m, c in zip(bounds, co))
                assert reserve > 0 and reserve == Q(terminal['reserve'])
                assert co == list(map(Q, terminal['weighted_coefficients']))
                assert rhs == Q(terminal['weighted_rhs'])
                assert list(map(str, bounds)) == terminal['absolute_variable_bounds']
                reserves.append(reserve)
                used_rules.extend(names)
                printed_count += len(used)
                terminal_counts['positive_exact_reserve'] += 1
                tile_reports.append({'tile': i, 'kind': 'positive_exact_reserve',
                                     'reserve': str(reserve), 'printed_rows': len(used)})
        print(ident, 'PASS FROZEN STATIC TILE', i, flush=True)
    assert observed_pending == sorted(supplements)
    assert len(tile_reports) == 64
    report = {
        'schema': 'n9_complete_original_fixed_i_static_replay_v1',
        'id': ident, 'status': 'PASS_COMPLETE_ORIGINAL_PARENT',
        'whole_original_parent_closed': True, 'whole_mask_closed': False,
        'original_path_sha256': hashlib.sha256(json.dumps(path, separators=(',', ':')).encode()).hexdigest(),
        'parent_proof': parent_report, 'grid_size': [8, 8], 'all_64_tiles_accounted_for': True,
        'static_tiles_checked': 64, 'static_terminal_counts': dict(terminal_counts),
        'static_tile_reports': tile_reports, 'static_tile_sha256': tile_hashes,
        'explicit_interval_tiles': observed_pending, 'new_bound_rounds': 0,
        'new_branch_nodes': 0, 'new_printed_rows_checked': printed_count,
        'least_positive_reserve': str(min(reserves)) if reserves else None,
        'independently_rebuilt_new_rules': used_rules, 'unsupported_rules_accepted': False,
        'grid_manifest_sha256': digest(tiles_dir / 'manifest.json'),
        'supplement_sha256': supplement_hash, 'verifier_sha256': digest(__file__),
        'joint_verifier_sha256': digest(J.__file__),
        'independent_rules_sha256': digest(joint_root / 'independent_all_rules.py'),
        'seconds': time.monotonic()-start, 'lean_lake_ci_run': False,
        'human_or_kernel_verification': False,
    }
    if out_path is not None:
        Path(out_path).write_text(json.dumps(report, indent=2) + '\n')
    omit = {'parent_proof', 'static_tile_reports', 'static_tile_sha256', 'independently_rebuilt_new_rules'}
    print(json.dumps({k: v for k, v in report.items() if k not in omit}), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent', required=True)
    parser.add_argument('--tiles', required=True)
    parser.add_argument('--supplement')
    parser.add_argument('--joint-root', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    verify(args.parent, args.tiles, args.supplement, args.joint_root, args.out)
