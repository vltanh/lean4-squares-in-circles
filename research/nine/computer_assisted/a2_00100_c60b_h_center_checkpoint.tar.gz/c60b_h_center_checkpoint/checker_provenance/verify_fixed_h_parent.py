#!/usr/bin/env python3
"""Independent exact replay of a whole original using its H-center cover.

No discovery producer, optimizer, point generator, or grid driver is imported.
The accepted original geometry and the separately implemented joint physical
row checker are reused. Every child premise, row, scalar induction and the
closed-face union is checked here. Requires Python standard library only.
"""
import argparse, hashlib, json, sys, time
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path

HERE=Path(__file__).resolve().parent
TARGET_ORIGINAL=7
CENTER_X=2*TARGET_ORIGINAL
CENTER_Y=CENTER_X+1

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def boxes(value):return tuple(tuple(Q(v)for v in pair)for pair in value)

def verify(parent_path,tiles_dir,union_path,joint_root,out_path=None):
    started=time.monotonic()
    parent_path,tiles_dir,union_path,joint_root=map(Path,(parent_path,tiles_dir,union_path,joint_root))
    sys.path.insert(0,str(joint_root))
    import verify_joint_original as J
    K=J.K
    # This callback replays every original-parent deduction; a saved report
    # or unverified declared final state is never accepted as the premise.
    parent_report,parent=J.replay(parent_path,allow_open=True,return_state=True)
    assert parent_report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
    ident=parent['id'];path=parent['path'];angles=parent['angles']
    scalar=parent['scalar'];choices=parent['choices'];basepos=parent['positions']
    parentdiff=parent['differences']
    manifest=json.loads((tiles_dir/'manifest.json').read_text())
    assert manifest['schema']=='n9_fixed_h_center_8x8_diagnostic_v1'
    assert manifest['target_original']==TARGET_ORIGINAL and manifest['original_count']==9
    assert manifest['scope']=='WHOLE_PARENT_COVER_CONDITIONAL_ON_SOURCE_BOUND_V2_INDUCTION'
    assert manifest['id']==ident and manifest['path']==path
    assert manifest['parent_sha256']==digest(parent_path)
    assert manifest['grid_size']==[8,8] and manifest['adaptive_splits']==0
    assert manifest['additional_bound_rounds_per_tile']==0
    assert manifest['static_dual_tests_per_tile']==1
    xa,xb=basepos[CENTER_X];ya,yb=basepos[CENTER_Y]
    assert boxes(manifest['center_box'])==((xa,xb),(ya,yb))
    assert xa<xb and ya<yb
    for source,sha in manifest['sources'].items():assert digest(J.local_source(source))==sha,('grid_source_changed',source)
    expected_files={f'tile_{i:02d}.json'for i in range(64)}
    assert {p.name for p in tiles_dir.glob('tile_*.json')}==expected_files
    record=json.loads(union_path.read_text())
    assert record['schema']=='n9_frozen_h_grid_covering_rectangle_five_round_v1'
    assert record['target_original']==TARGET_ORIGINAL
    assert record['prior']['target_original']==TARGET_ORIGINAL
    assert record['prior']['original']=='H'
    assert record['additional_predicate']['target_original']==TARGET_ORIGINAL
    covered=record['prior']['covered_tiles'];pending=record['prior']['pending_tiles']
    assert covered==record['additional_predicate']['covered_tiles']
    assert pending==record['additional_predicate']['pending_tiles']
    expected_suffix='_covering_H_rectangle'
    expected_scope='COMPLETE_FROZEN_GRID_COVERING_RECTANGLE_ONLY; NOT_WHOLE_PARENT_BY_ITSELF'
    expected_prior_kind='SOURCE_BOUND_PARENT_PLUS_FROZEN_GRID_COVERING_RECTANGLE'
    assert record['prior']['grid_manifest_sha256']==digest(tiles_dir/'manifest.json')
    assert record['prior']['grid_summary_sha256']==digest(tiles_dir/'summary.json')
    grid_summary=json.loads((tiles_dir/'summary.json').read_text())
    assert grid_summary['id']==ident and grid_summary['target_original']==TARGET_ORIGINAL
    assert boxes(grid_summary['center_box'])==((xa,xb),(ya,yb))
    assert grid_summary['tiles_tested']==64
    assert covered and pending
    assert all(type(i)is int and 0<=i<64 for i in covered+pending)
    assert covered==sorted(set(covered))and pending==sorted(set(pending))
    assert set(pending)<=set(covered)
    xs=[i//8 for i in pending];ys=[i%8 for i in pending]
    xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys)
    rectangle_tiles=[8*x+y for x in range(xmin,xmax+1)for y in range(ymin,ymax+1)]
    assert covered==rectangle_tiles,'The declared covering set must be the complete fixed-grid rectangle.'

    def rebuild(pos,oldscalar,oldangles,differences):
        # This preliminary collector is the frozen physical original
        # constructor, not the new producer's early-terminal function.
        _,_,early=K.collect_rows(K.V,path,oldangles,pos,choices)
        if early:return None,None,early,None,None,None,None
        base,bounds,prop,phys,diffs,guards=K.rebuild(path,oldangles,pos,choices,oldscalar,differences)
        return base,bounds,None,prop,phys,diffs,guards

    def check_state(saved,prop,phys,diffs,guards):
        assert boxes(saved['propagated_positions'])==prop
        assert boxes(saved['physical_scalar_intersection'])==phys
        assert saved['effective_differences']==K.diffview(diffs)
        assert saved['three_square_guards'][:len(guards)]==guards

    def check_dual(saved,terminal,base,bounds,phys,diffs,oldangles):
        printed=terminal['rows']
        rows,names=J.rows_for_record(dict(saved,printed_rows=printed),base,phys,diffs,oldangles)
        used={k for k,w in terminal['weights']}
        assert used=={r['index']for r in printed}
        co,rhs=K.sum_rows(rows,bounds,terminal['weights'])
        reserve=-rhs-sum(m*abs(c)for m,c in zip(bounds,co))
        assert reserve>0 and reserve==Q(terminal['reserve'])
        assert co==list(map(Q,terminal['weighted_coefficients']))
        assert rhs==Q(terminal['weighted_rhs'])
        assert list(map(str,bounds))==terminal['absolute_variable_bounds']
        return reserve,len(used),names

    terminal_counts=Counter();tile_reports=[];used_rules=[];printed_count=0
    exact_boxes={};tile_hashes={};reserves=[];observed_pending=[]
    for i in range(64):
        file=tiles_dir/f'tile_{i:02d}.json';saved=json.loads(file.read_text());tile_hashes[file.name]=digest(file)
        ix,iy=divmod(i,8)
        x=(xa+(xb-xa)*ix/8,xa+(xb-xa)*(ix+1)/8)
        y=(ya+(yb-ya)*iy/8,ya+(yb-ya)*(iy+1)/8)
        assert saved['tile']==i and saved['ix']==ix and saved['iy']==iy and saved['parent_id']==ident
        assert saved['target_original']==TARGET_ORIGINAL
        assert boxes(saved['center_box'])==(x,y)
        exact_boxes[i]=(x,y)
        assert saved['status']in('OPEN','CANDIDATE_CLOSED')
        if saved['status']=='OPEN':observed_pending.append(i)
        if i in covered:continue
        assert saved['status']=='CANDIDATE_CLOSED'
        pos=list(basepos);pos[CENTER_X]=x;pos[CENTER_Y]=y;pos=tuple(pos)
        base,bounds,early,prop,phys,diffs,guards=rebuild(pos,scalar,angles,parentdiff)
        terminal=saved['terminal']
        if early:
            assert terminal['kind']=='exact_interval_or_accepted_terminal' and terminal['label']==early
            terminal_counts[early]+=1
            tile_reports.append({'tile':i,'kind':'frozen_original_geometric_terminal','label':early})
        else:
            assert terminal['kind']=='positive_exact_reserve'
            check_state(saved,prop,phys,diffs,guards)
            reserve,used,names=check_dual(saved,terminal,base,bounds,phys,diffs,angles)
            reserves.append(reserve);printed_count+=used;used_rules+=names
            terminal_counts['positive_exact_reserve']+=1
            tile_reports.append({'tile':i,'kind':'positive_exact_reserve','reserve':str(reserve),'printed_rows':used})
        print(ident,'PASS STATIC TILE',i,flush=True)

    # Every tile in the Cartesian rectangle, including shared faces, is
    # accounted for by one complete rectangular induction. Already proved
    # static tiles inside it may overlap harmlessly and are not required.
    assert observed_pending==pending
    assert grid_summary['open']==pending
    assert grid_summary['candidate_closed']==[i for i in range(64)if i not in pending]
    union=((xa+(xb-xa)*xmin/8,xa+(xb-xa)*(xmax+1)/8),
           (ya+(yb-ya)*ymin/8,ya+(yb-ya)*(ymax+1)/8))
    assert all(union[0][0]<=exact_boxes[i][0][0]<=exact_boxes[i][0][1]<=union[0][1]
               and union[1][0]<=exact_boxes[i][1][0]<=exact_boxes[i][1][1]<=union[1][1]for i in covered)
    assert record['id']==ident+expected_suffix and record['path']==path
    assert record['status']=='CANDIDATE_CLOSED'
    assert record['scope']==expected_scope and record['original_parent']==ident
    assert record['new_branch_nodes']==0 and record['maximum_new_rounds']==5 and len(record['rounds'])<=5
    assert record['prior']['kind']==expected_prior_kind
    assert record['prior']['sha256']==digest(parent_path) and record['prior']['parent_id']==ident
    assert boxes(record['prior']['center_box'])==union
    assert boxes(record['center_box'])==union
    assert record['additional_predicate']['original']=='H'
    assert boxes(record['additional_predicate']['center_rectangle'])==union
    sources=dict(record['sources'])
    for source,sha in record['additional_sources'].items():
        assert source not in sources or sources[source]==sha;sources[source]=sha
    for source,sha in sources.items():assert digest(J.local_source(source))==sha,('union_source_changed',source)

    pos=list(basepos);pos[CENTER_X],pos[CENTER_Y]=union;pos=tuple(pos)
    oldangles=angles;oldscalar=scalar;difference={};deductions=0;round_reports=[];analytic_terminal=None;terminal_old_state=None
    physical_difference_terminal=None
    # The producer retained the original parent's relational bounds on
    # every round. Re-establish that exact intersection independently.
    def inherited_intersection(current):
        merged=dict(parentdiff)
        for pair,intervals in current.items():
            assert pair in merged
            merged[pair]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(merged[pair],intervals))
        assert all(a<=b for intervals in merged.values()for a,b in intervals)
        return merged

    if record['terminal']['kind']=='proved_empty_parent_difference_intersection':
        # Zero-round physical terminal: reconstruct the entire restricted
        # rectangle directly from the frozen original geometry, then
        # intersect every pair difference with the proved parent bounds.
        # No failed assertion, printed label, or optimizer status counts.
        assert record['rounds']==[]
        terminal=record['terminal']
        assert set(terminal)=={'kind','effective_angles','propagated_positions','witnesses'}
        effective,early=K.V.effective_boxes(angles,choices,K.LEGACY)
        assert early is None
        assert boxes(terminal['effective_angles'])==tuple(map(tuple,effective))
        propagated,hs,gs,early=K.V.center_bounds(effective,pos,choices,K.LEGACY)
        assert early is None
        assert boxes(terminal['propagated_positions'])==tuple(map(tuple,propagated))
        witnesses=[]
        for i in range(9):
            for j in range(i+1,9):
                physical=K.V.difference_bounds((i,j),propagated,gs,K.LEGACY)
                prior=parentdiff[i,j]
                for axis in (0,1):
                    lo=max(prior[axis][0],physical[axis][0])
                    hi=min(prior[axis][1],physical[axis][1])
                    if lo>hi:
                        witnesses.append({'pair':[i,j],'axis':axis,
                            'parent_interval':list(map(str,prior[axis])),
                            'physical_interval':list(map(str,physical[axis])),
                            'intersection':list(map(str,(lo,hi))),'gap':str(lo-hi)})
        assert witnesses and terminal['witnesses']==witnesses
        physical_difference_terminal=witnesses

    for ri,rr in enumerate(record['rounds']):
        preceding_state=(oldangles,pos,oldscalar)
        assert rr['round']==ri
        assert boxes(rr['angles_before'])==oldangles and boxes(rr['positions_before'])==pos and boxes(rr['scalar_before'])==oldscalar
        assert rr['differences_before']==K.diffview(difference)
        base,bounds,early,prop,phys,diffs,guards=rebuild(pos,oldscalar,oldangles,inherited_intersection(difference))
        assert early is None
        check_state(rr,prop,phys,diffs,guards)
        assert list(map(str,bounds))==rr['absolute_variable_bounds']
        rows,names=J.rows_for_record(rr,base,phys,diffs,oldangles);used_rules+=names
        newpos=[list(v)for v in prop];newscalar=[list(v)for v in phys]
        newdiff={pair:[list(v)for v in intervals]for pair,intervals in diffs.items()}
        used=set()
        for proposal in rr['proposals']:
            upper=K.audit_bound(rows,bounds,proposal)
            sign=proposal['sign'];key=proposal['key'];assert sign in(-1,1)
            if proposal['kind']=='scalar':
                assert type(key)is int and 0<=key<54
                assert proposal['objective']==[[key,sign]]
                target=newpos[key]if key<18 else newscalar[key-18]
            else:
                assert proposal['kind']=='difference'and len(key)==3
                i,j,axis=key;assert 0<=i<j<9 and axis in(0,1)
                assert proposal['objective']==[[2*j+axis,sign],[2*i+axis,-sign]]
                target=newdiff[i,j][axis]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
            used.update(i for i,w in proposal['weights']);deductions+=1
        assert used=={r['index']for r in rr['printed_rows']}
        printed_count+=len(used)
        pos=tuple(map(tuple,newpos));oldscalar=tuple(map(tuple,newscalar))
        difference={pair:tuple(map(tuple,intervals))for pair,intervals in newdiff.items()}
        assert all(a<=b for a,b in pos+oldscalar)
        assert all(a<=b for intervals in difference.values()for a,b in intervals)
        oldangles=K.angles_from_scalar(oldangles,oldscalar,rr['physical_frame_inferences'])
        physical=K.analytic(oldangles)
        prior_to_intersection=oldscalar
        oldscalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(oldscalar,physical))
        empty=[{'variable':18+i,'proved_interval':list(map(str,prior_to_intersection[i])),
                'physical_interval':list(map(str,physical[i])),
                'intersection':list(map(str,(a,b))),'gap':str(a-b)}
               for i,(a,b)in enumerate(oldscalar)if a>b]
        round_reports.append({'round':ri,'deductions':len(rr['proposals']),'printed_rows':len(used)})
        print(ident,'PASS COMPLETE COVERING RECTANGLE ROUND',ri,len(rr['proposals']),flush=True)
        if empty:
            assert ri==len(record['rounds'])-1
            assert record['terminal']['kind']=='proved_empty_analytic_frame'
            assert all(key not in rr for key in ('angles_after','positions_after','scalar_after','differences_after'))
            analytic_terminal=empty;terminal_old_state=preceding_state
            break
        assert boxes(rr['angles_after'])==oldangles and boxes(rr['positions_after'])==pos and boxes(rr['scalar_after'])==oldscalar
        assert rr['differences_after']==K.diffview(difference)

    if physical_difference_terminal is not None:
        assert deductions==0 and round_reports==[]
        assert boxes(record['final_angles'])==angles
        assert boxes(record['final_positions'])==pos
        assert boxes(record['final_scalar'])==scalar
        assert record['final_differences']==K.diffview(parentdiff)
        reserve=None;used=0
    elif analytic_terminal is None:
        terminal=record['terminal'];rr=terminal['state']
        assert terminal['kind']=='positive_exact_reserve'and rr['round']==len(record['rounds'])
        assert boxes(rr['angles_before'])==oldangles and boxes(rr['positions_before'])==pos and boxes(rr['scalar_before'])==oldscalar
        assert rr['differences_before']==K.diffview(difference)
        base,bounds,early,prop,phys,diffs,guards=rebuild(pos,oldscalar,oldangles,inherited_intersection(difference))
        assert early is None
        check_state(rr,prop,phys,diffs,guards)
        reserve,used,names=check_dual(rr,terminal,base,bounds,phys,diffs,oldangles)
        reserves.append(reserve);printed_count+=used;used_rules+=names
        assert boxes(record['final_angles'])==oldangles and boxes(record['final_positions'])==pos and boxes(record['final_scalar'])==oldscalar
        assert record['final_differences']==K.diffview(difference)
    else:
        # The producer stops before replacing its last complete state. These
        # saved arrays are checked as the preceding state, never promoted
        # to the state that established the actual empty intersection.
        assert record['terminal']=={'kind':'proved_empty_analytic_frame'}
        before_angles,before_positions,before_scalar=terminal_old_state
        assert boxes(record['final_angles'])==before_angles
        assert boxes(record['final_positions'])==before_positions
        assert boxes(record['final_scalar'])==before_scalar
        assert record['final_differences']==K.diffview(difference)
        reserve=None;used=0
    assert len(tile_reports)==64-len(covered)

    # No tile is sampled: all outside static rectangles plus this one
    # complete Cartesian rectangle cover the original H-center rectangle.
    # Every other original variable keeps its entire proved parent domain.
    report={
        'schema':'n9_complete_original_fixed_h_rectangle_replay_v1',
        'id':ident,'status':'PASS_COMPLETE_ORIGINAL_PARENT','whole_original_parent_closed':True,
        'whole_mask_closed':False,'original_path_sha256':hashlib.sha256(json.dumps(path,separators=(',',':')).encode()).hexdigest(),
        'parent_proof':parent_report,'target_original':TARGET_ORIGINAL,
        'grid_size':[8,8],'all_64_tiles_accounted_for':True,
        'static_tiles_checked':len(tile_reports),'static_terminal_counts':dict(terminal_counts),
        'static_tile_reports':tile_reports,'static_tile_sha256':tile_hashes,
        'covered_rectangle_tiles':covered,'original_pending_tiles':pending,'center_rectangle':[[str(a),str(b)]for a,b in union],
        'rectangle_deductions':deductions,'rectangle_rounds':round_reports,
        'rectangle_terminal_rows':used,'rectangle_positive_reserve':str(reserve),'analytic_frame_terminal':analytic_terminal,
        'physical_difference_terminal':physical_difference_terminal,
        'least_positive_reserve':str(min(reserves)),'new_printed_rows_checked':printed_count,
        'independently_rebuilt_new_rules':used_rules,'unsupported_rules_accepted':False,
        'grid_manifest_sha256':digest(tiles_dir/'manifest.json'),
        'grid_summary_sha256':digest(tiles_dir/'summary.json'),'union_certificate_sha256':digest(union_path),
        'verifier_sha256':digest(__file__),'joint_verifier_sha256':digest(J.__file__),
        'independent_rules_sha256':digest(joint_root/'independent_all_rules.py'),
        'seconds':time.monotonic()-started,'lean_lake_ci_run':False,'human_or_kernel_verification':False,
    }
    if out_path is not None:Path(out_path).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in('parent_proof','static_tile_reports','static_tile_sha256','independently_rebuilt_new_rules')}),flush=True)
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--parent',default=str(HERE.parent/'b_macro/v2/results/negative-daf08b7f35b70b9a.json'))
    ap.add_argument('--tiles',default=str(HERE.parent/'b_macro/fixed_h_grid/negative-daf08b7f35b70b9a'))
    ap.add_argument('--union',default=str(HERE.parent/'b_macro/fixed_h_unions/results/negative-daf08b7f35b70b9a_covering_H_rectangle.json'))
    ap.add_argument('--joint-root',default=str(HERE))
    ap.add_argument('--out',default=str(HERE/'new_reviews/negative-daf08b7f35b70b9a_fixed_h_complete.json'))
    args=ap.parse_args()
    verify(args.parent,args.tiles,args.union,args.joint_root,args.out)
