#!/usr/bin/env python3
"""Portable exact replay of the complete C60b original H-center cover."""
import ast
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
IDENT = "negative-60b1043c8c722dd5"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def local(relative):
    path = Path(relative)
    assert not path.is_absolute() and ".." not in path.parts
    result = HERE / path
    assert result.resolve().is_relative_to(HERE) and result.is_file()
    return result


def main():
    if not __debug__:
        raise RuntimeError("Exact checks require Python without optimization.")
    frozen = json.loads(local("SHA256_MANIFEST.json").read_text())
    assert frozen["schema"] == "n9_c60b_h_center_immutable_files_v1"
    for name, expected in frozen["files"].items():
        assert sha(local(name)) == expected, ("payload_file_changed", name)
    index = json.loads(local("portfolio_index.json").read_text())
    assert index["schema"] == "n9_c60b_h_center_portfolio_v1"
    register = json.loads(local("original_register.json").read_text())
    assert sha(local("original_register.json")) == index["original_register_sha256"]
    cells = register["cells"]
    assert len(cells) == 231
    baseline_closed = {cell["id"] for cell in cells if cell["status"] == "CLOSED"}
    baseline_open = {cell["id"] for cell in cells if cell["status"] == "OPEN"}
    assert len(baseline_closed) == 174 and len(baseline_open) == 57
    assert index["target_mask"] == "001/00" and index["reversal_partner"] == "100/00"
    assert index["strict_q"] == "1105/256" and index["whole_masks"] == {"closed": 8, "open": 24}
    earlier_ids, earlier_after = [], {"closed": 174, "open": 57}
    for dependency in index["previous_checkpoints"]:
        file = local(dependency["manifest"])
        assert sha(file) == dependency["manifest_sha256"]
        previous = json.loads(file.read_text())
        assert previous["status"] == "PASS_ALL_COMPLETE_ORIGINAL_PARENTS"
        assert previous["archive_sha256"] == dependency["archive_sha256"]
        assert previous["before"] == dependency["before"] == earlier_after
        assert previous["after"] == dependency["after"]
        assert previous["whole_masks"] == index["whole_masks"]
        key = ("baseline_register_sha256"
               if previous["schema"] == "n9_original_center_capacity_delivery_v1"
               else "original_register_sha256")
        assert previous[key] == index["original_register_sha256"]
        ids = [item["id"] for item in previous["complete_originals"]]
        assert len(ids) == previous["complete_original_count"] == len(set(ids))
        assert not set(ids).intersection(earlier_ids)
        assert previous["after"] == {
            "closed": previous["before"]["closed"] + len(ids),
            "open": previous["before"]["open"] - len(ids),
        }
        earlier_ids += ids
        earlier_after = previous["after"]
    assert len(index["previous_checkpoints"]) == 4
    assert earlier_ids == index["previously_closed_original_ids"]
    assert len(earlier_ids) == len(set(earlier_ids)) == 18
    assert set(earlier_ids) <= baseline_open and IDENT not in earlier_ids
    assert earlier_after == index["before"] == {"closed": 192, "open": 39}
    assert index["after"] == {"closed": 193, "open": 38}
    assert len(index["entries"]) == 1
    entry = index["entries"][0]
    assert entry["id"] == IDENT and entry["kind"] == "h_grid_rectangle"
    assert entry["target_original"] == 7
    for key in ["certificate", "union", "checker", "accepted_report", "root_report",
                "scope_audit", "adapter_review", "adapter_base", "adapter_provenance",
                "adapter_diff", "hand_assembly"]:
        assert sha(local(entry[key])) == entry[key + "_sha256"]
    assert entry["checker"] == "verify_fixed_h_canonical_v3_parent.py"
    certificate, union = local(entry["certificate"]), local(entry["union"])
    parent_record = json.loads(certificate.read_text())
    rectangle_record = json.loads(union.read_text())
    grid = HERE / entry["tiles"]
    assert grid.resolve().is_relative_to(HERE) and grid.is_dir()
    manifest = json.loads((grid / "manifest.json").read_text())
    assert sha(grid / "manifest.json") == entry["grid_manifest_sha256"]
    assert sha(grid / "summary.json") == entry["grid_summary_sha256"]
    assert manifest["parent_source"] == rectangle_record["prior"]["file"]
    assert manifest["parent_sha256"] == rectangle_record["prior"]["sha256"] == entry["certificate_sha256"]
    sources = {}
    for record in [parent_record, rectangle_record, manifest]:
        for source_field in ["sources", "additional_sources"]:
            for name, expected in record.get(source_field, {}).items():
                assert name not in sources or sources[name] == expected
                sources[name] = expected
    prior = parent_record["prior"]
    assert prior["kind"] == "fresh_replayed_coordinate_prefix" and prior["deductions"] == 31
    assert prior["file"] not in sources
    bindings = json.loads(local("source_bindings.json").read_text())
    assert set(bindings) == set(sources) | {prior["file"]}
    expected_sources = dict(sources)
    expected_sources[prior["file"]] = prior["sha256"]
    for name, expected in expected_sources.items():
        assert bindings[name] in frozen["files"]
        assert sha(local(bindings[name])) == expected

    # The accepted H checker's complete physical/arithmetic/coverage core is
    # unchanged. The separate adapter adds canonical-v3 metadata checks.
    old, new = local(entry["adapter_base"]).read_text(), local(entry["checker"]).read_text()
    first, last = "    def rebuild(", "    report={"
    old_core = old[old.index(first):old.index(last)]
    new_core = new[new.index(first):new.index(last)]
    assert old_core == new_core
    imports = lambda code: [
        ast.dump(node, include_attributes=False) for node in ast.walk(ast.parse(code))
        if isinstance(node, (ast.Import, ast.ImportFrom))
    ]
    assert imports(old) == imports(new)
    adapter_review = json.loads(local(entry["adapter_review"]).read_text())
    assert adapter_review["status"] == "PASS_METADATA_ADAPTER_AND_COMPLETE_ORIGINAL_REPLAY"
    assert adapter_review["base_verifier_sha256"] == entry["adapter_base_sha256"]
    assert adapter_review["adapter_sha256"] == entry["checker_sha256"]
    assert adapter_review["core_sha256"] == hashlib.sha256(new_core.encode()).hexdigest()
    assert adapter_review["target_original_unchanged"] == 7
    assert adapter_review["independent_replay_report_sha256"] == entry["accepted_report_sha256"]

    from verify_fixed_h_canonical_v3_parent import verify
    out = HERE / "new_reviews"
    out.mkdir(exist_ok=True)
    destination = out / (IDENT + "_complete.json")
    report = verify(certificate, grid, union, HERE, destination)
    accepted = [
        json.loads(local(entry["accepted_report"]).read_text()),
        json.loads(local(entry["root_report"]).read_text()),
    ]
    expected = {
        "id": IDENT, "status": "PASS_COMPLETE_ORIGINAL_PARENT",
        "whole_original_parent_closed": True, "whole_mask_closed": False,
        "parent_schema": "whole_parent_sharp_altitude_support_frame_pointdisk_v3",
        "canonical_parent_id": IDENT, "target_original": 7,
        "grid_size": [8, 8], "all_64_tiles_accounted_for": True,
        "static_tiles_checked": 60, "static_terminal_counts": {"positive_exact_reserve": 60},
        "covered_rectangle_tiles": [16, 17, 24, 25], "original_pending_tiles": [16, 17, 24],
        "rectangle_deductions": 172,
        "rectangle_rounds": [{"round": 0, "deductions": 172, "printed_rows": 216}],
        "rectangle_terminal_rows": 22, "new_printed_rows_checked": 574,
        "analytic_frame_terminal": None, "physical_difference_terminal": None,
        "unsupported_rules_accepted": False,
        "union_certificate_sha256": entry["union_sha256"],
        "verifier_sha256": entry["checker_sha256"],
        "joint_verifier_sha256": sha(local("verify_joint_original.py")),
        "independent_rules_sha256": sha(local("independent_all_rules.py")),
    }
    for key, value in expected.items():
        assert report[key] == value
        assert all(previous[key] == value for previous in accepted)
    expected_parent = {
        "status": "PASS_CERTIFIED_PARENT_STATE_OPEN",
        "whole_original_parent_closed": False,
        "prior_coordinate_deductions": 31, "new_deductions": 457,
        "rounds": 5, "printed_rows_checked": 1241,
        "certificate_sha256": entry["certificate_sha256"],
        "bound_induction_branch_nodes": 0,
    }
    for key, value in expected_parent.items():
        assert report["parent_proof"][key] == value
        assert all(previous["parent_proof"][key] == value for previous in accepted)
    assert sum(tile["printed_rows"] for tile in report["static_tile_reports"]) == 336
    assert Q(report["rectangle_positive_reserve"]) == Q(rectangle_record["terminal"]["reserve"]) > Q(7, 1000)
    assert Q(report["least_positive_reserve"]) > Q(1, 1000)
    assert all(previous["rectangle_positive_reserve"] == report["rectangle_positive_reserve"] for previous in accepted)

    audit = json.loads(local(entry["scope_audit"]).read_text())
    assert audit["schema"] == "n9_c60b_exact_original_scope_audit_v1"
    assert audit["register_sha256"] == index["original_register_sha256"]
    assert audit["preceding_checkpoint_manifest_sha256"] == index["previous_checkpoints"][-1]["manifest_sha256"]
    assert audit["preceding_complete_original_count"] == 18
    assert audit["original_id"] == IDENT and audit["original_path"] == parent_record["path"]
    assert audit["certificate_sha256"] == entry["certificate_sha256"]
    path = parent_record["path"]
    assert path == [["angle", 3, 0], ["angle_cut", [0, "0"], 1],
                    ["alternate_four_escape", [1, 7], [7]],
                    ["alternate_four_escape", [1, 8], [6]]]
    exact = [cell["id"] for cell in cells if cell["path"][:len(path)] == path]
    assert exact == audit["exact_path_original_ids"] == [IDENT]
    assert audit["new_complete_original_count"] == 1 and audit["new_original_predicates"] == 0
    broader = [cell["id"] for cell in cells if cell["path"][:3] == path[:3]]
    assert broader == audit["broader_prefix_original_ids"] and len(broader) == 29
    assert audit["broader_prefix"] == path[:3]
    closed = baseline_closed | set(earlier_ids) | {IDENT}
    assert len(closed) == 193
    remaining = [ident for ident in broader if ident not in closed]
    assert remaining == audit["broader_prefix_remaining_open_after_c60b"] == [
        "negative-6181e7007bf6714b", "negative-95371f658da581d0", "negative-573078fc944ce553"]
    assert audit["broader_prefix_closed"] is False and audit["new_broad_macro_closures"] == 0
    assert audit["whole_mask_closed"] is False
    scope_report = {
        "status": "PASS_EXACT_ORIGINAL_SCOPE_BROADER_PREFIX_OPEN",
        "original_id": IDENT, "original_path": path, "complete_original_count": 1,
        "broader_prefix_original_count": 29, "broader_prefix_remaining_open": remaining,
        "broader_prefix_closed": False, "new_broad_macro_closures": 0,
        "whole_mask_closed": False,
    }
    (out / "c60b_scope.json").write_text(json.dumps(scope_report, indent=2) + "\n")
    summary = {
        "schema": "n9_c60b_h_center_complete_replay_v1",
        "status": "PASS_ALL_COMPLETE_ORIGINAL_PARENTS",
        "complete_original_ids": [IDENT], "complete_original_count": 1,
        "before": index["before"], "after": index["after"], "whole_masks": index["whole_masks"],
        "previously_closed_original_count": 18,
        "totals": {
            "prior_coordinate_deductions": 31, "whole_parent_new_deductions": 457,
            "rectangle_new_deductions": 172, "new_exact_deductions": 629,
            "printed_rows_checked": 1815, "complete_terminal_domains": 61,
            "fixed_grid_tiles": 64, "static_terminal_domains": 60,
            "complete_rectangle_domains": 1, "whole_parent_terminal_domains": 0,
        },
        "new_broad_macro_closures": 0, "broader_prefix_remaining_open": remaining,
        "scope_report": "new_reviews/c60b_scope.json",
        "reports": [{"id": IDENT, "kind": "h_grid_rectangle", "status": report["status"],
                     "report": str(destination.relative_to(HERE))}],
        "relocated_producer_sources": len(sources), "relocated_coordinate_priors": 1,
        "source_bindings_complete_and_relative": True,
        "physical_arithmetic_and_coverage_core_unchanged": True,
        "unsupported_rules_accepted": False, "lean_lake_ci_run": False,
        "proof_kernel_verification": False, "whole_mask_closed": False,
    }
    (out / "portable_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)
    return summary


if __name__ == "__main__":
    main()
