# One complete original A cell closes by the D/I corner and C/I distance

The unchanged original cell is `positive-8f760b2d708ad21d`, which is OPEN at PR head `cab1367cd3792ff73034a81e3017cec2779b6cf1`. Its entire immutable ancestor path is

```json
[["angle",3,1],["angle_cut",[0,"0"],0],["inward_row_escape",[7,8],[6]],["position_cut",[11,"1/2"],0],["f_side_escape",[5,7],[6]],["f_side_escape",[5,8],[5]]]
```

The caller is the complete original-nine strict-radius mask `001/00`, with the same normalization and fixed-cover semantics. All nine squares, 36 physical pairs, 36 corner conditions, marked cone comparisons and original strict weak CD bit remain in force. No additional split or restriction is made on the original parent.

## Complete exact derivation

The accepted coordinate prefix gives 34 deductions. Two new whole-parent rounds give 173 and 185 deductions, for 358 new deductions. Every round uses only its predecessor's proved coordinate, angle, scalar and difference intervals. All bounds are nonnegative rational sums with exact paid residuals and outward rounding, followed by the same physical original-frame inversion.

The portable independent checker reconstructs all accepted v4 rows, independently reconstructs each newly used original point/incircle row, checks all 373 printed rows, all weighted sums, simultaneous state transitions, original path identity and final contradiction. It imports neither the new search driver nor the new point/incircle generator. The added altitude rows are unused in the certificate and are not proof premises.

Only one new point/incircle rule occurs in a weighted deduction:

    original_point_incircle_3_8_8_-1_1_0_1.

It concerns the physical pair D/I and the actual frame of original I. For d=c_I−c_D and z=(−u_I+v_I)/2, the physical point c_I−z belongs to original I. Its distance from c_D is at least one-half, since original D's open incircle is disjoint from the interior of original I; a point on I's boundary lying strictly inside that disk would also force interior intersection. Thus ||d−z||²≥1/4. Expanding this identity, then using independently proved old-state secants and the two exact product lower planes, yields the printed linear row. No independently chosen artificial orientation is substituted for I.

## Short final hand contradiction

The two complete rounds prove the following intervals for the unchanged original pair C/I:

    x_I−x_C ∈ [−14143810182083/140737488355328, 84539/1048576],
    y_I−y_C ∈ [205223/262144, 1013291/1048576].

Direct cross multiplication shows

    |x_I−x_C| < 11/100,
    |y_I−y_C| < 97/100.

Consequently

    ||c_I−c_C||² < (11²+97²)/10000
                  =953/1000 < 1.

But both original unit squares contain radius-one-half incircles. Their disjoint open interiors force their center distance to be at least one. This contradiction excludes the entire original parent.

The saved optimizer terminal separately has three rational rows and exact positive reserve

    511825180985444640006414591300671/
    405648192073033408478945025720320.

The simple distance argument above supplies the geometric terminal; the optimizer's claim is not a premise.

## Evidence and scope

Certificate: `joint_results/positive-8f760b2d708ad21d.json`.
Independent checker: `verify_new_originals.py`.
Independent replay: `new_reviews/positive-8f760b2d708ad21d.json`.

This proof closes one original fixed cell after integration and independent root acceptance. It does not close the entire `001/00` mask, its reversal, another mask, a positional root, or a roadmap gate. No Lean, Lake or CI was run. No human or proof-kernel verification is claimed.
