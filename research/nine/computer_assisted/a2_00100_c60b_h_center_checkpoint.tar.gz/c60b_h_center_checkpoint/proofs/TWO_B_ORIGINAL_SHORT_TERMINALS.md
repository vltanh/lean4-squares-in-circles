# Two complete B originals: short terminals and exact scope

The source-bound full-parent inductions for `negative-a3ab8823d7fe0fa6` and `negative-ab8b276e0338d7f0` preserve the unchanged original caller, all nine physical originals and their original paths. Both close after one new simultaneous bound round, with zero new case splits. The short terminals here simplify the last step; the independently replayed original-parent deductions remain essential prerequisites.

## A–H–F strip terminal

For `negative-a3ab8823d7fe0fa6`, 55 inherited coordinate deductions and 150 new deductions prove the premises of seven final rows. One of them is the sharper physical A,H,F capacity row in the rational orthonormal frame with transverse direction `(5/13,-12/13)`. The other six are original A corner/frame constraints, F coordinate bounds, and a proved original F-minus-A vertical bound.

`a3ab_seven_row_exact_terminal.json` prints seven strictly positive rational multipliers. All six coefficients of the variables `x_A,y_A,x_F,y_F,alpha_A,beta_A` cancel exactly. The weighted right side is

    -586586786986515328416722777007112863012397 /
      12064216768231511637477644304384000000000000 < 0.

Thus the full original parent implies zero is at most a strictly negative rational number. This exact dependence uses no residual-coefficient payment.

## H–I incircle terminal

For `negative-ab8b276e0338d7f0`, 34 inherited coordinate deductions and 138 new deductions prove

    |y_I-y_H| <= 977503/1048576 < 1.

The original ancestor path already contains the closed predecessor implication `x_H>=0` from `lower_escape(C,H), child 1`, the primary inequality `x_I<=0` from `lower_escape(C,I), child 0`, and the original normalization `x_H<=x_I`. Therefore **x_H=x_I=0 exactly**. The two unchanged unit squares contain their original open disks of radius one half; their interior disjointness requires center distance at least one. Equal x coordinates therefore require `|y_I-y_H|>=1`, contradicting the proved upper bound. The exact gap is `71073/1048576`.

The stored final table provides another two-row version. Both signed original H/I vertical gap alternatives are forced because the opposite sign is incompatible with the full parent's proved interval. With one half of each row, all coordinate coefficients cancel and the right side is

    -4294967295/4294967296 < 0.

`ab8_two_row_exact_terminal.json` prints the rows, multipliers, and full original path. Even without using exact x equality, the outward-rounded displacement box suffices: `|x_I-x_H|<=1/1048576` and the displayed y bound give squared center distance at most one minus `71999756383/549755813888`, strictly below one.

## What the two closures do and do not finish

The two original paths have exactly the first three conditions in common: negative D sign, nonpositive A sign, and the low-F branch `y_F<=1/2`. They then use different original H-routing children. Their common early branch has 29 fixed original descendants, 20 of them OPEN in the incoming register. Closing these two leaves 18 OPEN descendants there. Consequently these two results **do not** finish that broader parent or the entire B family.

The first result does finish the whole early H-routing child 3, whose entire fixed descendant set consists of the a3ab original. The second finishes its own unchanged original parent. The entire B scan covers the same 27 incoming OPEN B IDs: these two have full candidate contradictions, and the other 25 remained OPEN after the predeclared five-round pass. Independent replay is required before any candidate is accepted. The mask ledger does not change from these two original-cell closures.

The exact path-union audit is `two_b_original_scope_audit.json`. No Lean, Lake, CI, new original IDs, compulsory subgates, or positional-root exclusions are introduced.
