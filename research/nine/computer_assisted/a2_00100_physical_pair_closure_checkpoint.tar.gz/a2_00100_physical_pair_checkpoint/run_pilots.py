#!/usr/bin/env python3
"""Whole original-cell physical-pair pilots, exact replays of claimed leaves.

No child or floating feasibility result changes the fixed parent status.
The existing v14 physical row semantics and verifier remain unchanged.
"""
import argparse, concurrent.futures, json, os, sys, time, traceback, warnings
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'whole_cell_payload'))
PILOTS=(
 ('A','shallow','positive-2d5aba857f2f7602'),
 ('A','deep','positive-c5d1d2351fe764c2'),
 ('B','shallow','negative-16a2fc93c8d133f0'),
 ('B','deep','negative-31ce871c81b35b54'),
 ('C','shallow','negative-0b5d0bfec10c8526'),
 ('C','deep','negative-b1a9c1540e73c619'),
 ('D','shallow','positive-3622c4448973035b'),
 ('D','deep','positive-655c4b699ba028a1'))

def trial(job):
 row,limit=job
 import numpy as np
 import weak_outer_numeric_strict_bulk_v14_lp as M
 import weak_outer_numeric_strict_bulk_v14_branch as B
 import weak_outer_numeric_strict_bulk_v14_verify as V
 from frontier_bounded_cells import children,verify_cell_union
 warnings.filterwarnings('ignore')
 M.linprog=B.capture_lp
 start=time.monotonic();prefix=row['path']
 pending=[f['path'] for f in row['frontier']] if 'frontier' in row else [prefix]
 leaves=list(row.get('leaves',[]));frontier=[];decisions=list(row.get('decisions',[]));errors=[];nodes=0
 while pending and nodes<limit:
  path=pending.pop();nodes+=1
  box,pos,ch=V.reconstruct(path)
  fl=lambda z:tuple(tuple(float(v) for v in interval) for interval in z)
  hit,point,data=M.solve(fl(box),fl(pos),ch)
  if hit is not None:
   leaf=json.loads(json.dumps({'path':path,**hit}))
   try:
    reserve,terminal=V.replay_leaf(leaf)
    leaf['checked_reserve']=str(reserve);leaf['checked_terminal']=terminal
    leaves.append(leaf);continue
   except Exception:
    errors.append({'path':path,'hit':hit,'error':traceback.format_exc()})
  selected={(pair,kind) for pair,kind,_ in ch}
  if point is None:
   frontier.append({'path':path,'reason':'NO_LP_POINT'});continue
  centers=point.reshape(9,2)
  pairs=[]
  for i in range(9):
   for j in range(i+1,9):
    pair=(i,j)
    if (pair,'sat') not in selected:
     d=max(abs(centers[j]-centers[i]))
     pairs.append((float(d),pair))
  if not pairs:
   frontier.append({'path':path,'reason':'ALL_SAT_PAIRS_RETAINED_RELAXATION_FEASIBLE','relaxed_variables':list(map(float,B._last))});continue
  _,pair=min(pairs)
  kind='sat' if (pair,'proxy') in selected else 'proxy'
  # Physical pair splits only: no angle, center, or analytic escape refinement.
  query=(kind,pair)
  decisions.append({'path':path,'query':[kind,list(pair)],'relaxed_centers':list(map(float,point))})
  for step in reversed(children(query)):
   child=path+[step];V.reconstruct(child);pending.append(child)
 frontier.extend({'path':p,'reason':'NODE_LIMIT'} for p in pending)
 closed=not frontier and not errors
 if closed:verify_cell_union(prefix,leaves)
 return {'id':row['id'],'sign':row['sign'],'path':prefix,'status':'CLOSED' if closed else 'OPEN',
         'nodes':nodes+row.get('nodes',0),'new_nodes':nodes,'leaves':leaves,'frontier':frontier,'decisions':decisions,'errors':errors,
         'seconds':time.monotonic()-start,'mechanism':'full-v14 original shared-frame corner rows; physical pair proxy then SAT only'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--nodes',type=int,default=48);ap.add_argument('--workers',type=int,default=2)
 ap.add_argument('--ids',nargs='*');ap.add_argument('--name',default='pair_pilot_report');args=ap.parse_args()
 register=json.loads((HERE/'whole_cell_payload/fixed_231_register.json').read_text());cells={r['id']:r for r in register['cells']}
 selected=[p for p in PILOTS if not args.ids or p[2] in args.ids]
 if args.ids==['all-open']:
  selected=[('scale','fixed',r['id']) for r in register['cells'] if r['status']=='OPEN']
 results=[];start=time.monotonic()
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  futures={pool.submit(trial,(cells[ident],args.nodes)):(family,depth,ident) for family,depth,ident in selected}
  for future in concurrent.futures.as_completed(futures):
   family,depth,ident=futures[future]
   try:r=future.result();r.update(family=family,pilot=depth)
   except Exception:r={'id':ident,'status':'OPEN','error':traceback.format_exc(),'family':family,'pilot':depth}
   results.append(r)
   report={'source_register':'whole_cell_payload/fixed_231_register.json','original_cells':231,'baseline_closed':53,'baseline_open':178,
           'pilot_ids':[p[2] for p in selected],'node_limit':args.nodes,'completed':len(results),'closed_original_parents':sum(r['status']=='CLOSED' for r in results),
           'results':results,'seconds':time.monotonic()-start,'whole_mask_closed':False}
   (HERE/(args.name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
   print(ident,r['status'],'nodes',r.get('nodes'),'leaves',len(r.get('leaves',[])),'frontier',len(r.get('frontier',[])),'seconds',round(r.get('seconds',0),1),flush=True)
if __name__=='__main__':main()
