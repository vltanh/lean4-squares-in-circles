#!/usr/bin/env python3
"""Independent whole-parent coverage and exact replay of physical pair trees.

Discovery code is never imported. New descendants may use only the complete
four inset branches or eight owned separating-axis branches. The unchanged
accepted verifier reconstructs every rational physical leaf.
"""
import argparse
import copy
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import tarfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_cover(prefix, leaves):
    tree = {}
    for leaf in leaves:
        path = leaf['path']
        assert path[:len(prefix)] == prefix, 'Wrong original parent'
        node = tree
        for kind, pair, option in path[len(prefix):]:
            assert kind in ('proxy', 'sat'), 'Unexpected new split'
            assert len(pair) == 2 and all(type(i) is int for i in pair)
            i, j = pair
            assert 0 <= i < j < 9
            assert 'leaf' not in node, 'A leaf is an ancestor'
            query = (kind, tuple(pair))
            if not node:
                node['query'] = query
                node['children'] = {}
            assert node['query'] == query, 'Mixed queries at one node'
            node = node['children'].setdefault(tuple(option), {})
        assert not node, 'Duplicate leaf or leaf contains descendants'
        node['leaf'] = True

    count = {'nodes': 0, 'leaves': 0, 'proxy_splits': 0, 'sat_splits': 0}

    def visit(node):
        count['nodes'] += 1
        if 'leaf' in node:
            assert node == {'leaf': True}
            count['leaves'] += 1
            return
        assert set(node) == {'query', 'children'}, 'Empty/malformed node'
        kind, pair = node['query']
        if kind == 'proxy':
            expected = {(a, s) for a in (0, 1) for s in (-1, 1)}
        else:
            expected = {(o, a, s) for o in pair for a in (0, 1) for s in (-1, 1)}
        assert set(node['children']) == expected, 'Uncovered physical alternative'
        count[kind + '_splits'] += 1
        for child in node['children'].values():
            visit(child)

    visit(tree)
    return count


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('certificate', type=Path)
    ap.add_argument('--payload', type=Path, required=True)
    ap.add_argument('--archive', type=Path, required=True)
    ap.add_argument('--register', type=Path, required=True)
    ap.add_argument('--report', type=Path, required=True)
    ap.add_argument('--controls', action='store_true')
    args = ap.parse_args()
    payload = args.payload.resolve()
    # Verify all inherited Python/checker dependencies against the accepted
    # archive before importing any of them. Only source identity is checked;
    # this is not represented as fresh baseline arithmetic replay.
    archive_blob = args.archive.read_bytes()
    blob_sha = hashlib.sha1(b'blob ' + str(len(archive_blob)).encode() + b'\0' + archive_blob).hexdigest()
    assert blob_sha == '4a104744e1bf439e006a1c034eea284fd22fa8c8'
    source_count = 0
    with tarfile.open(args.archive) as archive:
        for member in archive.getmembers():
            if not member.isfile():
                continue
            name = Path(member.name).name
            local = payload / name
            if local.exists() and (name.endswith('.py') or name.endswith('_certificate.json')):
                assert local.read_bytes() == archive.extractfile(member).read(), name
                source_count += 1
    assert source_count > 10
    sys.path.insert(0, str(payload))
    import weak_outer_numeric_strict_bulk_v14_verify as V
    assert Path(V.__file__).resolve() == payload / 'weak_outer_numeric_strict_bulk_v14_verify.py'
    register = json.loads(args.register.read_text())
    original = {c['id']: c for c in register['cells']}
    data = json.loads(args.certificate.read_text())
    cells = data.get('cells', data.get('results'))
    assert isinstance(cells, list)
    cells = [c for c in cells if c['status'] == 'CLOSED']
    seen = set()
    results = []
    least = None
    terminal_counts = {}
    for cell in cells:
        ident = cell['id']
        assert ident not in seen
        seen.add(ident)
        baseline = original[ident]
        assert baseline['status'] == 'OPEN'
        assert baseline['path'] == cell['path']
        assert baseline['sign'] == cell['sign']
        path_hash = hashlib.sha256(json.dumps(cell['path'], separators=(',', ':')).encode()).hexdigest()[:16]
        assert ident == cell['sign'] + '-' + path_hash
        assert not cell.get('frontier') and not cell.get('errors')
        counts = verify_cover(cell['path'], cell['leaves'])
        reserves = []
        for leaf in cell['leaves']:
            assert leaf['context_version'] == 'strict_bulk_2026_11_03_v14'
            V.reconstruct(leaf['path'])
            reserve, terminal = V.replay_leaf(leaf)
            if reserve is not None:
                assert reserve > 0 and terminal is None
                least = reserve if least is None else min(least, reserve)
                reserves.append(str(reserve))
            else:
                assert isinstance(terminal, str) and terminal
            key = terminal or 'positive exact rational combination'
            terminal_counts[key] = terminal_counts.get(key, 0) + 1
        results.append({'id': ident, 'sign': cell['sign'], **counts,
                        'weighted_leaves': len(reserves),
                        'least_positive_reserve': str(min(map(Fraction, reserves))) if reserves else None})
    controls = []
    if args.controls:
        assert cells
        bad = copy.deepcopy(cells[0])
        bad['leaves'].pop()
        try:
            verify_cover(bad['path'], bad['leaves'])
        except AssertionError:
            controls.append('missing physical child rejected')
        else:
            raise AssertionError('Missing child accepted')
        bad = copy.deepcopy(cells[0])
        bad['leaves'].append(copy.deepcopy(bad['leaves'][0]))
        try:
            verify_cover(bad['path'], bad['leaves'])
        except AssertionError:
            controls.append('duplicate leaf rejected')
        else:
            raise AssertionError('Duplicate leaf accepted')
        bad = copy.deepcopy(cells[0])
        bad['leaves'][0]['path'][len(bad['path'])][2] = [2, 1]
        try:
            verify_cover(bad['path'], bad['leaves'])
        except AssertionError:
            controls.append('invalid inset axis rejected')
        else:
            raise AssertionError('Invalid axis accepted')
        weighted = next(leaf for c in cells for leaf in c['leaves']
                        if V.replay_leaf(leaf)[0] is not None)
        bad = copy.deepcopy(weighted)
        bad['weights'] = []
        try:
            V.replay_leaf(bad)
        except AssertionError:
            controls.append('missing rational multipliers rejected')
        else:
            raise AssertionError('Missing multipliers accepted')
    summary = {'status': 'PASS', 'whole_mask_closed': False,
               'scope': 'Fresh independent complete parent coverage and exact replay of every new leaf; inherited source identity only, no repeated baseline arithmetic.',
               'certificate_sha256': digest(args.certificate),
               'register_sha256': digest(args.register),
               'accepted_archive_git_blob': blob_sha,
               'unchanged_inherited_sources': source_count,
               'verifier_sha256': digest(Path(V.__file__)),
               'closed_original_cells': len(results),
               'new_terminal_leaves': sum(r['leaves'] for r in results),
               'least_positive_reserve': str(least),
               'terminal_counts': terminal_counts, 'cells': results,
               'rejected_controls': controls}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k != 'cells'}, indent=2))


if __name__ == '__main__':
    main()
