#!/usr/bin/env python3
"""Collect complete original parents and print their exact finite row tables."""
import hashlib,json,sys,time
from pathlib import Path
from run_pilots import HERE
sys.path.insert(0,str(HERE/'whole_cell_payload'))
from export_cell_tables import export_leaf
from check_cell_tables import check
from frontier_bounded_cells import verify_cell_union

def atomic(path,data):
 temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(path)

def main():
 register=json.loads((HERE/'whole_cell_payload/fixed_231_register.json').read_text())
 byid={r['id']:r for r in register['cells']}
 reports=['pair_pilot_report.json','physical_scale24_report.json','near_parents_first_report.json','near_parents_second_report.json','near_parents_final_report.json']
 sources=[];selected={}
 paths=[HERE/p for p in reports]+[HERE.parent/'sharp_frame/negative_shallow_resume.json']
 for path in paths:
  if not path.exists():continue
  raw=path.read_bytes();data=json.loads(raw);rows=data.get('results',[data])
  sources.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()})
  for row in rows:
   if row['status']!='CLOSED':continue
   assert row['id'] in byid and row['path']==byid[row['id']]['path'] and byid[row['id']]['status']=='OPEN'
   assert not row['frontier'] and not row.get('errors',[])
   previous=selected.get(row['id'])
   if previous is None or len(row['leaves'])<len(previous['leaves']):selected[row['id']]=row
 cells=[]
 for ident,row in sorted(selected.items()):
  verify_cell_union(row['path'],row['leaves'])
  cells.append({k:row[k] for k in ('id','sign','path','status','nodes','leaves')})
 proof={'scope':'Complete exclusions for fixed original OPEN cells in the accepted231-cell cover; no whole-mask conclusion',
        'source_context':'strict_bulk_2026_11_03_v14','baseline_closed_cells':53,'baseline_open_cells':178,
        'new_closed_original_cells':len(cells),'remaining_original_cells':178-len(cells),'source_reports':sources,'cells':cells}
 atomic(HERE/'physical_closed_union.json',proof)
 cache_dir=HERE/'rational_leaf_cache';cache_dir.mkdir(exist_ok=True);records=[];start=time.monotonic()
 for cell in cells:
  for index,leaf in enumerate(cell['leaves']):
   key=hashlib.sha256(json.dumps([cell['id'],index,leaf],sort_keys=True,separators=(',',':')).encode()).hexdigest()
   cache=cache_dir/(key+'.json')
   if cache.exists():record=json.loads(cache.read_text())
   else:
    record=export_leaf(cell['id'],index,leaf);atomic(cache,record)
   records.append(record)
  print('exported',cell['id'],'cells',len({r['cell_id'] for r in records}),'leaves',len(records),'seconds',round(time.monotonic()-start,1),flush=True)
 tables={'scope':'Explicit rational rows for all weighted leaves of complete new original-parent proofs; interval leaves retain their derivations',
         'closed_original_cells':len(cells),'new_terminal_leaves':len(records),'whole_mask_closed':False,'records':records}
 atomic(HERE/'physical_rational_tables.json',tables)
 arithmetic=check(tables);arithmetic['table_sha256']=hashlib.sha256((HERE/'physical_rational_tables.json').read_bytes()).hexdigest()
 atomic(HERE/'physical_rational_tables_check.json',arithmetic)
 print({'cells':len(cells),'leaves':len(records),**arithmetic},flush=True)
if __name__=='__main__':main()
