#!/usr/bin/env python3
"""Deduplicate completed original parents; preserve every original path.

This assembles already independently replayed proof packages. It does not
represent a hash/identity check as an additional arithmetic replay.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def assemble(root):
    original = json.loads((root/'original_fixed_register.json').read_text())
    assert original['closed_cells'] == 53 and original['open_cells'] == 178
    index = {c['id']: c for c in original['cells']}
    accepted = {}
    alternatives = []
    physical = [('physical_closed_union.json','physical_union_exact_review.json'),
                ('physical_closed_union_v2_additions.json','physical_v2_exact_review.json')]
    for filename, reportname in physical:
        proof = json.loads((root/filename).read_text())
        report = json.loads((root/reportname).read_text())
        assert report['status']=='PASS' and report['certificate_sha256']==sha(root/filename)
        rows = {r['id']:r for r in report['cells']}
        assert len(rows)==len(proof['cells'])
        for c in proof['cells']:
            ident=c['id'];old=index[ident]
            assert c['status']=='CLOSED' and old['status']=='OPEN'
            assert c['path']==old['path'] and c['sign']==old['sign']
            assert not c.get('frontier') and not c.get('errors')
            assert ident not in accepted and ident in rows
            assert rows[ident]['leaves']==len(c['leaves'])
            accepted[ident]={'method':'complete_physical_pair_tree',
                'certificate':filename,'record_id':ident,'independent_report':reportname,
                'terminal_leaves':len(c['leaves'])}
    bound_report=json.loads((root/'derived_bound_exact_review.json').read_text())
    assert bound_report['status']=='PASS' and not bound_report['rejected_candidates']
    inputs={Path(p).name:h for p,h in bound_report['input_sha256'].items()}
    assert len(inputs)==6
    for c in bound_report['cells']:
        ident=c['id'];name=ident+'.json';p=root/'derived_bound_certificates'/name
        assert c['status']=='PASS_COMPLETE_ORIGINAL_CELL' and sha(p)==inputs[name]
        assert index[ident]['status']=='OPEN' and c['parent_path']==index[ident]['path']
        evidence={'method':'acyclic_derived_coordinate_bounds',
            'certificate':'derived_bound_certificates/'+name,'record_id':ident,
            'independent_report':'derived_bound_exact_review.json',
            'bound_deductions':c['verified_bound_deductions'],'terminal_leaves':1}
        if ident in accepted:alternatives.append({'id':ident,**evidence})
        else:accepted[ident]=evidence
    assert len(accepted)==99 and len(alternatives)==1
    current=copy.deepcopy(original)
    for c in current['cells']:
        if c['id'] not in accepted:continue
        e=accepted[c['id']]
        c['status']='CLOSED';c['method']=e['method'];c['terminal_leaves']=e['terminal_leaves']
        c['evidence']={'archive':'a2_00100_physical_pair_closure_checkpoint.tar.gz',**e}
    assert [(c['id'],c['path']) for c in current['cells']]==[(c['id'],c['path']) for c in original['cells']]
    current['closed_cells']=sum(c['status']=='CLOSED' for c in current['cells'])
    current['open_cells']=sum(c['status']=='OPEN' for c in current['cells'])
    assert current['closed_cells']==152 and current['open_cells']==79
    current['baseline_assembly']=original['assembly']
    current['assembly']='../A2_00100_PHYSICAL_PAIR_CLOSURE_CHECKPOINT.md'
    current['baseline_manifest']=original['manifest']
    current['manifest']='../computer_assisted/a2_00100_physical_pair_closure_manifest.json'
    current['cell_review']='../A2_00100_PHYSICAL_PAIR_CLOSURE_CHECKPOINT.md'
    current['latest_new_closed_cells']=99
    current['open_cell_obstruction']='No complete proof is known for this unchanged original path. Physical-pair, bound and original-frame continuation trees retain all unresolved descendants internally; partial trials do not replace this parent.'
    current['open_cell_discovery_report']='../computer_assisted/a2_00100_physical_pair_closure_manifest.json'
    result={'status':'PASS_IDENTITY_AND_DEDUPLICATED_ASSEMBLY',
        'arithmetic_replay_not_repeated':True,'original_register_sha256':sha(root/'original_fixed_register.json'),
        'new_closed_original_cells':99,'closed_original_cells':152,'open_original_cells':79,
        'physical_tree_cells':94,'additional_bound_cells':5,
        'cells':[{'id':i,**e} for i,e in sorted(accepted.items())],
        'alternative_proofs':alternatives,
        'remaining_original_ids':[c['id'] for c in current['cells'] if c['status']=='OPEN'],
        'whole_mask_closed':False,'new_mask_closures':0,'new_positional_root_exclusions':0,
        'new_roadmap_gate_closures':0,'lean_lake_ci_run':False}
    return current,result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--register-output',type=Path);a=ap.parse_args()
    root=Path(__file__).resolve().parent
    current,index=assemble(root)
    (root/'cell_index.json').write_text(json.dumps(index,indent=2)+'\n')
    if a.register_output:a.register_output.write_text(json.dumps(current,indent=2)+'\n')
    print({k:v for k,v in index.items() if k not in ('cells','remaining_original_ids','alternative_proofs')})
