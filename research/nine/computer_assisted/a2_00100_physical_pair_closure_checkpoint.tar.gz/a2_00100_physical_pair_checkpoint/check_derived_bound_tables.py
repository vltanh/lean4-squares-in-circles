#!/usr/bin/env python3
"""Recheck the printed rational arithmetic without importing physical code.

Physical validity of printed rows is separately established by the source-bound
reviewer. This compact checker verifies their weights, sums, residual bounds,
round-delayed interval updates and final positive reserves from the table alone.
"""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

RHO = F(91, 60)


def arithmetic(table, n, objective=None):
    rows = {row["index"]: row for row in table["rows"]}
    assert len(rows) == len(table["rows"])
    denominator = table["weight_denominator"]
    assert denominator == 1 << 40
    vector = [F(0)] * n
    scalar = F(0)
    seen = set()
    for index, integer in table["weights"]:
        assert type(index) is int and index not in seen and index in rows
        assert type(integer) is int and integer > 0
        seen.add(index)
        row = rows[index]
        used = set()
        weight = F(integer, denominator)
        scalar += weight * F(row["rhs"])
        for k, rational in row["coefficients"]:
            assert type(k) is int and 0 <= k < n and k not in used
            used.add(k)
            vector[k] += weight * F(rational)
    assert scalar == F(table["summed_rhs"])
    if objective:
        k, sign = objective
        vector[k] -= sign
    return vector, scalar


def check(path):
    data = json.loads(path.read_text())
    seen = set()
    deductions = finals = analytic = 0
    for cell in data["cells"]:
        assert cell["id"] not in seen
        seen.add(cell["id"])
        n = 54 + 6 * sum(step[0] == "sat" for step in cell["parent_path"])
        bounds = [RHO] * 18 + [F(1)] * 36
        bounds += [2*RHO, 2*RHO, F(1), F(1), F(1), F(1)] * ((n-54)//6)
        previous = None
        for ridx, state in enumerate(cell["states"]):
            assert state["round"] == ridx
            before = [[F(a), F(b)] for a, b in state["certified_positions_before"]]
            assert len(before) == 18
            assert previous is None or before == previous
            assert [F(x) for x in state["absolute_variable_bounds"]] == bounds
            after = [v[:] for v in before]
            for index, d in enumerate(state["deductions"]):
                assert d["round"] == ridx and d["index"] == index
                k, sign = d["coordinate"], d["sign"]
                assert type(k) is int and 0 <= k < 18 and sign in (-1, 1)
                vector, scalar = arithmetic({**d, "rows": state["rows"]}, n, (k, sign))
                assert [[j, str(c)] for j, c in enumerate(vector) if c] == d["residual"]
                error = sum(M * abs(c) for M, c in zip(bounds, vector))
                assert error == F(d["residual_correction"])
                proven = scalar + error
                upper = F(d["declared_upper"])
                assert proven == F(d["proved_upper"]) and proven <= upper
                assert upper - proven == F(d["slack"])
                if sign == 1:
                    after[k][1] = min(after[k][1], upper)
                else:
                    after[k][0] = max(after[k][0], -upper)
                deductions += 1
            assert after == [[F(a), F(b)] for a, b in state["certified_positions_after"]]
            previous = after
        final = cell["final_state"]
        if final and "reserve" in final:
            assert previous == [[F(a), F(b)] for a, b in final["certified_positions"]]
            assert [F(x) for x in final["absolute_variable_bounds"]] == bounds
            vector, scalar = arithmetic(final, n)
            assert [[j, str(c)] for j, c in enumerate(vector) if c] == final["summed_coefficients"]
            error = sum(M * abs(c) for M, c in zip(bounds, vector))
            assert error == F(final["residual_correction"])
            reserve = -scalar - error
            assert reserve == F(final["reserve"]) and reserve > 0
            assert cell["conclusion"] == "positive_rational_reserve"
            finals += 1
        elif cell["conclusion"] == "contradictory_certified_coordinate_interval":
            assert any(a > b for a, b in previous)
            finals += 1
        else:
            # Interval/analytic terminal validity is covered by the separate
            # fresh physical-source replay, not by a stand-alone sum checker.
            assert isinstance(cell["conclusion"], str) and cell["conclusion"]
            if final:
                assert final["analytic_terminal"] == cell["conclusion"]
                assert previous == [[F(a), F(b)] for a, b in final["certified_positions"]]
            analytic += 1
    return {"status": "PASS_PRINTED_ARITHMETIC", "cells": len(seen),
            "bound_deductions": deductions, "direct_final_contradictions": finals,
            "terminals_requiring_separate_physical_replay": analytic,
            "table_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("table", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = check(args.table)
    output = json.dumps(result, indent=2) + "\n"
    if args.report:
        args.report.write_text(output)
    print(output, end="")
