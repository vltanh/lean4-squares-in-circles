# 99 additional original-cell proofs for 001/00

This archive proves 99 of the 178 original OPEN cell predicates in the
unchanged 231-cell cover. It leaves 79 OPEN and does not close a whole mask.
The repository's `A2_00100_PHYSICAL_PAIR_CLOSURE_CHECKPOINT.md` gives the
complete geometric assembly and proof of both certificate rules.

## Contents and counts

- `physical_closed_union.json`: 87 entire parent trees, 789 leaves.
- `physical_closed_union_v2_additions.json`: 7 further parent trees, 76 leaves.
- The two `physical_rational_tables*.json` files: 466 weighted leaves,
  6027 explicit scalar rows; other leaves are explicit interval terminals.
- `derived_bound_certificates/`: 6 complete acyclic bound certificates,
  316 rational deductions and six final contradictions. One is an alternate
  proof of physical parent `negative-e82c87a207fdb074`; only five add IDs.
- `cell_index.json`: exactly 99 distinct complete original IDs and the
  remaining 79 IDs, checked against `original_fixed_register.json`.
- `whole_cell_payload/`: unchanged frozen verifier sources and dependencies.
- Root independent exact and printed-arithmetic reports, with source hashes.

No original parent is replaced by an unfinished subtree. Every source
register retains the full original path and strict nine-square caller.

## Portable exact replay

Python 3 and the standard library suffice. The accepted original archive
`a2_00100_fixed_frontier_checkpoint.tar.gz` must be alongside this extracted
directory, as it is in the repository. The physical checker uses it for
inherited source identity, then freshly checks every new leaf and union.

```sh
python review_physical_cells.py physical_closed_union.json --payload whole_cell_payload --archive ../a2_00100_fixed_frontier_checkpoint.tar.gz --register original_fixed_register.json --report fresh_physical_v1.json --controls
python review_physical_cells.py physical_closed_union_v2_additions.json --payload whole_cell_payload --archive ../a2_00100_fixed_frontier_checkpoint.tar.gz --register original_fixed_register.json --report fresh_physical_v2.json --controls
python whole_cell_payload/check_cell_tables.py physical_rational_tables.json
python whole_cell_payload/check_cell_tables.py physical_rational_tables_v2_additions.json
python review_tight_bounds_independent.py --payload whole_cell_payload --inputs derived_bound_certificates --report fresh_bounds.json --table fresh_bound_tables.json
python check_derived_bound_tables.py fresh_bound_tables.json
```

The physical reviewers independently check complete four/eight child unions
and reuse the unchanged accepted scalar-row verifier. The bound reviewer
independently checks each rational sum and its acyclic interval induction.
The printed-table checkers are separate arithmetic implementations. No
optimizer result is a proof premise. Old baseline arithmetic is not
silently counted as newly replayed. No Lean, Lake, CI, human or proof-kernel
verification is claimed.

`manifest.json` records exact delivered file hashes. Fresh reports named in
the commands are new outputs and are not members of that frozen manifest.
