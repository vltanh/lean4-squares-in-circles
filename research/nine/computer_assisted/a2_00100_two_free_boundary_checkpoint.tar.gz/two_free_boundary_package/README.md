# Explicit two-free aligned boundary family

This compact packet proves and checks a specified family of closed-radius
controls. It contributes **zero original cells and zero masks**.

Seven aligned unit-square centers A,C,D,E,F,G,I are fixed at the coordinates
in `global_theorem/D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md`. Under its
explicit AB/BC gap and cone hypotheses and the orders `x_H<=x_I` and
`y_H<=y_B`, the remaining centers are exactly

\[
B=(-1/2,-1/16-t),\qquad H=(-1/2-u,-17/16-s),
\]

where

\[
u\ge0,\qquad 0\le t\le s,\qquad
u^2+2u+s^2+\frac{25}{8}s-\frac78\le0.
\]

The exact positive factorization with constant `467/20000` proves
`s<53/200`. The selected ABID row therefore satisfies the accepted sharp
guard `U_ABID=2t<53/100`, with all seven selected frame components zero,
three horizontal gaps one, and two shoulder heights one. This covers
independent left/down movement of H as well as B's vertical movement.
The previously studied one-parameter slider is a subfamily.

Every family member has the fixed aligned C–D gap equal to one. It fails
the original strictly weak C–D predicate. These are boundary controls of
the closed relaxation; the packet does not classify all configurations of
D821, A c744, B462, or any other original cell.

## Replay

From this packet's directory, run:

```sh
python verify_all.py
```

The default result is `new_reviews/COMPLETE_REPLAY.json`. The script checks
all frozen hashes, recomputes 150 exact rational criterion checks for the
accepted sharp-row theorem, checks its guard on a uniform enclosure of
the entire specified family, and reruns both independent family-arithmetic
scripts. The latter verify the cap identity, every one of the 36 pair
separations, and all corner bounds through seven fixed farthest radii and
the two moving-radius identities. Their fresh reports must equal the
previously reviewed reports exactly.

The two unchanged scripts execute in a temporary copy inside
`new_reviews`; the frozen reports are never overwritten. The packet uses
only Python's standard library and its local frozen files. No numerical
optimizer, Lean, Lake, or CI is involved.

## Proof and review

The continuous necessity and equality-case argument is the family hand
proof. A separate independent hand review is retained at
`a_family/TWO_FREE_ALIGNED_FAMILY_INDEPENDENT_REVIEW.md`. Its independent
exact checker represents every pair separator as a nonnegative linear
combination of `1,u,t,s-t` and verifies the moving-radius comparison

\[
r_H^2-r_B^2=u^2+2u+(1+s-t)(17/8+s+t)\ge0.
\]

The accepted seven-square continuous theorem and its rational criterion
are frozen under `accepted/`. The shared original-label substitution and
strict-boundary equality argument are retained under `global_theorem/`.
Arithmetic replay substantiates the printed identities and hypotheses;
the continuous implications remain the explicitly supplied hand proofs.

The unchanged manuscripts mention separate original-caller replays and
controls. Those larger ancestry packets are outside this compact packet.
They are neither read by this replay nor silently used to infer a
whole-original implication. A future original closure must independently
prove the necessary caller hypotheses or cover their complements.

`SOURCE_BINDINGS.json` records the original source paths and hashes for
provenance. `MANIFEST.json` freezes the local inputs used by this packet.
