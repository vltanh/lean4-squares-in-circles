# Independent review of the two-free aligned boundary family

**PASS for the explicitly specified control family.** This review does not infer that an entire original cell belongs to the family and gives no original-cell or mask closure credit.

I reviewed `../global_theorem/D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md` independently of its arithmetic producer. The accompanying `check_two_free_aligned_family.py` uses standard-library rational arithmetic, verifies all 36 pair-separation witnesses and all fixed corner bounds, and writes the source-bound report `TWO_FREE_ALIGNED_FAMILY_ARITHMETIC_REVIEW.json`.

## Necessity

The actual AB and BC horizontal gaps force `x_B=-1/2`. The BC cone gives `y_B<=-1/16`.

If `x_H>-1/2`, the assumed `x_H<=x_I=1/2` makes the horizontal H–C distance strictly less than one. Their aligned nonoverlap forces either `y_H<=-33/16` or `y_H>=-1/16`. The first alternative has a corner whose squared vertical coordinate exceeds Q by at least `9/4`. In the second, the retained order `y_H<=y_B<=-1/16` forces equality of the two heights. B–H nonoverlap then forces `x_H=1/2`, so H coincides with I. Both alternatives are impossible.

If `x_H<=-3/2`, the retained height order gives `y_H<=-1/16`. The lower-left H corner then has squared norm at least `4+(9/16)^2=Q`. Containment forces equality in both coordinates, making H coincide with A. Thus `-3/2<x_H<=-1/2`.

The B–H horizontal distance is consequently strictly less than one. Their nonoverlap and height order force `y_H<=y_B-1`. The parameters `t=-1/16-y_B`, `u=-1/2-x_H`, `s=-17/16-y_H` therefore satisfy `u>=0`, `0<=t<=s`. H lies in the negative coordinate quadrant, so its lower-left corner is farthest. Its exact corner inequality is

`(1+u)^2+(25/16+s)^2<=1105/256`,

which expands to the stated `R(u,s)<=0`. No equality face was discarded in these implications.

## Sufficiency and guard

The verifier expresses a valid separation gap minus one for every original pair as a nonnegative linear combination of `1`, `u`, `t`, and `s-t`. This proves all 36 weak separations on the complete parameter domain.

H's corner inequality is the assumed `R<=0`. B's farthest squared radius is `1+(9/16+t)^2`, and the exact difference from H's farthest squared radius is

`u^2+2u+(1+s-t)(17/8+s+t)>=0`.

The seven fixed squares' farthest squared radii are checked directly. Thus all 36 corners are contained. The AB and BC cones follow from `0<=t<1`, once the next bound is proved; EF and FG retain their horizontal unit gaps.

For `r=53/200`, the constant in

`R=u^2+2u+(s-r)(s+r+25/8)+467/20000`

is exactly positive. Since `u>=0` and `s>=0`, `s>=r` would contradict `R<=0`. Hence `s<r` and `U_ABID=2t<=2s<53/100`. The ABID horizontal gaps and the two shoulder heights are all exactly one; all selected beta values are zero. This verifies the stated guard conditions throughout the family.

The strict weak C–D bit is false at every listed aligned control because its horizontal gap and combined halfwidth are both one. The document correctly treats these configurations as boundary controls for the relaxed model, not as strict counterexamples. The assertion that the guard covers a neighborhood is conditional on retaining its explicit inequalities and the physical caller; it does not supply a whole-original implication.
