#!/usr/bin/env python3
"""Independent exact arithmetic for the explicit two-free aligned controls."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
PROOF = HERE.parent / 'global_theorem/D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md'
Q = F(1105, 256)
R = F(53, 200)
# Affine forms use coordinates (constant, u, t, s).
zero = (F(0),) * 4

def form(c=0, u=0, t=0, s=0):
    return tuple(map(F, (c, u, t, s)))

def difference(a, b, sign=1):
    return tuple(sign * (x - y) for x, y in zip(a, b))

def polynomial_product(a, b):
    answer = {}
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            if x * y:
                key = tuple(sorted((i, j)))
                answer[key] = answer.get(key, F(0)) + x * y
    return {key: value for key, value in answer.items() if value}

def polynomial_sum(*terms):
    answer = {}
    for scale, poly in terms:
        for key, value in poly.items():
            answer[key] = answer.get(key, F(0)) + scale * value
    return {key: value for key, value in answer.items() if value}

centers = {
    'A': (form(F(-3, 2)), form(F(-1, 16))),
    'B': (form(F(-1, 2)), form(F(-1, 16), t=-1)),
    'C': (form(F(1, 2)), form(F(-17, 16))),
    'D': (form(F(3, 2)), form(F(-1, 16))),
    'E': (form(-1), form(F(15, 16))),
    'F': (form(0), form(F(15, 16))),
    'G': (form(1), form(F(15, 16))),
    'H': (form(F(-1, 2), u=-1), form(F(-17, 16), s=-1)),
    'I': (form(F(1, 2)), form(F(-1, 16))),
}
separations = []
for first, second in combinations(centers, 2):
    witnesses = []
    for axis in (0, 1):
        for sign in (-1, 1):
            gap = list(difference(centers[second][axis], centers[first][axis], sign))
            gap[0] -= 1
            # c + a*u + b*t + d*s = c + a*u + (b+d)*t + d*(s-t).
            cone = (gap[0], gap[1], gap[2] + gap[3], gap[3])
            if all(value >= 0 for value in cone):
                witnesses.append(dict(axis=axis, sign=sign,
                    nonnegative_coefficients_on_1_u_t_s_minus_t=list(map(str, cone))))
    assert witnesses, (first, second)
    separations.append(dict(pair=[first, second], witness=witnesses[0]))
assert len(separations) == 36
fixed_radii = {}
for name in ('A', 'C', 'D', 'E', 'F', 'G', 'I'):
    x, y = centers[name]
    assert x[1:] == zero[1:] and y[1:] == zero[1:]
    radius = (abs(x[0]) + F(1, 2)) ** 2 + (abs(y[0]) + F(1, 2)) ** 2
    assert radius <= Q
    fixed_radii[name] = str(radius)

h_radius = polynomial_sum((1, polynomial_product(form(1, u=1), form(1, u=1))),
                          (1, polynomial_product(form(F(25, 16), s=1), form(F(25, 16), s=1))))
b_radius = polynomial_sum((1, polynomial_product(form(1), form(1))),
                          (1, polynomial_product(form(F(9, 16), t=1), form(F(9, 16), t=1))))
difference_radius = polynomial_sum((1, h_radius), (-1, b_radius))
nonnegative_factorization = polynomial_sum(
    (1, polynomial_product(form(u=1), form(u=1))),
    (1, polynomial_product(form(2), form(u=1))),
    (1, polynomial_product(form(1, t=-1, s=1), form(F(17, 8), t=1, s=1))))
assert difference_radius == nonnegative_factorization
assert R * R + F(25, 8) * R - F(7, 8) == F(467, 20000) > 0
assert 2 * R == F(53, 100)
assert F(41, 16) ** 2 - Q == F(9, 4) > 0
assert F(2) ** 2 + F(9, 16) ** 2 == Q
answer = dict(status='PASS_EXPLICIT_TWO_FREE_CONTROL_FAMILY_ARITHMETIC',
    proof_sha256=hashlib.sha256(PROOF.read_bytes()).hexdigest(),
    independent_checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    pair_separations=separations, fixed_farthest_squared_radii=fixed_radii,
    radius_difference_factorization_verified=True, positive_factorization_constant='467/20000',
    guard_variation_bound='53/100', whole_original_implication_checked=False,
    original_cells_closed=0, masks_closed=0)
(HERE / 'TWO_FREE_ALIGNED_FAMILY_ARITHMETIC_REVIEW.json').write_text(json.dumps(answer, indent=2) + '\n')
print(answer['status'], 'all36 pairs and all corner bounds')
