#!/usr/bin/env python3
"""Exact polynomial and fixed-control checks for the B/H-free boundary cap."""
from fractions import Fraction as F
from itertools import combinations,product
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent

def add(*polys):
    out={}
    for p in polys:
        for key,value in p.items():out[key]=out.get(key,F(0))+value
    return {k:v for k,v in out.items()if v}

def mul(a,b):
    out={}
    for(i,j),x in a.items():
        for(k,l),y in b.items():out[i+k,j+l]=out.get((i+k,j+l),F(0))+x*y
    return {k:v for k,v in out.items()if v}

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    Q=F(1105,256);r=F(53,200)
    R={(2,0):F(1),(1,0):F(2),(0,2):F(1),(0,1):F(25,8),(0,0):F(-7,8)}
    uplusone={(1,0):F(1),(0,0):F(1)}
    splusheight={(0,1):F(1),(0,0):F(25,16)}
    assert add(mul(uplusone,uplusone),mul(splusheight,splusheight),{(0,0):-Q})==R
    gap=r*r+F(25,8)*r-F(7,8);assert gap==F(467,20000)>0
    sm={(0,1):F(1),(0,0):-r};sp={(0,1):F(1),(0,0):r+F(25,8)}
    assert add({(2,0):F(1),(1,0):F(2)},mul(sm,sp),{(0,0):gap})==R
    assert 2*r==F(53,100)and r<1
    assert F(731,25)**2-849==F(3736,625)>0
    assert 2**2+F(9,16)**2==Q and F(41,16)**2>Q
    fixed={0:(F(-3,2),F(-1,16)),2:(F(1,2),F(-17,16)),3:(F(3,2),F(-1,16)),
           4:(F(-1),F(15,16)),5:(F(0),F(15,16)),6:(F(1),F(15,16)),8:(F(1,2),F(-1,16))}
    corners=0;pairs=0
    for i,(x,y)in fixed.items():
        for a,b in product((-1,1),repeat=2):
            assert (x+F(a,2))**2+(y+F(b,2))**2<=Q;corners+=1
    for i,j in combinations(fixed,2):
        assert max(abs(fixed[i][axis]-fixed[j][axis])for axis in(0,1))>=1;pairs+=1
    criterion=json.loads((HERE/'SHARED_ABID_STRICT_TERMINAL_CHECK.json').read_text())
    report=dict(schema='exact_two_free_aligned_boundary_cap_arithmetic_v1',
        status='PASS_EXACT_IDENTITIES_AND_FIXED_CONTROL',Q=str(Q),variation_threshold=str(2*r),
        rational_positive_cap_gap=str(gap),exact_circle_expansion=True,exact_nonnegative_factorization=True,
        fixed_originals=sorted(fixed),fixed_corners_checked=corners,fixed_pairs_checked=pairs,
        necessity_and_sufficiency_require_hand_argument='D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md',
        hand_argument_sha256=digest(HERE/'D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md'),
        accepted_sharp_criterion_report_sha256=digest(HERE/'SHARED_ABID_STRICT_TERMINAL_CHECK.json'),
        source_sha256=digest(__file__),whole_original_classification_claimed=False,new_original_cells=0,new_masks=0)
    (HERE/'TWO_FREE_ALIGNED_BOUNDARY_CAP_ARITHMETIC.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
