#!/usr/bin/env python3
"""Replay the explicit two-free aligned family and sharp-guard arithmetic.

All inputs are frozen by the local manifest. The unchanged two independent
arithmetic scripts run in a temporary copy inside this packet; their output
cannot overwrite the frozen reviewed evidence. No original-cell inference
or numerical solver is used.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def frozen_inputs():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    assert manifest['schema'] == 'two_free_aligned_boundary_family_packet_v1'
    assert manifest['new_original_cells'] == manifest['new_masks'] == 0
    assert manifest['whole_original_classification_claimed'] is False
    files = manifest['frozen_file_sha256']
    assert 'verify_all.py' in files
    for name, expected in files.items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        path = ROOT / relative
        assert path.resolve().is_relative_to(ROOT) and path.is_file()
        assert digest(path) == expected, ('changed frozen input', name)
    bindings = json.loads((ROOT / 'SOURCE_BINDINGS.json').read_text())['files']
    for original, binding in bindings.items():
        assert files[binding['relative_path']] == binding['sha256']
    return manifest, files


def exact_guard_on_uniform_family_enclosure(guard):
    # The family proof gives u>=0 and 0<=t<=s<53/200. Its seven selected
    # centers are enclosed below. H's broad bounds are immaterial to ABID.
    r = F(53, 200)
    fixed = [(-F(3, 2), -F(1, 16)), (-F(1, 2), -F(1, 16)),
             (F(1, 2), -F(17, 16)), (F(3, 2), -F(1, 16)),
             (-F(1), F(15, 16)), (F(0), F(15, 16)),
             (F(1), F(15, 16)), (-F(1, 2), -F(17, 16)),
             (F(1, 2), -F(1, 16))]
    positions = [(value, value) for point in fixed for value in point]
    positions[3] = (-F(1, 16) - r, -F(1, 16))
    positions[14] = (-F(3, 2), -F(1, 2))
    positions[15] = (-F(17, 16) - r, -F(17, 16))
    scalar = [(F(1), F(1))] * 9 + [(F(0), F(0))] * 18 + [(F(1, 2), F(1, 2))] * 9
    state = dict(positions=positions, scalar=scalar,
                 angles=[(F(0), F(0))] * 9, differences={})
    result = guard.evaluate_guard(state)
    assert result['status'] == 'PASS_SHARP_PHYSICAL_ROW_GUARD'
    assert result['row'] == [0, 1, 8, 3]
    assert result['beta_bound'] == '1/200' and result['variation_bound'] == '53/100'
    assert result['certified_variation_upper'] == '53/100'
    assert set(result['certified_beta_upper'].values()) == {'0'}
    assert result['certified_horizontal_order'] == [['1', '1']] * 3
    assert result['certified_shoulder_gaps'] == [['1', '1']] * 2
    # The fixed aligned C--D coordinates meet, and fail the strictly weak bit.
    assert fixed[3][0] - fixed[2][0] == F(1, 2) + F(1, 2) == 1
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, default=ROOT / 'new_reviews/COMPLETE_REPLAY.json')
    args = parser.parse_args()
    manifest, files = frozen_inputs()
    output = args.report.resolve()
    assert output.is_relative_to(ROOT) and output != ROOT / 'MANIFEST.json'
    assert output.relative_to(ROOT).as_posix() not in files
    output.parent.mkdir(parents=True, exist_ok=True)

    # These are the already accepted continuous theorem and its exact
    # rational-criterion evaluator, kept byte-for-byte in this packet.
    hand = ROOT / 'accepted/ALL_SIGN_CORRELATED_CORNER_ROW_HAND_STRENGTHENING.md'
    criterion_path = ROOT / 'accepted/weak_outer_correlated_corner_row_arithmetic.py'
    assert digest(hand) == '0d233bddea414938482cb312519da061a546d26c4ee5a5bb83a14b48c178ed02'
    assert digest(criterion_path) == 'b67785b140fbdd448bd43d720299491c96649be3fe76c08a4e73fe5725431c4e'
    criterion = load_module('frozen_sharp_criterion', criterion_path)
    guard = load_module('frozen_sharp_guard', ROOT / 'global_theorem/shared_strict_row_terminal.py')
    criteria = [criterion.criterion(b, U, F(7, 10)) for b, U in guard.PARAMETERS]
    accepted = json.loads((ROOT / 'global_theorem/SHARED_ABID_STRICT_TERMINAL_CHECK.json').read_text())
    assert criteria == accepted['exact_source_criteria']
    assert all(result['status'] == 'PASS' for result in criteria)
    assert sum(result['check_count'] for result in criteria) == 150
    assert F(criteria[2]['parameters']['epsilon']) == F(58049449601280546655747607,
                                                      327651328921587200064000000) > 0
    family_guard = exact_guard_on_uniform_family_enclosure(guard)

    # Preserve the original checker bytes, relative source layout, and old
    # reports. Fresh outputs are compared with those reviewed reports.
    with tempfile.TemporaryDirectory(prefix='exact_family_', dir=output.parent) as temporary:
        stage = Path(temporary)
        for name in files:
            destination = stage / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, destination)
        for relative in ('global_theorem/check_two_free_boundary_cap.py',
                         'a_family/check_two_free_aligned_family.py'):
            result = subprocess.run([sys.executable, str(stage / relative)], cwd=stage,
                                    text=True, capture_output=True)
            assert result.returncode == 0, (relative, result.stdout, result.stderr)
        first_name = 'global_theorem/TWO_FREE_ALIGNED_BOUNDARY_CAP_ARITHMETIC.json'
        second_name = 'a_family/TWO_FREE_ALIGNED_FAMILY_ARITHMETIC_REVIEW.json'
        first = json.loads((stage / first_name).read_text())
        second = json.loads((stage / second_name).read_text())
        assert first == json.loads((ROOT / first_name).read_text())
        assert second == json.loads((ROOT / second_name).read_text())

    assert first['status'] == 'PASS_EXACT_IDENTITIES_AND_FIXED_CONTROL'
    assert second['status'] == 'PASS_EXPLICIT_TWO_FREE_CONTROL_FAMILY_ARITHMETIC'
    assert len(second['pair_separations']) == 36
    assert set(second['fixed_farthest_squared_radii']) == {'A', 'C', 'D', 'E', 'F', 'G', 'I'}
    assert second['radius_difference_factorization_verified'] is True
    assert first['rational_positive_cap_gap'] == second['positive_factorization_constant'] == '467/20000'
    assert first['new_original_cells'] == first['new_masks'] == 0
    assert second['original_cells_closed'] == second['masks_closed'] == 0
    assert second['whole_original_implication_checked'] is False
    proof_hash = digest(ROOT / 'global_theorem/D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md')
    assert first['hand_argument_sha256'] == second['proof_sha256'] == proof_hash
    _, after = frozen_inputs()
    assert after == files
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy', 'cvxpy'))
    report = dict(schema='independent_two_free_aligned_boundary_family_packet_replay_v1',
                  status='PASS_EXPLICIT_FAMILY_AND_CONDITIONAL_GUARD_ARITHMETIC',
                  scope='Explicit aligned B/H control family with seven fixed physical centers; no whole-original classification.',
                  family_hand_proof_sha256=proof_hash,
                  parent_hand_theorem_sha256=digest(hand),
                  frozen_inputs_checked=len(files), frozen_inputs_unchanged=True,
                  manifest_sha256=digest(ROOT / 'MANIFEST.json'),
                  source_bindings_sha256=digest(ROOT / 'SOURCE_BINDINGS.json'),
                  exact_rational_criterion_checks=150,
                  independent_pair_separation_witnesses=36,
                  all_36_corners_covered_by_fixed_radii_and_two_moving_radius_identities=True,
                  fresh_outputs_equal_independently_reviewed_outputs=True,
                  exact_positive_cap_factor='467/20000',
                  uniform_family_enclosure_guard=family_guard,
                  cap_arithmetic=first, independent_family_arithmetic=second,
                  continuous_necessity_and_sufficiency_proof='global_theorem/D821_TWO_FREE_ALIGNED_BOUNDARY_FAMILY.md',
                  independent_continuous_review='a_family/TWO_FREE_ALIGNED_FAMILY_INDEPENDENT_REVIEW.md',
                  caller_ancestor_replay_included=False,
                  whole_original_classification_claimed=False,
                  all_masks_completed=False, new_original_cells=0, new_masks=0,
                  floating_point_or_optimizer_premise=False,
                  lean_lake_ci_run=False, checker_sha256=digest(__file__))
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items()
                      if key not in ('uniform_family_enclosure_guard', 'cap_arithmetic', 'independent_family_arithmetic')}, indent=2))


if __name__ == '__main__':
    main()
