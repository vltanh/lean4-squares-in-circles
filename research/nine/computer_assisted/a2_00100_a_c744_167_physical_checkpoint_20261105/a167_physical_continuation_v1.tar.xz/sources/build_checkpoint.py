from pathlib import Path
from copy import deepcopy
import json,hashlib,os
R=Path(__file__).resolve().parent;source=R/'retained165';out=R/'checkpoint167';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
m=json.loads((source/'manifest.json').read_text());oldm=deepcopy(m);nodes=m['nodes'];proofs={};changes=[]
closed=(145,149,152,163);bounded=(144,148,151,154,156,157,159,161,164)
for n in nodes:
 p=source/n['file'];d=json.loads(p.read_text())
 if n['index'] in closed:
  q=R/f"screen_{n['index']}_full.json";s=json.loads(q.read_text());assert s['initial']==d['final']and s['terminal']
  assert all(not r['name'].startswith('selected_extra')for r in s['terminal'].get('rows',[]))
  d.update(status='CANDIDATE_CLOSED',terminal=s['terminal'],terminal_state=d.pop('final'));proofs[str(q)]=sha(q)
 elif n['index'] in bounded:
  q=R/'bound108'/n['file'];s=json.loads(q.read_text());assert s['initial']==d['final']
  d['rounds']+=s['rounds'];d.update({k:v for k,v in s.items()if k not in('initial','rounds')});proofs[str(q)]=sha(q)
 else:os.link(p,out/n['file']);continue
 d['physical_continuation_suffix']=dict(source_node_sha256=n['sha256'],old_rounds=len(json.loads(p.read_text())['rounds']),source_final=json.loads(p.read_text())['final'])
 write(out/n['file'],d);changes.append(n['index']);n.update(sha256=sha(out/n['file']),status=d['status'])
n=nodes[146];old=json.loads((source/n['file']).read_text());n.update(children=[165,166],complete_children=True,split=dict(kind='closed_angle_bisection',owner=8,cut='1/2'))
for i,mode,side in ((165,'central',0),(166,'outer',1)):
 q=R/f'screen_146_{mode}.json';s=json.loads(q.read_text());assert s['terminal']
 assert all(not r['name'].startswith('selected_extra')for r in s['terminal'].get('rows',[]))
 record=dict(status='CANDIDATE_CLOSED',initial=s['initial'],rounds=[],terminal=s['terminal'],terminal_state=s['initial'],id=m['id'],original_path=m['original_path'])
 name=f'node_{i:05}.json';write(out/name,record)
 nodes.append(dict(index=i,parent=146,depth=n['depth']+1,restriction=dict(kind='closed_angle',owner=8,cut='1/2',side=side),file=name,children=[],status='CANDIDATE_CLOSED',sha256=sha(out/name)));proofs[str(q)]=sha(q)
def visit(i):
 n=nodes[i]
 if n['children']:
  outcomes=[visit(k)for k in n['children']];n['status']='CANDIDATE_COVER_CLOSED'if all(outcomes)else'OPEN'
 return n['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')
visit(0);m['status']=nodes[0]['status'];m['physical_continuation']=dict(source_manifest_sha256=sha(source/'manifest.json'),old_nodes=165,old_payloads_retained_except_suffixes=True,changed_leaf_records=changes,new_complete_angle_cover=146,new_nodes=2,guarded_exploratory_rows_omitted=True,source_suffix_proofs=proofs)
m['source_sha256'][str(Path(__file__).resolve())]=sha(__file__)
write(out/'manifest.json',m);print('BUILT',len(nodes),'excluded',sum(not n['children']and n['status']=='CANDIDATE_CLOSED'for n in nodes),'open',sum(not n['children']and n['status']=='OPEN'for n in nodes))
