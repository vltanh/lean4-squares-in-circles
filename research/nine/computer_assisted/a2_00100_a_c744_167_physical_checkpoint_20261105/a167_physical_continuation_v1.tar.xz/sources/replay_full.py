from pathlib import Path
import json,sys,time,hashlib
N=Path('/workspace/scratch/f9f48fcfb253/ac_work/recovery_20261105_reset2/a165_i64_exact_continuation_v1');sys.path.insert(0,str(N))
import i64_retained_cover_adapter as A
R=Path(__file__).resolve().parent;folder=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve();assert not output.exists()
binding=A.ROWS.verify_binding();evidence,cache=A.ROWS.HISTORY.validate();instances=[];Checker,Adapter=A.classes(binding,instances)
A.FOUR.Checker=Checker;A.FOUR.Adapter=Adapter
with A.ROWS.HISTORY.InstalledCache(cache)as installed:
 result=A.TREE.replay(folder,output)
assert len(instances)==1
result.update(all_current_records_and_prefixes_freshly_replayed=True,historical_source_proofs_reused_not_repeated=evidence,cached_source_provider_calls=installed.calls,new_original_cells=0,new_masks=0)
output.write_text(json.dumps(result,indent=2)+'\n');print('FULL_PASS',result['nodes'],result['excluded_leaves'],result['open_leaves'],flush=True)
