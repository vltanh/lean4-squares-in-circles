import sys,json,time,pathlib
T=pathlib.Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
ROOT=pathlib.Path(__file__).resolve().parent;out=ROOT/'bound108';out.mkdir(exist_ok=True)
context=R.Context()
for n in map(int,sys.argv[1:]):
 source=ROOT/'retained165'/f'node_{n:05}.json';old=json.loads(source.read_text());s=R.state_from_view(old['final']);start=time.monotonic()
 rows,bounds,prop,term=context.collect(s);assert term is None
 h,phase,point,term=R.E.phase_solve(rows,bounds);assert term is None
 context.gram_active=False
 try:after,rr,term=R.E.bound_round(context,s,rows,bounds,prop,h,objective_limit=108)
 finally:context.gram_active=True
 rr['phase']=phase
 record=dict(initial=R.stateview(s),rounds=[rr],status='CANDIDATE_CLOSED'if term else'OPEN')
 if term:record['terminal']=term
 else:
  R.E.ACTIVE.SEED_NAMES.update(r['name']for r in rr['printed_rows'])
  final,_,_=R.E.search_node(context,after,0);record.update({k:v for k,v in final.items()if k not in('initial','rounds')})
 (out/f'node_{n:05}.json').write_text(json.dumps(record,indent=2)+'\n')
 print(n,record['status'],'deductions',len(rr['proposals']),'sec',round(time.monotonic()-start,2),flush=True)
