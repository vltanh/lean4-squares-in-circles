from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import verify_c887_unit_four_corner_tree as V
import independent_physical_sat_diagonal_replay as S
C=V.Checker();A=V.Adapter(C)
root=Path(__file__).resolve().parent
reports=[]
for p in sorted((root/'bound108').glob('node_*.json')):
 r=json.loads(p.read_text());v=r['initial'];s=dict(id=v['id'],path=v['path'],choices=A.choices(v['path']))
 for k in ('angles','positions','scalar'):s[k]=tuple(tuple(map(F,z))for z in v[k])
 for k in ('differences','diagonal'):s[k]={tuple(e['pair']):tuple(tuple(map(F,z))for z in e['intervals'])for e in v[k]}
 report,after=S.check_record(r,s,A)
 reports.append(dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),**report));print(p.name,report['status'],flush=True)
assert not any(n in sys.modules for n in ('numpy','scipy','highspy'))
(root/'BOUND108_EXACT_SUFFIX_REPLAY.json').write_text(json.dumps(dict(status='PASS_LOCAL_PHYSICAL_SUFFIXES',reports=reports,accepted_full_prefixes_reused_not_replayed=True,new_originals=0),indent=2)+'\n')
