#!/usr/bin/env python3
"""Semantic damaged-certificate controls for the independent verifier.
The ordinary verifier separately checks byte identity; these controlled inputs
exercise the path, guard, bound, frame and weighted-arithmetic checks themselves.
"""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as Q
from tempfile import TemporaryDirectory
import json
import verify_shared_bound as verifier

root=Path(__file__).resolve().parent
ident='positive-033850931bb6d4ef'
original=json.loads((root/verifier.INDEX['certificates'][ident]['certificate']).read_text())
original_entry=deepcopy(verifier.INDEX['certificates'][ident])
controls=[]
with TemporaryDirectory(prefix='damaged_controls_',dir=root)as tmp:
 def reject(label,edit):
  data=deepcopy(original);edit(data);path=Path(tmp)/(label+'.json');path.write_text(json.dumps(data))
  verifier.INDEX['certificates'][ident]=dict(original_entry,certificate=str(path.relative_to(root)))
  try:verifier.verify_certificate(ident)
  except AssertionError as e:
   controls.append({'control':label,'status':'REJECTED','assertion':str(e)});return
  raise RuntimeError('damaged certificate accepted: '+label)
 reject('changed_original_path',lambda j:j['path'][-1][-1].__setitem__(0,2))
 reject('unproved_bound',lambda j:j['rounds'][0]['proposals'][0].__setitem__('upper',str(Q(j['rounds'][0]['proposals'][0]['proved_upper'])-1)))
 reject('understated_strip_guard',lambda j:j['rounds'][1]['three_square_guards'][0].__setitem__('width_upper','0'))
 reject('altered_frame_inference',lambda j:j['rounds'][1]['physical_frame_inferences'][0]['new_slope_interval'].__setitem__(0,'0'))
 reject('altered_final_multiplier',lambda j:j['terminal']['weights'][0].__setitem__(1,j['terminal']['weights'][0][1]+1))
verifier.INDEX['certificates'][ident]=original_entry
(root/'reports/portable_rejection_controls.json').write_text(json.dumps({'status':'PASS','controls':controls},indent=2)+'\n')
print(json.dumps({'status':'PASS','rejected':len(controls)}))
