#!/usr/bin/env python3
"""Portable exact check of the optional seven-row final hand table."""
from fractions import Fraction as F
from hashlib import sha256
import json
import verify_shared_bound as R


def signature(row):
    coefficients = {}
    for k, value in row['coefficients']:
        coefficients[k] = coefficients.get(k, F(0)) + F(value)
    return row['name'], tuple(sorted(coefficients.items())), F(row['rhs'])


def main():
    R.verify_index()
    ids = ['positive-033850931bb6d4ef', 'positive-3cd9c2a7981effa2']
    records = []
    for ident in ids:
        R.verify_certificate(ident)
        file = R.BUNDLE / R.INDEX['certificates'][ident]['certificate']
        records.append(json.loads(file.read_text()))
    rows = [record['terminal']['rows'] for record in records]
    assert len(rows[0]) == len(rows[1]) == 7
    assert list(map(signature, rows[0])) == list(map(signature, rows[1]))
    p, q, s = F(108567, 1048576), F(30302249, 15728640), F(3837595, 14680064)
    weights = [F(1), 1 / p, F(1), 1 - s, F(1), q / p - 2 + s, F(1)]
    assert all(value > 0 for value in weights)
    coefficients = [F(0)] * 54
    rhs = F(0)
    for row, weight in zip(rows[0], weights):
        for k, value in row['coefficients']:
            coefficients[k] += weight * F(value)
        rhs += weight * F(row['rhs'])
    assert all(value == 0 for value in coefficients)
    assert rhs == -F(2315620317940810579, 12533921283739484160) < 0
    report = {
        'status': 'PASS_EXACT_ZERO_RESIDUAL_SEVEN_ROW_HAND_TABLE',
        'parent_ids': ids,
        'positive_multipliers': list(map(str, weights)),
        'summed_coefficients': list(map(str, coefficients)),
        'summed_rhs': str(rhs),
        'strict_positive_reserve': str(-rhs),
        'certificate_sha256': {
            ident: sha256((R.BUNDLE / R.INDEX['certificates'][ident]['certificate']).read_bytes()).hexdigest()
            for ident in ids
        },
    }
    (R.BUNDLE / 'reports/seven_row_portable_replay.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
