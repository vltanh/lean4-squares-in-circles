# Portable exact proofs for three original cells

This cumulative v1 archive contains independently accepted complete proofs
for the following unchanged original cells. It introduces no additional
branches and does not assert closure of the entire mask or any other mask.

- `positive-033850931bb6d4ef`
- `positive-3cd9c2a7981effa2`
- `positive-b696531e6d132c9e`

    python verify_shared_bound.py --all

`V1_CONTRIBUTION.md` explains the three closures and their scope. The full
fixed-domain discovery summary in `reports/` records all 63 initial OPEN
originals; the 60 v1 OPEN results are not treated as exclusions. The
optional `SEVEN_ROW_ZERO_RESIDUAL_HAND_TABLE.md` gives a short exact
positive dependence for the first two cells. Its portable check first
replays both complete certificates:

```sh
python verify_seven_row_table.py
```

## Exact replay

Run from any directory with Python 3 and its standard library:

```sh
python verify_shared_bound.py --all
```

For one supplied original cell:

```sh
python verify_shared_bound.py --id positive-033850931bb6d4ef
```

The script resolves all dependencies relative to its own directory. It
requires no optimizer, NumPy, SciPy, network connection, Lean, Lake or CI.
The frozen discovery source in `sources/` is retained for byte binding;
it is not executed or imported by this verifier.

The verifier checks the immutable original path and original OPEN status,
all supplied source/input hashes, every inherited coordinate or original
frame deduction, each new simultaneous bound round, every new inset and
three-square row, every whole-parent strip/order guard, every printed
rational sum and the final strictly positive reserve. Its new row formulas,
weighted arithmetic and physical unit-frame inversions are independent of
the discovery producer and its row modules. Only the already accepted
frozen v14 physical geometry and unweighted historical row collector are
reused.

`replay_index.json` maps the historical source identifiers retained in the
certificates to exact local copies. `original_register.json` is the fixed
baseline register at adoption, so later ledger changes do not erase which
original cells were OPEN when these certificates were discovered.

The `--allow-open` option exists solely to audit a supplied unfinished parent
state; it never changes that parent's status to CLOSED. The current proof
bundle supplies complete-parent certificates. Unsupported terminal types
are rejected rather than silently accepted.

The three-square hand theorem and its exact scalar companion are in
`proofs/`. The complete per-parent replay reports are written to `reports/`.
A successful certificate excludes its unchanged original cell; the bundle
does not by itself assert closure of an entire mask, positional root or
roadmap gate. No human or proof-kernel verification is claimed.

Run the five semantic damaged-certificate controls with:

```sh
python check_rejection_controls.py
```

The release file manifest is `SHA256_MANIFEST.json`. It binds every delivered
file other than the manifest itself. Runtime cache directories are omitted.
