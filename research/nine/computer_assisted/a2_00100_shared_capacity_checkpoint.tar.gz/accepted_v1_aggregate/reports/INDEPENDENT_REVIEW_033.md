# Independent complete-parent review: positive-033850931bb6d4ef

**Accepted.** The unchanged original cell is excluded by a complete exact
acyclic argument. No child branch was introduced, and no unresolved
subtree is credited. No Lean, Lake or CI was run.

The independently checked original path is

    positive D;
    A slope <= 0;
    inward_row_escape(H,I), child 9;
    alternate_four_escape(B,H), child 1.

Its full compact-path SHA-256 prefix agrees with the immutable ID, and the
current baseline register marks this exact path OPEN. All original caller
hypotheses, all nine squares, original frames, corner constraints and physical
pairs remain part of the unchanged physical row model.

## Exact replay and independence

`independent_replay.py` imports only the accepted frozen v14 unweighted
physical row collector and its geometry. It imports neither the new bound
producer nor either new row generator. It independently reconstructs the
new quadratic-inset secant rows, guarded three-square strip rows, weighted
rational sums, simultaneous bound installation and physical frame inversions.

The check replays all 76 inherited coordinate deductions and then all 575
new deductions in three rounds of 200, 180 and 195. Each round is generated
entirely from the preceding proved state. No deduction within a round is
used by a later deduction of that same round. Pair-difference intervals,
coordinate intervals, scalar-frame intervals and every printed bound are
checked separately. Exact physical unit-circle identities are used only
through valid monotone slope inversions with directed integer square-root
bounds.

All new strip guards are reconstructed from preceding exact pair-difference
bounds. The successive rounds have 2, 4 and 6 guarded strip rows; the final
state has 6. No order or strip width is inferred from a numerical pose.
The separate hand theorem and its independent geometric review cover every
original frame, contact face and coordinate reflection used by those rows.

The original inset quadratic family is physically valid because physical
inset separation supplies |dx|>=g_i+g_j or |dy|>=g_i+g_j. For |t|<=1,

    dx^2+dy^2-2t dx dy >= (1-t^2)(g_i+g_j)^2.

The two completions of squares cover those alternatives. A tangent lower
bound for the right square and exact upper secants/McCormick envelopes for
the left side produce the printed rational rows. Every interval used by
those envelopes comes from the same preceding proved original state.

## Final contradiction

The final seven weighted rows have nonnegative rational weights with
common denominator 2^40. Their exact residual coefficients are paid using
the retained absolute original-variable bounds. The resulting reserve is

    8929382507225583434487 / 1511157274518286468382720 > 0.

The new strip row is used essentially: it is the A,H,I triple, ordered
horizontally, with the original vertical center spread less than 2/5.
The other rows are the CD cone, a C/I center-distance secant, the retained
inward-row predecessor height budget and three independently proved pair
differences. The contradiction uses no artificial positive clearance on
the global sharp boundary.

The complete replay result is `independent_replay_report.json`.
Five damaged controls were all rejected: a changed original path, an
unproved installed bound, an understated strip width, an altered physical
frame inference and an altered final multiplier. Their report is
`rejection_controls_report.json`.

This acceptance closes exactly this original fixed cell. The whole-mask,
positional-root and roadmap ledgers require their separate complete
assemblies. No human or proof-kernel verification is claimed.
