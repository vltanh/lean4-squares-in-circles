# Complete independent review: positive-b696531e6d132c9e

**ACCEPTED: complete unchanged original parent.** No child was added and
no mask is declared closed. The same independently implemented generic
replayer used for the first two cells was run from this separate extension
directory; the frozen two-cell release was not modified.

Certificate SHA256:
`dc40a92af77feebf14789f65173208b936a8dc2ef2a4a0c696bf58e15a52a4ef`.
Prior prefix SHA256:
`9661c370617a34ab9f5fa1920fe7f2c8c24cffd63daa6837edd8535b84dc8b3e`.
Independent replayer SHA256:
`a159fa854fb537b016d6dcc9537c28b81026cf51e91970f1898ca7eac067dac9`.

## Coverage and finite induction

The original path is

    [angle,3,1]
    [angle_cut,[0,0],0]
    [inward_row_escape,[7,8],[6]]
    [position_cut,[11,1/2],0]
    [f_side_escape,[5,7],[6]]
    [f_side_escape,[5,8],[2]].

The replayer verified that this path hashes to the immutable original ID
and appears OPEN in the frozen 168/63 original register. It replayed all
33 prior coordinate deductions from that original path, followed by
160 first-round and 36 second-round new deductions. Each deduction was
an exact nonnegative weighted sum with its coefficient residual fully
paid. All before/after states, original frame inversions, pair differences,
and geometric row guards were reconstructed independently. Proposals
were installed only after the complete old-state round had been checked.

The new rows were independently generated from the hand formulas; the
producer and its new-row modules were not imported. The verifier used
the accepted historical unweighted geometry collector for inherited
rows. It reconstructed 327 printed row occurrences across both rounds
and the terminal sum. Seven inset-family rows are used in round 1.

## Final original F, I, H capacity contradiction

The terminal state proves the following exact original differences:

| Difference | Horizontal interval | Vertical interval |
|---|---|---|
| H minus F | `[0,0]` | `[169711/262144,228339/131072]` |
| I minus F | `[0,0]` | `[292429/524288,1580019/1048576]` |
| I minus H | `[0,0]` | `[-4347194684024569/4222124650659840,-93985/1048576]` |

Thus the three physical original centers have the same x coordinate
and satisfy `y_F <= y_I <= y_H`. The accepted three-original strip
theorem applies with transverse width zero and endpoint transverse
difference zero, yielding

    y_H-y_F >= 2.

For this zero-width instance there is also an elementary direct proof:
each original unit square contains its centered open disk of radius
one half, so each two distinct original centers have distance at least
one. The positive ordered gaps `y_I-y_F` and `y_H-y_I` are each at
least one; add them. This direct observation is not needed by the
generic replay but explains its final physical contradiction.

The other terminal row is the proved whole-parent difference bound

    y_H-y_F <= 228339/131072 < 2.

The certificate gives each of these two rows weight one half. Every
variable coefficient cancels exactly, leaving

    0 <= -33805/262144.

The reserve is positive and no residual correction is required at the
terminal step. The machine-readable independent report is
`positive-b696531e6d132c9e_portable_replay.json` in this directory.

Reproduce from the extension root using standard-library Python:

    python verify_shared_bound.py --id positive-b696531e6d132c9e
