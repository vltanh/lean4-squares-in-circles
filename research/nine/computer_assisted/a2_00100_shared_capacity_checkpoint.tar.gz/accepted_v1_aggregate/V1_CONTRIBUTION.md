# Complete original cells proved by the shared inset and strip rule

This cumulative archive proves three unchanged original cells of mask
`001/00`. It introduces no new case splits. It does not assert that the
entire mask, any other mask, or a larger roadmap gate is closed.

| Original cell | Inherited coordinate deductions | New bound deductions | New rounds | Exact final reserve |
| --- | ---: | ---: | ---: | --- |
| `positive-033850931bb6d4ef` | 76 | 575 | 3 | `8929382507225583434487/1511157274518286468382720` |
| `positive-3cd9c2a7981effa2` | 76 | 580 | 3 | `8929382507225583434487/1511157274518286468382720` |
| `positive-b696531e6d132c9e` | 33 | 196 | 2 | `33805/262144` |

The exact independent replay checks 185 inherited and 1,351 new bound
deductions. Each deduction uses nonnegative rational multipliers of rows
valid before that round. A residual coefficient is paid using an inherited
absolute variable bound. Only then are the new bounds installed together.
Original frame intervals are narrowed using the physical unit-frame
identities, and the next round's geometric rows use only proved intervals.

## Shared geometric rule

Three disjoint original unit squares, with arbitrary independent
orientations, have centers ordered along one coordinate axis. If their
spread along the other axis is at most `W <= 7/10`, their endpoint span `V`
and endpoint transverse difference `Delta` obey

\[
 V+\frac5{14}\Delta^2\ge
 \min\!\left(2,\frac{208}{75}-\frac{29}{15}W\right).
\]

The supplied hand proof establishes this physical implication. A proved
interval `[a,b]` for `Delta` supplies the secant
`Delta^2 <= (a+b) Delta - ab`, giving the exact affine row used in the
certificates. Every order and width guard is reconstructed by the
independent replay. The additional inset separation rows and their
secants are also reconstructed independently.

For the first two original cells, a guarded strip containing `A,H,I`
contributes the last row of a seven-row contradiction. The archive includes
an optional exact positive dependence whose weighted coefficients vanish
identically; the original certificates retain their independently checked
dyadic multipliers and paid residuals.

For `positive-b696531e6d132c9e`, the proved strip width is zero:
`x_F = x_I = x_H` and `y_F <= y_I <= y_H`. Pairwise unit center distance
already gives `y_H-y_F >= 2` in this special case. A separately proved
bound gives

\[
 y_H-y_F\le\frac{228339}{131072}<2.
\]

Multiplying these two opposing affine rows by `1/2` gives the displayed
positive reserve `33805/262144`, with zero residual coefficients.

## Scope of the bounded discovery pass

The associated discovery pass started from the fixed 63 OPEN original
cells and allowed at most three new rounds per original. The resulting
summary records every original without changing the denominator or adding
descendants. An OPEN result is not an exclusion. The proof archive contains
only the three independently accepted complete certificates listed above.

Run `python verify_shared_bound.py --all` from this directory to replay
the complete proofs with Python's standard library. The verifier imports
neither the discovery producer nor a numerical optimizer. No Lean, Lake,
or CI execution is used.
