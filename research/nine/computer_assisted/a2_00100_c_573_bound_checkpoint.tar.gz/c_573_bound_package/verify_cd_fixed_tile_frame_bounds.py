#!/usr/bin/env python3
"""Independent affine induction in one fixed C/D I or HI rectangle.

Preserves every original predicate and every inherited Cartesian and diagonal
bound. Replays the frozen original ancestor and every exact deduction, using
only independent physical row reconstructors. OPEN records may export their
certified state, with no tile/original/mask closure credit.
"""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import importlib
import json
import sys
import time
from independent_empty_angle_terminal import verify as verify_empty_angle
from independent_fixed_bound_terminals import empty_interval_witness

HERE=Path(__file__).resolve().parent
DEFAULT_CONTEXT=Path('/workspace/scratch/fee12ff81cbd/d_a497_psd_package')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def box(values,allow_empty=False):
    result=tuple(tuple(map(F,ab))for ab in values)
    assert all(len(ab)==2 and(allow_empty or ab[0]<=ab[1])for ab in result)
    return result

def canonical(row,n):
    terms,rhs,name=row;co={}
    for k,v in terms:
        assert type(k)is int and 0<=k<n
        co[k]=co.get(k,F(0))+F(v)
    return tuple((k,v)for k,v in sorted(co.items())if v),F(rhs),name

class Checker:
    def __init__(self,context=DEFAULT_CONTEXT,ancestry=None,strict_root=None):
        self.context=Path(context).resolve()
        self.ancestry=Path(ancestry or self.context/'ancestry').resolve()
        sys.path.insert(0,str(self.context))
        from replay_context import install
        self.J,self.D,self.bound_locate=install(self.ancestry,strict_root)
        self.K=self.J.K;self.strict_root=strict_root
        self.ID=importlib.import_module('independent_diagonal_rows')
        self.IC=importlib.import_module('independent_correlated_capacity')
        self.A=importlib.import_module('verify_affine_cover')
        self.priors={}

    def locate(self,name):
        try:return self.bound_locate(name)
        except FileNotFoundError:
            # Local research replay may read a new producer file by its exact
            # recorded hash. Portable strict replay requires explicit bindings.
            path=Path(name)
            assert self.strict_root is None and path.is_absolute()and path.is_file()
            return path

    def view(self,state,diagonal):
        K=self.K
        return dict(angles=K.view(state['angles']),positions=K.view(state['positions']),
                    scalar=K.view(state['scalar']),differences=K.diffview(state['differences']),
                    diagonal=K.diffview(diagonal))

    def original_and_tile(self,record):
        K=self.K;prior=record['prior'];prefix=self.locate(prior['path'])
        assert digest(prefix)==prior['sha256']
        literal=json.loads(prefix.read_text())
        assert literal['schema']==prior['schema']=='correlated_diagonal_whole_parent_v1'
        assert literal['id']==record['id']and literal['path']==record['path']
        # A copied C618 path is an alias of the unchanged frozen original.
        # Replay the frozen bytes after proving identity, without weakening the
        # historical context's source-binding restrictions.
        frozen=self.ancestry/'cd_family/diagonal_results'/(record['id']+'.json')
        assert digest(frozen)==prior['sha256']
        key=(str(frozen),digest(frozen))
        if key not in self.priors:
            report,parent,diagonal=self.D.replay(frozen)
            assert report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
            self.priors[key]=(report,parent,diagonal)
        prior_report,parent,diagonal=self.priors[key]
        assert parent['id']==record['id']and parent['path']==record['path']
        tile=prior['tile'];assert isinstance(tile,list)and len(tile)in(2,4)
        assert prior['closed_cover_parts']==[4,4]+([2,4]if len(tile)==4 else[])
        pos=list(parent['positions'])
        for axis,index in enumerate(tile[:2]):
            assert type(index)is int and 0<=index<4
            lo,hi=parent['positions'][16+axis]
            pos[16+axis]=(lo+(hi-lo)*F(index,4),lo+(hi-lo)*F(index+1,4))
        assert prior['rectangle']==K.view(pos[16:18])
        if len(tile)==4:
            for axis,index,parts in((0,tile[2],2),(1,tile[3],4)):
                assert type(index)is int and 0<=index<parts
                lo,hi=parent['positions'][14+axis]
                pos[14+axis]=(lo+(hi-lo)*F(index,parts),lo+(hi-lo)*F(index+1,parts))
            assert prior['h_rectangle']==K.view(pos[14:16])
        else:assert prior['h_rectangle']is None
        return dict(parent,positions=tuple(pos)),dict(diagonal),prior_report

    def reconstruct(self,rr,state,diagonal,allow_empty_diagonal=False):
        K=self.K;assert rr['before']==self.view(state,diagonal)
        base,bounds,pos,scalar,diff,guards=K.rebuild(state['path'],state['angles'],state['positions'],
                                                  state['choices'],state['scalar'],state['differences'])
        gg=self.ID.intervals(diff,diagonal)
        assert rr['propagated_positions']==K.view(pos)
        assert rr['physical_scalar_intersection']==K.view(scalar)
        assert rr['effective_differences']==K.diffview(diff)
        assert rr['effective_diagonal']==K.diffview(gg)
        if not allow_empty_diagonal:assert all(a<=b for ds in gg.values()for a,b in ds)
        assert type(rr['rows'])is int and len(base)<=rr['rows']
        return base,bounds,pos,scalar,diff,gg

    def printed_rows(self,saved,total,base,bounds,scalar,diff,diagonal,angles):
        indices=[e['index']for e in saved]
        assert len(indices)==len(set(indices))and all(type(k)is int and 0<=k<total for k in indices)
        rows=list(base)
        rows.extend([((),F(0),'UNUSED_UNVERIFIED')]*max(0,max(indices,default=-1)+1-len(rows)))
        names=[]
        for entry in saved:
            k,name=entry['index'],entry['name']
            if k>=len(base):
                if name.startswith(('correlated_rotated_','correlated_diagonal_altitude_')):
                    row=self.IC.physical_row(name,diff,diagonal)
                elif name.startswith('correlated_'):
                    row=self.ID.physical_row(name,scalar,diff,diagonal)
                elif name.startswith('four_center_energy_'):
                    row=self.A.four_energy(name,diff,diagonal)
                elif name.startswith('square_area_moment_secant_'):
                    row=self.A.area_secant(name,diff)
                else:
                    row=self.J.rebuild_joint(name,scalar,diff,angles,self.J.point_row)
                rows[k]=row;names.append(name)
            assert canonical(rows[k],len(bounds))==canonical((entry['coefficients'],entry['rhs'],name),len(bounds)),name
        return rows,names

    def replay(self,filename,allow_open=False,return_state=False):
        start=time.monotonic();path=Path(filename).resolve();raw=path.read_bytes();record=json.loads(raw)
        filehash=hashlib.sha256(raw).hexdigest()
        assert record['schema']in('CD_fixed_tile_affine_bound_induction_discovery_v1','CD_fixed_tile_affine_bound_continuation_discovery_v1')
        assert record['scope']=='ONE_CLOSED_RECTANGLE_OF_DECLARED_COMPLETE_ORIGINAL_COVER'
        assert record['status']in('OPEN','CANDIDATE_CLOSED')and record['new_original_cells']==0
        continuation=record.get('continuation')
        if record['schema']=='CD_fixed_tile_affine_bound_continuation_discovery_v1':
            assert isinstance(continuation,dict)
            previous_path=self.locate(continuation['file'])
            assert digest(previous_path)==continuation['sha256']
            previous=json.loads(previous_path.read_text())
            assert previous['schema']=='CD_fixed_tile_affine_bound_induction_discovery_v1'
            assert previous['status']=='OPEN'and len(previous['rounds'])==3
            assert continuation['inherited_rounds']==3 and continuation['additional_round_budget']==3
            assert 3<=len(record['rounds'])<=6
            for key in('id','path','prior','scope','new_original_cells'):
                assert record[key]==previous[key]
            assert record['rounds'][:3]==previous['rounds']
            for name,h in previous['sources'].items():
                assert record['sources'][name]==h
            assert previous['final']==previous['rounds'][-1]['after']
            if len(record['rounds'])>3:
                assert record['rounds'][3]['before']==previous['final']
        else:
            assert continuation is None and len(record['rounds'])<=3
        for name,h in record['sources'].items():assert digest(self.locate(name))==h,('source_changed',name)
        state,diagonal,prior_report=self.original_and_tile(record)
        K=self.K;totalrows=0;deductions=0;newnames=[];stats=[];variable_counts=set()
        early_closed=False;terminal_evidence=None
        for ri,rr in enumerate(record['rounds']):
            assert rr['round']==ri
            base,bounds,pos,scalar,diff,gg=self.reconstruct(rr,state,diagonal)
            assert rr['absolute_variable_bounds']==list(map(str,bounds))
            rows,names=self.printed_rows(rr['printed_rows'],rr['rows'],base,bounds,scalar,diff,gg,state['angles'])
            newnames+=names;variable_counts.add(len(bounds))
            pp=[list(ab)for ab in pos];ss=[list(ab)for ab in scalar]
            dd={pair:[list(ab)for ab in ds]for pair,ds in diff.items()}
            dg={pair:[list(ab)for ab in ds]for pair,ds in gg.items()}
            used=set();objectives=set();counts=Counter()
            for p in rr['proposals']:
                kind,key,sign=p['kind'],p['key'],p['sign']
                assert type(sign)is int and sign in(-1,1)
                assert kind in('scalar','difference','diagonal');counts[kind]+=1
                if kind=='scalar':
                    assert type(key)is int and 0<=key<54 and p['objective']==[[key,sign]]
                    target=pp[key]if key<18 else ss[key-18]
                    old=pos[key]if key<18 else scalar[key-18]
                else:
                    assert isinstance(key,list)and len(key)==3 and all(type(k)is int for k in key)
                    i,j,axis=key;assert 0<=i<j<9 and axis in(0,1)
                    if kind=='difference':
                        assert p['objective']==[[2*j+axis,sign],[2*i+axis,-sign]]
                        target=dd[i,j][axis];old=diff[i,j][axis]
                    else:
                        sy=1 if axis==0 else-1
                        assert p['objective']==[[2*j,sign],[2*i,-sign],[2*j+1,sign*sy],[2*i+1,-sign*sy]]
                        target=dg[i,j][axis];old=gg[i,j][axis]
                objective=tuple(map(tuple,p['objective']));assert objective not in objectives
                objectives.add(objective)
                assert F(p['old'])==(old[1]if sign==1 else-old[0])
                upper=K.audit_bound(rows,bounds,p)
                if sign==1:target[1]=min(target[1],upper)
                else:target[0]=max(target[0],-upper)
                used.update(k for k,w in p['weights']);deductions+=1
            assert used=={e['index']for e in rr['printed_rows']};totalrows+=len(used)
            pos=box(pp);scalar=box(ss)
            diff={pair:box(ds)for pair,ds in dd.items()};diagonal={pair:box(ds)for pair,ds in dg.items()}
            if record.get('terminal',{}).get('kind')=='proved_empty_original_angle_interval'and ri==len(record['rounds'])-1:
                assert record['status']=='CANDIDATE_CLOSED'and 'after'not in rr
                terminal_evidence=verify_empty_angle(K,state['angles'],scalar,rr['physical_frame_inferences'])
                early_closed=True
                # The producer exits before updating the scalar/center/angle
                # state, but after updating its two local difference maps.
                expected_final=self.view(state,diagonal)
                expected_final['differences']=K.diffview(diff)
                assert record['final']==expected_final
                stats.append(dict(round=ri,printed_rows=len(used),**counts))
                break
            angles=K.angles_from_scalar(state['angles'],scalar,rr['physical_frame_inferences'])
            analytic=K.analytic(angles)
            intersection=tuple((max(lo,a),min(hi,b))for(lo,hi),(a,b)in zip(scalar,analytic))
            witness=empty_interval_witness(intersection,'empty_physical_frame',18)
            if witness is not None:
                assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='empty_physical_frame'
                assert ri==len(record['rounds'])-1 and 'after'not in rr
                index=witness['index']-18
                witness.update(certified_interval=list(map(str,scalar[index])),
                    analytic_interval=list(map(str,analytic[index])),
                    derived_slope_interval=list(map(str,angles[index%9])),checked_frame_inferences=9)
                terminal_evidence=witness;early_closed=True
                expected_final=self.view(state,diagonal)
                expected_final['differences']=K.diffview(diff)
                assert record['final']==expected_final
                stats.append(dict(round=ri,printed_rows=len(used),**counts))
                break
            scalar=box(intersection)
            state=dict(state,positions=pos,scalar=scalar,angles=angles,differences=diff)
            assert rr['after']==self.view(state,diagonal)
            stats.append(dict(round=ri,printed_rows=len(used),**counts))
            print(record['id'],'PASS FIXED-TILE DIAGONAL ROUND',stats[-1],flush=True)
        if not early_closed:assert record['final']==self.view(state,diagonal)
        reserve=None;terminal_rows=0
        if record['status']=='CANDIDATE_CLOSED'and not early_closed:
            terminal=record['terminal'];assert terminal['kind']=='positive_exact_reserve','Dedicated review required for a nonpositive-reserve terminal.'
            rr=terminal['state'];assert rr['round']==len(record['rounds'])
            base,bounds,pos,scalar,diff,gg=self.reconstruct(rr,state,diagonal)
            assert terminal['absolute_variable_bounds']==list(map(str,bounds))
            rows,names=self.printed_rows(terminal['printed_rows'],rr['rows'],base,bounds,scalar,diff,gg,state['angles'])
            newnames+=names;variable_counts.add(len(bounds))
            used={k for k,w in terminal['weights']};assert used=={e['index']for e in terminal['printed_rows']}
            co,rhs=K.sum_rows(rows,bounds,terminal['weights'])
            reserve=-rhs-sum(bound*abs(c)for bound,c in zip(bounds,co))
            assert reserve>0 and reserve==F(terminal['reserve'])
            assert terminal['weighted_rhs']==str(rhs)and terminal['weighted_coefficients']==list(map(str,co))
            terminal_rows=len(used);totalrows+=terminal_rows
        elif record['status']=='OPEN':assert allow_open,'Explicit --allow-open required for a state-only replay.'
        forbidden=('numpy','scipy','highspy','v3_whole_parent_pass','quadratic_moment_pilot',
                   'diagonal_rows','correlated_capacity_rows','four_center_rows','square_area_moment_rows')
        assert not any(name in sys.modules for name in forbidden)
        assert digest(path)==filehash,'The producer rewrote this record during replay.'
        prior=record['prior']
        report=dict(schema='independent_CD_frame_fixed_tile_affine_bound_replay_v1',id=record['id'],
            status='PASS_COMPLETE_PHYSICAL_TILE'if reserve is not None or early_closed else'PASS_CERTIFIED_TILE_STATE_OPEN',
            tile=prior['tile'],closed_cover_parts=prior['closed_cover_parts'],
            rectangle=prior['rectangle'],h_rectangle=prior['h_rectangle'],original_parent_path=record['path'],
            original_prefix_replay=prior_report,inherited_diagonals_retained=True,
            bound_rounds=len(stats),bound_deductions=deductions,round_reports=stats,
            original_variables=54,affine_variable_counts=sorted(variable_counts),
            printed_rows_checked=totalrows,terminal_rows=terminal_rows,reserve=str(reserve)if reserve is not None else None,
            terminal_kind=record.get('terminal',{}).get('kind'),terminal_evidence=terminal_evidence,
            early_exit_stale_final_fields_used_as_derived_state=False,
            independently_rebuilt_new_rule_counts=dict(Counter(name.split('_')[0]for name in newnames)),
            certificate_sha256=filehash,checker_sha256=digest(__file__),
            verified_producer_source_bindings=len(record['sources']),continuation_checked=continuation,
            unsupported_rules_accepted=False,numerical_producer_or_optimizer_imported=False,
            whole_parent_cover_checked=False,new_original_cells=0,new_masks=0,seconds=time.monotonic()-start)
        print(record['id'],'FIXED-TILE DIAGONAL BOUND REPLAY',report['status'],'rows',totalrows,flush=True)
        return(report,state,diagonal)if return_state else report

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('certificates',type=Path,nargs='+')
    ap.add_argument('--context',type=Path,default=DEFAULT_CONTEXT)
    ap.add_argument('--ancestry',type=Path)
    ap.add_argument('--strict-root',type=Path)
    ap.add_argument('--allow-open',action='store_true')
    ap.add_argument('--report',type=Path,required=True)
    a=ap.parse_args();checker=Checker(a.context,a.ancestry,a.strict_root)
    results=[checker.replay(path,a.allow_open)for path in a.certificates]
    keys=[(r['id'],tuple(r['tile']))for r in results];assert len(keys)==len(set(keys))
    report=dict(schema='independent_CD_frame_fixed_tile_affine_bound_batch_v1',
        status='PASS_ALL_LISTED_PHYSICAL_TILES'if all(r['status']=='PASS_COMPLETE_PHYSICAL_TILE'for r in results)else'PASS_LISTED_BOUND_STATES',
        tiles=len(results),bound_deductions=sum(r['bound_deductions']for r in results),
        printed_rows_checked=sum(r['printed_rows_checked']for r in results),tile_reports=results,
        whole_parent_cover_checked=False,new_original_cells=0,new_masks=0)
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='tile_reports'},indent=2))

if __name__=='__main__':main()
