#!/usr/bin/env python3
"""Complete independent exact assembly of the original C573 I-center cover."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import argparse,hashlib,json,sys,time

HERE=Path(__file__).resolve().parent
IDENT='negative-573078fc944ce553'
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    assert __debug__, 'Assertions are required for exact replay.'
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allow-partial',action='store_true')
    args=parser.parse_args();start=time.monotonic()
    manifest=json.loads((HERE/'SHA256_MANIFEST.json').read_text())
    for name,value in manifest['files'].items():
        target=(HERE/name).resolve()
        assert target.is_relative_to(HERE)
        assert digest(target)==value,name
    from verify_cd_fixed_tile_frame_bounds import Checker
    checker=Checker(context=HERE,ancestry=HERE/'ancestry',strict_root=HERE)
    import verify_affine_cover as A
    prefix=HERE/'ancestry/cd_family/diagonal_results'/(IDENT+'.json')
    prior,parent,diagonal=checker.D.replay(prefix)
    assert prior['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'and parent['id']==IDENT
    register=json.loads((HERE/'INPUT_FIXED_FRONTIER.json').read_text())
    assert len(register['cells'])==231
    original=next(c for c in register['cells']if c['id']==IDENT)
    assert original['status']=='OPEN'and original['path']==parent['path']
    terminal_reports=[];remaining=[];bound_reports=[];raw_error_checks=[]
    for tile in product(range(4),repeat=2):
        path=HERE/'data/fixed_I_grid'/(IDENT+'_'+'_'.join(map(str,tile))+'.json')
        record=json.loads(path.read_text())
        assert record['id']==IDENT and record['tile']==list(tile)
        assert record['prior']['sha256']==digest(prefix)
        assert digest(checker.locate(record['prior']['path']))==digest(prefix)
        if record['status']=='CANDIDATE_CLOSED':
            report=A.verify_tile(record,parent,diagonal,checker.J)
            report['method']='direct_'+report['kind'];report['source_sha256']=digest(path)
            if 'raw_error_record'in record:
                raw=HERE/'data/raw_errors'/Path(record['raw_error_record']).name
                assert digest(raw)==record['raw_error_sha256']
                unaccepted=json.loads(raw.read_text())
                assert unaccepted['id']==IDENT and unaccepted['tile']==list(tile)
                assert unaccepted['status']=='OPEN'and unaccepted.get('error')
                assert digest(checker.locate(record['continuation_source']))==record['continuation_source_sha256']
                raw_error_checks.append(dict(tile=list(tile),preserved_raw_error_sha256=digest(raw),
                                             exact_interval_reconstructed_independently=True))
            terminal_reports.append(report)
        else:
            assert record['status']=='OPEN'
            bound=HERE/'data/bounds'/('I_'+'_'.join(map(str,tile))+'.json')
            if not bound.exists():
                assert args.allow_partial,('Missing complete tile proof',tile)
                remaining.append(list(tile));continue
            report=checker.replay(bound)
            assert report['status']=='PASS_COMPLETE_PHYSICAL_TILE'
            assert report['id']==IDENT and report['tile']==list(tile)
            assert report['original_parent_path']==parent['path']
            assert report['original_prefix_replay']['certificate_sha256']==prior['certificate_sha256']==digest(prefix)
            bound_record=json.loads(bound.read_text())
            assert bound_record['prior']['sha256']==digest(prefix)
            assert bound_record['prior']['closed_cover_parts']==[4,4]
            kind=report['terminal_kind']
            assert kind in ('positive_exact_reserve','proved_empty_original_angle_interval','empty_physical_frame')
            if kind=='positive_exact_reserve':
                assert F(report['reserve'])>0
                method='affine_after_bound_induction'
            else:
                assert report['reserve'] is None and report['terminal_evidence']
                assert report['terminal_rows']==0
                method='empty_original_frame_after_bound_induction'
            bound_reports.append(report)
            terminal_reports.append(dict(tile=list(tile),kind=kind,method=method,
                                         rows=report['terminal_rows'],reserve=report['reserve'],source_sha256=digest(bound)))
        print(IDENT,'VERIFIED CLOSED I RECTANGLE',tile,flush=True)
    assert len(terminal_reports)+len(remaining)==16
    assert len({tuple(t['tile'])for t in terminal_reports})==len(terminal_reports)
    assert not any(name in sys.modules for name in('numpy','scipy','highspy','quadratic_moment_pilot','v3_whole_parent_pass',
        'cd_tile_affine_bounds','cd_tile_affine_continue','four_center_rows','square_area_moment_rows'))
    module_audit={}
    for name,module in sorted(sys.modules.items()):
        origin=getattr(module,'__file__',None)
        if origin:
            origin=Path(origin).resolve()
            if origin.is_relative_to('/workspace'):
                assert origin.is_relative_to(HERE),('External workspace module',name,str(origin))
                module_audit[name]=str(origin.relative_to(HERE))
    complete=not remaining
    result=dict(schema='complete_C573_fixed_I_affine_bound_cover_v1',id=IDENT,path=parent['path'],
        status='PASS_COMPLETE_ORIGINAL_PARENT'if complete else'PASS_PARTIAL_COVER_WITH_EXPLICIT_REMAINDER',
        original_physical_squares=9,original_corners=36,original_pairs=36,
        strict_CD_original_path_retained=True,closed_cover_parts=[4,4],
        original_I_rectangle=checker.K.view(parent['positions'][16:18]),
        cover_rectangles=16,proved_rectangles=len(terminal_reports),remaining_rectangles=remaining,
        terminal_reports=terminal_reports,bound_reports=bound_reports,original_prefix_replay=prior,
        terminal_rows=sum(r['rows']for r in terminal_reports),
        direct_affine_terminals=sum(r['method']=='direct_positive_exact_reserve'for r in terminal_reports),
        direct_interval_terminals=sum(r['method']=='direct_exact_interval'for r in terminal_reports),
        bound_affine_terminals=sum(r['method']=='affine_after_bound_induction'for r in terminal_reports),
        bound_frame_terminals=sum(r['method']=='empty_original_frame_after_bound_induction'for r in terminal_reports),
        bound_terminals=len(bound_reports),bound_induction_rounds=sum(r['bound_rounds']for r in bound_reports),
        bound_induction_deductions=sum(r['bound_deductions']for r in bound_reports),
        bound_induction_rows=sum(r['printed_rows_checked']-r['terminal_rows']for r in bound_reports),
        preserved_raw_error_checks=raw_error_checks,source_manifest_sha256=digest(HERE/'SHA256_MANIFEST.json'),
        all_workspace_reads_confined_to_packet=True,local_module_import_audit=module_audit,
        numerical_producer_or_optimizer_imported=False,
        new_original_cells=int(complete),new_masks=0,whole_mask_closed=False,lean_lake_ci_run=False,
        seconds=time.monotonic()-start)
    name='COMPLETE_REPLAY.json'if complete else'PARTIAL_REPLAY.json'
    (HERE/name).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k]for k in('id','status','proved_rectangles','remaining_rectangles','terminal_rows','bound_induction_deductions','new_original_cells','seconds')}),flush=True)

if __name__=='__main__':main()
