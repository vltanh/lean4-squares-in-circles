# Complete existing inward-row child 8

This standalone packet proves both unchanged original A cells
positive-2dcf3464c0e0dafb and positive-3bf14a18887cabaf. Each has a complete
six-round exact physical bound induction and a 22-row positive terminal.
The two use the same smaller integer-weight terminal table. All nine
originals, their physical frames, corners, pair constraints, marked cones,
and strict original bits are retained. No additional case split is made.

Run Python with its standard library after extraction:

    python inward_child8_checkpoint/verify_all.py

The original arithmetic and physical row checkers are byte-identical to
the accepted original-center packet. The wrapper checks source bindings,
replays both inductions and their complete terminals, verifies the shared
small-weight table independently, and checks the exact 26-original prefix
map against the unchanged 193/38 input register. Its other 24 registered
originals were already closed; accepted baseline terminal descendants are
retained. Thus the existing inward-row child 8 is complete. Other inward
children, the A family, and the whole mask remain separate obligations.

Each original had a prior five-round OPEN state. One additional round
closed each entire parent. Those earlier states and their hashes are
preserved for provenance. They are not assumed: every bound from the
original path is replayed afresh, using 81 prior coordinate deductions,
2,109 further deductions and 3,339 checked printed rows in total.

No Lean, Lake, CI, human proof review, proof-kernel verification, or new
whole-mask closure is claimed. The baseline original_register.json is the
frozen 174/57 register required by the unchanged mathematical checker;
input_current_register.json records the later 193/38 accounting baseline.
Discovery sources are retained as hashed provenance and are not imported
by the independent exact replay. Output goes only into new_reviews/.
