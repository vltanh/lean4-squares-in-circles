#!/usr/bin/env python3
"""Portable exact verification of both unchanged inward-child-8 originals."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
HERE=Path(__file__).resolve().parent
IDS=['positive-2dcf3464c0e0dafb','positive-3bf14a18887cabaf']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def file(name):
 p=Path(name);assert not p.is_absolute()and '..'not in p.parts
 f=HERE/p;assert f.is_file()and f.resolve().is_relative_to(HERE);return f
def read(name):return json.loads(file(name).read_text())
def main():
 assert __debug__,'Exact checks require assertions enabled.'
 frozen=read('SHA256_MANIFEST.json');assert frozen['schema']=='n9_inward_child8_immutable_files_v1'
 for name,h in frozen['files'].items():assert sha(file(name))==h,('changed_file',name)
 index=read('portfolio_index.json');assert index['schema']=='n9_inward_child8_portfolio_v1'
 assert index['target_mask']=='001/00'and index['strict_q']=='1105/256'and index['whole_masks']=={'closed':8,'open':24}
 old=read('original_register.json');cur=read('input_current_register.json')
 assert sha(file('original_register.json'))==index['original_register_sha256']and sha(file('input_current_register.json'))==index['input_current_register_sha256']
 assert len(old['cells'])==len(cur['cells'])==231
 oldmap={c['id']:c for c in old['cells']};curmap={c['id']:c for c in cur['cells']};assert set(oldmap)==set(curmap)
 for ident in oldmap:assert oldmap[ident]['path']==curmap[ident]['path']
 assert all(curmap[i]['status']=='OPEN'and oldmap[i]['status']=='OPEN'for i in IDS)
 assert sum(c['status']=='CLOSED'for c in cur['cells'])==193 and sum(c['status']=='OPEN'for c in cur['cells'])==38
 assert index['before']=={'closed':193,'open':38}and index['after']=={'closed':195,'open':36}
 assert sha(file('input_checkpoint_manifest.json'))==index['input_checkpoint_manifest_sha256']
 checkpoint=read('input_checkpoint_manifest.json');assert checkpoint['after']==index['before']and checkpoint['status']=='PASS_ALL_COMPLETE_ORIGINAL_PARENTS'
 assert [e['id']for e in index['entries']]==IDS
 bindings=read('source_bindings.json');expected_bindings={};reports=[]
 from verify_joint_original import replay
 for e in index['entries']:
  ident=e['id'];record=read(e['certificate']);assert sha(file(e['certificate']))==e['certificate_sha256']
  assert e['checker']=='verify_joint_original.py'and sha(file(e['checker']))==e['checker_sha256']
  assert record['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and record['new_branch_nodes']==0 and record['path']==curmap[ident]['path']
  assert record['status']=='CANDIDATE_CLOSED'and len(record['rounds'])==6 and record['terminal']['kind']=='positive_exact_reserve'
  src=read(e['inherited_open_state']);assert sha(file(e['inherited_open_state']))==e['inherited_open_state_sha256']==record['continuation']['sha256']
  assert src['status']=='OPEN'and len(src['rounds'])==5 and src['rounds']==record['rounds'][:5]
  sources=dict(record['sources']);sources.update(record.get('additional_sources',{}))
  for name,h in sources.items():
   assert name in bindings and sha(file(bindings[name]))==h
   assert name not in expected_bindings or expected_bindings[name]==h;expected_bindings[name]=h
  prior=record['prior'];assert prior['file']in bindings and sha(file(bindings[prior['file']]))==prior['sha256'];expected_bindings[prior['file']]=prior['sha256']
  result=replay(file(e['certificate']))
  assert result['status']=='PASS_COMPLETE_ORIGINAL_PARENT'and result['whole_original_parent_closed']and result['bound_induction_branch_nodes']==0 and result['center_cover']is None
  for key in ['prior_coordinate_deductions','printed_rows_checked','terminal_rows','rounds']:assert result[key]==e[key]
  assert result['new_deductions']==e['new_exact_deductions']and result['certificate_sha256']==e['certificate_sha256']and Q(result['reserve'])>Q(7,1000)
  accepted=read(e['accepted_report']);assert sha(file(e['accepted_report']))==e['accepted_report_sha256']
  for key in ['status','id','certificate_sha256','prior_coordinate_deductions','new_deductions','printed_rows_checked','terminal_rows','reserve']:assert accepted[key]==result[key]
  reports.append(result)
 assert set(bindings)==set(expected_bindings)
 shared=read('shared_terminal.json');assert shared['ids']==IDS and shared['weight_denominator']==65536
 shared_reports=[]
 for n,e in enumerate(index['entries']):
  terminal=read(e['certificate'])['terminal'];weights=shared['weight_numerators'];assert len(weights)==len(terminal['weights'])==22 and all(type(x)is int and x>0 for x in weights)
  printed={r['index']:r for r in terminal['rows']};co=[Q(0)]*54;rhs=Q(0)
  for (k,_),w in zip(terminal['weights'],weights):
   row=printed[k];lam=Q(w,65536);rhs+=lam*Q(row['rhs'])
   for j,c in row['coefficients']:co[j]+=lam*Q(c)
  residual=sum(abs(c)*Q(m)for c,m in zip(co,terminal['absolute_variable_bounds']));reserve=-rhs-residual
  assert reserve==Q(shared['reserves'][n])and reserve>Q(1,200)
  shared_reports.append({'id':e['id'],'rows':22,'rhs':str(rhs),'residual_correction':str(residual),'reserve':str(reserve),'weight_denominator':65536,'weight_numerators':weights,'weighted_coefficients':list(map(str,co))})
 scope=read(index['scope_file']);prefix=scope['prefix'];children=[c for c in cur['cells']if c['path'][:len(prefix)]==prefix]
 assert prefix==[['angle',3,1],['angle_cut',[0,'0'],0],['inward_row_escape',[7,8],[8]]]
 assert len(children)==scope['original_count']==index['existing_prefix_original_count']==26
 assert [c['id']for c in children]==scope['original_ids']and [c['status']for c in children]==scope['input_statuses']
 assert [c['id']for c in children if c['status']=='OPEN']==scope['newly_closed_originals']==IDS
 assert len([c for c in children if c['status']=='CLOSED'])==24 and scope['retained_accepted_baseline_terminal_descendants']is True
 out=HERE/'new_reviews';out.mkdir(exist_ok=True)
 (out/'shared_terminal_replay.json').write_text(json.dumps({'status':'PASS_SHARED_EXACT_TERMINALS','reports':shared_reports},indent=2)+'\n')
 totals={'prior_coordinate_deductions':sum(r['prior_coordinate_deductions']for r in reports),'new_exact_deductions':sum(r['new_deductions']for r in reports),'printed_rows_checked':sum(r['printed_rows_checked']for r in reports),'complete_terminal_domains':2,'new_internal_case_splits':0}
 assert totals=={'prior_coordinate_deductions':81,'new_exact_deductions':2109,'printed_rows_checked':3339,'complete_terminal_domains':2,'new_internal_case_splits':0}
 summary={'status':'PASS_ALL_COMPLETE_ORIGINAL_PARENTS','complete_original_ids':IDS,'complete_original_count':2,'before':index['before'],'after':index['after'],'whole_masks':index['whole_masks'],'totals':totals,'existing_prefix':prefix,'existing_prefix_original_count':26,'completed_existing_domains':1,'whole_mask_closed':False,'lean_lake_ci_run':False,'independent_checker_unchanged':True}
 (out/'portable_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
