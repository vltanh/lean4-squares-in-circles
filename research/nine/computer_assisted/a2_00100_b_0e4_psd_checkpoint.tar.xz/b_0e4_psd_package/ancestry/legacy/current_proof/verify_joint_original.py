#!/usr/bin/env python3
"""Independent arithmetic/state replay of whole-original v1 candidates.

Imports only accepted portable v4 geometry/replay. It does NOT import the
new producer, point-disk generator or altitude generator. Every newly used
point-disk row is rebuilt independently from its physical rule parameters.
Unused appended rows are irrelevant to a nonnegative weighted certificate.
New altitude rows are rejected unless separately implemented/reviewed.
"""
import sys,json,hashlib,time
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent
from independent_all_rules import rebuild as rebuild_joint
BUNDLE=HERE/'shared_capacity_three_b_v4'
sys.path.insert(0,str(BUNDLE))
import verify_shared_bound as K
REG=HERE/'original_register.json'
BINDINGS=json.loads((HERE/'source_bindings.json').read_text())if(HERE/'source_bindings.json').exists()else{}
def local_source(name):return HERE/BINDINGS[name]if name in BINDINGS else Path(name)

def box(values):return tuple(tuple(Q(x)for x in ab)for ab in values)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def point_row(name,scalar,diffs):
    parts=name.split('_');assert parts[:3]==['original','point','incircle']and len(parts)==10
    i,j,owner=map(int,parts[3:6]);s,t=map(Q,parts[6:8]);ap,bp=map(int,parts[8:])
    assert 0<=i<j<9 and owner in(i,j) and ap in(0,1) and bp in(0,1)
    assert -1<=s<=1 and -1<=t<=1
    x,y=diffs[i,j]
    def scaled(c,ab):
        p,q=(c*ab[0],c*ab[1]);return min(p,q),max(p,q)
    def linear(p,q):
        u,v=scaled(p,x),scaled(q,y);return u[0]+v[0],u[1]+v[1]
    p=linear(s,t);z=linear(-t,s)
    aa=scalar[owner][ap];bb=scalar[9+owner][bp]
    # Lower planes for alpha*(s dx+t dy), beta*(-t dx+s dy).
    # Build lhs as lower-product planes minus upper distance-square secants.
    coeff={2*i:Q(0),2*j:Q(0),2*i+1:Q(0),2*j+1:Q(0),18+owner:p[ap],27+owner:z[bp]}
    for ax,pc,qc in ((0,s,-t),(1,t,s)):
        v=aa*pc+bb*qc-sum(diffs[i,j][ax])
        coeff[2*j+ax]+=v;coeff[2*i+ax]-=v
    rhs=(s*s+t*t-1)/4-x[0]*x[1]-y[0]*y[1]+aa*p[ap]+bb*z[bp]
    return tuple((k,v)for k,v in sorted(coeff.items())if v),rhs,name

def rows_for_record(saved,oldrows,scalar,diffs,angles):
    # Each used index has exactly one printed physical row; arbitrary other
    # rows cannot contribute to the checked positive linear combination.
    indices=[x['index']for x in saved['printed_rows']];assert len(indices)==len(set(indices))
    maxindex=max(indices,default=-1);rows=list(oldrows)
    if len(rows)<=maxindex:rows += [((),Q(0),'UNUSED_UNVERIFIED')]*(maxindex+1-len(rows))
    newrules=[]
    for x in saved['printed_rows']:
        k=x['index'];assert type(k)is int and 0<=k<saved['rows']
        if k>=len(oldrows):
            rows[k]=rebuild_joint(x['name'],scalar,diffs,angles,point_row);newrules.append(x['name'])
        co,r,name=rows[k]
        assert name==x['name']and Q(x['rhs'])==r
        assert [(i,Q(v))for i,v in x['coefficients']if Q(v)]==[(i,v)for i,v in co if v], (x['name'],x['coefficients'],co)
    return rows,newrules

def replay(path,cover_path=None,allow_open=False,return_state=False):
    started=time.monotonic();K.verify_index();path=Path(path);record=json.loads(path.read_text());ident=record['id']
    assert record['schema']in('b_macro_joint_frame_pointdisk_sharp_capacity_v2','whole_parent_altitude_pointdisk_capacity_v1','whole_parent_sharp_altitude_support_frame_pointdisk_v3')
    assert record['status']in('OPEN','CANDIDATE_CLOSED')and record['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and record['new_branch_nodes']==0
    cell=next(c for c in json.loads(REG.read_text())['cells']if c['id']==ident)
    assert cell['status']=='OPEN'and cell['path']==record['path']
    assert ident.split('-')[1]==hashlib.sha256(json.dumps(record['path'],separators=(',',':')).encode()).hexdigest()[:16]
    sources=dict(record['sources'])
    for p,h in record.get('additional_sources',{}).items():
        assert p not in sources or sources[p]==h; sources[p]=h
    for p,h in sources.items():assert digest(local_source(p))==h,('source_changed',p)
    angles,pos,choices=K.V.reconstruct(record['path']);angles=tuple(map(tuple,angles));pos=tuple(map(tuple,pos))
    if record['prior']['kind']=='fresh_replayed_coordinate_prefix':
        prior=local_source(record['prior']['file']);assert digest(prior)==record['prior']['sha256']
        pos,count=K.coordinate_prior(json.loads(prior.read_text()),record['path'],angles,pos,choices);assert count==record['prior']['deductions']
    else:
        assert record['prior']['kind']=='original_path_only'and record['prior']['deductions']==0
        prior=None;count=0
    scalar=K.analytic(angles);difference={};newcount=0;usednew=[];printed=0
    for ri,rr in enumerate(record['rounds']):
        assert rr['round']==ri and box(rr['angles_before'])==angles and box(rr['positions_before'])==pos and box(rr['scalar_before'])==scalar
        assert rr['differences_before']==K.diffview(difference)
        base,bounds,prop,phys,diffs,guards=K.rebuild(record['path'],angles,pos,choices,scalar,difference)
        assert box(rr['propagated_positions'])==prop and box(rr['physical_scalar_intersection'])==phys and rr['effective_differences']==K.diffview(diffs)
        assert rr['three_square_guards'][:len(guards)]==guards
        assert list(map(str,bounds))==rr['absolute_variable_bounds']
        rows,names=rows_for_record(rr,base,phys,diffs,angles);usednew+=names
        newpos=[list(z)for z in prop];newscalar=[list(z)for z in phys];newdiff={p:[list(z)for z in ds]for p,ds in diffs.items()};used=set()
        for p in rr['proposals']:
            up=K.audit_bound(rows,bounds,p);sg=p['sign'];key=p['key'];assert sg in(-1,1)
            if p['kind']=='scalar':
                assert type(key)is int and 0<=key<54 and p['objective']==[[key,sg]]
                target=newpos[key]if key<18 else newscalar[key-18]
            else:
                assert p['kind']=='difference'and len(key)==3;i,j,ax=key;assert 0<=i<j<9 and ax in(0,1)
                assert p['objective']==[[2*j+ax,sg],[2*i+ax,-sg]];target=newdiff[i,j][ax]
            if sg==1:target[1]=min(target[1],up)
            else:target[0]=max(target[0],-up)
            used.update(i for i,w in p['weights']);newcount+=1
        assert used=={x['index']for x in rr['printed_rows']};printed+=len(used)
        pos=tuple(map(tuple,newpos));scalar=tuple(map(tuple,newscalar));difference={p:tuple(map(tuple,ds))for p,ds in newdiff.items()}
        assert all(a<=b for a,b in pos+scalar)and all(a<=b for ds in difference.values()for a,b in ds)
        angles=K.angles_from_scalar(angles,scalar,rr['physical_frame_inferences'])
        physical=K.analytic(angles);scalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(scalar,physical));assert all(a<=b for a,b in scalar)
        assert box(rr['angles_after'])==angles and box(rr['positions_after'])==pos and box(rr['scalar_after'])==scalar and rr['differences_after']==K.diffview(difference)
        print(ident,'PASS ROUND',ri,len(rr['proposals']),flush=True)
    reserve=None;terminal_rows=0;cover_report=None
    if record['status']=='CANDIDATE_CLOSED':
        terminal=record['terminal'];assert terminal['kind']=='positive_exact_reserve';rr=terminal['state']
        assert rr['round']==len(record['rounds']) and box(rr['angles_before'])==angles and box(rr['positions_before'])==pos and box(rr['scalar_before'])==scalar and rr['differences_before']==K.diffview(difference)
        base,bounds,prop,phys,diffs,guards=K.rebuild(record['path'],angles,pos,choices,scalar,difference)
        assert box(rr['propagated_positions'])==prop and box(rr['physical_scalar_intersection'])==phys and rr['effective_differences']==K.diffview(diffs) and rr['three_square_guards'][:len(guards)]==guards
        terminalview=dict(rr,printed_rows=terminal['rows']);rows,names=rows_for_record(terminalview,base,phys,diffs,angles);usednew+=names
        used={k for k,w in terminal['weights']};assert used=={x['index']for x in terminal['rows']}
        co,rhs=K.sum_rows(rows,bounds,terminal['weights']);reserve=-rhs-sum(m*abs(v)for m,v in zip(bounds,co))
        assert reserve>0 and reserve==Q(terminal['reserve'])and co==list(map(Q,terminal['weighted_coefficients']))and rhs==Q(terminal['weighted_rhs'])
        assert list(map(str,bounds))==terminal['absolute_variable_bounds'];printed+=len(used)
        terminal_rows=len(used)
    else:
        assert cover_path is not None or allow_open,'An OPEN bound-state record needs a complete center cover for closure.'
    assert box(record['final_angles'])==angles and box(record['final_positions'])==pos and box(record['final_scalar'])==scalar and record['final_differences']==K.diffview(difference)
    if cover_path is not None:
        from verify_original_center_cover import verify as verify_cover
        cover_report=verify_cover(cover_path,path)
        assert cover_report['status']=='PASS_COMPLETE_ORIGINAL_CENTER_COVER'
    complete=record['status']=='CANDIDATE_CLOSED'or cover_report is not None
    report={'id':ident,'status':'PASS_COMPLETE_ORIGINAL_PARENT'if complete else'PASS_CERTIFIED_PARENT_STATE_OPEN','whole_original_parent_closed':complete,'bound_induction_branch_nodes':0,
        'prior_coordinate_deductions':count,'new_deductions':newcount,'rounds':len(record['rounds']),
        'printed_rows_checked':printed,'terminal_rows':terminal_rows,'reserve':str(reserve),
        'center_cover':cover_report,'independently_rebuilt_new_rules':usednew,'unsupported_rules_accepted':False,
        'certificate_sha256':digest(path),'reviewer_sha256':digest(__file__),
        'independent_rules_sha256':digest(HERE/'independent_all_rules.py'),'verified_source_bindings':len(sources),
        'seconds':time.monotonic()-started,'whole_mask_closed':False,'human_or_kernel_verification':False}
    (HERE/'new_reviews').mkdir(exist_ok=True);(HERE/'new_reviews'/(ident+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='independently_rebuilt_new_rules'}),flush=True)
    state={'id':ident,'path':record['path'],'angles':angles,'positions':pos,'scalar':scalar,'choices':choices,'differences':difference}
    return (report,state)if return_state else report
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('certificate');ap.add_argument('cover',nargs='?');ap.add_argument('--state-only',action='store_true');a=ap.parse_args()
    replay(a.certificate,a.cover,allow_open=a.state_only)
