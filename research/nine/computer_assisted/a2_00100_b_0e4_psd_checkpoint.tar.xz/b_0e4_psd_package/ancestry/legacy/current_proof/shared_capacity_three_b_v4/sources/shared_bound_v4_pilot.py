#!/usr/bin/env python3
"""Separate bounded whole-parent pilot using rotated capacity and forced norm gaps."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,argparse,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/scratch/2281714110bb/nonlinear_geometry/bound_macro')
import shared_bound_induction as M
sys.path.insert(0,'/workspace/scratch/f694a78df3e7/sharp_frame')
import owner_free_relative_support as S
sys.path.insert(0,str(HERE/'v4_snapshot'))
import rotated_three_square_rows as T
import forced_distance_gap_rows as G
OLD_COLLECT=M.collect

def collect(state,differences):
    rows,absolute,terminal,positions,scalar,dr,guards=OLD_COLLECT(state,differences)
    if not terminal:
        rows+=S.interval_radius_rows(positions,state['angles'],differences=dr)
        extra,g=T.rotated_three_square_rows(dr);rows+=extra
        guards += [dict(extension_rule='rational_rotated_strip',**x) for x in g]
        radii={(i,j):S.support_radius_lower(state['angles'][i],state['angles'][j]) for i,j in dr}
        extra,g=G.gap_rows(dr,T.DIRECTIONS,radii);rows+=extra
        guards += [dict(extension_rule='forced_distance_gap',**x) for x in g]
    return rows,absolute,terminal,positions,scalar,dr,guards

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--rounds',type=int,default=6)
    a=ap.parse_args();assert 0<=a.rounds<=8
    out=HERE/'v4_pilot';out.mkdir(exist_ok=True)
    if (out/'results'/(a.id+'.json')).exists():raise RuntimeError('refusing overwrite')
    M.collect=collect;M.HERE=out;M.VERSION='shared_inset_rotated_strip_ordered_gap_induction_v4_pilot'
    cell=next(x for x in json.loads(M.REG.read_text())['cells'] if x['id']==a.id)
    assert cell['status']=='OPEN'
    r=M.run(cell,a.rounds)
    p=out/'results'/(a.id+'.json');record=json.loads(p.read_text())
    record['additional_sources']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()
       for q in map(Path,(__file__,S.__file__,T.__file__,G.__file__))}
    record['independent_review_status']='PENDING_NOT_ACCEPTED'
    p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(r),flush=True)
if __name__=='__main__':main()
