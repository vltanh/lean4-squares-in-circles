"""Exact nonbranching Euclidean gap consequences on proved differences.

Every pair of physical unit squares has center distance at least one.
The optional r>=1 bound is the separately proved relative-frame radius.
If |e.d|<=w<r and f.d>=0 in a rational orthonormal frame, then
f.d >= sqrt(r*r-w*w).  A rational lower square root gives a valid row.
"""
from fractions import Fraction as F
from itertools import combinations
from math import isqrt

def scale(c,ab):
    a,b=ab
    return (c*a,c*b) if c>=0 else (c*b,c*a)

def lower_root(q,bits=32):
    q=F(q);assert q>=0
    d=1<<bits;n=isqrt((q.numerator*d*d)//q.denominator)
    assert F(n,d)**2<=q<F(n+1,d)**2
    return F(n,d)

def gap_rows(differences,directions,radii=None):
    rows=[];guards=[]
    for i,j in combinations(range(9),2):
        box=[tuple(map(F,b)) for b in differences[(i,j)]]
        radius=F(1) if radii is None else F(radii[(i,j)])
        assert radius>=1
        for e in directions:
            e=tuple(map(F,e));f=(-e[1],e[0]);assert sum(x*x for x in e)==1
            def project(d):
                (a,b),(c,d)=scale(d[0],box[0]),scale(d[1],box[1])
                return a+c,b+d
            trans=project(e);long=project(f);w=max(map(abs,trans))
            if w>=radius:continue
            signs=[]
            q=radius*radius-w*w;bound=lower_root(q)
            # The strict comparison excludes the opposite closed magnitude
            # alternative. Equality never silently chooses a sign.
            if long[0]>-bound:signs.append(1)
            if long[1]<bound:signs.append(-1)
            for sg in signs:
                co={2*i:sg*f[0],2*i+1:sg*f[1],2*j:-sg*f[0],2*j+1:-sg*f[1]}
                name=f'ordered_euclidean_gap_{i}_{j}_{e[0]}_{e[1]}_{sg}'
                rows.append((tuple((k,v) for k,v in sorted(co.items()) if v),-bound,name))
                guards.append({'name':name,'pair':[i,j],
                    'transverse_direction':list(map(str,e)),
                    'longitudinal_direction':list(map(str,f)),
                    'transverse_interval':list(map(str,trans)),
                    'longitudinal_interval':list(map(str,long)),
                    'radius_lower':str(radius),'width_upper':str(w),
                    'sign_guard':'lower > -L' if sg==1 else 'upper < L',
                    'longitudinal_sign':sg,'squared_gap_lower':str(q),
                    'rational_gap_lower':str(bound)})
    return rows,guards
