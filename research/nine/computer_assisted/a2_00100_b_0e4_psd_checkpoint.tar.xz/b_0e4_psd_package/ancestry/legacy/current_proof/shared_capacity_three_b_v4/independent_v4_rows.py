"""Independent exact reconstruction of the three added v4 row families.

This implementation imports no discovery source or new-row generator.
Projections are independently formed by evaluating box vertices. Every
support radius and root enclosure is checked over exact rational numbers.
"""
from fractions import Fraction as Q
from itertools import combinations, permutations, product
from math import isqrt

THEOREM = 'three_original_strip_V_plus_5_over_14_Delta_squared_v1'


def view(xs):
    return [str(x) for x in xs]


def root_bounds(value, bits):
    value = Q(value)
    assert value >= 0
    scale = 2**bits
    n = isqrt(value.numerator * scale**2 // value.denominator)
    lo = Q(n, scale)
    hi = lo if lo*lo == value else Q(n+1, scale)
    assert lo*lo <= value <= hi*hi
    assert Q(n+1, scale)**2 > value
    return lo, hi


def directions():
    answer = [(Q(1), Q(0)), (Q(0), Q(1))]
    for a, b, h in ((3,4,5), (5,12,13), (8,15,17),
                    (7,24,25), (20,21,29), (9,40,41)):
        assert a*a+b*b == h*h
        for x, y in ((a,b), (b,a)):
            answer += [(Q(x,h), Q(-y,h)), (Q(x,h), Q(y,h))]
    assert len(answer) == len(set(answer)) == 26
    assert all(x*x+y*y == 1 for x,y in answer)
    return answer


def projection(boxes, i, j, direction):
    x, y = boxes[(min(i,j), max(i,j))]
    values = [direction[0]*u+direction[1]*v for u,v in product(x,y)]
    lo, hi = min(values), max(values)
    return (lo,hi) if i<j else (-hi,-lo)


def support_radius(angles_i, angles_j):
    a,b = angles_i
    c,d = angles_j
    assert -1 <= a <= b <= 1 and -1 <= c <= d <= 1
    if not (b<c or d<a):
        return Q(1)
    ratios = []
    for t,u in ((a,d),(b,c)):
        numerator = 1+t*u+abs(t-u)
        _,denominator = root_bounds((1+t*t)*(1+u*u),48)
        assert numerator >= 0 and denominator > 0
        ratios.append(numerator/denominator)
    return max(Q(1),(1+min(ratios))/2)


def radius_rows(angles, boxes):
    rows = []
    radii = {}
    for i,j in combinations(range(9),2):
        radius = support_radius(angles[i],angles[j])
        assert radius >= 1
        radii[(i,j)] = radius
        terms = []
        rhs = -radius*radius
        for axis,(lo,hi) in enumerate(boxes[(i,j)]):
            assert lo <= hi
            terms.extend(((2*i+axis,lo+hi),(2*j+axis,-lo-hi)))
            rhs -= lo*hi
        rows.append((tuple((k,c) for k,c in terms if c),rhs,
                     f'owner_free_interval_radius_{i}_{j}'))
    return rows,radii


def rotated_strips(boxes):
    rows,guards = [],[]
    for direction_index,e in enumerate(directions()):
        f = (-e[1],e[0])
        assert e[0]*f[0]+e[1]*f[1] == 0
        for triple in combinations(range(9),3):
            pairs = list(combinations(triple,2))
            width = max(abs(v) for i,j in pairs for v in projection(boxes,i,j,e))
            if width > Q(7,10):
                continue
            ordered = [p for p in permutations(triple)
                       if projection(boxes,p[0],p[1],f)[0]>=0
                       and projection(boxes,p[1],p[2],f)[0]>=0]
            if not ordered:
                continue
            lo,mid,hi = ordered[0]
            a,b = projection(boxes,lo,hi,e)
            floor = Q(2) if width<=Q(2,5) else Q(208,75)-Q(29,15)*width
            secant = Q(5,14)*(a+b)
            normal = tuple(f[k]+secant*e[k] for k in range(2))
            terms = {2*lo+k:normal[k] for k in range(2)}
            terms.update({2*hi+k:-normal[k] for k in range(2)})
            rhs = -floor-Q(5,14)*a*b
            name = f'rotated_three_square_strip_{lo}_{mid}_{hi}_{e[0]}_{e[1]}'
            rows.append((tuple((k,c) for k,c in sorted(terms.items()) if c),rhs,name))
            guards.append(dict(
                extension_rule='rational_rotated_strip', theorem=THEOREM,
                name=name,direction_index=direction_index,triple=[lo,mid,hi],
                transverse_direction=view(e),longitudinal_direction=view(f),
                width_upper=str(width),width_limit='7/10',
                endpoint_transverse_interval=view((a,b)),floor=str(floor),
                secant_multiplier=str(secant),row_normal=view(normal),rhs=str(rhs),
                successive_longitudinal_intervals=[
                    view(projection(boxes,lo,mid,f)),view(projection(boxes,mid,hi,f))],
                pair_projection_bounds=[dict(pair=[i,j],
                    cartesian_intervals=[view(ab) for ab in boxes[(i,j)]],
                    transverse_interval=view(projection(boxes,i,j,e)),
                    longitudinal_interval=view(projection(boxes,i,j,f))) for i,j in pairs]))
    return rows,guards


def forced_gaps(boxes,radii):
    rows,guards = [],[]
    for i,j in combinations(range(9),2):
        radius = radii[(i,j)]
        assert radius>=1
        for e in directions():
            f = (-e[1],e[0])
            transverse = projection(boxes,i,j,e)
            longitudinal = projection(boxes,i,j,f)
            width = max(abs(z) for z in transverse)
            if width>=radius:
                continue
            square = radius*radius-width*width
            bound,_ = root_bounds(square,32)
            # z^2>=square>=bound^2 implies z<=-bound or z>=bound.
            # Each strict endpoint comparison excludes the other CLOSED side.
            for sign in (1,-1):
                excluded = (longitudinal[0]>-bound if sign==1
                            else longitudinal[1]<bound)
                if not excluded:
                    continue
                terms = {2*i+k:sign*f[k] for k in range(2)}
                terms.update({2*j+k:-sign*f[k] for k in range(2)})
                name = f'ordered_euclidean_gap_{i}_{j}_{e[0]}_{e[1]}_{sign}'
                rows.append((tuple((k,c) for k,c in sorted(terms.items()) if c),-bound,name))
                guards.append(dict(
                    extension_rule='forced_distance_gap',name=name,pair=[i,j],
                    transverse_direction=view(e),longitudinal_direction=view(f),
                    transverse_interval=view(transverse),longitudinal_interval=view(longitudinal),
                    radius_lower=str(radius),width_upper=str(width),
                    sign_guard='lower > -L' if sign==1 else 'upper < L',
                    longitudinal_sign=sign,squared_gap_lower=str(square),
                    rational_gap_lower=str(bound)))
    return rows,guards


def extra_rows(angles,boxes):
    rows,radii = radius_rows(angles,boxes)
    more,guards = rotated_strips(boxes)
    rows += more
    more,moreguards = forced_gaps(boxes,radii)
    rows += more
    guards += moreguards
    return rows,guards
