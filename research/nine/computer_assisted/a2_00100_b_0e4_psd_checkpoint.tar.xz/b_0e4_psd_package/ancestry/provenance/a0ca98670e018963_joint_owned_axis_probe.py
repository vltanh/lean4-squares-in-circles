#!/usr/bin/env python3
"""Discover complete original-parent owned-axis contradictions.

Every physical packing embeds in the same-original quadratic variables.
Binary alternatives below represent the complete owned-axis separation
union for each original pair.  Solver infeasibility is discovery only;
acceptance still requires a separate exact rational finite certificate.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
import sys,json,time,argparse,hashlib
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
import numpy as np
from scipy.sparse import csr_matrix
from scipy.optimize._highspy import _core as H

HERE=Path(__file__).resolve().parent
OLD=Path('/workspace/scratch/0220f3e5a56d')
sys.path.insert(0,str(OLD/'cd_family'))
import quadratic_moment_pilot as T
import quadratic_owned_axis_union as U
import quadratic_global_nine_cardinality as G
sys.path.insert(0,str(OLD/'b_family'))
import fixed_sat_moment_rows as S
L=T.L
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def prefix(id):
    for base in [OLD/'b_family/resumed',OLD/'b_family/continued',Path('/workspace/scratch/29af4f6e10bf/b_macro/v2/results')]:
        p=base/(id+'.json')
        if p.exists():return p
    raise FileNotFoundError(id)

def collect(id,rlt='none',inherit_squares=True):
    p=prefix(id);state,dd,dg,prior=T.read_prefix(p);assert not dg
    allrows,ab,term,pos,sc,diffs,guards=T.P.M.collect(state,dd);assert term is None
    linear=[r for r in allrows if all(k<54 for k,v in r[0])]
    rows,absolute,meta=L.collect(linear,pos,sc,state['angles'],diffs,None,rlt)
    rows+=S.rows(state['path'])
    extra,ug=U.generate(state['angles'],diffs);rows+=extra
    nine,ng=G.generate(pos);rows+=nine
    oldmoment=OLD/'b_family/moment_results'/(id+'-fixed-sat-ipm.json')
    squares=[]
    if inherit_squares and oldmoment.exists():
        old=json.loads(oldmoment.read_text());assert old['prior']==prior
        squares=old['squares']
        for sq in squares:rows.append(L.psd_square_row(tuple(map(F,sq['coefficients'])),sq['index']))
    physical=dict(angles=T.P.M.render(state['angles']),positions=T.P.M.render(pos),scalar=T.P.M.render(sc),differences=T.P.M.render_diff(diffs))
    return rows,absolute,state,diffs,ug,dict(prior=prior,physical_state=physical,metadata=meta,all_nine_guards=ng,squares=squares)

def alternative_rows(pair,owner,axis,sign):
    i,j=pair;c,s=U.relative_polynomials(i,j)
    p=U.projection_polynomial(i,j,owner,axis,sign)
    out=[]
    for eps in(-1,1):
        co={};L.affine(co,c);L.affine(co,s,eps);L.affine(co,p,-2)
        out.append(L.clean(co,-1,f'joint_owned_axis_{i}_{j}_{owner}_{axis}_{sign}_{eps}'))
    return out

def mip_model(rows,absolute,guards,pairs):
    rr=list(rows);bs=[];n=L.SIZE
    for guard in guards:
        pair=tuple(guard['pair'])
        if pair not in pairs:continue
        alive=[a for a in guard['alternatives']if not a['eliminated']]
        inds=[]
        for a in alive:
            col=n+len(bs);inds.append(col);bs.append(dict(pair=list(pair),owner=a['owner'],axis=a['axis'],sign=a['sign']))
            ars=alternative_rows(pair,a['owner'],a['axis'],a['sign'])
            for eps,(terms,rhs,name)in zip((-1,1),ars):
                low=F(a['t_bounds'][str(eps)][0]);big=max(F(0),1-low)
                rr.append((terms+((col,big),),rhs+big,name+'_binary'))
        rr.append((tuple((k,F(-1))for k in inds),F(-1),f'complete_pair_union_{pair}'))
    size=n+len(bs);ir=[];ic=[];iv=[];rhs=[]
    for r,(co,b,name)in enumerate(rr):
        for k,v in co:ir.append(r);ic.append(k);iv.append(float(v))
        rhs.append(float(b))
    mat=csr_matrix((iv,(ir,ic)),shape=(len(rr),size))
    lp=H.HighsLp();lp.num_col_=size;lp.num_row_=len(rr)
    lp.col_cost_=np.zeros(size)
    lp.col_lower_=np.r_[-np.array(list(map(float,absolute))),np.zeros(len(bs))]
    lp.col_upper_=np.r_[np.array(list(map(float,absolute))),np.ones(len(bs))]
    lp.row_lower_=np.full(len(rr),-np.inf);lp.row_upper_=np.array(rhs)
    lp.integrality_=[H.HighsVarType.kContinuous]*n+[H.HighsVarType.kInteger]*len(bs)
    lp.a_matrix_.format_=H.MatrixFormat.kRowwise;lp.a_matrix_.start_=mat.indptr;lp.a_matrix_.index_=mat.indices;lp.a_matrix_.value_=mat.data
    h=H._Highs();h.setOptionValue('output_flag',True);h.setOptionValue('threads',1);h.passModel(lp)
    return h,rr,bs

def run(id,seconds=120,rlt='none',pairs=None):
    started=time.monotonic();rows,absolute,state,dt,guards,meta=collect(id,rlt)
    pairs=set(combinations(range(9),2))if pairs is None else set(pairs)
    h,rr,bs=mip_model(rows,absolute,guards,pairs);h.setOptionValue('time_limit',seconds);h.setOptionValue('mip_max_nodes',10000)
    print(id,'JOINT_INITIAL',len(rr),'rows',len(bs),'binaries',flush=True);h.run()
    status=str(h.getModelStatus());info=h.getInfo();solution=h.getSolution()
    out=dict(schema='joint_owned_axis_discovery_only_v1',id=id,path=state['path'],status='OPEN_DISCOVERY_ONLY',solver_status=status,
      seconds=time.monotonic()-started,whole_parent=True,accepted_originals=0,rows=len(rr),binaries=len(bs),
      selected_pairs=[list(p)for p in sorted(pairs)],prior=meta['prior'],physical_state=meta['physical_state'],
      metadata=meta['metadata'],mip_nodes=int(info.mip_node_count),sources={str(Path(p)):sha(p)for p in [__file__,T.__file__,U.__file__,G.__file__,L.__file__,S.__file__]})
    if solution.value_valid:
        vals=list(solution.col_value);out['relaxed_original_variables']=vals[:54]
        out['selected_alternatives']=[bs[i]for i,v in enumerate(vals[L.SIZE:])if v>.5]
        out['moment_values']=vals[:L.SIZE]
    dest=HERE/'joint_results';dest.mkdir(exist_ok=True);(dest/(id+'.json')).write_text(json.dumps(out,indent=2)+'\n')
    print(id,'JOINT_RESULT',status,'nodes',info.mip_node_count,'seconds',time.monotonic()-started,flush=True)
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--seconds',type=float,default=120);ap.add_argument('--rlt',choices=['none','core'],default='none');ap.add_argument('--pairs');a=ap.parse_args()
    pairs=None if not a.pairs else [tuple(map(int,p.split(',')))for p in a.pairs.split(';')]
    run(a.id,a.seconds,a.rlt,pairs)
