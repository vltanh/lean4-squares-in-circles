#!/usr/bin/env python3
"""Continue a certified whole-parent induction, retaining its entire prefix.

No new geometric partition. Output uses the existing canonical replay schema.
All candidate results require independent full-prefix and physical-row replay.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,argparse,copy
from pathlib import Path
OLD=Path('/workspace/scratch/29af4f6e10bf')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(OLD/'current_proof'))
import v3_whole_parent_pass as M
REG=HERE.parent/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
BASE_COLLECT=M.collect

def run(cell,rounds):
    source=OLD/'b_macro/v2/results'/(cell['id']+'.json')
    prefix=json.loads(source.read_text())
    assert prefix['status']=='OPEN' and prefix['path']==cell['path']
    before={tuple(d['pair']):M.K.box(d['intervals'])for d in prefix['final_differences']}
    def initial(c):
        assert c['id']==prefix['id'] and c['path']==prefix['path']
        _,_,choices=M.V.reconstruct(c['path'])
        return {'id':c['id'],'path':c['path'],'angles':M.K.box(prefix['final_angles']),
                'positions':M.K.box(prefix['final_positions']),'scalar':M.K.box(prefix['final_scalar']),
                'choices':choices},prefix['prior'],None
    def collect(state,diffs):
        merged=dict(before)
        for p,intervals in diffs.items():
            merged[p]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(merged[p],intervals))
        return BASE_COLLECT(state,merged)
    def save(record):
        out=copy.deepcopy(record)
        for field in ('sources','additional_sources'):
            combined=dict(prefix.get(field,{}))
            for k,v in out.get(field,{}).items():
                assert k not in combined or combined[k]==v
                combined[k]=v
            out[field]=combined
        out['additional_sources'][str(Path(__file__))]=M.sha(__file__)
        out['continuation_input']={'file':str(source),'sha256':M.sha(source),
              'inherited_rounds':len(prefix['rounds']),'additional_round_limit':rounds}
        out['prior']=prefix['prior']
        for k,rr in enumerate(out['rounds']):
            if k==0:rr['differences_before']=prefix['final_differences']
            rr['round']+=len(prefix['rounds'])
        for field in ('final_test','terminal'):
            rr=out.get(field)
            if field=='terminal' and rr:rr=rr.get('state')
            if rr:
                if rr['round']==0:rr['differences_before']=prefix['final_differences']
                rr['round']+=len(prefix['rounds'])
        out['rounds']=copy.deepcopy(prefix['rounds'])+out['rounds']
        if not record['rounds']:out['final_differences']=prefix['final_differences']
        out['independent_review_status']='PENDING_FULL_REPLAY'
        dest=HERE/'continued';dest.mkdir(exist_ok=True)
        (dest/(cell['id']+'.json')).write_text(json.dumps(out,indent=2)+'\n')
    M.initial=initial;M.collect=collect;M.save=save
    M.HERE=HERE;M.VERSION=prefix['schema']
    return M.run(cell,rounds)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--id');ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=11);ap.add_argument('--rounds',type=int,default=8);a=ap.parse_args()
    cells=[c for c in json.loads(REG.read_text())['cells']if c['status']=='OPEN'and c['sign']=='negative'and c['path'][1][-1]==0]
    if a.id:cells=[c for c in cells if c['id']==a.id]
    else:cells=cells[a.start:a.stop]
    for c in cells:
        if not(HERE/'continued'/(c['id']+'.json')).exists():run(c,a.rounds)
