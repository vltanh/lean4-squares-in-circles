#!/usr/bin/env python3
"""Bounded original-parent quadratic lift with rational square cuts.

Numerical LP/eigenvector calculations only discover candidates.  An exclusion
must end with a strictly positive rational residual-corrected Farkas reserve.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
from fractions import Fraction as Q
import sys,json,time,argparse,hashlib
import numpy as np
import diagonal_pass as P
import correlated_capacity_rows as C
import quadratic_moment_rows as L

HERE=Path(__file__).resolve().parent

def read_prefix(path):
    path=Path(path).resolve();r=json.loads(path.read_text())
    if 'final'in r:
        f=r['final'];angles=f['angles'];positions=f['positions'];scalar=f['scalar'];diff=f['differences'];diag=f.get('diagonal',[])
    else:
        angles=r['final_angles'];positions=r['final_positions'];scalar=r['final_scalar'];diff=r['final_differences'];diag=[]
    _,_,choices=P.M.V.reconstruct(r['path'])
    state=dict(id=r['id'],path=r['path'],choices=choices,angles=P.box(angles),positions=P.box(positions),scalar=P.box(scalar))
    dd={tuple(x['pair']):P.box(x['intervals']) for x in diff}
    dg={tuple(x['pair']):P.box(x['intervals']) for x in diag}
    return state,dd,dg,dict(path=str(path),sha256=P.sha(path),schema=r.get('schema'))

def collect(state,dd,dg,rlt):
    if dg:
        rows,ab,term,pos,sc,dt,gt=P.collect(state,dd,dg)
    else:
        rows,ab,term,pos,sc,dt,guards=P.M.collect(state,dd);gt={}
    if term:raise RuntimeError('Unreviewed interval terminal: '+str(term))
    assert len(ab)==L.N
    guards=[]
    if gt:
        extra,guards=C.generate_rows(dt,gt);rows+=extra
    lifted,absolute,meta=L.collect(rows,pos,sc,state['angles'],dt,gt,rlt)
    data=dict(angles=P.M.render(state['angles']),positions=P.M.render(pos),scalar=P.M.render(sc),
              differences=P.M.render_diff(dt),diagonal=P.M.render_diff(gt),capacity_guards=guards)
    return lifted,absolute,meta,data

def moment_matrix(values,bounds):
    n=L.N;matrix=np.ones((n+1,n+1));matrix[0,1:]=values[:n];matrix[1:,0]=values[:n]
    for i,j in L.PAIRS:matrix[i+1,j+1]=matrix[j+1,i+1]=values[L.mon(i,j)]
    midpoint=np.array([float((a+b)/2) for a,b in bounds]);radius=np.array([max(.05,float((b-a)/2)) for a,b in bounds])
    transform=np.zeros((n+1,n+1));transform[0,0]=1.
    for i in range(n):transform[i+1,0]=-midpoint[i]/radius[i];transform[i+1,i+1]=1./radius[i]
    return transform@matrix@transform.T,transform

def discover_squares(values,bounds,count,known):
    matrix,transform=moment_matrix(values,bounds)
    eigenvalues,eigenvectors=np.linalg.eigh(matrix)
    found=[]
    for k,value in enumerate(eigenvalues):
        if value>=-1e-7 or len(found)>=count:break
        vector=eigenvectors[:,k]@transform
        vector/=max(abs(vector))
        q=tuple(Q(int(round(float(v)*(1<<16))),1<<16) for v in vector)
        if q in known:continue
        row=L.psd_square_row(q,len(known)+len(found))
        co,rhs,name=row;violation=sum(float(c)*values[i]for i,c in co)-float(rhs)
        if violation<=1e-9:continue
        found.append((q,row,float(value),violation))
    return found,eigenvalues

def exact_terminal(rows,absolute,solution):
    if solution.col_value[-1]<=1e-9:return None
    weights=P.M.terms(solution.row_dual)
    co,rhs=P.M.R.weighted_sum(rows,absolute,weights)
    reserve=-rhs-sum(a*abs(v) for a,v in zip(absolute,co))
    if reserve<=0:return dict(kind='REJECTED_NONPOSITIVE_RESERVE',reserve=str(reserve))
    return dict(kind='positive_exact_reserve',weights=weights,reserve=str(reserve),
         printed_rows=P.M.R.printed_rows(rows,{i for i,w in weights}),
         absolute_variable_bounds=list(map(str,absolute)),weighted_rhs=str(rhs),
         weighted_coefficients=list(map(str,co)))

def run(prefix,rounds=12,cuts=24,rlt='core',lp_seconds=60,tag=''):
    started=time.monotonic();state,dd,dg,prior=read_prefix(prefix)
    rows,absolute,meta,physical=collect(state,dd,dg,rlt)
    bounds=P.box(physical['positions'])+P.box(physical['scalar'])
    out=HERE/'moment_results';out.mkdir(exist_ok=True)
    dest=out/(state['id']+('-'+tag if tag else'')+'.json')
    record=dict(schema='same_original_quadratic_moment_pilot_v1',id=state['id'],path=state['path'],
         prior=prior,physical_state=physical,metadata=meta,status='OPEN',scope='WHOLE_UNCHANGED_ORIGINAL_PARENT',
         maximum_rounds=rounds,maximum_squares_per_round=cuts,new_branch_nodes=0,
         sources={str(Path(p)):P.sha(p) for p in(__file__,L.__file__,P.__file__,C.__file__,P.M.__file__)},
         squares=[],rounds=[])
    def save():
        record['seconds']=time.monotonic()-started
        dest.write_text(json.dumps(record,indent=2)+'\n')
    save();print(state['id'],'MOMENT INITIAL',meta,flush=True)
    h=P.M.highs(rows,L.SIZE);known=set()
    for ri in range(rounds+1):
        h.setOptionValue('time_limit',h.getRunTime()+lp_seconds);h.run()
        status=h.getModelStatus();item=dict(round=ri,rows=len(rows),solver_status=str(status))
        record['rounds'].append(item)
        if status!=P.M.H.HighsModelStatus.kOptimal:
            record['stop_reason']='bounded_lp_limit_or_nonoptimal';save();break
        solution=h.getSolution();values=np.array(solution.col_value[:L.SIZE]);item['phase_margin']=float(solution.col_value[-1])
        terminal=exact_terminal(rows,absolute,solution)
        if terminal and terminal['kind']=='positive_exact_reserve':
            record.update(status='CANDIDATE_CLOSED',terminal=terminal);save()
            print(state['id'],'MOMENT EXACT CANDIDATE',ri,'reserve',terminal['reserve'],flush=True);break
        if terminal:item['rejected_terminal']=terminal
        proposals,eigenvalues=discover_squares(values,bounds,cuts,known)
        item.update(minimum_normalized_eigenvalue=float(eigenvalues[0]),negative_eigenvalues=int(sum(eigenvalues< -1e-7)),
                    proposed_squares=len(proposals))
        print(state['id'],'MOMENT ROUND',ri,'phase',item['phase_margin'],'minEig',item['minimum_normalized_eigenvalue'],
              'negative',item['negative_eigenvalues'],'cuts',len(proposals),'seconds',round(time.monotonic()-started,2),flush=True)
        if ri==rounds or not proposals:
            record['stop_reason']='bounded_square_budget_exhausted'if ri==rounds else'no_new_violated_rational_square'
            record['relaxed_original_variables']=list(map(float,values[:L.N]));save();break
        for q,row,eigenvalue,violation in proposals:
            index=len(record['squares']);assert row[2]==f'moment_psd_square_{index}'
            record['squares'].append(dict(index=index,coefficients=list(map(str,q)),discovery_eigenvalue=eigenvalue,
                                         discovery_violation=violation,installed_after_round=ri))
            known.add(q);rows.append(row)
            co,rhs,name=row;indices=np.array([k for k,v in co]+[L.SIZE],dtype=np.int32)
            values2=np.array([float(v) for k,v in co]+[-1.],dtype=np.float64)
            h.addRow(-np.inf,float(rhs),len(indices),indices,values2)
        save()
    print(state['id'],'MOMENT RESULT',record['status'],record.get('stop_reason',''),'seconds',round(time.monotonic()-started,2),flush=True)
    return record

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('prefix');ap.add_argument('--rounds',type=int,default=12)
    ap.add_argument('--cuts',type=int,default=24);ap.add_argument('--rlt',choices=('core','none'),default='core')
    ap.add_argument('--lp-seconds',type=int,default=60);ap.add_argument('--tag',default='')
    a=ap.parse_args();run(a.prefix,a.rounds,a.cuts,a.rlt,a.lp_seconds,a.tag)
