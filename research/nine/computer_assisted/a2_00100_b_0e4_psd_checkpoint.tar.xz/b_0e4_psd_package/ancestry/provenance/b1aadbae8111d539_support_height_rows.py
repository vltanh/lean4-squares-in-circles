"""Exact owner-free pair norm rows from the same originals' support heights.
Physical theorem: norm(center_j-center_i) >= 1+abs(h_i-h_j),
h_i=(alpha_i+absbeta_i)/2. Proved in SUPPORT_HEIGHT_PAIR_HAND_PROOF.md.
"""
from fractions import Fraction as F
from itertools import combinations

def rows(scalar,differences):
    result=[]
    for i,j in combinations(range(9),2):
        hi=tuple((scalar[i][k]+scalar[18+i][k])/2 for k in (0,1))
        hj=tuple((scalar[j][k]+scalar[18+j][k])/2 for k in (0,1))
        lo,up=hi[0]-hj[1],hi[1]-hj[0]
        (a,b),(c,e)=differences[i,j]
        for sign in (-1,1):
            for t in sorted({F(0),lo,(lo+up)/2,up}):
                co={2*i:a+b,2*j:-(a+b),2*i+1:c+e,2*j+1:-(c+e),18+i:sign+t,36+i:sign+t,18+j:-(sign+t),36+j:-(sign+t)}
                rhs=t*t-1-a*b-c*e
                result.append((tuple((k,v)for k,v in sorted(co.items())if v),rhs,f'original_support_height_radius_{i}_{j}_{sign}_{t}'))
    return result
