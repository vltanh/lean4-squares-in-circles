"""Exact same-frame projection bounds and complete owned-axis union cuts.

This is separate from the frozen initial moment pilot.  All arithmetic is
rational; square-root intervals are outward rounded by integer square roots.
The proof is recorded in QUADRATIC_OWNED_AXIS_UNION_HAND_PROOF.md.
"""
from fractions import Fraction as Q
from itertools import combinations,product
from math import isqrt
import quadratic_moment_rows as L

def sqrt_bounds(v):
    assert v>=0
    scale=1<<40
    floor=isqrt((v.numerator*scale*scale)//v.denominator)
    lo=Q(floor,scale)
    return lo,lo if lo*lo==v else Q(floor+1,scale)

def divide_by_sqrt(n,d):
    lo,hi=sqrt_bounds(d);assert lo>0
    return (n/hi,n/lo)if n>=0 else(n/lo,n/hi)

def fixed_projection(x,y,angle):
    """Range of (x+t*y)/sqrt(1+t*t) on one exact slope interval."""
    a,b=angle;ts={a,b}
    if x and a<=y/x<=b:ts.add(y/x)
    vv=[divide_by_sqrt(x+t*y,1+t*t)for t in ts]
    return min(a for a,b in vv),max(b for a,b in vv)

def vertices(cartesian,diagonal=False):
    if diagonal:
        return [((s+t)/2,(s-t)/2)for s,t in product(*cartesian)]
    return list(product(*cartesian))

def projection_range(box,angle,axis,diagonal=False):
    vv=[]
    for dx,dy in vertices(box,diagonal):
        x,y=(dx,dy)if axis==0 else(dy,-dx)
        vv.append(fixed_projection(x,y,angle))
    return min(a for a,b in vv),max(b for a,b in vv)

def projection_bounds(pair,owner,axis,angles,differences,diagonal):
    lo,hi=projection_range(differences[pair],angles[owner],axis)
    if pair in diagonal:
        a,b=projection_range(diagonal[pair],angles[owner],axis,True);lo=max(lo,a);hi=min(hi,b)
    assert lo<=hi
    return lo,hi

def relative_bounds(a,b):
    """cos/sin of theta_j-theta_i from canonical slope intervals."""
    endpoints=((a[1],b[0]),(a[0],b[1]))
    cs=[divide_by_sqrt(1+x*y,(1+x*x)*(1+y*y))for x,y in endpoints]
    ss=[divide_by_sqrt(y-x,(1+x*x)*(1+y*y))for x,y in endpoints]
    clo=max(Q(0),min(lo for lo,hi in cs))
    chi=Q(1)if max(a[0],b[0])<=min(a[1],b[1])else min(Q(1),max(hi for lo,hi in cs))
    return (clo,chi),(max(Q(-1),ss[0][0]),min(Q(1),ss[1][1]))

def projection_polynomial(i,j,owner,axis,sign=1):
    dx,dy=L.delta(i,j,0),L.delta(i,j,1);co={}
    if axis==0:
        L.multiply(co,{18+owner:Q(sign)},dx);L.multiply(co,{27+owner:Q(sign)},dy)
    else:
        L.multiply(co,{18+owner:Q(sign)},dy);L.multiply(co,{27+owner:Q(-sign)},dx)
    return co

def relative_polynomials(i,j):
    return ({L.mon(18+i,18+j):Q(1),L.mon(27+i,27+j):Q(1)},
            {L.mon(18+i,27+j):Q(1),L.mon(27+i,18+j):Q(-1)})

def difference_projection_bound(pair,axis,angles,differences,diagonal):
    i,j=pair
    def one(box,diag):
        rr=[]
        for dx,dy in vertices(box,diag):
            x,y=(dx,dy)if axis==0 else(dy,-dx)
            a,b=fixed_projection(x,y,angles[i]);c,d=fixed_projection(x,y,angles[j])
            rr.append((a-d,b-c))
        return min(a for a,b in rr),max(b for a,b in rr)
    lo,hi=one(differences[pair],False)
    if pair in diagonal:
        a,b=one(diagonal[pair],True);lo=max(lo,a);hi=min(hi,b)
    assert lo<=hi
    return max(abs(lo),abs(hi))

def generate(angles,differences,diagonal=None):
    diagonal=diagonal or{};rows=[];guards=[]
    for i,j in combinations(range(9),2):
        pair=(i,j);c,s=relative_polynomials(i,j);cb,sb=relative_bounds(angles[i],angles[j])
        for tag,expr,(lo,hi)in(('cos',c,cb),('sin',s,sb)):
            rows.append(L.clean(expr,hi,f'owned_axis_relative_upper_{i}_{j}_{tag}'))
            rows.append(L.clean({k:-v for k,v in expr.items()},-lo,f'owned_axis_relative_lower_{i}_{j}_{tag}'))
        alternatives=[]
        for owner,axis in product((i,j),(0,1)):
            pb=projection_bounds(pair,owner,axis,angles,differences,diagonal)
            polynomial=projection_polynomial(i,j,owner,axis)
            rows.append(L.clean(polynomial,pb[1],f'owned_axis_projection_upper_{i}_{j}_{owner}_{axis}'))
            rows.append(L.clean({k:-v for k,v in polynomial.items()},-pb[0],f'owned_axis_projection_lower_{i}_{j}_{owner}_{axis}'))
            for sign in(-1,1):
                lo,hi=pb if sign==1 else(-pb[1],-pb[0]);p={k:sign*v for k,v in polynomial.items()}
                t={};intervals={}
                for eps in(-1,1):
                    co={};L.affine(co,p,2);L.affine(co,c,-1);L.affine(co,s,-eps)
                    sl,su=sb if eps==1 else(-sb[1],-sb[0])
                    t[eps]=co;intervals[eps]=(2*lo-cb[1]-su,2*hi-cb[0]-sl)
                impossible=(hi<1)or any(upper<1 for lower,upper in intervals.values())
                alternatives.append(dict(owner=owner,axis=axis,sign=sign,p=p,pb=(lo,hi),t=t,tb=intervals,impossible=impossible))
        alive=[a for a in alternatives if not a['impossible']]
        guard=dict(pair=[i,j],relative_cos=list(map(str,cb)),relative_sin=list(map(str,sb)),
           alternatives=[dict(owner=a['owner'],axis=a['axis'],sign=a['sign'],projection=list(map(str,a['pb'])),
             t_bounds={str(e):list(map(str,b))for e,b in a['tb'].items()},eliminated=a['impossible'])for a in alternatives],
           surviving=len(alive),union_rows=[],close_axis_rows=[])
        if not alive:
            # Every one of the complete eight physical alternatives is excluded.
            rows.append(L.clean({},-1,f'owned_axis_empty_complete_cover_{i}_{j}'));guard['empty_cover']=True
        else:
            for eps in(-1,1):
                if any(a['tb'][eps][0]>=1 for a in alive):continue
                co={};rhs=Q(-1)
                for a in alive:
                    lower=a['tb'][eps][0];weight=1/(1-lower)
                    L.affine(co,a['t'][eps],-weight);rhs-=weight*lower
                rows.append(L.clean(co,rhs,f'owned_axis_complete_union_{i}_{j}_{eps}'))
                guard['union_rows'].append(eps)
            if all(a['pb'][0]<1 for a in alive):
                co={};rhs=Q(-1)
                for a in alive:
                    lower=a['pb'][0];weight=1/(1-lower)
                    L.affine(co,a['p'],-weight);rhs-=weight*lower
                rows.append(L.clean(co,rhs,f'owned_axis_unit_union_{i}_{j}'));guard['unit_union']=True
            if len(alive)==2 and{a['owner']for a in alive}=={i,j}and len({(a['axis'],a['sign'])for a in alive})==1:
                axis=alive[0]['axis'];delta=difference_projection_bound(pair,axis,angles,differences,diagonal)
                for a in alive:
                    for eps in(-1,1):
                        rows.append(L.clean({k:-v for k,v in a['t'][eps].items()},2*delta-1,
                          f'owned_axis_close_pair_{i}_{j}_{a["owner"]}_{axis}_{a["sign"]}_{eps}'))
                guard['close_axis_rows']=dict(axis=axis,sign=alive[0]['sign'],delta=str(delta))
        guards.append(guard)
    return rows,guards
