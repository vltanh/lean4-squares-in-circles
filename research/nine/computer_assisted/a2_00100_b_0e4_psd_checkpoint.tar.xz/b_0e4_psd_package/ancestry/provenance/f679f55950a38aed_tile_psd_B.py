#!/usr/bin/env python3
"""One bounded numerical SDP discovery attempt on one frozen A2 moment model.

No numerical status is a proof.  A physical configuration embeds in the PSD
moment cone.  A candidate must subsequently produce a positive exact sum of
existing rational rows and explicit rational negative-square rows.
Budget: at most12000 ADMM iterations and240 wall seconds. Positive paid duals
are converted in the separate active-support rational certificate producer.
"""
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
from fractions import Fraction as Q
import json,time,hashlib
import numpy as np
from scipy.sparse import coo_matrix,csr_matrix,hstack,vstack
from scipy.linalg import cho_factor,cho_solve,eigh
import sys
import joint_owned_axis_probe as J
import planar_four_center_rows as FC
import square_area_moment_rows as AREA
import b_tile_model as BM
D=J.T
HERE=Path(__file__).resolve().parent
IDENT=sys.argv[1]
FIXED=False
TILE=tuple(map(int,sys.argv[2:4]));assert len(TILE)==2
H_TILE=tuple(map(int,sys.argv[4:6])) if len(sys.argv)>=6 else None
SIGN_CODE='';ENERGY=True
FROZEN=Path(json.loads((HERE/'fixed_i_grid_capacity'/IDENT/'manifest.json').read_text())['parent_source'])
OUT=HERE/('tile_psd_B_'+IDENT+'_'+'_'.join(map(str,TILE+(H_TILE or ()))));OUT.mkdir(exist_ok=True)
MAX_ITERATIONS=12000;MAX_SECONDS=240;GAMMA=4.;RHO=.5
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 start=time.monotonic()
 rows,absolute,state,details,frozen=BM.collect(IDENT,TILE,H_TILE)
 physical=details['physical_state'];prior=details['prior']
 n=D.L.SIZE;m=len(rows);assert n==1539
 bounds=D.P.box(physical['positions'])+D.P.box(physical['scalar'])
 midpoint=tuple((a+b)/2 for a,b in bounds);radius=tuple(max(Q(1,20),(b-a)/2)for a,b in bounds)
 mu=np.array(list(map(float,midpoint)));rad=np.array(list(map(float,radius)))
 tr=[];tc=[];tv=[];shift=np.zeros(n)
 for i in range(54):tr.append(i);tc.append(i);tv.append(rad[i]);shift[i]=mu[i]
 for i,j in D.L.PAIRS:
  k=D.L.mon(i,j);shift[k]=mu[i]*mu[j]
  for col,value in((i,mu[j]*rad[i]),(j,mu[i]*rad[j]),(k,rad[i]*rad[j])):
   if value:tr.append(k);tc.append(col);tv.append(value)
 transform=coo_matrix((tv,(tr,tc)),shape=(n,n)).tocsr()
 ar=[];ac=[];av=[];rhs=np.empty(m)
 for r,(co,b,name)in enumerate(rows):
  rhs[r]=float(b)
  for k,v in co:ar.append(r);ac.append(k);av.append(float(v))
 original=coo_matrix((av,(ar,ac)),shape=(m,n)).tocsr()
 aa=(original@transform).tocsr();bb=rhs-original@shift
 rownorm=np.sqrt(np.asarray(aa.multiply(aa).sum(axis=1)).ravel());rownorm=np.maximum(rownorm,1e-12)
 aa=aa.multiply((1/rownorm)[:,None]).tocsr();bb=bb/rownorm
 blin=hstack((aa,csr_matrix(-np.ones((m,1)))),format='csr')
 lower=csr_matrix(([-1.],([0],[n])),shape=(1,n+1));blin=vstack((blin,lower),format='csr');bb=np.r_[bb,1.]
 weights=np.r_[np.full(54,2.),np.array([1. if i==j else 2. for i,j in D.L.PAIRS]),0.]
 gram=(blin.T@blin).toarray();gram[np.diag_indices(n+1)]+=GAMMA*GAMMA*weights
 factor=cho_factor(gram,lower=True,check_finite=False)
 qabs=np.array([float((b-a)/2/r)for(a,b),r in zip(bounds,radius)])
 absolute_normalized=np.r_[qabs,[qabs[i]*qabs[j]for i,j in D.L.PAIRS]]
 def matrix(x):
  ans=np.zeros((55,55));ans[0,0]=1.;ans[0,1:]=ans[1:,0]=x[:54]
  for i,j in D.L.PAIRS:ans[i+1,j+1]=ans[j+1,i+1]=x[D.L.mon(i,j)]
  return ans
 def pull(mat):
  ans=np.empty(n+1);ans[:54]=mat[0,1:]+mat[1:,0]
  for i,j in D.L.PAIRS:ans[D.L.mon(i,j)]=mat[i+1,j+1]*(1 if i==j else 2)
  ans[-1]=0.;return ans
 rho=RHO;x=np.zeros(n+1);s=np.maximum(bb,0);u=np.zeros(m+1);S=np.zeros((55,55));S[0,0]=GAMMA;U=np.zeros((55,55));objective=np.zeros(n+1);objective[-1]=1
 record={'schema':'fixed_original_B_I_tile_full_psd_discovery_v1','id':state['id'],'path':state['path'],'status':'OPEN_NUMERICAL_DISCOVERY','originals_accepted':0,'new_branch_nodes':0,
  'frozen_model':str(FROZEN),'frozen_model_sha256':sha(FROZEN),'source':str(Path(__file__).resolve()),'source_sha256':sha(__file__),
  'sources':frozen['sources'],**details,'initial_rows':m,'sign_code':SIGN_CODE,'four_center_energy':ENERGY,'original_square_area_rows':True,'fixed_mip_selection_conditional':FIXED,'variables':n,'maximum_iterations':MAX_ITERATIONS,'maximum_seconds':MAX_SECONDS,
  'maximum_final_exact_lp_seconds':60,'normalization_midpoint':list(map(str,midpoint)),'normalization_radius':list(map(str,radius)),
  'psd_constraint_scale':GAMMA,'initial_rho':RHO,'iterations':[]}
 print(state['id'],'DIRECT_PSD_INITIAL',m,n,'setup_seconds',round(time.monotonic()-start,2),flush=True)
 best=(-np.inf,None);last_metrics=None
 for it in range(MAX_ITERATIONS+1):
  if time.monotonic()-start>MAX_SECONDS:record['stop_reason']='declared_wall_budget';break
  old_s=s;old_S=S
  xx=blin.T@(bb-s-u)+GAMMA*pull(S+U)-objective/rho
  x=cho_solve(factor,xx,check_finite=False)
  bx=blin@x
  s=np.maximum(bb-bx-u,0)
  mm=matrix(x);e,v=eigh(GAMMA*mm-U,check_finite=False)
  S=(v*np.maximum(e,0))@v.T
  rp=bx+s-bb;RP=S-GAMMA*mm
  u+=rp;U+=RP;U=(U+U.T)/2
  if it%100==0 or it==MAX_ITERATIONS:
   residual_dual=rho*(blin.T@(s-old_s)-GAMMA*pull(S-old_S))
   pri=float(np.sqrt(rp@rp+np.sum(RP*RP)));dua=float(np.linalg.norm(residual_dual))
   Y=GAMMA*rho*U;lambda_normal=rho*u[:m]
   coeff=aa.T@lambda_normal-pull(Y)[:n]
   constant=float(bb[:m]@lambda_normal+Y[0,0])
   paid=-constant-float(absolute_normalized@np.abs(coeff))
   mineig=float(np.linalg.eigvalsh(mm)[0]);maxlin=float(np.max(aa@x[:n]-bb[:m]))
   metrics={'iteration':it,'seconds':time.monotonic()-start,'phase':float(x[-1]),'primal_residual_l2':pri,
    'dual_residual_l2':dua,'minimum_moment_eigenvalue':mineig,'maximum_normalized_linear_violation_at_zero_phase':maxlin,
    'numerical_dual_rhs':constant,'numerical_dual_residual_paid_bound':float(absolute_normalized@np.abs(coeff)),
    'numerical_paid_reserve':paid,'rho':rho}
   record['iterations'].append(metrics);last_metrics=metrics
   if paid>best[0]:best=(paid,{'linear_dual_normalized':lambda_normal.copy(),'psd_dual_normalized':Y.copy(),'normalized_primal':x.copy(),'coefficients':coeff.copy(),'rhs':constant})
   print(state['id'],'DIRECT_PSD_ITER',it,'phase',round(float(x[-1]),7),'primal',round(pri,7),'dual',round(dua,7),'minEig',round(mineig,7),'paid',round(paid,7),flush=True)
   (OUT/'diagnostics.json').write_text(json.dumps(record,indent=2)+'\n')
   if paid>1e-5:record['stop_reason']='positive_numerical_paid_reserve_requires_exact_certificate';break
   if pri<1e-6 and dua<1e-6:record['stop_reason']='numerical_convergence_requires_exact_interpretation';break
   if it>0:
    change=2. if pri>10*dua else .5 if dua>10*pri else 1.
    new_rho=min(32.,max(1/128,rho*change))
    if new_rho!=rho:u*=rho/new_rho;U*=rho/new_rho;rho=new_rho
 else:record['stop_reason']='declared_iteration_budget'
 record['seconds']=time.monotonic()-start;record['best_numerical_paid_reserve']=best[0];record['final_metrics']=last_metrics
 arrays=best[1];assert arrays is not None
 np.savez_compressed(OUT/'complete_numerical_state.npz',**arrays,final_normalized_primal=x,final_linear_slack=s,final_linear_dual_scaled=u,
  final_psd_slack=S,final_psd_dual_scaled=U,linear_row_normalizers=rownorm,original_shift=shift,final_rho=np.array(rho))
 record['complete_numerical_state_file']='complete_numerical_state.npz';record['complete_numerical_state_sha256']=sha(OUT/'complete_numerical_state.npz')
 if best[0]>1e-5:
  Y=arrays['psd_dual_normalized'];eig,vec=eigh(Y,check_finite=False);C=np.eye(55)
  for i in range(54):C[i+1,0]=-mu[i]/rad[i];C[i+1,i+1]=1/rad[i]
  new_squares=[]
  for i,value in enumerate(eig):
   if value<=max(eig)*1e-10:continue
   q=vec[:,i]@C;q/=max(abs(q));qr=tuple(Q(round(float(t)*(1<<24)),1<<24)for t in q)
   index=len(frozen['squares'])+len(new_squares);row=D.L.psd_square_row(qr,index);rows.append(row)
   new_squares.append({'index':index,'coefficients':list(map(str,qr))})
  record['new_rational_squares']=new_squares
 assert sha(FROZEN)==record['frozen_model_sha256']
 record['seconds']=time.monotonic()-start;(OUT/'diagnostics.json').write_text(json.dumps(record,indent=2)+'\n')
 print(state['id'],'DIRECT_PSD_RESULT',record['status'],record['stop_reason'],'best_paid',best[0],'seconds',round(record['seconds'],2),flush=True)
if __name__=='__main__':main()
