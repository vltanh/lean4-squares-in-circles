"""Exact affine strip rows in 26 rational orthonormal frames.

Premise: every supplied Cartesian pair-difference interval has already been
proved for these same nine distinct, nonoverlapping physical unit squares.
The geometric three-original strip theorem is a separate hand-proof premise.
There is no optimization, sampling, branch selection, or interval tightening
inside this module.  Every guard is recorded using only the input intervals.
"""
from fractions import Fraction as F
from itertools import combinations, permutations


def rational_directions():
    result = [(F(1), F(0)), (F(0), F(1))]
    for a, b, d in ((3,4,5), (5,12,13), (8,15,17), (7,24,25), (20,21,29), (9,40,41)):
        for p, q in ((a,b), (b,a)):
            for sign in (-1,1):
                result.append((F(p,d), F(sign*q,d)))
    assert len(result) == len(set(result)) == 26
    assert all(p*p + q*q == 1 for p,q in result)
    return tuple(result)


DIRECTIONS = rational_directions()
THEOREM = 'sharp_three_original_slice_capacity_v3'


def _scale(c, interval):
    low, high = interval
    return (c*low, c*high) if c >= 0 else (c*high, c*low)


def _render(interval):
    return [str(x) for x in interval]


def rotated_three_square_rows(differences, directions=DIRECTIONS):
    """Return (rows, guards), with rows of the established (co,rhs,name) form.

    A row is valid for the full input state whenever its guard is emitted.
    The first lexicographic longitudinal order with both proved successive
    gaps nonnegative is used; ties and width exactly 7/10 are included.
    """
    pairs = tuple(combinations(range(9), 2))
    assert all(pair in differences for pair in pairs)
    boxes = {pair: tuple(tuple(F(x) for x in ab) for ab in differences[pair]) for pair in pairs}
    assert all(len(box) == 2 and all(len(ab) == 2 and ab[0] <= ab[1] for ab in box) for box in boxes.values())
    directions = tuple(tuple(F(x) for x in direction) for direction in directions)
    assert all(len(e) == 2 and e[0]*e[0] + e[1]*e[1] == 1 for e in directions)
    assert len(directions) == len(set(directions))

    def projection(i, j, direction):
        reverse = i > j
        x, y = boxes[(j,i) if reverse else (i,j)]
        ax, bx = _scale(direction[0], x)
        ay, by = _scale(direction[1], y)
        low, high = ax+ay, bx+by
        return (-high, -low) if reverse else (low, high)

    rows, guards = [], []
    for direction_index, e in enumerate(directions):
        f = (-e[1], e[0])
        assert e[0]*f[0] + e[1]*f[1] == 0 and f[0]*f[0] + f[1]*f[1] == 1
        for triple in combinations(range(9), 3):
            triple_pairs = tuple(combinations(triple, 2))
            width = max(abs(v) for i,j in triple_pairs for v in projection(i,j,e))
            if width > F(7,10):
                continue
            order = next((order for order in permutations(triple)
                          if projection(order[0],order[1],f)[0] >= 0
                          and projection(order[1],order[2],f)[0] >= 0), None)
            if order is None:
                continue
            lo, mid, hi = order
            a, b = projection(lo,hi,e)
            capacity = min(F(2), F(280,99) - 2*width)
            secant = F(13,50)*(a+b)
            normal = (f[0]+secant*e[0], f[1]+secant*e[1])
            coefficients = {2*lo:normal[0], 2*lo+1:normal[1],
                            2*hi:-normal[0], 2*hi+1:-normal[1]}
            name = f'sharp_rotated_three_square_strip_{lo}_{mid}_{hi}_{e[0]}_{e[1]}'
            rhs = -capacity - F(13,50)*a*b
            rows.append((tuple((k,v) for k,v in sorted(coefficients.items()) if v), rhs, name))
            guards.append({'theorem':THEOREM,'name':name,'direction_index':direction_index,
                           'triple':list(order),'transverse_direction':_render(e),
                           'longitudinal_direction':_render(f),'width_upper':str(width),
                           'width_limit':'7/10','endpoint_transverse_interval':_render((a,b)),
                           'floor':str(capacity),'secant_multiplier':str(secant),
                           'row_normal':_render(normal),'rhs':str(rhs),
                           'successive_longitudinal_intervals':[
                               _render(projection(lo,mid,f)),_render(projection(mid,hi,f))],
                           'pair_projection_bounds':[
                               {'pair':[i,j], 'cartesian_intervals':[_render(v) for v in boxes[(i,j)]],
                                'transverse_interval':_render(projection(i,j,e)),
                                'longitudinal_interval':_render(projection(i,j,f))}
                               for i,j in triple_pairs]})
    return rows, guards
