"""Unconditional all-nine radial and near-cardinality quadratic rows.

The geometric premise is the independently reviewed all-nine small-central-disk
arc theorem.  No near-original pair is selected.  This module is standard-
library-only and introduces only shared original center-square moments.
"""
from fractions import Fraction as Q

N=54
H=Q(23,100)
R=Q(27,100)
U=Q(1,2)+H*H+Q(99,70)*H
GLOBAL_RADIAL_MAX=Q(91,60)**2
DISK_Q=Q(1105,256)
assert GLOBAL_RADIAL_MAX+Q(91,60)+Q(1,2)-DISK_Q==Q(31,57600)

def squared_index(k):
    assert 0<=k<N
    return N+k*N-k*(k-1)//2

def clean(coeff,rhs,name):
    return tuple((k,v)for k,v in sorted(coeff.items())if v),Q(rhs),name

def radial_interval(positions,i):
    boxes=positions[2*i:2*i+2]
    lower=sum(Q(0)if a<=0<=b else min(a*a,b*b)for a,b in boxes)
    box_upper=sum(max(a*a,b*b)for a,b in boxes)
    return lower,min(box_upper,GLOBAL_RADIAL_MAX),box_upper

def generate(positions):
    assert len(positions)==18 and all(a<=b for a,b in positions)
    rows=[];labels=[];far=[];constants=[];candidates=[];upper={}
    for i in range(9):
        lo,hi,box_upper=radial_interval(positions,i);xx,yy=squared_index(2*i),squared_index(2*i+1)
        # Both hold on the entire physical parent, independently of nearness.
        rows.append(clean({xx:Q(-1),yy:Q(-1)},-R*R,f'all_nine_radial_lower_{i}'))
        rows.append(clean({xx:Q(1),yy:Q(1)},hi,f'all_nine_radial_upper_{i}'))
        if lo>=U:kind='far';far.append(i)
        elif hi<=U:kind='constant_indicator_upper';constants.append(i)
        else:kind='radial_indicator_upper';candidates.append(i);upper[i]=hi
        labels.append(dict(original=i,box_norm_lower=str(lo),box_norm_upper=str(box_upper),
                           global_norm_upper=str(GLOBAL_RADIAL_MAX),used_norm_upper=str(hi),classification=kind))
    C=len(constants)
    selections=[]
    if C<2:
        selections.append((None,list(candidates),Q(2-C)))
        if C==0:
            selections += [(omit,[i for i in candidates if i!=omit],Q(1))for omit in candidates]
    for omitted,selected,required in selections:
        co={};rhs=-required
        for i in selected:
            weight=1/(upper[i]-U)
            co[squared_index(2*i)]=weight;co[squared_index(2*i+1)]=weight
            rhs+=weight*upper[i]
        name='all_nine_near_cardinality_'+('all'if omitted is None else'omit_'+str(omitted))
        rows.append(clean(co,rhs,name))
    guards=dict(h=str(H),r=str(R),near_norm_upper=str(U),global_radial_upper=str(GLOBAL_RADIAL_MAX),
      labels=labels,far=far,constant_indicator_upper=constants,radial_indicator_upper=candidates,
      cardinality_rows=[name for co,b,name in rows if name.startswith('all_nine_near_cardinality_')])
    return rows,guards
