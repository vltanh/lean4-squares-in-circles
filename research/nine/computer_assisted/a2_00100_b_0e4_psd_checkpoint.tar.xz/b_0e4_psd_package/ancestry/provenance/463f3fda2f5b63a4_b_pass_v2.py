#!/usr/bin/env python3
import sys,json,argparse,traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'current_proof'))
import whole_parent_pass as M
ORIGINAL_INITIAL=M.initial

def initial(cell):
    old=M.HERE;M.HERE=HERE.parent/'current_proof'
    try:return ORIGINAL_INITIAL(cell)
    finally:M.HERE=old
M.initial=initial
sys.path.insert(0,str(HERE.parent/'rounded_support'))
import point_disk_rows as P
import frame_perspective_rows as F
import altitude_capacity_v2 as A
import strong_strip_rows as T
import owner_free_relative_support as S
OLD_COLLECT=M.collect

def collect(state,differences):
    rs,ab,tm,pos,sca,dif,g=OLD_COLLECT(state,differences)
    if not tm:
        rs+=F.rows(state['angles'],sca)
        rs+=P.generate_rows(sca,dif)
        extra,guards=T.rotated_three_square_rows(dif);rs+=extra;g+=guards
        radii={(i,j):S.support_radius_lower(state['angles'][i],state['angles'][j])for i,j in dif}
        extra,guards=A.generate_rows(dif,radii);rs+=extra;g+=guards
    return rs,ab,tm,pos,sca,dif,g

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--id');ap.add_argument('--rounds',type=int,default=5);ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=27);a=ap.parse_args()
    M.collect=collect;M.HERE=HERE/'v2';M.HERE.mkdir(exist_ok=True);M.VERSION='b_macro_joint_frame_pointdisk_sharp_capacity_v2'
    cells=json.loads(M.REG.read_text())['cells']
    cells=[c for c in cells if c['status']=='OPEN'and(c['id']==a.id if a.id else c['sign']=='negative'and c['path'][1][-1]==0)]
    if not a.id:cells=cells[a.start:a.stop]
    for c in cells:
        dest=M.HERE/'results'/(c['id']+'.json')
        if dest.exists():continue
        try:
            M.run(c,a.rounds)
            out=json.loads(dest.read_text());out['additional_sources']={str(p):M.sha(p)for p in [Path(__file__),Path(F.__file__),Path(P.__file__),Path(A.__file__),Path(T.__file__),Path(S.__file__)]}
            out['independent_review_status']='PENDING_NOT_ACCEPTED';dest.write_text(json.dumps(out,indent=2)+'\n')
        except Exception:
            print('ERROR',c['id'],traceback.format_exc(),flush=True)
if __name__=='__main__':main()
