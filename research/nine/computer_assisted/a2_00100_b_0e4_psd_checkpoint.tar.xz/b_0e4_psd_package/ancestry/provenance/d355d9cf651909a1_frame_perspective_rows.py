"""Exact convex perspective of each original frame's aligned inset.

For a=alpha>0,z=|beta|, t=z/a in[0,1], g=1/(2(a+z)), a²+z²=1:
2g/a = r(t)=(1+t²)/(1+t).  r''=4/(1+t)^3>0.
Tangents and secants in t turn into linear rows in (alpha,z,g).
Every supplied angle/scalar interval is a proved whole-parent interval.
"""
from fractions import Fraction as Q
from math import isqrt

DEN=1<<48

def root_lower(z):
    z=Q(z);assert z>=0
    n=isqrt(z.numerator*DEN*DEN//z.denominator)
    return Q(n,DEN)

def r(t):return (1+t*t)/(1+t)
def dr(t):return 1-2/(1+t)**2

def rows(angles,scalar):
    out=[]
    for i,(tl,tu) in enumerate(angles):
        al,au=scalar[i];zl,zu=scalar[18+i]
        assert 0<al<=au<=1 and 0<=zl<=zu<1
        m=Q(0) if tl<=0<=tu else min(abs(tl),abs(tu))
        M=max(abs(tl),abs(tu))
        m=max(m,zl/au);M=min(M,zu/al,Q(1));assert 0<=m<=M<=1
        for t in sorted({m,(m+M)/2,M,*[Q(k,4)for k in range(5)]}):
            q=dr(t);p=r(t)-t*q
            out.append((((18+i,p),(36+i,q),(45+i,Q(-2))),Q(0),f'physical_inset_perspective_tangent_{i}_{t}'))
        if m<M:
            q=(r(M)-r(m))/(M-m);p=r(m)-m*q
        else:p=r(m);q=Q(0)
        out.append((((18+i,-p),(36+i,-q),(45+i,Q(2))),Q(0),f'physical_inset_perspective_secant_{i}_{m}_{M}'))
        # Convex reciprocal s -> 1/(2s), using same folded frame.
        sl=max(Q(1),al+zl);su=min(au+zu,Q(99,70));assert sl<=su
        out.append((((18+i,Q(1)),(36+i,Q(1)),(45+i,2*sl*su)),sl+su,f'physical_inset_reciprocal_upper_{i}_{sl}_{su}'))
        for s in sorted({sl,(sl+su)/2,su}):
            out.append((((18+i,-Q(1)/(2*s*s)),(36+i,-Q(1)/(2*s*s)),(45+i,Q(-1))),-1/s,f'physical_inset_reciprocal_tangent_{i}_{s}'))
        # Lower chord of the concave folded unit-circle arc.
        if zl<zu:
            fl=root_lower(1-zl*zl);fu=root_lower(1-zu*zu)
            q=(fu-fl)/(zu-zl);p=fl-q*zl
            out.append((((18+i,Q(-1)),(36+i,q)),-p,f'physical_folded_arc_chord_{i}_{zl}_{zu}'))
        else:
            out.append((((18+i,Q(-1)),),-root_lower(1-zl*zl),f'physical_folded_arc_point_{i}_{zl}'))
    return out
