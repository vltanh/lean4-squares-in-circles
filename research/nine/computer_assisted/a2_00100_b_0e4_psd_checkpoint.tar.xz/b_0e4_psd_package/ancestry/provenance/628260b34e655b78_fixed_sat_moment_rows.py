"""Exact quadratic versions of SAT alternatives already in original paths."""
from fractions import Fraction as F
import sys
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/cd_family')
import quadratic_moment_rows as L

def rows(path):
 out=[]
 for k,step in enumerate(path):
  if step[0]!='sat':continue
  i,j=step[1];owner,axis,sign=step[2]
  assert owner in(i,j) and axis in(0,1) and sign in(-1,1)
  dx,dy=L.delta(i,j,0),L.delta(i,j,1)
  for eps in(-1,1):
   co={}
   L.add(co,L.mon(18+i,18+j),1);L.add(co,L.mon(27+i,27+j),1)
   L.add(co,L.mon(18+i,27+j),eps);L.add(co,L.mon(27+i,18+j),-eps)
   if axis==0:
    L.multiply(co,{18+owner:F(1)},dx,-2*sign)
    L.multiply(co,{27+owner:F(1)},dy,-2*sign)
   else:
    L.multiply(co,{18+owner:F(1)},dy,-2*sign)
    L.multiply(co,{27+owner:F(1)},dx,2*sign)
   out.append(L.clean(co,-1,f'moment_original_sat_{k}_{i}_{j}_{owner}_{axis}_{sign}_{eps}'))
 return out
