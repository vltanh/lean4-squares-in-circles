"""A planar four-point moment bound, applied to unchanged original centers.

Geometric input: four planar points separated pairwise by at least one
have sum of their six squared distances at least eight. Its independent
geometric proof is a prerequisite to accepting any resulting closure.
"""
from fractions import Fraction as Q
from itertools import combinations

def rows(differences):
    answer=[]
    for quad in combinations(range(9),4):
        coeff={};rhs=Q(-8)
        for i,j in combinations(quad,2):
            for ax,(lo,hi)in enumerate(differences[i,j]):
                coeff[2*i+ax]=coeff.get(2*i+ax,Q(0))+lo+hi
                coeff[2*j+ax]=coeff.get(2*j+ax,Q(0))-lo-hi
                rhs-=lo*hi
        answer.append((tuple((k,v)for k,v in sorted(coeff.items())if v),rhs,
                       'planar_four_center_sum_'+ '_'.join(map(str,quad))))
    return answer

def moment_rows(lift):
    answer=[]
    for quad in combinations(range(9),4):
        co={}
        for i,j in combinations(quad,2):
            for ax in range(2):
                lift.multiply(co,lift.delta(i,j,ax),lift.delta(i,j,ax),-1)
        answer.append(lift.clean(co,-8,'planar_four_center_moment_'+'_'.join(map(str,quad))))
    return answer
