"""Exact owner-square / other-original incircle rows, without a separator.

For d = c_j-c_i and z=(s*u_i+t*v_i)/2 in the SAME original square,
interior-disjointness implies |d-z| >= 1/2. Consequently
    |d|^2 - alpha_i*(s*dx+t*dy) - beta_i*(s*dy-t*dx)
        + (s*s+t*t-1)/4 >= 0.
We upper-bound |d|^2 by interval secants, and lower-bound each of
the two bilinear terms by either McCormick lower plane. All interval
inputs must be proved on the unchanged whole parent before use.
"""
from fractions import Fraction as Q
from itertools import combinations, product


def boundary_points(denominator=2):
    assert isinstance(denominator, int) and denominator > 0
    grid = [Q(k, denominator) for k in range(-denominator, denominator+1)]
    return sorted({(s, t) for s, t in product(grid, repeat=2)
                   if abs(s) == 1 or abs(t) == 1})


def projection(box, p, q):
    values = [p*x+q*y for x, y in product(*box)]
    return min(values), max(values)


def generate_rows(scalar, differences, points=None):
    """Return exact tuples (sparse coefficients, rhs, unique rule name).

    scalar contains 9 alpha, 9 beta, 9 |beta|, 9 inset intervals.
    differences[(i,j)] contains dx and dy intervals for c_j-c_i.
    Output variables use the frozen 54-original-variable convention.
    Both owner orientations are retained with the same d; the entire
    parameter set is centrally symmetric, so no sign change is needed.
    """
    if points is None:
        points = boundary_points()
    rows = []
    for i, j in combinations(range(9), 2):
        box = differences[(i, j)]
        (lx, ux), (ly, uy) = box
        assert lx <= ux and ly <= uy
        for owner in (i, j):
            alpha, beta = scalar[owner], scalar[owner+9]
            assert alpha[0] <= alpha[1] and beta[0] <= beta[1]
            for s, t in points:
                s, t = Q(s), Q(t)
                assert -1 <= s <= 1 and -1 <= t <= 1
                pbox = projection(box, s, t)
                qbox = projection(box, -t, s)
                for ap, bp in product((0, 1), repeat=2):
                    a0, p0 = alpha[ap], pbox[ap]
                    b0, q0 = beta[bp], qbox[bp]
                    cx = a0*s-b0*t-lx-ux
                    cy = a0*t+b0*s-ly-uy
                    coeff = {2*i:-cx, 2*j:cx,
                             2*i+1:-cy, 2*j+1:cy,
                             18+owner:p0, 27+owner:q0}
                    rhs = (s*s+t*t-1)/4-lx*ux-ly*uy+a0*p0+b0*q0
                    name = f'original_point_incircle_{i}_{j}_{owner}_{s}_{t}_{ap}_{bp}'
                    rows.append((tuple((k,v) for k,v in sorted(coeff.items()) if v),rhs,name))
    return rows


def residual_identity(dx, dy, a, b, abox, bbox, box, s, t, ap, bp):
    """Exact algebra control, not geometric evidence or a sampled proof."""
    (lx, ux), (ly, uy) = box
    p, q = s*dx+t*dy, s*dy-t*dx
    pbox, qbox = projection(box,s,t), projection(box,-t,s)
    a0, p0, b0, q0 = abox[ap], pbox[ap], bbox[bp], qbox[bp]
    lower = a0*p+p0*a-a0*p0+b0*q+q0*b-b0*q0
    upper = (lx+ux)*dx-lx*ux+(ly+uy)*dy-ly*uy
    exact = dx*dx+dy*dy-a*p-b*q+(s*s+t*t-1)/4
    derived = upper-lower+(s*s+t*t-1)/4
    reserve = (dx-lx)*(ux-dx)+(dy-ly)*(uy-dy)+(a-a0)*(p-p0)+(b-b0)*(q-q0)
    assert derived-exact == reserve
    return exact, derived, reserve
