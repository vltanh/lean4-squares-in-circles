"""Universal directional support-height physical pair rows.

For each rational unit n, physical nonoverlap implies
||d_ij|| >= 1 + |h_i(n)-h_j(n)|.
Proof: the Hausdorff distance between two centered unit squares at
relative angle eta is rho=(cos eta+|sin eta|-1)/2. Each rotated vertex
lies outside at most one side of the other square by at most rho;
convexity gives both inclusions S_i subset S_j+B_rho. Therefore every
unit-direction support difference is at most rho. The original SAT
common threshold gives ||d_ij|| >= 1+rho.

We use affine lower corner supports and upper absolute-value secants.
Since norm² >=1+2(1+t)(h_i-h_j)-t² for any t>=-1, every lower bound
h_i-h_j>=L yields norm² >=1+2(1+t)L-t². Square-difference secants
then give exact necessary rows, without bilinear original-frame terms.
"""
from fractions import Fraction as Q
from itertools import combinations,product

DIRECTIONS=((Q(1),Q(0)),)+tuple((Q(p,d),Q(q,d))for a,b,d in ((3,4,5),(5,12,13),(8,15,17),(7,24,25),(20,21,29),(9,40,41))for p,q in ((a,b),(b,a)))

def interval(ca,cb,a,b):
    vals=[ca*x+cb*y for x,y in product(a,b)]
    return min(vals),max(vals)

def abs_upper(ca,cb,a,b):
    lo,hi=interval(ca,cb,a,b)
    if lo>=0:return ca,cb,Q(0)
    if hi<=0:return -ca,-cb,Q(0)
    m=(hi+lo)/(hi-lo);c=-2*hi*lo/(hi-lo)
    return m*ca,m*cb,c

def rows(scalar,differences,tangents=(Q(0),Q(1,5))):
    out=[]
    for nidx,(p,q) in enumerate(DIRECTIONS):
        assert p*p+q*q==1
        supports=[]
        for i in range(9):
            a,b=scalar[i],scalar[9+i]
            u=abs_upper(p,q,a,b);v=abs_upper(q,-p,a,b)
            up=tuple((x+y)/2 for x,y in zip(u,v))
            lows=[]
            for s,t in product((-1,1),repeat=2):
                ca=(s*p+t*q)/2;cb=(s*q-t*p)/2
                if interval(ca,cb,a,b)[1]<=Q(1,2):continue
                lows.append((ca,cb,s,t))
            supports.append((up,lows))
        for i,j in combinations(range(9),2):
            (lx,ux),(ly,uy)=differences[i,j]
            for owner,other in ((i,j),(j,i)):
                ua,ub,uc=supports[other][0]
                for la,lb,s,t in supports[owner][1]:
                    for k in tangents:
                        k=Q(k);assert k>=-1;c=2*(1+k)
                        co={2*i:lx+ux,2*j:-(lx+ux),2*i+1:ly+uy,2*j+1:-(ly+uy),18+owner:c*la,27+owner:c*lb,18+other:-c*ua,27+other:-c*ub}
                        rhs=k*k-1-lx*ux-ly*uy+c*uc
                        name=f'directional_support_gap_{i}_{j}_{owner}_{nidx}_{s}_{t}_{k}'
                        out.append((tuple((k,v)for k,v in sorted(co.items())if v),rhs,name))
    return out
