"""Whole-parent three-original altitude-capacity rows.

Accepted three-square slice theorem: endpoint distance D >= f(altitude)
when middle projection lies on the endpoint segment and altitude <=7/10.
Each guard is reconstructed from complete old-state pair intervals.
"""
from fractions import Fraction as F
from itertools import combinations
from math import isqrt
DEN=1<<48

def root_lower(q):
    q=F(q);assert q>=0
    n=isqrt(q.numerator*DEN*DEN//q.denominator)
    return F(n,DEN)

def product(p,q):
    v=[x*y for x in p for y in q];return min(v),max(v)

def dot_lower(p,q):return sum(product(x,y)[0] for x,y in zip(p,q))
def det_upper(p,q):
    a,b=product(p[0],q[1]);c,d=product(p[1],q[0])
    return max(abs(a-d),abs(b-c))
def minnorm2(p):
    return sum(F(0) if a<=0<=b else min(a*a,b*b) for a,b in p)

def generate_rows(diffs,radii=None):
    def pair(i,j):
        if i<j:return diffs[i,j]
        return tuple((-b,-a)for a,b in diffs[j,i])
    def norm2lower(i,j,delta):
        r=F(1) if radii is None else radii[min(i,j),max(i,j)]
        return max(r*r,minnorm2(delta))
    rows=[];guards=[]
    for originals in combinations(range(9),3):
        for middle in originals:
            left,right=[k for k in originals if k!=middle]
            m=pair(left,middle);n=pair(middle,right);d=pair(left,right)
            mn=dot_lower(m,n)
            first=max(dot_lower(m,d),norm2lower(left,middle,m)+mn)
            last=max(dot_lower(n,d),norm2lower(middle,right,n)+mn)
            if first<0 or last<0:continue
            denominator=root_lower(norm2lower(left,right,d))
            numerator=min(det_upper(m,n),det_upper(m,d),det_upper(n,d))
            altitude=numerator/denominator
            if altitude>F(7,10):continue
            floor=min(F(2),F(280,99)-2*altitude)
            (a,b),(c,e)=d
            co={2*left:a+b,2*right:-(a+b),2*left+1:c+e,2*right+1:-(c+e)}
            rhs=-floor*floor-a*b-c*e
            name=f'original_stronger_altitude_capacity_{left}_{middle}_{right}'
            rows.append((tuple((k,v)for k,v in sorted(co.items())if v),rhs,name))
            guards.append({'triple':[left,middle,right],'projection_lower':[str(first),str(last)],'endpoint_distance_lower':str(denominator),'determinant_upper':str(numerator),'altitude_upper':str(altitude),'distance_lower':str(floor)})
    return rows,guards
