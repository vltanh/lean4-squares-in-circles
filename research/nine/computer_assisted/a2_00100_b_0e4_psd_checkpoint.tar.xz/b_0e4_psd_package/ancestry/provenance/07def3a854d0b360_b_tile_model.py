#!/usr/bin/env python3
"""Untrusted producer for one member of a frozen complete B-parent cover.

All constraints concern the same nine original physical squares.  This
module generates discovery rows; acceptance requires independent replay.
"""
import json
from fractions import Fraction as Q
from pathlib import Path

import joint_owned_axis_probe as J
import planar_four_center_rows as FC
import square_area_moment_rows as AREA

HERE = Path(__file__).resolve().parent
D = J.T
PARTS = 4


def collect(ident, tile, h_tile=None):
    manifest_path = HERE / 'fixed_i_grid_capacity' / ident / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    source = Path(manifest['parent_source'])
    assert J.sha(source) == manifest['parent_sha256']
    state, dd, dg, prior = D.read_prefix(source)
    assert not dg and state['path'] == manifest['path']
    positions = list(state['positions'])
    rectangle = []
    for axis, index in enumerate(tile):
        assert 0 <= index < PARTS
        lo, hi = positions[16 + axis]
        interval = (lo + (hi - lo) * index / PARTS,
                    lo + (hi - lo) * (index + 1) / PARTS)
        positions[16 + axis] = interval
        rectangle.append(list(map(str, interval)))
    h_rectangle = []
    if h_tile is not None:
        for axis, (index, count) in enumerate(zip(h_tile, (2, 4))):
            assert 0 <= index < count
            lo, hi = positions[14 + axis]
            interval = (lo + (hi - lo) * index / count,
                        lo + (hi - lo) * (index + 1) / count)
            positions[14 + axis] = interval
            h_rectangle.append(list(map(str, interval)))
    state = dict(state, positions=tuple(positions))
    allrows, ab, terminal, pos, scalar, differences, guards = D.P.M.collect(state, dd)
    assert terminal is None, terminal
    linear = [row for row in allrows if all(k < 54 for k, value in row[0])]
    linear += FC.rows(differences)
    matrices = list(AREA.axes_matrices()) + [
        ((Q(1), Q(1)), (Q(-1), Q(1))),
        ((Q(2), Q(1)), (Q(0), Q(1))),
        ((Q(2), Q(-1)), (Q(0), Q(1))),
        ((Q(1), Q(0)), (Q(1), Q(2))),
        ((Q(1), Q(0)), (Q(-1), Q(2))),
    ]
    linear += AREA.generate_linear(differences, matrices=matrices)
    rows, absolute, metadata = D.L.collect(
        linear, pos, scalar, state['angles'], differences, None, 'core')
    rows += J.S.rows(state['path'])
    owned_rows, owned_guards = J.U.generate(state['angles'], differences)
    rows += owned_rows
    nine_rows, nine_guards = J.G.generate(pos)
    rows += nine_rows
    squares = []
    oldmoment = J.OLD / 'b_family/moment_results' / (ident + '-fixed-sat-ipm.json')
    if oldmoment.exists():
        old = json.loads(oldmoment.read_text())
        assert old['prior'] == prior
        squares = old['squares']
        for square in squares:
            rows.append(D.L.psd_square_row(tuple(map(Q, square['coefficients'])), square['index']))
    rows += FC.moment_rows(D.L)
    rows += AREA.generate_quadratic(D.L, matrices=matrices)
    physical = dict(angles=D.P.M.render(state['angles']), positions=D.P.M.render(pos),
                    scalar=D.P.M.render(scalar), differences=D.P.M.render_diff(differences))
    source_modules = [__file__, J.__file__, D.__file__, D.L.__file__, D.P.M.__file__,
                      J.S.__file__, J.U.__file__, J.G.__file__, FC.__file__, AREA.__file__]
    frozen = dict(squares=squares, sources={str(Path(p)): J.sha(p) for p in source_modules})
    details = dict(prior=prior, metadata=metadata, physical_state=physical,
                   original_parent_path=state['path'], tile=list(tile), parts=PARTS,
                   rectangle=rectangle, h_tile=None if h_tile is None else list(h_tile),
                   h_rectangle=h_rectangle, h_parts=[2, 4] if h_tile is not None else None,
                   manifest_path=str(manifest_path), manifest_sha256=J.sha(manifest_path),
                   owned_axis_guards=owned_guards, all_nine_guards=nine_guards,
                   area_matrices=[[list(map(str, row)) for row in B] for B in matrices])
    return rows, absolute, state, details, frozen
