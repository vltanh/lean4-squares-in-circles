#!/usr/bin/env python3
"""Propose an exact rational certificate from an active numerical PSD dual.

Numerical discovery is discarded after selecting rows and rational squares.
This producer is not the independent physical geometry and cover checker.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import json
import sys
from fractions import Fraction as Q
from pathlib import Path
import numpy as np
import b_tile_model as BM

D = BM.D
HERE = Path(__file__).resolve().parent


def main():
    ident = sys.argv[1]
    tile = tuple(map(int, sys.argv[2:4]))
    h_tile = tuple(map(int, sys.argv[4:6])) if len(sys.argv) >= 6 else None
    out = HERE / ('tile_psd_B_' + ident + '_' + '_'.join(map(str, tile + (h_tile or ()))))
    record = json.loads((out / 'diagnostics.json').read_text())
    rows, absolute, state, details, frozen = BM.collect(ident, tile, h_tile)
    assert len(rows) == record['initial_rows']
    assert details['physical_state'] == record['physical_state']
    assert frozen['sources'] == record['sources']
    arrays = np.load(out / 'complete_numerical_state.npz')
    dual = arrays['linear_dual_normalized']
    assert len(dual) == len(rows)
    chosen = [i for i, value in enumerate(dual) if value > 1e-12]
    selected = [rows[i] for i in chosen]
    squares = record.get('new_rational_squares', [])
    assert squares, 'No positive numerical PSD dual supplied rational square candidates'
    for square in squares:
        selected.append(D.L.psd_square_row(tuple(map(Q, square['coefficients'])), square['index']))
    physical = details['physical_state']
    box_rows = D.L.box_rows(D.P.box(physical['positions']) + D.P.box(physical['scalar']))
    selected += box_rows
    h = D.P.M.highs(selected, D.L.SIZE)
    h.setOptionValue('solver', 'simplex')
    h.setOptionValue('time_limit', 120.)
    for k, bound in enumerate(absolute):
        h.changeColBounds(k, -float(bound), float(bound))
    print(ident, tile, h_tile, 'ACTIVE_ROWS', len(chosen), 'NEW_SQUARES', len(squares), flush=True)
    h.run()
    result = dict(schema='fixed_B_tile_active_psd_exact_candidate_v1', id=ident,
                  status='OPEN', originals_closed=0, source_indices=chosen,
                  new_squares=squares, box_rows_added=len(box_rows), **details,
                  solver_status=str(h.getModelStatus()),
                  input_diagnostics_sha256=BM.J.sha(out / 'diagnostics.json'),
                  producer_sha256=BM.J.sha(__file__))
    if h.getModelStatus() == D.P.M.H.HighsModelStatus.kOptimal:
        solution = h.getSolution()
        result['phase'] = float(solution.col_value[-1])
        terminal = D.exact_terminal(selected, absolute, solution)
        if terminal and terminal['kind'] == 'positive_exact_reserve':
            result.update(status='CANDIDATE_COMPLETE_TILE', terminal=terminal)
        elif terminal:
            result['rejected_candidate'] = terminal
    (out / 'active_box_exact_candidate.json').write_text(json.dumps(result, indent=2) + '\n')
    print(ident, tile, h_tile, result['status'], result.get('phase'),
          result.get('terminal', {}).get('reserve'), flush=True)


if __name__ == '__main__':
    main()
