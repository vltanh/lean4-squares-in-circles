"""Same-original quadratic rows and an exact rational moment lift.

All rows are necessary for the *same* nine physical squares.  A feasible
physical configuration embeds as X[i,j] = z[i]*z[j].  No LP moment is asserted
to equal that product, and numerical eigensolvers have no proof authority.
"""
from fractions import Fraction as Q
from itertools import combinations, combinations_with_replacement, product

N = 54
PAIRS = tuple(combinations_with_replacement(range(N), 2))
INDEX = {ij: N + k for k, ij in enumerate(PAIRS)}
SIZE = N + len(PAIRS)
QDISK = Q(1105, 256)

def mon(i,j):
    return INDEX[min(i,j),max(i,j)]

def add(co,k,v):
    co[k] = co.get(k,Q(0)) + Q(v)

def affine(co,v,scale=1):
    for k,c in v.items(): add(co,k,scale*c)

def multiply(co,v,w,scale=1):
    for i,a in v.items():
        for j,b in w.items(): add(co,mon(i,j),scale*a*b)

def clean(co,rhs,name):
    return tuple((k,v) for k,v in sorted(co.items()) if v),Q(rhs),name

def square(v,scale=1):
    co={};multiply(co,v,v,scale);return co

def delta(i,j,axis):
    return {2*j+axis:Q(1),2*i+axis:Q(-1)}

def lift_bounds(bounds):
    assert len(bounds)==N and all(a<=b for a,b in bounds)
    original=tuple(max(abs(a),abs(b)) for a,b in bounds)
    return original+tuple(original[i]*original[j] for i,j in PAIRS)

def box_rows(bounds):
    out=[]
    for i,(lo,hi) in enumerate(bounds):
        out.extend([clean({i:1},hi,f'moment_variable_upper_{i}'),
                    clean({i:-1},-lo,f'moment_variable_lower_{i}')])
    for i,j in PAIRS:
        a,b=bounds[i];c,d=bounds[j];k=mon(i,j)
        for e,f in ((a,c),(b,d)):
            co={k:Q(-1)};add(co,i,f);add(co,j,e)
            out.append(clean(co,e*f,f'moment_mccormick_lower_{i}_{j}_{e}_{f}'))
        for e,f in ((a,d),(b,c)):
            co={k:Q(1)};add(co,i,-f);add(co,j,-e)
            out.append(clean(co,-e*f,f'moment_mccormick_upper_{i}_{j}_{e}_{f}'))
        if i==j:
            out.append(clean({k:-1},0,f'moment_square_nonnegative_{i}'))
            t=(a+b)/2
            out.append(clean({i:2*t,k:-1},t*t,f'moment_square_midpoint_{i}_{t}'))
    return out

def physical_rows(angles,differences,diagonal=None):
    out=[]
    for i in range(9):
        x,y,a,b,z,g=2*i,2*i+1,18+i,27+i,36+i,45+i
        for name,co,rhs in (
            ('unit',{mon(a,a):1,mon(b,b):1},1),
            ('absolute',{mon(z,z):1,mon(b,b):-1},0),
            ('reciprocal',{mon(a,g):2,mon(z,g):2},1)):
            for sg in(-1,1):
                out.append(clean({k:sg*v for k,v in co.items()},sg*rhs,f'moment_frame_{name}_{i}_{sg}'))
        lo,hi=angles[i]
        out.append(clean({mon(b,b):1,mon(a,b):-(lo+hi),mon(a,a):lo*hi},0,
                         f'moment_orientation_interval_{i}_{lo}_{hi}'))
        for s,t in product((-1,1),repeat=2):
            co={mon(x,x):Q(1),mon(y,y):Q(1),mon(x,a):Q(s),mon(y,b):Q(s),
                mon(y,a):Q(t),mon(x,b):Q(-t)}
            out.append(clean(co,QDISK-Q(1,2),f'moment_corner_circle_{i}_{s}_{t}'))
    points=sorted({(Q(a,2),Q(b,2)) for a,b in product(range(-2,3),repeat=2)
                   if abs(a)==2 or abs(b)==2})
    for i,j in combinations(range(9),2):
        dx,dy=delta(i,j,0),delta(i,j,1)
        negnorm=square(dx,-1);multiply(negnorm,dy,dy,-1)
        out.append(clean(negnorm,-1,f'moment_unit_pair_{i}_{j}'))
        for v in map(Q,('-7/8','-3/4','-1/2','-1/4','0','1/4','1/2','3/4','7/8')):
            co=dict(negnorm);multiply(co,dx,dy,2*v)
            multiply(co,{45+i:Q(1),45+j:Q(1)},{45+i:Q(1),45+j:Q(1)},1-v*v)
            out.append(clean(co,0,f'moment_inset_ellipse_{i}_{j}_{v}'))
        height={18+i:Q(1,2),36+i:Q(1,2),18+j:Q(-1,2),36+j:Q(-1,2)}
        for sg in(-1,1):
            co=dict(negnorm);multiply(co,height,height);affine(co,height,2*sg)
            out.append(clean(co,-1,f'moment_support_height_{i}_{j}_{sg}'))
        # R=(1+c+|s|)/2 <= physical pair distance.  R^2 >= 2*t*R-t^2.
        relative_cos={mon(18+i,18+j):Q(1),mon(27+i,27+j):Q(1)}
        relative_sin={mon(18+i,27+j):Q(1),mon(27+i,18+j):Q(-1)}
        for t,sg in product((Q(1),Q(9,8),Q(5,4)),(-1,1)):
            co=dict(negnorm);affine(co,relative_cos,t);affine(co,relative_sin,t*sg)
            out.append(clean(co,t*t-t,f'moment_relative_support_{i}_{j}_{t}_{sg}'))
        for owner in(i,j):
            for s,t in points:
                co=dict(negnorm)
                multiply(co,{18+owner:Q(1)},dx,s);multiply(co,{18+owner:Q(1)},dy,t)
                multiply(co,{27+owner:Q(1)},dy,s);multiply(co,{27+owner:Q(1)},dx,-t)
                out.append(clean(co,(s*s+t*t-1)/4,f'moment_point_incircle_{i}_{j}_{owner}_{s}_{t}'))
        expressions=[(0,dx,differences[i,j][0]),(1,dy,differences[i,j][1])]
        if diagonal and(i,j)in diagonal:
            for k in range(2):
                v=dict(dx);affine(v,dy,1 if k==0 else-1)
                expressions.append((2+k,v,diagonal[i,j][k]))
        for k,v,(lo,hi) in expressions:
            co=square(v);affine(co,v,-(lo+hi))
            out.append(clean(co,-lo*hi,f'moment_difference_secant_{i}_{j}_{k}_{lo}_{hi}'))
    return out

RLT_PREFIXES=('cone_','alternate_','chain_','guard_','left_','DG_','CD_',
              'extras_','remaining_','orientation_','axis_support_',
              'accepted_','certified_difference_', 'ordered_','abs_equal_',
              'width_','fold_order','arc_','physical_frame_')

def rlt_rows(linear_rows,bounds,mode='core'):
    """Products of a certified nonnegative affine slack and a bound slack.

    Each selected source row is multiplied against every original variable.
    The row's frozen source index is retained; no inferred moment relation is
    multiplied, and no branch assumption is introduced.
    """
    out=[];selected=[]
    if mode=='none':return out,selected
    for source,(terms,rhs,name) in enumerate(linear_rows):
        if not name.startswith(RLT_PREFIXES):continue
        assert all(k<N for k,c in terms)
        v=dict(terms);selected.append(source)
        for k,(lo,hi) in enumerate(bounds):
            # (rhs-Az)(z_k-lo)>=0 and (rhs-Az)(hi-z_k)>=0.
            co={};multiply(co,v,{k:Q(1)});affine(co,v,-lo);add(co,k,-rhs)
            out.append(clean(co,-rhs*lo,f'moment_rlt_lower_{source}_{k}'))
            co={};multiply(co,v,{k:Q(1)},-1);affine(co,v,hi);add(co,k,rhs)
            out.append(clean(co,rhs*hi,f'moment_rlt_upper_{source}_{k}'))
    return out,selected

def collect(linear_rows,positions,scalar,angles,differences,diagonal=None,rlt='core'):
    """Reusable collector; caller supplies certified unchanged-parent data."""
    bounds=tuple(positions)+tuple(scalar)
    assert len(bounds)==N and all(k<N for co,b,n in linear_rows for k,c in co)
    rows=list(linear_rows)+box_rows(bounds)+physical_rows(angles,differences,diagonal)
    rrows,sources=rlt_rows(linear_rows,bounds,rlt);rows+=rrows
    return rows,lift_bounds(bounds),dict(original_variables=N,moment_variables=SIZE,
         initial_linear_rows=len(linear_rows),initial_total_rows=len(rows),
         rlt_source_indices=sources,rlt_rows=len(rrows),rlt_mode=rlt)

def psd_square_row(q,index):
    """Exact expansion of -(q[0]+sum q[i+1]*z[i])^2 <= 0."""
    assert len(q)==N+1
    v={k:q[k+1] for k in range(N) if q[k+1]}
    co=square(v,-1);affine(co,v,-2*q[0])
    return clean(co,q[0]*q[0],f'moment_psd_square_{index}')
