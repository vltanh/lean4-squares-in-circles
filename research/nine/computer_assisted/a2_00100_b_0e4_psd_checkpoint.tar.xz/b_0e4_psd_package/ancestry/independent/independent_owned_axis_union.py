"""Independent exact guard and polynomial replay of complete owned-axis unions.

No producer, optimizer or numerical eigenvalue code is imported. Projection
bounds are proved by exact comparisons with the finite radical extrema.
"""
from fractions import Fraction as F
from itertools import product,combinations
from math import isqrt
from pathlib import Path
import sys
sys.path.insert(0,'/workspace/scratch/0220f3e5a56d/a_family')
import independent_moment_rows as P

def le_radical(q,n,d):
    assert d>0
    if n>=0:return q<=0 or q*q*d<=n*n
    return q<0 and q*q*d>=n*n

def radical_in(lo,hi,n,d):
    return le_radical(lo,n,d)and le_radical(-hi,-n,d)

def owned_frame(i,a):
    c,s=P.variable(18+i),P.variable(27+i)
    return (c,s)if a==0 else(P.times_constant(s,-1),c)
def dot(v,w):return P.combine(P.product(v[0],w[0]),P.product(v[1],w[1]))
def relative(i,j):
    u,v=owned_frame(i,0),owned_frame(j,0)
    return dot(u,v),P.minus(P.product(u[0],v[1]),P.product(u[1],v[0]))
def projection(i,j,o,a,sg=1):
    d=tuple(P.minus(P.variable(2*j+k),P.variable(2*i+k))for k in(0,1))
    return P.times_constant(dot(d,owned_frame(o,a)),sg)
def rational_box(x):return tuple(tuple(map(F,a))for a in x)
def map_vertices(box,diagonal):
    for x,y in product(*box):yield ((x+y)/2,(x-y)/2)if diagonal else(x,y)
def extrema_at_vertex(x,y,angle,axis):
    X,Y=(x,y)if axis==0 else(y,-x)
    slopes=list(angle)
    if X and angle[0]<=Y/X<=angle[1]:slopes.append(Y/X)
    return [(X+t*Y,1+t*t)for t in slopes]
def outward80(n,d):
    scale=1<<80;k=isqrt((d.numerator*scale*scale)//d.denominator)
    lo=F(k,scale);hi=lo if lo*lo==d else F(k+1,scale)
    return (n/hi,n/lo)if n>=0 else(n/lo,n/hi)

class Replay:
    def __init__(self,angles,differences,diagonal,guards):
        self.angles=angles;self.differences=differences;self.diagonal=diagonal
        self.rows={};self.alternative_count=0;self.eliminated=0;self.projection_comparisons=0
        assert len(guards)==36
        pairs=[tuple(g['pair'])for g in guards];assert pairs==list(combinations(range(9),2))
        for g in guards:self.check_pair(g)
    def put(self,poly,name):
        assert name not in self.rows
        self.rows[name]=P.inequality(poly,name)
    def rectangle_extrema(self,pair,owner,axis):
        out=[]
        for box,diagonal in [(self.differences[pair],False)]+([(self.diagonal[pair],True)]if pair in self.diagonal else[]):
            out.append([r for x,y in map_vertices(box,diagonal)for r in extrema_at_vertex(x,y,self.angles[owner],axis)])
        return out
    def check_projection(self,pair,owner,axis,sign,lo,hi):
        assert lo<=hi
        domains=self.rectangle_extrema(pair,owner,axis)
        # Each one-sided bound may be proved on either containing rectangle.
        assert any(all(le_radical(lo,sign*n,d)for n,d in rs)for rs in domains)
        assert any(all(le_radical(-hi,-sign*n,d)for n,d in rs)for rs in domains)
        self.projection_comparisons+=sum(map(len,domains))*2
    def check_delta(self,pair,axis,claimed):
        ranges=[]
        for box,diag in [(self.differences[pair],False)]+([(self.diagonal[pair],True)]if pair in self.diagonal else[]):
            vertex_ranges=[]
            for x,y in map_vertices(box,diag):
                ranges_at=[]
                for owner in pair:
                    vals=[outward80(n,d)for n,d in extrema_at_vertex(x,y,self.angles[owner],axis)]
                    ranges_at.append((min(a for a,b in vals),max(b for a,b in vals)))
                (a,b),(c,d)=ranges_at;vertex_ranges.append((a-d,b-c))
            ranges.append((min(a for a,b in vertex_ranges),max(b for a,b in vertex_ranges)))
        lo=max(a for a,b in ranges);hi=min(b for a,b in ranges)
        assert lo<=hi and claimed>=max(abs(lo),abs(hi))
    def check_pair(self,g):
        i,j=g['pair'];pair=i,j;cb=tuple(map(F,g['relative_cos']));sb=tuple(map(F,g['relative_sin']))
        assert 0<=cb[0]<=cb[1]<=1 and -1<=sb[0]<=sb[1]<=1
        a,b=self.angles[i],self.angles[j]
        for x,y in [(a[1],b[0]),(a[0],b[1])]:
            den=(1+x*x)*(1+y*y)
            assert radical_in(*cb,1+x*y,den)and radical_in(*sb,y-x,den)
        if max(a[0],b[0])<=min(a[1],b[1]):assert cb[0]<=1<=cb[1]
        c,s=relative(i,j)
        for tag,expr,ab in [('cos',c,cb),('sin',s,sb)]:
            self.put(P.minus(expr,P.number(ab[1])),f'owned_axis_relative_upper_{i}_{j}_{tag}')
            self.put(P.minus(P.number(ab[0]),expr),f'owned_axis_relative_lower_{i}_{j}_{tag}')
        expected=list(product((i,j),(0,1),(-1,1)))
        actual=[(a['owner'],a['axis'],a['sign'])for a in g['alternatives']];assert actual==expected
        alive=[]
        for a in g['alternatives']:
            owner,axis,sign=a['owner'],a['axis'],a['sign'];lo,hi=map(F,a['projection'])
            self.check_projection(pair,owner,axis,sign,lo,hi)
            p=projection(i,j,owner,axis,sign)
            if sign==1:
                self.put(P.minus(p,P.number(hi)),f'owned_axis_projection_upper_{i}_{j}_{owner}_{axis}')
                self.put(P.minus(P.number(lo),p),f'owned_axis_projection_lower_{i}_{j}_{owner}_{axis}')
            tt={};bounds={}
            for eps in(-1,1):
                sl,su=sb if eps==1 else(-sb[1],-sb[0])
                lower,upper=2*lo-cb[1]-su,2*hi-cb[0]-sl
                assert tuple(map(F,a['t_bounds'][str(eps)]))==(lower,upper)
                tt[eps]=P.combine(P.times_constant(p,2),P.times_constant(c,-1),P.times_constant(s,-eps));bounds[eps]=(lower,upper)
            eliminated=hi<1 or any(u<1 for l,u in bounds.values());assert a['eliminated']==eliminated
            self.alternative_count+=1;self.eliminated+=eliminated
            if not eliminated:alive.append(dict(owner=owner,axis=axis,sign=sign,p=p,pb=(lo,hi),t=tt,tb=bounds))
        assert g['surviving']==len(alive)
        if not alive:
            assert g.get('empty_cover')is True
            self.put(P.number(1),f'owned_axis_empty_complete_cover_{i}_{j}')
            assert not g['union_rows']and not g['close_axis_rows'];return
        actual_union=[]
        for eps in(-1,1):
            if any(a['tb'][eps][0]>=1 for a in alive):continue
            poly=P.number(1)
            for a in alive:
                lo=a['tb'][eps][0]
                poly=P.minus(poly,P.times_constant(P.minus(a['t'][eps],P.number(lo)),1/(1-lo)))
            self.put(poly,f'owned_axis_complete_union_{i}_{j}_{eps}');actual_union.append(eps)
        assert g['union_rows']==actual_union
        unit=all(a['pb'][0]<1 for a in alive);assert bool(g.get('unit_union',False))==unit
        if unit:
            poly=P.number(1)
            for a in alive:
                lo=a['pb'][0];poly=P.minus(poly,P.times_constant(P.minus(a['p'],P.number(lo)),1/(1-lo)))
            self.put(poly,f'owned_axis_unit_union_{i}_{j}')
        close=(len(alive)==2 and{a['owner']for a in alive}=={i,j}and len({(a['axis'],a['sign'])for a in alive})==1)
        assert bool(g['close_axis_rows'])==close
        if close:
            data=g['close_axis_rows'];delta=F(data['delta']);axis=alive[0]['axis'];sign=alive[0]['sign']
            assert(data['axis'],data['sign'])==(axis,sign);self.check_delta(pair,axis,delta)
            for a in alive:
                for eps in(-1,1):
                    self.put(P.minus(P.number(1-2*delta),a['t'][eps]),f'owned_axis_close_pair_{i}_{j}_{a["owner"]}_{axis}_{sign}_{eps}')
    def rebuild(self,name):return self.rows[name]
