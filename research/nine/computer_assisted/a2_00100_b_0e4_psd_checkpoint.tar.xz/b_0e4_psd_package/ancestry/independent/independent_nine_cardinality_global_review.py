#!/usr/bin/env python3
"""Independent semantic-polynomial reconstruction of every global-nine row.

Standard library only. Imports neither the producer, its existing checker,
the moment generator, nor a numerical package. Square-monomial indices are
obtained by explicit lexicographic enumeration, not the producer's formula.
The mathematical precondition is exactly the all-nine closed-Q packing
premise plus the caller's independently certified original center boxes.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations_with_replacement
import hashlib,json,re

ORIGINAL_DIMENSION=54
MONOMIALS=tuple((i,j)for i in range(ORIGINAL_DIMENSION)for j in range(i,ORIGINAL_DIMENSION))
LIFTED_INDEX={ij:ORIGINAL_DIMENSION+k for k,ij in enumerate(MONOMIALS)}
assert len(MONOMIALS)==1485 and len(LIFTED_INDEX)==1485
assert LIFTED_INDEX[0,0]==54 and LIFTED_INDEX[53,53]==1538
H=F(23,100)
RADIAL_FLOOR=(F(1,2)-H)**2
GLOBAL_UPPER=F(91,60)**2
NEAR_UPPER=F(1,2)+H*H+H*F(99,70)
assert F(99,70)**2>2 and NEAR_UPPER==F(61473,70000)
assert GLOBAL_UPPER+F(91,60)+F(1,2)-F(1105,256)==F(31,57600)>0


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical_box(positions):
    assert len(positions)==18
    ans=tuple(tuple(F(v)for v in interval)for interval in positions)
    assert all(len(interval)==2 and interval[0]<=interval[1]for interval in ans)
    return ans


def classify(positions):
    positions=canonical_box(positions);labels=[];far=[];constants=[];radial=[];maxima={}
    for original in range(9):
        least=F(0);greatest=F(0)
        for lower,upper in positions[2*original:2*original+2]:
            endpoints=(lower*lower,upper*upper)
            least+=F(0)if lower<=0<=upper else min(endpoints)
            greatest+=max(endpoints)
        maximum=min(greatest,GLOBAL_UPPER)
        # Strict physical near upper means >= at the lower endpoint proves
        # non-nearness, including equality. This test has first priority.
        if least>=NEAR_UPPER:
            kind='far';far.append(original)
        elif maximum<=NEAR_UPPER:
            kind='constant_indicator_upper';constants.append(original)
        else:
            kind='radial_indicator_upper';radial.append(original);maxima[original]=maximum
            assert maximum-NEAR_UPPER>0
        labels.append({'original':original,'box_norm_lower':str(least),
            'box_norm_upper':str(greatest),'global_norm_upper':str(GLOBAL_UPPER),
            'used_norm_upper':str(maximum),'classification':kind})
    return labels,far,constants,radial,maxima


def expected_names(positions):
    _,far,constants,radial,maxima=classify(positions)
    names=[f'all_nine_radial_{kind}_{i}'for i in range(9)for kind in('lower','upper')]
    if len(constants)<2:
        names.append('all_nine_near_cardinality_all')
        if not constants:names += [f'all_nine_near_cardinality_omit_{i}'for i in radial]
    return names


def polynomial(name,positions):
    """Return {semantic monomial (z-index,z-index): coefficient}, rhs.

    The returned statement is sum coefficient*z_i*z_j <= rhs. Its lifted
    row is only a necessary relaxation of that same-original polynomial.
    """
    positions=canonical_box(positions)
    labels,far,constants,radial,maxima=classify(positions)
    match=re.fullmatch(r'all_nine_radial_(lower|upper)_([0-8])',name)
    if match:
        kind,tag=match.groups();i=int(tag)
        coefficient=F(-1)if kind=='lower'else F(1)
        rhs=-RADIAL_FLOOR if kind=='lower'else F(labels[i]['used_norm_upper'])
        return {(2*i,2*i):coefficient,(2*i+1,2*i+1):coefficient},rhs
    assert name in expected_names(positions),('unjustified_cardinality_row_or_omission',name)
    assert len(constants)<2
    if name=='all_nine_near_cardinality_all':
        selected=radial;required=F(2-len(constants))
    else:
        match=re.fullmatch(r'all_nine_near_cardinality_omit_([0-8])',name)
        assert match is not None and not constants
        omitted=int(match.group(1));assert omitted in radial
        selected=[i for i in radial if i!=omitted];required=F(1)
    # Each retained term is an upper bound for its actual near indicator.
    # Far indicators are zero; constants contribute at most one. The only
    # nontrivial choices have zero or one constant, since every f_i>=0.
    poly={};rhs=-required
    for i in selected:
        denominator=maxima[i]-NEAR_UPPER;assert denominator>0
        factor=1/denominator
        poly[2*i,2*i]=factor;poly[2*i+1,2*i+1]=factor
        rhs+=maxima[i]*factor
    return poly,rhs


def physical_row(name,positions):
    poly,rhs=polynomial(name,positions)
    coefficients=tuple(sorted((LIFTED_INDEX[monomial],coefficient)for monomial,coefficient in poly.items()if coefficient))
    return coefficients,rhs,name


def expected_guards(positions):
    labels,far,constants,radial,maxima=classify(positions)
    return {'h':str(H),'r':str(F(1,2)-H),'near_norm_upper':str(NEAR_UPPER),
        'global_radial_upper':str(GLOBAL_UPPER),'labels':labels,'far':far,
        'constant_indicator_upper':constants,'radial_indicator_upper':radial,
        'cardinality_rows':[name for name in expected_names(positions)if name.startswith('all_nine_near_cardinality_')]}


def verify_tables(filename):
    path=Path(filename);data=json.loads(path.read_text())
    assert data['schema']=='all_nine_quadratic_cardinality_literal_rows_v1'
    assert sha(data['producer']['path'])==data['producer']['sha256']
    assert sha(data['hand_proof']['path'])==data['hand_proof']['sha256']
    reports=[];seen=set();total=0
    for entry in data['states']:
        source=Path(entry['path']);assert sha(source)==entry['sha256']
        record=json.loads(source.read_text());ident=record['id'];assert ident==entry['id']and ident not in seen;seen.add(ident)
        assert record['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and record['new_branch_nodes']==0
        pos=canonical_box(record['physical_state']['positions'])
        assert pos==canonical_box(entry['positions'])
        prior=record['prior'];assert sha(prior['path'])==prior['sha256']
        previous=json.loads(Path(prior['path']).read_text());assert previous['id']==ident and previous['path']==record['path']
        previous_pos=previous['final']['positions']if 'final'in previous else previous['final_positions']
        assert pos==canonical_box(previous_pos),'The supplied positions must equal the certified final parent box.'
        review=Path(entry['prior_review']['path']);assert sha(review)==entry['prior_review']['sha256']
        accepted=json.loads(review.read_text())
        assert accepted['id']==ident and accepted['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
        assert accepted['certificate_sha256']==prior['sha256']
        names=expected_names(pos)
        assert [r['name']for r in entry['rows']]==names
        assert entry['guards']==expected_guards(pos)
        semantics=[]
        for row in entry['rows']:
            terms,rhs,name=physical_row(row['name'],pos)
            assert terms==tuple((int(i),F(v))for i,v in row['coefficients'])
            assert rhs==F(row['rhs'])
            poly,constant=polynomial(name,pos)
            assert all(i==j and 0<=i<18 for i,j in poly)
            semantics.append({'name':name,'polynomial':[[list(m),str(c)]for m,c in sorted(poly.items())],
                              'rhs':str(constant)})
        guards=expected_guards(pos);number=len(names);total+=number
        reports.append({'id':ident,'state_path':str(source),'state_sha256':entry['sha256'],
            'certified_prior_sha256':prior['sha256'],'prior_review_sha256':entry['prior_review']['sha256'],
            'physical_positions_equal_certified_prior':True,'rows_checked':number,
            'radial_rows':18,'cardinality_rows':number-18,'far_originals':guards['far'],
            'constant_indicator_upper_originals':guards['constant_indicator_upper'],
            'radial_indicator_upper_originals':guards['radial_indicator_upper'],
            'semantically_reconstructed_rows':semantics})
    assert len(reports)==4
    report={'schema':'independent_all_nine_quadratic_cardinality_review_v1',
        'status':'PASS_ALL_FOUR_CERTIFIED_STATE_ROW_TABLES','states_checked':len(reports),
        'rows_checked':total,'physical_scope':'nine actual original unit squares, closed Q, disjoint open interiors; certified original center boxes',
        'producer_or_existing_checker_imported':False,'solver_imported':False,
        'semantic_polynomial_reconstruction':True,'square_indices_independently_enumerated':True,
        'far_equality_endpoint_checked':True,'constant_classification_does_not_assert_nearness':True,
        'all_and_single_omission_family_complete_among_nontrivial_indicator_upper_bound_choices':True,
        'near_pair_or_other_branch_selected':False,'new_originals_closed':0,'new_masks_closed':0,
        'whole_original_closure_claimed':False,'lean_lake_ci_run':False,
        'literal_table_sha256':sha(path),'producer_sha256':data['producer']['sha256'],
        'hand_proof_sha256':data['hand_proof']['sha256'],'reviewer_sha256':sha(__file__),
        'upstream_state_reviews_replayed_in_this_check':False,
        'upstream_scope_note':'Existing exact-state reviews are source-bound by certificate hash; this check validates all new rows and rechecks the copied positions, not the previously reviewed full bound inductions.',
        'reports':reports}
    dest=Path(__file__).with_name('all_nine_cardinality_global_review.json')
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='reports'},indent=2))
    for item in reports:print(item['id'],item['rows_checked'],'rows; far',item['far_originals'],'constant',item['constant_indicator_upper_originals'],'radial',item['radial_indicator_upper_originals'])
    return report

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('literal_tables');args=parser.parse_args()
    verify_tables(args.literal_tables)
