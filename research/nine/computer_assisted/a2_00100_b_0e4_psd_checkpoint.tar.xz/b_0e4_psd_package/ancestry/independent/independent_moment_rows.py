"""Independent exact reconstruction of same-original quadratic necessary rows.

This module imports no row producer or solver.  It expands degree-at-most-two
polynomials in the 54 original physical variables.  The caller independently
rebuilds any affine RLT premise before exposing it through linear_source(index).
All named intervals and square coefficients are checked against supplied data.
"""
from fractions import Fraction as Q

N=54
SIZE=N+N*(N+1)//2

def number(x):return {():Q(x)}if Q(x)else{}
def variable(i):
    assert type(i)is int and 0<=i<N
    return {(i,):Q(1)}
def combine(*polys):
    out={}
    for p in polys:
        for key,val in p.items():out[key]=out.get(key,Q(0))+val
    return {key:v for key,v in out.items()if v}
def times_constant(p,c):return {key:Q(c)*v for key,v in p.items()if Q(c)*v}
def product(p,q):
    out={}
    for a,x in p.items():
        for b,y in q.items():
            key=tuple(sorted(a+b));assert len(key)<=2
            out[key]=out.get(key,Q(0))+x*y
    return {key:v for key,v in out.items()if v}
def minus(p,q):return combine(p,times_constant(q,-1))
def norm2(x,y):return combine(product(x,x),product(y,y))
def product_index(i,j):
    assert 0<=i<=j<N
    # Sum the row lengths 54,53,... preceding row i, then offset j-i.
    return N+i*N-i*(i-1)//2+j-i

def inequality(poly,name):
    co={}
    for key,v in poly.items():
        if not key:continue
        index=key[0]if len(key)==1 else product_index(*key)
        co[index]=co.get(index,Q(0))+v
    return tuple((k,v)for k,v in sorted(co.items())if v),-poly.get((),Q(0)),name

def lifted_absolute_bounds(positions,scalar):
    b=tuple(positions)+tuple(scalar);assert len(b)==N and all(l<=u for l,u in b)
    m=tuple(max(abs(l),abs(u))for l,u in b)
    return m+tuple(m[i]*m[j]for i in range(N)for j in range(i,N))

class Rebuilder:
    def __init__(self,positions,scalar,angles,differences,diagonal=None,squares=(),linear_source=None,linear_count=None):
        self.positions=tuple(positions);self.scalar=tuple(scalar);self.bounds=self.positions+self.scalar
        self.angles=tuple(angles);self.differences=differences;self.diagonal=diagonal or{}
        assert len(self.positions)==18 and len(self.scalar)==36 and len(self.angles)==9
        assert all(l<=u for l,u in self.bounds)and all(-1<=l<=u<=1 for l,u in self.angles)
        self.squares={}
        for s in squares:
            i=s['index'];q=tuple(map(Q,s['coefficients']))
            assert type(i)is int and i>=0 and i not in self.squares and len(q)==N+1
            self.squares[i]=q
        self.linear_source=linear_source;self.linear_count=linear_count;self._source_polynomials={}
    def linear_polynomial(self,index):
        assert type(index)is int and 0<=index<self.linear_count and self.linear_source is not None
        if index not in self._source_polynomials:
            row,rhs,name=self.linear_source(index);p=number(-rhs);seen=set()
            for k,v in row:
                assert type(k)is int and 0<=k<N and k not in seen;seen.add(k)
                p=combine(p,times_constant(variable(k),Q(v)))
            self._source_polynomials[index]=p
        return self._source_polynomials[index]
    def delta(self,i,j,axis):
        assert 0<=i<j<9 and axis in(0,1)
        return minus(variable(2*j+axis),variable(2*i+axis))
    def reduce_unit(self,p,i):
        """Replace equal alpha_i^2 and beta_i^2 coefficients using their sum=1."""
        a,b=18+i,27+i;ca=p.get((a,a),Q(0));cb=p.get((b,b),Q(0));assert ca==cb
        p=dict(p);p.pop((a,a),None);p.pop((b,b),None)
        return combine(p,number(ca))
    def rebuild(self,name):
        p=name.split('_');assert p[0]=='moment'
        if p[1]=='variable':
            assert len(p)==4 and p[2]in('lower','upper');i=int(p[3]);assert 0<=i<N
            lo,hi=self.bounds[i]
            poly=minus(number(lo),variable(i))if p[2]=='lower'else minus(variable(i),number(hi))
        elif p[1]=='mccormick':
            assert len(p)==7 and p[2]in('lower','upper');i,j=int(p[3]),int(p[4]);assert 0<=i<=j<N
            a,b=map(Q,p[5:]);l,u=self.bounds[i];v,w=self.bounds[j]
            if p[2]=='lower':assert(a,b)in((l,v),(u,w));sg=-1
            else:assert(a,b)in((l,w),(u,v));sg=1
            poly=times_constant(product(minus(variable(i),number(a)),minus(variable(j),number(b))),sg)
        elif p[1:3]==['square','nonnegative']:
            assert len(p)==4;i=int(p[3]);assert 0<=i<N;poly=times_constant(product(variable(i),variable(i)),-1)
        elif p[1:3]==['square','midpoint']:
            assert len(p)==5;i=int(p[3]);assert 0<=i<N;t=Q(p[4]);assert t==sum(self.bounds[i])/2
            v=minus(variable(i),number(t));poly=times_constant(product(v,v),-1)
        elif p[1]=='frame':
            assert len(p)==5 and p[2]in('unit','absolute','reciprocal');i,sg=int(p[3]),int(p[4]);assert 0<=i<9 and sg in(-1,1)
            a,b,z,g=(variable(k+i)for k in(18,27,36,45))
            if p[2]=='unit':poly=minus(norm2(a,b),number(1))
            elif p[2]=='absolute':poly=minus(product(z,z),product(b,b))
            else:poly=minus(times_constant(product(g,combine(a,z)),2),number(1))
            poly=times_constant(poly,sg)
        elif p[1:3]==['orientation','interval']:
            assert len(p)==6;i=int(p[3]);assert 0<=i<9;l,u=map(Q,p[4:]);assert(l,u)==self.angles[i]
            a,b=variable(18+i),variable(27+i)
            poly=product(minus(b,times_constant(a,l)),minus(b,times_constant(a,u)))
        elif p[1:3]==['corner','circle']:
            assert len(p)==6;i,s,t=map(int,p[3:]);assert 0<=i<9 and s in(-1,1)and t in(-1,1)
            x,y,a,b=(variable(k)for k in(2*i,2*i+1,18+i,27+i))
            px=combine(x,times_constant(a,Q(s,2)),times_constant(b,Q(-t,2)))
            py=combine(y,times_constant(b,Q(s,2)),times_constant(a,Q(t,2)))
            poly=self.reduce_unit(minus(norm2(px,py),number(Q(1105,256))),i)
        elif p[1:3]==['unit','pair']:
            assert len(p)==5;i,j=map(int,p[3:]);dx,dy=self.delta(i,j,0),self.delta(i,j,1)
            poly=minus(number(1),norm2(dx,dy))
        elif p[1:3]==['inset','ellipse']:
            assert len(p)==6;i,j=int(p[3]),int(p[4]);v=Q(p[5]);assert abs(v)<1
            dx,dy=self.delta(i,j,0),self.delta(i,j,1);g=combine(variable(45+i),variable(45+j))
            poly=combine(times_constant(product(g,g),1-v*v),times_constant(norm2(dx,dy),-1),times_constant(product(dx,dy),2*v))
        elif p[1:3]==['support','height']:
            assert len(p)==6;i,j,sg=map(int,p[3:]);assert sg in(-1,1)
            dx,dy=self.delta(i,j,0),self.delta(i,j,1)
            hi=times_constant(combine(variable(18+i),variable(36+i)),Q(1,2))
            hj=times_constant(combine(variable(18+j),variable(36+j)),Q(1,2))
            v=combine(number(1),times_constant(minus(hi,hj),sg));poly=minus(product(v,v),norm2(dx,dy))
        elif p[1:3]==['relative','support']:
            assert len(p)==7;i,j=int(p[3]),int(p[4]);t=Q(p[5]);sg=int(p[6]);assert t>0 and sg in(-1,1)
            dx,dy=self.delta(i,j,0),self.delta(i,j,1)
            ai,bi,aj,bj=(variable(k)for k in(18+i,27+i,18+j,27+j))
            cos=combine(product(ai,aj),product(bi,bj));sin=minus(product(ai,bj),product(bi,aj))
            poly=combine(times_constant(norm2(dx,dy),-1),times_constant(cos,t),times_constant(sin,sg*t),number(t-t*t))
        elif p[1:3]==['point','incircle']:
            assert len(p)==8;i,j,o=map(int,p[3:6]);s,t=map(Q,p[6:]);assert o in(i,j)
            assert max(abs(s),abs(t))==1 and s*2 in range(-2,3)and t*2 in range(-2,3)
            dx,dy=self.delta(i,j,0),self.delta(i,j,1);a,b=variable(18+o),variable(27+o)
            px=combine(dx,times_constant(a,-s/2),times_constant(b,t/2))
            py=combine(dy,times_constant(b,-s/2),times_constant(a,-t/2))
            poly=self.reduce_unit(minus(number(Q(1,4)),norm2(px,py)),o)
        elif p[1:3]==['difference','secant']:
            assert len(p)==8;i,j,k=map(int,p[3:6]);lo,hi=map(Q,p[6:]);assert k in(0,1,2,3)
            dx,dy=self.delta(i,j,0),self.delta(i,j,1)
            if k<2:v=dx if k==0 else dy;assert(lo,hi)==self.differences[i,j][k]
            else:
                assert(i,j)in self.diagonal and(lo,hi)==self.diagonal[i,j][k-2]
                v=combine(dx,times_constant(dy,1 if k==2 else-1))
            poly=product(minus(v,number(lo)),minus(v,number(hi)))
        elif p[1]=='rlt':
            assert len(p)==5 and p[2]in('lower','upper');source,k=map(int,p[3:]);assert 0<=k<N
            row=self.linear_polynomial(source);lo,hi=self.bounds[k]
            slack=minus(variable(k),number(lo))if p[2]=='lower'else minus(number(hi),variable(k))
            poly=product(row,slack)
        elif p[1:3]==['psd','square']:
            assert len(p)==4;index=int(p[3]);q=self.squares[index];v=number(q[0])
            for k,c in enumerate(q[1:]):v=combine(v,times_constant(variable(k),c))
            poly=times_constant(product(v,v),-1)
        else:raise AssertionError(('unsupported_moment_rule',name))
        return inequality(poly,name)
