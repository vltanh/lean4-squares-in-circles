#!/usr/bin/env python3
"""Independent standard-library replay of a fixed B-parent I-center cover.

The source-bound original ancestor is replayed before every tile is attached
to its exact closed rectangle.  A partial cover explicitly earns no closure.
Numerical discovery modules are never imported.
"""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ANCESTRY = HERE / 'ancestry'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def install():
    from b_replay_context import install as install_context
    J, locate = install_context(ANCESTRY)
    return J


def four_row(name, differences):
    parts = name.split('_')
    assert parts[:4] == ['planar', 'four', 'center', 'sum'] and len(parts) == 8
    selected = tuple(map(int, parts[4:]))
    assert tuple(sorted(set(selected))) == selected and len(selected) == 4
    assert all(0 <= k < 9 for k in selected)
    coefficients = [F(0)] * 18
    rhs = F(-8)
    for i, j in combinations(selected, 2):
        for axis, (lo, hi) in enumerate(differences[i, j]):
            rhs -= lo * hi
            coefficients[2 * i + axis] += lo + hi
            coefficients[2 * j + axis] -= lo + hi
    return tuple((i, v) for i, v in enumerate(coefficients) if v), rhs, name


def area_row(name, differences):
    parts = name.split('_')
    assert parts[:4] == ['square', 'area', 'moment', 'secant'] and len(parts) == 9
    selected = tuple(map(int, parts[4].split('-')))
    assert tuple(sorted(set(selected))) == selected and 2 <= len(selected) <= 9
    assert all(0 <= k < 9 for k in selected)
    a, b, c, d = map(F, parts[5:])
    k = len(selected)
    rhs = F(k * k, 12) * (a*a+b*b+c*c+d*d) - F(7*k**3, 44) * abs(a*d-b*c)
    coefficients = [F(0)] * 18
    for i, j in combinations(selected, 2):
        for x, y in ((a, b), (c, d)):
            endpoints = [x*u+y*v for u, v in product(*differences[i, j])]
            lo, hi = min(endpoints), max(endpoints)
            rhs -= lo * hi
            for axis, scale in enumerate((x, y)):
                coefficients[2*i+axis] += (lo+hi)*scale
                coefficients[2*j+axis] -= (lo+hi)*scale
    return tuple((i, v) for i, v in enumerate(coefficients) if v), rhs, name


def physical_row(name, scalar, differences, angles, J):
    if name.startswith('planar_four_center_sum_'):
        return four_row(name, differences)
    if name.startswith('square_area_moment_secant_'):
        return area_row(name, differences)
    return J.rebuild_joint(name, scalar, differences, angles, J.point_row)


def verify_tile(record, parent, J):
    K = J.K
    tile = record['tile']
    ix, iy = divmod(tile, 4)
    assert type(tile) is int and 0 <= tile < 16
    assert record['parent_id'] == parent['id'] and record['target_original'] == 8
    assert (record['ix'], record['iy']) == (ix, iy)
    positions = list(parent['positions'])
    for axis, index in enumerate((ix, iy)):
        lo, hi = positions[16 + axis]
        positions[16 + axis] = (lo+(hi-lo)*F(index, 4), lo+(hi-lo)*F(index+1, 4))
    assert record['center_box'] == K.view(positions[16:18])
    if record['status'] == 'OPEN':
        return dict(tile=tile, status='OPEN', new_original_closures=0)
    assert record['status'] == 'CANDIDATE_CLOSED'
    state = dict(parent, positions=tuple(positions))
    effective, early = K.V.effective_boxes(state['angles'], state['choices'], K.LEGACY)
    assert early is None
    propagated, hs, gs, early = K.V.center_bounds(effective, state['positions'], state['choices'], K.LEGACY)
    terminal = record['terminal']
    if terminal['kind'] == 'exact_interval_or_accepted_terminal':
        assert type(terminal['label']) is str
        assert terminal['label'] == early, ('interval terminal mismatch', early, terminal['label'])
        return dict(tile=tile, status='PASS_EXACT_INTERVAL', label=early, rows=0)
    assert terminal['kind'] == 'positive_exact_reserve' and early is None
    base, absolute, positions, scalar, differences, guards = K.rebuild(
        state['path'], state['angles'], state['positions'], state['choices'], state['scalar'], state['differences'])
    assert record['propagated_positions'] == K.view(positions)
    assert record['physical_scalar_intersection'] == K.view(scalar)
    assert record['effective_differences'] == K.diffview(differences)
    assert list(map(str, absolute)) == terminal['absolute_variable_bounds']
    entries = terminal['rows']
    indices = [e['index'] for e in entries]
    assert len(indices) == len(set(indices))
    rows = list(base)
    rows += [((), F(0), 'UNUSED_UNVERIFIED')] * max(0, max(indices, default=-1) + 1 - len(rows))
    for entry in entries:
        index = entry['index']
        assert type(index) is int and 0 <= index < record['rows']
        if index >= len(base):
            rows[index] = physical_row(entry['name'], scalar, differences, state['angles'], J)
        coefficients, rhs, name = rows[index]
        assert name == entry['name'] and rhs == F(entry['rhs'])
        assert [(i, F(v)) for i, v in entry['coefficients'] if F(v)] == [(i, v) for i, v in coefficients if v], name
    assert set(indices) == {i for i, weight in terminal['weights']}
    coefficients, rhs = K.sum_rows(rows, absolute, terminal['weights'])
    reserve = -rhs - sum(bound * abs(value) for bound, value in zip(absolute, coefficients))
    assert reserve > 0 and reserve == F(terminal['reserve'])
    assert rhs == F(terminal['weighted_rhs'])
    assert coefficients == list(map(F, terminal['weighted_coefficients']))
    return dict(tile=tile, status='PASS_EXACT_POSITIVE_RESERVE', reserve=str(reserve), rows=len(entries))


def run(ident):
    started = time.monotonic()
    J = install()
    folder = HERE / 'data/fixed_i_grid_capacity' / ident
    manifest = json.loads((folder / 'manifest.json').read_text())
    prefix = J.local_source(manifest['parent_source'])
    assert digest(prefix) == manifest['parent_sha256']
    prefix_report, parent = J.replay(prefix, allow_open=True, return_state=True)
    assert prefix_report['status'] == 'PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert manifest['id'] == ident == parent['id'] and manifest['path'] == parent['path']
    assert manifest['target_original'] == 8 and manifest['original_count'] == 9
    assert manifest['grid_size'] == [4, 4] and manifest['adaptive_splits'] == 0
    assert manifest['center_box'] == J.K.view(parent['positions'][16:18])
    results = []
    certificates = {}
    for tile in range(16):
        path = folder / f'tile_{tile:02d}.json'
        record = json.loads(path.read_text())
        assert record['tile'] == tile
        results.append(verify_tile(record, parent, J))
        certificates[str(path)] = digest(path)
        print(ident, 'AFFINE TILE', tile, results[-1]['status'], flush=True)
    opened = [result['tile'] for result in results if result['status'] == 'OPEN']
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy'))
    report = dict(schema='independent_B_fixed_I_affine_cover_v1', id=ident, path=parent['path'],
                  status='PASS_AFFINE_PARTIAL_COVER_REMAINDER_EXPLICIT' if opened else 'PASS_COMPLETE_ORIGINAL_PARENT',
                  exact_prefix_report=prefix_report, prefix_sha256=digest(prefix),
                  tiles=results, remaining_I_tiles=opened, closed_face_cover_tiles=16,
                  new_original_closures=int(not opened), whole_masks_closed=0,
                  certificate_sha256=certificates, checker_sha256=digest(__file__),
                  numerical_producer_or_optimizer_imported=False, seconds=time.monotonic()-started)
    dest = HERE / ('AFFINE_REPLAY_' + ident + '.json')
    dest.write_text(json.dumps(report, indent=2) + '\n')
    print(ident, report['status'], 'remaining', opened, 'seconds', round(report['seconds'], 2), flush=True)
    return report, parent


if __name__ == '__main__':
    assert __debug__
    run(sys.argv[1])
