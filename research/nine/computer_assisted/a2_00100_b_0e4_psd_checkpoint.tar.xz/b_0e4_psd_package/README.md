# B0e4: one complete original cell

This portable packet excludes `negative-0e4fa3209b6f7b12` of mask
`001/00`. It provides one original-cell closure and zero mask closures.

Run the full independent exact replay:

```sh
python -B -S verify_all.py
```

The replay uses standard-library Python and no numerical optimizer.
All required ancestry bytes are included. A strict audit hook confines
workspace reads to this directory, so previous scratch directories are
not needed.

The complete proof has a fixed 4×4 closed cover of the I center, with
eight affine rational contradictions, seven exact interval
contradictions, and one quadratic rational contradiction. It retains
the same nine original physical squares, all 36 corners and pairs,
the exact original path and the strict CD predicate.

`HAND_PROOF.md` explains the physical implications and finite cover.
`COVER_TABLE.json` lists all sixteen outcomes and checked rational
reserve floors. `COMPLETE_REPLAY.json` is the combined independent
report. The three records for the last quadratic tile live under
`data/psd/`; the original sixteen discovery records under
`data/fixed_i_grid_capacity/` retain their original candidate labels.
Only the complete combined replay earns an original-cell closure.

The historical geometry and prefix checkers are preserved byte for
byte under `ancestry/`. `b_replay_context.py` supplies explicit portable
path bindings. Numerical discovery sources are included as frozen
provenance but are never imported by the exact replay. The numerical
semidefinite state is unnecessary: the certificate consists of explicit
rational rows, rational square coefficients and positive rational
weights.

No Lean, Lake or CI was run.
