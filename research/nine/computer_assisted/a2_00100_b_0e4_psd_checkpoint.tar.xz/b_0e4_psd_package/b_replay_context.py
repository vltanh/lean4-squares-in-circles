"""Resolve historical source names only to frozen bytes inside this packet.

No numerical producer is imported.  The unchanged earlier exact checker
receives explicit path bindings and a replay cache, not new geometric rules.
"""
from pathlib import Path
import copy
import hashlib
import json
import sys


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def install(ancestry, strict_root=None):
    ancestry = Path(ancestry).resolve()
    inventory = json.loads((ancestry / 'MANIFEST.json').read_text())
    bindings = json.loads((ancestry / 'SOURCE_BINDINGS.json').read_text())
    for name, expected in inventory['frozen_file_sha256'].items():
        target = (ancestry / name).resolve()
        assert target.is_relative_to(ancestry)
        assert digest(target) == expected, ('frozen ancestry changed', name)

    def locate(name):
        path = Path(name)
        if str(path) in bindings:
            answer = (ancestry / bindings[str(path)]).resolve()
            assert answer.is_relative_to(ancestry)
            return answer
        if not path.is_absolute():
            answer = (ancestry / path).resolve()
            assert answer.is_relative_to(ancestry)
            return answer
        if path.resolve().is_relative_to(ancestry):
            return path.resolve()
        raise FileNotFoundError('No explicit frozen source binding: ' + str(path))

    if strict_root is not None:
        strict_root = Path(strict_root).resolve()
        assert ancestry.is_relative_to(strict_root)

        def audit(event, arguments):
            if event == 'open' and arguments and isinstance(arguments[0], (str, bytes)):
                name = arguments[0].decode() if isinstance(arguments[0], bytes) else arguments[0]
                path = Path(name).resolve()
                if str(path).startswith('/workspace/'):
                    assert path.is_relative_to(strict_root), ('unbound external workspace read', str(path))
        sys.addaudithook(audit)

    legacy = ancestry / 'legacy/current_proof'
    for directory in (legacy, legacy / 'shared_capacity_three_b_v4',
                      legacy / 'shared_capacity_three_b_v4/geometry',
                      legacy / 'shared_capacity_three_b_v4/sources', ancestry / 'independent'):
        sys.path.insert(0, str(directory))
    import verify_joint_original as J
    assert Path(J.__file__).resolve() == legacy / 'verify_joint_original.py'
    J.local_source = locate
    J.digest = lambda name: digest(locate(name))
    raw_replay = J.replay
    cache = {}

    def replay(path, *args, **kwargs):
        target = locate(path)
        key = (str(target), digest(target), repr(args), repr(kwargs))
        if key not in cache:
            cache[key] = raw_replay(target, *args, **kwargs)
        return copy.deepcopy(cache[key])
    J.replay = replay
    return J, locate
