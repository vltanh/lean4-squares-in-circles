#!/usr/bin/env python3
"""Replay all sixteen exact rectangles and close one unchanged original cell."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent
IDENT = 'negative-0e4fa3209b6f7b12'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert __debug__, 'Assertions are part of this exact replay.'
    started = time.monotonic()
    inventory = json.loads((HERE / 'SHA256_MANIFEST.json').read_text())
    for name, expected in inventory['files'].items():
        path = (HERE / name).resolve()
        assert path.is_relative_to(HERE) and digest(path) == expected, ('frozen file changed', name)
    from verify_b_active_psd_tiles import Checker
    checker = Checker(HERE, HERE / 'ancestry', HERE)
    import verify_b_affine_cover as affine
    affine_report, parent = affine.run(IDENT)
    assert affine_report['status'] == 'PASS_AFFINE_PARTIAL_COVER_REMAINDER_EXPLICIT'
    assert affine_report['remaining_I_tiles'] == [3]
    filename = HERE / 'data/psd' / ('tile_psd_B_' + IDENT + '_0_3') / 'active_box_exact_candidate.json'
    psd_report = checker.replay(filename)
    assert psd_report['status'] == 'PASS_COMPLETE_PHYSICAL_TILE'
    assert psd_report['id'] == IDENT and psd_report['tile'] == [0, 3]
    assert psd_report['original_parent_path'] == parent['path']
    assert psd_report['coordinate_divisions'] == [4, 4]
    table = json.loads((HERE / 'COVER_TABLE.json').read_text())
    assert table['id'] == IDENT and table['parts'] == [4, 4] and table['original'] == 8
    assert [entry['tile'] for entry in table['entries']] == list(range(16))
    outcomes = {entry['tile']: entry for entry in affine_report['tiles']}
    assert set(outcomes) == set(range(16))
    assert outcomes[3]['status'] == 'OPEN'
    outcomes[3] = dict(tile=3, status='PASS_EXACT_PSD_RESERVE', reserve=psd_report['reserve'],
                       rows=psd_report['terminal_rows'])
    for entry in table['entries']:
        tile = entry['tile']
        assert entry['indices'] == list(divmod(tile, 4))
        actual = outcomes[tile]
        assert actual['status'] == entry['status'] and actual['rows'] == entry['rows']
        if 'reserve_floor' in entry:
            assert F(actual['reserve']) >= F(entry['reserve_floor']) > 0
        else:
            assert actual['label'] == entry['label']
    assert len(outcomes) == 16 and all(entry['status'].startswith('PASS_EXACT_') for entry in outcomes.values())
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy'))
    report = dict(schema='complete_B_original_I_cover_v1', id=IDENT, path=parent['path'],
                  status='PASS_COMPLETE_ORIGINAL_PARENT', original_center=8,
                  original_physical_squares=9, original_corners=36, original_pairs=36,
                  fixed_closed_rectangle_cover=[4, 4], cover_rectangles=16,
                  strict_CD_original_path_retained=True, h_subdivisions=0,
                  affine_terminals=8, interval_terminals=7, psd_terminals=1,
                  terminal_rows=sum(entry['rows'] for entry in outcomes.values()),
                  prefix_sha256=affine_report['prefix_sha256'], affine_report=affine_report,
                  psd_report=psd_report, table_sha256=digest(HERE / 'COVER_TABLE.json'),
                  new_original_cells=1, new_masks=0, whole_mask_closed=False,
                  source_bound_original_ancestor_replayed=True,
                  independent_exact_rows_and_nonnegative_weights=True,
                  numerical_producer_or_optimizer_imported=False,
                  all_workspace_reads_confined_to_packet=True, lean_lake_ci_run=False,
                  seconds=time.monotonic()-started)
    (HERE / 'COMPLETE_REPLAY.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ('id', 'status', 'cover_rectangles', 'terminal_rows',
          'new_original_cells', 'new_masks', 'seconds')}), flush=True)
    return report


if __name__ == '__main__':
    main()
