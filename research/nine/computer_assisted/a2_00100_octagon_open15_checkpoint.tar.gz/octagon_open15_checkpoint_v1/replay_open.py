#!/usr/bin/env python3
"""Exact partial replay. Unproved frontier paths always remain OPEN."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
COMBINED=HERE/'physical_pilots/combined_bounds'
ACCEPTED_SOURCE_MANIFEST='f9cb4c494e97974b3d92c1e94e60ebae3f6dfbfd02d6696281eab6af529d3676'


def verify_manifest():
    manifest=json.loads((HERE/'manifest.json').read_bytes())
    for name,digest in manifest['files'].items():
        assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
    raw=(HERE/'accepted_D_source_manifest.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==ACCEPTED_SOURCE_MANIFEST
    accepted=json.loads(raw)
    for name in manifest['unchanged_source_files']:
        assert manifest['files'][name]==accepted['files'][name],name
    return manifest


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path)
    ap.add_argument('--original',help='Optional one-original partial replay.')
    args=ap.parse_args()
    manifest=verify_manifest()
    ids=json.loads((HERE/'original_ids.json').read_bytes())
    assert len(ids)==len(set(ids))==15
    if args.original:
        assert args.original in ids
        ids=[args.original]
    sys.path.insert(0,str(COMBINED))
    import review_octagon as checker
    register=json.loads((COMBINED/'whole_cell_payload/fixed_231_register.json').read_bytes())
    registry={r['id']:r for r in register['cells']}
    results=[]
    for name in ids:
        raw=(HERE/'records'/(name+'.json')).read_bytes()
        record=json.loads(raw)
        assert record['id']==name and record['status']=='OPEN' and record['frontier']
        prefix=(HERE/'prefixes'/(name+'.json')).read_bytes()
        result,tables=checker.review_parent(record,prefix,registry)
        assert result['status']=='PASS_PARTIAL_LEAVES_ONLY' and not result['whole_parent_closed']
        # Frontier terminals are deliberately unproved: they are used only
        # to verify that the retained partition covers the original caller.
        complete_partition=record['leaves']+[{'path':f['path']} for f in record['frontier']]
        checker.verify_complete_union(record['path'],complete_partition)
        result.update(whole_parent_closed=False,whole_mask_closed=False,
                      retained_frontier=len(record['frontier']),partition_includes_unproved_frontier=True,
                      complete_partial_partition_checked=True,record_sha256=hashlib.sha256(raw).hexdigest())
        results.append(result)
        del tables
        print('PARTIAL',name,'proved leaves',result['leaves_checked'],
              'OPEN paths',result['retained_frontier'],flush=True)
    report={'schema':'optional_open15_exact_partial_replay','status':'PASS_PARTIAL_LEAVES_AND_PARTITION_ONLY',
            'originals_checked':len(results),'whole_original_parents_closed':0,'whole_mask_closed':False,
            'verified_bound_deductions':sum(r['bound_deductions'] for r in results),
            'verified_leaves':sum(r['leaves_checked'] for r in results),
            'remaining_frontier_paths':sum(r['retained_frontier'] for r in results),
            'manifest_files_checked':len(manifest['files']),'results':results}
    if args.out:
        target=args.out.resolve()
        assert not target.is_relative_to(HERE),'Keep the checkpoint immutable.'
        target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))


if __name__=='__main__':
    main()
