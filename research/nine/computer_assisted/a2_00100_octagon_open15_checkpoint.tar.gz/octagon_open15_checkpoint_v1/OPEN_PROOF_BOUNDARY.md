# Optional OPEN research checkpoint: exact proof boundary

This checkpoint preserves **15 OPEN original parents** from the accepted
231-cell `001/00` cover. It closes zero original parents and zero masks.
It was captured after the bounded C/D transfer experiment and before any
further inspection of the two smallest remaining frontiers.

Every record preserves the original ID and full original path. Its caller
contains the same nine independently oriented physical unit squares, all
original corners and pairs, and the unchanged strict `001/00` marked bits
at `q<Q=1105/256`. The accepted common normalization and prior geometric
theorems retain their original scopes. A saved LP point is never a new
caller, an actual packing, or a proof of feasibility.

## What is proved

The inherited coordinate-bound prefixes consist of finite acyclic rational
row-sum deductions on the entire original parent. Their exact bytes are
bound by each record's `prefix_sha256`. Numerical interval summaries inside
those prefix files are ignored by the independent checker.

Every retained proof leaf carries an exact positive-reserve rational
contradiction in the frozen `disk_octagon_structural_v3` context. The
included standard-library checker regenerates the unchanged version14
physical rows, adds the exact versioned path and guarded rows, and sums the
recorded rational weights. It uses no producer or numerical optimizer.

The union of all proved leaves **and all retained unproved frontier paths**
is checked as a complete partition of each original parent. Exhaustiveness
of that partial partition does not turn an unproved frontier into a proof.
The replay explicitly reports `whole_parent_closed=false` for every record.

## What remains unproved

The records contain 1028 unproved frontier paths across the 15 originals.
Each path stopped at the finite node cap. None is a solver-failure frontier,
and none is asserted to contain a valid physical packing. The accepted
leaves prove only the corresponding proper descendants. Every original
parent in this checkpoint remains OPEN regardless of how many of its other
descendants have been discharged.

The smallest frontiers are `negative-2f9ffd3df06e7c5f` with six paths and
`negative-573078fc944ce553` with seventeen. Their final saved paths are the
complete named domains for any subsequent inspection. Replacing a parent
by one sampled point or by only its already discharged descendants would
invalidate the intended coverage claim.

## Source and theorem boundary

All producer and checker sources under `sharp_frame/` and
`physical_pilots/combined_bounds/` are byte-for-byte copies of the accepted
D-method bundle. The copied accepted manifest has SHA256
`f9cb4c494e97974b3d92c1e94e60ebae3f6dfbfd02d6696281eab6af529d3676`.
The replay checks both the present manifest and this independent source
binding. The accepted version14 verifier has SHA256
`ec1b7de7b15bcc9d89d12087bff974c68e6d056bdaae26b482d514027ec97993`.

`ACCEPTED_V3_METHOD_HAND_PROOF.md` is an unchanged copy of the accepted D
method's hand proof. Its specific D-cell counts refer to that separate
completed certificate, not these OPEN originals. Its general rational
octagon union, ordered complements, original-selector theorem, guarded
consequences, and bound-induction arguments supply the reused row semantics.
The unchanged unique-penultimate hand theorem is under `global_masks/`.

These hand results use earlier accepted low-gap, endpoint-order, C-slant,
physical inset, and strict `000/00` cap theorems with their documented
scopes. The numerical source copies do not re-prove those earlier tables,
and this optional checkpoint introduces no new geometric assumption.
Strict-radius theorems are not advertised as closed-boundary exclusions.

The benchmark and search records document finite discovery only. NumPy,
SciPy, solver statuses, and search-order choices are not proof premises.
No Lean, Lake, CI, new required gate, ledger modification, or publication
action is part of this checkpoint.
