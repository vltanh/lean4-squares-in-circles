# Portable optional OPEN checkpoint

This archive preserves 15 unchanged original C/D parents, their complete
retained partial partitions, exact coordinate-bound prefixes, and unchanged
versioned sources. **All 15 originals remain OPEN.** Read
`OPEN_PROOF_BOUNDARY.md` before interpreting the replay result.

Run the independent partial proof and coverage check with Python 3.12 or
later, from any directory:

```bash
python /path/to/octagon_open15_checkpoint_v1/replay_open.py
```

To save the result, choose a destination outside the immutable bundle:

```bash
python /path/to/octagon_open15_checkpoint_v1/replay_open.py --out /tmp/open15_review.json
```

For one original:

```bash
python /path/to/octagon_open15_checkpoint_v1/replay_open.py --original negative-2f9ffd3df06e7c5f
```

The replay uses only Python's standard library. It checks manifest hashes,
byte identity with the accepted D sources, exact parent-bound induction,
every retained rational contradiction leaf, and complete coverage by proved
leaves plus explicitly unproved frontier paths. It never reports a complete
original-parent proof.

`records/` contains the final unchanged producer records and numerical
fallback diagnostics. `prefixes/` contains their exact inherited bound
certificates. Absolute source-file paths in the producer metadata have no
authority; the portable replay passes the local prefix bytes explicitly.
`original_ids.json` identifies the 15 retained parents.

The accepted source layout is preserved so relative imports remain valid.
The accompanying transfer benchmark includes the separate five completed
parents only as context; their completed certificates are not in this OPEN
bundle. This checkpoint contains no new required task or acceptance gate.
