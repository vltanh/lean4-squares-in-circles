# Exact parent bounds followed by original physical pair separation

The fixed input for each record is its unchanged original path in the accepted
231-cell `001/00` cover. The input retains all nine original physical squares,
their independent shared frames, all original corners and pairs, exact marked
bits, and the existing normalized root and path conditions. No numerical point
defines a proof domain. The same original path remains the reported parent.

## Acyclic coordinate bounds

Begin with the exact position intervals decoded from that parent. In one bound
round, regenerate the accepted version14 physical rows from those intervals,
the unchanged original angle intervals, and all original path choices. Write
the rows as `a_j z <= b_j` and valid absolute variable bounds as `|z_k| <= M_k`.
For a recorded coordinate `k`, sign `s` in `{-1,1}`, and nonnegative rational
weights `lambda_j`, put

    r = sum_j lambda_j a_j - s e_k,
    B = sum_j lambda_j b_j.

Summing the rows and bounding the residual gives

    s z_k <= B + sum_l M_l |r_l|.

The checker proves that the right-hand side is at most the recorded rational
upper bound `U`. It may therefore intersect the current interval with
`s z_k <= U`. All proposals in one round use the same pre-round intervals;
their proved bounds become available in the following round. This gives a
finite induction with no circular use of a tightened interval.

The records' numerical `before_box`, `before_pos`, and `current_pos` fields
have no authority. The exact checker rebuilds the intervals from the original
path and the rational proofs. Every proof remains attached to the same fixed
original parent, so its final coordinate bounds hold on every descendant.

## Physical child coverage

Every new tree split is either the complete four-way original-inset separation
for one physical pair, or the complete eight-way separating-axis choice for
one physical pair. The unchanged frame of square `i` contains an axis-aligned
inset of halfwidth `g_i=1/[2(alpha_i+|beta_i|)]`. Disjoint square interiors force
one of the four signed coordinate gaps to be at least `g_i+g_j`. Alternatively,
the separating-axis theorem supplies one of the two side axes of either
original square, with one of its two signs. All four or eight closed children
are retained. Their union covers the whole caller, including contact faces.

The independently reconstructed trie rejects a missing child, a duplicate
leaf, a prefix mismatch, or a leaf that is an ancestor of another leaf.
Every original parent's complete tree must close. Unfinished descendants
remain research records attached to an OPEN original parent.

## Leaf proof under inherited bounds

At a child path, first decode its original angles, positions, and choices with
the unchanged path decoder. Intersect its position intervals with the already
proved parent coordinate bounds. Angles and physical choices are unchanged.
The accepted version14 exact row routine is then evaluated in a private
namespace whose `reconstruct` returns exactly that certified state for exactly
the requested child path. It cannot install a new frame, branch condition,
unproved position, or unrelated parent's bound.

The frozen row formulas, row indices, auxiliary product semantics, absolute
variable bounds, and analytic terminals remain those of version14. Narrower
proved intervals make their McCormick and geometric envelopes valid for the
same physical originals. A new weighted leaf supplies nonnegative rational
weights and proves

    -sum_j lambda_j b_j - sum_k M_k |sum_j lambda_j a_jk| > 0.

The resulting contradiction is an exact sum of valid original-square rows.
An interval or accepted analytic terminal is checked directly. A retained
earlier leaf without `uses_inherited_bounds` is replayed at its original path
state; it receives no new assumption.

## Source and replay

`run_combined.py` performs discovery and a first exact replay. The separate
`review_combined.py` does not import the producer. It reconstructs the bound
induction, collects unweighted rows, sums rational weights independently, and
checks complete child unions. Its printed tables include every used bound and
leaf row. `review_tight_bounds_independent.py` supplies the existing reviewed
exact row collector; all physical rows come from the unchanged version14
verifier with SHA256
`ec1b7de7b15bcc9d89d12087bff974c68e6d056bdaae26b482d514027ec97993`.

The prefix JSON bytes are bound separately by each record's `prefix_sha256`.
All sources are included or referenced through the original accepted archive.
The proof uses no Lean, Lake, CI, floating-point infeasibility assertion, or
positive-margin assumption at the sharp weak-link boundary. It proves only
the complete fixed original parents explicitly supplied in a closed record.
