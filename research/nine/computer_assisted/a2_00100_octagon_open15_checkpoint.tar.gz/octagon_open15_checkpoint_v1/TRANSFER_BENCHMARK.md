# Bounded transfer of the complete D-parent method

The frozen `disk_octagon_structural_v3` method closed **five additional
immutable original C/D parents**. Every complete parent has a fresh
independent rational replay and an exhaustive child-union check. Fifteen
other originals remain OPEN. The completed D pilot is a separate sixth
closure and is not counted in the five-parent figures below.

The source target list came from the published `159/72` fixed register.
It contains the 20 other OPEN originals whose second path step is
`["angle_cut",[0,"0"],1]`, excluding the completed D parent and the separately
assigned hard original `positive-2c719a20ef7510de`. The target-list file binds
the precise source-register bytes. Every attempt starts at, or resumes a
complete tree under, the same unchanged original path and its independently
proved coordinate-bound prefix.

## Finite work and outcome

| Stage | Originals | Additional node cap per original | Workers | Actual nodes | New complete parents |
|---|---:|---:|---:|---:|---:|
| Uniform first pass | 20 | 64 | 2 | 1280 | 0 |
| Three smallest retained frontiers | 3 | 256 | 2 | 115 | 3 |
| Remaining original-parent continuations | 17 | 256 | 3 | 3986 | 2 |
| Total | 20 distinct originals | 320 maximum per original | — | 5381 | 5 |

The resulting complete parents are:

| Original ID | Bound deductions | Weighted terminal leaves | New internal splits |
|---|---:|---:|---:|
| `positive-f312768df8c0e949` | 32 | 57 | 8 ordered octagons |
| `positive-69f6ff1ef1be2b79` | 32 | 64 | 9 ordered octagons |
| `negative-4296ece9afbd18f6` | 32 | 148 | 21 ordered octagons |
| `positive-4b582e8d1ada2f88` | 32 | 127 | 18 ordered octagons |
| `positive-ab48a9ab55af0106` | 31 | 113 | 16 ordered octagons |
| Total | 159 | 509 | 72 ordered octagons |

All five complete trees use only the already-reviewed ordered eight-child
center-distance octagon split after their original parent. Their existing
parent conditions supply the exact guarded ABXD consequences. No new angle
split, new SAT semantics, new unit-frame context, or unproved numerical
coordinate bound is used by these completed trees.

The independently printed tables contain 7519 used rows across the exact
bound deductions and contradiction leaves. Each bound proof is acyclic;
each weighted leaf has strictly positive rational reserve. Every original
parent's complete child union is checked independently of the producer.

## Remaining obstruction

The other 15 original parents retain 1028 unproved descendants. Every retained
path stopped at the stated node cap. None is classified as a mathematical
counterexample, and none changes its original parent's OPEN status. In the
last 17-parent pass, 13 failed default HiGHS solves were successfully retried
with dual simplex and presolve disabled; there are no remaining numerical
solver-failure frontiers. No exact candidate was rejected.

The smallest remaining frontiers belong to
`negative-2f9ffd3df06e7c5f` (6 paths),
`negative-573078fc944ce553` (17),
`positive-3b5d35fda8ec4119` (22), and
`positive-a4979e5f2a7e8734` (22). Other broad parents accumulated larger
frontiers, reaching 237 on `negative-95371f658da581d0`.
This single bounded continuation pass has ended. No further search is
running. The final per-original record files preserve all completed leaves
and all unfinished paths for later research.

## Frozen acceptance files

The first three complete parents are in `transfer_closed_v1.json`;
their independent arithmetic is in `transfer_independent_review_v1.json`
and `transfer_printed_tables_v1.json`. The final two are exclusively in
`transfer_closed_v2_additions.json`, with corresponding
`transfer_independent_review_v2_additions.json` and
`transfer_printed_tables_v2_additions.json`. The two packages contain
disjoint original IDs. Neither earlier package nor its source has been
overwritten.

The unchanged source and exact hand coverage proof are in the sibling
`d_original_parent_closed_v3/` bundle. Its manifest SHA256 is
`f9cb4c494e97974b3d92c1e94e60ebae3f6dfbfd02d6696281eab6af529d3676`.
Each complete parent also has its individual source record under
`resumed_records/`, its exact inherited bound proof under `prefixes/`, and
an individual independent review and printed table at this directory's
top level.

`final_benchmark.json` gives machine-readable totals and all 15 remaining
original IDs. `remaining_resume_report.json` was finalized from all 17
finished per-original records and matching diagnostics; the hashes of the 16
records already present in its last progress snapshot were unchanged.
The numerical producer and search-order choices are not proof premises.
No Lean, Lake, CI, full-mask closure, or closure of any unfinished original
is asserted.
