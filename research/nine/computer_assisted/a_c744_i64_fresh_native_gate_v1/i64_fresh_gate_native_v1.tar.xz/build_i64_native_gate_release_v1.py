#!/usr/bin/env python3
"""Preserve a completed native gate without presenting it as a cold proof."""
if not __debug__:raise RuntimeError('Release assembly requires assertions.')
from pathlib import Path
import hashlib,json

ROOT=Path('/workspace/scratch/f9f48fcfb253')
HERE=ROOT/'ac_work/recovery_20261105_reset2'
GATE=HERE/'i64_fresh_gate_v3'
OUT=HERE/'i64_fresh_gate_native_checkpoint_v1'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def dump(path,value):
    assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')

def main():
    assert not OUT.exists();OUT.mkdir()
    copies={}
    def copy(source,member,expected=None):
        source=Path(source);raw=source.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        if expected:assert digest==expected
        target=OUT/member;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==raw
        else:
            with target.open('xb')as stream:stream.write(raw)
        copies[str(source)]=dict(member=member,sha256=digest,bytes=len(raw));return digest
    freeze=read(GATE/'SOURCE_BINDINGS.json')
    assert sha(GATE/'SOURCE_BINDINGS.json')=='80b4dcd1582f18e50b1db4b6d592b3f7b0863a4dff76ffb4ddbc6105e140820a'
    copy(GATE/'SOURCE_BINDINGS.json','gate/SOURCE_BINDINGS.json')
    for rel,h in freeze['files'].items():copy(GATE/rel,'gate/'+rel,h)
    names=['I64_RECOVERED_813_FRESH_EXACT_REPLAY.json','I64_RECOVERED_813_FRESH_EXACT_REPLAY.log',
      'I64_RECOVERED_813_FRESH_EXACT_REPLAY_FRESH_SCALAR_064.json','I64_RECOVERED_813_FRESH_EXACT_REPLAY_FRESH_SCALAR_064.log',
      'I64_RECOVERED_813_FRESH_EXACT_REPLAY_INHERITED_ENGINE_ON_NARROWED_DOMAIN.json',
      'I64_FRESH_GATE_V3_CONTROLS.json','I64_FRESH_GATE_V3_CACHE_IDENTITY.json']
    for name in names:copy(HERE/name,'reports/'+name)
    for source in [ROOT/'d_work/I64_RECOVERED_813_GATE_ROOT_SOURCE_REVIEW.json',
      ROOT/'b_work/recovery_20261105_reset2/A_I64_RESTORED_CACHE_V3_SOURCE_REVIEW.md',
      ROOT/'b_work/recovery_20261105_reset2/A_I64_RESTORED_CACHE_V3_SOURCE_REVIEW.json']:
        copy(source,'reviews/'+source.name)
    report=read(HERE/names[0]);assert sha(HERE/names[0])=='a6798bdf6a99d3bfdbf5bbe4af6600577959fd06da2c97412c0f7f9fa384a07e'
    assert report['status']=='PASS_RECOVERED_NARROWED_A3_064_BOUND_RECORD_OPEN'
    assert report['scope']=='EXPLICIT_NARROWED_SUBSET_OF_OLD_COMPONENT3'
    assert (report['rounds'],report['deductions'],report['printed_rows_checked'])==(7,813,1941)
    assert report['complete_A1_and_old_source_arithmetic_repeated']is False
    assert report['new_original_cells']==report['new_masks']==0
    required={}
    for file,field in [('SOURCE_BINDINGS.json','loaded_independent_dependency_sha256'),
      ('HISTORICAL_PROOF_BINDING.json','historical_report_inputs'),('HISTORICAL_PROOF_BINDING.json','source_sha256'),
      ('NARROWED_SOURCE_BINDING.json','new_theorem_source_sha256'),('tree/manifest.json','source_sha256')]:
        for path,h in read(GATE/file)[field].items():
            if path in required:assert required[path]==h
            required[path]=h
    recovery=HERE/'i64_source_checkpoint_v3';available=read(recovery/'SOURCE_AVAILABILITY.json')['native_aliases']
    dependency_map={};categories={}
    for path,h in sorted(required.items()):
        p=Path(path);assert sha(p)==h,path
        if path in available and available[path]['sha256']==h:
            item=dict(kind='PUBLISHED_A1_MATERIALIZED_ALIAS',sha256=h)
        elif p.is_relative_to(GATE):item=dict(kind='INCLUDED_GATE',member='gate/'+str(p.relative_to(GATE)),sha256=h)
        elif p.is_relative_to(recovery):item=dict(kind='PUBLISHED_I64_RECOVERY_MEMBER',member=str(p.relative_to(recovery)),sha256=h)
        elif p.is_relative_to(ROOT/'repo'):item=dict(kind='PUBLISHED_REPOSITORY_FILE',repository_path=str(p.relative_to(ROOT/'repo')),sha256=h)
        else:
            member='additional_exact_sources/'+h;copy(p,member,h)
            item=dict(kind='INCLUDED_EXACT_SOURCE_ALIAS',member=member,sha256=h)
        dependency_map[path]=item;categories[item['kind']]=categories.get(item['kind'],0)+1
    checkpoint=read(recovery/'CHECKPOINT.json')
    dump(OUT/'DEPENDENCIES.json',dict(schema='I64_native_gate_explicit_dependency_map_v1',
      complete_A1_publication=checkpoint['base'],I64_recovery_publication=dict(commit='9d4d1129c57fb83d9e2e1ae9db4761accf64ee2c',folder='research/nine/computer_assisted/a_c744_i64_source_recovery_v3',archive_sha256='2ac4146142e260d62aa8b2156e7e01962ce4f8abb69f8429171c6fa7f26ce86c'),
      paths=dependency_map,categories=categories,missing_unpreserved_dependencies=[],
      full_cold_replay_claimed=False,native_paths_preserved_as_metadata_only=True))
    dump(OUT/'OBSERVED_EXECUTION.json',dict(status='OBSERVED_FRESH_I64_SOURCE_GATE_EXIT_ZERO',session_id=23651,observed_exit_code=0,
      command=['python','-B','-S',str(GATE/'replay_recovered_813.py'),str(HERE/names[0])],
      report_member='reports/'+names[0],report_sha256=sha(HERE/names[0]),
      scoped_status=report['status'],historical_source_arithmetic_repeated=False,fresh_weighted_source=True,
      fresh_scalar=True,numerical_solver_run=False,old_lost_receipts_recreated=False,
      retained235_consumer_replayed=False,new_original_cells=0,new_masks=0))
    (OUT/'README.md').write_text('''# Recovered A-c744 I64 source: fresh native exact gate\n\nThe new exact run observed exit0 and checked all seven rounds,813 deductions\nand1941 printed premises of the byte-identical recovered source. Both I64\nliterals and131 universal center literals were reconstructed. The separate\n16/25 scalar checker freshly passed28 domains,121 leaves and15125 Bernstein\ncoefficients. The source remains one OPEN domain.\n\nThe certified domain is the unchanged original A-c744 oldcomponent3\nintersected with yB+yD-2yI<=-16/25. The inherited reader's oldcomponent3 label\ndoes not enlarge that domain. Promotion to an original-wide endpoint family\nrequires the separately published complete I64 implication and its new\nattachment; this packet does not install such a family.\n\nFour old source-provider proofs are explicitly reused from the complete A1\npublication after exact full report/domain/node/input identity checks. Their\n757-node A1 arithmetic is not repeated or called fresh. No lost29c8 receipt,\nlost235-node cover or unavailable numerical suffix is used. The full new\nreport, its unchanged recovered source record, scalar result, controls,\nroot/B source reviews and observed-exit receipt are included.\n\nDEPENDENCIES identifies every required native hash. Most old payloads are\nreused from the pinned published A1 archive and prior base; the I64 source\nrecovery and theorem files are separately published dependencies. All71\nremaining small source aliases are included by exact content. No unpreserved\ndependency is omitted from the map. This is a durable native proof checkpoint,\nnot a claim that these files alone are a cold portable proof. Native path\nstrings are provenance; extraction never recreates them automatically.\n\nTo repeat the native gate, restore the explicit pinned aliases and run the\nrecorded Python -B -S command with a fresh output name. To repeat all older\nsource arithmetic too, the four frozen original providers must replace the\nexplicit historical cache; that more expensive cold protocol is separate.\n\nNo numerical solve, Lean, Lake or CI was run here. No original-cell or\nwhole-mask credit is granted. The current registered original remains OPEN.\n''')
    copy(__file__,'build_i64_native_gate_release_v1.py')
    dump(OUT/'COPY_PROVENANCE.json',dict(schema='exact_native_gate_publication_copies_v1',sources=copies))
    for path,entry in copies.items():assert sha(path)==entry['sha256'];assert sha(OUT/entry['member'])==entry['sha256']
    files={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(OUT.rglob('*'))if p.is_file()}
    dump(OUT/'INPUT_MANIFEST.json',dict(schema='I64_fresh_native_gate_publication_members_v1',files=files,
      members=len(files),file_bytes=sum(v['bytes']for v in files.values()),
      source_record_sha256='858f627dd6ab4ed6efbd6f57614787d037fe1482997eca4313a3a9eaa1e25244',
      new_report_sha256=sha(HERE/names[0]),cold_portable_replay_claimed=False,new_original_cells=0,new_masks=0))
    print(json.dumps(dict(status='READY_NATIVE_GATE_PUBLICATION',folder=str(OUT),manifest_sha256=sha(OUT/'INPUT_MANIFEST.json'),members=len(files)+1,file_bytes=sum(v['bytes']for v in files.values())+(OUT/'INPUT_MANIFEST.json').stat().st_size,dependency_categories=categories)),flush=True)

if __name__=='__main__':main()
