# Independent source and domain review of the recovered I64 gate

This review accepts the source-reuse and domain composition of the frozen v3
gate. It does not repeat the old A1 arithmetic or the new seven-round weighted
record. The latter remains a separate execution gate.

The reviewed source freeze is
`80b4dcd1582f18e50b1db4b6d592b3f7b0863a4dff76ffb4ddbc6105e140820a`.
The cache source has SHA256
`fae655ca5cb79f719cb238b82b808102b968dac7829cb3e71fc9d3473fc4464f`,
the historical binding has SHA256
`c80c305b0ec5cae2ad7942c388e68a0991a658b916a5361b8dce8363635d94b7`,
and the v3 entry point has SHA256
`bbbd9ddee1c6457e995bc1c768b6c1477f19bd9a46080d3b4f98c9b0969e3c09`.
The complete cache, entry point, hand attachment and control source were read.
All 12 package files and 41 loaded dependency pins were independently rehashed.
The v3 delta from v2 is exactly the explicit dependency-hash loop. No arithmetic
or domain rule changed in that delta.

## Historical proof identity and scope

The cache is tied to the published outer report with SHA256 `5c14a5ee...`,
not to the unavailable later `29c8...` receipt. It verifies the original
`positive-c744bc031d40ee64`, its literal path, mask, nine-original and closed-face
flags. The older seven-round, 565-deduction component3 report is distinct from
the newly recovered seven-round, 813-deduction record.

The four embedded report objects reproduce their original hashes in memory.
The source checks retain the exact old conditional parent and domain, the
four-round and post-A1 bound-source counts, and the complete component0/1
exclusions. The declaration checks all five components and exactly the prior
excluded components2/4. The cache verifies the union of 1,010 historical input
identities and binds all 798 component0/1 node payloads to the accepted reports
and manifests. Those identity checks are not represented as a fresh arithmetic
replay. The saved cache-identity and 28-control reports were read and rehashed
for this review; their full checks were not repeated here.

Exactly four provider functions are replaced temporarily: post-A1 bounds,
the prior four-round bounds, complete A1, and complete components0/2/4. Each
provider call rechecks its frozen binding and returns a deep copy. The context
restores every original provider on exit, including when the consumer raises.
The entry point independently restores its temporary checker and adapter.
No record-core, row reconstruction, residual calculation, rounding, frame
inference, child construction or complete-cover traversal is replaced.

## New narrowed source

The new source explicitly assumes

\[
y_B+y_D-2y_I\leq -16/25.
\]

Because `16/25 > 3/5`, this domain is contained in the old component3 domain.
All older necessary bounds therefore remain valid on it. The exact new I64
literal is checked against that declared premise, the unchanged original ID
and the unchanged path. Universal center rows are decoded independently.
The frozen entry point permits only the one specified seven-round OPEN record;
its initial parent and arithmetic remain checked by the inherited reader.

The new manifest, binding and outer result explicitly retain the narrower
scope even though the inherited internal reader retains its historical
component3 label. Consequently no result from this gate alone applies to the
whole original. The separate original-wide implication must be attached before
such a use. This distinction prevents circular promotion of the new I64 premise.

The final result must state that the recovered record's weighted arithmetic
was freshly replayed, while the identified older proof providers were reused.
It must not claim a cold replay or a replay of the lost 235-node consumer tree.
The reviewed source does so explicitly and revalidates frozen inputs and cache
evidence after the consumer check.

No source/domain gap was found in this composition. Fresh execution of the
seven-round record, and any later whole-original promotion, remain separate
obligations. This review changes no proof inputs, live process or ledger.
