#!/usr/bin/env python3
"""Assemble exact recovered source and new, explicitly historical metadata.

This preparation does not run a scalar/weighted proof and never overwrites an
existing file. Its input is the published recovery bundle and accepted A1 base.
"""
if not __debug__:raise RuntimeError('Preparation requires assertions.')
from pathlib import Path
import hashlib,json,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PACKET=HERE.parent/'i64_source_checkpoint_v3'
TARGET='positive-c744bc031d40ee64'
PATH=[['angle',3,1],['angle_cut',[0,'0'],0],['inward_row_escape',[7,8],[4]]]
I64=dict(name='stronger_actual_ab_064_A_c744_I_high',coefficients=[[3,'1'],[7,'1'],[17,'-2']],rhs='-16/25')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def put(path,raw):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==raw,path
    else:
        with path.open('xb')as stream:stream.write(raw)
def dump(path,value):put(path,(json.dumps(value,indent=2)+'\n').encode())

def prepare():
    assert sha(PACKET/'SOURCE_BINDINGS.json')=='f740ecf06bc2c60b1dbe17ebaa0eef41c468857f595cdbad0cf079426905417a'
    original_freeze=read(PACKET/'SOURCE_BINDINGS.json')
    for rel,h in original_freeze['files'].items():assert sha(PACKET/rel)==h,rel
    checkpoint=read(PACKET/'CHECKPOINT.json');availability=read(PACKET/'SOURCE_AVAILABILITY.json')
    record=PACKET/'RECOVERED_SEVEN_ROUND_SOURCE.json'
    assert sha(record)=='858f627dd6ab4ed6efbd6f57614787d037fe1482997eca4313a3a9eaa1e25244'
    put(HERE/'tree/node_00000.json',record.read_bytes())
    decoder=PACKET/'sources/independent_physical_center_disk_rows.py'
    assert sha(decoder)=='9fafd523e0154fcb8aedb7ecf2f36aa6213a77c84ff619ae12cd5612fc1b2acc'
    put(HERE/decoder.name,decoder.read_bytes())
    external=read(PACKET/'EXTERNAL_SOURCE_MANIFEST.json')
    requirements={e['original_path']:e for e in availability['external_source_requirements']}
    aliases={};sources={}
    for old,h in external['source_sha256'].items():
        if Path(old).is_file()and sha(old)==h:new=old
        else:
            item=requirements[old];assert item['available']is True and item['sha256']==h
            new=item['donor']['path'];assert sha(new)==h
        if new in sources:assert sources[new]==h
        sources[new]=h;aliases[old]=dict(path=new,sha256=h)
    keep=('schema','status','parent','id','original_path','conditional_parent','component','closed_domain','scope','nodes','new_original_cells','new_masks')
    manifest={k:external[k]for k in keep}
    for key,name in [('component3_shared_bound_state','A_C744_COMPONENT3_SHARED_BOUND_STATE_BINDING.json'),
      ('component1_closed_consequence','A_C744_COMPONENT1_CLOSED_CONSEQUENCE_BINDING.json'),
      ('component3_post_a1_bound_state','A_C744_COMPONENT3_POST_A1_BOUND_STATE_BINDING.json')]:
        entry=dict(external[key]);entry['path']=str(ROOT/'ac_work/tree'/name)
        assert sha(entry['path'])==entry['sha256'];manifest[key]=entry
    manifest['source_sha256']=sources
    manifest['narrowed_I64_source_domain']=I64
    manifest['external_source_manifest']=dict(path=str(PACKET/'EXTERNAL_SOURCE_MANIFEST.json'),sha256=sha(PACKET/'EXTERNAL_SOURCE_MANIFEST.json'))
    manifest['scope_note']='The frozen component3 reader retains its older 3/5 parent. This one-node proof additionally assumes the literal 16/25 row and is certified only on that explicit narrowed subset.'
    dump(HERE/'tree/manifest.json',manifest)
    dump(HERE/'EXACT_REFERENCE_ALIASES.json',dict(schema='exact_source_reference_aliases_v1',source_manifest=manifest['external_source_manifest'],aliases=aliases,record_bytes_changed=False,mathematical_literals_changed=False))
    report_path=ROOT/'ac_work/tree/A_C744_COMPONENT3_FIRST_COMPLETE_A1_CONSEQUENCE_EXACT_REPLAY.json'
    assert sha(report_path)=='5c14a5ee853378adf31fcb56665bafa0c98656eec9bab0ca27ba596c03dc826d'
    outer=read(report_path)
    shared=outer['fresh_component3_shared_bound_source']['source_report']
    a1=outer['fresh_completed_component1_consequence_source']['source_report']
    declaration,zero=outer['freshly_replayed_original_complement_consequences']['source_reports']
    references={'shared_four':shared,'complete_A1':a1,'five_declaration':declaration,'complete_component0':zero}
    for ref in references.values():
        assert hashlib.sha256((json.dumps(ref['report'],indent=2)+'\n').encode()).hexdigest()==ref['sha256']
    historical={}
    for value in [outer]+[r['report']for r in references.values()]:
        for key in ('input_sha256','checker_dependency_sha256','source_sha256'):
            for path,h in value.get(key,{}).items():
                if path in historical:assert historical[path]==h
                historical[path]=h;assert sha(path)==h,path
    sources_explicit={str(ROOT/'ac_work/tree'/name):sha(ROOT/'ac_work/tree'/name)for name in[
      'independent_a_c744_component3_post_a1_bound_rows.py','independent_a_c744_component3_shared_bound_rows.py',
      'independent_a_c744_component1_consequence.py','independent_a_c744_complement_consequences.py',
      'verify_a_c744_component3_post_a1_bounds_lazy_tree.py','verify_a_c744_component3_a1_consequence_lazy_tree.py',
      'independent_physical_sat_diagonal_replay.py']}
    historical_binding=dict(schema='historically_accepted_A1_complete_source_reuse_v2',original_id=TARGET,original_path=PATH,
      published_outer_report=dict(path=str(report_path),sha256=sha(report_path)),
      published_A1_checkpoint=checkpoint['base'],recovered_source_checkpoint=dict(path=str(PACKET/'CHECKPOINT.json'),sha256=sha(PACKET/'CHECKPOINT.json')),
      embedded_report_sha256={k:v['sha256']for k,v in references.items()},historical_report_inputs=historical,
      source_sha256=sources_explicit,lost_receipts_used=False,source_arithmetic_repeated=False,
      old_embedded_report_objects_preserved=True,historical_source_reuse_explicit=True,
      complete_source_reports_not_recreated=True,new_original_cells=0,new_masks=0)
    dump(HERE/'HISTORICAL_PROOF_BINDING.json',historical_binding)
    theorem_sources={}
    for rel,h in checkpoint['published_theorem_files'].items():
        p=ROOT/'repo'/rel
        if not p.is_file():p=PACKET/checkpoint['published_theorem_local_aliases'][rel]
        assert sha(p)==h,rel;theorem_sources[str(p)]=h
    for rel in ['CHECKPOINT.json','ORIGINAL_WIDE_I64_IMPLICATION.md','sources/UNIVERSAL_CENTER_DISK_HAND_PROOF.md']:
        p=PACKET/rel
        assert p.is_file();theorem_sources[str(p)]=sha(p)
    theorem_sources[str(decoder)]=sha(decoder)
    scalar_folder=ROOT/'repo/research/nine/computer_assisted/actual_AB_two_link_row_064_v1'
    scalar_checker=scalar_folder/'check_three_angle_cover_0641.py'
    assert sha(scalar_checker)=='b3fa06fa47cd82a4fbc2f48f50d1ac4fc379c3d5367002fa38416c9ef0c29976'
    narrowed=dict(schema='fresh_recovered_I64_narrowed_source_gate_v2',original_id=TARGET,original_path=PATH,
      scope='EXPLICIT_NARROWED_SUBSET_OF_OLD_COMPONENT3',source_domain=I64,
      inherited_parent_domain=manifest['closed_domain'],mask='001/00',squared_radius='1105/256',
      source_checkpoint=dict(path=str(PACKET/'CHECKPOINT.json'),sha256=sha(PACKET/'CHECKPOINT.json')),
      manifest_sha256=sha(HERE/'tree/manifest.json'),record_sha256=sha(record),
      scalar_checker=dict(path=str(scalar_checker),cover=str(scalar_folder/'cover_0641')),
      new_theorem_source_sha256=theorem_sources,first_five_rounds_preserved=True,
      original_wide_promotion_separate=True,all_nine_originals_retained=True,
      original_corners=36,original_pairs=36,marked_cones=5,closed_shared_faces_retained=True,
      new_original_cells=0,new_masks=0)
    dump(HERE/'NARROWED_SOURCE_BINDING.json',narrowed)
    print(json.dumps(dict(status='PREPARED_NO_ARITHMETIC_RUN',historical_inputs=len(historical),external_source_references=len(sources),theorem_sources=len(theorem_sources),record_sha256=sha(record),historical_binding_sha256=sha(HERE/'HISTORICAL_PROOF_BINDING.json'),narrowed_binding_sha256=sha(HERE/'NARROWED_SOURCE_BINDING.json'))),flush=True)

if __name__=='__main__':prepare()
