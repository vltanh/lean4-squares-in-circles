# V3 dependency check

V2 completed only source-identity and literal controls. Its source freeze also
inventoried the 41 loaded independent modules. V3 explicitly hashes every entry
in that inventory on both sides of the fresh weighted replay. The only change
to the replay source is that additional validation loop. The historical cache,
recovered source record, narrowed domain and arithmetic adapters are unchanged.
V2 files and its preparation receipts remain intact; it was not used for a
weighted replay.
