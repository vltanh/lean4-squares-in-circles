# Independent review of original-pair relative-support rows

This review concerns the same nine physical originals in the strict normalized
`001/00` caller. It adds necessary pair inequalities and replays named exact
certificates. It does not close the original A or B parent, the current mask,
or any other mask.

The reviewed new row source is
`sharp_frame/owner_free_relative_support.py`, SHA-256
`b1445ad4e00a0127b201d784b72e1df2246101f567b0bf952ca46b463595e788`.
The separate executable reviewer is
`global_masks/review_owner_free_support_independent.py`. It imports only the
accepted frozen native collector and verifier, and imports no new producer,
optimizer, or discovery replay wrapper. Numerical LP points and margins are
ignored throughout acceptance.

## 1. Physical implication

For originals `i,j`, let

\[
c=\alpha_i\alpha_j+\beta_i\beta_j,\qquad
s=\alpha_i\beta_j-\beta_i\alpha_j.
\]

The canonical original frames have `alpha>=|beta|` and unit norm, so `c>=0`.
Each of the four possible owned unit side normals has the same sum of square
support halfwidths, `(1+c+|s|)/2`. The separating-axis theorem supplies at least
one signed normal when the physical interiors are disjoint. Cauchy--Schwarz
therefore gives the necessary, owner-free inequality

\[
\|c_j-c_i\|\geq (1+c+|s|)/2.
\]

No particular separating owner or axis is assumed. Contact is included.

Write `a_i=|beta_i|` and use the folded pair

\[
c_f=\alpha_i\alpha_j+a_i a_j,\qquad
s_f=\alpha_i a_j-a_i\alpha_j.
\]

Equal beta signs give equality between `c+|s|` and `c_f+|s_f|`.
For opposite signs, their difference equals

\[
2\bigl(\min(\alpha_i a_j,a_i\alpha_j)-a_i a_j\bigr)\geq0.
\]

This includes zero betas. Thus folded rows require no additional sign guard.
Their variables are still the absolute betas of the same physical originals.

## 2. Exact affine rows

For either signed or folded pair `(C,S)`, each `tau>=0` and
`epsilon in {-1,1}` imply

\[
\|d\|^2\geq\tau(1+C+\epsilon S)-\tau^2.
\]

This follows by expanding `(h-tau)^2>=0`, where
`h=(1+C+|S|)/2`, and using `tau>=0` when replacing `|S|` by `epsilon S`.

For a proved coordinate-difference interval `[l,u]`, the secant inequality is
`d^2<=(l+u)d-lu`. Each of the four signed frame products has two valid affine
lower planes. The reviewer derives them by expanding nonnegative rectangle
products and additionally checks all four rectangle corners exactly. If the
sum of the selected four planes is `L+K`, the resulting row is

\[
\tau L-\sum_k(l_k+u_k)d_k
\leq \tau^2-\tau-\tau K-\sum_k l_k u_k.
\]

The signs of both center coefficients and the constant were independently
checked. The finite order comprises 36 pairs, two frame families, two sine
signs, three rational tangents `1,9/8,6/5`, and 16 plane selections: 6,912
rows. The next 36 rows use exact rational lower bounds on the relative support
radius. Their endpoint argument is valid because `cos(v)+sin(v)` is concave
on `[0,pi/2]`. Every square-root enclosure is recomputed using integer
arithmetic and checked by squaring its endpoints.

## 3. Interval provenance and prior rows

For each certificate the reviewer:

1. Checks the immutable original cell identity and original path.
2. Replays every parent-coordinate prefix deduction before installing it.
3. Decodes old angle and position splits at their original locations, then
   intersects the proved parent-coordinate intervals.
4. Calls the hash-bound native physical angle and center propagation.
5. Independently recomputes original alpha, signed beta, absolute beta and
   inset intervals, and compares the exact directed bounds with the frozen
   physical convention.
6. Independently reconstructs all 36 physical pair-difference intervals and
   compares them with the frozen native bounds.
7. Regenerates ordered-octagon, applicable unique-penultimate guard, and 1,737
   signed/folded unit-frame support rows in their prescribed order.
8. Regenerates all 6,948 new relative-support rows without importing their
   producer, checks every printed weighted row, and sums rational weights.

The final contradiction uses the unchanged global absolute variable bounds.
For weighted sum `a.z<=b` and `|z_k|<=M_k`, its exact reserve is
`-b-sum(M_k*|a_k|)`. Only a strictly positive recomputed reserve is accepted.

## 4. Results and exact scope

The saved deep A descendant independently passes with 29 weighted rows,
including two new folded rows. Its rational reserve matches the supplied
certificate exactly. Its path also matches the separately saved old deep
descendant. This is a named descendant closure.

The fixed zero-branch A filter independently passes all 24 candidate paths.
All 48 source indices and paths were checked against the prior filter and
the original 211-path frontier, with source hashes checked. Twenty-four
previously pending paths remain pending. No new branch was introduced, and
the original A parent remains open.

The two pair-difference induction rounds independently pass 168 A deductions
and 171 B deductions, in addition to 33 and 30 earlier coordinate deductions.
Each objective is exactly
`sign*(center_j[axis]-center_i[axis])`. The residual correction therefore adds
`sign` at the `i` variable and subtracts `sign` at the `j` variable. All
proposals in a round use one unchanged predecessor matrix, and all updates
are installed together afterward. The subsequent product/secant envelopes
use only previously proved intervals. This is acyclic induction.

Both induced whole-parent states remain open. No whole-parent or mask closure
is inferred from the improved bounds or from a numerical LP point.

Exact reviews, printed row sums, physical interval provenance and source-path
audit are under `global_masks/owner_free_support_review/`.

## 5. Ordered-diagonal interval consequences and the final frozen A cover

An ordered diagonal octagon child retains all four earlier closed axis
complements. In its rotated coordinates these give `|w_x|,|w_y|<=12/13`.
The chosen signed diagonal has value at least `17/13`. Consequently both
signed rotated coordinates lie in `[5/13,12/13]`. Mapping the four corners
back by the exact rational orthogonal rotation gives valid original
coordinate-difference intervals. No branch or new assumption is introduced.

The independent checker expands those four corners itself and then verifies
the recorded triangle-inequality updates. Every update cites earlier proof
IDs for exactly the same original coordinate differences. Identity and native
input records, predecessor IDs, all exact sums, final interval IDs and any
negative-cycle terminal are checked. Parent pair bounds are intersected only
after their separate whole-parent induction has passed.

All 24 existing A survivor paths passed this interval-provenance audit. Two
paths, original source indices 20 and 57, additionally have independently
verified positive weighted reserves. Their interval traces use respectively
3 diagonal plus20 triangle deductions, and4 diagonal plus14 triangle
deductions. The other22 paths remain open.

The entire frozen original A cover now has818 independently replayed terminal
paths:629 prior V3 leaves,163 V4 leaves,24 relative-support leaves, and2
inherited-difference leaves. The previous sample-only V3/V4 boundary has been
replaced by a fresh full replay of all629 and163 candidates with exact used-row
tables. There are22 explicit pending paths. The complete840-path union has395
split nodes and retains every closed child and equality boundary. The separate
saved deep descendant is excluded from these counts to avoid double counting.

`audit_A_owner_free_composition.py` resolves every file relative to its
workspace-shaped packet root. Its default mode checks the full finite cover,
all source and review hashes, and every index/path replacement. The
`--replay-new` mode additionally replays all26 new terminals and their parent
proof; `--replay-all` also freshly replays the629 prior V3 and163 V4 terminals.
Every mode leaves original A and the whole mask OPEN.
