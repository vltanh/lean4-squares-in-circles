#!/usr/bin/env python3
"""Audit all24 existing A paths, including interval-only records for survivors."""
import json
from pathlib import Path
import time
import review_owner_free_support_independent as R

BASE = Path(__file__).resolve().parent.parent
OUT = BASE/'global_masks/owner_free_support_review'


def main():
    started = time.monotonic()
    folder = BASE/'sharp_frame/A_inherited_difference_filter'
    report_path = folder/'filter_report.json'
    static_path = BASE/'root_exploration/A_relative_support_filter/filter_report.json'
    parent_path = BASE/'sharp_frame/owner_free_pair_bounds/positive-2d5aba857f2f7602.json'
    prefix_path = BASE/'sharp_frame/bounds/positive-2d5aba857f2f7602.json'
    report = json.loads(report_path.read_text()); static = json.loads(static_path.read_text())
    assert report['source_static_filter_sha256'] == R.sha(static_path)
    assert report['parent_pair_bound_sha256'] == R.sha(parent_path)
    assert report['owner_free_source_sha256'] == R.ROW_SOURCE_SHA256
    assert report['difference_propagator_sha256'] == R.DIFFERENCE_SOURCE_SHA256
    state, parent_review, parent_tables = R.verify_pair_induction(parent_path, prefix_path)
    assert not parent_review['whole_parent_closed']
    old = {item['source_index']: item for item in static['results'] if item['status'] == 'OPEN_RELAXATION'}
    current = {item['source_index']: item for item in report['results']}
    assert len(old) == len(current) == len(report['results']) == report['original_pending_count'] == report['processed'] == 24
    assert set(old) == set(current)
    assert report['new_branch_nodes'] == 0 and report['whole_mask_closed'] is False
    reviews = []; survivors = []
    for index in sorted(current):
        item = current[index]; assert item['path'] == old[index]['path']
        certificate_path = folder/item['certificate']; certificate = json.loads(certificate_path.read_text())
        assert certificate['source_index'] == index and certificate['path'] == item['path']
        assert certificate['source_static_record'] == old[index]['certificate']
        assert certificate['status'] == item['status']
        review, tables = R.verify_inherited_child(certificate_path, state)
        (OUT/f'A_inherited_child_{index:03d}.json').write_text(json.dumps(review, indent=2)+'\n')
        (OUT/f'A_inherited_child_{index:03d}.tables.json').write_text(json.dumps(tables, indent=2)+'\n')
        reviews.append(review)
        if review['descendant_closed']:
            assert review['positive_reserve'] == item['reserve']
        else:
            survivors.append({'source_index': index, 'path': item['path'], 'certificate_sha256': R.sha(certificate_path)})
        print(index, review['status'], flush=True)
    closed = sum(item['descendant_closed'] for item in reviews)
    assert closed == report['candidate_closed'] == 2 and len(survivors) == report['remaining'] == 22
    result = {'id': state['id'], 'path': state['path'], 'status': 'PASS_PARTIAL_FIXED_FRONTIER_FILTER',
              'whole_parent_closed': False, 'whole_mask_closed': False, 'new_branch_nodes': 0,
              'source_report_sha256': R.sha(report_path), 'static_filter_sha256': R.sha(static_path),
              'source_index_and_path_correspondence': 'PASS', 'parent_induction_review': parent_review,
              'existing_paths_checked': 24, 'additional_closed_existing_paths': 2,
              'remaining_existing_paths': 22, 'reviews': reviews, 'survivors': survivors,
              'seconds': time.monotonic()-started}
    (OUT/'A_inherited_filter_review.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('reviews', 'survivors')}, indent=2))


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True, parents=True)
    main()
