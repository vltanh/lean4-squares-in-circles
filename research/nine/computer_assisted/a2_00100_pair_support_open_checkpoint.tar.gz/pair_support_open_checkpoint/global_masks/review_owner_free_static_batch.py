#!/usr/bin/env python3
"""Independent replay and source-path audit for the fixed zero-branch A pass."""
import hashlib
import json
from pathlib import Path
import time
import review_owner_free_support_independent as R

BASE = Path(__file__).resolve().parent.parent
DEST = BASE/'global_masks/owner_free_support_review'


def main():
    start = time.monotonic()
    folder = BASE/'root_exploration/A_relative_support_filter'
    report_file = folder/'filter_report.json'
    source_file = BASE/'sharp_frame/positive_shallow_unit_frame_filter.json'
    ancestor_file = BASE/'sharp_frame/positive_shallow_sat_priority.json'
    prefix_file = BASE/'sharp_frame/bounds/positive-2d5aba857f2f7602.json'
    report = json.loads(report_file.read_text()); source = json.loads(source_file.read_text())
    ancestor = json.loads(ancestor_file.read_text())
    assert R.sha(source_file) == report['source_sha256']
    assert R.sha(ancestor_file) == source['source_sha256']
    assert report['id'] == source['id'] == ancestor['id'] == 'positive-2d5aba857f2f7602'
    assert report['path'] == source['path'] == ancestor['path']
    assert report['new_branch_nodes'] == source['new_branch_nodes'] == 0
    assert report['whole_mask_closed'] is False
    old = {r['index']: r for r in source['results']}
    assert len(old) == len(source['results']) == len(ancestor['frontier'])
    for index, item in old.items():
        assert type(index) is int and 0 <= index < len(ancestor['frontier'])
        assert item['path'] == ancestor['frontier'][index]['path']
    pending = {index: r for index, r in old.items() if r['status'] == 'OPEN'}
    assert len(pending) == report['original_pending_count'] == 48
    current = {r['source_index']: r for r in report['results']}
    assert len(current) == len(report['results']) == report['processed'] == 48
    assert set(current) == set(pending)
    reviews = []; survivors = []
    for index in sorted(current):
        item = current[index]
        assert item['path'] == pending[index]['path']
        path = folder/item['certificate']; certificate = json.loads(path.read_text())
        assert certificate['path'] == item['path'] and certificate['id'] == report['id']
        assert certificate['status'] == item['status']
        assert certificate['label'] == f'A_old_frontier_{index:03}'
        if item['status'] != 'CANDIDATE_CLOSED':
            assert item['status'] == 'OPEN_RELAXATION'
            survivors.append({'source_index': index, 'path': item['path'], 'certificate_sha256': R.sha(path)})
            continue
        review, tables = R.verify_certificate(path, prefix_file)
        assert not review['whole_parent_closed'] and review['positive_reserve'] == item['reserve']
        review['original_source_index'] = index
        reviews.append(review)
        (DEST/(certificate['label']+'.json')).write_text(json.dumps(review, indent=2)+'\n')
        (DEST/(certificate['label']+'.tables.json')).write_text(json.dumps(tables, indent=2)+'\n')
        print(index, 'PASS', flush=True)
    assert len(reviews) == report['candidate_closed'] == 24 and len(survivors) == 24
    deep = json.loads((BASE/'sharp_frame/unit_frame_deep_probe.json').read_text())
    deep_certificate = json.loads((BASE/'sharp_frame/owner_free_support_probes/A_saved_deep_descendant.json').read_text())
    assert deep_certificate['path'] == deep['path']
    summary = {'id': report['id'], 'status': 'PASS_PARTIAL_FIXED_FRONTIER_FILTER',
               'whole_parent_closed': False, 'whole_mask_closed': False, 'new_branch_nodes': 0,
               'original_source_frontier_count': len(ancestor['frontier']), 'source_pending_count': 48,
               'independently_closed_existing_paths': 24, 'remaining_existing_paths': 24,
               'source_report_sha256': R.sha(report_file), 'previous_filter_sha256': R.sha(source_file),
               'original_frontier_sha256': R.sha(ancestor_file), 'source_index_and_path_correspondence': 'PASS',
               'saved_deep_path_correspondence': 'PASS', 'reviews': reviews, 'survivors': survivors,
               'seconds': time.monotonic()-start}
    (DEST/'A_fixed_filter_review.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('reviews', 'survivors')}, indent=2))


if __name__ == '__main__':
    DEST.mkdir(exist_ok=True, parents=True)
    main()
