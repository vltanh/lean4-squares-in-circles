#!/usr/bin/env python3
"""Portable mixed-context A cover:818 proved terminals and22 explicit pending.

Default checks immutable source/review correspondence and the entire finite
cover. --replay-new rechecks all26 added terminals and their parent bound
proofs. --replay-all additionally replays all629 V3 and163 V4 terminals.
All dependencies resolve below the workspace-shaped packet root; no producer
is imported. No mode asserts a whole-original or mask closure.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import time
import review_owner_free_support_independent as R

BASE = Path(__file__).resolve().parent.parent
IDENT = 'positive-2d5aba857f2f7602'
FILES = {
    'v3_source': 'sharp_frame/positive_shallow_sat_priority.json',
    'v4_source': 'sharp_frame/positive_shallow_unit_frame_filter.json',
    'support_source': 'root_exploration/A_relative_support_filter/filter_report.json',
    'inherited_source': 'sharp_frame/A_inherited_difference_filter/filter_report.json',
    'prefix': 'sharp_frame/bounds/positive-2d5aba857f2f7602.json',
    'parent_pair': 'sharp_frame/owner_free_pair_bounds/positive-2d5aba857f2f7602.json',
    'v3_review': 'sharp_frame/A_629_v3_independent_review.json',
    'v3_tables': 'sharp_frame/A_629_v3_independent_review.tables.json',
    'v4_review': 'physical_pilots/combined_bounds/v4_all163_independent_review.json',
    'v4_tables': 'physical_pilots/combined_bounds/v4_all163_independent_tables.json',
    'support_review': 'global_masks/owner_free_support_review/A_fixed_filter_review.json',
    'inherited_review': 'global_masks/owner_free_support_review/A_inherited_filter_review.json',
}


def load(name):
    return json.loads((BASE/FILES[name]).read_text())


def branch_children(query):
    kind, key = query
    if kind in ('angle', 'angle_cut', 'position', 'position_cut'):
        return [0, 1]
    if kind in ('disk8', 'disk8_ordered'):
        R.octagon_rows(key)
        return [[k] for k in range(8)]
    if kind in ('first_two_escape', 'first_two_reduced_escape'):
        return [[k] for k in range(len(R.first_two_rows(key, kind == 'first_two_reduced_escape')))]
    # The fixed A tree uses the kinds above only. Reject new tree semantics.
    raise AssertionError(('unexpected split kind in immutable A cover', kind))


def full_cover(prefix, records):
    root = {}
    for record in records:
        path = record['path']; assert path[:len(prefix)] == prefix
        node = root
        for step in path[len(prefix):]:
            assert 'terminal' not in node
            query = step[:2]
            if 'query' in node: assert node['query'] == query
            else: node['query'] = query; node['children'] = {}
            node = node['children'].setdefault(R.compact(step[2]), {})
        assert not node
        node['terminal'] = {k: v for k, v in record.items() if k != 'path'}
    splits = Counter(); dispositions = Counter(); tree_records = []

    def visit(node, path):
        if 'terminal' in node:
            assert set(node) == {'terminal'}
            terminal = node['terminal']; dispositions[terminal['disposition']] += 1
            tree_records.append({'path': path, **terminal})
            return
        assert set(node) == {'query', 'children'}
        query = node['query']; expected = {R.compact(child) for child in branch_children(query)}
        assert set(node['children']) == expected
        splits[query[0]] += 1
        for child, subtree in sorted(node['children'].items()):
            visit(subtree, path+[query+[json.loads(child)]])

    visit(root, prefix)
    assert dispositions == {'PROVED_TERMINAL': 818, 'OPEN_PENDING': 22}
    return {'status': 'PASS_COMPLETE_CLOSED_CHILD_UNION_WITH_EXPLICIT_PENDING',
            'terminal_paths': sum(dispositions.values()), 'proved_terminal_paths': 818,
            'open_pending_paths': 22, 'split_nodes': sum(splits.values()),
            'split_kinds': dict(splits)}, tree_records


def run(replay_new=False, replay_all=False):
    started = time.monotonic()
    v3, v4, support, inherited = (load(k) for k in ('v3_source', 'v4_source', 'support_source', 'inherited_source'))
    prefix = load('prefix'); parent_pair = load('parent_pair')
    v3_review, v4_review, support_review, inherited_review = (load(k) for k in ('v3_review', 'v4_review', 'support_review', 'inherited_review'))
    records = [v3, v4, support, inherited, prefix, parent_pair, v3_review, v4_review, support_review, inherited_review]
    assert all(record['id'] == IDENT for record in records)
    assert all(record['path'] == prefix['path'] for record in (v3, v4, support, inherited, parent_pair))
    prefix_hash = R.sha(BASE/FILES['prefix'])
    assert v3['prefix_sha256'] == v4['prefix_sha256'] == parent_pair['prefix_sha256'] == prefix_hash
    assert v4['source_sha256'] == R.sha(BASE/FILES['v3_source'])
    assert support['source_sha256'] == R.sha(BASE/FILES['v4_source'])
    assert inherited['source_static_filter_sha256'] == R.sha(BASE/FILES['support_source'])
    assert inherited['parent_pair_bound_sha256'] == R.sha(BASE/FILES['parent_pair'])
    assert v3_review['status'] == 'PASS_PARTIAL_LEAVES_ONLY' and v3_review['leaves_checked'] == 629
    assert v3_review['weighted_leaves'] == 629 and v3_review['bound_deductions'] == 33
    assert v3_review['source_report_sha256'] == R.sha(BASE/FILES['v3_source'])
    assert v3_review['prefix_sha256'] == prefix_hash and v3_review['checked_indices'] == list(range(629))
    assert v3_review['leaf_replay_status'] == 'PASS'
    assert v4_review['status'] == 'PASS_ALL163_V4_PARTIAL_CANDIDATES'
    assert v4_review['candidates_checked'] == v4_review['weighted_leaves'] == 163 and v4_review['bound_deductions'] == 33
    assert v4_review['source_sha256'] == R.sha(BASE/FILES['v4_source']) and v4_review['prefix_sha256'] == prefix_hash
    assert all(r['whole_parent_closed'] is False and r['whole_mask_closed'] is False for r in (v3_review, v4_review, support_review, inherited_review))
    assert support_review['status'] == inherited_review['status'] == 'PASS_PARTIAL_FIXED_FRONTIER_FILTER'
    assert support_review['source_report_sha256'] == R.sha(BASE/FILES['support_source'])
    assert inherited_review['source_report_sha256'] == R.sha(BASE/FILES['inherited_source'])
    assert support_review['independently_closed_existing_paths'] == 24 and support_review['remaining_existing_paths'] == 24
    assert inherited_review['additional_closed_existing_paths'] == 2 and inherited_review['remaining_existing_paths'] == 22
    assert support_review['source_index_and_path_correspondence'] == inherited_review['source_index_and_path_correspondence'] == 'PASS'
    assert len(v3['leaves']) == 629 and len(v3['frontier']) == 211
    v4_by_index = {r['index']: r for r in v4['results']}
    assert len(v4_by_index) == len(v4['results']) == 211 and set(v4_by_index) == set(range(211))
    assert all(r['path'] == v3['frontier'][i]['path'] for i, r in v4_by_index.items())
    v4_closed = {i: r for i, r in v4_by_index.items() if r['status'] == 'CANDIDATE_CLOSED'}
    v4_open = {i: r for i, r in v4_by_index.items() if r['status'] == 'OPEN'}
    assert len(v4_closed) == 163 and len(v4_open) == 48 and set(v4_closed) | set(v4_open) == set(range(211))
    checked_v4 = {r['source_index']: r for r in v4_review['checked']}
    assert len(checked_v4) == len(v4_review['checked']) == 163 and set(checked_v4) == set(v4_closed)
    assert all(r['path'] == v4_closed[i]['path'] for i, r in checked_v4.items())
    support_by_index = {r['source_index']: r for r in support['results']}
    assert len(support_by_index) == len(support['results']) == 48 and set(support_by_index) == set(v4_open)
    assert all(r['path'] == v4_open[i]['path'] for i, r in support_by_index.items())
    support_closed = {i: r for i, r in support_by_index.items() if r['status'] == 'CANDIDATE_CLOSED'}
    support_open = {i: r for i, r in support_by_index.items() if r['status'] == 'OPEN_RELAXATION'}
    assert len(support_closed) == len(support_open) == 24
    checked_support = {r['original_source_index']: r for r in support_review['reviews']}
    assert set(checked_support) == set(support_closed) and len(checked_support) == len(support_review['reviews']) == 24
    inherited_by_index = {r['source_index']: r for r in inherited['results']}
    assert len(inherited_by_index) == len(inherited['results']) == 24 and set(inherited_by_index) == set(support_open)
    assert all(r['path'] == support_open[i]['path'] for i, r in inherited_by_index.items())
    newest_closed = {i: r for i, r in inherited_by_index.items() if r['status'] == 'CANDIDATE_CLOSED'}
    pending = {i: r for i, r in inherited_by_index.items() if r['status'] == 'OPEN_RELAXATION'}
    assert set(newest_closed) == {20, 57} and len(pending) == 22
    checked_inherited = {r['source_index']: r for r in inherited_review['reviews']}
    assert set(checked_inherited) == set(inherited_by_index) and len(checked_inherited) == len(inherited_review['reviews']) == 24
    assert all(r['descendant_closed'] == (i in newest_closed) for i, r in checked_inherited.items())
    assert all(r['new_branch_nodes'] == 0 for r in (v4, support, inherited))
    manifest = {relative: R.sha(BASE/relative) for relative in FILES.values()}
    for relative in (
        'global_masks/review_owner_free_support_independent.py',
        'global_masks/audit_A_owner_free_composition.py',
        'global_masks/review_owner_free_static_batch.py',
        'global_masks/review_owner_free_inherited_batch.py',
        'global_masks/WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md',
        'physical_pilots/combined_bounds/review_octagon.py',
        'physical_pilots/combined_bounds/review_unit_frame_v4.py',
        'physical_pilots/combined_bounds/review_tight_bounds_independent.py',
        'physical_pilots/combined_bounds/whole_cell_payload/weak_outer_numeric_strict_bulk_v14_verify.py',
        'physical_pilots/combined_bounds/whole_cell_payload/fixed_231_register.json',
        'sharp_frame/owner_free_relative_support.py',
        'physical_pilots/small_frontier_inspection/ordered_octagon_pair_differences.py',
    ):
        manifest[relative] = R.sha(BASE/relative)
    # The stored tables are hashed as explicit replay artifacts. The initial
    #629 and163 paths were all independently replayed, not sampled.
    proof_references = []; cover_records = []
    for index, leaf in enumerate(v3['leaves']):
        cover_records.append({'path': leaf['path'], 'disposition': 'PROVED_TERMINAL', 'context': 'v3', 'source_index': index})
    for index, record in sorted(v4_closed.items()):
        cover_records.append({'path': record['path'], 'disposition': 'PROVED_TERMINAL', 'context': 'v4', 'source_index': index})
    for group, source, reviews, folder, review_stem in (
        ('owner_free', support_closed, checked_support, BASE/'root_exploration/A_relative_support_filter', 'A_old_frontier_'),
        ('inherited_pair', inherited_by_index, checked_inherited, BASE/'sharp_frame/A_inherited_difference_filter', 'A_inherited_child_')):
        for index, entry in sorted(source.items()):
            certificate_path = folder/entry['certificate']; certificate = json.loads(certificate_path.read_text())
            review = reviews[index]
            assert certificate['id'] == IDENT and certificate['path'] == entry['path'] and certificate['status'] == entry['status']
            assert review['source_report_sha256'] == R.sha(certificate_path)
            if group == 'owner_free':
                assert review['status'] == 'PASS_NAMED_EXISTING_DESCENDANT'
                assert certificate['exact_reserve'] == entry['reserve'] == review['positive_reserve']
            else:
                assert certificate['parent_pair_bound_sha256'] == R.sha(BASE/FILES['parent_pair'])
                if index in newest_closed:
                    assert review['status'] == 'PASS_NAMED_EXISTING_DESCENDANT'
                    assert certificate['terminal']['reserve'] == entry['reserve'] == review['positive_reserve']
                else:
                    assert review['status'] == 'PASS_CERTIFIED_EXISTING_DESCENDANT_INTERVALS_ONLY'
            name = certificate_path.relative_to(BASE).as_posix(); manifest[name] = R.sha(certificate_path)
            for suffix in ('.json', '.tables.json'):
                path = BASE/'global_masks/owner_free_support_review'/(review_stem+f'{index:03d}'+suffix)
                manifest[path.relative_to(BASE).as_posix()] = R.sha(path)
            proof_references.append({'context': group, 'source_index': index, 'certificate': name,
                                     'certificate_sha256': R.sha(certificate_path), 'review_status': review['status']})
            cover_records.append({'path': entry['path'], 'disposition': 'OPEN_PENDING' if index in pending and group == 'inherited_pair' else 'PROVED_TERMINAL',
                                  'context': group, 'source_index': index})
    coverage, complete_paths = full_cover(prefix['path'], cover_records)
    # The separately saved deep leaf is useful evidence but is not an extra
    #member of this cover and is deliberately excluded from all counts.
    fresh = {'prefix_deductions': 0, 'parent_pair_deductions': 0, 'v3': 0, 'v4': 0, 'owner_free': 0, 'inherited_pair': 0}
    fresh_tables = {}
    if replay_new or replay_all:
        state, review, table = R.verify_pair_induction(BASE/FILES['parent_pair'], BASE/FILES['prefix'])
        assert not review['whole_parent_closed'] and review['new_pair_difference_deductions'] == 168
        fresh['prefix_deductions'] = review['prefix_deductions']; fresh['parent_pair_deductions'] = 168
        fresh_tables['parent_pair'] = table
        fresh_tables['new_terminals'] = []
        for index, entry in sorted(support_closed.items()):
            review, table = R.verify_certificate(BASE/'root_exploration/A_relative_support_filter'/entry['certificate'], BASE/FILES['prefix'])
            assert review['status'] == 'PASS_NAMED_EXISTING_DESCENDANT'
            fresh['owner_free'] += 1; fresh_tables['new_terminals'].append({'context': 'owner_free', 'source_index': index, 'table': table})
        for index, entry in sorted(newest_closed.items()):
            review, table = R.verify_inherited_child(BASE/'sharp_frame/A_inherited_difference_filter'/entry['certificate'], state)
            assert review['descendant_closed']
            fresh['inherited_pair'] += 1; fresh_tables['new_terminals'].append({'context': 'inherited_pair', 'source_index': index, 'table': table})
        if replay_all:
            import review_octagon as O
            import review_unit_frame_v4 as U
            fresh_tables['v3'] = []; fresh_tables['v4'] = []
            for index, leaf in enumerate(v3['leaves']):
                reserve, terminal, table = O.verify_leaf(leaf, prefix['path'], state['parent_positions'])
                assert reserve is not None or terminal is not None
                fresh['v3'] += 1; fresh_tables['v3'].append({'source_index': index, 'table': table})
            for index, entry in sorted(v4_closed.items()):
                result = U.verify_leaf(entry['leaf'], prefix['path'], state['parent_positions'])
                fresh['v4'] += 1; fresh_tables['v4'].append({'source_index': index, **result})
    result = {'id': IDENT, 'path': prefix['path'], 'status': 'PASS_FROZEN_OPEN_ORIGINAL_A_COVER',
              'whole_parent_closed': False, 'whole_mask_closed': False, 'new_branch_nodes_in_filters': 0,
              'complete_finite_cover': coverage, 'independently_replayed_terminal_counts': {'v3': 629, 'v4': 163, 'owner_free': 24, 'inherited_pair': 2},
              'total_independently_proved_terminal_paths': 818, 'remaining_pending_paths': 22,
              'all_closed_paths_independently_replayed': True, 'review_scope_is_sample_only': False,
              'fresh_replay_this_invocation': fresh, 'source_manifest': manifest,
              'pending': [{'source_index': i, 'path': r['path']} for i, r in sorted(pending.items())],
              'redundant_saved_deep_descendant_counted': False, 'seconds': time.monotonic()-started}
    tables = {'id': IDENT, 'original_parent_path': prefix['path'], 'source_manifest': manifest,
              'all_cover_paths': complete_paths, 'proof_references': proof_references, 'fresh_replay_tables': fresh_tables}
    return result, tables


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--replay-new', action='store_true')
    parser.add_argument('--replay-all', action='store_true')
    parser.add_argument('--out', type=Path, default=BASE/'global_masks/owner_free_support_review/A_complete_partial_composition.json')
    args = parser.parse_args()
    result, tables = run(args.replay_new, args.replay_all)
    args.out.parent.mkdir(exist_ok=True, parents=True)
    args.out.write_text(json.dumps(result, indent=2)+'\n')
    args.out.with_suffix('.tables.json').write_text(json.dumps(tables, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('source_manifest', 'pending')}, indent=2))


if __name__ == '__main__': main()
