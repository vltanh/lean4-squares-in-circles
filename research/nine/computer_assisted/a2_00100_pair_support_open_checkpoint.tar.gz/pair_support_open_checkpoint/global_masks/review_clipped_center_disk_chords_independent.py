#!/usr/bin/env python3
"""Independent exact audit of the separate clipped-disk chord extension.

Imports the frozen independent original-pair checker, never the chord or
discovery producer. The earlier818/22 checkpoint is left byte-for-byte intact.
"""
import argparse
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path
import time
import review_owner_free_support_independent as R

BASE = Path(__file__).resolve().parent.parent
SOURCE_SHA256 = '1f72cd4727af4a4ffa5c22e67e0de4d82cc5f4acbf15d3f9ccd038097023b694'


def chord_rows(differences, radii):
    """Derive every eligible signed cap row via its three-vertex triangle."""
    assert set(differences) == set(radii) == set(combinations(range(9), 2))
    rows, proofs = [], []
    for i, j in combinations(range(9), 2):
        (xl, xu), (yl, yu) = differences[i, j]
        radius = radii[i, j]; square = radius*radius
        assert radius > 0 and xl <= xu and yl <= yu
        for index in range(4):
            sx = -1 if index < 2 else 1
            sy = -1 if index % 2 == 0 else 1
            a, b = (xu if sx > 0 else -xl), (yu if sy > 0 else -yl)
            if a*a+b*b >= square: continue
            p = R.root_bracket(square-a*a)[0]
            q = R.root_bracket(square-b*b)[0]
            assert p >= 0 and q >= 0 and p*p <= square-a*a and q*q <= square-b*b
            first, second = b+p, a+q
            if first <= 0 or second <= 0: continue
            rhs = a*b-p*q
            vertices = ((a, b), (-q, b), (a, -p))
            norms = tuple(x*x+y*y for x, y in vertices)
            assert norms[0] < square and norms[1] <= square and norms[2] <= square
            assert first*(-q)+second*b == rhs and first*a-second*p == rhs
            assert first*a+second*b-rhs == first*second > 0
            # With u<=a,v<=b, let mu=(a-u)/second and nu=(b-v)/first.
            # A strict violation gives lambda=1-mu-nu>0. These are convex
            # weights on (a,b),(-q,b),(a,-p). The first vertex is strictly
            # inside the disk and the other two are inside its closed disk.
            # Norm-squared convexity contradicts the proved ||d||>=radius.
            entries = ((2*j, first*sx), (2*i, -first*sx),
                       (2*j+1, second*sy), (2*i+1, -second*sy))
            rows.append((R.canonical_row(entries), rhs, f'clipped_center_disk_{i}_{j}_{sx}_{sy}'))
            proofs.append({'pair': [i, j], 'signs': [sx, sy], 'radius': str(radius),
                           'signed_upper_corner': [str(a), str(b)], 'p': str(p), 'q': str(q),
                           'positive_coefficients': [str(first), str(second)], 'rhs': str(rhs),
                           'vertices': [[str(x), str(y)] for x, y in vertices],
                           'vertex_squared_norms': list(map(str, norms)),
                           'corner_reserve': str(square-norms[0]), 'corner_line_gap': str(first*second)})
    return rows, proofs


def verify_certificate(report_path, state_path, parent_pair_path, prefix_path):
    started = time.monotonic(); report_path = Path(report_path); state_path = Path(state_path)
    record = json.loads(report_path.read_text()); saved_state = json.loads(state_path.read_text())
    assert record['schema'] == 'owner_free_inherited_difference_clipped_disk_v1'
    assert record['clipped_disk_source_sha256'] == SOURCE_SHA256
    assert record['owner_free_source_sha256'] == R.ROW_SOURCE_SHA256
    assert record['difference_state_sha256'] == R.sha(state_path)
    assert record['new_branch_nodes'] == 0 and record['whole_mask_closed'] is False
    assert record['status'] == 'CANDIDATE_CLOSED'
    parent, parent_review, parent_tables = R.verify_pair_induction(parent_pair_path, prefix_path)
    assert not parent_review['whole_parent_closed']
    assert record['id'] == saved_state['id'] == parent['id']
    assert record['path'] == saved_state['path'] and record['prefix_sha256'] == parent['prefix_sha256']
    assert record['prefix_deductions'] == parent_review['prefix_deductions']
    whole_parent = record['path'] == parent['path']
    prerequisite_table = None
    if whole_parent:
        assert R.sha(state_path) == R.sha(parent_pair_path)
        assert record['scope'] == 'WHOLE_ORIGINAL_PARENT'
        differences = parent['differences']
        prerequisite_review = parent_review
    else:
        assert record['scope'] == 'EXISTING_ORIGINAL_A_DESCENDANT'
        prerequisite_review, prerequisite_table = R.verify_inherited_child(state_path, parent)
        assert not prerequisite_review['descendant_closed']
        differences = R.parse_differences(saved_state['final_differences'])
    old_rows, bounds, provenance = R.collect_owner_free(record['path'], parent['path'], parent['parent_positions'])
    angles = tuple(tuple(map(F, pair)) for pair in provenance['effective_original_angles'])
    positions = tuple(tuple(map(F, pair)) for pair in provenance['propagated_original_positions'])
    scalar = tuple(tuple(map(F, pair)) for pair in provenance['original_frame_scalar_intervals'])
    necessary, radius_proofs = R.original_pair_rows(positions, scalar, angles, differences)
    rows = old_rows[:provenance['base_rows']]+necessary+R.explicit_difference_rows(differences)
    assert len(rows) == record['base_row_count']
    radii = {tuple(proof['pair']): F(proof['radius_lower']) for proof in radius_proofs}
    additional, derivations = chord_rows(differences, radii)
    assert len(additional) == record['clipped_disk_row_count']
    assert derivations == record['clipped_disk_derivations']
    rows += additional
    terminal = record['terminal']; assert terminal['kind'] == 'positive_rational_reserve'
    assert tuple(map(F, terminal['absolute_variable_bounds'])) == bounds
    coefficients, rhs = R.exact_sum(rows, bounds, terminal['weights'])
    correction = sum(m*abs(c) for m, c in zip(bounds, coefficients)); reserve = -rhs-correction
    assert reserve > 0 and reserve == F(terminal['reserve'])
    assert coefficients == list(map(F, terminal['weighted_coefficients']))
    assert rhs == F(terminal['weighted_rhs']) and correction == F(terminal['residual_correction'])
    printed = R.print_rows(rows, {index for index, integer in terminal['weights']})
    R.compare_printed_rows(terminal['rows'], printed)
    used_chords = sum(index >= record['base_row_count'] for index, integer in terminal['weights'])
    assert used_chords == record['used_clipped_disk_rows']
    review = {'id': record['id'], 'label': record['label'],
              'status': 'PASS_COMPLETE_ORIGINAL_PARENT' if whole_parent else 'PASS_NAMED_EXISTING_DESCENDANT',
              'whole_parent_closed': whole_parent, 'whole_mask_closed': False, 'new_branch_nodes': 0,
              'source_report_sha256': R.sha(report_path), 'source_difference_state_sha256': R.sha(state_path),
              'parent_pair_bound_sha256': R.sha(parent_pair_path), 'prefix_sha256': parent['prefix_sha256'],
              'prefix_deductions': parent_review['prefix_deductions'],
              'parent_pair_deductions': parent_review['new_pair_difference_deductions'],
              'prerequisite_review': prerequisite_review, 'clipped_disk_source_sha256': SOURCE_SHA256,
              'chord_rows_independently_reconstructed': len(additional), 'weighted_chord_rows': used_chords,
              'weighted_rows': len(terminal['weights']), 'positive_reserve': str(reserve),
              'seconds': time.monotonic()-started}
    tables = {'id': record['id'], 'path': record['path'], 'parent_path': parent['path'],
              'parent_induction_tables': parent_tables, 'prerequisite_interval_tables': prerequisite_table,
              'physical_interval_provenance': provenance, 'certified_pair_differences': R.render_differences(differences),
              'radius_derivations': radius_proofs, 'chord_derivations': derivations,
              'rows': printed, 'weights': terminal['weights'], 'weight_denominator': R.SCALE,
              'absolute_variable_bounds': list(map(str, bounds)), 'weighted_coefficients': list(map(str, coefficients)),
              'weighted_rhs': str(rhs), 'residual_correction': str(correction), 'positive_reserve': str(reserve)}
    return review, tables


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, default=BASE/'sharp_frame/clipped_center_disk_probes/A_child_043.json')
    parser.add_argument('--state', type=Path, default=BASE/'sharp_frame/A_inherited_difference_filter/child_043.json')
    parser.add_argument('--parent', type=Path, default=BASE/'sharp_frame/owner_free_pair_bounds/positive-2d5aba857f2f7602.json')
    parser.add_argument('--prefix', type=Path, default=BASE/'sharp_frame/bounds/positive-2d5aba857f2f7602.json')
    parser.add_argument('--out', type=Path, default=BASE/'global_masks/clipped_disk_review/A_child_043.json')
    args = parser.parse_args()
    review, tables = verify_certificate(args.report, args.state, args.parent, args.prefix)
    args.out.parent.mkdir(exist_ok=True, parents=True)
    args.out.write_text(json.dumps(review, indent=2)+'\n')
    args.out.with_suffix('.tables.json').write_text(json.dumps(tables, indent=2)+'\n')
    print(json.dumps(review, indent=2))


if __name__ == '__main__': main()
