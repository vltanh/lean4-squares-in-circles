#!/usr/bin/env python3
"""Independent exact owner-free original-pair certificate audit.

Only the accepted frozen native row collector/verifier is imported. No new
row producer, discovery wrapper, optimizer, or floating-point data is used.
Path rows, unit-frame supports, product planes, physical interval provenance,
and the final weighted contradiction are regenerated here.
"""
import argparse
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
import hashlib
from itertools import combinations
import json
from math import gcd, isqrt
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
FROZEN = BASE / 'physical_pilots/combined_bounds'
sys.path.insert(0, str(FROZEN))
sys.path.insert(0, str(FROZEN / 'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from review_tight_bounds_independent import collect_rows, VERIFIER_SHA256

VERSION = 'owner_free_signed_folded_relative_support_v1'
LEGACY = 'strict_bulk_2026_11_03_v14'
ROW_SOURCE_SHA256 = 'b1445ad4e00a0127b201d784b72e1df2246101f567b0bf952ca46b463595e788'
THEOREM_SHA256 = '618e099086b5a98b60a38456e25dcce00d57075169aa716b1d59f0813b4ab407'
DIFFERENCE_SOURCE_SHA256 = '51a5ec13de29669abb9ac8797784120a378578d47bcfbc395b405a6965cfa97d'
SCALE = 1 << 40
DEN = 1 << 48
RHO = F(91, 60)
NEW_KINDS = ('disk8', 'disk8_ordered', 'first_two_escape', 'first_two_reduced_escape')
NORMALS = ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compact(value):
    return json.dumps(value, separators=(',', ':'))


def render(intervals):
    return [[str(a), str(b)] for a, b in intervals]


def canonical_row(entries):
    result = {}
    for index, value in entries:
        assert type(index) is int
        result[index] = result.get(index, F(0)) + F(value)
    return tuple((k, result[k]) for k in sorted(result) if result[k])


def exact_sum(rows, bounds, weights):
    assert type(weights) is list
    coefficients = [F(0)] * len(bounds)
    rhs = F(0)
    seen = set()
    for item in weights:
        assert type(item) is list and len(item) == 2
        index, integer = item
        assert type(index) is int and 0 <= index < len(rows) and index not in seen
        assert type(integer) is int and integer > 0
        seen.add(index)
        multiplier = F(integer, SCALE)
        entries, bound, _ = rows[index]
        rhs += multiplier * bound
        for column, value in entries:
            assert 0 <= column < len(coefficients)
            coefficients[column] += multiplier * value
    return coefficients, rhs


def print_rows(rows, indices):
    return [{'index': k, 'name': rows[k][2],
             'coefficients': [[j, str(v)] for j, v in canonical_row(rows[k][0])],
             'rhs': str(rows[k][1])} for k in sorted(indices)]


def root_bracket(value):
    value = F(value)
    assert value >= 0
    integer = isqrt((value.numerator * DEN * DEN) // value.denominator)
    lo = F(integer, DEN)
    hi = lo if lo * lo == value else F(integer + 1, DEN)
    assert 0 <= lo <= hi and lo * lo <= value <= hi * hi
    return lo, hi


def floor48(value):
    value = F(value) * DEN
    return F(value.numerator // value.denominator, DEN)


def ceil48(value):
    return -floor48(-F(value))


def quotient_interval(numerator, radicand):
    numerator = F(numerator)
    lo, hi = root_bracket(radicand)
    assert numerator >= 0 and lo > 0
    return floor48(numerator / hi), ceil48(numerator / lo)


def physical_frame_intervals(angles):
    """Original alpha, beta, |beta| and inset intervals, with exact rounding."""
    assert len(angles) == 9
    alpha, beta, absolute, inset = [], [], [], []
    for lower, upper in angles:
        assert -1 <= lower <= upper <= 1
        near = F(0) if lower <= 0 <= upper else min(abs(lower), abs(upper))
        far = max(abs(lower), abs(upper))
        a = (quotient_interval(1, 1 + far * far)[0],
             quotient_interval(1, 1 + near * near)[1])

        def sine(t):
            l, u = quotient_interval(abs(t), 1 + t * t)
            return (l, u) if t >= 0 else (-u, -l)

        b = (sine(lower)[0], sine(upper)[1])
        v = (quotient_interval(near, 1 + near * near)[0], max(abs(b[0]), abs(b[1])))
        supports = [quotient_interval(1 + abs(t), 1 + t * t) for t in (lower, upper)]
        hmin = F(1, 2) if lower <= 0 <= upper else min(l / 2 for l, u in supports)
        hmax = max(u / 2 for l, u in supports)
        g = (floor48(1 / (4 * hmax)), ceil48(1 / (4 * hmin)))
        # These are comparisons against the accepted physical convention,
        # not calls to the new producer's interval helper.
        assert (a, b) == V.normal_bounds((lower, upper))
        assert (hmin, hmax) == V.h_bounds((lower, upper))
        assert v[0] == V.beta_lower((lower, upper))
        alpha.append(a); beta.append(b); absolute.append(v); inset.append(g)
    return tuple(alpha + beta + absolute + inset)


def difference_intervals(positions, insets):
    """Frozen physical original-pair interval consequences, independently listed."""
    result = {}
    for i, j in combinations(range(9), 2):
        pair = (i, j)
        intervals = []
        for axis in range(2):
            lo = positions[2*j + axis][0] - positions[2*i + axis][1]
            hi = positions[2*j + axis][1] - positions[2*i + axis][0]
            if pair == (2, 3):
                lo = max(lo, insets[2] + insets[3] if axis == 0 else F(5, 8))
                hi = min(hi, F(31, 30))
            if pair == (3, 6):
                if axis == 0:
                    lo = max(lo, -F(1459, 1728)); hi = min(hi, F(1459, 1728))
                else:
                    lo = max(lo, F(0))
            if pair == (1, 5):
                lo = max(lo, F(269, 1728) if axis == 0 else insets[1] + insets[5])
                if axis == 0: hi = min(hi, F(751, 960))
            if pair == (2, 5) and axis == 1:
                lo = max(lo, insets[2] + insets[5])
            if pair == (0, 4):
                if axis == 0:
                    lo = max(lo, -F(17, 20)); hi = min(hi, F(17, 20))
                else:
                    lo = max(lo, insets[0] + insets[4])
            assert lo <= hi
            intervals.append((lo, hi))
        assert intervals == V.difference_bounds(pair, positions, insets, LEGACY)
        result[pair] = tuple(intervals)
    return result


def original_pair_rows(positions, scalar, angles, differences):
    """Regenerate all new rows by expanding nonnegative rectangle products."""
    assert len(positions) == 18 and len(scalar) == 36 and len(angles) == 9
    assert set(differences) == set(combinations(range(9), 2))
    assert all(lo <= hi for lo, hi in tuple(positions) + tuple(scalar))
    rows = []
    radius_provenance = []
    for i, j in combinations(range(9), 2):
        dr = differences[i, j]
        negative_secant = []
        secant_constant = F(0)
        for axis, (lo, hi) in enumerate(dr):
            assert lo <= hi
            negative_secant.extend(((2*i + axis, lo + hi), (2*j + axis, -lo - hi)))
            secant_constant += lo * hi
        for family, offset in (('signed', 27), ('folded', 36)):
            for epsilon in (-1, 1):
                products = ((18+i, 18+j, 1), (offset+i, offset+j, 1),
                            (18+i, offset+j, epsilon), (offset+i, 18+j, -epsilon))
                planes = []
                for x, y, sign in products:
                    xl, xu = scalar[x-18]; yl, yu = scalar[y-18]
                    if sign > 0:
                        # xy-L is (x-xl)(y-yl), or (xu-x)(yu-y).
                        alternatives = ((((x, yl), (y, xl)), -xl*yl),
                                        (((x, yu), (y, xu)), -xu*yu))
                    else:
                        # -xy-L is (xu-x)(y-yl), or (x-xl)(yu-y).
                        alternatives = ((((x, -yl), (y, -xu)), xu*yl),
                                        (((x, -yu), (y, -xl)), xl*yu))
                    # The polynomial residual has nonnegative values at all
                    # four rectangle corners, including degenerate intervals.
                    for entries, constant in alternatives:
                        for xx in (xl, xu):
                            for yy in (yl, yu):
                                assert sign*xx*yy - sum(c*(xx if k == x else yy) for k, c in entries) - constant >= 0
                    planes.append(alternatives)
                for tau in (F(1), F(9, 8), F(6, 5)):
                    assert tau >= 0
                    for selection in range(16):
                        bits = tuple((selection >> (3-k)) & 1 for k in range(4))
                        entries = list(negative_secant); constant = F(0)
                        for alternatives, bit in zip(planes, bits):
                            terms, shift = alternatives[bit]
                            entries.extend((k, tau*c) for k, c in terms)
                            constant += shift
                        name = f'owner_free_{family}_{i}_{j}_{epsilon}_{tau.numerator}_{tau.denominator}_' + ''.join(map(str, bits))
                        rhs = tau*tau - tau - tau*constant - secant_constant
                        rows.append((canonical_row(entries), rhs, name))
    assert len(rows) == 6912
    for i, j in combinations(range(9), 2):
        a, b = angles[i]; c, d = angles[j]
        if max(a, c) <= min(b, d):
            radius = F(1); endpoints = []
        else:
            endpoints = []
            for t, u in ((a, d), (b, c)):
                numerator = 1 + t*u + abs(t-u)
                radicand = (1+t*t)*(1+u*u)
                lower, upper = root_bracket(radicand)
                assert numerator >= 0 and lower > 0
                endpoints.append({'slopes': [str(t), str(u)], 'numerator': str(numerator),
                                  'radicand': str(radicand), 'root_interval': [str(lower), str(upper)],
                                  'lower_cosine_plus_absolute_sine': str(numerator/upper)})
            radius = max(F(1), (1 + min(F(e['lower_cosine_plus_absolute_sine']) for e in endpoints))/2)
        entries = []; constant = F(0)
        for axis, (lo, hi) in enumerate(differences[i, j]):
            entries.extend(((2*i + axis, lo+hi), (2*j + axis, -lo-hi)))
            constant += lo*hi
        rows.append((canonical_row(entries), -radius*radius-constant, f'owner_free_interval_radius_{i}_{j}'))
        radius_provenance.append({'pair': [i, j], 'radius_lower': str(radius), 'endpoint_calculations': endpoints})
    assert len(rows) == 6948
    return rows, radius_provenance


def octagon_rows(query):
    assert type(query) is list and len(query) == 4 and all(type(x) is int for x in query)
    i, j, numerator, denominator = query
    assert 0 <= i < j < 9 and denominator > 0 and abs(numerator) <= denominator
    assert gcd(numerator, denominator) == 1
    t = F(numerator, denominator)
    cosine, sine = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    assert cosine*cosine+sine*sine == 1
    result = []
    for index, (a, b) in enumerate(NORMALS):
        nx, ny = a*cosine-b*sine, a*sine+b*cosine
        result.append((((2*i, nx), (2*i+1, ny), (2*j, -nx), (2*j+1, -ny)),
                       -F(12 if index < 4 else 17, 13), 'disk8'))
    return result


def first_two_rows(chain, reduced):
    assert type(chain) is list and len(chain) == 4 and all(type(k) is int for k in chain)
    assert chain[3] == 3 and chain[2] != 2 and len(set(chain)) == 4
    assert all(k in (0, 1, 2, 7, 8) for k in chain[:3])
    rows = []
    for i, j in zip(chain, chain[1:]):
        if reduced and 0 <= i < j <= 2: continue
        for sign in (-1, 1):
            rows.append((((2*j, F(1)), (2*i, F(-1)), (2*j+1, F(sign)), (2*i+1, F(-sign))),
                         F(0), 'first_two_cone_escape'))
    for i, j in zip(chain[:2], chain[1:3]):
        if reduced and 0 <= i < j <= 2: continue
        rows.append((((2*j, F(1)), (2*i, F(-1)), (18+i, -F(1, 2)), (36+i, -F(1, 2)),
                      (18+j, -F(1, 2)), (36+j, -F(1, 2))), F(0), 'first_two_actual_escape'))
    assert len(rows) in ((5, 8) if reduced else (8,))
    return rows


def guarded_xs(path):
    result = set()
    for kind, query, child in path:
        if kind == 'alternate_four_escape' and query in ([1, 7], [1, 8]) and child[0] in (6, 7): result.add(query[1])
        if kind == 'first_two_escape' and query in ([0, 1, 7, 3], [0, 1, 8, 3]) and child[0] in (6, 7): result.add(query[2])
        if kind == 'first_two_reduced_escape' and query in ([0, 1, 7, 3], [0, 1, 8, 3]) and child[0] == 4: result.add(query[2])
    return sorted(result)


def path_and_unit_rows(path):
    legacy = []; rows = []; seen = set(); structural = False
    for step in path:
        assert type(step) is list and len(step) == 3
        kind, query, child = step
        if kind not in NEW_KINDS:
            legacy.append(step); continue
        assert type(child) is list and len(child) == 1 and type(child[0]) is int
        key = compact(step[:2]); assert key not in seen; seen.add(key)
        if kind.startswith('first_two'):
            possibilities = first_two_rows(query, kind == 'first_two_reduced_escape'); structural = True
        else:
            possibilities = octagon_rows(query)
        index = child[0]; assert 0 <= index < len(possibilities)
        rows.append(possibilities[index])
        if kind != 'disk8':
            for entries, rhs, name in possibilities[:index]:
                rows.append((tuple((k, -value) for k, value in entries), -rhs, name+'_closed_predecessor_complement'))
    V.reconstruct(legacy)  # All retained native choices are checked first.
    xs = guarded_xs(path)
    if structural or xs:
        assert sha(HERE/'WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md') == THEOREM_SHA256
    for x in xs:
        rows.extend([
            (((2, F(1)), (2*x, F(-1)), (46, F(1)), (45+x, F(1))), F(0), 'BX_cone_inset'),
            (((2*x, F(1)), (6, F(-1)), (45+x, F(1)), (48, F(1))), F(0), 'XD_cone_inset'),
            (((2*x, F(1)), (2, F(-1)), (19, -F(1, 2)), (37, -F(1, 2)),
              (18+x, -F(1, 2)), (36+x, -F(1, 2))), F(0), 'BX_weak'),
            (((5, F(1)), (2*x+1, F(-1)), (47, F(1)), (45+x, F(1))), F(0), 'CX_vertical_inset'),
        ])
    path_count = len(rows)
    for i in range(9):
        for p, q in V.DENSE_DIRS:
            assert p*p+q*q == 1
            rows.append((((18+i, p), (27+i, q)), F(1), 'exact_signed_unit_frame'))
        for p, q in V.DENSE_DIRS:
            if q >= 0:
                rows.append((((18+i, p), (36+i, q)), F(1), 'exact_folded_unit_frame'))
    assert len(rows)-path_count == 1737
    return legacy, rows, path_count


@lru_cache(maxsize=16)
def load_prefix(prefix_name, expected_hash):
    prefix_path = Path(prefix_name)
    assert sha(prefix_path) == expected_hash
    prefix = json.loads(prefix_path.read_text())
    registry = {r['id']: r for r in json.loads((FROZEN/'whole_cell_payload/fixed_231_register.json').read_text())['cells']}
    original = registry[prefix['id']]
    assert original['status'] == 'OPEN' and original['path'] == prefix['path']
    canonical = original['sign']+'-'+hashlib.sha256(compact(original['path']).encode()).hexdigest()[:16]
    assert canonical == original['id']
    angles, positions, choices = V.reconstruct(original['path'])
    tables = []; count = 0
    for round_index, record in enumerate(prefix['rounds']):
        rows, bounds, terminal = collect_rows(V, original['path'], angles, positions, choices)
        assert terminal is None
        updated = [list(pair) for pair in positions]
        deductions = []; used = set()
        for proposal in record['proposals']:
            objective = proposal['objective']
            assert type(objective) is list and len(objective) == 1
            variable, sign = objective[0]
            assert type(variable) is int and 0 <= variable < 18 and type(sign) is int and sign in (-1, 1)
            coefficients, rhs = exact_sum(rows, bounds, proposal['weights'])
            coefficients[variable] -= sign
            correction = sum(m*abs(c) for m, c in zip(bounds, coefficients))
            proven = rhs+correction; upper = F(proposal['upper'])
            assert proven <= upper
            if 'proved_upper' in proposal: assert proven == F(proposal['proved_upper'])
            if sign == 1: updated[variable][1] = min(updated[variable][1], upper)
            else: updated[variable][0] = max(updated[variable][0], -upper)
            used.update(index for index, weight in proposal['weights']); count += 1
            deductions.append({'objective': objective, 'upper': str(upper), 'proven_upper': str(proven),
                               'weights': proposal['weights'], 'summed_rhs': str(rhs),
                               'residual_coefficients': list(map(str, coefficients)), 'residual_correction': str(correction)})
        assert all(lo <= hi for lo, hi in updated)
        tables.append({'round': round_index, 'positions_before': render(positions), 'positions_after': render(updated),
                       'rows': print_rows(rows, used), 'absolute_variable_bounds': list(map(str, bounds)), 'deductions': deductions})
        positions = tuple(map(tuple, updated))
    return original, positions, count, tables


def collect_owner_free(path, original_path, parent_positions):
    """Reusable independent collector, with complete physical provenance."""
    assert path[:len(original_path)] == original_path
    legacy, additions, path_count = path_and_unit_rows(path)
    assert legacy[:len(original_path)] == original_path
    angles, positions, choices = V.reconstruct(legacy)
    positions = tuple((max(lo, a), min(hi, b)) for (lo, hi), (a, b) in zip(positions, parent_positions))
    assert len(positions) == 18 and all(lo <= hi for lo, hi in positions)
    native, bounds, terminal = collect_rows(V, legacy, angles, positions, choices)
    assert terminal is None
    effective, terminal = V.effective_boxes(angles, choices, LEGACY)
    assert terminal is None
    propagated, supports, insets, terminal = V.center_bounds(effective, positions, choices, LEGACY)
    assert terminal is None
    scalar = physical_frame_intervals(effective)
    differences = difference_intervals(propagated, insets)
    new_rows, radii = original_pair_rows(propagated, scalar, effective, differences)
    base = native+additions
    provenance = {'legacy_path': legacy, 'path_angles': render(angles), 'intersected_parent_positions': render(positions),
                  'effective_original_angles': render(effective), 'propagated_original_positions': render(propagated),
                  'original_frame_scalar_intervals': render(scalar), 'original_support_intervals': render(supports),
                  'original_inset_lower_bounds': list(map(str, insets)),
                  'physical_pair_difference_intervals': [{'pair': list(pair), 'intervals': render(differences[pair])} for pair in sorted(differences)],
                  'interval_radius_derivations': radii, 'native_rows': len(native), 'path_and_guard_rows': path_count,
                  'unit_frame_rows': 1737, 'base_rows': len(base), 'relative_product_rows': 6912, 'interval_radius_rows': 36}
    return base+new_rows, bounds, provenance


def parse_differences(records):
    result = {}
    for record in records:
        pair = tuple(record['pair'])
        assert pair not in result and len(pair) == 2 and all(type(k) is int for k in pair)
        assert 0 <= pair[0] < pair[1] < 9
        intervals = tuple(tuple(F(x) for x in interval) for interval in record['intervals'])
        assert len(intervals) == 2 and all(len(p) == 2 for p in intervals)
        result[pair] = intervals
    assert set(result) == set(combinations(range(9), 2))
    return result


def render_differences(differences):
    return [{'pair': list(pair), 'intervals': render(differences[pair])} for pair in sorted(differences)]


def explicit_difference_rows(differences):
    rows = []
    for (i, j), intervals in sorted(differences.items()):
        for axis, (lo, hi) in enumerate(intervals):
            assert lo <= hi
            rows.append((((2*j+axis, F(1)), (2*i+axis, F(-1))), hi, f'proved_pair_diff_upper_{i}_{j}_{axis}'))
            rows.append((((2*j+axis, F(-1)), (2*i+axis, F(1))), -lo, f'proved_pair_diff_lower_{i}_{j}_{axis}'))
    assert len(rows) == 144
    return rows


def diagonal_difference_box(step):
    """Closed ordered child k>=4 entails a rotated [5/13,12/13]^2 box."""
    assert type(step) is list and len(step) == 3 and step[0] == 'disk8_ordered'
    _, marker, child = step
    octagon_rows(marker)  # Independently validates the original physical pair/rotation.
    assert type(child) is list and len(child) == 1 and type(child[0]) is int and 4 <= child[0] < 8
    i, j, num, den = marker
    t = F(num, den); cosine = (1-t*t)/(1+t*t); sine = 2*t/(1+t*t)
    a, b = NORMALS[child[0]]
    assert a in (-1, 1) and b in (-1, 1)
    # wx=c*dx+s*dy, wy=-s*dx+c*dy. The four earlier axis
    # complements give |wx|,|wy|<=12/13; the chosen diagonal gives
    # a*wx+b*wy>=17/13, hence each signed coordinate is >=5/13.
    corners = [(a*x, b*y) for x in (F(5, 13), F(12, 13)) for y in (F(5, 13), F(12, 13))]
    original_corners = [(cosine*x-sine*y, sine*x+cosine*y) for x, y in corners]
    intervals = tuple((min(point[k] for point in original_corners), max(point[k] for point in original_corners)) for k in (0, 1))
    return (i, j), intervals, (cosine, sine), (a, b)


def verify_difference_trace(path, proved_inputs, certificate):
    """Replay an acyclic identity/native/ordered-diagonal/triangle bound trace.

    proved_inputs must be supplied by the caller from independently verified
    physical or ancestor certificates; source JSON alone never establishes it.
    """
    assert certificate['schema'] == 'ordered_octagon_pair_differences_v1'
    assert certificate['original_labels'] == 9 and certificate['path'] == path
    path_and_unit_rows(path)  # Validate the complete old/new path syntax.
    assert parse_differences(certificate['native_differences']) == proved_inputs
    upper = [[[None for j in range(9)] for i in range(9)] for axis in (0, 1)]
    ids = [[[None for j in range(9)] for i in range(9)] for axis in (0, 1)]
    checked = []; counts = {'diagonal': 0, 'triangle': 0}; initial_count = 0
    for index, record in enumerate(certificate['trace']):
        assert record['id'] == index and type(record['id']) is int
        axis, i, j = record['axis'], record['i'], record['j']
        assert type(axis) is int and axis in (0, 1)
        assert type(i) is int and type(j) is int and 0 <= i < 9 and 0 <= j < 9
        value = F(record['value']); kind = record['kind']
        if kind == 'identity':
            assert i == j and value == 0 and ids[axis][i][j] is None
            initial_count += 1
        elif kind == 'native_upper':
            pair = tuple(record['pair']); assert pair == tuple(sorted((i, j))) and i != j
            endpoint = record['endpoint']
            assert endpoint == ('upper' if i < j else 'negated_lower')
            lo, hi = proved_inputs[pair][axis]
            assert value == (hi if i < j else -lo) and ids[axis][i][j] is None
            initial_count += 1
        else:
            assert initial_count == 162 and all(k is not None for matrix in ids for row in matrix for k in row)
            assert record['previous_upper_id'] == ids[axis][i][j]
            assert value < upper[axis][i][j]
            if kind == 'ordered_diagonal_upper':
                step_index = record['step_index']; assert type(step_index) is int and 0 <= step_index < len(path)
                assert record['path_step'] == path[step_index]
                pair, intervals, rotation, signs = diagonal_difference_box(path[step_index])
                assert record['signed_rectangle'] == ['5/13', '12/13']
                assert tuple(map(F, record['rotation'])) == rotation and tuple(record['diagonal_signs']) == signs
                lo, hi = intervals[axis]
                if record['endpoint'] == 'upper':
                    assert (i, j) == pair and value == hi
                else:
                    assert record['endpoint'] == 'negated_lower' and (j, i) == pair and value == -lo
                counts['diagonal'] += 1
            else:
                assert kind == 'triangle_upper'
                via = record['via']; assert type(via) is int and 0 <= via < 9
                antecedents = record['antecedents']; assert type(antecedents) is list and len(antecedents) == 2
                left, right = antecedents
                assert type(left) is int and type(right) is int and 0 <= left < index and 0 <= right < index
                assert left == ids[axis][i][via] and right == ids[axis][via][j]
                lrow, rrow = checked[left], checked[right]
                assert (lrow['axis'], lrow['i'], lrow['j']) == (axis, i, via)
                assert (rrow['axis'], rrow['i'], rrow['j']) == (axis, via, j)
                assert value == F(lrow['value'])+F(rrow['value'])
                counts['triangle'] += 1
        upper[axis][i][j] = value; ids[axis][i][j] = index
        checked.append({**record, 'value': str(value)})
    assert initial_count == 162 and ids == certificate['final_upper_ids'] and counts == certificate['narrowings']
    terminal = certificate['terminal']
    if terminal is not None:
        assert certificate['differences'] is None
        axis = terminal['axis']; assert type(axis) is int and axis in (0, 1)
        if terminal['kind'] == 'negative_cycle':
            i = terminal['i']; assert type(i) is int and 0 <= i < 9
            assert terminal['antecedents'] == [ids[axis][i][i]]
            assert upper[axis][i][i] < 0 and F(terminal['negative_upper']) == upper[axis][i][i]
        else:
            assert terminal['kind'] == 'empty_pair_interval'
            i, j = terminal['pair']; assert type(i) is int and type(j) is int and 0 <= i < j < 9
            assert set(terminal['antecedents']) == {ids[axis][i][j], ids[axis][j][i]}
            total = upper[axis][i][j]+upper[axis][j][i]
            assert total < 0 and F(terminal['negative_zero_upper']) == total
        differences = None
    else:
        differences = {(i, j): tuple((-upper[a][j][i], upper[a][i][j]) for a in (0, 1)) for i, j in combinations(range(9), 2)}
        assert all(lo <= hi for dr in differences.values() for lo, hi in dr)
        assert all(upper[a][i][i] == 0 for a in (0, 1) for i in range(9))
        assert parse_differences(certificate['differences']) == differences
    review = {'status': 'PASS_EXACT_PAIR_INTERVAL_CONTRADICTION' if terminal else 'PASS_CERTIFIED_PATH_PAIR_INTERVALS',
              'trace_records': len(checked), 'initial_records': initial_count, 'narrowings': counts, 'terminal': terminal,
              'whole_parent_closed': False, 'whole_mask_closed': False}
    return differences, review, {'checked_trace': checked, 'final_upper_ids': ids,
                                 'differences': None if differences is None else render_differences(differences)}


def compare_printed_rows(source, expected):
    assert len(source) == len(expected)
    for item, row in zip(source, expected):
        normalized = {'index': item['index'], 'name': item['name'],
                      'coefficients': [[k, str(v)] for k, v in canonical_row(item['coefficients'])],
                      'rhs': str(F(item['rhs']))}
        assert normalized == row, ('printed row disagreement', item['index'], item['name'], row['name'])


def verify_pair_induction(report_path, prefix_path):
    """Replay whole-parent pair bounds; rounds never use their own proposals."""
    started = time.monotonic(); report_path = Path(report_path)
    assert sha(V.__file__) == VERIFIER_SHA256
    record = json.loads(report_path.read_text())
    assert record['schema'] == 'owner_free_pair_difference_induction_v1'
    assert record['owner_free_source_sha256'] == ROW_SOURCE_SHA256
    assert record['whole_mask_closed'] is False and record['new_branch_nodes'] == 0
    original, parent_positions, old_count, prefix_tables = load_prefix(str(Path(prefix_path).resolve()), record['prefix_sha256'])
    assert record['id'] == original['id'] and record['path'] == original['path']
    assert record['prefix_deductions'] == old_count
    initial_rows, bounds, provenance = collect_owner_free(record['path'], original['path'], parent_positions)
    base = initial_rows[:provenance['base_rows']]
    angles = tuple(tuple(map(F, p)) for p in provenance['effective_original_angles'])
    positions = tuple(tuple(map(F, p)) for p in provenance['propagated_original_positions'])
    scalar = tuple(tuple(map(F, p)) for p in provenance['original_frame_scalar_intervals'])
    differences = parse_differences(provenance['physical_pair_difference_intervals'])
    assert parse_differences(record['initial_differences']) == differences
    rounds = []; total = 0; closed = None; reserve = None

    def rows_for(old):
        necessary, radii = original_pair_rows(positions, scalar, angles, old)
        return base+necessary+explicit_difference_rows(old)

    for round_index, saved in enumerate(record['rounds']):
        assert saved['round'] == round_index and round_index < record['maximum_rounds']
        assert parse_differences(saved['differences_before']) == differences
        assert all(lo <= hi for dr in differences.values() for lo, hi in dr)
        rows = rows_for(differences)
        assert saved['row_count'] == len(rows) and tuple(map(F, saved['absolute_variable_bounds'])) == bounds
        next_intervals = {pair: [list(p) for p in dr] for pair, dr in differences.items()}
        used = set(); deductions = []
        for proposal in saved['proposals']:
            i, j = proposal['pair']; axis = proposal['axis']; sign = proposal['sign']
            assert type(i) is int and type(j) is int and 0 <= i < j < 9
            assert type(axis) is int and axis in (0, 1) and type(sign) is int and sign in (-1, 1)
            coefficients, rhs = exact_sum(rows, bounds, proposal['weights'])
            # Objective is sign*(center_j[axis]-center_i[axis]).
            coefficients[2*i+axis] += sign
            coefficients[2*j+axis] -= sign
            correction = sum(m*abs(c) for m, c in zip(bounds, coefficients))
            proven = rhs+correction; upper = F(proposal['upper'])
            assert proven <= upper and proven == F(proposal['proved_upper'])
            assert rhs == F(proposal['rhs']) and correction == F(proposal['residual_correction'])
            printed_residual = [[k, str(c)] for k, c in enumerate(coefficients) if c]
            assert printed_residual == proposal['residual']
            if sign == 1: next_intervals[i, j][axis][1] = min(next_intervals[i, j][axis][1], upper)
            else: next_intervals[i, j][axis][0] = max(next_intervals[i, j][axis][0], -upper)
            total += 1; used.update(index for index, integer in proposal['weights'])
            deductions.append({'pair': [i, j], 'axis': axis, 'sign': sign, 'upper': str(upper),
                               'proved_upper': str(proven), 'slack': str(upper-proven),
                               'weights': proposal['weights'], 'residual_coefficients': printed_residual,
                               'summed_rhs': str(rhs), 'residual_correction': str(correction)})
        # No update can affect any row or objective within the same round.
        updated = {pair: tuple(map(tuple, dr)) for pair, dr in next_intervals.items()}
        printed = print_rows(rows, used)
        compare_printed_rows(saved['printed_rows'], printed)
        rounds.append({'round': round_index, 'differences_before': render_differences(differences),
                       'differences_after': render_differences(updated), 'row_count': len(rows),
                       'rows': printed, 'absolute_variable_bounds': list(map(str, bounds)), 'deductions': deductions})
        differences = updated
        if any(lo > hi for dr in differences.values() for lo, hi in dr):
            assert record['status'] == 'CANDIDATE_CLOSED_EMPTY_PAIR_INTERVAL'
            assert round_index == len(record['rounds'])-1
            closed = 'empty_proved_original_pair_interval'; break
    assert parse_differences(record['final_differences']) == differences
    terminal_table = None
    if record['status'] == 'CANDIDATE_CLOSED':
        terminal = record['terminal']; saved = terminal['state']
        assert saved['round'] == len(record['rounds']) and parse_differences(saved['differences_before']) == differences
        rows = rows_for(differences)
        assert saved['row_count'] == len(rows) and tuple(map(F, terminal['absolute_bounds'])) == bounds
        coefficients, rhs = exact_sum(rows, bounds, terminal['weights'])
        correction = sum(m*abs(c) for m, c in zip(bounds, coefficients)); reserve = -rhs-correction
        assert reserve > 0 and reserve == F(terminal['reserve'])
        assert coefficients == list(map(F, terminal['residual'])) and rhs == F(terminal['rhs'])
        printed = print_rows(rows, {index for index, integer in terminal['weights']})
        compare_printed_rows(terminal['printed_rows'], printed)
        terminal_table = {'rows': printed, 'weights': terminal['weights'], 'absolute_variable_bounds': list(map(str, bounds)),
                          'weighted_coefficients': list(map(str, coefficients)), 'weighted_rhs': str(rhs),
                          'residual_correction': str(correction), 'positive_reserve': str(reserve)}
        closed = 'positive_rational_reserve'
    elif closed is None:
        assert record['status'] in ('OPEN', 'OPEN_SOLVER_FAILURE')
        if 'terminal_state' in record:
            assert record['terminal_state']['round'] == len(record['rounds'])
            assert parse_differences(record['terminal_state']['differences_before']) == differences
    state = {'id': original['id'], 'path': original['path'], 'parent_positions': parent_positions,
             'effective_angles': angles, 'propagated_positions': positions, 'scalar': scalar,
             'differences': differences, 'source_sha256': sha(report_path), 'prefix_sha256': record['prefix_sha256']}
    review = {'id': original['id'], 'status': 'PASS_COMPLETE_ORIGINAL_PARENT' if closed else 'PASS_CERTIFIED_PAIR_DIFFERENCE_STATE',
              'whole_parent_closed': bool(closed), 'whole_mask_closed': False, 'new_branch_nodes': 0,
              'source_report_sha256': sha(report_path), 'prefix_sha256': record['prefix_sha256'],
              'prefix_deductions': old_count, 'new_pair_difference_deductions': total, 'rounds': len(rounds),
              'native_verifier_sha256': VERIFIER_SHA256, 'owner_free_row_source_sha256': ROW_SOURCE_SHA256,
              'closure': closed, 'positive_reserve': str(reserve), 'seconds': time.monotonic()-started}
    tables = {'id': original['id'], 'path': original['path'], 'prefix_tables': prefix_tables,
              'physical_interval_provenance': provenance, 'rounds': rounds,
              'final_differences': render_differences(differences), 'terminal': terminal_table}
    return state, review, tables


def verify_inherited_child(report_path, parent_state):
    """Check one existing descendant using an already independently proved parent state."""
    started = time.monotonic(); report_path = Path(report_path)
    record = json.loads(report_path.read_text())
    assert record['schema'] == 'owner_free_inherited_parent_and_octagon_differences_v1'
    assert record['id'] == parent_state['id'] and record['path'][:len(parent_state['path'])] == parent_state['path']
    assert record['parent_pair_bound_sha256'] == parent_state['source_sha256']
    assert record['prefix_sha256'] == parent_state['prefix_sha256']
    assert record['owner_free_source_sha256'] == ROW_SOURCE_SHA256
    assert record['difference_propagator_sha256'] == DIFFERENCE_SOURCE_SHA256
    assert record['new_branch_nodes'] == 0 and record['whole_mask_closed'] is False
    rows, bounds, provenance = collect_owner_free(record['path'], parent_state['path'], parent_state['parent_positions'])
    native = parse_differences(provenance['physical_pair_difference_intervals'])
    assert parse_differences(record['native_differences']) == native
    inherited = {pair: tuple((max(lo, a), min(hi, b)) for (lo, hi), (a, b) in zip(dr, parent_state['differences'][pair]))
                 for pair, dr in native.items()}
    assert parse_differences(record['parent_intersected_differences']) == inherited
    final, trace_review, trace_table = verify_difference_trace(record['path'], inherited, record['difference_derivation'])
    reserve = None; terminal_table = None; closed = final is None
    if final is None:
        assert record['status'] == 'CANDIDATE_CLOSED'
        assert record['terminal']['kind'] == 'exact_pair_difference_contradiction'
        assert record['terminal']['detail'] == record['difference_derivation']['terminal']
        terminal_table = {'kind': 'exact_pair_difference_contradiction', 'detail': trace_review['terminal']}
    else:
        assert parse_differences(record['final_differences']) == final
        assert record['row_count'] == provenance['base_rows']+6948+144
        if record['status'] == 'CANDIDATE_CLOSED':
            positions = tuple(tuple(map(F, p)) for p in provenance['propagated_original_positions'])
            angles = tuple(tuple(map(F, p)) for p in provenance['effective_original_angles'])
            scalar = tuple(tuple(map(F, p)) for p in provenance['original_frame_scalar_intervals'])
            updated, radii = original_pair_rows(positions, scalar, angles, final)
            rows = rows[:provenance['base_rows']]+updated+explicit_difference_rows(final)
            terminal = record['terminal']; assert terminal['kind'] == 'positive_rational_reserve'
            assert tuple(map(F, terminal['absolute_variable_bounds'])) == bounds
            coefficients, rhs = exact_sum(rows, bounds, terminal['weights'])
            correction = sum(m*abs(c) for m, c in zip(bounds, coefficients)); reserve = -rhs-correction
            assert reserve > 0 and reserve == F(terminal['reserve'])
            assert coefficients == list(map(F, terminal['weighted_coefficients']))
            assert rhs == F(terminal['weighted_rhs']) and correction == F(terminal['residual_correction'])
            printed = print_rows(rows, {index for index, integer in terminal['weights']})
            compare_printed_rows(terminal['rows'], printed)
            terminal_table = {'rows': printed, 'weights': terminal['weights'], 'absolute_variable_bounds': list(map(str, bounds)),
                              'weighted_coefficients': list(map(str, coefficients)), 'weighted_rhs': str(rhs),
                              'residual_correction': str(correction), 'positive_reserve': str(reserve),
                              'interval_radius_derivations': radii}
            closed = True
        else:
            assert record['status'] in ('OPEN_RELAXATION', 'OPEN_SOLVER_FAILURE')
    review = {'id': record['id'], 'source_index': record['source_index'],
              'status': 'PASS_NAMED_EXISTING_DESCENDANT' if closed else 'PASS_CERTIFIED_EXISTING_DESCENDANT_INTERVALS_ONLY',
              'descendant_closed': closed, 'whole_parent_closed': False, 'whole_mask_closed': False,
              'new_branch_nodes': 0, 'source_report_sha256': sha(report_path),
              'parent_pair_bound_sha256': parent_state['source_sha256'], 'prefix_sha256': parent_state['prefix_sha256'],
              'trace_review': trace_review, 'positive_reserve': str(reserve), 'seconds': time.monotonic()-started}
    table = {'id': record['id'], 'path': record['path'], 'parent_path': parent_state['path'],
             'physical_interval_provenance': provenance, 'parent_intersected_differences': render_differences(inherited),
             'difference_trace': trace_table, 'terminal': terminal_table}
    return review, table


def verify_certificate(report_path, prefix_path):
    started = time.monotonic(); report_path = Path(report_path)
    assert sha(V.__file__) == VERIFIER_SHA256
    report = json.loads(report_path.read_text())
    assert report['context_version'] == VERSION and report['new_row_source_sha256'] == ROW_SOURCE_SHA256
    assert report['status'] == 'CANDIDATE_CLOSED' and report['new_branch_nodes'] == 0 and report['whole_mask_closed'] is False
    original, parent_positions, deductions, prefix_tables = load_prefix(str(Path(prefix_path).resolve()), report['prefix_sha256'])
    assert report['id'] == original['id'] and report['prefix_deductions'] == deductions
    whole_parent = report['path'] == original['path']
    assert report['scope'] == ('WHOLE_ORIGINAL_PARENT' if whole_parent else 'NAMED_EXISTING_DESCENDANT')
    rows, bounds, provenance = collect_owner_free(report['path'], original['path'], parent_positions)
    assert report['base_rows'] == provenance['base_rows'] and report['new_rows'] == 6948
    assert tuple(map(F, report['absolute_variable_bounds'])) == bounds
    coefficients, rhs = exact_sum(rows, bounds, report['weights'])
    correction = sum(m*abs(c) for m, c in zip(bounds, coefficients))
    reserve = -rhs-correction
    assert reserve > 0 and reserve == F(report['exact_reserve'])
    assert coefficients == list(map(F, report['weighted_coefficients'])) and rhs == F(report['weighted_rhs'])
    used = {index for index, integer in report['weights']}
    printed = print_rows(rows, used)
    compare_printed_rows(report['used_rows'], printed)
    used_new = [rows[k][2] for k in used if k >= report['base_rows']]
    summary = {'id': original['id'], 'label': report.get('label'), 'status': 'PASS_COMPLETE_ORIGINAL_PARENT' if whole_parent else 'PASS_NAMED_EXISTING_DESCENDANT',
               'scope': report['scope'], 'whole_parent_closed': whole_parent, 'whole_mask_closed': False,
               'new_branch_nodes': 0, 'source_report_sha256': sha(report_path), 'prefix_sha256': report['prefix_sha256'],
               'prefix_deductions': deductions, 'native_verifier_sha256': VERIFIER_SHA256, 'new_row_source_sha256': ROW_SOURCE_SHA256,
               'base_rows': provenance['base_rows'], 'new_rows_reconstructed': 6948, 'weighted_rows': len(used),
               'weighted_new_rows': len(used_new), 'weighted_new_families': dict(Counter(name.split('_')[2] for name in used_new)),
               'positive_reserve': str(reserve), 'seconds': time.monotonic()-started}
    table = {'id': original['id'], 'path': report['path'], 'original_parent_path': original['path'],
             'prefix_tables': prefix_tables, 'physical_interval_provenance': provenance, 'rows': printed,
             'weights': report['weights'], 'weight_denominator': SCALE, 'absolute_variable_bounds': list(map(str, bounds)),
             'weighted_coefficients': list(map(str, coefficients)), 'weighted_rhs': str(rhs),
             'residual_correction': str(correction), 'positive_reserve': str(reserve)}
    return summary, table


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('report')
    parser.add_argument('--prefix', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    record = json.loads(Path(args.report).read_text())
    if record.get('schema') == 'owner_free_pair_difference_induction_v1':
        _, review, table = verify_pair_induction(args.report, args.prefix)
    else:
        review, table = verify_certificate(args.report, args.prefix)
    output = Path(args.out); output.parent.mkdir(exist_ok=True, parents=True)
    output.write_text(json.dumps(review, indent=2)+'\n')
    output.with_suffix('.tables.json').write_text(json.dumps(table, indent=2)+'\n')
    print(json.dumps(review, indent=2))


if __name__ == '__main__': main()
