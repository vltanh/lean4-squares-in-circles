#!/usr/bin/env python3
"""Portable819/21 composition overlay; preserves the frozen818/22 checkpoint."""
import argparse
from collections import Counter
import json
from pathlib import Path
import time
import audit_A_owner_free_composition as OLD
import review_clipped_center_disk_chords_independent as C
import review_owner_free_support_independent as R

BASE = Path(__file__).resolve().parent.parent
FOLDER = BASE/'sharp_frame/clipped_center_disk_probes'


def run(replay_new=False, replay_all=False):
    started = time.monotonic()
    old_review, old_tables = OLD.run(replay_new=replay_new, replay_all=replay_all)
    assert old_review['total_independently_proved_terminal_paths'] == 818 and old_review['remaining_pending_paths'] == 22
    old_pending = {row['source_index']: row['path'] for row in old_review['pending']}
    summary_path = FOLDER/'summary.json'; summary = json.loads(summary_path.read_text())
    assert summary['new_branch_nodes'] == 0 and summary['whole_mask_closed'] is False
    roots = {record['id']: record for record in summary['whole_parent_results']}
    assert set(roots) == {'positive-2d5aba857f2f7602', 'negative-16a2fc93c8d133f0'}
    assert all(record['status'] == 'OPEN_RELAXATION' for record in roots.values())
    by_index = {}
    for entry in summary['child_results']:
        label = entry['label']; assert label.startswith('A_child_')
        index = int(label[len('A_child_'):]); assert label == f'A_child_{index:03d}' and index not in by_index
        by_index[index] = entry
    assert len(by_index) == len(summary['child_results']) == 22 and set(by_index) == set(old_pending)
    overlay_manifest = {'sharp_frame/clipped_center_disk_probes/summary.json': R.sha(summary_path)}
    candidates = []; pending = []; mapping = []
    for index, entry in sorted(by_index.items()):
        assert entry['path'] == old_pending[index]
        certificate_path = FOLDER/(entry['label']+'.json'); certificate = json.loads(certificate_path.read_text())
        assert certificate['id'] == OLD.IDENT and certificate['path'] == entry['path'] and certificate['label'] == entry['label']
        assert certificate['status'] == entry['status'] and certificate['scope'] == 'EXISTING_ORIGINAL_A_DESCENDANT'
        assert certificate['clipped_disk_source_sha256'] == C.SOURCE_SHA256
        assert certificate['owner_free_source_sha256'] == R.ROW_SOURCE_SHA256
        assert certificate['new_branch_nodes'] == 0 and certificate['whole_mask_closed'] is False
        old_state = BASE/'sharp_frame/A_inherited_difference_filter'/f'child_{index:03d}.json'
        assert certificate['difference_state_sha256'] == R.sha(old_state)
        overlay_manifest[certificate_path.relative_to(BASE).as_posix()] = R.sha(certificate_path)
        mapping.append({'source_index': index, 'path': entry['path'], 'status': entry['status'],
                        'source_state_sha256': R.sha(old_state), 'certificate_sha256': R.sha(certificate_path)})
        if entry['status'] == 'CANDIDATE_CLOSED': candidates.append(index)
        else:
            assert entry['status'] == 'OPEN_RELAXATION'
            pending.append({'source_index': index, 'path': entry['path']})
    assert candidates == [43] and len(pending) == 21
    # The one new terminal is freshly checked on every invocation. The older
    #818 can be freshly checked with --replay-all, independently of this layer.
    review, tables = C.verify_certificate(
        FOLDER/'A_child_043.json', BASE/'sharp_frame/A_inherited_difference_filter/child_043.json',
        BASE/'sharp_frame/owner_free_pair_bounds/positive-2d5aba857f2f7602.json',
        BASE/'sharp_frame/bounds/positive-2d5aba857f2f7602.json')
    assert review['status'] == 'PASS_NAMED_EXISTING_DESCENDANT' and not review['whole_parent_closed']
    new_cover = []
    replacements = 0
    for record in old_tables['all_cover_paths']:
        if record['disposition'] == 'OPEN_PENDING' and record['source_index'] == 43:
            assert record['path'] == old_pending[43]
            new_cover.append({**record, 'disposition': 'PROVED_TERMINAL', 'context': 'clipped_center_disk'})
            replacements += 1
        else: new_cover.append(record)
    assert replacements == 1
    counts = Counter(record['disposition'] for record in new_cover)
    assert counts == {'PROVED_TERMINAL': 819, 'OPEN_PENDING': 21}
    # Replacing a terminal's disposition changes no split or path. Therefore
    #the complete840-path union checked by the frozen audit remains exactly
    #the same union, with one additional proved leaf and one fewer placeholder.
    assert [record['path'] for record in new_cover] == [record['path'] for record in old_tables['all_cover_paths']]
    for name in (
        'global_masks/review_clipped_center_disk_chords_independent.py',
        'global_masks/audit_A_clipped_disk_overlay.py',
        'sharp_frame/clipped_center_disk_chords.py',
        'sharp_frame/probe_clipped_center_disk_chords.py',
        'sharp_frame/CLIPPED_CENTER_DISK_CHORD_HAND_LEMMA.md',
    ):
        overlay_manifest[name] = R.sha(BASE/name)
    result = {'id': OLD.IDENT, 'path': old_review['path'], 'status': 'PASS_FROZEN_OPEN_ORIGINAL_A_CHORD_OVERLAY',
              'whole_parent_closed': False, 'whole_mask_closed': False, 'new_branch_nodes': 0,
              'base_checkpoint_proved_paths': 818, 'base_checkpoint_pending_paths': 22,
              'additional_proved_existing_paths': 1, 'total_independently_proved_terminal_paths': 819,
              'remaining_pending_paths': 21, 'complete_finite_cover': True, 'cover_paths': 840,
              'split_nodes': old_review['complete_finite_cover']['split_nodes'],
              'all22_previous_pending_paths_mapped_exactly': True,
              'all_closed_paths_independently_replayed': True, 'whole_parent_static_results': roots,
              'fresh_base_replay_this_invocation': old_review['fresh_replay_this_invocation'],
              'new_chord_review': review, 'pending': pending, 'source_manifest': old_review['source_manifest'],
              'overlay_manifest': overlay_manifest, 'seconds': time.monotonic()-started}
    table = {'id': OLD.IDENT, 'base_composition': old_tables, 'all22_source_mappings': mapping,
             'new_chord_tables': tables, 'all_cover_paths': new_cover}
    return result, table


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--replay-new', action='store_true')
    parser.add_argument('--replay-all', action='store_true')
    parser.add_argument('--out', type=Path, default=BASE/'global_masks/clipped_disk_review/A_819_21_overlay.json')
    args = parser.parse_args()
    review, tables = run(args.replay_new, args.replay_all)
    args.out.parent.mkdir(exist_ok=True, parents=True)
    args.out.write_text(json.dumps(review, indent=2)+'\n')
    args.out.with_suffix('.tables.json').write_text(json.dumps(tables, indent=2)+'\n')
    print(json.dumps({k: v for k, v in review.items() if k not in ('pending', 'source_manifest', 'overlay_manifest', 'new_chord_review')}, indent=2))


if __name__ == '__main__': main()
