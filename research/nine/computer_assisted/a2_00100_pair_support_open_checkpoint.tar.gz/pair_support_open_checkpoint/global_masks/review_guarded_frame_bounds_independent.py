#!/usr/bin/env python3
"""Independent exact audit of parent coordinate and original-frame induction.

No discovery producer, optimizer, or producer replay function is imported.
The frozen physical rows are collected without weights, independently summed,
and printed. Every round uses only its predecessor's proved intervals.
"""
import argparse,hashlib,json,sys,time
from fractions import Fraction as F
from pathlib import Path

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
CERTIFIED=BASE/'physical_pilots/combined_bounds'
sys.path.insert(0,str(CERTIFIED));sys.path.insert(0,str(CERTIFIED/'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from review_tight_bounds_independent import collect_rows,weighted_sum,printed_rows,VERIFIER_SHA256
VERSION='exact_guarded_frame_bound_induction_v1'
TREE_VERSION='exact_guarded_frame_physical_tree_v1'
NODE_VERSION='exact_guarded_frame_node_induction_v1'
SCALE=1<<40

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def intervals(value):return tuple(tuple(F(x)for x in pair)for pair in value)
def render(value):return [[str(a),str(b)]for a,b in value]

def guard_rows(path):
    # Decode first, so every selected escape and predecessor is checked by
    # the frozen syntax. The guard is a theorem premise, never a point test.
    _,_,choices=V.reconstruct(path)
    xs=sorted({pair[1]for pair,kind,choice in choices
               if kind=='alternate_four_escape'and pair in ((1,7),(1,8))and choice[0]in (6,7)})
    result=[]
    for x in xs:
        result.extend([
            (((2*x,F(1)),(2,F(-1)),(19,-F(1,2)),(37,-F(1,2)),(18+x,-F(1,2)),(36+x,-F(1,2))),F(0),f'guard_B{x}_weak'),
            (((2,F(1)),(2*x,F(-1)),(46,F(1)),(45+x,F(1))),F(0),f'guard_B{x}_inset'),
            (((2*x,F(1)),(6,F(-1)),(45+x,F(1)),(48,F(1))),F(0),f'guard_{x}D_inset'),
            (((5,F(1)),(2*x+1,F(-1)),(47,F(1)),(45+x,F(1))),F(0),f'guard_C{x}_vertical'),
        ])
    return result

def analytic_frames(angles):
    assert len(angles)==9 and all(-1<=a<=b<=1 for a,b in angles)
    normal=[V.normal_bounds(pair)for pair in angles]
    alpha=[a for a,b in normal];beta=[b for a,b in normal]
    absolute=[(V.beta_lower(pair),max(abs(b[0]),abs(b[1])))for pair,(a,b)in zip(angles,normal)]
    inset=[]
    for pair in angles:
        hlo,hhi=V.h_bounds(pair)
        inset.append((V.down(1/(4*hhi)),V.up(1/(4*hlo))))
    return tuple(alpha+beta+absolute+inset)

def beta_to_slope(beta):
    """Enclose beta/sqrt(1-beta^2); both directed endpoints are exact."""
    assert -1<beta<1
    root_lo,root_hi=V.roots(1-beta*beta);assert root_lo>0
    if beta>=0:return V.down(beta/root_hi),V.up(beta/root_lo)
    return V.down(beta/root_lo),V.up(beta/root_hi)

def infer_angles(angles,scalar):
    """Use the physical unit frame, not an LP circle relaxation."""
    answer=[];identities=[]
    for i,(old_lo,old_hi)in enumerate(angles):
        amin,amax=scalar[i];bmin,bmax=scalar[9+i];vmin,vmax=scalar[18+i]
        assert 0<amin<=amax and 0<=vmin<=vmax
        # These broad beta bounds are inherited from [-1,1] slope at the
        # original caller and only intersected later; they may not widen.
        assert -1<bmin<=bmax<1
        if amin>1 or vmin>=1:return None,'unit_frame_scalar_outside_range',identities
        cap=V.roots(1/(amin*amin)-1)[1]
        blo=beta_to_slope(bmin)[0];bhi=beta_to_slope(bmax)[1]
        lo=max(old_lo,-cap,blo);hi=min(old_hi,cap,bhi)
        abs_cap=None
        if vmax<1:
            abs_cap=beta_to_slope(vmax)[1]
            lo=max(lo,-abs_cap);hi=min(hi,abs_cap)
        lower_abs=None
        if lo>=0 or hi<=0:
            lower_abs=beta_to_slope(vmin)[0]
            if amax<1:lower_abs=max(lower_abs,V.roots(1/(amax*amax)-1)[0])
            if lo>=0:lo=max(lo,lower_abs)
            if hi<=0:hi=min(hi,-lower_abs)
        identities.append({'original':i,'old_slope_interval':[str(old_lo),str(old_hi)],
                           'alpha_interval':[str(amin),str(amax)],'beta_interval':[str(bmin),str(bmax)],
                           'absolute_beta_interval':[str(vmin),str(vmax)],'alpha_lower_slope_cap':str(cap),
                           'beta_inverse_interval':[str(blo),str(bhi)],'absolute_beta_slope_cap':str(abs_cap),
                           'one_sign_slope_floor':str(lower_abs),'new_slope_interval':[str(lo),str(hi)]})
        if lo>hi:return None,'proved_empty_original_angle_interval',identities
        answer.append((lo,hi))
    return tuple(answer),None,identities

def collect_guarded(path,angles,positions,choices,scalar,cuts=()):
    assert len(scalar)==36 and all(a<=b for a,b in scalar)
    rows,bounds,terminal=collect_rows(V,path,angles,positions,choices,cuts)
    if terminal:return rows,bounds,terminal
    rows.extend(guard_rows(path))
    for index,(lo,hi)in enumerate(scalar,18):
        rows.append((((index,F(1)),),hi,f'certified_scalar_upper_{index}'))
        rows.append((((index,F(-1)),),-lo,f'certified_scalar_lower_{index}'))
    return rows,bounds,None

def audit_proposals(rows,bounds,proposals,positions,scalar=None):
    limit=54 if scalar is not None else 18
    target=[list(p)for p in positions]+([]if scalar is None else[list(p)for p in scalar])
    printed=[];used=set()
    for index,proposal in enumerate(proposals):
        objective=proposal['objective'];assert type(objective)is list and len(objective)==1
        k,sign=objective[0];assert type(k)is int and 0<=k<limit and type(sign)is int and sign in (-1,1)
        upper=F(proposal['upper']);co,rhs=weighted_sum(rows,bounds,proposal['weights']);co[k]-=sign
        correction=sum(m*abs(c)for m,c in zip(bounds,co));proved=rhs+correction
        assert proved<=upper,('unproved original-variable bound',index,k,sign,str(proved),str(upper))
        if 'proved_upper'in proposal:assert proved==F(proposal['proved_upper'])
        if sign==1:target[k][1]=min(target[k][1],upper)
        else:target[k][0]=max(target[k][0],-upper)
        used.update(j for j,w in proposal['weights'])
        printed.append({'index':index,'coordinate':k,'sign':sign,'upper':str(upper),'proved_upper':str(proved),
                        'slack':str(upper-proved),'weights':proposal['weights'],'weight_denominator':SCALE,
                        'summed_rhs':str(rhs),'residual_coefficients':[[j,str(c)]for j,c in enumerate(co)if c],
                        'residual_correction':str(correction)})
    return tuple(map(tuple,target)),{'rows':printed_rows(rows,used),'absolute_variable_bounds':list(map(str,bounds)),
                                     'deductions':printed}

def verify_parent(record,prefix_record):
    """Return (certified_state, independent_review, printed_proof_tables)."""
    assert sha(V.__file__)==VERIFIER_SHA256
    assert record['schema']==VERSION and record['status']in ('OPEN','CANDIDATE_CLOSED')
    path=record['path'];ident=record['id']
    register={c['id']:c for c in json.loads((CERTIFIED/'whole_cell_payload/fixed_231_register.json').read_text())['cells']}
    original=register[ident];assert original['status']=='OPEN'and path==original['path']
    canonical=original['sign']+'-'+hashlib.sha256(json.dumps(path,separators=(',',':')).encode()).hexdigest()[:16]
    assert canonical==ident
    angles,positions,choices=V.reconstruct(path);positions=tuple(map(tuple,positions))
    assert record['guard_originals']==len(guard_rows(path))//4
    tables={'id':ident,'parent_path':path,'old_prefix':[],'frame_rounds':[]};old_count=0;new_count=0
    if prefix_record is not None:
        assert prefix_record['id']==ident and prefix_record['path']==path
        for ri,item in enumerate(prefix_record['rounds']):
            rows,bounds,terminal=collect_rows(V,path,angles,positions,choices)
            assert terminal is None
            updated,printed=audit_proposals(rows,bounds,item['proposals'],positions)
            assert all(a<=b for a,b in updated)
            printed.update(round=ri,positions_before=render(positions),positions_after=render(updated))
            tables['old_prefix'].append(printed);positions=updated;old_count+=len(item['proposals'])
    assert old_count==record['prefix_deductions']
    scalar=analytic_frames(angles);assert intervals(record['initial_angles'])==angles
    def finish(closure=None,reserve=None):
        state={'id':ident,'path':path,'angles':angles,'positions':positions,'scalar':scalar,'choices':choices}
        review={'id':ident,'status':'PASS_COMPLETE_ORIGINAL_PARENT'if closure else'PASS_CERTIFIED_PARENT_STATE',
                'old_coordinate_deductions':old_count,'new_original_variable_deductions':new_count,
                'frame_rounds':len(tables['frame_rounds']),'closure':closure,'reserve':str(reserve),
                'whole_mask_closed':False}
        return state,review,tables
    for ri,item in enumerate(record['rounds']):
        assert item['round']==ri
        assert intervals(item['angles_before'])==angles and intervals(item['positions_before'])==positions
        assert intervals(item['scalar_before'])==scalar
        cuts=item['circle_cuts'];rows,bounds,terminal=collect_guarded(path,angles,positions,choices,scalar,cuts)
        assert terminal is None
        updated,printed=audit_proposals(rows,bounds,item['proposals'],positions,scalar)
        printed.update(round=ri,angles_before=render(angles),positions_before=render(positions),scalar_before=render(scalar),circle_cuts=cuts)
        positions,scalar=updated[:18],updated[18:];new_count+=len(item['proposals'])
        printed.update(positions_after=render(positions),scalar_after_proposals=render(scalar));tables['frame_rounds'].append(printed)
        if any(a>b for a,b in updated):
            assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='proved_empty_scalar_interval'
            return finish('proved_empty_original_variable_interval')
        new_angles,closed,identities=infer_angles(angles,scalar);printed['physical_frame_identities']=identities
        if closed:
            assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']==closed
            return finish(closed)
        angles=new_angles
        frame=analytic_frames(angles);scalar=tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(scalar,frame))
        printed.update(angles_after=render(angles),analytic_frame_intervals=render(frame),scalar_after=render(scalar))
        if any(a>b for a,b in scalar):
            assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='proved_empty_analytic_frame_interval'
            return finish('proved_empty_analytic_frame_interval')
        assert intervals(item['angles_after'])==angles
    if record['status']=='OPEN':
        for name,value in (('final_angles',angles),('final_positions',positions),('final_scalar',scalar)):
            if name in record:assert intervals(record[name])==value
        return finish()
    final=record['terminal'];saved=final['state']
    assert intervals(saved['angles_before'])==angles and intervals(saved['positions_before'])==positions
    assert intervals(saved['scalar_before'])==scalar
    rows,bounds,terminal=collect_guarded(path,angles,positions,choices,scalar,saved['circle_cuts'])
    if terminal:
        assert final['kind']=='native_analytic'and final['label']==terminal
        tables['terminal']={'kind':terminal,'angles':render(angles),'positions':render(positions),'scalar':render(scalar)}
        return finish(terminal)
    assert final['kind']=='positive_rational_reserve'
    co,rhs=weighted_sum(rows,bounds,final['weights']);correction=sum(m*abs(c)for m,c in zip(bounds,co));reserve=-rhs-correction
    assert reserve>0 and reserve==F(final['reserve'])
    tables['terminal']={'rows':printed_rows(rows,{i for i,w in final['weights']}),'weights':final['weights'],
                        'absolute_variable_bounds':list(map(str,bounds)),'summed_coefficients':list(map(str,co)),
                        'summed_rhs':str(rhs),'residual_correction':str(correction),'positive_reserve':str(reserve)}
    return finish('positive_rational_reserve',reserve)

def load_parent(path):
    path=Path(path);record=json.loads(path.read_text());prefix=CERTIFIED/'prefixes'/(record['id']+'.json')
    prior=None
    if record['prefix_sha256']is not None:
        assert sha(prefix)==record['prefix_sha256'];prior=json.loads(prefix.read_text())
    state,review,table=verify_parent(record,prior)
    review.update(source_sha256=sha(path),native_verifier_sha256=sha(V.__file__),prefix_sha256=record['prefix_sha256'])
    return state,review,table

def child_state(parent,path):
    """Decode old split locations first; then intersect proved parent bounds."""
    assert path[:len(parent['path'])]==parent['path']
    angles,pos,ch=V.reconstruct(path)
    angles=tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(angles,parent['angles']))
    pos=tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(pos,parent['positions']))
    if any(a>b for a,b in angles+pos):return angles,pos,ch,None,'empty_certified_child_interval'
    frame=analytic_frames(angles)
    scalar=tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(frame,parent['scalar']))
    if any(a>b for a,b in scalar):return angles,pos,ch,scalar,'empty_certified_child_frame_interval'
    return angles,pos,ch,scalar,None

def verify_tree_leaf(parent,leaf):
    assert leaf['context_version']==TREE_VERSION
    angles,pos,ch,scalar,empty=child_state(parent,leaf['path'])
    table={'path':leaf['path'],'angles':render(angles),'positions':render(pos)}
    if empty:
        expected={'empty_certified_child_interval':'empty_inherited_interval',
                  'empty_certified_child_frame_interval':'empty_inherited_frame_interval'}[empty]
        assert leaf.get('terminal')in (empty,expected)
        table['terminal']=empty
        return {'status':'PASS','terminal':empty,'reserve':None},table
    table['scalar']=render(scalar)
    rows,bounds,terminal=collect_guarded(leaf['path'],angles,pos,ch,scalar,leaf.get('circle_cuts',()))
    if terminal:
        assert leaf.get('terminal')==terminal
        table['terminal']=terminal
        return {'status':'PASS','terminal':terminal,'reserve':None},table
    assert not leaf.get('terminal')
    co,rhs=weighted_sum(rows,bounds,leaf['weights']);correction=sum(m*abs(c)for m,c in zip(bounds,co));reserve=-rhs-correction
    assert reserve>0
    if leaf.get('checked_reserve'):assert reserve==F(leaf['checked_reserve'])
    table.update(rows=printed_rows(rows,{i for i,w in leaf['weights']}),weights=leaf['weights'],
                 absolute_variable_bounds=list(map(str,bounds)),summed_coefficients=list(map(str,co)),
                 summed_rhs=str(rhs),residual_correction=str(correction),positive_reserve=str(reserve),
                 circle_cuts=leaf.get('circle_cuts',()))
    return {'status':'PASS','terminal':None,'reserve':str(reserve)},table

def check_physical_union(prefix,leaves):
    tree={}
    for leaf in leaves:
        path=leaf['path'];assert path[:len(prefix)]==prefix;V.reconstruct(path)
        node=tree
        for kind,pair,choice in path[len(prefix):]:
            assert kind in ('proxy','sat')and len(pair)==2 and 0<=pair[0]<pair[1]<9
            assert 'leaf'not in node
            query=(kind,tuple(pair))
            if 'query'in node:assert node['query']==query
            else:node['query']=query;node['children']={}
            node=node['children'].setdefault(tuple(choice),{})
        assert not node;node['leaf']=True
    def visit(node):
        if 'leaf'in node:assert node=={'leaf':True};return
        assert set(node)=={'query','children'};kind,pair=node['query']
        expected={(axis,sign)for axis in (0,1)for sign in (-1,1)}if kind=='proxy'else{(owner,axis,sign)for owner in pair for axis in (0,1)for sign in (-1,1)}
        assert set(node['children'])==expected
        for child in node['children'].values():visit(child)
    visit(tree)

def verify_tree_record(record,parent_file):
    assert record['schema']==TREE_VERSION and record['status']=='CANDIDATE_CLOSED'
    assert not record['frontier']and not record.get('errors')
    assert sha(parent_file)==record['parent_bound_sha256']
    parent,review,parent_table=load_parent(parent_file)
    assert review['status']=='PASS_CERTIFIED_PARENT_STATE'
    assert record['id']==parent['id']and record['path']==parent['path']
    check_physical_union(parent['path'],record['leaves'])
    tables=[];least=None;weighted=0
    for leaf in record['leaves']:
        result,table=verify_tree_leaf(parent,leaf);tables.append(table)
        if result['reserve']is not None:
            r=F(result['reserve']);least=r if least is None else min(least,r);weighted+=1
    return {'id':parent['id'],'status':'PASS_COMPLETE_ORIGINAL_PARENT','leaves':len(tables),
            'weighted_leaves':weighted,'least_reserve':str(least),'parent_review':review,'whole_mask_closed':False},\
           {'id':parent['id'],'parent_proof':parent_table,'leaf_tables':tables,'whole_mask_closed':False}

def verify_node_induction(parent,record):
    """Independently check the same induction under one exhaustive child."""
    assert record['schema']==NODE_VERSION and record['status']in ('OPEN','CANDIDATE_CLOSED')
    assert record['id']==parent['id'];path=record['path']
    angles,pos,ch,scalar,empty=child_state(parent,path)
    tables={'id':parent['id'],'path':path,'rounds':[]};deductions=0
    def finish(closure=None,reserve=None):
        state={'id':parent['id'],'path':path,'angles':angles,'positions':pos,'scalar':scalar,'choices':ch}
        return state,{'status':'PASS_COMPLETE_CHILD'if closure else'PASS_CERTIFIED_CHILD_STATE',
                      'deductions':deductions,'closure':closure,'reserve':str(reserve)},tables
    if empty:
        assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']==empty
        return finish(empty)
    assert intervals(record['initial_angles'])==angles and intervals(record['initial_positions'])==pos
    assert intervals(record['initial_scalar'])==scalar
    for ri,item in enumerate(record['rounds']):
        assert item['round']==ri
        assert intervals(item['angles_before'])==angles and intervals(item['positions_before'])==pos
        assert intervals(item['scalar_before'])==scalar
        rows,bounds,terminal=collect_guarded(path,angles,pos,ch,scalar,item['circle_cuts']);assert terminal is None
        updated,printed=audit_proposals(rows,bounds,item['proposals'],pos,scalar)
        printed.update(round=ri,angles_before=render(angles),positions_before=render(pos),scalar_before=render(scalar),circle_cuts=item['circle_cuts'])
        pos,scalar=updated[:18],updated[18:];deductions+=len(item['proposals']);tables['rounds'].append(printed)
        printed.update(positions_after=render(pos),scalar_after_proposals=render(scalar))
        if any(a>b for a,b in updated):
            assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='proved_empty_scalar_interval'
            return finish('proved_empty_original_variable_interval')
        narrowed,terminal,identities=infer_angles(angles,scalar);printed['physical_frame_identities']=identities
        if terminal:
            assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']==terminal
            return finish(terminal)
        angles=narrowed;frame=analytic_frames(angles);scalar=tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(scalar,frame))
        printed.update(angles_after=render(angles),analytic_frame_intervals=render(frame),scalar_after=render(scalar))
        if any(a>b for a,b in scalar):
            assert record['status']=='CANDIDATE_CLOSED'and record['terminal']['kind']=='proved_empty_analytic_frame_interval'
            return finish('proved_empty_analytic_frame_interval')
        assert intervals(item['angles_after'])==angles
    if record['status']=='OPEN':
        for key,value in (('final_angles',angles),('final_positions',pos),('final_scalar',scalar)):
            if key in record:assert intervals(record[key])==value
        return finish()
    final=record['terminal'];saved=final['state']
    assert intervals(saved['angles_before'])==angles and intervals(saved['positions_before'])==pos
    assert intervals(saved['scalar_before'])==scalar
    rows,bounds,terminal=collect_guarded(path,angles,pos,ch,scalar,saved['circle_cuts'])
    if terminal:
        assert final['kind']=='native_analytic'and final['label']==terminal
        tables['terminal']={'kind':terminal,'angles':render(angles),'positions':render(pos),'scalar':render(scalar)}
        return finish(terminal)
    assert final['kind']=='positive_rational_reserve'
    co,rhs=weighted_sum(rows,bounds,final['weights']);correction=sum(m*abs(c)for m,c in zip(bounds,co));reserve=-rhs-correction
    assert reserve>0 and reserve==F(final['reserve'])
    tables['terminal']={'rows':printed_rows(rows,{i for i,w in final['weights']}),'weights':final['weights'],
                        'absolute_variable_bounds':list(map(str,bounds)),'summed_coefficients':list(map(str,co)),
                        'summed_rhs':str(rhs),'residual_correction':str(correction),'positive_reserve':str(reserve)}
    return finish('positive_rational_reserve',reserve)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('inputs',nargs='+');ap.add_argument('--out',default=str(HERE/'guarded_frame_independent_review.json'));args=ap.parse_args()
    started=time.monotonic();reviews=[];tables=[]
    for filename in args.inputs:
        state,review,table=load_parent(filename);reviews.append(review);tables.append(table);print(review,flush=True)
    result={'status':'PASS','parents':len(reviews),'old_coordinate_deductions':sum(r['old_coordinate_deductions']for r in reviews),
            'new_original_variable_deductions':sum(r['new_original_variable_deductions']for r in reviews),
            'reviews':reviews,'seconds':time.monotonic()-started,'whole_mask_closed':False}
    target=Path(args.out);target.write_text(json.dumps(result,indent=2)+'\n')
    target.with_name(target.stem+'_tables.json').write_text(json.dumps({'parents':tables,'whole_mask_closed':False},indent=2)+'\n')
    print('DONE',result['parents'],'new deductions',result['new_original_variable_deductions'],'seconds',result['seconds'],flush=True)
if __name__=='__main__':main()
