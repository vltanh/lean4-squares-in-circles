#!/usr/bin/env python3
"""Replay this immutable OPEN research packet with exact rational arithmetic.

This entry point never runs a producer, optimizer, Lean, Lake, or CI. Its
default mode freshly replays all 819 proved A terminals, the B pair-bound
induction, and both final partial C trees. No mode closes an original parent
or a mask. Optional fresh reports must be written outside the payload.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "global_masks"))
sys.path.insert(0, str(BASE / "physical_pilots/combined_bounds"))

CURRENT_REGISTER_SHA = "a7fd0cd7aef32e5231b8ff7a46e504ca13502e72aca1d6cb02c47d5159545d34"
BASELINE_REGISTER_SHA = "b49bf3cfd51278827e0027ec8d7ad3230303bfce799c861baa1a9b4d02ddaee6"
BASE_MANIFEST_SHA = "89cbfbcc9f4a7e8e6f4aeba10059be0dbffc755f32fa00858d37d49ef19a1ded"
CHORD_MANIFEST_SHA = "15e091bb2648ef499a52520c16e9cbc19488a0713ad9242768ea48acdce8bdbf"
BASELINE_REGISTER = "physical_pilots/combined_bounds/whole_cell_payload/fixed_231_register.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(relative):
    return json.loads((BASE / relative).read_bytes())


def progress(message):
    print(message, file=sys.stderr, flush=True)


def audit_payload():
    manifest_path = BASE / "payload_manifest.json"
    manifest = read("payload_manifest.json")
    assert manifest["schema"] == "a2_00100_pair_support_open_checkpoint_v1"
    assert manifest["A_proved_terminal_paths"] == 819
    assert manifest["A_pending_paths"] == 21
    assert manifest["new_original_parent_closures"] == manifest["new_mask_closures"] == 0
    files = manifest["files"]
    actual = set()
    for path in BASE.rglob("*"):
        assert not path.is_symlink(), ("symlink in immutable payload", str(path))
        if path.is_file() and path != manifest_path:
            actual.add(path.relative_to(BASE).as_posix())
    assert actual == set(files), ("payload file-set mismatch", sorted(actual ^ set(files)))
    for relative, expected in files.items():
        path = BASE / relative
        assert path.resolve().is_relative_to(BASE), relative
        assert path.stat().st_size == expected["bytes"], relative
        assert sha(path) == expected["sha256"], relative

    for name, digest, count in (
        ("global_masks/OWNER_FREE_SUPPORT_FROZEN_DELIVERABLES.json", BASE_MANIFEST_SHA, 214),
        ("global_masks/CLIPPED_DISK_FROZEN_OVERLAY.json", CHORD_MANIFEST_SHA, 35),
    ):
        assert sha(BASE / name) == digest
        frozen = read(name)
        assert len(frozen["files"]) == count
        for relative, expected in frozen["files"].items():
            assert sha(BASE / relative) == expected, relative

    assert sha(BASE / "current_register.json") == CURRENT_REGISTER_SHA
    assert sha(BASE / BASELINE_REGISTER) == BASELINE_REGISTER_SHA
    current = read("current_register.json")
    baseline = read(BASELINE_REGISTER)
    assert (current["original_cells"], current["closed_cells"], current["open_cells"]) == (231, 168, 63)
    assert (baseline["closed_cells"], baseline["open_cells"]) == (53, 178)
    assert not current["whole_mask_closed"] and not baseline["whole_mask_closed"]
    current_cells = {cell["id"]: cell for cell in current["cells"]}
    baseline_cells = {cell["id"]: cell for cell in baseline["cells"]}
    assert len(current_cells) == len(baseline_cells) == 231
    assert set(current_cells) == set(baseline_cells)
    assert all(current_cells[key]["path"] == cell["path"] for key, cell in baseline_cells.items())
    assert sum(cell["status"] == "OPEN" for cell in current_cells.values()) == 63

    index = read("static_parent_prefix_index.json")
    summary = read("root_exploration/remaining_original_support/summary.json")
    assert summary["processed"] == summary["targets"] == len(index) == 61
    assert summary["candidate_closed"] == summary["new_branch_nodes"] == 0
    assert summary["register_sha256"] == CURRENT_REGISTER_SHA
    assert len({entry["id"] for entry in index}) == 61
    assert {entry["id"] for entry in index} == {entry["id"] for entry in summary["results"]}
    for entry in index:
        assert sha(BASE / entry["prefix"]) == entry["prefix_sha256"]
        assert sha(BASE / entry["static_report"]) == entry["static_report_sha256"]
        prefix, report = read(entry["prefix"]), read(entry["static_report"])
        assert prefix["id"] == report["id"] == entry["id"]
        assert prefix["path"] == report["path"] == current_cells[entry["id"]]["path"]
        assert report["prefix_sha256"] == entry["prefix_sha256"]
        assert current_cells[entry["id"]]["status"] == "OPEN"
        assert report["status"] == "OPEN_RELAXATION" and report["new_branch_nodes"] == 0

    return {
        "status": "PASS_IMMUTABLE_PAYLOAD_HASHES_AND_REGISTER_BINDINGS",
        "payload_manifest_sha256": sha(manifest_path),
        "checked_files": len(files),
        "checked_bytes": sum(entry["bytes"] for entry in files.values()),
        "byte_preserved_base_layer_files": 214,
        "separate_chord_overlay_files": 35,
        "static_parent_prefixes": 61,
        "current_original_cells": 231,
        "current_closed_original_cells": 168,
        "current_open_original_cells": 63,
        "baseline_register_preserved": True,
        "new_original_parent_closures": 0,
        "new_mask_closures": 0,
        "whole_mask_closed": False,
    }


def replay_a():
    import audit_A_clipped_disk_overlay as checker
    review, tables = checker.run(replay_all=True)
    assert review["status"] == "PASS_FROZEN_OPEN_ORIGINAL_A_CHORD_OVERLAY"
    assert review["total_independently_proved_terminal_paths"] == 819
    assert review["remaining_pending_paths"] == 21 and review["cover_paths"] == 840
    assert review["complete_finite_cover"]
    assert not review["whole_parent_closed"] and not review["whole_mask_closed"]
    fresh = review["fresh_base_replay_this_invocation"]
    assert fresh == {"prefix_deductions": 33, "parent_pair_deductions": 168,
                     "v3": 629, "v4": 163, "owner_free": 24, "inherited_pair": 2}
    assert review["new_chord_review"]["status"] == "PASS_NAMED_EXISTING_DESCENDANT"
    review["new_original_parent_closures"] = 0
    review["new_mask_closures"] = 0
    return review, tables


def replay_b():
    import review_owner_free_support_independent as checker
    ident = "negative-16a2fc93c8d133f0"
    _, review, tables = checker.verify_pair_induction(
        BASE / "sharp_frame/owner_free_pair_bounds" / (ident + ".json"),
        BASE / "physical_pilots/combined_bounds/prefixes" / (ident + ".json"),
    )
    assert review["status"] == "PASS_CERTIFIED_PAIR_DIFFERENCE_STATE"
    assert review["new_pair_difference_deductions"] == 171 and review["rounds"] == 2
    assert not review["whole_parent_closed"] and not review["whole_mask_closed"]
    review["new_original_parent_closures"] = 0
    review["new_mask_closures"] = 0
    return review, tables


def replay_c():
    import review_octagon as checker
    registry = {cell["id"]: cell for cell in read(BASELINE_REGISTER)["cells"]}
    reviews, tables = [], []
    for ident, expected_leaves, expected_frontier in (
        ("negative-2f9ffd3df06e7c5f", 503, 20),
        ("negative-573078fc944ce553", 511, 43),
    ):
        relative = "physical_pilots/small_frontier_inspection/" + ident + "_v3_bounded_finish256.json"
        record = read(relative)
        assert record["status"] == "OPEN"
        assert len(record["leaves"]) == expected_leaves and len(record["frontier"]) == expected_frontier
        prefix_bytes = (BASE / "physical_pilots/combined_bounds/prefixes" / (ident + ".json")).read_bytes()
        review, table = checker.review_parent(record, prefix_bytes, registry)
        assert review["status"] == "PASS_PARTIAL_LEAVES_ONLY" and not review["whole_parent_closed"]
        assert review["leaves_checked"] == expected_leaves
        checker.verify_complete_union(record["path"], record["leaves"] +
                                      [{"path": item["path"]} for item in record["frontier"]])
        review.update(record_sha256=sha(BASE / relative), retained_frontier=expected_frontier,
                      partition_includes_unproved_frontier=True, new_original_parent_closures=0,
                      new_mask_closures=0)
        reviews.append(review)
        tables.append(table)
        progress(f"C {ident}: {expected_leaves} exact leaves, {expected_frontier} explicit pending paths; OPEN")
    return reviews, tables


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("all", "a", "b", "c", "hashes"), default="all")
    parser.add_argument("--out", type=Path, help="Optional fresh JSON report outside this immutable packet; tables are adjacent.")
    args = parser.parse_args()
    output = args.out.resolve() if args.out else None
    if output is not None:
        assert not output.is_relative_to(BASE), "Fresh reports must be outside the immutable payload."
        assert not output.with_suffix(".tables.json").is_relative_to(BASE)
        assert not output.exists() and not output.with_suffix(".tables.json").exists(), "Do not overwrite existing reports."
    start = time.monotonic()
    result = {"schema": "pair_support_open_portable_replay_v1", "mode": args.mode,
              "status": "PASS_OPEN_RESEARCH_ONLY", "whole_mask_closed": False,
              "new_original_parent_closures": 0, "new_mask_closures": 0,
              "discovery_run": False, "lean_lake_ci_run": False}
    tables = {}
    result["payload_audit"] = audit_payload()
    progress(f"Payload hashes and 61 static-parent prefixes: PASS ({result['payload_audit']['checked_files']} files)")
    if args.mode in ("all", "a"):
        progress("Fresh A replay: 819 exact terminal proofs and complete 840-path union")
        result["A"], tables["A"] = replay_a()
        progress("A: 819 exact terminal proofs, 21 explicit pending paths; OPEN")
    if args.mode in ("all", "b"):
        progress("Fresh B replay: two-round pair-difference bound induction")
        result["B"], tables["B"] = replay_b()
        progress("B: 171 exact pair-difference deductions; OPEN")
    if args.mode in ("all", "c"):
        progress("Fresh C replay: both partial trees, including all retained unproved paths in each union")
        result["C"], tables["C"] = replay_c()
    result["payload_unchanged_after_replay"] = audit_payload() == result["payload_audit"]
    assert result["payload_unchanged_after_replay"]
    result["seconds"] = time.monotonic() - start
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, indent=2) + "\n")
        output.with_suffix(".tables.json").write_text(json.dumps(tables, indent=2) + "\n")
    display = {key: value for key, value in result.items() if key not in ("A", "B", "C")}
    if "A" in result:
        display["A"] = {"proved_terminal_paths": 819, "pending_paths": 21, "whole_parent_closed": False}
    if "B" in result:
        display["B"] = {"pair_difference_deductions": 171, "whole_parent_closed": False}
    if "C" in result:
        display["C"] = [{"id": item["id"], "proved_terminal_paths": item["leaves_checked"],
                         "pending_paths": item["retained_frontier"], "whole_parent_closed": False}
                        for item in result["C"]]
    print(json.dumps(display, indent=2))


if __name__ == "__main__":
    main()
