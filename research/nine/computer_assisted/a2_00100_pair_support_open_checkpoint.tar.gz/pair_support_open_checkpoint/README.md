# Pair-support OPEN research checkpoint

This packet preserves exact proofs and explicit unresolved domains for mask `001/00`. It adds **zero original-parent closures and zero mask closures**. The copied current register remains **168 CLOSED / 63 OPEN** among the same 231 original cells. Its global mask snapshot remains 8 CLOSED / 24 OPEN. Neither the current mask nor any additional mask is declared closed by this packet.

## Exact replay

Extract the archive and run the following from any working directory, using Python 3.10 or later. The exact checker uses Python's standard library and rational arithmetic; it does not run an optimizer, discovery search, Lean, Lake, or CI.

```sh
python -I -B /absolute/path/pair_support_open_checkpoint/replay_partial.py --out /tmp/pair_support_fresh_review.json
```

The output path must be outside the packet and must not already exist. The fresh report and adjacent `pair_support_fresh_review.tables.json` retain the complete replay result and printed rational evidence. Omitting `--out` prints a concise result without writing files. All delivered source records, reviews, and tables remain unchanged.

The default replay first checks every payload SHA256 and the 61 static-parent prefix bindings, then freshly verifies the following scopes:

| Original parent | Fresh proof scope | Explicit unresolved domains | Result |
| --- | --- | ---: | --- |
| `positive-2d5aba857f2f7602` | 819 terminal proofs and the complete 840-path union | 21 | OPEN |
| `negative-16a2fc93c8d133f0` | 171 pair-difference deductions in two acyclic rounds | Whole parent remains unresolved | OPEN |
| `negative-2f9ffd3df06e7c5f` | 503 terminal proofs and complete partial-tree union | 20 | OPEN |
| `negative-573078fc944ce553` | 511 terminal proofs and complete partial-tree union | 43 | OPEN |

The A proof consists of 629 V3 terminals, 163 unit-frame V4 terminals, 24 owner-free support terminals, 2 terminals using inherited pair bounds and ordered-octagon difference propagation, and 1 clipped-center-disk chord terminal. Its 168 whole-parent pair-difference deductions and original coordinate prefix are also freshly replayed. The original finite cover has 840 terminal paths throughout; the later static filters change only which paths have proofs. The redundant saved deep-A example is preserved as research evidence and is not counted again.

Use `--mode a`, `--mode b`, or `--mode c` to replay only that named scope. `--mode hashes` checks integrity and prefix/register identity without claiming a fresh mathematical replay. Every mode explicitly reports zero new original-parent and mask closures.

## Proof boundary

The original nine physical squares, their shared frames, corners, and original pair conditions remain the mathematical caller. Numerical relaxations are used only to discover candidates. Accepted terminals have independently reconstructed exact rows, nonnegative rational weights, and a positive rational reserve after bounding the residual coefficients. Pair-bound deductions are checked in acyclic rounds: a proposal cannot use another proposal from its own round. Complete finite unions include every unresolved path as an explicit placeholder; proved descendants never replace an unresolved original parent in the register.

The independent sources reconstruct the rotated octagon cover, ordered predecessor complements, unique-penultimate selector guards, signed and folded owner-free relative-support rows, certified difference propagation, and clipped-disk chord rows. The corresponding hand proofs are included beside their sources. The selectors retain the strict original `q < 1105/256` hypothesis. The current `168/63` register is a snapshot of previously accepted work; this packet does not reproduce all proofs underlying those 168 earlier closures.

The 61 whole-parent static probes in `root_exploration/remaining_original_support` all retain `OPEN_RELAXATION`. Their source/prefix correspondence is preserved and independently audited. An open linear relaxation is neither a packing witness nor a proof that the original geometric problem is feasible.

## Immutable layers and layout

- `payload_manifest.json` binds every delivered file except itself and records the final `819/21` scope.
- `current_register.json` is the unchanged `168/63` snapshot. The original `53/178` source register remains byte-preserved under `physical_pilots/combined_bounds/whole_cell_payload/fixed_231_register.json`; the native verifier uses that historical source identity.
- `global_masks/OWNER_FREE_SUPPORT_FROZEN_DELIVERABLES.json` binds the 214 files of the earlier `818/22` layer. Those files are unchanged.
- `global_masks/CLIPPED_DISK_FROZEN_OVERLAY.json` binds the separate 35-file `819/21` overlay. Only the previously pending A source index 43 gains a proof; all other 21 pending paths are retained.
- `assembly_provenance.json` records the earlier assembly step and its byte-preserved inputs. Its `818/22` fields describe that historical layer. The final payload manifest and chord overlay describe the delivered `819/21` state.
- `historical_base/` contains the old packet's README, audit entry point, and manifest unchanged for provenance. Use the root `replay_partial.py` for this packet.
- `physical_pilots/small_frontier_inspection/` retains the exact ordered-octagon difference module, its hand proof and three checked traces, both final C trees, and the source records from the bounded inspection.
- `root_review/` includes the separate printed-arithmetic pair-bound audit and final two-C reviews/tables. The full V3 629 and V4 163 independent reviews/tables are also included.

The workspace-shaped directory layout is intentional: all exact-replay dependencies and all 61 static-parent prefixes are inside this packet. The hard `positive-2c719a20ef7510de` prefix remains at its original `global_masks/v3_fresh_2c/` relative path.

Historical discovery drivers are preserved as source records. Some refer to the separate `physical_pilots/octagon_open15_checkpoint_v1/` discovery packet, whose archive SHA256 is `59d60bc4fd77a6927d35bb6097ffa7390e3a16715230e8e72523027b7d72d49b`. Re-running those old drivers may require that separate packet and numerical dependencies. **The root exact replay has no such dependency.** No discovery driver is imported by the exact entry point.
