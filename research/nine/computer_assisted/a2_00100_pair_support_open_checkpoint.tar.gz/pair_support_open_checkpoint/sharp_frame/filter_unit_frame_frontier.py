#!/usr/bin/env python3
"""One finite, non-branching V4 pass over the saved V3 A frontier.

Discovery only. Every candidate is replayed exactly by the producer-side
collector; independent acceptance is still required. No new subtree grows.
"""
import concurrent.futures
import hashlib
import json
import time
import traceback
from pathlib import Path

HERE = Path(__file__).parent
PREFIX = HERE / 'bounds/positive-2d5aba857f2f7602.json'
SOURCE = HERE / 'positive_shallow_sat_priority.json'
OUTPUT = HERE / 'positive_shallow_unit_frame_filter.json'


def worker(index, path):
    import octagon_unit_frame_producer as P
    O = P.O
    record = json.loads(PREFIX.read_text())
    bounds, _ = O.replay_prefix(record)
    legacy, box, pos, choices, extra = O.decode(path, record['path'], bounds)
    hit, point, data = O.solve(box, pos, choices, extra)
    if hit is not None:
        leaf = json.loads(json.dumps({
            'path': path, 'legacy_physical_path': legacy, **hit,
            'context_version': P.VERSION,
            'legacy_context_version': O.LEGACY,
        }))
        try:
            reserve, terminal = O.make_exact_collector(record['path'], bounds)(leaf)
            leaf.update(checked_reserve=str(reserve), checked_terminal=terminal)
            return {'index': index, 'path': path, 'status': 'CANDIDATE_CLOSED', 'leaf': leaf}
        except Exception:
            return {'index': index, 'path': path, 'status': 'REJECTED', 'error': traceback.format_exc()}
    result = {'index': index, 'path': path, 'status': 'OPEN'}
    if point is None or O.B._last is None:
        result['reason'] = 'NO_LP_POINT'
    else:
        z = O.B._last
        result['relaxed_variables'] = list(map(float, z))
        result['signed_norm_defects'] = [float(1-z[18+i]**2-z[27+i]**2) for i in range(9)]
        result['folded_norm_defects'] = [float(1-z[18+i]**2-z[36+i]**2) for i in range(9)]
    return result


def main():
    source = json.loads(SOURCE.read_text())
    start = time.monotonic()
    results = []
    def save():
        result = {
            'schema': 'v4_nonbranching_frontier_filter',
            'id': source['id'], 'path': source['path'],
            'status': 'OPEN', 'whole_mask_closed': False,
            'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'source_file': str(SOURCE),
            'prefix_sha256': hashlib.sha256(PREFIX.read_bytes()).hexdigest(),
            'source_frontier_count': len(source['frontier']),
            'source_accepted_leaf_count': len(source['leaves']),
            'new_branch_nodes': 0,
            'results': sorted(results, key=lambda r: r['index']),
            'seconds': time.monotonic()-start,
            'scope': 'Single non-branching pass. Existing original A remains OPEN unless all frontier branches independently close.',
        }
        temporary = OUTPUT.with_suffix('.tmp')
        temporary.write_text(json.dumps(result, indent=2)+'\n')
        temporary.replace(OUTPUT)
    with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
        jobs = [pool.submit(worker, i, f['path']) for i, f in enumerate(source['frontier'])]
        for job in concurrent.futures.as_completed(jobs):
            results.append(job.result())
            if len(results)%20 == 0:
                save()
                print('completed',len(results),'closed',sum(r['status']=='CANDIDATE_CLOSED' for r in results),'seconds',round(time.monotonic()-start,1),flush=True)
    save()
    print('DONE',len(results),'closed',sum(r['status']=='CANDIDATE_CLOSED' for r in results),'open',sum(r['status']=='OPEN' for r in results),'rejected',sum(r['status']=='REJECTED' for r in results),flush=True)


if __name__ == '__main__':
    main()
