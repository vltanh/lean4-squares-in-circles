#!/usr/bin/env python3
"""V3: four reviewed ABXD consequences after the V2 conditional rows."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import octagon_structural_producer as S
O=S.O
HERE=Path(__file__).parent
VERSION='disk_octagon_structural_v3'
PREVIOUS_DECODE=O.decode
PREVIOUS_ROW=O.disk_row
PREVIOUS_SELECT=O.select

def guarded_originals(path):
    answer=set()
    for kind,marker,choice in path:
        if kind=='alternate_four_escape' and marker in ([1,7],[1,8]) and choice[0]in (6,7):answer.add(marker[1])
        elif kind=='first_two_escape' and marker in ([0,1,7,3],[0,1,8,3]) and choice[0]in (6,7):answer.add(marker[2])
        elif kind=='first_two_reduced_escape' and marker in ([0,1,7,3],[0,1,8,3]) and choice[0]==4:answer.add(marker[2])
    return tuple(sorted(answer))

def guard_rows(x):
    assert x in (7,8)
    return (
      (((2,F(1)),(2*x,F(-1)),(46,F(1)),(45+x,F(1))),F(0),'BX_cone_inset'),
      (((2*x,F(1)),(6,F(-1)),(45+x,F(1)),(48,F(1))),F(0),'XD_cone_inset'),
      (((2*x,F(1)),(2,F(-1)),(19,-F(1,2)),(37,-F(1,2)),(18+x,-F(1,2)),(36+x,-F(1,2))),F(0),'BX_weak'),
      (((5,F(1)),(2*x+1,F(-1)),(47,F(1)),(45+x,F(1))),F(0),'CX_vertical_inset'))

def decode(path,prefix,bounds):
    legacy,box,pos,ch,extra=PREVIOUS_DECODE(path,prefix,bounds)
    for x in guarded_originals(path):extra.extend((('abxd_guard',x),k) for k in range(4))
    return legacy,box,pos,ch,extra

def row(marker,choice):
    if marker[0]=='abxd_guard':
        assert len(marker)==2 and type(choice)is int and 0<=choice<4
        return guard_rows(marker[1])[choice]
    return PREVIOUS_ROW(marker,choice)

def select(box,ch,extra,z):
    seen={marker for marker,_ in extra};candidates=[]
    for x in (7,8):
        chain=(0,1,x,3);marker=('first_two_reduced_escape',*chain)
        if marker in seen:continue
        cone_rows=S.chain_rows(chain,True)[:4]
        cone_margin=min(sum(float(c)*z[k] for k,c in co)-float(rhs) for co,rhs,_ in cone_rows)
        violation=max(sum(float(c)*z[k] for k,c in co)-float(rhs) for co,rhs,_ in guard_rows(x))
        if cone_margin>1e-8 and violation>1e-8:candidates.append((min(cone_margin,violation),chain))
    if candidates:return 'first_two_reduced_escape',max(candidates)[1]
    structural=[]
    for chain in S.CHAINS:
        if ('first_two_reduced_escape',*chain) in seen:continue
        score=min(sum(float(c)*z[k] for k,c in co)-float(rhs) for co,rhs,_ in S.chain_rows(chain,True))
        if score>1e-8:structural.append((score,chain))
    if structural:return 'first_two_reduced_escape',max(structural)[1]
    centers=z[:18].reshape(9,2)
    min_distance=min(float((centers[j]-centers[i])@(centers[j]-centers[i])) for i in range(9) for j in range(i+1,9))
    if min_distance>=1-1e-5:
        selected={(pair,kind) for pair,kind,_ in ch};violated=[]
        for i in range(9):
            for j in range(i+1,9):
                pair=(i,j)
                if (pair,'sat') in selected:continue
                d=centers[j]-centers[i];ai,bi,aj,bj=z[18+i],z[27+i],z[18+j],z[27+j]
                required=.5*(1+abs(ai*aj+bi*bj)+abs(ai*bj-bi*aj))
                projection=max(abs(ai*d[0]+bi*d[1]),abs(-bi*d[0]+ai*d[1]),abs(aj*d[0]+bj*d[1]),abs(-bj*d[0]+aj*d[1]))
                if required-projection>.03:violated.append((float(required-projection),pair))
        if violated:
            pair=max(violated)[1]
            return ('sat' if (pair,'proxy') in selected else 'proxy'),pair
    return PREVIOUS_SELECT(box,ch,extra,z)

O.VERSION=VERSION;O.decode=decode;O.disk_row=row;O.select=select

def run(prefix_file,node_limit,outfile,resume=None):
    result=O.run(prefix_file,node_limit,outfile,resume)
    result['unique_penultimate_theorem_sha256']=hashlib.sha256(S.THEOREM.read_bytes()).hexdigest()
    result['unique_penultimate_theorem_file']=str(S.THEOREM)
    result['guarded_row_order']='After all V2 path rows, for each qualifying X=7,8 in ascending order: BX cone-inset, XD cone-inset, BX weak, CX vertical-inset; adaptive circle rows remain last.'
    Path(outfile).write_text(json.dumps(result,indent=2)+'\n');return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prefix',default=str(HERE/'bounds/positive-2d5aba857f2f7602.json'));ap.add_argument('--nodes',type=int,default=512);ap.add_argument('--out',default=str(HERE/'positive_shallow_guarded_octagon.json'));ap.add_argument('--resume');args=ap.parse_args()
    run(args.prefix,args.nodes,args.out,args.resume)
if __name__=='__main__':main()
