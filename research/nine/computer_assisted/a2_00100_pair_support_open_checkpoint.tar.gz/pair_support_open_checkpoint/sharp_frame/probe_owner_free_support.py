#!/usr/bin/env python3
"""Targeted static A/B owner-free row probes, with no proof-tree expansion."""
import hashlib
import json
import sys
import time
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
import octagon_unit_frame_producer as P
import owner_free_relative_support as N

HERE=Path(__file__).parent
BASE=HERE.parent
O=P.O
sys.path.insert(0,str(BASE/'global_masks'))
import review_guarded_frame_bounds_independent as R
OUT=HERE/'owner_free_support_probes'


def matrix(rows,n):
    a=np.zeros((len(rows),n));b=np.zeros(len(rows))
    for i,(co,rhs,name)in enumerate(rows):
        for k,value in co:a[i,k]+=float(value)
        b[i]=float(rhs)
    return a,b


def phase(a,b):
    n=a.shape[1]
    return linprog(np.r_[np.zeros(n),1.],A_ub=np.c_[a,-np.ones(len(b))],b_ub=b,bounds=[(None,None)]*(n+1),method='highs-ds',options={'presolve':False,'threads':1,'time_limit':20})


def pair_diagnostics(z):
    values=[]
    for i in range(9):
        for j in range(i+1,9):
            d=z[2*j:2*j+2]-z[2*i:2*i+2];norm=float(d@d)
            ai,aj=z[18+i],z[18+j]
            for family,offset in (('signed',27),('folded',36)):
                bi,bj=z[offset+i],z[offset+j];c=ai*aj+bi*bj;s=ai*bj-bi*aj;required=((1+c+abs(s))/2)**2
                values.append({'pair':[i,j],'family':family,'norm2':norm,'required_norm2_at_relaxed_frames':float(required),'deficit':float(required-norm)})
    return sorted(values,key=lambda r:r['deficit'],reverse=True)[:10]


def run(ident,prefix_file,path=None,label=None):
    started=time.monotonic();prefix=json.loads(prefix_file.read_text());bounds,deductions=O.replay_prefix(prefix)
    assert prefix['id']==ident
    path=path or prefix['path'];legacy,angles,positions,choices,extra=O.decode(path,prefix['path'],bounds)
    base,absolute_bounds,terminal=O.collect_rows(O.V,legacy,angles,positions,choices)
    assert terminal is None
    base+= [O.disk_row(marker,choice)for marker,choice in extra]
    effective,terminal=O.V.effective_boxes(angles,choices,O.LEGACY);assert terminal is None
    propagated,hs,gs,terminal=O.V.center_bounds(effective,positions,choices,O.LEGACY);assert terminal is None
    scalar=R.analytic_frames(effective)
    differences={(i,j):O.V.difference_bounds((i,j),propagated,gs,O.LEGACY)for i in range(9)for j in range(i+1,9)}
    new=N.relative_support_rows(propagated,scalar,differences=differences)+N.interval_radius_rows(propagated,effective,differences=differences)
    a,b=matrix(base,len(absolute_bounds));aa,bb=matrix(new,len(absolute_bounds));before=phase(a,b);after=phase(np.vstack((a,aa)),np.r_[b,bb])
    report={'id':ident,'label':label or ident,'scope':'WHOLE_ORIGINAL_PARENT'if path==prefix['path']else'NAMED_EXISTING_DESCENDANT',
            'path':path,'prefix_sha256':hashlib.sha256(prefix_file.read_bytes()).hexdigest(),'prefix_deductions':deductions,
            'context_version':N.VERSION,'base_rows':len(base),'new_rows':len(new),'new_branch_nodes':0,'whole_mask_closed':False,
            'new_row_source_sha256':hashlib.sha256(Path(N.__file__).read_bytes()).hexdigest(),
            'baseline_solver_status':int(before.status),'new_solver_status':int(after.status)}
    if before.success:
        z=before.x[:-1];violation=aa@z-bb;order=np.argsort(violation)[-12:][::-1]
        report.update(baseline_phase_margin=float(before.x[-1]),maximum_new_row_violation_at_baseline=float(violation.max()),
                      strongest_new_rows=[{'name':new[k][2],'violation':float(violation[k])}for k in order],baseline_pair_diagnostics=pair_diagnostics(z))
    if after.success:
        z=after.x[:-1];report.update(new_phase_margin=float(after.x[-1]),relaxed_variables=list(map(float,z)),new_pair_diagnostics=pair_diagnostics(z))
        if after.x[-1]>1e-8:
            weights=[[i,int(round(-v*(1<<40)))]for i,v in enumerate(after.ineqlin.marginals)if int(round(-v*(1<<40)))>0]
            co,rhs=O.weighted_sum(base+new,absolute_bounds,weights);reserve=-rhs-sum(m*abs(c)for m,c in zip(absolute_bounds,co))
            report.update(weights=weights,exact_reserve=str(reserve),status='CANDIDATE_CLOSED'if reserve>0 else'OPEN_NUMERICAL_CANDIDATE_REJECTED')
            if reserve>0:
                report['used_rows']=R.printed_rows(base+new,{i for i,w in weights})
                report['absolute_variable_bounds']=list(map(str,absolute_bounds));report['weighted_coefficients']=list(map(str,co));report['weighted_rhs']=str(rhs)
        else:report['status']='OPEN_RELAXATION'
    else:report['status']='NO_NUMERICAL_CONCLUSION'
    report['seconds']=time.monotonic()-started
    OUT.mkdir(exist_ok=True);(OUT/(report['label']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(report['label'],report['status'],'margin',report.get('new_phase_margin'),'old-point violation',report.get('maximum_new_row_violation_at_baseline'),'seconds',round(report['seconds'],2),flush=True)
    return report


def main():
    a=HERE/'bounds/positive-2d5aba857f2f7602.json';b=BASE/'physical_pilots/combined_bounds/prefixes/negative-16a2fc93c8d133f0.json'
    results=[run('positive-2d5aba857f2f7602',a),run('negative-16a2fc93c8d133f0',b)]
    deep=json.loads((HERE/'unit_frame_deep_probe.json').read_text())
    results.append(run('positive-2d5aba857f2f7602',a,deep['path'],'A_saved_deep_descendant'))
    (OUT/'summary.json').write_text(json.dumps({'results':[{k:v for k,v in r.items()if k not in ('relaxed_variables','path','weights','used_rows','weighted_coefficients')}for r in results],'whole_mask_closed':False},indent=2)+'\n')


if __name__=='__main__':main()
