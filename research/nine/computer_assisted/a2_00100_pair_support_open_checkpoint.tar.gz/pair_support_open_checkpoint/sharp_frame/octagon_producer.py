#!/usr/bin/env python3
"""Discovery: complete rational-octagon center-distance splits.

Original mask, parent and inherited bound proofs are unchanged. This file is
an untrusted producer; acceptance requires the separate augmented-row checker.
The old v14 source is never edited and keeps all old row indices internally.
"""
import argparse,hashlib,json,math,sys,time,traceback,warnings
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import numpy as np
HERE=Path(__file__).parent
sys.path.insert(0,str(HERE.parent/'physical_pilots/combined_bounds'))
from bound_prefix import replay_prefix
from review_tight_bounds_independent import collect_rows,weighted_sum,VERIFIER_SHA256
import weak_outer_numeric_strict_bulk_v14_verify as V
import weak_outer_numeric_strict_bulk_v14_lp as M
import weak_outer_numeric_strict_bulk_v14_branch as B
from frontier_bounded_cells import children as old_children

NORMALS=((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
VERSION='disk_octagon_v1'
LEGACY='strict_bulk_2026_11_03_v14'
MATRIX=M.matrix
M.linprog=B.capture_lp
warnings.filterwarnings('ignore')

def disk_row(marker,choice):
    i,j,p,q=marker
    assert all(type(k)is int for k in marker) and 0<=i<j<9 and q>0 and abs(p)<=q
    assert math.gcd(p,q)==1 and type(choice)is int and 0<=choice<8
    t=F(p,q);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t);assert c*c+s*s==1
    a,b=NORMALS[choice];nx=a*c-b*s;ny=a*s+b*c
    return ((2*i,nx),(2*i+1,ny),(2*j,-nx),(2*j+1,-ny)),-F(12 if choice<4 else 17,13),'disk8'

def decode(path,prefix,bounds):
    assert path[:len(prefix)]==prefix
    legacy=[];disks=[];seen=set()
    for step in path:
        if step[0]!='disk8':legacy.append(step);continue
        assert len(step)==3 and type(step[1])is list and len(step[1])==4
        assert type(step[2])is list and len(step[2])==1
        marker=tuple(step[1]);assert marker not in seen;seen.add(marker)
        disk_row(marker,step[2][0]);disks.append((marker,step[2][0]))
    box,pos,ch=V.reconstruct(legacy)
    pos=tuple((max(a,l),min(b,u)) for(a,b),(l,u) in zip(pos,bounds))
    assert all(l<=u for l,u in pos)
    return legacy,box,pos,ch,disks

def children(query):
    kind,key=query
    return [['disk8',list(key),[k]] for k in range(8)] if kind=='disk8' else old_children(query)

def union(prefix,leaves):
    root={}
    for leaf in leaves:
        assert leaf['path'][:len(prefix)]==prefix;node=root
        for step in leaf['path'][len(prefix):]:
            assert 'terminal' not in node;query=step[:2]
            if 'query'in node:assert node['query']==query
            else:node['query']=query;node['children']={}
            node=node['children'].setdefault(json.dumps(step[2]),{})
        assert not node;node['terminal']=True
    def check(node):
        if 'terminal'in node:assert set(node)=={'terminal'};return
        assert set(node['children'])=={json.dumps(x[2]) for x in children(node['query'])}
        for child in node['children'].values():check(child)
    check(root)

def make_exact_collector(prefix,bounds):
    @lru_cache(maxsize=12)
    def old_rows(legacy_json,cuts_json,analytic_json):
        legacy=json.loads(legacy_json);box,pos,ch=V.reconstruct(legacy)
        pos=tuple((max(a,l),min(b,u)) for(a,b),(l,u) in zip(pos,bounds))
        return collect_rows(V,legacy,box,pos,ch,json.loads(cuts_json),json.loads(analytic_json))
    def exact(leaf):
        assert leaf['context_version']==VERSION and leaf['legacy_context_version']==LEGACY
        legacy,box,pos,ch,disks=decode(leaf['path'],prefix,bounds)
        assert leaf['legacy_physical_path']==legacy
        analytic={k:leaf[k] for k in ('analytic_terminal','row_guard','local_radius') if k in leaf}
        cuts=leaf.get('circle_cuts',[])
        rows,variable_bounds,terminal=old_rows(json.dumps(legacy),json.dumps(cuts),json.dumps(analytic))
        if terminal:return None,terminal
        k=len(cuts);split=len(rows)-k
        rows=rows[:split]+[disk_row(marker,choice) for marker,choice in disks]+rows[split:]
        co,rhs=weighted_sum(rows,variable_bounds,leaf['weights'])
        reserve=-rhs-sum(m*abs(a) for m,a in zip(variable_bounds,co));assert reserve>0
        return reserve,None
    return exact

def solve(box,pos,ch,disks):
    def matrix(box,pos,ch,circle_cuts=()):
        assert not circle_cuts
        A,b,names,cb,hs,gs=MATRIX(box,pos,ch)
        extra=[];rhs=[]
        for marker,choice in disks:
            entries,rv,name=disk_row(marker,choice);row=np.zeros(A.shape[1])
            for col,value in entries:row[col]+=float(value)
            extra.append(row);rhs.append(float(rv));names.append('disk8_'+str(marker)+'_'+str(choice))
        if extra:A=np.vstack((A,np.array(extra)));b=np.r_[b,rhs]
        return A,b,names,cb,hs,gs
    M.matrix=matrix
    try:return M.solve(tuple(tuple(map(float,t)) for t in box),tuple(tuple(map(float,t)) for t in pos),ch)
    finally:M.matrix=MATRIX

def select(box,ch,disks,z):
    centers=z[:18].reshape(9,2);seen={marker for marker,_ in disks};candidates=[]
    for i in range(9):
        for j in range(i+1,9):
            d=centers[j]-centers[i];norm2=float(d@d)
            if norm2>=1-1e-8:continue
            phi=math.atan2(d[1],d[0])-math.atan2(5,12)
            phi=(phi+math.pi/4)%(math.pi/2)-math.pi/4
            t=F(round(math.tan(phi/2)*(1<<16)),1<<16);marker=(i,j,t.numerator,t.denominator)
            if marker in seen:continue
            margins=[-float(rv)-sum(float(co)*z[k] for k,co in row) for row,rv,_ in (disk_row(marker,k) for k in range(8))]
            # A branch row is a.z<=negative threshold. The proposal must
            # violate every row: a.z-rhs>0, equivalent to threshold-n.d>0.
            gaps=[sum(float(co)*z[k] for k,co in row)-float(rv) for row,rv,_ in (disk_row(marker,k) for k in range(8))]
            if min(gaps)>1e-9:candidates.append((1-norm2,marker))
    if candidates:return 'disk8',max(candidates)[1]
    absdef=[(float(z[36+i]-abs(z[27+i])),i) for i in range(9) if box[i][0]<0<box[i][1]]
    if absdef and max(absdef)[0]>.005:return 'angle_cut',(max(absdef)[1],'0')
    normdef=[(float(1-z[18+i]**2-z[27+i]**2),i) for i in range(9)]
    if max(normdef)[0]>.001:
        i=max(normdef)[1];eff,term=V.effective_boxes(box,ch,LEGACY);l,u=eff[i];mid=(l+u)/2
        if not box[i][0]<mid<box[i][1]:mid=sum(box[i])/2
        return 'angle_cut',(i,str(mid))
    selected={(pair,kind) for pair,kind,_ in ch};bad=[]
    for i in range(9):
        for j in range(i+1,9):
            pair=(i,j)
            if(pair,'sat')in selected:continue
            d=centers[j]-centers[i];ai,bi,aj,bj=z[18+i],z[27+i],z[18+j],z[27+j]
            req=.5*(1+abs(ai*aj+bi*bj)+abs(ai*bj-bi*aj))
            projection=max(abs(ai*d[0]+bi*d[1]),abs(-bi*d[0]+ai*d[1]),abs(aj*d[0]+bj*d[1]),abs(-bj*d[0]+aj*d[1]))
            bad.append((float(req-projection),pair))
    if bad and max(bad)[0]>1e-7:
        pair=max(bad)[1];return ('sat' if(pair,'proxy')in selected else 'proxy'),pair
    i=max(normdef)[1];eff,term=V.effective_boxes(box,ch,LEGACY);l,u=eff[i];mid=(l+u)/2
    if not box[i][0]<mid<box[i][1]:mid=sum(box[i])/2
    return 'angle_cut',(i,str(mid))

def run(prefix_file,node_limit,outfile,resume=None):
    raw=Path(prefix_file).read_bytes();record=json.loads(raw);prefix=record['path']
    assert hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest()==VERIFIER_SHA256
    bounds,deductions=replay_prefix(record);replay=make_exact_collector(prefix,bounds)
    pending=[prefix];leaves=[];frontier=[];errors=[];decisions=[];nodes=0;start=time.monotonic()
    if resume:
        prior=json.loads(Path(resume).read_text());assert prior['id']==record['id'] and prior['prefix_sha256']==hashlib.sha256(raw).hexdigest()
        pending=[f['path'] for f in prior['frontier']];leaves=prior['leaves']
    def save():
        current=frontier+[{'path':p,'reason':'NODE_LIMIT'} for p in pending]
        obj={'schema':VERSION,'id':record['id'],'path':prefix,'status':'OPEN' if current else 'CLOSED',
             'prefix_sha256':hashlib.sha256(raw).hexdigest(),'source_prefix':str(prefix_file),'verified_bound_deductions':deductions,
             'proved_parent_positions':[[str(a),str(b)] for a,b in bounds],'nodes':nodes,'leaves':leaves,'frontier':current,'decisions':decisions,
             'rejected_candidates':errors,'seconds':time.monotonic()-start,'whole_mask_closed':False}
        if not current:union(prefix,leaves)
        target=Path(outfile);temp=target.with_suffix('.tmp');temp.write_text(json.dumps(obj,indent=2)+'\n');temp.replace(target)
        return obj
    while pending and nodes<node_limit:
        path=pending.pop();nodes+=1
        legacy,box,pos,ch,disks=decode(path,prefix,bounds)
        hit,point,data=solve(box,pos,ch,disks)
        if hit is not None:
            leaf=json.loads(json.dumps({'path':path,'legacy_physical_path':legacy,**hit,'context_version':VERSION,'legacy_context_version':LEGACY}))
            try:
                reserve,terminal=replay(leaf);leaf.update(checked_reserve=str(reserve),checked_terminal=terminal);leaves.append(leaf)
                if nodes%20==0:save();print(record['id'],'nodes',nodes,'leaves',len(leaves),'queued',len(pending),'seconds',round(time.monotonic()-start,1),flush=True)
                continue
            except Exception:errors.append({'path':path,'candidate':leaf,'error':traceback.format_exc()})
        if point is None or B._last is None:
            frontier.append({'path':path,'reason':'NO_LP_POINT'});continue
        query=select(box,ch,disks,B._last);decisions.append({'path':path,'query':query})
        for step in reversed(children(query)):
            child=path+[step];decode(child,prefix,bounds);pending.append(child)
        if nodes%20==0:save();print(record['id'],'nodes',nodes,'leaves',len(leaves),'queued',len(pending),'seconds',round(time.monotonic()-start,1),flush=True)
    obj=save();print('DONE',record['id'],obj['status'],'nodes',nodes,'leaves',len(leaves),'frontier',len(obj['frontier']),'rejected',len(errors),flush=True)
    return obj

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prefix',default=str(HERE/'bounds/positive-2d5aba857f2f7602.json'));ap.add_argument('--nodes',type=int,default=512);ap.add_argument('--out',default=str(HERE/'positive_shallow_octagon.json'));ap.add_argument('--resume');args=ap.parse_args()
    run(args.prefix,args.nodes,args.out,args.resume)
if __name__=='__main__':main()
