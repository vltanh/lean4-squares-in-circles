#!/usr/bin/env python3
"""Targeted exact clipped-disk row tests, never adding a proof-tree branch."""
import concurrent.futures
import hashlib
import json
import time
from fractions import Fraction as F
from pathlib import Path
import probe_owner_free_support as Q
from owner_free_pair_difference_induction import extra_bounds,rational_weights
import clipped_center_disk_chords as C

HERE=Path(__file__).parent
BASE=HERE.parent
OUT=HERE/'clipped_center_disk_probes'
O,R,N=Q.O,Q.R,Q.N
VERSION='owner_free_inherited_difference_clipped_disk_v1'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(ident,prefix_file,state_file,label=None):
    start=time.monotonic();prefix=json.loads(prefix_file.read_text());state=json.loads(state_file.read_text())
    path=state['path'];positions,count=O.replay_prefix(prefix)
    assert ident==prefix['id']==state['id'] and path[:len(prefix['path'])]==prefix['path']
    legacy,angles,positions,choices,extras=O.decode(path,prefix['path'],positions)
    rows,absolute,terminal=O.collect_rows(O.V,legacy,angles,positions,choices);assert terminal is None
    rows += [O.disk_row(marker,choice)for marker,choice in extras]
    effective,terminal=O.V.effective_boxes(angles,choices,O.LEGACY);assert terminal is None
    propagated,hs,gs,terminal=O.V.center_bounds(effective,positions,choices,O.LEGACY);assert terminal is None
    scalar=R.analytic_frames(effective)
    differences={tuple(r['pair']):tuple(tuple(F(x)for x in t)for t in r['intervals'])for r in state['final_differences']}
    rows += N.relative_support_rows(propagated,scalar,differences=differences)+N.interval_radius_rows(propagated,effective,differences=differences)+extra_bounds(differences)
    radii={(i,j):N.support_radius_lower(effective[i],effective[j])for i in range(9)for j in range(i+1,9)}
    additional,derivations=C.derive_rows(differences,radii);base_count=len(rows);rows+=additional
    a,b=Q.matrix(rows,len(absolute));phase=Q.phase(a,b)
    report={'schema':VERSION,'id':ident,'label':label or ident,'path':path,
            'scope':'WHOLE_ORIGINAL_PARENT'if path==prefix['path']else'EXISTING_ORIGINAL_A_DESCENDANT',
            'prefix_sha256':sha(prefix_file),'prefix_deductions':count,'difference_state_file':str(state_file),
            'difference_state_sha256':sha(state_file),'owner_free_source_sha256':sha(N.__file__),
            'clipped_disk_source_sha256':sha(C.__file__),'new_branch_nodes':0,'whole_mask_closed':False,
            'base_row_count':base_count,'clipped_disk_row_count':len(additional),'clipped_disk_derivations':derivations,
            'solver_status':int(phase.status),'status':'OPEN_SOLVER_FAILURE'}
    if phase.success:
        report.update(status='OPEN_RELAXATION',phase_margin=float(phase.x[-1]))
        if phase.x[-1]>1e-8:
            weights=rational_weights(phase.ineqlin.marginals);co,rhs=O.weighted_sum(rows,absolute,weights);correction=sum(m*abs(c)for m,c in zip(absolute,co));reserve=-rhs-correction
            if reserve>0:
                report.update(status='CANDIDATE_CLOSED',terminal={'kind':'positive_rational_reserve','weights':weights,'reserve':str(reserve),'rows':R.printed_rows(rows,{i for i,w in weights}),'absolute_variable_bounds':list(map(str,absolute)),'weighted_coefficients':list(map(str,co)),'weighted_rhs':str(rhs),'residual_correction':str(correction)},used_clipped_disk_rows=sum(k>=base_count for k,w in weights))
        if report['status']=='OPEN_RELAXATION':report.update(relaxed_variables=list(map(float,phase.x[:-1])),remaining_pair_diagnostics=Q.pair_diagnostics(phase.x[:-1]))
    report['seconds']=time.monotonic()-start
    OUT.mkdir(exist_ok=True);(OUT/(report['label']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(report['label'],report['status'],'chords',len(additional),'margin',report.get('phase_margin'),'seconds',round(report['seconds'],2),flush=True)
    return report


def main():
    a='positive-2d5aba857f2f7602';b='negative-16a2fc93c8d133f0'
    ap=HERE/'bounds'/(a+'.json');bp=BASE/'physical_pilots/combined_bounds/prefixes'/(b+'.json')
    roots=[run(a,ap,HERE/'owner_free_pair_bounds'/(a+'.json')),run(b,bp,HERE/'owner_free_pair_bounds'/(b+'.json'))]
    summary={'whole_parent_results':[{k:r.get(k)for k in ('id','status','clipped_disk_row_count','phase_margin','used_clipped_disk_rows','seconds')}for r in roots],
             'child_results':[],'new_branch_nodes':0,'whole_mask_closed':False}
    if all(r['status']=='OPEN_RELAXATION'for r in roots):
        source=json.loads((HERE/'A_inherited_difference_filter/filter_report.json').read_text())
        targets=[r for r in source['results']if r['status']=='OPEN_RELAXATION'];assert len(targets)==22
        with concurrent.futures.ProcessPoolExecutor(max_workers=2)as pool:
            jobs=[pool.submit(run,a,ap,HERE/'A_inherited_difference_filter'/entry['certificate'],f'A_child_{entry["source_index"]:03d}')for entry in targets]
            for job in concurrent.futures.as_completed(jobs):
                child=job.result();summary['child_results'].append({k:child.get(k)for k in ('label','path','status','clipped_disk_row_count','phase_margin','used_clipped_disk_rows','seconds')})
                (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('DONE roots',[(r['id'],r['status'])for r in roots],'child_candidates',sum(r['status']=='CANDIDATE_CLOSED'for r in summary['child_results']),'children',len(summary['child_results']),flush=True)


if __name__=='__main__':main()
