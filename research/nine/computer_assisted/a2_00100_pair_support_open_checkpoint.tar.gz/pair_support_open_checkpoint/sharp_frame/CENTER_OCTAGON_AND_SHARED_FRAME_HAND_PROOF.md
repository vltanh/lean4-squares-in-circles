# Exact center-octagon covers and shared unit-frame supports

This note proves two relaxations used in discovery for the original nine-square
`001/00` caller. Neither statement by itself closes that mask. All centers and
frame variables below refer to the same original squares throughout a proof
path. The new rows do not permit replacing corners or frames independently.

## 1. Every physical original pair has center distance at least one

A unit square contains the open Euclidean disk of radius `1/2` centered at its
center. If two original centers had distance less than one, those two open
disks would meet, and hence the interiors of their original squares would meet.
Therefore every allowed pair of distinct original squares satisfies

\[
\|c_j-c_i\|^2\geq 1.
\]

This implication permits boundary contact and does not use a strict pair
separation margin.

## 2. An exact eight-case linear cover of center distance at least one

Let `d=(x,y)` and put

\[
a=\frac{12}{13},\qquad b=\frac{17}{13}.
\]

The closed polygon

\[
P=\{(x,y): |x|\leq a,\ |y|\leq a,
                      |x+y|\leq b,\ |x-y|\leq b\}
\]

has precisely the eight vertices

\[
(\pm12/13,\pm5/13),\qquad(\pm5/13,\pm12/13),
\]

with independent signs in each family. Each vertex has squared norm
`(144+25)/169=1`. Convexity of squared norm implies `P` is contained in the
closed unit disk. Strict convexity implies that every nonvertex of `P` has
squared norm less than one: any such point is a nontrivial convex combination
of two or more distinct vertices. Each vertex has an equality in at least one
of the defining inequalities. Consequently the intersection of all eight
*strict* inequalities lies in the open unit disk.

It follows contrapositively that `||d||>=1` is covered by the following eight
closed cases, in the displayed order:

| Case | Necessary alternative |
|---|---|
| 0 | `x >= 12/13` |
| 1 | `-x >= 12/13` |
| 2 | `y >= 12/13` |
| 3 | `-y >= 12/13` |
| 4 | `x+y >= 17/13` |
| 5 | `x-y >= 17/13` |
| 6 | `-x+y >= 17/13` |
| 7 | `-x-y >= 17/13` |

All equality faces are covered. No claim is made that an individual case
implies center distance at least one; this is an outer cover used for
contradiction.

For a rational parameter `t`, define

\[
c=\frac{1-t^2}{1+t^2},\qquad
s=\frac{2t}{1+t^2}.
\]

Direct rational calculation gives `c^2+s^2=1`. Thus the same cover remains
valid after replacing each normal `(p,q)` above by

\[
n=(pc-qs,ps+qc).
\]

For `d=c_j-c_i`, a branch row is exactly

\[
n_x x_i+n_y y_i-n_x x_j-n_y y_j\leq-\tau,
\]

where `tau=12/13` for the first four normals and `tau=17/13` for the last four.
The producer stores the reduced rational parameter as its numerator and
positive denominator. The verifier recomputes both rational rotation entries
and checks their squared-norm identity.

## 3. Ordered closed covers preserve the whole parent

Write the eight branch rows as `r_k(z)<=0`. The ordinary cover has one child
for each such inequality. The ordered version uses, in child `k`,

\[
r_k(z)\leq0,\qquad -r_j(z)\leq0\quad(0\leq j<k).
\]

Given any point in the parent, select the first index `k` for which
`r_k(z)<=0`; the center-distance theorem and Section 2 guarantee that such an
index exists. All earlier `r_j` are positive, so the point belongs to child
`k`. The closed predecessor conditions may duplicate boundary points between
children, which is harmless. They never discard an equality face.

The same argument applies to an independently proved finite escape selector:
one must first prove that at least one of its displayed margin rows is
nonpositive. It does not justify negating a necessary relaxation of a
conjunction. In particular, the two signed physical SAT rows for one owned
separator form a conjunction; their false branch is a disjunction and is not
represented by negating both at once.

## 4. Exact upper supports for the same original unit frames

For each original square `i`, let `(alpha_i,beta_i)` be its common physical
unit frame. Let `absbeta_i=|beta_i|`. Then

\[
\alpha_i^2+\beta_i^2=1,
\qquad \alpha_i^2+\operatorname{absbeta}_i^2=1.
\]

For any exact rational `(p,q)` satisfying `p^2+q^2=1`, Cauchy--Schwarz gives
both necessary inequalities

\[
p\alpha_i+q\beta_i\leq1,
\qquad p\alpha_i+q\operatorname{absbeta}_i\leq1.
\]

These are rows in the original shared variables, without auxiliary copies of
the frame for different corners or pairs. The V4 discovery wrapper uses every
direction in the frozen `V.DENSE_DIRS` list for the signed pair and every entry
with `q>=0` for the folded pair. Every direction is checked exactly for unit
norm. Row order is: all frozen base rows; all V3 path and guarded rows;
originals `0..8`, each with signed directions in list order and then folded
directions in list order; finally the adaptive original-corner rows.

These unit-frame supports are closed inequalities. They must not be marked
strict: an original frame can equal the support normal. They strengthen the
convex upper envelope but do not enforce the nonconvex equality of norm one.
In particular, a surviving relaxed point with frame norm strictly below one
does not describe a physical square packing.

## 5. Exact strict weighted contradictions

Suppose sound rows are `a_r.z <= b_r`, some with a genuine strict inequality,
and the same variables satisfy `|z_k|<=M_k`. For nonnegative rational weights
`lambda_r`, write

\[
A=\sum_r\lambda_r a_r,\quad
B=\sum_r\lambda_r b_r,\quad
E=-B-\sum_k M_k|A_k|.
\]

If `E>0`, the usual exact residual estimate contradicts the rows. If `E=0`
and at least one genuine strict row has a positive weight, the weighted sum
is strict and still contradicts the same residual estimate:

\[
-\sum_k M_k|A_k|\leq A.z < B
 =-\sum_k M_k|A_k|.
\]

This argument uses strictness already present in the original configuration;
it does not introduce a fixed positive slack. In the strict-radius caller
`q<1105/256`, an original corner support against a nonzero exact contact
normal is genuinely strict, as is the original weak `CD` comparison. A
zero-reserve implementation would need to certify the exact row identities,
nonnegative weights, exact residual, and a positive weight on an identified
genuine strict row. The current V1--V4 producers accept only positive-reserve
weighted leaves. The recorded deep A strict-slack diagnostic did not yield a
candidate for this additional terminal.

## Scope of the A diagnostic

The fixed original `positive-2d5aba857f2f7602` remains open in this work. The
V4 probe and frontier filter are discovery records, not a claim of a complete
nine-square feasibility witness or a completed whole-parent proof. The V3
octagon and extraction rows also support a separate completed original D
cell reviewed by the physical-pilots agent; the V4 supports are not needed
for that D certificate.
