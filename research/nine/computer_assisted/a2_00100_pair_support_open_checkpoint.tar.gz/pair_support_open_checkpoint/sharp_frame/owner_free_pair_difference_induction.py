#!/usr/bin/env python3
"""Two bounded, branch-free exact pair-difference rounds on whole A/B.

Every new bound is derived from one unchanged preceding matrix by an exact
nonnegative row sum. No optimum or floating interval is installed as fact.
The frozen owner-free source and initial static probe are not modified.
"""
import hashlib
import json
import time
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
import probe_owner_free_support as Q

O,R,N=Q.O,Q.R,Q.N
HERE=Path(__file__).parent
OUT=HERE/'owner_free_pair_bounds'
SCALE=1<<40
ROUNDING=1<<20


def render(differences):
    return [{'pair':list(pair),'intervals':[[str(a),str(b)]for a,b in dr]}for pair,dr in sorted(differences.items())]


def extra_bounds(differences):
    rows=[]
    for (i,j),dr in sorted(differences.items()):
        for axis,(lo,hi)in enumerate(dr):
            rows.append((((2*j+axis,F(1)),(2*i+axis,F(-1))),hi,f'proved_pair_diff_upper_{i}_{j}_{axis}'))
            rows.append((((2*j+axis,F(-1)),(2*i+axis,F(1))),-lo,f'proved_pair_diff_lower_{i}_{j}_{axis}'))
    return rows


def rational_weights(marginals):
    return [[i,int(round(-v*SCALE))]for i,v in enumerate(marginals)if int(round(-v*SCALE))>0]


def ceil_bound(value):
    scaled=value*ROUNDING
    return F(-((-scaled.numerator)//scaled.denominator),ROUNDING)


def run(ident,prefix_file,maximum_rounds=2):
    start=time.monotonic();prefix=json.loads(prefix_file.read_text());positions,count=O.replay_prefix(prefix)
    path=prefix['path'];legacy,angles,positions,choices,extras=O.decode(path,path,positions)
    base,absolute,terminal=O.collect_rows(O.V,legacy,angles,positions,choices);assert terminal is None
    base += [O.disk_row(marker,choice)for marker,choice in extras]
    effective,terminal=O.V.effective_boxes(angles,choices,O.LEGACY);assert terminal is None
    propagated,hs,gs,terminal=O.V.center_bounds(effective,positions,choices,O.LEGACY);assert terminal is None
    scalar=R.analytic_frames(effective)
    differences={(i,j):tuple(O.V.difference_bounds((i,j),propagated,gs,O.LEGACY))for i in range(9)for j in range(i+1,9)}
    record={'schema':'owner_free_pair_difference_induction_v1','id':ident,'path':path,'status':'OPEN','maximum_rounds':maximum_rounds,
            'prefix_sha256':hashlib.sha256(prefix_file.read_bytes()).hexdigest(),'prefix_deductions':count,
            'owner_free_source_sha256':hashlib.sha256(Path(N.__file__).read_bytes()).hexdigest(),
            'new_branch_nodes':0,'whole_mask_closed':False,'initial_differences':render(differences),'rounds':[]}
    for ri in range(maximum_rounds+1):
        rows=base+N.relative_support_rows(propagated,scalar,differences=differences)+N.interval_radius_rows(propagated,effective,differences=differences)+extra_bounds(differences)
        a,b=Q.matrix(rows,len(absolute));phase=Q.phase(a,b)
        state={'round':ri,'differences_before':render(differences),'row_count':len(rows),'phase_status':int(phase.status)}
        if not phase.success:
            record.update(status='OPEN_SOLVER_FAILURE',terminal_state=state);break
        state['phase_margin']=float(phase.x[-1])
        if phase.x[-1]>1e-8:
            weights=rational_weights(phase.ineqlin.marginals);co,rhs=O.weighted_sum(rows,absolute,weights);reserve=-rhs-sum(m*abs(c)for m,c in zip(absolute,co))
            if reserve>0:
                record.update(status='CANDIDATE_CLOSED',terminal={'state':state,'weights':weights,'reserve':str(reserve),'printed_rows':R.printed_rows(rows,{i for i,w in weights}),'absolute_bounds':list(map(str,absolute)),'residual':list(map(str,co)),'rhs':str(rhs)});break
        if ri==maximum_rounds:
            record.update(relaxed_variables=list(map(float,phase.x[:-1])),remaining_pair_diagnostics=Q.pair_diagnostics(phase.x[:-1]),terminal_state=state);break
        proposals=[];new={pair:[list(p)for p in dr]for pair,dr in differences.items()};used=set()
        for (i,j),dr in sorted(differences.items()):
            for axis in (0,1):
                for sign in (-1,1):
                    objective=np.zeros(len(absolute));objective[2*i+axis]=sign;objective[2*j+axis]=-sign
                    fit=linprog(objective,A_ub=a,b_ub=b,bounds=[(None,None)]*len(absolute),method='highs-ds',options={'presolve':False,'threads':1,'time_limit':5})
                    if not fit.success:continue
                    old=dr[axis][1]if sign==1 else-dr[axis][0]
                    if float(old)+fit.fun<.0005:continue
                    weights=rational_weights(fit.ineqlin.marginals);co,rhs=O.weighted_sum(rows,absolute,weights)
                    co[2*i+axis]+=sign;co[2*j+axis]-=sign
                    correction=sum(m*abs(c)for m,c in zip(absolute,co));proved=rhs+correction;upper=ceil_bound(proved)
                    if old-upper<F(1,2000):continue
                    proposals.append({'pair':[i,j],'axis':axis,'sign':sign,'upper':str(upper),'proved_upper':str(proved),'weights':weights,'residual':[[k,str(c)]for k,c in enumerate(co)if c],'rhs':str(rhs),'residual_correction':str(correction)})
                    if sign==1:new[(i,j)][axis][1]=min(new[(i,j)][axis][1],upper)
                    else:new[(i,j)][axis][0]=max(new[(i,j)][axis][0],-upper)
                    used.update(k for k,w in weights)
        state.update(proposals=proposals,printed_rows=R.printed_rows(rows,used),absolute_variable_bounds=list(map(str,absolute)))
        record['rounds'].append(state);differences={pair:tuple(map(tuple,dr))for pair,dr in new.items()}
        if any(lo>hi for dr in differences.values()for lo,hi in dr):record['status']='CANDIDATE_CLOSED_EMPTY_PAIR_INTERVAL';break
        record.update(final_differences=render(differences),seconds=time.monotonic()-start)
        OUT.mkdir(exist_ok=True);(OUT/(ident+'.json')).write_text(json.dumps(record,indent=2)+'\n')
        print(ident,'round',ri,'exact deductions',len(proposals),'seconds',round(record['seconds'],1),flush=True)
        if not proposals:break
    record.update(final_differences=render(differences),seconds=time.monotonic()-start)
    OUT.mkdir(exist_ok=True);(OUT/(ident+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print('DONE',ident,record['status'],'deductions',sum(len(r['proposals'])for r in record['rounds']),'seconds',round(record['seconds'],1),flush=True)
    return record


def main():
    run('positive-2d5aba857f2f7602',HERE/'bounds/positive-2d5aba857f2f7602.json')
    run('negative-16a2fc93c8d133f0',HERE.parent/'physical_pilots/combined_bounds/prefixes/negative-16a2fc93c8d133f0.json')


if __name__=='__main__':main()
