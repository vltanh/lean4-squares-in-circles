#!/usr/bin/env python3
"""One branch-free pass over exactly the 24 saved surviving original-A paths."""
import concurrent.futures
import hashlib
import importlib.util
import json
import time
from fractions import Fraction as F
from pathlib import Path
import probe_owner_free_support as Q
from owner_free_pair_difference_induction import extra_bounds,rational_weights,render

HERE=Path(__file__).parent
BASE=HERE.parent
OUT=HERE/'A_inherited_difference_filter'
SOURCE=BASE/'root_exploration/A_relative_support_filter/filter_report.json'
PARENT_BOUNDS=HERE/'owner_free_pair_bounds/positive-2d5aba857f2f7602.json'
PREFIX=HERE/'bounds/positive-2d5aba857f2f7602.json'
PROPAGATOR=BASE/'physical_pilots/small_frontier_inspection/ordered_octagon_pair_differences.py'
VERSION='owner_free_inherited_parent_and_octagon_differences_v1'
O,R,N=Q.O,Q.R,Q.N


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_propagator():
    spec=importlib.util.spec_from_file_location('frozen_octagon_difference_propagator',PROPAGATOR)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def run_one(entry,positions,parent_differences,prefix):
    started=time.monotonic();path=entry['path'];source_index=entry['source_index'];D=load_propagator()
    legacy,angles,positions,choices,extras=O.decode(path,prefix,positions)
    rows,absolute,terminal=O.collect_rows(O.V,legacy,angles,positions,choices)
    assert terminal is None
    rows += [O.disk_row(marker,choice)for marker,choice in extras]
    effective,terminal=O.V.effective_boxes(angles,choices,O.LEGACY);assert terminal is None
    propagated,hs,gs,terminal=O.V.center_bounds(effective,positions,choices,O.LEGACY);assert terminal is None
    scalar=R.analytic_frames(effective)
    native={(i,j):tuple(O.V.difference_bounds((i,j),propagated,gs,O.LEGACY))for i in range(9)for j in range(i+1,9)}
    inherited={pair:tuple((max(a,l),min(b,u))for(a,b),(l,u)in zip(dr,parent_differences[pair]))for pair,dr in native.items()}
    differences,derivation=D.derive_pair_differences(path,inherited)
    report={'schema':VERSION,'id':'positive-2d5aba857f2f7602','source_index':source_index,'path':path,
            'source_static_record':entry['certificate'],'parent_pair_bound_sha256':sha(PARENT_BOUNDS),'prefix_sha256':sha(PREFIX),
            'owner_free_source_sha256':sha(N.__file__),'difference_propagator_sha256':sha(PROPAGATOR),
            'native_differences':render(native),'parent_intersected_differences':render(inherited),
            'difference_derivation':derivation,'new_branch_nodes':0,'whole_mask_closed':False}
    if differences is None:
        report.update(status='CANDIDATE_CLOSED',terminal={'kind':'exact_pair_difference_contradiction','detail':derivation['terminal']})
    else:
        rows += N.relative_support_rows(propagated,scalar,differences=differences)+N.interval_radius_rows(propagated,effective,differences=differences)+extra_bounds(differences)
        a,b=Q.matrix(rows,len(absolute));phase=Q.phase(a,b)
        report.update(row_count=len(rows),solver_status=int(phase.status),final_differences=render(differences))
        if not phase.success:report['status']='OPEN_SOLVER_FAILURE'
        else:
            report['phase_margin']=float(phase.x[-1]);report['status']='OPEN_RELAXATION'
            if phase.x[-1]>1e-8:
                weights=rational_weights(phase.ineqlin.marginals);co,rhs=O.weighted_sum(rows,absolute,weights);correction=sum(m*abs(c)for m,c in zip(absolute,co));reserve=-rhs-correction
                if reserve>0:
                    report.update(status='CANDIDATE_CLOSED',terminal={'kind':'positive_rational_reserve','weights':weights,'reserve':str(reserve),'rows':R.printed_rows(rows,{i for i,w in weights}),'absolute_variable_bounds':list(map(str,absolute)),'weighted_coefficients':list(map(str,co)),'weighted_rhs':str(rhs),'residual_correction':str(correction)})
            if report['status']=='OPEN_RELAXATION':
                report['relaxed_variables']=list(map(float,phase.x[:-1]));report['remaining_pair_diagnostics']=Q.pair_diagnostics(phase.x[:-1])
    report['seconds']=time.monotonic()-started
    (OUT/f'child_{source_index:03d}.json').write_text(json.dumps(report,indent=2)+'\n')
    return {'source_index':source_index,'path':path,'status':report['status'],'certificate':f'child_{source_index:03d}.json','terminal':report.get('terminal',{}).get('kind'),'reserve':report.get('terminal',{}).get('reserve'),'seconds':report['seconds']}


def main():
    OUT.mkdir(exist_ok=True);source=json.loads(SOURCE.read_text());parent=json.loads(PARENT_BOUNDS.read_text());prefix_record=json.loads(PREFIX.read_text())
    targets=[r for r in source['results']if r['status']=='OPEN_RELAXATION']
    assert len(source['results'])==48 and len(targets)==24
    assert parent['id']==source['id']==prefix_record['id']=='positive-2d5aba857f2f7602'
    assert parent['path']==source['path']==prefix_record['path']
    assert len(parent['rounds'])==2 and sum(len(r['proposals'])for r in parent['rounds'])==168
    parent_differences={tuple(r['pair']):tuple(tuple(F(x)for x in interval)for interval in r['intervals'])for r in parent['final_differences']}
    positions,deductions=O.replay_prefix(prefix_record);assert deductions==33
    results=[];started=time.monotonic()
    def save():
        closed=sum(r['status']=='CANDIDATE_CLOSED'for r in results)
        report={'schema':VERSION,'id':source['id'],'path':source['path'],'source_static_filter_sha256':sha(SOURCE),
                'parent_pair_bound_sha256':sha(PARENT_BOUNDS),'difference_propagator_sha256':sha(PROPAGATOR),
                'owner_free_source_sha256':sha(N.__file__),'producer_sha256':sha(__file__),
                'original_pending_count':24,'processed':len(results),'candidate_closed':closed,
                'remaining':24-closed,'status':'CANDIDATE_COMPLETE_EXISTING_A_COVER'if closed==24 else'OPEN',
                'results':sorted(results,key=lambda r:r['source_index']),'new_branch_nodes':0,'whole_mask_closed':False,
                'seconds':time.monotonic()-started}
        (OUT/'filter_report.json').write_text(json.dumps(report,indent=2)+'\n')
    with concurrent.futures.ProcessPoolExecutor(max_workers=2)as pool:
        jobs=[pool.submit(run_one,entry,positions,parent_differences,source['path'])for entry in targets]
        for job in concurrent.futures.as_completed(jobs):
            results.append(job.result());save()
            print('processed',len(results),'candidate closed',sum(r['status']=='CANDIDATE_CLOSED'for r in results),'seconds',round(time.monotonic()-started,1),flush=True)
    old=json.loads((HERE/'positive_shallow_sat_priority.json').read_text());v4=json.loads((HERE/'positive_shallow_unit_frame_filter.json').read_text())
    prior_v4=[r for r in v4['results']if r['status']=='CANDIDATE_CLOSED']
    prior_static=[r for r in source['results']if r['status']=='CANDIDATE_CLOSED']
    assert len(old['leaves'])==629 and len(prior_v4)==163 and len(prior_static)==24
    O.union(source['path'],old['leaves']+prior_v4+prior_static+results)
    save();print('DONE complete original cover preserved; new candidates',sum(r['status']=='CANDIDATE_CLOSED'for r in results),'remaining',sum(r['status']!='CANDIDATE_CLOSED'for r in results),flush=True)


if __name__=='__main__':main()
