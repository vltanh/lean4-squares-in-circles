#!/usr/bin/env python3
"""Exact guarded convex-hull rows for a pair outside an inscribed disk.

No optimizer or discovery imports. Every emitted row carries exact vertex
and guard checks. Input center-difference intervals and radii must be proved.
"""
from fractions import Fraction as F
from itertools import product
from math import isqrt

VERSION='exact_clipped_center_disk_chords_v1'


def lower_root(value):
    value=F(value);assert value>=0
    n=isqrt((value.numerator<<96)//value.denominator)
    result=F(n,1<<48)
    assert result*result<=value<(result+F(1,1<<48))**2
    return result


def derive_rows(differences,radii):
    """Return (exact necessary rows, exact geometric derivations).

    differences[(i,j)] encloses center_j-center_i in both coordinates.
    radii[(i,j)] is a positive proved lower bound on its Euclidean norm.
    """
    expected={(i,j)for i in range(9)for j in range(i+1,9)}
    assert set(differences)==set(radii)==expected
    rows=[];proofs=[]
    for i,j in sorted(expected):
        dr=tuple(tuple(map(F,t))for t in differences[(i,j)])
        radius=F(radii[(i,j)]);assert radius>0 and all(lo<=hi for lo,hi in dr)
        for sx,sy in product((-1,1),repeat=2):
            a=dr[0][1]if sx==1 else-dr[0][0]
            b=dr[1][1]if sy==1 else-dr[1][0]
            square=radius*radius
            if a*a+b*b>=square:continue
            p=lower_root(square-a*a);q=lower_root(square-b*b)
            first=b+p;second=a+q
            if first<=0 or second<=0:continue
            rhs=a*b-p*q
            vertices=((a,b),(-q,b),(a,-p))
            norms=[x*x+y*y for x,y in vertices]
            assert norms[0]<square and all(n<=square for n in norms)
            assert first*(-q)+second*b==rhs and first*a+second*(-p)==rhs
            assert first*a+second*b-rhs==first*second>0
            entries=((2*j,first*sx),(2*i,-first*sx),(2*j+1,second*sy),(2*i+1,-second*sy))
            rows.append((tuple(sorted((k,v)for k,v in entries if v)),rhs,f'clipped_center_disk_{i}_{j}_{sx}_{sy}'))
            proofs.append({'pair':[i,j],'signs':[sx,sy],'radius':str(radius),'signed_upper_corner':[str(a),str(b)],
                           'p':str(p),'q':str(q),'positive_coefficients':[str(first),str(second)],'rhs':str(rhs),
                           'vertices':[[str(x),str(y)]for x,y in vertices],'vertex_squared_norms':list(map(str,norms)),
                           'corner_reserve':str(square-norms[0]),'corner_line_gap':str(first*second)})
    return rows,proofs
