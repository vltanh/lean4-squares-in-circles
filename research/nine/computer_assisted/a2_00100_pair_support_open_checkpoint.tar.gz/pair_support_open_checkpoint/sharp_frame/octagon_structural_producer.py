#!/usr/bin/env python3
"""Ordered octagons plus the accepted unique-penultimate-original theorem.

The v1 producer/source and path semantics stay unchanged. This process adds
explicit new path kinds, each with a complete guarded child union.
"""
import argparse,hashlib,itertools,json,math
from fractions import Fraction as F
from pathlib import Path
import octagon_producer as O

HERE=Path(__file__).parent
VERSION='disk_octagon_structural_v2'
THEOREM=HERE.parent/'global_masks/WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md'
CHAINS=tuple((*p,3) for p in itertools.permutations((0,1,2,7,8),3) if p[2]!=2)
assert len(CHAINS)==48
BASE_DISK_ROW=O.disk_row
BASE_SELECT=O.select
BASE_CHILDREN=O.children

def chain_rows(chain,reduced):
    assert len(chain)==4 and chain[3]==3 and len(set(chain))==4 and chain[2]!=2
    assert all(i in (0,1,2,7,8) for i in chain[:3])
    rows=[]
    for i,j in zip(chain,chain[1:]):
        if reduced and 0<=i<j<=2:continue
        for sg in (-1,1):
            rows.append((((2*j,F(1)),(2*i,F(-1)),(2*j+1,F(sg)),(2*i+1,F(-sg))),F(0),'first_two_cone_escape'))
    for i,j in zip(chain[:2],chain[1:3]):
        if reduced and 0<=i<j<=2:continue
        rows.append((((2*j,F(1)),(2*i,F(-1)),(18+i,-F(1,2)),(36+i,-F(1,2)),
                      (18+j,-F(1,2)),(36+j,-F(1,2))),F(0),'first_two_actual_escape'))
    assert len(rows) in ((5,8) if reduced else (8,))
    return rows

def row(marker,choice):
    flipped=choice<0;k=-choice-1 if flipped else choice
    if type(marker[0])is str:
        kind=marker[0];assert kind in ('first_two_escape','first_two_reduced_escape')
        rows=chain_rows(marker[1:],kind=='first_two_reduced_escape');assert 0<=k<len(rows)
        coefficients,rhs,name=rows[k]
    else:coefficients,rhs,name=BASE_DISK_ROW(marker,k)
    if flipped:return tuple((i,-c) for i,c in coefficients),-rhs,name+'_closed_predecessor_complement'
    return coefficients,rhs,name

def decode(path,prefix,bounds):
    assert path[:len(prefix)]==prefix
    legacy=[];extra=[];seen=set()
    for step in path:
        kind=step[0]
        if kind not in ('disk8','disk8_ordered','first_two_escape','first_two_reduced_escape'):
            legacy.append(step);continue
        assert len(step)==3 and type(step[1])is list and type(step[2])is list and len(step[2])==1
        marker=tuple(step[1]);choice=step[2][0];assert type(choice)is int
        query=(kind,marker);assert query not in seen;seen.add(query)
        if kind.startswith('first_two'):
            count=len(chain_rows(marker,kind=='first_two_reduced_escape'));encoded=(kind,*marker)
        else:
            assert len(marker)==4;count=8;encoded=marker;BASE_DISK_ROW(marker,choice)
        assert 0<=choice<count
        extra.append((encoded,choice))
        if kind!='disk8':extra.extend((encoded,-previous-1) for previous in range(choice))
    box,pos,ch=O.V.reconstruct(legacy)
    pos=tuple((max(a,l),min(b,u)) for(a,b),(l,u) in zip(pos,bounds));assert all(l<=u for l,u in pos)
    return legacy,box,pos,ch,extra

def children(query):
    kind,key=query
    if kind in ('disk8','disk8_ordered'):count=8
    elif kind.startswith('first_two'):count=len(chain_rows(tuple(key),kind=='first_two_reduced_escape'))
    else:return BASE_CHILDREN(query)
    return [[kind,list(key),[k]] for k in range(count)]

def select(box,ch,extra,z):
    seen={marker for marker,_ in extra};useful=[]
    for chain in CHAINS:
        marker=('first_two_reduced_escape',*chain)
        if marker in seen:continue
        rows=chain_rows(chain,True)
        score=min(sum(float(c)*z[k] for k,c in coefficients)-float(rhs) for coefficients,rhs,_ in rows)
        if score>1e-8:useful.append((score,chain))
    if useful:return 'first_two_reduced_escape',max(useful)[1]
    # The v1 heuristic sees only the actual octagon cuts. Conditional chain
    # markers are also harmless in its seen-set, but never used as pair IDs.
    query=BASE_SELECT(box,ch,extra,z)
    return ('disk8_ordered',query[1]) if query[0]=='disk8' else query

O.VERSION=VERSION;O.disk_row=row;O.decode=decode;O.children=children;O.select=select

def run(prefix_file,node_limit,outfile,resume=None):
    assert THEOREM.exists()
    result=O.run(prefix_file,node_limit,outfile,resume)
    result['unique_penultimate_theorem_sha256']=hashlib.sha256(THEOREM.read_bytes()).hexdigest()
    result['unique_penultimate_theorem_file']=str(THEOREM)
    result['new_semantics']='disk8_ordered and first_two_reduced_escape: primary row then closed complements of earlier retained rows; old disk8 unchanged'
    Path(outfile).write_text(json.dumps(result,indent=2)+'\n');return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prefix',default=str(HERE/'bounds/positive-2d5aba857f2f7602.json'));ap.add_argument('--nodes',type=int,default=1024);ap.add_argument('--out',default=str(HERE/'positive_shallow_structural_octagon.json'));ap.add_argument('--resume');args=ap.parse_args()
    run(args.prefix,args.nodes,args.out,args.resume)
if __name__=='__main__':main()
