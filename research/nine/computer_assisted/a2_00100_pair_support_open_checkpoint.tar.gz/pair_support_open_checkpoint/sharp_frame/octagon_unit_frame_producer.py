#!/usr/bin/env python3
"""V4 adds deterministic exact signed and folded original-unit-frame supports."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import octagon_guarded_producer as P
O=P.O
HERE=Path(__file__).parent
VERSION='disk_octagon_unit_frames_v4'
PREVIOUS_DECODE=O.decode
PREVIOUS_ROW=O.disk_row

def decode(path,prefix,bounds):
    legacy,box,pos,ch,extra=PREVIOUS_DECODE(path,prefix,bounds)
    for original in range(9):
        for direction in range(len(O.V.DENSE_DIRS)):extra.append((('unit_frame',original,direction,0),0))
        for direction,(p,q) in enumerate(O.V.DENSE_DIRS):
            if q>=0:extra.append((('unit_frame',original,direction,1),0))
    return legacy,box,pos,ch,extra

def row(marker,choice):
    if marker[0]=='unit_frame':
        assert len(marker)==4 and choice==0
        _,original,direction,folded=marker
        assert type(original)is int and 0<=original<9 and type(direction)is int and 0<=direction<len(O.V.DENSE_DIRS)
        assert folded in (0,1)
        p,q=O.V.DENSE_DIRS[direction];assert p*p+q*q==1
        if folded:assert q>=0
        return ((18+original,p),((36 if folded else 27)+original,q)),F(1),'exact_folded_unit_frame' if folded else 'exact_signed_unit_frame'
    return PREVIOUS_ROW(marker,choice)

O.VERSION=VERSION;O.decode=decode;O.disk_row=row

def run(prefix_file,node_limit,outfile,resume=None):
    result=O.run(prefix_file,node_limit,outfile,resume)
    result['unique_penultimate_theorem_sha256']=hashlib.sha256(P.S.THEOREM.read_bytes()).hexdigest()
    result['unit_frame_row_order']='After all V3 path/guard rows, for each original0..8: signed V.DENSE_DIRS in order, then folded V.DENSE_DIRS with q>=0 in order; adaptive corner rows last.'
    result['signed_unit_frame_rows']=9*len(O.V.DENSE_DIRS)
    result['folded_unit_frame_rows']=9*sum(q>=0 for p,q in O.V.DENSE_DIRS)
    Path(outfile).write_text(json.dumps(result,indent=2)+'\n');return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prefix',default=str(HERE/'bounds/positive-2d5aba857f2f7602.json'));ap.add_argument('--nodes',type=int,default=256);ap.add_argument('--out',default=str(HERE/'positive_shallow_unit_frames.json'));ap.add_argument('--resume');args=ap.parse_args()
    run(args.prefix,args.nodes,args.out,args.resume)
if __name__=='__main__':main()
