#!/usr/bin/env python3
"""Second arithmetic implementation for printed pair-difference inductions.

This only checks rational sums and simultaneous bound updates. Physical row
validity, prefix provenance and exact context generation have separate review.
"""
from fractions import Fraction
from pathlib import Path
import argparse,json

F=Fraction

def decode(items):
    answer={}
    for item in items:
        pair=tuple(item['pair']);assert pair not in answer
        answer[pair]=tuple(tuple(F(x) for x in p) for p in item['intervals'])
    assert set(answer)=={(i,j) for i in range(9) for j in range(i+1,9)}
    assert all(a<=b for p in answer.values() for a,b in p)
    return answer

def verify(path):
    record=json.loads(Path(path).read_text());state=decode(record['initial_differences'])
    count=0;printed=0
    for ri,round_ in enumerate(record['rounds']):
        assert round_['round']==ri and decode(round_['differences_before'])==state
        rows={row['index']:row for row in round_['printed_rows']};assert len(rows)==len(round_['printed_rows'])
        bounds=list(map(F,round_['absolute_variable_bounds']));assert all(v>=0 for v in bounds)
        new={pair:[list(p) for p in dr] for pair,dr in state.items()}
        for proposal in round_['proposals']:
            coefficients=[F(0)]*len(bounds);rhs=F(0);seen=set()
            for index,integer in proposal['weights']:
                assert type(index) is int and type(integer) is int and integer>0 and index not in seen
                seen.add(index);row=rows[index];weight=F(integer,2**40)
                for k,value in row['coefficients']:coefficients[k]+=weight*F(value)
                rhs+=weight*F(row['rhs'])
            i,j=proposal['pair'];axis=proposal['axis'];sign=proposal['sign']
            assert 0<=i<j<9 and axis in (0,1) and sign in (-1,1)
            coefficients[2*i+axis]+=sign;coefficients[2*j+axis]-=sign
            residual=[[k,str(v)] for k,v in enumerate(coefficients) if v]
            correction=sum(abs(v)*b for v,b in zip(coefficients,bounds))
            assert residual==proposal['residual'] and rhs==F(proposal['rhs'])
            assert correction==F(proposal['residual_correction'])
            proved=rhs+correction;assert proved==F(proposal['proved_upper'])
            upper=F(proposal['upper']);assert upper>=proved
            old=state[(i,j)][axis][1] if sign==1 else -state[(i,j)][axis][0]
            assert upper<old
            if sign==1:new[(i,j)][axis][1]=min(new[(i,j)][axis][1],upper)
            else:new[(i,j)][axis][0]=max(new[(i,j)][axis][0],-upper)
            count+=1
        state={p:tuple(map(tuple,dr)) for p,dr in new.items()}
        assert all(l<=u for dr in state.values() for l,u in dr)
        printed+=len(rows)
    assert decode(record['final_differences'])==state
    return {'id':record['id'],'status':'PASS_PRINTED_PAIR_DIFFERENCE_ARITHMETIC',
            'rounds':len(record['rounds']),'deductions':count,'printed_rows':printed,
            'whole_parent_closed':False,'whole_mask_closed':False}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('certificates',nargs='+');ap.add_argument('--out',required=True);args=ap.parse_args()
    results=[verify(p) for p in args.certificates]
    report={'status':'PASS','reviews':results,'deductions':sum(r['deductions'] for r in results),
            'scope':'Printed rational sums and acyclic interval updates; separate physical context replay required.',
            'new_original_closures':0}
    Path(args.out).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
