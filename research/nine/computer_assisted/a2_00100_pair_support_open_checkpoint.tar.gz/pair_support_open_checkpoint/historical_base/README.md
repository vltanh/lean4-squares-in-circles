# Optional OPEN A checkpoint with dense shared-frame supports

Original `positive-2d5aba857f2f7602` remains **OPEN**. This is a complete partial
cover for resuming or inspecting discovery; it is not a completed cell proof.
It contains exactly 629 preserved V3 leaf candidates, 163 new V4 leaf
candidates, and 48 open terminal paths. The 211 old frontier paths were each
tested once; no new branches were created by that filtering pass.

## Precise review status

- The producer replayed all 163 new candidates using exact rational sums.
- An independently written checker replayed 65 of those candidates and all
  33 inherited coordinate deductions. Source index94 is the first sampled
  certificate with a nonzero weight on a newly added unit-frame support.
- The other 98 new V4 candidates have not been independently replayed.
- The 629 preserved V3 candidates retain their producer checks. This package
  does not assert that the entire set of 629 received independent replay.
- The complete union of all 840 terminal paths is preserved, including all
  48 still-open paths. No original A closure or whole-mask closure is claimed.

The original filter report predates the expanded independent sample and is
preserved byte for byte. The sample report, manifest, and
`SHARP_FRAME_FINAL_CHECKPOINT.json` record the later 65-leaf review accurately.

## Portable audit

Python 3.12 or later and its standard library suffice:

```bash
python /path/to/a2_00100_A_open_checkpoint_v4/audit.py --manifest-only
python /path/to/a2_00100_A_open_checkpoint_v4/audit.py
python /path/to/a2_00100_A_open_checkpoint_v4/audit.py --sample
```

The default checks the original identity, every frontier mapping, and the
complete partial cover. `--sample` additionally replays the existing 65-leaf
sample and its exact prefix. `--all-leaves` optionally replays all 629 V3 and
163 V4 candidates; even a successful replay still leaves the same 48 open
paths. `--out /tmp/A_review.json` writes outside the frozen package.

The V4 source adds 1,737 exact rational unit-frame rows: for each original,
128 signed `(alpha,beta)` supports and 65 folded `(alpha,abs(beta))` supports.
These are valid closed upper supports, not unit-norm equalities. The remaining
relaxed points can have nonunit frames and overlapping physical squares;
they are not physical packing witnesses.

## Contents

`sharp_frame/positive_shallow_sat_priority.json` contains the 629 preserved
V3 candidates and the 211 original frontier paths.
`sharp_frame/positive_shallow_unit_frame_filter.json` contains all 211 filter
results, including all 163 V4 candidates and all 48 open paths.
`sharp_frame/bounds/` contains the exact coordinate prefix.
`physical_pilots/combined_bounds/unit_frame_v4_support_using_sample.json`
contains the 65 independent sample reviews. All four producer versions and
the independent V3/V4 checkers are included, together with their immutable
physical verifier dependencies and the relevant hand theorems.

The obsolete radial forest and superseded search snapshots are deliberately
absent. No new search or mathematical replay was performed while packaging.
