#!/usr/bin/env python3
"""Portable audit of an OPEN original A checkpoint; never asserts closure."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
DATA=HERE/'sharp_frame'
COMBINED=HERE/'physical_pilots/combined_bounds'

def verify_manifest():
    record=json.loads((HERE/'manifest.json').read_text())
    for name,expected in record['files'].items():
        path=HERE/name
        assert path.is_file(),name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,name
    return record

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest-only',action='store_true');ap.add_argument('--sample',action='store_true');ap.add_argument('--all-leaves',action='store_true');ap.add_argument('--out',type=Path)
    args=ap.parse_args();manifest=verify_manifest()
    if args.manifest_only:
        print(json.dumps({'status':'PASS_MANIFEST_ONLY','files':len(manifest['files']),'original_status':'OPEN','remaining_frontier':48},indent=2));return
    sys.path.insert(0,str(COMBINED))
    import review_octagon as O
    import review_unit_frame_v4 as U
    source=json.loads((DATA/'positive_shallow_sat_priority.json').read_text())
    filtered=json.loads((DATA/'positive_shallow_unit_frame_filter.json').read_text())
    assert hashlib.sha256((DATA/'positive_shallow_sat_priority.json').read_bytes()).hexdigest()==filtered['source_sha256']
    assert source['id']==filtered['id']=='positive-2d5aba857f2f7602' and source['path']==filtered['path']
    assert len(source['leaves'])==629 and len(source['frontier'])==len(filtered['results'])==211
    assert {r['index']for r in filtered['results']}==set(range(211))
    assert all(r['path']==source['frontier'][r['index']]['path']for r in filtered['results'])
    candidates=[r for r in filtered['results']if r['status']=='CANDIDATE_CLOSED'];open_nodes=[r for r in filtered['results']if r['status']=='OPEN']
    assert len(candidates)==163 and len(open_nodes)==48
    registry=json.loads((COMBINED/'whole_cell_payload/fixed_231_register.json').read_text())
    original=next(r for r in registry['cells']if r['id']==source['id']);assert original['path']==source['path'] and original['status']=='OPEN'
    O.verify_complete_union(source['path'],source['leaves']+filtered['results'])
    checked_v3=0;checked_v4=[];bound_count=None
    if args.sample or args.all_leaves:
        raw=(DATA/'bounds/positive-2d5aba857f2f7602.json').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==filtered['prefix_sha256']==source['prefix_sha256']
        positions,bound_count,_=O.verify_bound_prefix(json.loads(raw),original);assert bound_count==33
        if args.all_leaves:
            for leaf in source['leaves']:O.verify_leaf(leaf,original['path'],positions,False);checked_v3+=1
            requested=candidates
        else:
            stored=json.loads((COMBINED/'unit_frame_v4_support_using_sample.json').read_text())
            assert stored['source_sha256']==hashlib.sha256((DATA/'positive_shallow_unit_frame_filter.json').read_bytes()).hexdigest()
            indices={r['source_index']for r in stored['checked']};assert len(indices)==65
            requested=[r for r in candidates if r['index']in indices];assert len(requested)==65
        for item in requested:checked_v4.append({'source_index':item['index'],**U.verify_leaf(item['leaf'],original['path'],positions)})
    result={'id':source['id'],'status':'PASS_OPEN_PARTIAL_COVER','whole_parent_closed':False,'whole_mask_closed':False,
            'preserved_v3_leaves':629,'new_v4_candidate_leaves':163,'remaining_frontier':48,'complete_cover':True,
            'stored_independently_checked_v4_candidates':65,'fresh_v3_leaves_checked':checked_v3,
            'fresh_v4_leaves_checked':len(checked_v4),'fresh_bound_deductions':bound_count,'checked_v4':checked_v4,
            'manifest_files_checked':len(manifest['files'])}
    if args.out:
        target=args.out.resolve();assert not target.is_relative_to(HERE),'Keep the frozen bundle immutable.'
        target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='checked_v4'},indent=2))
if __name__=='__main__':main()
