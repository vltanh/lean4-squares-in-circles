#!/usr/bin/env python3
"""One zero-branch application of the new pair invariant to the saved A cover."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import concurrent.futures
import hashlib
import json
from pathlib import Path
import sys
import time
import warnings

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
SOURCE=BASE/'sharp_frame/positive_shallow_unit_frame_filter.json'
OUTPUT=ROOT/'A_relative_support_filter'
OUTPUT.mkdir(exist_ok=True)

def worker(index,path):
    warnings.filterwarnings('ignore')
    sys.path.insert(0,str(BASE/'sharp_frame'))
    import probe_owner_free_support as P
    P.OUT=OUTPUT
    result=P.run('positive-2d5aba857f2f7602',BASE/'sharp_frame/bounds/positive-2d5aba857f2f7602.json',path,f'A_old_frontier_{index:03}')
    return {'source_index':index,'path':path,'status':result['status'],
            'certificate':f'A_old_frontier_{index:03}.json',
            'reserve':result.get('exact_reserve'),'seconds':result['seconds']}

def main():
    source=json.loads(SOURCE.read_text());pending=[r for r in source['results'] if r['status']=='OPEN']
    assert len(pending)==48
    results=[];started=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(worker,r['index'],r['path']) for r in pending]
        for f in concurrent.futures.as_completed(futures):
            results.append(f.result())
            report={'id':source['id'],'path':source['path'],'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                    'original_pending_count':48,'results':sorted(results,key=lambda r:r['source_index']),
                    'new_branch_nodes':0,'candidate_closed':sum(r['status']=='CANDIDATE_CLOSED' for r in results),
                    'processed':len(results),'status':'OPEN_PENDING_INDEPENDENT_REVIEW','whole_mask_closed':False,
                    'seconds':time.monotonic()-started}
            (OUTPUT/'filter_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print('COMPLETE_ZERO_BRANCH_PASS',len(results),'closed_candidates',report['candidate_closed'],flush=True)

if __name__=='__main__':main()
