#!/usr/bin/env python3
"""One static relative-support check on remaining whole original predicates."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import concurrent.futures,hashlib,json,sys,time,traceback,warnings
from pathlib import Path

HERE=Path(__file__).resolve().parent;BASE=HERE.parent
OUT=HERE/'remaining_original_support';OUT.mkdir(exist_ok=True)
REG=BASE/'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
EXCLUDE={'positive-2d5aba857f2f7602','negative-16a2fc93c8d133f0'}

def worker(cell):
    warnings.filterwarnings('ignore');sys.path.insert(0,str(BASE/'sharp_frame'))
    import probe_owner_free_support as P
    P.OUT=OUT
    prefix=BASE/'physical_pilots/combined_bounds/prefixes'/(cell['id']+'.json')
    if not prefix.exists():
        assert cell['id']=='positive-2c719a20ef7510de'
        prefix=BASE/'global_masks/v3_fresh_2c/positive-2c719a20ef7510de_prefix.json'
    d=json.loads(prefix.read_text());assert d['id']==cell['id'] and d['path']==cell['path']
    try:
        result=P.run(cell['id'],prefix)
        return {k:v for k,v in result.items() if k in ('id','scope','path','status','exact_reserve','new_phase_margin','seconds','prefix_sha256','prefix_deductions')}
    except Exception:
        report={'id':cell['id'],'path':cell['path'],'status':'NO_CONCLUSION','error':traceback.format_exc()}
        (OUT/(cell['id']+'_error.json')).write_text(json.dumps(report,indent=2)+'\n')
        return report

def main():
    reg=json.loads(REG.read_text());cells=[c for c in reg['cells'] if c['status']=='OPEN' and c['id'] not in EXCLUDE]
    assert len(cells)==61
    started=time.monotonic();results=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(worker,c) for c in cells]
        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())
            report={'scope':'ONE_ZERO_BRANCH_CHECK_PER_ORIGINAL_PARENT','register_sha256':hashlib.sha256(REG.read_bytes()).hexdigest(),
                    'targets':len(cells),'processed':len(results),'new_branch_nodes':0,
                    'candidate_closed':sum(r['status']=='CANDIDATE_CLOSED' for r in results),
                    'results':sorted(results,key=lambda r:r['id']),'whole_mask_closed':False,
                    'seconds':time.monotonic()-started}
            (OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print('COMPLETE_STATIC_PARENT_PASS',report['processed'],'whole_parent_candidates',report['candidate_closed'],flush=True)

if __name__=='__main__':main()
