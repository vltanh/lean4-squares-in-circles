#!/usr/bin/env python3
"""One complete independent replay of the163 retained V4 candidates."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

import review_unit_frame_v4 as W
C=W.previous
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent.parent/'sharp_frame/positive_shallow_unit_frame_filter.json'
PREFIX=HERE.parent.parent/'sharp_frame/bounds/positive-2d5aba857f2f7602.json'


def table_for_leaf(leaf,parent_positions):
    legacy,additions=C.split_decode(leaf['path'])
    angles,positions,choices=C.V.reconstruct(legacy)
    positions=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(positions,parent_positions))
    cuts=leaf.get('circle_cuts',[])
    analytic={k:leaf[k] for k in ('analytic_terminal','row_guard','local_radius') if k in leaf}
    base,bounds,terminal=C.collect_unchanged_rows(json.dumps(legacy),json.dumps([[str(a),str(b)] for a,b in positions]),json.dumps(cuts),json.dumps(analytic))
    table={'path':leaf['path'],'legacy_physical_path':legacy,'terminal':terminal}
    if terminal is not None:return table
    extra=[row for step in additions for row in C.new_rows(step)]
    extra.extend(row for x in C.guarded_originals(leaf['path']) for row in C.abxd_guard_rows(x))
    frames=W.unit_frame_rows();split=len(base)-len(cuts)
    rows=base[:split]+extra+frames+base[split:]
    co,rhs=C.weighted_sum(rows,bounds,leaf['weights'])
    reserve=-rhs-sum(M*abs(v) for M,v in zip(bounds,co));assert reserve>0
    table.update(rows=C.printed_rows(rows,{i for i,w in leaf['weights']}),weights=leaf['weights'],power=40,
                 coefficient_sum=list(map(str,co)),rhs_sum=str(rhs),absolute_variable_bounds=list(map(str,bounds)),
                 positive_reserve=str(reserve),base_row_count=split,v3_added_row_count=len(extra),
                 new_frame_row_count=len(frames),circle_row_count=len(cuts))
    return table


def main():
    raw=SOURCE.read_bytes();source=json.loads(raw);prefix_bytes=PREFIX.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='5790fc8352475fb0020c0296ecb448ed43182962425e8efc9df3d710fa867de3'
    assert hashlib.sha256(prefix_bytes).hexdigest()==source['prefix_sha256']
    register=json.loads((C.HERE/'whole_cell_payload/fixed_231_register.json').read_bytes())
    original=next(r for r in register['cells'] if r['id']==source['id'])
    assert original['path']==source['path']
    bounds,deductions,prefix_tables=C.verify_bound_prefix(json.loads(prefix_bytes),original)
    candidates=[r for r in source['results'] if r.get('status')=='CANDIDATE_CLOSED']
    assert len(candidates)==163
    checked=[];tables=[];least=None
    for candidate in candidates:
        leaf=candidate['leaf'];assert candidate['path']==leaf['path']
        result=W.verify_leaf(leaf,original['path'],bounds)
        result['source_index']=candidate['index'];checked.append(result)
        table=table_for_leaf(leaf,bounds);table['source_index']=candidate['index'];tables.append(table)
        if 'reserve' in result:
            reserve=F(result['reserve']);assert reserve==F(table['positive_reserve'])
            least=reserve if least is None else min(least,reserve)
    report={'status':'PASS_ALL163_V4_PARTIAL_CANDIDATES','id':source['id'],
            'whole_parent_closed':False,'whole_mask_closed':False,'source_sha256':hashlib.sha256(raw).hexdigest(),
            'prefix_sha256':source['prefix_sha256'],'bound_deductions':deductions,'candidates_checked':len(checked),
            'weighted_leaves':sum('reserve' in r for r in checked),
            'leaves_using_new_frame_supports':sum(r.get('used_new_frame_rows',0)>0 for r in checked),
            'least_positive_reserve':str(least),'source_filter_remaining_frontier':source['remaining_open_count'],
            'scope':'All163 candidate leaves only; full A-tree composition and later descendants are checked separately.',
            'checked':checked}
    table_output={'id':source['id'],'prefix_tables':prefix_tables,'leaf_tables':tables}
    (HERE/'v4_all163_independent_review.json').write_text(json.dumps(report,indent=2)+'\n')
    (HERE/'v4_all163_independent_tables.json').write_text(json.dumps(table_output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='checked'},indent=2))


if __name__=='__main__':main()
