#!/usr/bin/env python3
"""No-subdivision diagnostic on the fixed 231 v13 uncovered cells.

Every candidate contradiction is separately replayed with rational arithmetic.
An accepted cell remains conditional on the physical validity of the original
forest's hand-theorem dependencies. No whole-mask closure is inferred.
"""
import hashlib,json,time,warnings
from pathlib import Path
import sparse_bulk_v14 as S
import weak_outer_numeric_strict_bulk_v14_verify as V
warnings.filterwarnings('ignore')
start=time.time();report=[];closed=[]
for sign in ('positive','negative'):
    data=json.loads(Path(sign+'_forest.json').read_text())
    for index,item in enumerate(data['frontier']):
        ident=sign+'-'+hashlib.sha256(json.dumps(item['path'],separators=(',',':')).encode()).hexdigest()[:16]
        box,pos,choices=V.reconstruct(item['path'])
        floating=lambda z:tuple(tuple(float(v) for v in interval) for interval in z)
        candidate,point,model=S.solve(floating(box),floating(pos),choices)
        row={'id':ident,'sign':sign,'index':index,'path':item['path'],'status':'OPEN'}
        if candidate is not None:
            leaf=dict(item);leaf.update(candidate)
            # The replay format is JSON: tuples from the discovery API must
            # be serialized before the strict parser inspects list fields.
            leaf=json.loads(json.dumps(leaf))
            try:
                reserve,terminal=V.replay_leaf(leaf)
                row.update(status='CLOSED_BY_EXACT_MODEL',reserve=str(reserve),terminal=terminal)
                closed.append({'id':ident,'leaf':leaf,'reserve':str(reserve),'terminal':terminal})
            except Exception as exc:
                row.update(status='REPLAY_REJECTED',error=repr(exc))
        elif point is not None:
            row['relaxed_centers']=[float(v) for v in point]
        report.append(row)
        if len(report)%10==0:print(len(report),'cells,',len(closed),'closed, seconds',round(time.time()-start,1),flush=True)
        Path('frontier_whole_cell_report.json').write_text(json.dumps({'model_coverage_only':True,'whole_mask_closed':False,'cells_checked':len(report),'closed':len(closed),'remaining':231-len(closed),'seconds':time.time()-start,'results':report},indent=2)+'\n')
        Path('frontier_whole_cell_closed.json').write_text(json.dumps(closed,indent=2)+'\n')
print('DONE',len(report),len(closed),time.time()-start,flush=True)
