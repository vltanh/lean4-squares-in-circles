#!/usr/bin/env python3
"""Freeze a self-contained, identity-bound finite original-cell proof package."""
import hashlib,json,shutil
from pathlib import Path
import weak_outer_numeric_strict_bulk_v14_verify as V
from frontier_bounded_cells import verify_cell_union

HERE=Path(__file__).resolve().parent
def load(name):return json.loads((HERE/name).read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def cell_id(sign,path):return sign+'-'+hashlib.sha256(json.dumps(path,separators=(',',':')).encode()).hexdigest()[:16]

def main():
    dest=HERE/'whole_cell_payload';dest.mkdir(exist_ok=True)
    direct=load('frontier_whole_cell_closed.json');bounded=load('frontier_bounded_cell_closed.json');focused=load('frontier_focused_cell_closed.json')
    proofs={}
    for kind,records in [('direct',direct),('bounded',bounded),('focused',focused)]:
        for row in records:
            assert row['id'] not in proofs
            leaves=[row['leaf']] if kind=='direct' else row['leaves']
            proofs[row['id']]={'id':row['id'],'method':kind,'leaves':leaves}
    register=[];partitions=[];leaves_count=0
    for sign in ('positive','negative'):
        original=load(sign+'_forest.json');result=json.loads(json.dumps(original));result['schema']='strict-bulk-2026-11-03-v14'
        result['frontier']=[];result['scope']='Immutable original-nine 001/00 large-gap sign root, with complete fixed-cell substitutions. Nonempty frontier remains unproved.'
        shutil.copyfile(HERE/(sign+'_forest.json'),dest/(sign+'_forest.json'))
        for index,cell in enumerate(original['frontier']):
            ident=cell_id(sign,cell['path'])
            entry={'id':ident,'sign':sign,'baseline_frontier_index':index,'path':cell['path'],
                   'status':'CLOSED' if ident in proofs else 'OPEN'}
            if ident in proofs:
                proof=proofs[ident];verify_cell_union(cell['path'],proof['leaves'])
                for leaf in proof['leaves']:V.replay_leaf(leaf)
                result['leaves'].extend(proof['leaves']);leaves_count+=len(proof['leaves'])
                entry.update(method=proof['method'],terminal_leaves=len(proof['leaves']))
            else:result['frontier'].append(cell)
            register.append(entry)
        part=V.verify_partition(result,result['root_side']);partitions.append({'sign':sign,**part})
        result['nodes']=part['nodes'];result['max_depth']=max(len(x['path']) for x in result['leaves']+result['frontier'])
        result['actions']={}
        result.pop('seconds',None);result.pop('minimum_discovery_reserve',None)
        # Preserve compact JSON for large repeated split paths.
        (dest/('final_'+sign+'.json')).write_text(json.dumps(result,separators=(',',':'))+'\n')
    assert len(register)==231 and len({r['id'] for r in register})==231
    assert set(proofs)=={r['id'] for r in register if r['status']=='CLOSED'}
    write(dest/'fixed_231_register.json',{'scope':'Coverage-qualified fixed original full-nine large-gap cells; all 231 IDs and paths immutable.',
          'whole_mask_closed':False,'original_cells':231,'closed_cells':len(proofs),'open_cells':231-len(proofs),'cells':register})
    write(dest/'new_cell_proofs.json',{'scope':'Each item replaces one entire original frontier cell. Every child is exact-replayed.',
          'closed_original_cells':len(proofs),'new_terminal_leaves':leaves_count,'proofs':[proofs[k] for k in sorted(proofs)]})
    write(dest/'assembly_report.json',{'status':'PASS','whole_mask_closed':False,'original_cells':231,
          'closed_cells':len(proofs),'open_cells':231-len(proofs),'new_exact_terminal_leaves':leaves_count,
          'methods':{'direct':len(direct),'bounded':len(bounded),'focused':len(focused)},'partitions':partitions})
    modules=[f'weak_outer_numeric_strict_bulk_v{v}_verify.py' for v in range(9,15)]
    modules+=['weak_outer_deep_boundary_verify.py','weak_outer_deep_boundary_angle_certificate.json',
      'weak_outer_numeric_positive_deep_cylinder_arithmetic.py','weak_outer_all_sign_small_row_arithmetic.py',
      'weak_outer_correlated_corner_row_arithmetic.py','weak_outer_hand_G_order_search.py',
      'weak_outer_numeric_strict_bulk_v14_driver.py','weak_outer_numeric_strict_bulk_v14_lp.py',
      'weak_outer_numeric_strict_bulk_v14_branch.py','weak_outer_numeric_strict_bulk_v14_prune.py','sparse_bulk_v14.py',
      'frontier_whole_cell_pass.py','frontier_bounded_cells.py','frontier_focused_cells.py','export_cell_tables.py',
      'check_cell_tables.py','verify_payload.py','check_payload_controls.py','whole_cell_rational_tables.json',
      'whole_cell_rational_tables_replay.json','assemble_payload.py',
      'frontier_whole_cell_report.json','frontier_whole_cell_closed.json','frontier_bounded_cell_closed.json',
      'frontier_focused_cell_closed.json','frontier_focused_cell_report.json','frontier_focused_selected.json']
    for name in modules:shutil.copyfile(HERE/name,dest/name)
    # The trial summary deliberately reports counts rather than resumed timers.
    trials=load('frontier_bounded_cell_report.json')['results'];assert len({r['id'] for r in trials})==len(trials)
    write(dest/'bounded_trial_summary.json',{'scope':'Discovery accounting; only complete cell proofs enter new_cell_proofs.json.',
      'cells_attempted':len(trials),'entire_cells_closed':len(bounded),'timed_out_cells':sum(r.get('timed_out',False) for r in trials),
      'trial_limits':'At most 24 nodes and 4 added path levels; resumed trials use a 12-second wall deadline. Initial completed trials had a 20-second nominal deadline.',
      'trials':[{k:v for k,v in r.items() if k not in ('leaves','path','seconds')} for r in trials]})
    write(dest/'focused_trial_summary.json',{'scope':'One larger bounded trial on six named original cells. Unfinished trials remain open.',
      'limits':load('frontier_focused_selected.json'),'results':[{k:v for k,v in r.items() if k not in ('leaves','path','seconds')} for r in load('frontier_focused_cell_report.json')['results']]})
    print(json.dumps(load('whole_cell_payload/assembly_report.json'),indent=2))

if __name__=='__main__':main()
