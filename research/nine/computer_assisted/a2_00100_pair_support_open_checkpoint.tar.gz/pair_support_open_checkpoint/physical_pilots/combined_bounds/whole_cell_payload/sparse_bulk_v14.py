"""Discovery accelerator. All terminal multipliers retain full v14 row indices.
Dropped LP rows are a relaxation; a returned contradiction is checked by the
unchanged exact v14 verifier. No discovery result alone constitutes a proof.
"""
import numpy as np
from math import sqrt
import weak_outer_numeric_strict_bulk_v14_lp as M
import weak_outer_numeric_strict_bulk_v14_branch as branch

FULL_SOLVE=M.solve

def retain(name):
    if name.startswith('dense_original_corner_'): return False
    if name.startswith('corner_support_'):
        z=name.split('_');p,q=int(z[3]),int(z[4])
        return abs(p)<=1 and abs(q)<=1
    return True

def solve(box,pos,ch):
    if M.LOCAL_ENABLED and all(-M.LOCAL_ETA<=l<=u<=M.LOCAL_ETA for l,u in box) and all(M.LOCAL_CENTERS[k]-M.LOCAL_ETA<=pos[k][0]<=pos[k][1]<=M.LOCAL_CENTERS[k]+M.LOCAL_ETA for k in M.LOCAL_COORDS):
        return {'analytic_terminal':'deep_B_cylinder_1_64_v1','context_version':M.CONTEXT_VERSION,'discovery_reserve':0.0},None,None
    fullA,fullB,fullnames,CB,hs,gs=M.matrix(box,pos,ch)
    if len(fullB)>1:
        for row_kind in M.CORRELATED_KINDS:
            eta,variation=M.correlated_parameters(row_kind,1.)
            if not M.small_row_guard(box,eta):continue
            upper=max(sum(-c*CB[k][1 if c<0 else 0] for k,c in row) for row,_ in M.small_row_specs(variation))
            if upper<variation-1e-10:
                return {'analytic_terminal':'all_sign_correlated_row_v1','row_guard':row_kind,'context_version':M.CONTEXT_VERSION,'discovery_reserve':0.0},None,None
    if M.small_row_guard(box,1/50) and len(fullB)>1:
        upper=max(sum(-c*CB[k][1 if c<0 else 0] for k,c in row) for row,_ in M.small_row_specs(1/12))
        if upper<1/12-1e-10:
            return {'analytic_terminal':'all_sign_seven_frame_row_1_12_v1','context_version':M.CONTEXT_VERSION,'discovery_reserve':0.0},None,None
    large=box[3][0]>=0 or any(pair==(2,3) and kind=='sat' and val[1]==0 for pair,kind,val in ch)
    radius=1/32 if large else 1/64
    if (len(fullB)>1 and all(-radius<=l<=u<=radius for l,u in box)
      and all((M.LOCAL_CENTERS[k]-radius<=pos[k][0]<=pos[k][1]<=M.LOCAL_CENTERS[k]+radius)
          or(M.LOCAL_CENTERS[k]-radius+1e-10<=CB[k][0]<=CB[k][1]<=M.LOCAL_CENTERS[k]+radius-1e-10)
          for k in M.LOCAL_COORDS)):
        return {'analytic_terminal':'deep_B_propagated_cylinder_v6','local_radius':'1/32' if large else '1/64','context_version':M.CONTEXT_VERSION,'discovery_reserve':0.0},None,None
    indices=[i for i,n in enumerate(fullnames) if retain(n)]
    A=fullA[indices];B=fullB[indices];names=[fullnames[i] for i in indices];N=A.shape[1]
    cuts=[];seen=set();initial_full_count=len(fullB)
    for it in range(13):
        r=M.linprog(np.r_[np.zeros(N),1.],A_ub=np.c_[A,-np.ones(len(B))],b_ub=B,bounds=[(None,None)]*(N+1),method='highs',options={'presolve':True,'threads':1,'time_limit':2.0})
        if not r.success:return None,None,(A,B,names,CB,hs,gs)
        if r.x[-1]>1e-7:
            lam=-r.ineqlin.marginals;weights=[];ll=np.zeros(len(B))
            for i,v in enumerate(lam):
                w=int(round(v*2**40))
                if w>0:weights.append((indices[i],w));ll[i]=w/2**40
            bounds=np.r_[np.full(18,M.rho),np.ones(36),np.tile([2*M.rho,2*M.rho,1,1,1,1],(N-54)//6)]
            reserve=-ll@B-bounds@abs(ll@A)
            if reserve>1e-8:return {'weights':weights,'power':40,'context_version':M.CONTEXT_VERSION,'circle_cuts':cuts,'discovery_reserve':float(reserve)},r.x[:18],(A,B,names,CB,hs,gs)
        if it==12:break
        candidates=[];power=20;scale=1<<power
        for original in range(9):
            alpha=r.x[M.AL(original)];beta=r.x[M.BE(original)]
            for ss in(-1,1):
                for tt in(-1,1):
                    xx=r.x[2*original]+.5*(ss*alpha-tt*beta);yy=r.x[2*original+1]+.5*(ss*beta+tt*alpha);norm=sqrt(xx*xx+yy*yy)
                    if norm*norm<=M.Q+1e-8:continue
                    pn=int(round(scale*xx/norm));qn=int(round(scale*yy/norm));cut=(original,ss,tt,pn,qn,power)
                    if cut not in seen:candidates.append((norm*norm-M.Q,cut))
        if not candidates:break
        for _,cut in sorted(candidates,reverse=True)[:4]:
            seen.add(cut);cuts.append(cut);original,ss,tt,pn,qn,power=cut;scale=1<<power;p=pn/scale;q=qn/scale;co=np.zeros(N)
            for k,val in((2*original,p),(2*original+1,q),(M.AL(original),(ss*p+tt*q)/2),(M.BE(original),(ss*q-tt*p)/2)):co[k]+=val
            A=np.vstack((A,co));B=np.append(B,sqrt(M.Q*(p*p+q*q))+1e-12);indices.append(initial_full_count+len(cuts)-1);names.append(f'adaptive_original_corner_{len(cuts)-1}_{original}_{ss}_{tt}')
    return None,r.x[:18],(A,B,names,CB,hs,gs)

if __name__=='__main__':
    M.linprog=branch.capture_lp
    M.base.matrix=M.matrix;M.base.solve=solve;M.base.select=branch.select
    M.base.main()
