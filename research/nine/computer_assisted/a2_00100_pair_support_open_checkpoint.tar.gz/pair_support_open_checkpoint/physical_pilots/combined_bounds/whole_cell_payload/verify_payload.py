#!/usr/bin/env python3
"""Portable exact replay of the fixed231 substitution, with optional baseline replay."""
from pathlib import Path
import argparse,hashlib,json
import weak_outer_numeric_strict_bulk_v14_verify as V
from frontier_bounded_cells import verify_cell_union
from check_cell_tables import check as check_tables

HERE=Path(__file__).resolve().parent
def load(name):return json.loads((HERE/name).read_text())
def ident(sign,path):return sign+'-'+hashlib.sha256(json.dumps(path,separators=(',',':')).encode()).hexdigest()[:16]
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'))

def verify(full=False):
    register=load('fixed_231_register.json');entries=register['cells'];proof_data=load('new_cell_proofs.json')
    assert len(entries)==231 and len({r['id'] for r in entries})==231
    proofs={p['id']:p for p in proof_data['proofs']};assert len(proofs)==len(proof_data['proofs'])
    all_expected=set();checked=0;least=None;terminals={};partitions=[];baseline_checked=0
    for sign in ('positive','negative'):
        original=load(sign+'_forest.json');final=load('final_'+sign+'.json');rootside=1 if sign=='positive' else 0
        V.verify_partition(original,rootside)
        expected=json.loads(json.dumps(original));expected['frontier']=[]
        for index,cell in enumerate(original['frontier']):
            key=ident(sign,cell['path']);all_expected.add(key)
            matching=[r for r in entries if r['id']==key];assert len(matching)==1;entry=matching[0]
            assert entry['sign']==sign and entry['baseline_frontier_index']==index and entry['path']==cell['path']
            if key in proofs:
                assert entry['status']=='CLOSED';leaves=proofs[key]['leaves'];assert len(leaves)==entry['terminal_leaves']
                verify_cell_union(cell['path'],leaves)
                for leaf in leaves:
                    reserve,terminal=V.replay_leaf(leaf);checked+=1
                    if terminal:terminals[terminal]=terminals.get(terminal,0)+1
                    else:least=reserve if least is None else min(least,reserve)
                expected['leaves'].extend(leaves)
            else:assert entry['status']=='OPEN';expected['frontier'].append(cell)
        assert canonical(expected['leaves'])==canonical(final['leaves'])
        assert canonical(expected['frontier'])==canonical(final['frontier'])
        assert final['root_side']==rootside
        part=V.verify_partition(final,rootside);partitions.append({'sign':sign,**part})
        if full:
            for leaf in original['leaves']:V.replay_leaf(leaf);baseline_checked+=1
    assert all_expected=={r['id'] for r in entries}
    assert set(proofs)=={r['id'] for r in entries if r['status']=='CLOSED'}
    assert register['closed_cells']==len(proofs) and register['open_cells']==231-len(proofs)
    assert proof_data['new_terminal_leaves']==checked
    tables=load('whole_cell_rational_tables.json');assert tables['closed_original_cells']==len(proofs)
    assert tables['new_terminal_leaves']==checked and len(tables['records'])==checked
    byleaf={(p['id'],i):leaf for p in proofs.values() for i,leaf in enumerate(p['leaves'])}
    assert len(byleaf)==checked
    for record in tables['records']:
        key=(record['cell_id'],record['leaf_index']);assert key in byleaf
        assert record['path']==byleaf[key]['path'];del byleaf[key]
    assert not byleaf
    printed=check_tables(tables)
    return {'status':'PASS','scope':'All new original-cell substitutions independently exact-replayed; immutable baseline leaves retained byte-for-value. Full baseline arithmetic is optional.',
      'whole_mask_closed':False,'original_cells':231,'closed_cells':len(proofs),'open_cells':231-len(proofs),
      'new_exact_terminal_leaves':checked,'baseline_leaves_replayed_this_run':baseline_checked,
      'partitions':partitions,'terminal_counts':terminals,'minimum_new_rational_reserve':str(least),
      'printed_rational_table_check':printed}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');ap.add_argument('--report',type=Path);ap.add_argument('--check-manifest',action='store_true');args=ap.parse_args()
    if args.check_manifest:
        manifest=load('manifest.json')
        for row in manifest['files']:
            path=HERE/row['path'];assert path.is_file()
            assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
    result=verify(args.full)
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
