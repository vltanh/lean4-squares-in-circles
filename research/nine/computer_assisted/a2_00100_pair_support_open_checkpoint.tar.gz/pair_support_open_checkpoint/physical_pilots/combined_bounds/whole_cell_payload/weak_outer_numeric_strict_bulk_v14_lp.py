#!/usr/bin/env python3
"""DISCOVERY ONLY: versioned original STRICT 001/00 bulk caller.

Unlike scalar width boxes, each original cos/sin and abs(sin) is a shared
LP variable in every corner, chain, pair cap and chosen physical separator.
Finite proofs require an independent rational reconstruction and replay.
"""
from math import sqrt
import numpy as np
from scipy.optimize import linprog
import weak_outer_numeric_strict_bulk_v14_driver as base

Q=base.Q;rho=base.rho;a=base.a;b=base.b;N=54
CONTEXT_VERSION='strict_bulk_2026_11_03_v14'
ASYMMETRIC_ENABLED=True  # Complete root/hand/global review of both signed pieces.
base.TARGET_TRANSVERSE='2/3'
LOCAL_ENABLED=True  # Final global/hand/root review and all144 exact identities PASS.
LOCAL_ETA=1/64
LOCAL_CENTERS=(-3/2,-1/16,-1/2,-17/16,1/2,-17/16,3/2,-1/16,-1,15/16,0,15/16,1,15/16,-1/2,-1/16,1/2,-1/16)
LOCAL_COORDS=tuple(k for k in range(18) if k not in (10,11))
base.LOCAL_CENTERS=LOCAL_CENTERS
AL=lambda i:18+i
BE=lambda i:27+i
AB=lambda i:36+i
GI=lambda i:45+i
DENSE_HALF_TANGENTS=(0,1609,3220,4834,6455,8083,9721,11372,13036,14717,
    16416,18136,19880,21650,23449,25280,27146,29050,30996,32988,
    35030,37126,39281,41500,43790,46156,48605,51145,53784,56532,59398,62395)
def dense_directions():
    # Exact Pythagorean unit directions; the checker uses rational arithmetic.
    den=1<<16;ans=[]
    for turn in range(4):
        for num in DENSE_HALF_TANGENTS:
            ss=den*den+num*num;p=(den*den-num*num)/ss;q=2*den*num/ss
            for _ in range(turn):p,q=-q,p
            ans.append((p,q))
    return tuple(ans)
DENSE_DIRS=dense_directions()
CONTACT_DIRS=tuple(sorted({(sx*p,sy*q) for p,q in ((32,9),(9,32),(24,23),(23,24)) for sx in (-1,1) for sy in (-1,1)}))
assert len(CONTACT_DIRS)==16 and all(p*p+q*q==1105 for p,q in CONTACT_DIRS)

from itertools import permutations
GENERAL_SELECTORS=tuple(chain for chain in permutations((0,1,2,3,7,8),4)
                        if tuple(i for i in chain if i<4)==tuple(sorted(i for i in chain if i<4)))
assert len(GENERAL_SELECTORS)==105 and len(set(GENERAL_SELECTORS))==105

def general_alternate_specs(marker,half):
    assert len(marker)==2 and marker[0]==0 and 1<=marker[1]<=105
    chain=GENERAL_SELECTORS[marker[1]-1];rows=[]
    for i,j in zip(chain,chain[1:]):
        for sign in (-1,1):
            rows.append(([(2*j,1),(2*i,-1),(2*j+1,sign),(2*i+1,-sign)],0))
    for i,j in ((chain[0],chain[1]),(chain[2],chain[3])):
        rows.append(([(2*j,1),(2*i,-1),(18+i,-half),(36+i,-half),
                      (18+j,-half),(36+j,-half)],0))
    return rows

def f_side_escape_rows(pair,branch,threshold):
    assert pair in ((5,7),(5,8)) and type(branch) is int and 0<=branch<8
    x=pair[1];side,local=divmod(branch,4)
    left,right=(0,5) if side==0 else (5,3)
    signs=((-1,-1),(-1,1),(1,-1),(1,1))
    def height_row(k):
        s,t=signs[k]
        return [(2*left+1,s),(2*x+1,t-s),(2*right+1,-t)],-threshold
    horizontal=([(2*x,1),(10,-1)],0) if side==0 else ([(10,1),(2*x,-1)],0)
    out=[horizontal,height_row(local)]
    for earlier in range(local):
        row,rhs=height_row(earlier)
        out.append(([(k,-c) for k,c in row],-rhs))
    return out

SMALL_ROW_ORIGINALS=(0,3,4,5,6,7,8)
CAP_KINDS={'cap_y_pos_escape':(1,1),'cap_y_neg_escape':(1,-1),
           'cap_x_pos_escape':(0,1),'cap_x_neg_escape':(0,-1)}

def small_row_guard(box,eta):
    return all(-eta<=box[i][0]<=box[i][1]<=eta for i in SMALL_ROW_ORIGINALS)

def small_row_specs(threshold):
    return inward_escape_specs(threshold)[2:]

def cap_escape_specs(pair,kind,threshold,gap):
    assert kind in CAP_KINDS
    i,j=pair;axis,sign=CAP_KINDS[kind];across=1-axis
    return [([(2*i+axis,sign)],threshold),([(2*j+axis,sign)],threshold),
            ([(2*i+across,1),(2*j+across,-1)],-gap),
            ([(2*j+across,1),(2*i+across,-1)],-gap)]

def gap_secant(lo,hi,g):
    assert lo<=hi and g>=0
    ff=lambda t:max(abs(t)-g,0)**2
    if lo==hi:return 0,ff(lo)
    fl,fu=ff(lo),ff(hi)
    return (fu-fl)/(hi-lo),(hi*fl-lo*fu)/(hi-lo)

def interval_row_propagation(X,Y,rows,eps):
    for entries,rval in rows:
        merged={}
        for k,c in entries:merged[k]=merged.get(k,0)+c
        merged={k:c for k,c in merged.items() if c}
        for k,c in merged.items():
            other=0
            for j,d in merged.items():
                if j==k:continue
                interval=(Y if j%2 else X)[j//2]
                other+=d*interval[0 if d>0 else 1]
            interval=(Y if k%2 else X)[k//2];bound=(rval-other)/c
            if c>0:interval[1]=min(interval[1],bound+eps)
            else:interval[0]=max(interval[0],bound-eps)

CORRELATED_KINDS=('correlated_row50_escape','correlated_row30_escape')
COLUMN_KINDS={'column_x_escape':0,'column_y_escape':1}
COLUMN_CHAINS=tuple(permutations(range(9),3))+tuple(permutations(range(9),4))
assert len(COLUMN_CHAINS)==3528
COLUMN_INDEX={chain:index+1 for index,chain in enumerate(COLUMN_CHAINS)}

def correlated_parameters(kind,one):
    assert kind in CORRELATED_KINDS
    return (one/50,one*9/20) if kind=='correlated_row50_escape' else (one/30,one*11/30)

def column_specs(marker,kind,one):
    assert kind in COLUMN_KINDS and marker[0]==0 and 1<=marker[1]<=len(COLUMN_CHAINS)
    chain=COLUMN_CHAINS[marker[1]-1];axis=COLUMN_KINDS[kind];across=1-axis
    rows=[([(2*j+axis,1),(2*i+axis,-1)],0) for i,j in zip(chain,chain[1:])]
    rows.append(([(2*chain[0]+axis,1),(2*chain[-1]+axis,-1)],-one*(len(chain)-2)-one*4/5))
    from itertools import product
    for signs in product((-1,1),repeat=len(chain)-1):
        row=[]
        for (i,j),sg in zip(zip(chain,chain[1:]),signs):row.extend(((2*i+across,sg),(2*j+across,-sg)))
        rows.append((row,-one*3/5))
    assert len(rows)==(7 if len(chain)==3 else 12)
    return rows

def alternate_chain(pair):
    options={(1,7):(0,1,7,3),(1,8):(0,1,8,3),(2,7):(0,2,7,3),
             (2,8):(0,2,8,3),(7,8):(0,7,8,3)}
    assert pair in options
    return options[pair]

def alternate_escape_specs(pair,half):
    chain=alternate_chain(pair);rows=[]
    for i,j in zip(chain,chain[1:]):
        for sign in (-1,1):
            rows.append(([(2*j,1),(2*i,-1),(2*j+1,sign),(2*i+1,-sign)],0))
    for i,j in ((chain[0],chain[1]),(chain[2],chain[3])):
        rows.append(([(2*j,1),(2*i,-1),(18+i,-half),(36+i,-half),
                      (18+j,-half),(36+j,-half)],0))
    return rows

def inward_escape_specs(threshold):
    from itertools import product
    rows=[([(14,1),(0,-1)],0), ([(6,1),(16,-1)],0)]
    for s1,s2,s3 in product((-1,1),repeat=3):
        rows.append(([(1,s1),(15,s2-s1),(17,s3-s2),(7,-s3)],-threshold))
    return rows

def matrix(box,pos,choices,circle_cuts=()):
    N=54+6*sum(kind=='sat' for pair,kind,ch in choices)
    # Derived sign restrictions use the ORIGINAL strict weak CD bit, not
    # the closed LP relaxation of that bit. Every omitted owner has the
    # explicit pen-and-paper impossibility proof in CONE_SEPARATOR_SIGNS.
    effective=list(box);forbidden=None
    for pair,kind,ch in choices:
        if kind=='inward_row_escape' and ch[0] in (0,1):
            forbidden='accepted_unique_A_leftmost' if ch[0]==0 else 'accepted_no_extra_right_of_D'
        if kind in ('row_escape','positive_row_escape','asymmetric_escape') and ch[0]==1:
            forbidden='accepted_no_extra_right_of_D'
    # This changes interval coefficients, so every new leaf carries an
    # explicit context version. Old leaves retain their original context in
    # the independent verifier. Actual main spans give h_A+h_B<=R-1,
    # hence |tan(theta_A)|,|tan(theta_B)|<7/40.
    for owner in (0,1):
        l,u=effective[owner];ll=max(l,-7/40);uu=min(u,7/40)
        if ll>uu:forbidden='accepted_left_main_angle_bound'
        else:effective[owner]=(ll,uu)
    product_cursor=54
    def product_rows(z,U,V,UB,VB,name):
        ul,uu=UB;vl,vu=VB
        def scale(E,c):return [(i,c*v) for i,v in E]
        add([(z,-1)]+scale(V,ul)+scale(U,vl),ul*vl,name+'_lower_ll')
        add([(z,-1)]+scale(V,uu)+scale(U,vu),uu*vu,name+'_lower_uu')
        add([(z,1)]+scale(V,-uu)+scale(U,-vl),-uu*vl,name+'_upper_ul')
        add([(z,1)]+scale(V,-ul)+scale(U,-vu),-ul*vu,name+'_upper_lu')
    for pair,kind,ch in choices:
        if kind!='sat':continue
        owner,axis,sg=ch
        if pair==(2,3):
            if sg<0:forbidden='weak_cone_backward_or_downward_steep'
            elif axis==0:
                l,u=effective[owner]
                if u<=0:forbidden='accepted_all_tilts_CD_normal_upward'
                else:effective[owner]=(max(l,0.),u)
            elif effective[3][0]>=0 and owner==2:
                if axis==1:forbidden='accepted_positive_D_excludes_steep_C_owner'
                elif effective[2][1]<=0:forbidden='accepted_positive_D_excludes_downward_C_owner'
            elif axis==1:
                l,u=effective[owner]
                if l>=0:forbidden='weak_cone_upward_steep_requires_negative_tilt'
                else:effective[owner]=(l,min(u,0.))
        if pair==(3,6):
            if axis==1 and sg<0:forbidden='accepted_DG_normal_upward'
            elif axis==0:
                l,u=effective[owner]
                if sg>0:
                    if u<=0:forbidden='accepted_DG_normal_upward'
                    else:effective[owner]=(max(l,0.),u)
                else:
                    if l>=0:forbidden='accepted_DG_normal_upward'
                    else:effective[owner]=(l,min(u,0.))
        if pair in ((0,4),(1,5),(2,5)):
            if axis==1 and sg<0:forbidden='accepted_AE_BF_CF_normal_upward'
            elif axis==0:
                l,u=effective[owner]
                if sg>0:
                    if u<=0:forbidden='accepted_AE_BF_CF_normal_upward'
                    else:effective[owner]=(max(l,0.),u)
                else:
                    if l>=0:forbidden='accepted_AE_BF_CF_normal_upward'
                    else:effective[owner]=(l,min(u,0.))
    box=tuple(effective)
    if forbidden:
        hs=[base.hbounds(T) for T in box];gs=[.25/h[1] for h in hs]
        return np.zeros((1,N)),np.array([-1.]),[forbidden],list(pos),hs,gs
    CB,hs,gs=base.center_bounds(box,pos,choices);rows=[];rhs=[];names=[]
    if any(l>u+1e-8 for l,u in CB):return np.zeros((1,N)),np.array([-1.]),['empty_propagated_center_interval'],CB,hs,gs
    def add(entries,rv,name):
        co=np.zeros(N)
        for k,v in entries:co[k]+=v
        rows.append(co);rhs.append(rv);names.append(name)
    for k,(l,u) in enumerate(CB):
        add([(k,1)],u,'bound_up_'+str(k));add([(k,-1)],-l,'bound_lo_'+str(k))
    for i,(tl,tu) in enumerate(box):
        aa,bb=base.nbounds(box[i],0,1)
        for var,rr in ((AL(i),aa),(BE(i),bb),(AB(i),(max(0,base.beta_lo(box[i])),max(abs(bb[0]),abs(bb[1])))),(GI(i),(gs[i],.25/hs[i][0]))):
            add([(var,1)],rr[1],f'pose_up_{var}');add([(var,-1)],-rr[0],f'pose_lo_{var}')
        add([(AL(i),-1),(AB(i),-1)],-2*hs[i][0],f'width_lower_{i}')
        add([(AL(i),1),(AB(i),1)],2*hs[i][1],f'width_upper_{i}')
        add([(AB(i),1),(AL(i),-1)],0,f'fold_order_{i}')
        for ax in (0,1):
          for sg in (-1,1):
            add([(2*i+ax,sg),(AL(i),.5),(AB(i),.5)],sqrt(Q)+1e-12,f'axis_support_shared_width_{i}_{ax}_{sg}')
        # Convex hull of the original |beta| graph on this beta interval.
        add([(BE(i),1),(AB(i),-1)],0,f'abs_pos_{i}')
        add([(BE(i),-1),(AB(i),-1)],0,f'abs_neg_{i}')
        if tl>=0:add([(AB(i),1),(BE(i),-1)],0,f'abs_equal_pos_{i}')
        elif tu<=0:add([(AB(i),1),(BE(i),1)],0,f'abs_equal_neg_{i}')
        else:
            bl,bu=bb;slope=(bu+bl)/(bu-bl);intercept=-2*bu*bl/(bu-bl)
            add([(AB(i),1),(BE(i),-slope)],intercept+1e-11,f'abs_chord_{i}')
        for p,q in base.DIRS:
            add([(AL(i),p),(BE(i),q)],sqrt(p*p+q*q)+1e-12,f'unit_disk_{i}_{p}_{q}')
        ul=np.array([1.,tl])/sqrt(1+tl*tl);uu=np.array([1.,tu])/sqrt(1+tu*tu)
        nm=np.round((ul+uu)*2**30)/2**30
        low=min(nm@ul,nm@uu)-1e-11
        add([(AL(i),-nm[0]),(BE(i),-nm[1])],-low,f'arc_chord_{i}')
        # g=1/[2(alpha+|beta|)] lies above every reciprocal tangent.
        for ss in (1.,9/8,5/4,11/8,3/2):
            co=-1/(2*ss*ss)
            add([(GI(i),-1),(AL(i),co),(AB(i),co)],-1/ss,f'inset_tangent_{i}_{ss}')
        for p,q in base.DIRS:
            bound=sqrt(Q*(p*p+q*q))+1e-12
            for s in (-1,1):
              for t in (-1,1):
                add([(2*i,p),(2*i+1,q),(AL(i),(s*p+t*q)/2),(BE(i),(s*q-t*p)/2)],bound,f'corner_support_{i}_{p}_{q}_{s}_{t}')
    for i,j,bit in base.EDGES:
        for sy in (-1,1):add([(2*i,1),(2*j,-1),(2*i+1,sy),(2*j+1,-sy)],0,f'cone_{i}_{j}_{sy}')
        widths=[(GI(i),1),(GI(j),1)] if bit else [(AL(i),.5),(AB(i),.5),(AL(j),.5),(AB(j),.5)]
        add([(2*i,1),(2*j,-1)]+widths,0,f'chain_{i}_{j}')
    add([(6,1),(4,-1),(AL(2),-.5),(AB(2),-.5),(AL(3),-.5),(AB(3),-.5)],0,'CD_weak')
    add([(5,1),(7,-1)],-5/8,'CD_big_transverse')
    add([(7,1),(13,-1)],0,'accepted_G_above_D')
    add([(7,1),(13,-1),(AL(3),7/16),(AB(3),7/16),(AL(6),7/16),(AB(6),7/16)],41/120,'DG_width_clearance')
    add([(12,-1),(AL(6),.5),(AB(6),.5)],-101/432,'accepted_G_edge')
    add([(4,1),(AL(2),-.5),(AB(2),-.5)],5/64,'accepted_C_edge')
    add([(14,1),(16,-1)],0,'extras_x_order')
    add([(4,-a),(12,-b),(AL(2),a/2),(AB(2),a/2),(AL(6),b/2),(AB(6),b/2)],-6.75,'left_cap_and_chains')
    add([(6,1),(12,-1)],1459/1728,'DG_horizontal_cap')
    add([(6,-1),(12,1)],1459/1728,'DG_horizontal_cap_other')
    for i in range(9):
      for j in range(9):
        if i==j:continue
        pose=[(AL(i),-a/2),(AB(i),-a/2+4),(AL(j),-b/2),(AB(j),-b/2)]
        for axis in (0,1):
          for sg in (-1,1):
            add([(2*i+axis,sg*a),(2*j+axis,sg*b)]+pose,211/4,f'all_pair_cap_{i}_{j}_{axis}_{sg}')
    budget=[(AL(1),a),(AB(1),a),(AL(2),a/2),(AB(2),a/2),(GI(2),a),(AL(5),b),(AB(5),b),(AB(0),4),(AB(3),4),(AL(3),-a/2),(AB(3),-a/2),(GI(3),a)]
    add(budget,2*a+b,'orientation_budget')
    if box[3][0]>=0:
        # Complete signed cap after the accepted G>D order theorem.
        k=207/16
        add([(6,a),(12,b),(AL(3),a/2),(BE(3),a/2-k),(AL(6),-b/2),(AB(6),-b/2)],211/4+a,'signed_right_cap')
        signedbudget=[(j,c) for j,c in budget]+[(AB(3),-4),(AL(3),a),(BE(3),a-k)]
        add(signedbudget,3*a+b,'signed_orientation_budget')
    for pair,kind,ch in choices:
        i,j=pair
        if kind=='proxy':
            ax,sg=ch;add([(2*i+ax,sg),(2*j+ax,-sg),(GI(i),1),(GI(j),1)],0,f'proxy_{i}_{j}_{ax}_{sg}')
        elif kind=='sat':
            owner,ax,sg=ch;nn=base.nbounds(box[owner],ax,sg)
            nm=np.round(np.array([(l+u)/2 for l,u in nn])*2**30)/2**30
            dr=[]
            for xy in (0,1):
                lo=CB[2*j+xy][0]-CB[2*i+xy][1];hi=CB[2*j+xy][1]-CB[2*i+xy][0]
                if pair==(2,3):lo=max(lo,gs[2]+gs[3] if xy==0 else 5/8);hi=min(hi,31/30)
                if pair==(3,6) and xy==0:lo=max(lo,-1459/1728);hi=min(hi,1459/1728)
                if pair==(3,6) and xy==1:lo=max(lo,0)
                if pair==(1,5):
                    lo=max(lo,269/1728 if xy==0 else gs[1]+gs[5])
                    if xy==0:hi=min(hi,751/960)
                if pair==(2,5) and xy==1:lo=max(lo,gs[2]+gs[5])
                if pair==(0,4):
                    if xy==0:lo=max(lo,-17/20);hi=min(hi,17/20)
                    else:lo=max(lo,gs[0]+gs[4])
                dr.append((lo,hi))
            d0=np.round(np.array([(l+u)/2 for l,u in dr])*2**30)/2**30
            upper=sum(base.mulup(nn[k],dr[k]) for k in (0,1))
            add([],upper-base.reqlo(box[i],box[j]),f'sep_projection_upper_{i}_{j}_{owner}_{ax}_{sg}')
            error=sum(base.mulup((nn[k][0]-nm[k],nn[k][1]-nm[k]),(dr[k][0]-d0[k],dr[k][1]-d0[k])) for k in (0,1))
            pose=[(AL(owner),-sg*d0[0]),(BE(owner),-sg*d0[1])] if ax==0 else [(BE(owner),sg*d0[0]),(AL(owner),-sg*d0[1])]
            if pair==(3,6):
                add([(BE(owner),-sg)] if ax==0 else [(AL(owner),-sg)],0,f'accepted_DG_normal_up_{owner}_{ax}_{sg}')
            add([(2*i,nm[0]),(2*i+1,nm[1]),(2*j,-nm[0]),(2*j+1,-nm[1])]+pose,-base.reqlo(box[i],box[j])+error-d0@nm,f'sep_{i}_{j}_{owner}_{ax}_{sg}')
            # Full McCormick envelopes preserve shared original frame and
            # center variables in both separator projection and pair support.
            z=list(range(product_cursor,product_cursor+6));product_cursor+=6
            normal=[[(AL(owner),sg)],[(BE(owner),sg)]] if ax==0 else [[(BE(owner),-sg)],[(AL(owner),sg)]]
            for xy in (0,1):
                diff=[(2*j+xy,1),(2*i+xy,-1)]
                product_rows(z[xy],normal[xy],diff,nn[xy],dr[xy],f'product_nd_{i}_{j}_{xy}')
            ai,bi=base.nbounds(box[i],0,1);aj,bj=base.nbounds(box[j],0,1)
            for target,U,V,UB,VB,label in (
                (z[2],AL(i),AL(j),ai,aj,'aa'),(z[3],BE(i),BE(j),bi,bj,'bb'),
                (z[4],AL(i),BE(j),ai,bj,'ab'),(z[5],BE(i),AL(j),bi,aj,'ba')):
                product_rows(target,[(U,1)],[(V,1)],UB,VB,f'product_frame_{i}_{j}_{label}')
            for signed in (-1,1):
                add([(z[0],-2),(z[1],-2),(z[2],1),(z[3],1),(z[4],signed),(z[5],-signed)],-1,f'full_physical_sep_{i}_{j}_{signed}')
            add([(z[0],-1),(z[1],-1)],-base.reqlo(box[i],box[j]),f'full_physical_sep_req_{i}_{j}')
            add([(z[2],-1),(z[3],-1)],0,f'relative_cos_nonnegative_{i}_{j}')
            add([(z[2],1),(z[3],1)],1,f'relative_cos_upper_{i}_{j}')
            for signed in (-1,1):add([(z[4],signed),(z[5],-signed)],1,f'relative_sin_bound_{i}_{j}_{signed}')
    # Append-only strengthening: the ORIGINAL folded pair (alpha,|beta|)
    # lies on the quarter-circle, even when the signed beta box crosses zero.
    # The rational chord follows by concavity: its endpoint values are 1 and
    # 17/(12*sqrt(2))>1.  Previous leaf row indices remain unchanged.
    for i in range(9):
        add([(AL(i),-1),(AB(i),-5/12)],-1,f'folded_rational_chord_{i}')
        for p,q in base.DIRS:
            if p>=0 and q>=0:
                add([(AL(i),p),(AB(i),q)],sqrt(p*p+q*q)+1e-12,f'folded_unit_support_{i}_{p}_{q}')
    # Accepted left-main inset barrier: g_A-|y_A|>3/40.
    add([(1,1),(GI(0),-1)],-3/40,'left_main_inset_barrier_up')
    add([(1,-1),(GI(0),-1)],-3/40,'left_main_inset_barrier_down')
    # Every original center is in the radius-rho disk. Every two original
    # centers have Euclidean distance at least 1 (inscribed radius-1/2 disks).
    for i in range(9):
        for p,q in base.DIRS:
            add([(2*i,p),(2*i+1,q)],rho*sqrt(p*p+q*q)+1e-12,f'original_center_disk_{i}_{p}_{q}')
        for j in range(i+1,9):
            ll,uu=CB[2*j][0]-CB[2*i][1],CB[2*j][1]-CB[2*i][0]
            vv,ww=CB[2*j+1][0]-CB[2*i+1][1],CB[2*j+1][1]-CB[2*i+1][0]
            # z^2 <= (lower+upper)z-lower*upper on each true interval.
            add([(2*i,ll+uu),(2*j,-ll-uu),(2*i+1,vv+ww),(2*j+1,-vv-ww)],-1-ll*uu-vv*ww,f'original_center_distance_secant_{i}_{j}')
            g=max(gs[i],gs[j]);ax,bx=gap_secant(ll,uu,g);ay,by=gap_secant(vv,ww,g)
            add([(2*i,ax),(2*j,-ax),(2*i+1,ay),(2*j+1,-ay)],-.25+bx+by,f'original_inset_disk_secant_{i}_{j}')
            aa_i=base.nbounds(box[i],0,1)[0][1];aa_j=base.nbounds(box[j],0,1)[0][1]
            p=max(.5/aa_i,.5/aa_j)
            ap,bp=gap_secant(ll+vv,uu+ww,p);am,bm=gap_secant(ll-ww,uu-vv,p)
            ax,ay=ap+am,ap-am
            add([(2*i,ax),(2*j,-ax),(2*i+1,ay),(2*j+1,-ay)],-.5+bp+bm,f'original_diamond_disk_secant_{i}_{j}')
    # Original D/G aligned insets cannot separate horizontally; G>D fixes
    # their vertical order. This complements the affine width clearance.
    add([(7,1),(13,-1),(GI(3),1),(GI(6),1)],0,'DG_original_inset_clearance')
    # Both original D-chirality low-gap proofs now cover v<=2/3.
    # Retain old weaker rows/intervals to preserve all earlier leaf indices.
    add([(5,1),(7,-1)],-2/3,'remaining_bulk_transverse_two_thirds')
    # Accepted positive-D owner reduction: a surviving C-owned shallow
    # axis points upward, so its original abs-beta graph has positive sign.
    if box[3][0]>=0 and any(pair==(2,3) and kind=='sat' and ch==(2,0,1) for pair,kind,ch in choices):
        add([(BE(2),-1)],0,'positive_D_C_owned_normal_upward')
        add([(AB(2),1),(BE(2),-1)],0,'positive_D_C_owned_abs_sign')
    # Append a dense exact-rational unit-direction family for EVERY original
    # corner. Sparse primitive directions alone leave a fixed polygon error
    # which orientation refinement cannot remove.
    for i in range(9):
        for direction,(p,q) in enumerate(DENSE_DIRS):
            for s in (-1,1):
                for t in (-1,1):
                    add([(2*i,p),(2*i+1,q),(AL(i),(s*p+t*q)/2),(BE(i),(s*q-t*p)/2)],sqrt(Q)+1e-12,f'dense_original_corner_{i}_{direction}_{s}_{t}')
    # Strict-caller hand inputs, each proved before this finite search.
    # The slant theorem has a complete independent exact three-original
    # forest; the CG row and the escape disjunctions have hand proofs.
    add([(5,1),(4,7/8)],-7/32,'accepted_C_slant')
    add([(5,1),(13,-1),(AL(2),.5),(AB(2),.5),(AL(6),.5),(AB(6),.5)],-97/4480,'accepted_CG_actual_vertical_clearance')
    for pair,kind,ch in choices:
        if kind=='row_escape':
            original=pair[1];xx=2*original;yy=xx+1;branch=ch[0]
            rowspec=(
                ([(xx,1),(2,-1)],0), ([(6,1),(xx,-1)],0),
                ([(yy,1),(3,-1)],-1/8), ([(3,1),(yy,-1)],-1/8),
                ([(7,1),(yy,-1)],-1/8), ([(yy,1),(7,-1)],-1/8))
            entries,rval=rowspec[branch]
            add(entries,rval,f'accepted_replacement_row_escape_{original}_{branch}')
        elif kind=='lower_escape':
            original=pair[1];branch=ch[0]
            add([(2*original,1)],0,f'accepted_right_lower_escape_{original}_0') if branch==0 else add([(5,1),(2*original+1,-1)],0,f'accepted_right_lower_escape_{original}_1')
    # Universal sharp toll is a separate necessary cap, never added to the
    # four-beta cap. It is valid for either physical endpoint chirality.
    for i,j,sg in ((0,4,-1),(3,6,1)):
        add([(2*i,sg*a),(2*j,sg*b),(AL(i),25*a/32),(AB(i),-7*a/32),(AL(j),-b/2),(AB(j),-b/2)],211/4+41*a/32,f'sharp_endpoint_cap_{i}_{j}')
    # Exact canonical contact directions remove the residual support-polygon
    # slack at equality. Q*(p^2+q^2)=(1105/16)^2 exactly.
    for i in range(9):
        for direction,(p,q) in enumerate(CONTACT_DIRS):
            for s in (-1,1):
                for t in (-1,1):
                    add([(2*i,p),(2*i+1,q),(AL(i),(s*p+t*q)/2),(BE(i),(s*q-t*p)/2)],1105/16,f'exact_contact_corner_{i}_{direction}_{s}_{t}')
    # Accepted full original F-order and C/F contained-inset consequences.
    add([(5,1),(11,-1),(GI(2),1),(GI(5),1)],0,'accepted_CF_vertical_insets')
    for sg in (-1,1):
        add([(10,sg),(4,-sg),(GI(2),-1),(GI(5),-1)],-1/25,f'accepted_CF_horizontal_overlap_{sg}')
    kk=92/27
    add([(12,1),(13,-1),(5,1),(4,kk),(AL(2),-kk/2),(AB(2),-kk/2)],0,'accepted_F_order_linear_S')
    for pair,kind,ch in choices:
        if kind=='asymmetric_escape':
            original=pair[1];xx=2*original;yy=xx+1;branch=ch[0]
            spec=(
                ([(xx,1),(2,-1)],0), ([(6,1),(xx,-1)],0),
                ([(yy,1),(3,-1)],0), ([(3,1),(yy,-1)],-1/3),
                ([(7,1),(yy,-1)],-1/16), ([(yy,1),(7,-1)],-1/16))
            entries,rval=spec[branch];add(entries,rval,f'accepted_asymmetric_row_escape_{original}_{branch}')
        elif kind=='positive_row_escape':
            original=pair[1];xx=2*original;yy=xx+1;branch=ch[0]
            spec=(
                ([(xx,1),(2,-1)],0), ([(6,1),(xx,-1)],0),
                ([(3,1),(7,-1)],-1/2), ([(3,-1),(7,1)],-1/2),
                ([(yy,-2),(3,1),(7,1)],-1/2), ([(yy,2),(3,-1),(7,-1)],-1/2))
            entries,rval=spec[branch];add(entries,rval,f'accepted_positive_total_variation_escape_{original}_{branch}')
    # A finite support polygon can retain a false corner pocket. These36
    # original signed-frame interval rows converge to genuine containment
    # when the corresponding original angle and center boxes are refined.
    def linear_interval(coef,interval):
        ll,uu=interval
        return (coef*ll,coef*uu) if coef>=0 else (coef*uu,coef*ll)
    def min_abs(interval):
        ll,uu=interval
        return 0. if ll<=0<=uu else min(abs(ll),abs(uu))
    for i in range(9):
        aa,bb=base.nbounds(box[i],0,1)
        for s in (-1,1):
            for t in (-1,1):
                sx=linear_interval(s/2,aa);tx=linear_interval(-t/2,bb)
                sy=linear_interval(s/2,bb);ty=linear_interval(t/2,aa)
                xx=(CB[2*i][0]+sx[0]+tx[0],CB[2*i][1]+sx[1]+tx[1])
                yy=(CB[2*i+1][0]+sy[0]+ty[0],CB[2*i+1][1]+sy[1]+ty[1])
                add([],Q-min_abs(xx)**2-min_abs(yy)**2,f'original_corner_box_norm_{i}_{s}_{t}')
    # Ordered escape semantics: in child j, also impose the closed
    # complements of predecessors0,...,j-1. Exhaustiveness follows by
    # selecting the FIRST satisfied halfspace in the accepted escape union.
    # These are conditional case assumptions, not global geometric claims.
    for pair,kind,ch in choices:
        if kind not in ('lower_escape','row_escape','asymmetric_escape','positive_row_escape'):continue
        original=pair[1];xx=2*original;yy=xx+1
        if kind=='lower_escape':
            spec=(([(xx,1)],0), ([(5,1),(yy,-1)],0))
        elif kind=='positive_row_escape':
            spec=(
                ([(xx,1),(2,-1)],0), ([(6,1),(xx,-1)],0),
                ([(3,1),(7,-1)],-1/2), ([(3,-1),(7,1)],-1/2),
                ([(yy,-2),(3,1),(7,1)],-1/2), ([(yy,2),(3,-1),(7,-1)],-1/2))
        elif kind=='asymmetric_escape':
            spec=(
                ([(xx,1),(2,-1)],0), ([(6,1),(xx,-1)],0),
                ([(yy,1),(3,-1)],0), ([(3,1),(yy,-1)],-1/3),
                ([(7,1),(yy,-1)],-1/16), ([(yy,1),(7,-1)],-1/16))
        else:
            spec=(
                ([(xx,1),(2,-1)],0), ([(6,1),(xx,-1)],0),
                ([(yy,1),(3,-1)],-1/8), ([(3,1),(yy,-1)],-1/8),
                ([(7,1),(yy,-1)],-1/8), ([(yy,1),(7,-1)],-1/8))
        for previous in range(ch[0]):
            entries,rval=spec[previous]
            add([(k,-c) for k,c in entries],-rval,
                f'ordered_escape_guard_{kind}_{original}_{ch[0]}_{previous}')
    # Complete G-edge table and its original B/F, A/E hand consequences.
    add([(12,1),(AL(6),-.5),(AB(6),-.5)],49/64,'accepted_G_edge_upper')
    add([(8,1),(AL(4),.5),(AB(4),.5)],-15/64,'accepted_E_right_edge_upper')
    add([(10,1),(AL(5),.5),(AB(5),.5)],49/64,'accepted_F_right_edge_upper')
    add([(10,-1)],115/432,'accepted_F_horizontal_lower')
    add([(3,1),(11,-1),(GI(1),1),(GI(5),1)],0,'accepted_BF_vertical_insets')
    add([(2,1),(10,-1)],-269/1728,'accepted_BF_horizontal_lower')
    add([(10,1),(2,-1)],751/960,'accepted_BF_horizontal_upper')
    for sg in (-1,1):
        add([(10,sg),(2,-sg),(GI(1),-1),(GI(5),-1)],-1/7104,'accepted_BF_horizontal_inset_overlap')
        add([(10,sg),(2,-sg),(3,1),(11,-1)],-1/7104,'accepted_BF_strict_vertical_cone')
        add([(8,sg),(0,-sg),(GI(0),-1),(GI(4),-1)],-3/20,'accepted_AE_horizontal_inset_overlap')
        add([(10,sg),(GI(5),-1)],-1/12,'accepted_F_contains_central_strip')
    # Complete E>A table. Strict inequalities are weakened only in these
    # necessary LP rows; their strict original premise still supplies the
    # omission of every non-upward physical A/E separator.
    add([(1,1),(9,-1),(GI(0),1),(GI(4),1)],0,'accepted_AE_vertical_insets')
    for sg in (-1,1):
        add([(8,sg),(0,-sg),(1,1),(9,-1)],-3/20,'accepted_AE_strict_vertical_cone')
    add([(9,-1),(GI(4),1)],-3/40,'accepted_E_inset_lower_edge')
    add([(9,-1)],-17/40,'accepted_E_height_lower')
    add([(3,1),(9,-1)],-13/480,'accepted_E_above_B')
    # A's universal sharp cap has the independently proved width lower
    # toll17(h_A-1/2) on its entire accepted h_A<37/64 range.
    add([(0,-a),(8,-b),(AL(0),-29/2),(AB(0),-29/2),
         (AL(4),-b/2),(AB(4),-b/2)],245/4,'accepted_left_width_toll_cap')
    if box[0][1]<=0:
        k=207/16
        add([(0,-a),(8,-b),(AL(0),a/2),(BE(0),-a/2+k),
             (AL(4),-b/2),(AB(4),-b/2)],211/4+a,'signed_left_cap')
        left_signed_budget=list(budget)+[(AB(0),-4),(AL(0),a),(BE(0),-a+k)]
        add(left_signed_budget,3*a+b,'left_signed_orientation_budget')
        if box[3][0]>=0:
            both_signed_budget=left_signed_budget+[(AB(3),-4),(AL(3),a),(BE(3),a-k)]
            add(both_signed_budget,4*a+b,'both_signed_orientation_budget')
    # Complete G upper-inset table and original extra endpoint strip.
    add([(13,-1),(GI(6),1)],-3/40,'accepted_G_inset_lower_edge')
    add([(13,-1)],-17/40,'accepted_G_height_lower')
    add([(3,1),(13,-1)],-13/480,'accepted_G_above_B')
    for original in (7,8):add([(2*original,1),(6,-1)],0,f'accepted_extra_left_of_D_{original}')
    for original in (7,8):add([(2*original,1)],5/4,f'accepted_extra_x_below_five_fourths_{original}')
    # New complete original-frame folded chord and unique-A-outermost input.
    for i,(lo,hi) in enumerate(box):
        folded=max(abs(lo),abs(hi));co=min(5/12,folded/2)
        add([(AL(i),-1),(AB(i),-co)],-1,f'adaptive_folded_chord_{i}')
        if i!=0:add([(0,1),(2*i,-1)],0,f'accepted_A_leftmost_{i}')
    for pair,kind,ch in choices:
        if kind=='inward_row_escape':
            assert pair==(7,8) and box[0][1]<=0 and box[3][0]>=0
            specs=inward_escape_specs(11/30)
        elif kind=='alternate_four_escape':specs=alternate_escape_specs(pair,.5)
        elif kind=='general_alternate_escape':specs=general_alternate_specs(pair,.5)
        elif kind=='small_row_escape':specs=small_row_specs(1/12)
        elif kind in CAP_KINDS:specs=cap_escape_specs(pair,kind,3/5,29/60)
        elif kind in CORRELATED_KINDS:specs=small_row_specs(correlated_parameters(kind,1.)[1])
        elif kind in COLUMN_KINDS:specs=column_specs(pair,kind,1.)
        else:continue
        entries,rval=specs[ch[0]];add(entries,rval,kind+'_primary')
        for earlier in range(ch[0]):
            entries,rval=specs[earlier]
            add([(k,-v) for k,v in entries],-rval,kind+'_predecessor')
    for pair,kind,ch in choices:
        if kind=='f_side_escape':
            for row,rval in f_side_escape_rows(pair,ch[0],3/5):add(row,rval,'F_side_height_routing')
    # A recorded rational normal gives a valid support inequality for each
    # ORIGINAL signed-frame corner. Its source point is only a discovery
    # heuristic; exact replay independently reconstructs every coefficient.
    for ci,cut in enumerate(circle_cuts):
        original,s,t,pn,qn,power=cut
        scale=1<<power;p=pn/scale;q=qn/scale
        add([(2*original,p),(2*original+1,q),
             (AL(original),(s*p+t*q)/2),(BE(original),(s*q-t*p)/2)],
            sqrt(Q*(p*p+q*q))+1e-12,
            f'adaptive_original_corner_{ci}_{original}_{s}_{t}')
    return np.array(rows),np.array(rhs),names,CB,hs,gs

def solve(box,pos,ch):
    if LOCAL_ENABLED and all(-LOCAL_ETA<=l<=u<=LOCAL_ETA for l,u in box) and all(LOCAL_CENTERS[k]-LOCAL_ETA<=pos[k][0]<=pos[k][1]<=LOCAL_CENTERS[k]+LOCAL_ETA for k in LOCAL_COORDS):
        return {'analytic_terminal':'deep_B_cylinder_1_64_v1','context_version':CONTEXT_VERSION,'discovery_reserve':0.0},None,None
    circle_cuts=[];seen=set()
    A,B,names,CB,hs,gs=matrix(box,pos,ch)
    large=box[3][0]>=0 or any(pair==(2,3) and kind=='sat' and selected[1]==0 for pair,kind,selected in ch)
    radius=1/32 if large else 1/64
    if (len(B)>1 and all(-radius<=l<=u<=radius for l,u in box)
        and all((LOCAL_CENTERS[k]-radius<=pos[k][0]<=pos[k][1]<=LOCAL_CENTERS[k]+radius)
                or (LOCAL_CENTERS[k]-radius+1e-10<=CB[k][0]<=CB[k][1]<=LOCAL_CENTERS[k]+radius-1e-10)
                for k in LOCAL_COORDS)):
        return {'analytic_terminal':'deep_B_propagated_cylinder_v6','local_radius':'1/32' if large else '1/64',
                'context_version':CONTEXT_VERSION,'discovery_reserve':0.0},None,None
    N=A.shape[1]
    for iteration in range(13):
        rr=linprog(np.r_[np.zeros(N),1.],A_ub=np.c_[A,-np.ones(len(B))],b_ub=B,bounds=[(None,None)]*(N+1),method='highs',options={'presolve':True,'threads':1})
        if not rr.success:return None,None,(A,B,names,CB,hs,gs)
        if rr.x[-1]>1e-7:
            lam=-rr.ineqlin.marginals
            terms=[(int(i),int(round(v*2**40))) for i,v in enumerate(lam) if round(v*2**40)>0]
            ll=np.zeros(len(B))
            for i,v in terms:ll[i]=v/2**40
            bounds=np.r_[np.full(18,rho),np.ones(36),np.tile([2*rho,2*rho,1,1,1,1],(N-54)//6)]
            reserve=-ll@B-bounds@abs(ll@A)
            if reserve>1e-8:
                return {'weights':terms,'power':40,'context_version':CONTEXT_VERSION,
                        'circle_cuts':circle_cuts,'discovery_reserve':float(reserve)},rr.x[:18],(A,B,names,CB,hs,gs)
        if iteration==12:break
        candidates=[];power=20;scale=1<<power
        for original in range(9):
            alpha=rr.x[AL(original)];beta=rr.x[BE(original)]
            for ss in (-1,1):
                for tt in (-1,1):
                    xx=rr.x[2*original]+.5*(ss*alpha-tt*beta)
                    yy=rr.x[2*original+1]+.5*(ss*beta+tt*alpha)
                    norm=sqrt(xx*xx+yy*yy)
                    if norm*norm<=Q+1e-8:continue
                    pn=int(round(scale*xx/norm));qn=int(round(scale*yy/norm))
                    cut=(original,ss,tt,pn,qn,power)
                    if cut not in seen:candidates.append((norm*norm-Q,cut))
        if not candidates:break
        for _,cut in sorted(candidates,reverse=True)[:4]:
            seen.add(cut);circle_cuts.append(cut)
            original,ss,tt,pn,qn,power=cut;scale=1<<power;p=pn/scale;q=qn/scale
            co=np.zeros(N)
            for k,val in ((2*original,p),(2*original+1,q),
                          (AL(original),(ss*p+tt*q)/2),(BE(original),(ss*q-tt*p)/2)):
                co[k]+=val
            A=np.vstack((A,co));B=np.append(B,sqrt(Q*(p*p+q*q))+1e-12)
            names.append(f'adaptive_original_corner_{len(circle_cuts)-1}_{original}_{ss}_{tt}')
    return None,rr.x[:18],(A,B,names,CB,hs,gs)

if __name__=='__main__':
    original_select=base.select
    def select(box,pos,ch,point,data):
        if box[3][0]<0<box[3][1]:return ('angle',3)
        selected={(p,k) for p,k,val in ch}
        for pair in ((2,3),(3,6),(2,6)):
            if (pair,'sat') not in selected:return ('sat',pair)
        return original_select(box,pos,ch,point,data)
    base.matrix=matrix;base.solve=solve;base.select=select;base.main()
