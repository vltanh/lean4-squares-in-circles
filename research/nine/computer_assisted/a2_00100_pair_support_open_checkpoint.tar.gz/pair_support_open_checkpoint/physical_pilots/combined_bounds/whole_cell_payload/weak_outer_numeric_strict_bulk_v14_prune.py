#!/usr/bin/env python3
"""Reprove open ancestors with a strengthened model; retain exact coverage.

Every newly closed parent is independently replayed before replacing its
descendants. An unresolved frontier is preserved and is never called a proof.
"""
import argparse,hashlib,json,time
from pathlib import Path
import weak_outer_numeric_strict_bulk_v14_lp as producer
from sparse_bulk_v14 import solve as sparse_solve
producer.solve=sparse_solve
import weak_outer_numeric_strict_bulk_v14_verify as verifier

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('source',type=Path);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--root-side',type=int,choices=(0,1),required=True)
    args=ap.parse_args();source_bytes=args.source.read_bytes();old=json.loads(source_bytes)
    root={'children':{},'open':0};prefix=[['angle',3,args.root_side]]
    for typ in ('leaves','frontier'):
        for item in old[typ]:
            assert item['path'][:1]==prefix;cur=root
            if typ=='frontier':cur['open']+=1
            for step in item['path'][1:]:
                key=json.dumps(step,separators=(',',':'))
                cur=cur['children'].setdefault(key,{'children':{},'open':0,'step':step})
                if typ=='frontier':cur['open']+=1
            assert 'item' not in cur;cur['item']=item;cur['type']=typ
    leaves=[];frontier=[];new_proofs=[];attempts=0;start=time.time()
    def collect(node):
        if 'item' in node:
            (leaves if node['type']=='leaves' else frontier).append(node['item']);return
        for child in node['children'].values():collect(child)
    def visit(node,path):
        nonlocal attempts
        if node['open']==0:collect(node);return
        box,pos,ch=verifier.reconstruct(path)
        box=tuple(tuple(map(float,t)) for t in box);pos=tuple(tuple(map(float,t)) for t in pos)
        hit,point,data=producer.solve(box,pos,ch);attempts+=1
        if hit:
            item=json.loads(json.dumps({'box':box,'position':pos,'choices':ch,'path':path,**hit}))
            reserve,terminal=verifier.replay_leaf(item)
            leaves.append(item);new_proofs.append(item)
            print('exact parent',len(path),'covered frontier',node['open'],
                  'reserve',str(reserve)[:60] if reserve else terminal,
                  'attempts',attempts,flush=True)
        elif 'item' in node:frontier.append(node['item'])
        else:
            for child in node['children'].values():visit(child,path+[child['step']])
    visit(root,prefix)
    result=dict(old,schema='strict-bulk-2026-11-03-v14',leaves=leaves,frontier=frontier,nodes=old['nodes']+attempts,
                target_transverse=getattr(producer.base,'TARGET_TRANSVERSE','5/8'))
    partition=verifier.verify_partition(result,args.root_side)
    report={'proof':False,'old_leaves':len(old['leaves']),'old_frontier':len(old['frontier']),
            'new_leaves':len(leaves),'new_frontier':len(frontier),
            'new_exact_parent_proofs':len(new_proofs),'lp_attempts':attempts,
            'partition':partition,'seconds':time.time()-start,
            'source_sha256':hashlib.sha256(source_bytes).hexdigest(),
            'all_new_parent_proofs_exact_pass':True}
    args.out.write_text(json.dumps(result,separators=(',',':'))+'\n')
    args.out.with_suffix('.report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
