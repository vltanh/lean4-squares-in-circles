#!/usr/bin/env python3
"""Exact reuse of the complete deep-boundary table at radius1/32.

The accepted nonlinear row estimates do not change. Only cases whose
original D angle is nonnegative, or whose physical CD separator is
shallow, are used. Each permitted case has the sharper recorded cost.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
import weak_outer_deep_boundary_verify as deep

CERT_SHA='0a64c08f0e7845a4bf6aa5d5ce43bcb80167a847101b36f903d10554e53a290c'
VERIFY_SHA='08d913b7e9adc174e66e2225fe0a05e732cd6fa6fbacb794f39b23f61c6e2aef'
RADIUS=F(1,32)

def verify():
    root=Path(__file__).resolve().parent
    cp=root/'weak_outer_deep_boundary_angle_certificate.json'
    vp=root/'weak_outer_deep_boundary_verify.py'
    assert Path(deep.__file__).resolve()==vp
    assert hashlib.sha256(cp.read_bytes()).hexdigest()==CERT_SHA
    assert hashlib.sha256(vp.read_bytes()).hexdigest()==VERIFY_SHA
    certificate=json.loads(cp.read_text())
    prior=deep.verify(certificate)
    assert prior['cases']==8 and prior['signed_angle_identities']==144
    checked=[];maximum=F(0);count=0
    for case in certificate['cases']:
        sign_c,sign_d,direction=case['sign_C'],case['sign_D'],case['separator']
        if sign_d!=1 and direction!='horizontal':continue
        rows=deep.physical_rows(sign_c,sign_d,direction)
        costs=[]
        for proof in case['proofs']:
            cost=sum(F(weight)*rows[index][2] for index,weight in proof['weights'])
            assert cost==F(proof['error_weight'])
            assert RADIUS*cost<1
            costs.append(cost);count+=1
        current=max(costs)
        assert current==F(154357,4968)
        maximum=max(maximum,current)
        checked.append({'sign_C':sign_c,'sign_D':sign_d,'CD_direction':direction,
                        'identities':len(costs),'maximum_error_weight':str(current)})
    assert len(checked)==6 and count==108
    assert sum(x['sign_D']==1 for x in checked)==4
    assert sum(x['CD_direction']=='horizontal' for x in checked)==4
    gap=1-RADIUS*maximum
    assert gap==F(4619,158976)>0 and RADIUS<=F(1,8)
    return {'status':'PASS','scope':'Original strict001 local deep-B cylinder; D nonnegative or physical CD separator shallow','radius':str(RADIUS),
            'boxed_original_centers':'A,B,C,D,E,G,H,I; F center remains free',
            'original_angles':'all9','cases':checked,'distinct_case_count':len(checked),
            'signed_angle_identities':count,'maximum_error_weight':str(maximum),
            'contraction_gap':str(gap),'whole_mask_closed':False,
            'prior_full_table_replay':'PASS144 identities/all8 cases',
            'certificate_sha256':CERT_SHA,'prior_verifier_sha256':VERIFY_SHA}

if __name__=='__main__':
    result=verify();Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
