"""Independently validate complete substitutions of immutable v13 frontier cells.

Tree coverage/ancestor inclusion use the separate reviewer implementation.
Arithmetic is independently EXECUTED with the delivered exact v14 verifier;
this is not a second implementation of its arithmetic formulas.
"""
import argparse, hashlib, importlib, json, sys
from collections import Counter
from pathlib import Path
from review_v13_partition import decode, expected, key, EXPECTED_FORESTS

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def path_key(path):return json.dumps(path,separators=(',',':'))
def union(prefix,leaves):
    trie={}
    for leaf in leaves:
        path=leaf['path'];assert path[:len(prefix)]==prefix
        decode(path);node=trie
        for step in path[len(prefix):]:
            assert 'leaf'not in node
            query=(step[0],key(step[1]))
            if 'query'in node:assert node['query']==query
            else:node['query']=query;node['children']={}
            node=node['children'].setdefault(key(step[2]),{})
        assert not node;node['leaf']=True
    count=Counter()
    def visit(node):
        count['nodes']+=1
        if 'leaf'in node:assert len(node)==1;count['leaves']+=1;return
        action,index=node['query'];assert set(node['children'])==expected(action,index)
        count['internal_nodes']+=1
        for child in node['children'].values():visit(child)
    visit(trie);return dict(count)

def run(args):
    base=args.base.resolve();sys.path.insert(0,str(base))
    V=importlib.import_module('weak_outer_numeric_strict_bulk_v14_verify')
    assert Path(V.__file__).resolve()==base/'weak_outer_numeric_strict_bulk_v14_verify.py'
    sources={p.name:digest(p) for p in base.glob('weak_outer_numeric_strict_bulk_v*_verify.py')}
    baseline={};forests={}
    for sign,side in [('negative',0),('positive',1)]:
        p=base/f'{sign}_forest.json';assert digest(p)==EXPECTED_FORESTS[p.name]
        data=json.loads(p.read_text());assert data['root_side']==side;forests[sign]=data
        for index,cell in enumerate(data['frontier']):
            k=path_key(cell['path']);assert k not in baseline
            baseline[k]=(sign,index,cell)
    records=[];seen=set();substitutions={};least=None;terminals=Counter();leaf_count=0
    input_hashes={}
    supplied_inputs=[(args.direct,'direct'),(args.bounded,'bounded')]+[(p,'bounded') for p in args.additional_bounded]
    resolved_inputs={}
    for filename,mode in supplied_inputs:
        path=filename if filename.is_absolute() else base/filename
        assert path.name not in resolved_inputs
        resolved_inputs[path.name]=path
        input_hashes[path.name]=digest(path)
        for record in json.loads(path.read_text()):
            leaves=[record['leaf']] if mode=='direct' else record['leaves']
            prefix=leaves[0]['path'] if mode=='direct' else record['path']
            k=path_key(prefix);assert k in baseline and k not in seen;seen.add(k)
            sign,index,original=baseline[k]
            ident=sign+'-'+hashlib.sha256(k.encode()).hexdigest()[:16]
            assert record['id']==ident
            if mode=='bounded':assert record['status']=='CLOSED_BY_EXACT_MODEL' and record['unproved_internal_frontier']==0
            coverage=union(prefix,leaves)
            for leaf in leaves:
                assert leaf['context_version']=='strict_bulk_2026_11_03_v14'
                assert decode(leaf['path'])==V.reconstruct(leaf['path'])
                reserve,terminal=V.replay_leaf(leaf);leaf_count+=1
                if terminal:terminals[terminal]+=1
                else:
                    assert reserve>0
                    least=reserve if least is None else min(least,reserve)
            substitutions[k]=leaves
            records.append({'id':ident,'sign':sign,'baseline_index':index,'mode':mode,'coverage':coverage,'status':'PASS_COMPLETE_ORIGINAL_CELL'})
    full=[]
    for sign,side in [('negative',0),('positive',1)]:
        original=forests[sign];new={'leaves':list(original['leaves']),'frontier':[]}
        for cell in original['frontier']:
            k=path_key(cell['path'])
            if k in substitutions:new['leaves'].extend(substitutions[k])
            else:new['frontier'].append(cell)
        # Separately validate the full delivered verifier's merged-root interpretation.
        partition=V.verify_partition(new,side)
        full.append({'sign':sign,'partition':partition})
    for filename,sha in input_hashes.items():
        assert digest(resolved_inputs[filename])==sha
    assert all(digest(base/name)==sha for name,sha in sources.items())
    return {'status':'PASS','scope':'COMPLETE_FIXED_CELL_SUBSTITUTION_AND_FRESH_EXACT_REPLAY',
            'baseline_cells':231,'closed_cells':len(seen),'remaining_cells':231-len(seen),
            'new_exact_leaves':leaf_count,'minimum_rational_reserve':str(least),
            'direct_terminals':dict(terminals),'substituted_roots':full,'input_sha256':input_hashes,
            'verifier_sha256':sources,'cells':records,'whole_mask_closed':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--direct',type=Path,default=Path('frontier_whole_cell_closed.json'))
    parser.add_argument('--bounded',type=Path,default=Path('frontier_bounded_cell_closed.json'))
    parser.add_argument('--additional-bounded',type=Path,nargs='*',default=[],
                        help='Additional complete original-cell substitution files, checked for duplicate parents.')
    parser.add_argument('--report',type=Path)
    args=parser.parse_args();report=run(args)
    if args.report:args.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k in ('status','scope','baseline_cells','closed_cells','remaining_cells','new_exact_leaves','minimum_rational_reserve','substituted_roots','whole_mask_closed')},indent=2))
