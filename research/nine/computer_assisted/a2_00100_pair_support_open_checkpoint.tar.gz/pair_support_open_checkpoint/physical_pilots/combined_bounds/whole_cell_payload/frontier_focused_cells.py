#!/usr/bin/env python3
"""One larger bounded trial for six nearly exhausted original fixed cells."""
import concurrent.futures,json,time
from pathlib import Path
from frontier_bounded_cells import trial

def main():
    d=json.loads(Path('frontier_bounded_cell_report.json').read_text())
    candidates=[x for x in d['results'] if x['status']=='OPEN']
    candidates.sort(key=lambda x:(x['unproved_internal_frontier'],-x['new_leaves']))
    selected=candidates[:6];args={'nodes':128,'seconds':35,'depth':9};start=time.monotonic();results=[]
    Path('frontier_focused_selected.json').write_text(json.dumps({'args':args,'ids':[x['id'] for x in selected]},indent=2)+'\n')
    with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(trial,(row,args)) for row in selected]
        for future in concurrent.futures.as_completed(futures):
            row=future.result();results.append(row)
            report={'scope':'Entire fixed cells only; unfinished internal trees do not replace their parents.',
                    'whole_mask_closed':False,'limits':args,'seconds':time.monotonic()-start,'results':results,
                    'closed_cells':sum(x['status']=='CLOSED_BY_EXACT_MODEL' for x in results)}
            Path('frontier_focused_cell_report.json').write_text(json.dumps(report,indent=2)+'\n')
            Path('frontier_focused_cell_closed.json').write_text(json.dumps([x for x in results if x['status']=='CLOSED_BY_EXACT_MODEL'],indent=2)+'\n')
            print(row['id'],row['status'],'nodes',row['nodes'],'frontier',row['unproved_internal_frontier'],'seconds',round(row['seconds'],2),flush=True)

if __name__=='__main__':main()
