#!/usr/bin/env python3
"""Prove entire fixed v13 cells with bounded internal trees.

The original 231-cell register never changes. Unfinished trials are discovery
only. An entire cell is discharged only after exact replay of every child and
an exhaustive child-union check; physical dependency review remains separate.
"""
import argparse,concurrent.futures,hashlib,json,signal,time,traceback,warnings
from pathlib import Path

def children(query):
    kind,key=query
    if kind in ('angle','position','angle_cut','position_cut'):
        return [[kind,key,side] for side in (0,1)]
    if kind=='proxy':return [[kind,list(key),[axis,sign]] for axis in (0,1) for sign in (-1,1)]
    if kind=='sat':return [[kind,list(key),[owner,axis,sign]] for owner in key for axis in (0,1) for sign in (-1,1)]
    counts={'lower_escape':2,'row_escape':6,'asymmetric_escape':6,'positive_row_escape':6,'inward_row_escape':10}
    count=counts.get(kind,4 if kind.startswith('cap_') else 8)
    if kind.startswith('column_'):
        # The first 9*8*7=504 markers are triples, followed by the
        # 9*8*7*6=3024 quadruples. Keep exact coverage standard-library-only.
        assert len(key)==2 and key[0]==0 and type(key[1]) is int and 1<=key[1]<=3528
        count=7 if key[1]<=504 else 12
    return [[kind,list(key),[index]] for index in range(count)]

def verify_cell_union(prefix,leaves):
    root={}
    for item in leaves:
        path=item['path'];assert path[:len(prefix)]==prefix
        node=root
        for step in path[len(prefix):]:
            assert 'leaf' not in node
            query=step[:2]
            if 'query' in node:assert node['query']==query
            else:node['query']=query;node['children']={}
            key=json.dumps(step[2]);node=node['children'].setdefault(key,{})
        assert not node;node['leaf']=True
    def visit(node):
        if 'leaf' in node:assert len(node)==1;return
        assert set(node)=={'query','children'}
        expected={json.dumps(step[2]) for step in children(node['query'])}
        assert set(node['children'])==expected
        for child in node['children'].values():visit(child)
    visit(root)

def _trial_unbounded_worker(job):
    row,args=job
    import sparse_bulk_v14 as S
    import weak_outer_numeric_strict_bulk_v14_verify as V
    warnings.filterwarnings('ignore');S.M.linprog=S.branch.capture_lp
    start=time.monotonic();prefix=row['path'];pending=[prefix];leaves=[];frontier=[];failures=[];nodes=0
    while pending and nodes<args['nodes'] and time.monotonic()-start<args['seconds']:
        path=pending.pop();nodes+=1
        box,pos,ch=V.reconstruct(path)
        fl=lambda vv:tuple(tuple(float(t) for t in v) for v in vv)
        hit,point,data=S.solve(fl(box),fl(pos),ch)
        if hit is not None:
            leaf=json.loads(json.dumps({'path':path,**hit}))
            try:
                reserve,terminal=V.replay_leaf(leaf)
                leaves.append(leaf);continue
            except Exception:
                failures.append({'path':path,'candidate':leaf,'error':traceback.format_exc()})
                if point is None or data is None:frontier.append(path);continue
        if len(path)-len(prefix)>=args['depth']:
            frontier.append(path);continue
        query=S.branch.select(fl(box),fl(pos),ch,point,data)
        for child in reversed(children(query)):
            # Guard semantics are validated before a branch is admitted.
            new=path+[child];V.reconstruct(new);pending.append(new)
    frontier.extend(pending)
    closed=not frontier
    if closed:verify_cell_union(prefix,leaves)
    result={'id':row['id'],'sign':row['sign'],'index':row['index'],'path':prefix,
            'status':'CLOSED_BY_EXACT_MODEL' if closed else 'OPEN','nodes':nodes,
            'new_leaves':len(leaves),'unproved_internal_frontier':len(frontier),
            'seconds':time.monotonic()-start,'failures':failures}
    if closed:result['leaves']=leaves
    return result

def trial(job):
    row,args=job;start=time.monotonic()
    def expired(signum,frame):raise TimeoutError('bounded cell trial deadline')
    previous=signal.signal(signal.SIGALRM,expired)
    signal.setitimer(signal.ITIMER_REAL,args['seconds'])
    try:return _trial_unbounded_worker(job)
    except TimeoutError:
        # Every unfinished internal tree is discarded; the complete original
        # parent cell remains open. A timeout never supplies a contradiction.
        return {'id':row['id'],'sign':row['sign'],'index':row['index'],'path':row['path'],
                'status':'OPEN','nodes':0,'new_leaves':0,'unproved_internal_frontier':1,
                'seconds':time.monotonic()-start,'failures':[],'timed_out':True}
    finally:
        signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--nodes',type=int,default=24);ap.add_argument('--seconds',type=int,default=20);ap.add_argument('--depth',type=int,default=4);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--limit',type=int);ap.add_argument('--resume',action='store_true')
    args=ap.parse_args();source=json.loads(Path('frontier_whole_cell_report.json').read_text())
    jobs=[row for row in source['results'] if row['status']!='CLOSED_BY_EXACT_MODEL']
    # More constrained original cells are tried first, with immutable IDs.
    jobs.sort(key=lambda row:-len(row['path']))
    if args.limit is not None:jobs=jobs[:args.limit]
    start=time.monotonic();results=[];closed=[]
    if args.resume:
        results=json.loads(Path('frontier_bounded_cell_report.json').read_text())['results']
        closed=[row for row in results if row['status']=='CLOSED_BY_EXACT_MODEL']
        done={row['id'] for row in results};jobs=[row for row in jobs if row['id'] not in done]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(trial,(row,vars(args))) for row in jobs]
        for future in concurrent.futures.as_completed(futures):
            result=future.result();results.append(result)
            if result['status']=='CLOSED_BY_EXACT_MODEL':closed.append(result)
            progress={'model_level_only':True,'whole_mask_closed':False,'original_cells':231,
                      'direct_closed':source['closed'],'bounded_cells_attempted':len(results),
                      'bounded_cells_closed':len(closed),'total_cells_open':231-source['closed']-len(closed),
                      'limits':vars(args),'seconds':time.monotonic()-start,'results':results}
            Path('frontier_bounded_cell_report.json').write_text(json.dumps(progress,indent=2)+'\n')
            Path('frontier_bounded_cell_closed.json').write_text(json.dumps(closed,indent=2)+'\n')
            print('cells',len(results),'closed',len(closed),'last',result['id'],result['status'],'nodes',result['nodes'],'sec',round(time.monotonic()-start,1),flush=True)
    print('DONE',len(results),len(closed),flush=True)

if __name__=='__main__':main()
