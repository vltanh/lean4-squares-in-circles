#!/usr/bin/env python3
"""Exhaustive analytic placement gates, followed by original physical gates.

Only discovery ordering lives here. The six row-escape children and two
right/lower escape children are proved necessary unions for the original
strict caller. All shared faces remain in both applicable closed children.
"""
import numpy as np
from fractions import Fraction
import weak_outer_numeric_strict_bulk_v14_lp as pose

base=pose.base
original_select=base.select
_linprog=pose.linprog
_last=None

def capture_lp(*args,**kwargs):
    global _last
    result=_linprog(*args,**kwargs)
    _last=result.x[:-1] if result.success else None
    return result

def frozen_select(box,pos,choices,point,data):
    if box[3][0]<0<box[3][1]:return ('angle',3)
    if box[0][0]<0<box[0][1]:return ('angle_cut',(0,'0'))
    if pos[11][0]<.5<pos[11][1]:return ('position_cut',(11,'1/2'))
    selected={(p,kind) for p,kind,value in choices}
    if box[0][1]<=0 and box[3][0]>=0 and ((7,8),'inward_row_escape') not in selected:
        return ('inward_row_escape',(7,8))
    for row_kind in pose.CORRELATED_KINDS:
        eta,variation=pose.correlated_parameters(row_kind,1.)
        if pose.small_row_guard(box,eta) and ((7,8),row_kind) not in selected:return(row_kind,(7,8))
    if pose.small_row_guard(box,1/50) and ((7,8),'small_row_escape') not in selected:
        return ('small_row_escape',(7,8))
    if _last is not None:
        current_variation=sum(abs(_last[2*j+1]-_last[2*i+1]) for i,j in ((0,7),(7,8),(8,3)))
        for row_kind in pose.CORRELATED_KINDS:
            eta,variation=pose.correlated_parameters(row_kind,1.)
            if current_variation<variation-1e-6 and all(abs(_last[27+i]/max(_last[18+i],1e-12))<eta-1e-6 for i in pose.SMALL_ROW_ORIGINALS):
                for i in pose.SMALL_ROW_ORIGINALS:
                    for threshold in (-eta,eta):
                        if box[i][0]<threshold<box[i][1]:return ('angle_cut',(i,str(Fraction(threshold).limit_denominator(150))))
        near_row=sum(abs(_last[2*j+1]-_last[2*i+1]) for i,j in ((0,7),(7,8),(8,3)))<1/12-1e-6
        near_angles=all(abs(_last[27+i]/max(_last[18+i],1e-12))<1/50-1e-6 for i in pose.SMALL_ROW_ORIGINALS)
        if near_row and near_angles:
            for i in pose.SMALL_ROW_ORIGINALS:
                for threshold in (-1/50,1/50):
                    if box[i][0]<threshold<box[i][1]:return ('angle_cut',(i,str(Fraction(threshold).limit_denominator(50))))
        from itertools import combinations
        useful_columns=[]
        for size in (3,4):
            for subset in combinations(range(9),size):
                for column_kind,axis in pose.COLUMN_KINDS.items():
                    chain=tuple(sorted(subset,key=lambda i:(_last[2*i+axis],i)))
                    marker=(0,pose.COLUMN_INDEX[chain])
                    if (marker,column_kind) in selected:continue
                    gaps=[_last[2*j+axis]-_last[2*i+axis] for i,j in zip(chain,chain[1:])]
                    span=sum(gaps);variation=sum(abs(_last[2*j+1-axis]-_last[2*i+1-axis]) for i,j in zip(chain,chain[1:]))
                    score=min(min(gaps),size-2+4/5-span,3/5-variation)
                    if score>1e-5:useful_columns.append((score,marker,column_kind))
        if useful_columns:
            _,marker,column_kind=max(useful_columns);return(column_kind,marker)
        useful_caps=[]
        for pair in base.PAIRS:
            for kind,(axis,sg) in pose.CAP_KINDS.items():
                if (pair,kind) in selected:continue
                i,j=pair;across=1-axis
                score=min(sg*_last[2*i+axis]-3/5,sg*_last[2*j+axis]-3/5,29/60-abs(_last[2*j+across]-_last[2*i+across]))
                if score>1e-5:useful_caps.append((score,pair,kind))
        if useful_caps:
            _,pair,kind=max(useful_caps);return(kind,pair)
        for original in (7,8):
            pair=(5,original)
            if (pair,'f_side_escape') in selected:continue
            yy=_last[2*original+1]
            left,right=(1,11) if _last[2*original]<=_last[10] else (11,7)
            if abs(yy-_last[left])+abs(_last[right]-yy)<3/5-1e-6:
                return ('f_side_escape',pair)
        done={pose.alternate_chain(pair) for pair,kind in selected if kind=='alternate_four_escape'}
        done|={pose.GENERAL_SELECTORS[pair[1]-1] for pair,kind in selected if kind=='general_alternate_escape'}
        useful=[]
        for index,chain in enumerate(pose.GENERAL_SELECTORS):
            if chain in done:continue
            marker=(0,index+1);rows=pose.general_alternate_specs(marker,.5)
            score=min(sum(v*_last[k] for k,v in row)-rhs for row,rhs in rows)
            if score>1e-5:useful.append((score,marker))
        if useful:return ('general_alternate_escape',max(useful)[1])
    # These finite, original-label disjunctions are mandatory gates of the
    # new caller. Their coverage does not depend on an optimizer's point.
    for original in (7,8):
        pair=(2,original)
        if (pair,'lower_escape') not in selected:return ('lower_escape',pair)
    chosen={(p,kind):value for p,kind,value in choices}
    for original in (7,8):
        pair=(1,original)
        old=chosen.get((pair,'row_escape'))
        if pose.ASYMMETRIC_ENABLED:
            # Existing horizontal escape rows already imply a component of
            # each enlarged escape union; no duplicate split is necessary.
            if old is not None and old[0] in (0,1):continue
            if box[3][0]>=0:
                if (pair,'positive_row_escape') not in selected:return ('positive_row_escape',pair)
                continue
            if (pair,'asymmetric_escape') not in selected:return ('asymmetric_escape',pair)
            new=chosen[(pair,'asymmetric_escape')][0]
            if new in (0,1,3):continue
        if (pair,'row_escape') not in selected:return ('row_escape',pair)
    if pose.LOCAL_ENABLED and _last is not None:
        large=box[3][0]>=0 or any(pair==(2,3) and kind=='sat' and val[1]==0 for pair,kind,val in choices)
        eta=1/32 if large else pose.LOCAL_ETA
        near_angles=all(abs(_last[27+i])<=eta for i in range(9))
        near_centers=all(abs(_last[k]-pose.LOCAL_CENTERS[k])<=eta for k in pose.LOCAL_COORDS)
        intersects=all(l<=eta and u>=-eta for l,u in box) and all(pos[k][0]<=pose.LOCAL_CENTERS[k]+eta and pos[k][1]>=pose.LOCAL_CENTERS[k]-eta for k in pose.LOCAL_COORDS)
        if near_angles and near_centers and intersects:
            # These rational cuts enter the independently proved closed
            # cylinder. Each split retains both closed children, while the
            # inner child is visited first. F's center is deliberately free.
            for k,(l,u) in enumerate(box):
                for m in (-eta,eta):
                    if l<m<u:return ('angle_cut',(k,str(Fraction(m))))
            for k in pose.LOCAL_COORDS:
                l,u=pos[k];c=pose.LOCAL_CENTERS[k]
                for m in (c-eta,c+eta):
                    if l<m<u:return ('position_cut',(k,str(Fraction(m))))
    if _last is not None and len(_last)>=54:
        defects=[max(0.,_last[36+i]-abs(_last[27+i]))
                 if box[i][0]<0<box[i][1] else 0. for i in range(9)]
        k=int(np.argmax(defects))
        if defects[k]>.03:return ('angle',k)
        deficits=[max(0.,1-_last[18+i]**2-_last[27+i]**2)
                  if box[i][1]-box[i][0]>.25 else 0. for i in range(9)]
        k=int(np.argmax(deficits))
        if deficits[k]>.06:return ('angle',k)
    # CG is already an actual vertical pair, so its SAT disjunction is not
    # needed unless the general selector later encounters a relaxation gap.
    for pair in ((2,3),(3,6)):
        if (pair,'sat') not in selected:return ('sat',pair)
    proposed=original_select(box,pos,choices,point,data)
    if proposed[0] in ('proxy','sat'):return proposed
    if point is not None:
        centers=point.reshape(9,2)
        slopes=np.array([(lo+hi)/2 for lo,hi in box])
        alpha=1/np.sqrt(1+slopes*slopes);beta=slopes*alpha
        uu=np.stack((alpha,beta),axis=1);vv=np.stack((-beta,alpha),axis=1)
        # Retain the original selector's response to a physical-pair
        # violation before refining a support-polygon corner pocket.
        for i,j in base.PAIRS:
            difference=centers[j]-centers[i]
            normals=np.array([uu[i],vv[i],uu[j],vv[j]])
            required=.5*(1+abs(uu[i]@uu[j])+abs(vv[i]@uu[j]))
            if required-max(abs(normals@difference))>1e-6:return proposed
        violations=[max(np.sum((centers[i]+.5*(ss*uu[i]+tt*vv[i]))**2)-pose.Q
                        for ss in (-1,1) for tt in (-1,1)) for i in range(9)]
        i=int(np.argmax(violations))
        if violations[i]>1e-7:
            cb=data[3];indices=(2*i,2*i+1)
            coordinate=max(indices,key=lambda k:cb[k][1]-cb[k][0])
            # Shrink both sources of corner uncertainty. A fixed position
            # threshold would repeatedly split an already tiny angle while
            # leaving a nonvanishing center-box error.
            if cb[coordinate][1]-cb[coordinate][0]>.75*(box[i][1]-box[i][0]):return ('position',coordinate)
            return ('angle',i)
    return proposed


def normalized_select(box, pos, choices, point, data):
    proposed = frozen_select(box, pos, choices, point, data)
    if proposed[0] not in ('angle', 'position', 'proxy', 'sat'):
        return proposed
    if box[3][0] < 0 < box[3][1]:
        return proposed
    selected = {(pair, kind): value for pair, kind, value in choices}
    if any((pair, 'sat') not in selected for pair in ((2, 3), (3, 6))):
        return proposed
    current = _last
    if current is None or point is None:
        return proposed
    # Keep the frozen large absolute-value and circle-arc defect handling.
    if any(box[i][0] < 0 < box[i][1] and
           current[36+i]-abs(current[27+i]) > .03 for i in range(9)):
        return proposed
    if any(box[i][1]-box[i][0] > .25 and
           1-current[18+i]**2-current[27+i]**2 > .06 for i in range(9)):
        return proposed
    centers = np.asarray(point).reshape(9, 2)
    slopes = np.array([np.clip(current[27+i]/max(current[18+i], 1e-12),
                               *box[i]) for i in range(9)])
    alpha = 1/np.sqrt(1+slopes*slopes)
    beta = slopes*alpha
    uu = np.stack((alpha, beta), axis=1)
    vv = np.stack((-beta, alpha), axis=1)
    cb, gs = data[3], data[5]
    inset = []
    for pair in base.PAIRS:
        i, j = pair
        gap = gs[i]+gs[j]-max(abs(centers[j]-centers[i]))
        if (pair, 'proxy') not in selected and gap > 1e-7:
            inset.append((gap, pair))
    if inset:
        return ('proxy', max(inset)[1])
    physical = []
    for pair in base.PAIRS:
        i, j = pair
        difference = centers[j]-centers[i]
        normals = np.array([uu[i], vv[i], uu[j], vv[j]])
        required = .5*(1+abs(uu[i]@uu[j])+abs(vv[i]@uu[j]))
        gap = required-max(abs(normals@difference))
        if gap > 1e-6:
            physical.append((gap, pair))
    if physical:
        _, pair = max(physical)
        i, j = pair
        angle = max(pair, key=lambda k: box[k][1]-box[k][0])
        if (pair, 'sat') not in selected:
            return ('angle', angle) if box[angle][1]-box[angle][0] > .5 else ('sat', pair)
        coordinate = max((2*i, 2*i+1, 2*j, 2*j+1),
                         key=lambda k: cb[k][1]-cb[k][0])
        if cb[coordinate][1]-cb[coordinate][0] > .75*(box[angle][1]-box[angle][0]):
            return ('position', coordinate)
        return ('angle', angle)
    defects = [max(np.sum((centers[i]+.5*(s*uu[i]+t*vv[i]))**2)-pose.Q
                   for s in (-1, 1) for t in (-1, 1)) for i in range(9)]
    i = int(np.argmax(defects))
    if defects[i] > 1e-7:
        coordinate = max((2*i, 2*i+1), key=lambda k: cb[k][1]-cb[k][0])
        if cb[coordinate][1]-cb[coordinate][0] > .75*(box[i][1]-box[i][0]):
            return ('position', coordinate)
        return ('angle', i)
    return proposed


def select(box,pos,choices,point,data):
    if box[3][0]<0<box[3][1]:return ('angle',3)
    if box[0][0]<0<box[0][1]:return ('angle_cut',(0,'0'))
    # Fix large folded-frame graph defects before multiplying geometric
    # escape branches around a fictitious frame. This changes ordering only.
    if _last is not None and len(_last)>=54:
        defects=[max(0.,_last[36+i]-abs(_last[27+i])) if box[i][0]<0<box[i][1] else 0. for i in range(9)]
        k=int(np.argmax(defects))
        if defects[k]>.03:return ('angle_cut',(k,'0'))
        deficits=[max(0.,1-_last[18+i]**2-_last[27+i]**2) if box[i][1]-box[i][0]>.25 else 0. for i in range(9)]
        k=int(np.argmax(deficits))
        if deficits[k]>.06:return ('angle',k)
    proposed=normalized_select(box,pos,choices,point,data)
    if proposed[0] not in ('angle','position','proxy','sat'):return proposed
    selected={(pair,kind) for pair,kind,value in choices}
    if any((pair,'sat') not in selected for pair in ((2,3),(3,6))):return proposed
    if _last is None or len(_last)<54:return proposed
    scores=[]
    for i,(lo,hi) in enumerate(box):
        if not lo<0<hi:continue
        aa=_last[18+i];bb=_last[27+i];ab=_last[36+i]
        score=max(ab-abs(bb),1-aa*aa-bb*bb)
        if score>1e-7:scores.append((score,i))
    if scores:return ('angle_cut',(max(scores)[1],'0'))
    return proposed

if __name__=='__main__':
    pose.linprog=capture_lp
    base.matrix=pose.matrix;base.solve=pose.solve;base.select=select
    base.main()
