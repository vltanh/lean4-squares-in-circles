#!/usr/bin/env python3
"""Independent arithmetic for printed weighted rational combinations only.

Uses no producer and no bulk verifier. It does not by itself establish each
printed row's physical hypothesis or analytic/interval terminals.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json

def check(data):
    count=0;rows=0;least=None
    for rec in data['records']:
        if rec['terminal'] is not None:continue
        assert rec['denominator_power']==40
        bounds=list(map(F,rec['absolute_variable_bounds']));rr=[F(0)]*len(bounds);bb=F(0);seen=set()
        for row in rec['weighted_rows']:
            assert row['index'] not in seen;seen.add(row['index'])
            w=row['weight'];assert type(w) is int and w>0
            bb+=w*F(row['rhs'])
            for k,c in row['coefficients']:
                assert type(k) is int and 0<=k<len(rr);rr[k]+=w*F(c)
            rows+=1
        assert rr==list(map(F,rec['coefficient_sum']))
        assert bb==F(rec['rhs_sum'])
        reserve=(-bb-sum(b*abs(c) for b,c in zip(bounds,rr)))/(1<<40)
        assert reserve==F(rec['positive_reserve'])>0
        least=reserve if least is None else min(least,reserve);count+=1
    return {'status':'PASS','scope':'Printed rational-combination arithmetic only; physical source review and branch coverage are separate.',
            'weighted_leaves':count,'explicit_rows':rows,'least_positive_reserve':str(least),'whole_mask_closed':False}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('table',type=Path);ap.add_argument('--report',type=Path);args=ap.parse_args()
    result=check(json.loads(args.table.read_text()));result['table_sha256']=hashlib.sha256(args.table.read_bytes()).hexdigest()
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
