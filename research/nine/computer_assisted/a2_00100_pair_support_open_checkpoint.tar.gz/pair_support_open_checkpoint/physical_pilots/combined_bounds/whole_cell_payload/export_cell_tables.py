#!/usr/bin/env python3
"""Print every rational row actually used by new accepted whole-cell proofs."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys
import weak_outer_numeric_strict_bulk_v14_verify as V

def printable(value):
    if isinstance(value,F):return str(value)
    if isinstance(value,(list,tuple)):return [printable(x) for x in value]
    if isinstance(value,dict):return {str(k):printable(v) for k,v in value.items()}
    return value

def export_leaf(cell_id,leaf_index,leaf):
    rows=[];final={};derivations=[]
    def trace(frame,event,arg):
        if frame.f_code.co_filename!=V.__file__:return
        name=frame.f_code.co_name;local=frame.f_locals
        if event=='call' and name=='add' and local['index'] in local['weights']:
            merged={}
            for k,c in local['entries']:merged[k]=merged.get(k,F(0))+F(c)
            rows.append({'index':local['index'],'weight':local['weights'][local['index']],
                         'name':local['name'],'coefficients':[[k,str(c)] for k,c in sorted(merged.items()) if c],
                         'rhs':str(local['rhs'])})
        if event=='return' and name=='replay_current_leaf' and arg is not None and arg[0] is not None:
            # The frozen verifier reconstructs two large sparse row families
            # directly, without calling add(). Export their used rows too.
            for stem,directions,rhs,label in [
                ('dense',V.DENSE_DIRS,V.roots(V.Q)[1],'dense_original_corner'),
                ('contact',V.CONTACT_DIRS,F(1105,16),'exact_contact_corner')]:
                start=local[stem+'_start'];stop=local[stem+'_stop']
                for index,weight in local['weights'].items():
                    if not start<=index<stop:continue
                    i,rest=divmod(index-start,len(directions)*4);direction,corner=divmod(rest,4)
                    ss,tt=divmod(corner,2);s=-1 if ss==0 else 1;t=-1 if tt==0 else 1
                    p,q=map(F,directions[direction])
                    coefficients=[(2*i,p),(2*i+1,q),(V.AL(i),(s*p+t*q)/2),(V.BE(i),(s*q-t*p)/2)]
                    rows.append({'index':index,'weight':weight,'name':label,
                                 'coefficients':[[k,str(c)] for k,c in coefficients if c],
                                 'rhs':str(rhs),'corner':[i,s,t],'normal':[str(p),str(q)]})
            final.update({'coefficient_sum':[str(x) for x in local['rr']],
                          'rhs_sum':str(local['bb']),'absolute_variable_bounds':[str(x) for x in local['bounds']],
                          'positive_reserve':str(arg[0])})
        if event=='return' and name=='center_bounds' and arg is not None and arg[3] is not None:
            derivations.append({'rule':'center_bounds','terminal':arg[3],
                                'X':printable(local.get('X')),'Y':printable(local.get('Y')),
                                'halfwidths':printable(local.get('hs')),'insets':printable(local.get('gs'))})
    sys.setprofile(trace)
    try:reserve,terminal=V.replay_leaf(leaf)
    finally:sys.setprofile(None)
    rows.sort(key=lambda row:row['index'])
    out={'cell_id':cell_id,'leaf_index':leaf_index,'path':leaf['path'],
         'context_version':leaf['context_version'],'terminal':terminal,
         'weighted_rows':rows,'denominator_power':40,**final}
    if derivations:out['interval_terminal_data']=derivations
    if reserve is not None:
        rr=[F(0)]*len(out['coefficient_sum']);bb=F(0)
        for row in rows:
            w=row['weight'];assert isinstance(w,int) and w>0
            bb+=w*F(row['rhs'])
            for k,c in row['coefficients']:rr[k]+=w*F(c)
        if rr!=list(map(F,out['coefficient_sum'])) or bb!=F(out['rhs_sum']):
            Path('table_export_diagnostic.json').write_text(json.dumps({'record':out,'recomputed_residual':[str(x) for x in rr],'recomputed_rhs':str(bb)},indent=2)+'\n')
            raise AssertionError('Printed row sum mismatch: '+cell_id)
        margin=(-bb-sum(F(b)*abs(c) for b,c in zip(out['absolute_variable_bounds'],rr)))/(1<<40)
        assert margin==reserve>0
    return out

def main():
    records=[]
    direct=json.loads(Path('frontier_whole_cell_closed.json').read_text())
    bounded=json.loads(Path('frontier_bounded_cell_closed.json').read_text())
    focused=json.loads(Path('frontier_focused_cell_closed.json').read_text())
    seen={item['id'] for item in direct+bounded}
    assert all(item['id'] not in seen for item in focused)
    bounded+=focused
    for item in direct:records.append(export_leaf(item['id'],0,item['leaf']))
    for item in bounded:
        for i,leaf in enumerate(item['leaves']):records.append(export_leaf(item['id'],i,leaf))
    out={'scope':'Explicit rational rows for newly closed entire original frontier cells. Physical implications and inherited closed cells are separate dependencies.',
         'whole_mask_closed':False,'verifier_sha256':hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest(),
         'closed_original_cells':len(direct)+len(bounded),'new_terminal_leaves':len(records),'records':records}
    Path('whole_cell_rational_tables.json').write_text(json.dumps(out,indent=2)+'\n')
    print({'cells':out['closed_original_cells'],'leaves':len(records),
           'weighted_leaves':sum(r['terminal'] is None for r in records),
           'explicit_weighted_rows':sum(len(r['weighted_rows']) for r in records)})

if __name__=='__main__':main()
