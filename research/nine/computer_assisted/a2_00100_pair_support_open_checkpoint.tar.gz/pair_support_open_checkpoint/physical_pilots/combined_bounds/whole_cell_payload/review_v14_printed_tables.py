"""Independent exact sums and certificate identity for the printed new-cell tables.

This reviewer does not import the producer, bulk verifier or producer's table
checker. Physical validity of generic printed rows is the source-review
obligation; this script checks identity, nonnegative weights, the complete
weighted sum, universal residual bounds, and strictly positive reserve.
"""
import argparse, hashlib, json
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path
from review_v13_partition import decode

RHO=F(91,60)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args):
    base=args.base.resolve();acceptance=json.loads(args.acceptance.read_text())
    assert acceptance['status']=='PASS' and acceptance['closed_cells']==53
    supplied={};inputs={}
    for name in ('frontier_whole_cell_closed.json','frontier_bounded_cell_closed.json','frontier_focused_cell_closed.json'):
        path=base/name;inputs[name]=sha(path)
        assert inputs[name]==acceptance['input_sha256'][name]
        for cell in json.loads(path.read_text()):
            leaves=[cell['leaf']] if 'leaf' in cell else cell['leaves']
            for index,leaf in enumerate(leaves):
                key=(cell['id'],index);assert key not in supplied;supplied[key]=leaf
    table_path=base/'whole_cell_rational_tables.json';table_sha=sha(table_path)
    table=json.loads(table_path.read_text())
    assert table['verifier_sha256']==acceptance['verifier_sha256']['weak_outer_numeric_strict_bulk_v14_verify.py']
    assert table['closed_original_cells']==53 and table['new_terminal_leaves']==len(supplied)==210
    seen=set();terminals=Counter();least=None;weighted=rows=0
    for rec in table['records']:
        key=(rec['cell_id'],rec['leaf_index']);assert key in supplied and key not in seen;seen.add(key)
        leaf=supplied[key]
        assert rec['path']==leaf['path']
        assert rec['context_version']==leaf['context_version']=='strict_bulk_2026_11_03_v14'
        assert rec['denominator_power']==40
        if rec['terminal'] is not None:
            assert not rec['weighted_rows'];terminals[rec['terminal']]+=1;continue
        assert leaf['power']==40
        declared={int(i):int(w) for i,w in leaf['weights']}
        assert len(declared)==len(leaf['weights'])
        row_indices={row['index'] for row in rec['weighted_rows']}
        assert len(row_indices)==len(rec['weighted_rows']) and row_indices==set(declared)
        sat=sum(kind=='sat' for pair,kind,choice in decode(leaf['path'])[2])
        required_bounds=[RHO]*18+[F(1)]*36+[2*RHO,2*RHO,F(1),F(1),F(1),F(1)]*sat
        assert list(map(F,rec['absolute_variable_bounds']))==required_bounds
        combined=defaultdict(F);rhs=F(0)
        for row in rec['weighted_rows']:
            weight=row['weight'];assert type(weight)is int and weight>0 and weight==declared[row['index']]
            rhs+=weight*F(row['rhs'])
            for index,value in row['coefficients']:
                assert type(index)is int and 0<=index<len(required_bounds)
                combined[index]+=weight*F(value)
            if 'normal' in row:
                # Explicit original-corner support rows admit this additional
                # independent geometric check directly from the printed data.
                i,s,t=row['corner'];p,q=map(F,row['normal']);r=F(row['rhs'])
                assert type(i)is int and 0<=i<9 and s in (-1,1) and t in (-1,1)
                expected={2*i:p,2*i+1:q,18+i:(s*p+t*q)/2,27+i:(s*q-t*p)/2}
                expected={k:v for k,v in expected.items() if v}
                actual={k:F(v) for k,v in row['coefficients']}
                assert actual==expected and r>=0 and r*r>=F(1105,256)*(p*p+q*q)
            rows+=1
        residual=[combined[k] for k in range(len(required_bounds))]
        assert residual==list(map(F,rec['coefficient_sum'])) and rhs==F(rec['rhs_sum'])
        numerator=-rhs
        for coefficient,bound in zip(residual,required_bounds):numerator-=abs(coefficient)*bound
        reserve=numerator/F(2**40)
        assert reserve==F(rec['positive_reserve']) and reserve>0
        weighted+=1;least=reserve if least is None else min(least,reserve)
    assert seen==set(supplied)
    assert dict(terminals)==acceptance['direct_terminals']
    assert str(least)==acceptance['minimum_rational_reserve']
    assert sha(table_path)==table_sha and all(sha(base/name)==value for name,value in inputs.items())
    return {'status':'PASS','scope':'INDEPENDENT_PRINTED_SUMS_AND_CERTIFICATE_IDENTITY',
            'closed_original_cells':53,'leaves':len(seen),'weighted_leaves':weighted,
            'analytic_leaves':sum(terminals.values()),'explicit_weighted_rows':rows,
            'least_positive_reserve':str(least),'table_sha256':table_sha,'input_sha256':inputs,
            'acceptance_report_sha256':sha(args.acceptance),'whole_mask_closed':False}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--acceptance',type=Path,default=Path(__file__).resolve().parent/'v14_whole_cell_independent_replay.json')
    ap.add_argument('--report',type=Path)
    args=ap.parse_args();report=run(args)
    if args.report:args.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
