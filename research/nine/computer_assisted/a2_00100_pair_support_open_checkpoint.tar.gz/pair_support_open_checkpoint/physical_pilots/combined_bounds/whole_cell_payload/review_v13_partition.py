"""Independent combinatorial/path audit; does not replay numeric leaf arithmetic."""
from collections import Counter
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import argparse, hashlib, importlib, json, sys

RHO=F(91,60)
SELECTORS=tuple(c for c in permutations((0,1,2,3,7,8),4) if tuple(i for i in c if i<4)==tuple(sorted(i for i in c if i<4)))
assert len(SELECTORS)==len(set(SELECTORS))==105
COLUMN_CHAINS=tuple(permutations(range(9),3))+tuple(permutations(range(9),4))
assert len(COLUMN_CHAINS)==3528
SMALL=(0,3,4,5,6,7,8)
CAPS=('cap_y_pos_escape','cap_y_neg_escape','cap_x_pos_escape','cap_x_neg_escape')
EXPECTED_FORESTS={
    'negative_forest.json':'48a5ccee0ccb00c744f2f8beff65b7a36c1b15a0bea36cb68a6a1d2180ce0e81',
    'positive_forest.json':'f6518c23a00c32e1f3d3915d1cd89cd24d162f459a6fc03a721fb843cc878d78',
}
COUNTS={'row_escape':6,'lower_escape':2,'asymmetric_escape':6,'positive_row_escape':6,
        'inward_row_escape':10,'alternate_four_escape':8,'general_alternate_escape':8,
        'f_side_escape':8,'small_row_escape':8,'correlated_row30_escape':8,'correlated_row50_escape':8,**{k:4 for k in CAPS}}
ALT={(1,7),(1,8),(2,7),(2,8),(7,8)}

def key(value):return tuple(key(v) for v in value) if isinstance(value,list) else value
def decode(path):
    angles=[(F(-1),F(1)) for _ in range(9)];centers=[(-RHO,RHO) for _ in range(18)];seen=set();choices=[]
    for step in path:
        assert len(step)==3
        kind,index,branch=step
        if kind in ('angle','position','angle_cut','position_cut'):
            intervals=angles if kind.startswith('angle') else centers
            if kind.endswith('_cut'):
                assert len(index)==2 and type(index[1])is str
                coord,cut=index;cut=F(cut)
            else:coord=index;cut=None
            assert type(coord)is int and 0<=coord<len(intervals) and type(branch)is int and branch in (0,1)
            lo,hi=intervals[coord]
            if cut is None:cut=(lo+hi)/2
            else:assert lo<cut<hi
            intervals[coord]=(lo,cut) if branch==0 else (cut,hi)
            continue
        pair=tuple(index);branch=tuple(branch);assert len(pair)==2 and (kind,pair) not in seen
        seen.add((kind,pair));i,j=pair
        if kind=='general_alternate_escape':assert i==0 and type(j)is int and 1<=j<=105
        elif kind in ('column_x_escape','column_y_escape'):assert i==0 and type(j)is int and 1<=j<=3528
        else:assert 0<=i<j<9
        if kind=='proxy':assert branch in ((0,-1),(0,1),(1,-1),(1,1))
        elif kind=='sat':assert len(branch)==3 and branch[0]in pair and branch[1]in(0,1) and branch[2]in(-1,1)
        elif kind in ('column_x_escape','column_y_escape'):
            count=7 if len(COLUMN_CHAINS[j-1])==3 else 12
            assert len(branch)==1 and type(branch[0])is int and 0<=branch[0]<count
        else:
            assert kind in COUNTS and len(branch)==1 and type(branch[0])is int and 0<=branch[0]<COUNTS[kind]
            if kind=='inward_row_escape':assert pair==(7,8) and angles[0][1]<=0 and angles[3][0]>=0
            elif kind=='small_row_escape':assert pair==(7,8) and all(-F(1,50)<=angles[k][0]<=angles[k][1]<=F(1,50) for k in SMALL)
            elif kind in ('correlated_row30_escape','correlated_row50_escape'):
                eta=F(1,30) if kind=='correlated_row30_escape' else F(1,50)
                assert pair==(7,8) and all(-eta<=angles[k][0]<=angles[k][1]<=eta for k in SMALL)
            elif kind=='alternate_four_escape':assert pair in ALT
            elif kind=='f_side_escape':assert pair in ((5,7),(5,8))
            elif kind=='lower_escape':assert pair in ((2,7),(2,8))
            elif kind in ('row_escape','asymmetric_escape','positive_row_escape'):
                assert pair in ((1,7),(1,8))
                if kind=='positive_row_escape':assert angles[3][0]>=0
        choices.append((pair,kind,branch))
    return tuple(angles),tuple(centers),tuple(choices)

def expected(action,index):
    if action in ('angle','position','angle_cut','position_cut'):return {0,1}
    if action=='proxy':return {(0,-1),(0,1),(1,-1),(1,1)}
    if action=='sat':return {(owner,axis,sign) for owner in index for axis in (0,1) for sign in (-1,1)}
    if action in ('column_x_escape','column_y_escape'):
        assert index[0]==0 and 1<=index[1]<=3528
        return {(b,) for b in range(7 if len(COLUMN_CHAINS[index[1]-1])==3 else 12)}
    return {(b,)for b in range(COUNTS[action])}

def audit(path,side):
    assert hashlib.sha256(path.read_bytes()).hexdigest()==EXPECTED_FORESTS[path.name]
    data=json.loads(path.read_text());assert data['root_side']==side
    trie={};versions=Counter();steps=Counter();old_modules={};frontier=[]
    for status,items in [('closed',data['leaves']),('open',data['frontier'])]:
        for item in items:
            route=item['path'];assert route[0]==['angle',3,side]
            decoded=decode(route)
            if status=='closed':
                version=int(item['context_version'].rsplit('_v',1)[1]);assert version in (9,10,11,12,13)
                versions[version]+=1
                if version not in old_modules:
                    module=importlib.import_module(f'weak_outer_numeric_strict_bulk_v{version}_verify')
                    assert Path(module.__file__).resolve()==path.parent/f'weak_outer_numeric_strict_bulk_v{version}_verify.py'
                    old_modules[version]=module
                # A retained old leaf interprets the same rational path and selected original labels.
                assert decoded==old_modules[version].reconstruct(route)
            else:
                canonical=json.dumps(route,separators=(',',':'),sort_keys=True)
                frontier.append({'id':f'WO-{side}-{len(frontier):03d}','path_sha256':hashlib.sha256(canonical.encode()).hexdigest(),'path':route})
            node=trie
            for step in route[1:]:
                assert 'terminal' not in node
                query=(step[0],key(step[1]));branch=key(step[2])
                if 'query'in node:assert node['query']==query
                else:node['query']=query;node['children']={}
                node=node['children'].setdefault(branch,{})
            assert not node
            node['terminal']=status
    counts=Counter()
    def visit(node):
        counts['nodes']+=1
        if 'terminal'in node:assert len(node)==1;counts[node['terminal']]+=1;return
        action,index=node['query'];steps[action]+=1
        assert set(node['children'])==expected(action,index)
        for child in node['children'].values():visit(child)
    visit(trie)
    return {'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'root_side':side,'counts':dict(counts),'split_nodes':dict(steps),'leaf_versions':dict(versions),'frontier':frontier,'status':'PASS_STRUCTURAL_ONLY'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,default=Path(__file__).resolve().parent,
                        help='Directory containing both immutable forests and frozen v9-v13 interpreters (default: beside this script).')
    parser.add_argument('--report',type=Path,help='Optional complete JSON report, including each frontier path.')
    args=parser.parse_args();base=args.base.resolve()
    assert (base/'positive_forest.json').is_file() and (base/'negative_forest.json').is_file()
    sys.path.insert(0,str(base))
    records=[audit(base/name,side) for name,side in [('negative_forest.json',0),('positive_forest.json',1)]]
    result={'scope':'INDEPENDENT_BRANCH_AND_CLOSED_BOUNDARY_COVERAGE_NO_NUMERIC_LEAF_REPLAY','roots':records,'total_frontier':sum(r['counts']['open']for r in records),'whole_mask_closed':False,'proof_of_new_closed_leaf':False}
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS_STRUCTURAL_ONLY','total_frontier':result['total_frontier'],
                      'whole_mask_closed':False,'roots':[{k:v for k,v in r.items() if k in ('file','sha256','root_side','counts')} for r in records]},indent=2))
