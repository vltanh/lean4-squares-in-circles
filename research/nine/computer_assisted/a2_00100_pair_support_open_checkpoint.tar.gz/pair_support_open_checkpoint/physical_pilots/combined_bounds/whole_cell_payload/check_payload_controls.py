#!/usr/bin/env python3
"""Damaged input controls for exact cells, split coverage and printed tables."""
from pathlib import Path
import copy,json
import weak_outer_numeric_strict_bulk_v14_verify as V
from frontier_bounded_cells import verify_cell_union
from check_cell_tables import check as check_tables

def main():
    root=Path(__file__).resolve().parent;reports=[]
    def rejected(name,operation):
        try:operation()
        except (AssertionError,ValueError,KeyError,TypeError) as exc:
            reports.append({'control':name,'status':'REJECTED','exception':type(exc).__name__});return
        raise AssertionError('Damaged control accepted: '+name)
    data=json.loads((root/'final_positive.json').read_text())
    broken=copy.deepcopy(data);assert broken['frontier'];broken['frontier'].pop()
    rejected('missing full-root frontier child',lambda:V.verify_partition(broken,1))
    proofs=json.loads((root/'new_cell_proofs.json').read_text())['proofs']
    multi=next(p for p in proofs if len(p['leaves'])>1)
    reg=json.loads((root/'fixed_231_register.json').read_text())['cells']
    prefix=next(r['path'] for r in reg if r['id']==multi['id'])
    rejected('missing child in an allegedly closed original cell',lambda:verify_cell_union(prefix,multi['leaves'][:-1]))
    invalid=copy.deepcopy(multi['leaves']);invalid[0]['path'][0][2]=3
    rejected('invalid angle branch label',lambda:V.replay_leaf(invalid[0]))
    table=json.loads((root/'whole_cell_rational_tables.json').read_text())
    i=next(i for i,r in enumerate(table['records']) if r['terminal'] is None)
    bad=copy.deepcopy(table);bad['records'][i]['weighted_rows'][0]['weight']=0
    rejected('zero purported positive Farkas multiplier',lambda:check_tables(bad))
    bad=copy.deepcopy(table);bad['records'][i]['positive_reserve']='0'
    rejected('corrupted printed positive reserve',lambda:check_tables(bad))
    bad=copy.deepcopy(table);bad['records'][i]['weighted_rows'][0]['rhs']=str(int(bad['records'][i]['weighted_rows'][0]['weight'])+1)
    rejected('corrupted printed rational row',lambda:check_tables(bad))
    out={'status':'PASS','damaged_controls_rejected':len(reports),'controls':reports,
         'scope':'Specific parser, coverage and arithmetic controls; not a substitute for the surviving geometric proof.'}
    (root/'damaged_controls_report.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

if __name__=='__main__':main()
