#!/usr/bin/env python3
"""Independent partial replay of deterministic original-unit-frame supports.

No producer is imported and no v3 code is changed. For every rational unit
normal (p,q), Cauchy-Schwarz gives p*alpha+q*beta<=1 because the original
frame has alpha^2+beta^2=1. Replacing beta by |beta| preserves its squared
norm and gives the folded support. These are unconditional physical rows.
"""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

import review_octagon as previous

VERSION = 'disk_octagon_unit_frames_v4'


def unit_frame_rows():
    rows = []
    for original in range(9):
        for p, q in previous.V.DENSE_DIRS:
            assert p*p + q*q == 1
            rows.append((((18+original, p), (27+original, q)), F(1), 'exact_signed_original_unit_frame'))
        for p, q in previous.V.DENSE_DIRS:
            assert p*p + q*q == 1
            if q >= 0:
                rows.append((((18+original, p), (36+original, q)), F(1), 'exact_folded_original_unit_frame'))
    return rows


def verify_leaf(leaf, parent_path, parent_bounds):
    assert leaf['context_version'] == VERSION
    assert leaf['legacy_context_version'] == previous.LEGACY
    assert leaf['path'][:len(parent_path)] == parent_path
    legacy, additions = previous.split_decode(leaf['path'])
    assert legacy == leaf['legacy_physical_path']
    angles, positions, choices = previous.V.reconstruct(legacy)
    positions = tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(positions,parent_bounds))
    assert all(a <= b for a,b in positions)
    cuts = leaf.get('circle_cuts', [])
    analytic = {k:leaf[k] for k in ('analytic_terminal','row_guard','local_radius') if k in leaf}
    base, bounds, terminal = previous.collect_unchanged_rows(
        json.dumps(legacy), json.dumps([[str(a),str(b)] for a,b in positions]), json.dumps(cuts), json.dumps(analytic))
    if terminal is not None:
        return {'path':leaf['path'], 'terminal':terminal}
    extra = [row for step in additions for row in previous.new_rows(step)]
    extra.extend(row for x in previous.guarded_originals(leaf['path']) for row in previous.abxd_guard_rows(x))
    frame = unit_frame_rows()
    split = len(base)-len(cuts)
    assert split >= 0 and leaf['power'] == 40
    rows = base[:split] + extra + frame + base[split:]
    co, rhs = previous.weighted_sum(rows, bounds, leaf['weights'])
    reserve = -rhs-sum(M*abs(a) for M,a in zip(bounds,co))
    assert reserve > 0
    start = split+len(extra)
    frame_weights = [i for i,w in leaf['weights'] if start <= i < start+len(frame) and F(w) != 0]
    return {'path':leaf['path'], 'reserve':str(reserve), 'new_frame_rows':len(frame), 'used_new_frame_rows':len(frame_weights)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('report', type=Path)
    ap.add_argument('--prefix', required=True, type=Path)
    ap.add_argument('--limit', type=int, default=10)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    raw = args.report.read_bytes()
    report = json.loads(raw)
    prefix_bytes = args.prefix.read_bytes()
    assert hashlib.sha256(prefix_bytes).hexdigest() == report['prefix_sha256']
    register = json.loads((previous.HERE/'whole_cell_payload/fixed_231_register.json').read_text())
    original = next(r for r in register['cells'] if r['id'] == report['id'])
    assert original['path'] == report['path'] and original['status'] == 'OPEN'
    positions, deductions, _ = previous.verify_bound_prefix(json.loads(prefix_bytes), original)
    leaves = [r['leaf'] for r in report['results'] if r.get('status') == 'CANDIDATE_CLOSED'][:args.limit]
    checked = [verify_leaf(leaf, original['path'], positions) for leaf in leaves]
    result = {'status':'PASS_PARTIAL_LEAF_SAMPLE_ONLY', 'id':report['id'], 'whole_parent_closed':False,
              'whole_mask_closed':False, 'prefix_deductions':deductions, 'leaves_checked':len(checked),
              'remaining_original_frontier':report['remaining_open_count'], 'source_sha256':hashlib.sha256(raw).hexdigest(),
              'frame_rows_per_leaf':len(unit_frame_rows()), 'checked':checked}
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'checked'},indent=2))


if __name__ == '__main__':
    main()
