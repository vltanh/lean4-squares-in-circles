"""Exact acyclic prefix replay, allowing an unfinished original cell.

Rows are generated once per round and weighted sums are independently added.
No numerical before-box or current-position report is trusted.
"""
import sys,hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from review_tight_bounds_independent import collect_rows,weighted_sum,VERIFIER_SHA256

def replay_prefix(record,keep_table=False):
 assert hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest()==VERIFIER_SHA256
 path=record['path'];box,pos,choices=V.reconstruct(path)
 pos=[list(v) for v in pos];checked=0;table=[]
 for ri,rr in enumerate(record['rounds']):
  rows,bounds,terminal=collect_rows(V,path,box,tuple(map(tuple,pos)),choices)
  assert terminal is None,'prefix already contradictory'
  nextpos=[v[:] for v in pos];used=set();entries=[]
  for pi,proposal in enumerate(rr['proposals']):
   objective=proposal['objective'];assert type(objective)is list and len(objective)==1
   k,sg=objective[0];assert type(k)is int and 0<=k<18 and type(sg)is int and sg in(-1,1)
   upper=F(proposal['upper']);co,rhs=weighted_sum(rows,bounds,proposal['weights'])
   co[k]-=sg;proven=rhs+sum(m*abs(r) for m,r in zip(bounds,co))
   assert proven<=upper,('invalid derived bound',record['id'],ri,k,sg)
   if sg==1:nextpos[k][1]=min(nextpos[k][1],upper)
   else:nextpos[k][0]=max(nextpos[k][0],-upper)
   checked+=1
   if keep_table:
    entries.append({'coordinate':k,'sign':sg,'upper':str(upper),'proven_upper':str(proven),'weights':proposal['weights'],'residual':[str(c) for c in co],'rhs':str(rhs)})
    used.update(i for i,w in proposal['weights'])
  if keep_table:
   table.append({'round':ri,'positions_before':[[str(v) for v in pair] for pair in pos],'rows':[{'index':i,'name':rows[i][2],'coefficients':[[k,str(c)] for k,c in rows[i][0]],'rhs':str(rows[i][1])} for i in sorted(used)],'absolute_variable_bounds':list(map(str,bounds)),'deductions':entries,'positions_after':[[str(v) for v in pair] for pair in nextpos]})
  pos=nextpos;assert all(l<=u for l,u in pos),'prefix empty'
 if keep_table:return tuple(map(tuple,pos)),checked,table
 return tuple(map(tuple,pos)),checked
