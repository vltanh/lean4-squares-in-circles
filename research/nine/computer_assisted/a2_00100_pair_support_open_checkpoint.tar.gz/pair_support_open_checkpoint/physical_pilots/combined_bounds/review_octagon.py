#!/usr/bin/env python3
"""Independent exact checker for versioned disk and structural pair splits.

No producer import. Version1 adds rotated center-disk rows. Version2 adds
ordered complements and the reviewed unique-penultimate-original selector.
Version3 adds four exactly guarded ABXD consequences. Existing rows are
independently collected from the unchanged v14 physical verifier.
"""
import argparse,hashlib,json,sys,time
from functools import lru_cache
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from review_tight_bounds_independent import collect_rows,weighted_sum,printed_rows,VERIFIER_SHA256
from frontier_bounded_cells import children as legacy_children

VERSION='disk_octagon_v1'
ORDERED_VERSION='disk_octagon_structural_v2'
GUARDED_VERSION='disk_octagon_structural_v3'
LEGACY='strict_bulk_2026_11_03_v14'
NORMALS=((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
NEW_KINDS=('disk8','disk8_ordered','first_two_escape','first_two_reduced_escape')

def verify_octagon_geometry():
 # Independently enumerate every vertex of the eight closed halfplanes.
 from itertools import combinations
 constraints=[(F(a),F(b),F(12 if k<4 else 17,13)) for k,(a,b) in enumerate(NORMALS)]
 vertices=set()
 for (a,b,h),(c,d,k) in combinations(constraints,2):
  determinant=a*d-b*c
  if not determinant:continue
  x=(h*d-b*k)/determinant;y=(a*k-h*c)/determinant
  if all(p*x+q*y<=r for p,q,r in constraints):vertices.add((x,y))
 expected={(F(s*a,13),F(t*b,13)) for a,b in ((12,5),(5,12)) for s in (-1,1) for t in (-1,1)}
 assert vertices==expected and len(vertices)==8
 assert all(x*x+y*y==1 for x,y in vertices)
 # The closed polygon is the convex hull of these eight vertices. The
 # squared norm is strictly convex, so every nonvertex point of it has norm
 # strictly below1. A point satisfying all eight strict inequalities is
 # not a vertex. Thus |d|>=1 forces at least one of the8 closed escapes.
 return {'status':'PASS','vertices':[[str(x),str(y)] for x,y in sorted(vertices)],'vertex_squared_norms':['1']*8,'escape_children':8}

def split_decode(path):
 legacy=[];new=[]
 for step in path:
  assert type(step)is list and len(step)==3
  if step[0] not in NEW_KINDS:legacy.append(step);continue
  new_rows(step)  # Validates every exact geometric marker and closed child.
  new.append(step)
 return legacy,new

def octagon_row(decoded):
 i,j,num,den,choice=decoded
 t=F(num,den);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
 assert c*c+s*s==1
 a,b=NORMALS[choice];nx=a*c-b*s;ny=a*s+b*c
 threshold=F(12 if choice<4 else 17,13)
 coeff=((2*i,nx),(2*i+1,ny),(2*j,-nx),(2*j+1,-ny))
 return tuple((k,v) for k,v in coeff if v),-threshold,'exact_rotated_center_disk_octagon'

def first_two_rows(chain,reduced=False):
 assert type(chain)is list and len(chain)==4 and all(type(k)is int for k in chain)
 a,b,x,d=chain
 assert d==3 and x!=2 and len(set(chain))==4 and all(k in (0,1,2,7,8) for k in (a,b,x))
 rows=[]
 for i,j in zip(chain,chain[1:]):
  if reduced and 0<=i<j<=2:continue
  for sign in (-1,1):
   rows.append((((2*j,F(1)),(2*i,F(-1)),(2*j+1,F(sign)),(2*i+1,F(-sign))),F(0),'unique_penultimate_cone_escape'))
 for i,j in zip(chain[:2],chain[1:3]):
  if reduced and 0<=i<j<=2:continue
  rows.append((((2*j,F(1)),(2*i,F(-1)),(18+i,F(-1,2)),(36+i,F(-1,2)),(18+j,F(-1,2)),(36+j,F(-1,2))),F(0),'unique_penultimate_first_actual_escape'))
 assert len(rows) in ((5,8) if reduced else (8,))
 return rows

def new_rows(step):
 kind,query,choice=step
 assert kind in NEW_KINDS and type(query)is list and len(query)==4 and all(type(v)is int for v in query)
 assert type(choice)is list and len(choice)==1 and type(choice[0])is int and 0<=choice[0]<8
 k=choice[0]
 if kind in ('first_two_escape','first_two_reduced_escape'):base=first_two_rows(query,kind=='first_two_reduced_escape')
 else:
  i,j,num,den=query;assert 0<=i<j<9 and den>0
  base=[octagon_row((i,j,num,den,index)) for index in range(8)]
 assert k<len(base)
 result=[base[k]]
 if kind!='disk8':
  for coefficients,rhs,label in base[:k]:
   result.append((tuple((i,-c) for i,c in coefficients),-rhs,label+'_prior_closed_complement'))
 return result

def guarded_originals(path):
 answer=set()
 for kind,marker,choice in path:
  if kind=='alternate_four_escape' and marker in ([1,7],[1,8]) and choice[0] in (6,7):answer.add(marker[1])
  if kind=='first_two_escape' and marker in ([0,1,7,3],[0,1,8,3]) and choice[0] in (6,7):answer.add(marker[2])
  if kind=='first_two_reduced_escape' and marker in ([0,1,7,3],[0,1,8,3]) and choice[0]==4:answer.add(marker[2])
 return sorted(answer)

def abxd_guard_rows(x):
 assert x in (7,8)
 # B=1,C=2,D=3; every GI variable is the same original physical inset.
 return [
  (((2,F(1)),(2*x,F(-1)),(46,F(1)),(45+x,F(1))),F(0),'proved_BX_cone_inset'),
  (((2*x,F(1)),(6,F(-1)),(45+x,F(1)),(48,F(1))),F(0),'proved_XD_cone_inset'),
  (((2*x,F(1)),(2,F(-1)),(19,F(-1,2)),(37,F(-1,2)),(18+x,F(-1,2)),(36+x,F(-1,2))),F(0),'proved_BX_weak'),
  (((5,F(1)),(2*x+1,F(-1)),(47,F(1)),(45+x,F(1))),F(0),'proved_CX_vertical_inset')]

@lru_cache(maxsize=12)
def collect_unchanged_rows(legacy_json,position_json,cuts_json,analytic_json):
 legacy=json.loads(legacy_json);angles,_,choices=V.reconstruct(legacy)
 positions=tuple(tuple(F(x) for x in row) for row in json.loads(position_json))
 return collect_rows(V,legacy,angles,positions,choices,json.loads(cuts_json),json.loads(analytic_json))

def verify_leaf(leaf,parent_path,parent_bounds,keep_table=True):
 assert leaf['context_version'] in (VERSION,ORDERED_VERSION,GUARDED_VERSION)
 assert leaf['legacy_context_version']==LEGACY
 assert leaf['path'][:len(parent_path)]==parent_path
 legacy,additions=split_decode(leaf['path'])
 if leaf['context_version']==VERSION:assert all(step[0]=='disk8' for step in additions)
 assert legacy==leaf['legacy_physical_path'] and legacy[:len(parent_path)]==parent_path
 angles,positions,choices=V.reconstruct(legacy)
 positions=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(positions,parent_bounds))
 assert all(a<=b for a,b in positions)
 cuts=leaf.get('circle_cuts',[])
 analytic={k:leaf[k] for k in ('analytic_terminal','row_guard','local_radius') if k in leaf}
 base,bounds,terminal=collect_unchanged_rows(json.dumps(legacy),json.dumps([[str(a),str(b)] for a,b in positions]),json.dumps(cuts),json.dumps(analytic))
 table={'path':leaf['path'],'legacy_physical_path':legacy,'parent_positions':[[str(a),str(b)] for a,b in parent_bounds],'effective_positions':[[str(a),str(b)] for a,b in positions],'terminal':terminal}
 if terminal is not None:return None,terminal,table
 assert type(cuts)is list and len(base)>=len(cuts)
 # The producer adds octagon rows before its adaptive circle rows. The
 # independent old-row collector adds all circle rows at the end.
 split=len(base)-len(cuts)
 added=[row for step in additions for row in new_rows(step)]
 if leaf['context_version']==GUARDED_VERSION:
  added.extend(row for x in guarded_originals(leaf['path']) for row in abxd_guard_rows(x))
 rows=base[:split]+added+base[split:]
 assert leaf['power']==40
 coefficient_sum,rhs_sum=weighted_sum(rows,bounds,leaf['weights'])
 reserve=-rhs_sum-sum(M*abs(r) for M,r in zip(bounds,coefficient_sum));assert reserve>0
 if keep_table:
  table.update(rows=printed_rows(rows,{k for k,_ in leaf['weights']}),weights=leaf['weights'],coefficient_sum=list(map(str,coefficient_sum)),rhs_sum=str(rhs_sum),absolute_variable_bounds=list(map(str,bounds)),positive_reserve=str(reserve),base_row_count=split,augmented_row_count=len(added),circle_row_count=len(cuts))
 return reserve,None,table

def verify_complete_union(parent_path,leaves):
 root={}
 for leaf in leaves:
  path=leaf['path'];assert path[:len(parent_path)]==parent_path
  legacy,_=split_decode(path);V.reconstruct(legacy)
  node=root
  for step in path[len(parent_path):]:
   assert not node.get('terminal')
   query=step[:2]
   if 'query' in node:assert node['query']==query
   else:node['query']=query;node['children']={}
   key=json.dumps(step[2],separators=(',',':'));node=node['children'].setdefault(key,{})
  assert not node;node['terminal']=True
 def walk(node):
  if node.get('terminal'):assert set(node)=={'terminal'};return
  query=node['query']
  if query[0] in NEW_KINDS:
   count=len(first_two_rows(query[1],True)) if query[0]=='first_two_reduced_escape' else 8
   expected={json.dumps([k],separators=(',',':')) for k in range(count)}
  else:expected={json.dumps(child[2],separators=(',',':')) for child in legacy_children(query)}
  assert set(node['children'])==expected
  for child in node['children'].values():walk(child)
 walk(root)

def verify_bound_prefix(prefix,original):
 assert prefix['id']==original['id'] and prefix['path']==original['path']
 assert hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest()==VERIFIER_SHA256
 angles,positions,choices=V.reconstruct(original['path']);positions=tuple(map(tuple,positions));count=0;tables=[]
 for index,round_record in enumerate(prefix['rounds']):
  rows,bounds,terminal=collect_rows(V,original['path'],angles,positions,choices)
  assert terminal is None
  changed=[list(p) for p in positions];used=set();deductions=[]
  for proposal in round_record['proposals']:
   assert type(proposal['objective'])is list and len(proposal['objective'])==1
   k,sign=proposal['objective'][0];assert type(k)is int and 0<=k<18 and type(sign)is int and sign in (-1,1)
   upper=F(proposal['upper']);co,rhs=weighted_sum(rows,bounds,proposal['weights']);co[k]-=sign
   proved=rhs+sum(M*abs(r) for M,r in zip(bounds,co));assert proved<=upper
   if sign==1:changed[k][1]=min(changed[k][1],upper)
   else:changed[k][0]=max(changed[k][0],-upper)
   count+=1;used.update(i for i,_ in proposal['weights'])
   deductions.append({'coordinate':k,'sign':sign,'upper':str(upper),'proved_upper':str(proved),'weights':proposal['weights'],'residual':list(map(str,co)),'rhs':str(rhs)})
  tables.append({'round':index,'positions_before':[[str(a),str(b)] for a,b in positions],'rows':printed_rows(rows,used),'absolute_variable_bounds':list(map(str,bounds)),'deductions':deductions,'positions_after':[[str(a),str(b)] for a,b in changed]})
  positions=tuple(map(tuple,changed));assert all(a<=b for a,b in positions)
 return positions,count,tables

def review_parent(report,prefix_bytes,registry,max_leaves=None):
 original=registry[report['id']];assert original['status']=='OPEN'
 assert report['path']==original['path']
 expected=original['sign']+'-'+hashlib.sha256(json.dumps(original['path'],separators=(',',':')).encode()).hexdigest()[:16]
 assert report['id']==expected
 assert report['prefix_sha256']==hashlib.sha256(prefix_bytes).hexdigest()
 prefix=json.loads(prefix_bytes);positions,count,prefix_tables=verify_bound_prefix(prefix,original)
 assert report['verified_bound_deductions']==count
 assert positions==tuple(tuple(F(x) for x in pair) for pair in report['proved_parent_positions'])
 leaves=report['leaves'] if max_leaves is None else report['leaves'][:max_leaves]
 tables=[];least=None;weighted=0
 for i,leaf in enumerate(leaves):
  reserve,terminal,table=verify_leaf(leaf,original['path'],positions)
  if reserve is not None:
   weighted+=1;least=reserve if least is None else min(least,reserve)
  table['leaf_index']=i;tables.append(table)
 complete=report['status']=='CLOSED' and max_leaves is None
 if complete:
  assert not report['frontier'];verify_complete_union(original['path'],leaves)
 return {'id':report['id'],'status':'PASS_COMPLETE_ORIGINAL_PARENT' if complete else 'PASS_PARTIAL_LEAVES_ONLY','whole_parent_closed':complete,'bound_deductions':count,'leaves_checked':len(leaves),'weighted_leaves':weighted,'least_positive_reserve':str(least),'geometry':verify_octagon_geometry(),'whole_mask_closed':False}, {'id':report['id'],'parent_path':original['path'],'prefix_tables':prefix_tables,'leaf_tables':tables}

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('report',nargs='?');ap.add_argument('--prefix');ap.add_argument('--out');ap.add_argument('--max-leaves',type=int);args=ap.parse_args()
 if not args.report:print(json.dumps(verify_octagon_geometry(),indent=2))
 else:
  start=time.monotonic();raw=Path(args.report).read_bytes();report=json.loads(raw)
  prefix_bytes=Path(args.prefix or report['source_prefix']).read_bytes()
  registry={r['id']:r for r in json.loads((HERE/'whole_cell_payload/fixed_231_register.json').read_text())['cells']}
  result,tables=review_parent(report,prefix_bytes,registry,args.max_leaves);result['source_report_sha256']=hashlib.sha256(raw).hexdigest();result['seconds']=time.monotonic()-start
  if args.out:
   dest=Path(args.out);dest.write_text(json.dumps(result,indent=2)+'\n');dest.with_suffix('.tables.json').write_text(json.dumps(tables,indent=2)+'\n')
  print(json.dumps(result,indent=2))
