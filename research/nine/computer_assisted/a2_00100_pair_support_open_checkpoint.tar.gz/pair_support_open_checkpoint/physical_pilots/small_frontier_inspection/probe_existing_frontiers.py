#!/usr/bin/env python3
"""Solve each of23 existing frontier domains once; never add a branch."""
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys
import time

import scipy.optimize as optimize

HERE=Path(__file__).resolve().parent
SNAPSHOT=HERE.parent/'octagon_open15_checkpoint_v1'
sys.path.insert(0,str(SNAPSHOT/'sharp_frame'))
import octagon_guarded_producer as G
O=G.O
sys.path.insert(0,str(SNAPSHOT/'physical_pilots/combined_bounds'))
import review_octagon as C

TARGETS=('negative-2f9ffd3df06e7c5f','negative-573078fc944ce553')
fallbacks=[]


def reliable_lp(*args,**kwargs):
    result=optimize.linprog(*args,**kwargs)
    if not result.success:
        first={'status':int(result.status),'message':str(result.message)}
        retry=dict(kwargs);retry['method']='highs-ds'
        retry['options']={**kwargs.get('options',{}),'presolve':False,'time_limit':30.0}
        result=optimize.linprog(*args,**retry)
        fallbacks.append({'first':first,'retry_status':int(result.status)})
    O.B._last=result.x[:-1] if result.success else None
    return result


O.M.linprog=reliable_lp


def diagnostics(box,choices,z,path):
    eff,terminal=O.V.effective_boxes(box,choices,O.LEGACY)
    assert terminal is None
    frames=[]
    for i in range(9):
        a=float(z[18+i]);b=float(z[27+i]);norm=math.hypot(a,b)
        frames.append((a/norm,b/norm))
    selected={(tuple(pair),kind) for pair,kind,_ in choices}
    pairs=[]
    for i in range(9):
        for j in range(i+1,9):
            dx=float(z[2*j]-z[2*i]);dy=float(z[2*j+1]-z[2*i+1]);d2=dx*dx+dy*dy
            ai,bi=frames[i];aj,bj=frames[j]
            cosine=ai*aj+bi*bj;sine=ai*bj-bi*aj
            threshold=.5*(1+abs(cosine)+abs(sine))
            projection=max(abs(ai*dx+bi*dy),abs(-bi*dx+ai*dy),abs(aj*dx+bj*dy),abs(-bj*dx+aj*dy))
            hmin=O.V.support_lower(eff[i],eff[j])
            pairs.append({'pair':[i,j],'center_norm_squared':d2,'normalized_shared_threshold':threshold,
                          'owner_free_squared_deficit':threshold*threshold-d2,'full_sat_deficit':threshold-projection,
                          'certified_interval_threshold':str(hmin),'certified_interval_squared_deficit':float(hmin*hmin)-d2,
                          'has_sat':((i,j),'sat') in selected,'has_proxy':((i,j),'proxy') in selected})
    selectors=[]
    for p in itertools.permutations((0,1,2,7,8),3):
        if p[2]==2:continue
        chain=[*p,3];rows=C.first_two_rows(chain,True)
        margin=min(sum(float(v)*float(z[k]) for k,v in co)-float(rhs) for co,rhs,_ in rows)
        if margin>1e-8:selectors.append({'chain':chain,'minimum_strict_margin':margin})
    return {'scope':'Numerical LP diagnostics only; normalized frame proposals are not original packings.',
            'minimum_center_pair':min(pairs,key=lambda r:r['center_norm_squared']),
            'largest_owner_free_deficits':sorted(pairs,key=lambda r:-r['owner_free_squared_deficit'])[:6],
            'largest_full_sat_deficits':sorted(pairs,key=lambda r:-r['full_sat_deficit'])[:6],
            'nontrivial_certified_interval_thresholds':[p for p in pairs if F(p['certified_interval_threshold'])>1],
            'violated_complete_selectors':sorted(selectors,key=lambda r:-r['minimum_strict_margin']),
            'eligible_ABXD_guards':C.guarded_originals(path),
            'frame_norm_squared_errors':[float(z[18+i]**2+z[27+i]**2-1) for i in range(9)],
            'absolute_beta_slacks':[float(z[36+i]-abs(z[27+i])) for i in range(9)],
            'point':list(map(float,z))}


def run(name):
    source=SNAPSHOT/'records'/(name+'.json');raw=source.read_bytes();old=json.loads(raw)
    prefix=SNAPSHOT/'prefixes'/(name+'.json');prefix_bytes=prefix.read_bytes()
    assert hashlib.sha256(prefix_bytes).hexdigest()==old['prefix_sha256']
    bounds,deductions=O.replay_prefix(json.loads(prefix_bytes));result=deepcopy(old)
    result['leaves']=deepcopy(old['leaves']);result['frontier']=[]
    result['source_record_sha256']=hashlib.sha256(raw).hexdigest()
    result['inspection_method']='One solve for each existing frontier path; zero new branches.'
    probes=[];start=time.monotonic()
    for index,frontier in enumerate(old['frontier']):
        path=frontier['path'];legacy,box,pos,choices,extra=O.decode(path,old['path'],bounds)
        hit,point,data=O.solve(box,pos,choices,extra)
        row={'index':index,'path':path,'status':'OPEN'}
        if hit is not None:
            leaf=json.loads(json.dumps({'path':path,'legacy_physical_path':legacy,**hit,
                                       'context_version':O.VERSION,'legacy_context_version':O.LEGACY}))
            reserve,terminal,_=C.verify_leaf(leaf,old['path'],bounds,keep_table=False)
            leaf.update(checked_reserve=str(reserve),checked_terminal=terminal)
            result['leaves'].append(leaf);row.update(status='DIRECT_EXACT_LEAF',reserve=str(reserve),terminal=terminal)
        elif point is not None and O.B._last is not None:
            row['diagnostic']=diagnostics(box,choices,O.B._last,path)
            result['frontier'].append({'path':path,'reason':'UNCLOSED_RELAXATION_AFTER_SINGLE_PROBE'})
        else:
            row['status']='NO_LP_POINT';result['frontier'].append({'path':path,'reason':'NO_LP_POINT'})
        probes.append(row)
        print('PROBE',name,index+1,'/',len(old['frontier']),row['status'],flush=True)
    result.update(status='OPEN' if result['frontier'] else 'CLOSED',inspection_nodes=len(probes),
                  inspection_seconds=time.monotonic()-start,inspection_new_branches=0)
    C.verify_complete_union(old['path'],result['leaves']+[{'path':f['path']} for f in result['frontier']])
    (HERE/(name+'_after_single_probe.json')).write_text(json.dumps(result,indent=2)+'\n')
    report={'id':name,'source_record_sha256':result['source_record_sha256'],'prefix_sha256':old['prefix_sha256'],
            'status':result['status'],'old_frontier':len(old['frontier']),'new_direct_leaves':len(result['leaves'])-len(old['leaves']),
            'remaining_frontier':len(result['frontier']),'new_branches':0,'whole_mask_closed':False,'probes':probes}
    (HERE/(name+'_inspection.json')).write_text(json.dumps(report,indent=2)+'\n')
    print('DONE',name,report['status'],'direct',report['new_direct_leaves'],'remaining',report['remaining_frontier'],flush=True)


if __name__=='__main__':
    for name in TARGETS:run(name)
    (HERE/'probe_fallbacks.json').write_text(json.dumps(fallbacks,indent=2)+'\n')
