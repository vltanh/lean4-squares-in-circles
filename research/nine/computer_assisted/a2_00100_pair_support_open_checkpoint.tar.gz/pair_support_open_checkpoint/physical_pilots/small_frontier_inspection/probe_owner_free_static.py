#!/usr/bin/env python3
"""One deterministic static row solve on each of seven existing domains.

No new branches. All old rows are independently regenerated; add the already
reviewed signed/folded unit-frame supports, then the new owner-free family.
"""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
SNAPSHOT=HERE.parent/'octagon_open15_checkpoint_v1'
sys.path.insert(0,str(SNAPSHOT/'physical_pilots/combined_bounds'))
import review_octagon as C
import owner_free_relative_support as N

TARGETS=('negative-2f9ffd3df06e7c5f','negative-573078fc944ce553')


def analytic_frames(angles):
    normal=[C.V.normal_bounds(pair) for pair in angles]
    alpha=[a for a,b in normal];beta=[b for a,b in normal]
    absolute=[(C.V.beta_lower(t),max(abs(b[0]),abs(b[1]))) for t,(a,b) in zip(angles,normal)]
    inset=[]
    for interval in angles:
        low,high=C.V.h_bounds(interval)
        inset.append((C.V.down(F(1,4)/high),C.V.up(F(1,4)/low)))
    return tuple(alpha+beta+absolute+inset)


def unit_rows():
    rows=[]
    for i in range(9):
        for p,q in C.V.DENSE_DIRS:
            assert p*p+q*q==1
            rows.append((((18+i,p),(27+i,q)),F(1),'original_signed_unit_frame'))
        for p,q in C.V.DENSE_DIRS:
            if q>=0:rows.append((((18+i,p),(36+i,q)),F(1),'original_folded_unit_frame'))
    return rows


def model(path,parent_path,parent_bounds):
    legacy,additions=C.split_decode(path)
    angles,pos,choices=C.V.reconstruct(legacy)
    pos=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(pos,parent_bounds))
    old,absolute_bounds,terminal=C.collect_rows(C.V,legacy,angles,pos,choices)
    assert terminal is None
    extra=[row for step in additions for row in C.new_rows(step)]
    extra.extend(row for x in C.guarded_originals(path) for row in C.abxd_guard_rows(x))
    base=old+extra+unit_rows()
    effective,terminal=C.V.effective_boxes(angles,choices,C.LEGACY);assert terminal is None
    propagated,hs,gs,terminal=C.V.center_bounds(effective,pos,choices,C.LEGACY);assert terminal is None
    scalar=analytic_frames(effective)
    differences={(i,j):C.V.difference_bounds((i,j),propagated,gs,C.LEGACY) for i in range(9) for j in range(i+1,9)}
    relative=N.relative_support_rows(propagated,scalar,differences=differences)
    interval=N.interval_radius_rows(propagated,effective,differences=differences)
    return base,relative+interval,absolute_bounds,legacy


def numerical_matrix(rows,n):
    a=np.zeros((len(rows),n));b=np.zeros(len(rows))
    for i,(co,rhs,name) in enumerate(rows):
        for k,value in co:a[i,k]+=float(value)
        b[i]=float(rhs)
    return a,b


def phase(a,b):
    n=a.shape[1]
    return linprog(np.r_[np.zeros(n),1.],A_ub=np.c_[a,-np.ones(len(b))],b_ub=b,
                   bounds=[(None,None)]*(n+1),method='highs-ds',
                   options={'presolve':False,'threads':1,'time_limit':30.0})


def main():
    register=json.loads((C.HERE/'whole_cell_payload/fixed_231_register.json').read_bytes())
    registry={r['id']:r for r in register['cells']};summaries=[]
    output=HERE/'static_owner_free';output.mkdir(exist_ok=True)
    for original in TARGETS:
        prior=json.loads((HERE/(original+'_inspection.json')).read_bytes())
        prefix_path=SNAPSHOT/'prefixes'/(original+'.json');prefix_bytes=prefix_path.read_bytes()
        prefix=json.loads(prefix_bytes);parent=registry[original]
        bounds,deductions,_=C.verify_bound_prefix(prefix,parent)
        probes=[r for r in prior['probes'] if r['status']=='OPEN']
        for item in probes:
            started=time.monotonic();base,new,absolute,legacy=model(item['path'],parent['path'],bounds)
            a,b=numerical_matrix(base+new,len(absolute));rr=phase(a,b)
            baseline_z=np.array(item['diagnostic']['point'])
            max_violation=max(sum(float(v)*baseline_z[k] for k,v in co)-float(rhs) for co,rhs,name in new)
            report={'id':original,'source_probe_index':item['index'],'path':item['path'],
                    'context_version':'disk_octagon_unit_owner_free_static_v1','legacy_physical_path':legacy,
                    'prefix_sha256':hashlib.sha256(prefix_bytes).hexdigest(),'bound_deductions':deductions,
                    'base_rows':len(base),'new_rows':len(new),'new_row_source_sha256':hashlib.sha256(Path(N.__file__).read_bytes()).hexdigest(),
                    'new_branches':0,'whole_mask_closed':False,'baseline_point_max_new_row_violation':max_violation,
                    'solver_status':int(rr.status),'status':'NO_NUMERICAL_CONCLUSION'}
            if rr.success:
                report.update(phase_margin=float(rr.x[-1]),relaxed_variables=list(map(float,rr.x[:-1])),status='OPEN_RELAXATION')
                if rr.x[-1]>1e-8:
                    weights=[[i,int(round(-v*(1<<40)))] for i,v in enumerate(rr.ineqlin.marginals) if int(round(-v*(1<<40)))>0]
                    co,rhs=C.weighted_sum(base+new,absolute,weights)
                    reserve=-rhs-sum(M*abs(v) for M,v in zip(absolute,co))
                    report.update(weights=weights,power=40,exact_reserve=str(reserve))
                    if reserve>0:
                        report.update(status='EXACT_CANDIDATE_LEAF',used_rows=C.printed_rows(base+new,{i for i,w in weights}),
                                      absolute_variable_bounds=list(map(str,absolute)),weighted_coefficients=list(map(str,co)),weighted_rhs=str(rhs))
            report['seconds']=time.monotonic()-started
            label=original+'_'+str(item['index'])
            (output/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
            summaries.append({k:v for k,v in report.items() if k not in ('path','legacy_physical_path','relaxed_variables','used_rows','weights','weighted_coefficients','absolute_variable_bounds')})
            (output/'summary.json').write_text(json.dumps({'probes':summaries,'whole_parent_closed':False,'whole_mask_closed':False},indent=2)+'\n')
            print('STATIC',label,report['status'],'phase',report.get('phase_margin'),'old-point violation',max_violation,flush=True)


if __name__=='__main__':main()
