#!/usr/bin/env python3
"""One static probe on exactly three pre-extension negative573 paths."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import time

import probe_owner_free_static as P
from ordered_octagon_pair_differences import derive_pair_differences

HERE=Path(__file__).resolve().parent
C=P.C;N=P.N
ORIGINAL='negative-573078fc944ce553'


def main():
    output=HERE/'ordered_difference_probes';output.mkdir(exist_ok=True)
    prior=json.loads((HERE/(ORIGINAL+'_inspection.json')).read_bytes())
    selected=[r for r in prior['probes'] if r['status']=='OPEN']
    assert [r['index'] for r in selected]==[2,5,7]
    prefix_file=P.SNAPSHOT/'prefixes'/(ORIGINAL+'.json');prefix_bytes=prefix_file.read_bytes()
    prefix=json.loads(prefix_bytes)
    register=json.loads((C.HERE/'whole_cell_payload/fixed_231_register.json').read_bytes())
    original=next(r for r in register['cells'] if r['id']==ORIGINAL)
    bounds,deductions,_=C.verify_bound_prefix(prefix,original);summaries=[]
    for item in selected:
        started=time.monotonic();path=item['path'];index=item['index']
        base,_,absolute,legacy=P.model(path,original['path'],bounds)
        angles,pos,choices=C.V.reconstruct(legacy)
        pos=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(pos,bounds))
        effective,terminal=C.V.effective_boxes(angles,choices,C.LEGACY);assert terminal is None
        propagated,hs,gs,terminal=C.V.center_bounds(effective,pos,choices,C.LEGACY);assert terminal is None
        scalar=P.analytic_frames(effective)
        native={(i,j):C.V.difference_bounds((i,j),propagated,gs,C.LEGACY) for i in range(9) for j in range(i+1,9)}
        refined,certificate=derive_pair_differences(path,native)
        trace_report={'id':ORIGINAL,'source_probe_index':index,'path':path,
                      'prefix_file':str(prefix_file),'prefix_sha256':hashlib.sha256(prefix_bytes).hexdigest(),
                      'parent_positions':[[str(l),str(u)] for l,u in bounds],
                      'native_provider':'frozen_v14_effective_boxes_center_bounds_difference_bounds',
                      'difference_certificate':certificate}
        trace_path=output/(ORIGINAL+'_'+str(index)+'_trace.json')
        assert not trace_path.exists();trace_path.write_text(json.dumps(trace_report,indent=2)+'\n')
        report={'id':ORIGINAL,'source_probe_index':index,'path':path,
                'context_version':'disk_octagon_path_difference_owner_free_v1',
                'prefix_sha256':hashlib.sha256(prefix_bytes).hexdigest(),'bound_deductions':deductions,
                'trace_sha256':hashlib.sha256(trace_path.read_bytes()).hexdigest(),'trace_file':trace_path.name,
                'new_branches':0,'whole_mask_closed':False,'narrowings':certificate['narrowings'],
                'new_row_source_sha256':hashlib.sha256(Path(N.__file__).read_bytes()).hexdigest()}
        if refined is None:
            report.update(status='EXACT_DIFFERENCE_TERMINAL_CANDIDATE',terminal=certificate['terminal'])
        else:
            new=N.relative_support_rows(propagated,scalar,differences=refined)+N.interval_radius_rows(propagated,effective,differences=refined)
            a,b=P.numerical_matrix(base+new,len(absolute));rr=P.phase(a,b)
            report.update(status='NO_NUMERICAL_CONCLUSION',solver_status=int(rr.status),base_rows=len(base),new_rows=len(new))
            if rr.success:
                report.update(status='OPEN_RELAXATION',phase_margin=float(rr.x[-1]),relaxed_variables=list(map(float,rr.x[:-1])))
                if rr.x[-1]>1e-8:
                    weights=[[i,int(round(-v*(1<<40)))] for i,v in enumerate(rr.ineqlin.marginals) if int(round(-v*(1<<40)))>0]
                    co,rhs=C.weighted_sum(base+new,absolute,weights)
                    reserve=-rhs-sum(M*abs(v) for M,v in zip(absolute,co))
                    report.update(weights=weights,power=40,exact_reserve=str(reserve))
                    if reserve>0:
                        report.update(status='EXACT_CANDIDATE_LEAF',used_rows=C.printed_rows(base+new,{i for i,w in weights}),
                                      absolute_variable_bounds=list(map(str,absolute)),weighted_coefficients=list(map(str,co)),weighted_rhs=str(rhs))
        report['seconds']=time.monotonic()-started
        (output/(ORIGINAL+'_'+str(index)+'_probe.json')).write_text(json.dumps(report,indent=2)+'\n')
        summaries.append({k:v for k,v in report.items() if k not in ('path','used_rows','weights','weighted_coefficients','absolute_variable_bounds','relaxed_variables')})
        (output/'summary.json').write_text(json.dumps({'probes':summaries,'whole_parent_closed':False,'whole_mask_closed':False},indent=2)+'\n')
        print('ORDERED_DIFFERENCES',index,report['status'],certificate['narrowings'],'phase',report.get('phase_margin'),flush=True)


if __name__=='__main__':main()
