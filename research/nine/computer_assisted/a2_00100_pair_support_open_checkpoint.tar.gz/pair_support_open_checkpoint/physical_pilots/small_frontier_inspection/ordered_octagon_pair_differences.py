#!/usr/bin/env python3
"""Exact path-derived pair differences; no numerical or producer imports.

Input intervals must already be proved for the same original caller. The
returned certificate records an acyclic derivation of every narrowing.
See ORDERED_OCTAGON_PAIR_DIFFERENCE_HAND_LEMMA.md.
"""
from copy import deepcopy
from fractions import Fraction as F

VERSION='ordered_octagon_pair_differences_v1'
DIAGONALS=((1,1),(1,-1),(-1,1),(-1,-1))
PAIRS=tuple((i,j) for i in range(9) for j in range(i+1,9))


def diagonal_intervals(step):
    """Proved original dx/dy intervals on one ordered diagonal child."""
    assert type(step) is list and len(step)==3 and step[0]=='disk8_ordered'
    marker,chosen=step[1:]
    assert type(marker) is list and len(marker)==4 and all(type(v) is int for v in marker)
    i,j,num,den=marker
    assert 0<=i<j<9 and den>0
    assert type(chosen) is list and len(chosen)==1 and type(chosen[0]) is int and 0<=chosen[0]<8
    choice=chosen[0]
    if choice<4:return None
    a,b=DIAGONALS[choice-4]
    t=F(num,den);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
    assert c*c+s*s==1
    low,high=F(5,13),F(12,13)
    def interval(p,q):
        return (min(p*low,p*high)+min(q*low,q*high),
                max(p*low,p*high)+max(q*low,q*high))
    return {'pair':(i,j),'rotation':(c,s),'signs':(a,b),
            'intervals':(interval(c*a,-s*b),interval(s*a,c*b))}


def derive_pair_differences(path,native_differences):
    """Return (refined, certificate); refined is None on exact contradiction.

    native_differences maps all36 ordered-index pairs (i,j), i<j, to two
    rational intervals for c_j-c_i. It may include independently proved
    parent-bound intersections. The caller/checker must establish those
    inputs; this module does not promote numerical intervals to premises.
    """
    assert type(path) is list and set(native_differences)==set(PAIRS)
    native={p:tuple(tuple(map(F,interval)) for interval in native_differences[p]) for p in PAIRS}
    assert all(len(value)==2 and all(len(interval)==2 for interval in value) for value in native.values())
    trace=[]
    upper=[[[None]*9 for _ in range(9)] for _ in range(2)]
    proofs=[[[None]*9 for _ in range(9)] for _ in range(2)]
    counts={'diagonal':0,'triangle':0}
    terminal=None

    def append(kind,axis,i,j,value,**details):
        ident=len(trace)
        trace.append({'id':ident,'kind':kind,'axis':axis,'i':i,'j':j,
                      'value':str(value),**details})
        upper[axis][i][j]=value;proofs[axis][i][j]=ident
        return ident

    for axis in range(2):
        for i in range(9):append('identity',axis,i,i,F(0))
        for i,j in PAIRS:
            lower,higher=native[(i,j)][axis]
            append('native_upper',axis,i,j,higher,pair=[i,j],endpoint='upper')
            append('native_upper',axis,j,i,-lower,pair=[i,j],endpoint='negated_lower')

    def contradiction(axis,i,j):
        if i==j and upper[axis][i][i]<0:
            return {'kind':'negative_cycle','axis':axis,'i':i,
                    'antecedents':[proofs[axis][i][i]],'negative_upper':str(upper[axis][i][i])}
        if i!=j and upper[axis][i][j]+upper[axis][j][i]<0:
            return {'kind':'empty_pair_interval','axis':axis,'pair':sorted((i,j)),
                    'antecedents':[proofs[axis][i][j],proofs[axis][j][i]],
                    'negative_zero_upper':str(upper[axis][i][j]+upper[axis][j][i])}
        return None

    for axis in range(2):
        for i,j in PAIRS:
            terminal=contradiction(axis,i,j)
            if terminal:break
        if terminal:break

    if terminal is None:
        for step_index,step in enumerate(path):
            if step[0]!='disk8_ordered':continue
            derived=diagonal_intervals(step)
            if derived is None:continue
            i,j=derived['pair'];c,s=derived['rotation'];a,b=derived['signs']
            for axis,(lower,higher) in enumerate(derived['intervals']):
                for left,right,value,side in ((i,j,higher,'upper'),(j,i,-lower,'negated_lower')):
                    if value>=upper[axis][left][right]:continue
                    previous=proofs[axis][left][right]
                    append('ordered_diagonal_upper',axis,left,right,value,
                           step_index=step_index,path_step=deepcopy(step),endpoint=side,
                           signed_rectangle=['5/13','12/13'],rotation=[str(c),str(s)],
                           diagonal_signs=[a,b],previous_upper_id=previous)
                    counts['diagonal']+=1
                    terminal=contradiction(axis,left,right)
                    if terminal:break
                if terminal:break
            if terminal:break

    # Fixed finite Floyd-Warshall order. Every update cites earlier bound
    # records, even when an in-place table entry was improved earlier in
    # the same k-loop. Thus the certificate is an acyclic proof sequence.
    if terminal is None:
        for axis in range(2):
            for k in range(9):
                for i in range(9):
                    for j in range(9):
                        value=upper[axis][i][k]+upper[axis][k][j]
                        if value>=upper[axis][i][j]:continue
                        left=proofs[axis][i][k];right=proofs[axis][k][j]
                        previous=proofs[axis][i][j]
                        append('triangle_upper',axis,i,j,value,via=k,
                               antecedents=[left,right],previous_upper_id=previous)
                        counts['triangle']+=1
                        terminal=contradiction(axis,i,j)
                        if terminal:break
                    if terminal:break
                if terminal:break
            if terminal:break

    refined=None if terminal else {p:tuple((-upper[a][p[1]][p[0]],upper[a][p[0]][p[1]]) for a in range(2)) for p in PAIRS}
    certificate={'schema':VERSION,'original_labels':9,'path':deepcopy(path),
                 'native_differences':[{'pair':list(p),'intervals':[[str(l),str(u)] for l,u in native[p]]} for p in PAIRS],
                 'trace':trace,'narrowings':counts,'final_upper_ids':proofs,'terminal':terminal,
                 'differences':None if refined is None else [{'pair':list(p),'intervals':[[str(l),str(u)] for l,u in refined[p]]} for p in PAIRS]}
    return refined,certificate
