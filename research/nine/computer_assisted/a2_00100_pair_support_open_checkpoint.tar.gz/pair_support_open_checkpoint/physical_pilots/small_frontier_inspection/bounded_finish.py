#!/usr/bin/env python3
"""Authorized last256-node v3 continuation of one named original parent."""
import argparse
import hashlib
import json

from probe_existing_frontiers import HERE,SNAPSHOT,TARGETS,G,C


def main():
    parser=argparse.ArgumentParser();parser.add_argument('original',choices=TARGETS);args=parser.parse_args()
    name=args.original
    destination=HERE/(name+'_v3_bounded_finish256.json')
    assert not destination.exists()
    prefix=SNAPSHOT/'prefixes'/(name+'.json')
    result=G.run(prefix,256,destination,HERE/(name+'_after_single_probe.json'))
    if result['status']=='CLOSED':
        register=json.loads((C.HERE/'whole_cell_payload/fixed_231_register.json').read_bytes())
        report,tables=C.review_parent(result,prefix.read_bytes(),{r['id']:r for r in register['cells']})
        assert report['whole_parent_closed']
        report['source_report_sha256']=hashlib.sha256(destination.read_bytes()).hexdigest()
        (HERE/(name+'_complete_independent_review.json')).write_text(json.dumps(report,indent=2)+'\n')
        (HERE/(name+'_complete_independent_review.tables.json')).write_text(json.dumps(tables,indent=2)+'\n')
        print('INDEPENDENT_COMPLETE_PASS',name,report['bound_deductions'],report['weighted_leaves'],flush=True)


if __name__=='__main__':main()
