# Two small frontiers: completed inspection and proof boundary

This research supplement concerns only the immutable originals
`negative-2f9ffd3df06e7c5f` and `negative-573078fc944ce553`. **Both remain
OPEN. No additional original cell or whole mask closed.** All discovery
and probe work described below has stopped.

## Frozen starting point

The portable starting checkpoint is the sibling
`octagon_open15_checkpoint_v1/` archive, whose SHA256 is
`59d60bc4fd77a6927d35bb6097ffa7390e3a16715230e8e72523027b7d72d49b`.
Its independent replay checked 457 exact bound deductions, 4036 retained
contradiction leaves, and complete partial covers including 1028 unproved
paths. It closes zero original parents. It has not been overwritten.

The two named originals initially had six and seventeen unproved paths.
One solve on each existing domain, with no branching, discharged two and
fourteen of those paths by exact v3 row sums. Four and three original
descendants respectively remained. The updated partial covers are in the
`*_after_single_probe.json` records.

## Concrete physical defects and static support probe

All seven surviving LP proposals violated the necessary original center
distance. Their minimum squared pair distances ranged from zero to about
0.617. None of the violating pairs had a selected SAT axis. Normalizing the
proposed frame vectors for diagnostic purposes exposed square-SAT deficits
of about 0.37 to 1.0; this normalization is not a construction of physical
packings and is never used as a proof premise. The proposals also had large
unit-frame and signed/absolute-beta relaxation defects.

All inherited angle intervals contain zero. Therefore their proved
constant shared-support lower radius is exactly one for every pair; a
larger pointwise orientation radius cannot be applied to the whole domain.

One deterministic static solve per surviving domain added the previously
reviewed 1737 signed/folded unit-frame supports, all 6912 signed/folded
owner-free relative-support rows, and 36 interval-radius secant rows.
All seven remained LP-open. Six old proposals already satisfied all new
relative-support secants. The remaining proposal violated one by about 0.320,
but the stronger model still admitted a relaxed point. Broad difference
intervals were a specific source of looseness.

The exact new invariant is proved in
`OWNER_FREE_RELATIVE_SUPPORT_HAND_PROOF.md`; its pure-rational generator
is `owner_free_relative_support.py`. These necessary constraints introduce
no new physical original, frame, or separating-axis owner.

## Final bounded v3 continuation

The two smaller partial covers were each continued once with at most 256
additional v3 nodes and no new proof context. Both reached the cap:

| Original | Retained contradiction leaves | Unproved frontier paths |
|---|---:|---:|
| `negative-2f9ffd3df06e7c5f` | 503 | 20 |
| `negative-573078fc944ce553` | 511 | 43 |

All 1014 retained leaves and both full partial covers subsequently passed
independent exact replay. The result is
`latest_two_independent_partial_review.json`. No candidate was rejected;
neither tree is a complete original-parent proof. The final trees are
separate `*_v3_bounded_finish256.json` files and do not replace the frozen
15-original starting checkpoint.

## Exact ordered-octagon difference consequence

`ORDERED_OCTAGON_PAIR_DIFFERENCE_HAND_LEMMA.md` proves a stronger interval
input for the owner-free secants. A diagonal ordered-octagon child retains
all four axis predecessor complements. If its primary signed diagonal is
`a*w_x+b*w_y>=17/13`, then each of `a*w_x` and `b*w_y` lies in the exact
interval `[5/13,12/13]`. The recorded rational rotation converts that box
into bounds on the same original pair's coordinate differences.

`ordered_octagon_pair_differences.py` implements this implication and
finite exact triangle propagation. Its API is

```python
refined_or_none, certificate = derive_pair_differences(path, proved_inputs)
```

The input maps all 36 original pairs to already proved dx/dy intervals. The
certificate records all 162 initial directed upper bounds, each exact
diagonal-child narrowing with its path antecedent, and every triangle
update with earlier proof IDs. It also records final bound IDs and exact
negative-cycle or empty-pair terminals. Numerical intervals are not
promoted to premises.

The three pre-extension `negative-573078fc944ce553` domains were tested once
with these stronger intervals. They produced four diagonal improvements
each and 9, 15, 22 additional triangle improvements. A separately written
checker independently verified every interval derivation and its native
bound provenance. All three static strengthened models nevertheless remain
LP-open. Their traces, probe records, and summary are under
`ordered_difference_probes/`; they add no branch or closure claim.

## Reuse and limits

The source module SHA256 is
`51a5ec13de29669abb9ac8797784120a378578d47bcfbc395b405a6965cfa97d`.
The independent trace review is copied as
`C_573_three_trace_independent_review.json`. Its result is certified
intervals only, not a contradiction or parent closure.

Extract this supplement alongside the unchanged OPEN15 checkpoint to
preserve the source layout used by the discovery scripts. Exact native
sources and prefixes remain in that checkpoint. Numerical scripts require
NumPy/SciPy and describe completed research; running them is not required
to accept the already recorded independent checks.

All accepted v3 source files, closure packages, and original-cell statuses
remain unchanged. No Lean, Lake, CI, new required gate, shared-ledger edit,
or push was performed.
