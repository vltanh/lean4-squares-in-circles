# C887 fresh starting-state integration packet

This packet contains byte-identical new proof records, the exact target statement, checker snapshots, and successful independent reports. It is ready for parent review and integration. It is not yet a portable standalone installation: the checker snapshots and original manifest retain their original dependency paths, listed in `DEPENDENCY_BINDINGS.json`. Existing original ancestry and height fixtures must remain available or be mapped injectively with exact SHA checks by the native publication transport. No missing archive is assumed.

Current verified local command, run from `/workspace/scratch/8446ce74729c/pr11/research/nine/.runs/c_family`:

```sh
python -B -S check_c887_general_cover_rejoined.py c887_whole_general_bounded/MANIFEST.json C887_REJOINED_WHOLE_PARTIAL_REPLAY.json --union c887_fresh_dg_union_refined/MANIFEST.json
```

For the root starting-box statement alone use `verify_c887_fresh_dg_union.py` with the same union manifest and a fresh output path. The packet includes the existing partial-tree report as integration evidence, but does not duplicate the25MB tree records. `HAND_PROOF.md` explains the complete8-cover and interval-hull implication.

Scope: one original's necessary starting-box theorem, no original or mask closure. All current C search frontiers remain active separately. Parent handles public integration and commits; this child has made no shared/public edits.
