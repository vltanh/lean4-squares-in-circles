#!/usr/bin/env python3
"""Bounded, read-only D/G SAT8 screen over fourteen certified B16 leaf states.

No numerical solver or new inequality is used.  Later propagation is recorded
as a proposal until ordinary-round replay; immediate zero-round terminals are
also checked by the unchanged independent arithmetic core.  The old complete
45-node proof is reused by its exact report and complete input identities.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import sys
import time

ROOT = Path('/workspace/scratch/f9f48fcfb253')
HERE = Path(__file__).resolve().parent
HELPER = ROOT / 'b_work/b16_existing_propagation_screen_v1/screen_repeated_propagation.py'
spec = importlib.util.spec_from_file_location('b16_existing_interval_screen_frozen', HELPER)
H = importlib.util.module_from_spec(spec)
spec.loader.exec_module(H)
EXACT = H.EXACT
PAIR = (3, 6)
ALTERNATIVES = tuple(product(PAIR, (0, 1), (-1, 1)))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def probe(initial, adapter, limit):
    state = deepcopy(initial)
    transitions = []
    terminal = None
    status = None
    for step in range(limit + 1):
        propagated, terminal = H.early_or_propagated(state, adapter)
        if terminal is not None:
            assert adapter.verify_early_terminal(deepcopy(state), terminal) is True
            status = 'EXISTING_EARLY_TERMINAL'
            break
        if step == limit:
            status = 'OPEN_BOUNDED_PROPAGATION_LIMIT'
            break
        EXACT.CORE.valid_state(propagated)
        H.interval_subset(state, propagated)
        angles, label, identities = adapter.infer_angles(state['angles'], propagated['scalar'])
        transition = dict(before=EXACT.CORE.state_view(state),
            propagated=EXACT.CORE.state_view(propagated), printed_rows=[], proposals=[],
            physical_frame_inferences=identities)
        if label is not None:
            terminal = dict(kind='proved_frame_contradiction', label=label)
            transitions.append(transition)
            status = 'FRAME_TERMINAL_PROPOSED_ORDINARY_ROUND'
            break
        scalar = tuple((max(a, c), min(b, d)) for (a, b), (c, d)
                       in zip(propagated['scalar'], adapter.analytic(angles)))
        bad = next(((i, a, b) for i, (a, b) in enumerate(scalar) if a > b), None)
        if bad is not None:
            index, low, high = bad
            terminal = dict(kind='proved_empty_analytic_frame', index=index,
                            lower=str(low), upper=str(high))
            transitions.append(transition)
            status = 'ANALYTIC_TERMINAL_PROPOSED_ORDINARY_ROUND'
            break
        after = dict(deepcopy(propagated), angles=angles, scalar=scalar)
        EXACT.CORE.valid_state(after)
        H.interval_subset(state, after)
        transition['after'] = EXACT.CORE.state_view(after)
        if after == state:
            status = 'OPEN_EXACT_PROPAGATION_FIXED_POINT'
            break
        transitions.append(transition)
        state = after
    immediate_audit = None
    zero_record = dict(initial=EXACT.CORE.state_view(initial), rounds=[])
    if terminal is not None and not transitions:
        zero_record.update(status='CANDIDATE_CLOSED', terminal=terminal)
        immediate_audit, end = EXACT.CORE.check_record(zero_record, initial, adapter)
        assert end is None
    else:
        zero_record.update(status='OPEN', final=EXACT.CORE.state_view(initial))
    return dict(status=status, terminal=terminal,
        proposed_empty_objective_rounds=len(transitions), transitions=transitions,
        current=EXACT.CORE.state_view(state), immediate_terminal_audit=immediate_audit,
        zero_round_cover_record=zero_record)


def main():
    if not __debug__:
        raise RuntimeError('Exact assertions are required')
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--max-rounds', type=int, default=4)
    args = ap.parse_args()
    assert args.max_rounds == 4 and not args.output.exists()
    freeze = json.loads((HERE / 'SOURCE_BINDING.json').read_text())
    for path, digest in freeze['files'].items():
        assert sha(path) == digest, path
    assert sha(H.REPORT) == H.REPORT_SHA and sha(H.TREE / 'manifest.json') == H.TREE_SHA
    report = json.loads(H.REPORT.read_text())
    manifest = json.loads((H.TREE / 'manifest.json').read_text())
    assert report['status'] == 'PASS_PARTIAL_PHYSICAL_TREE'
    assert (report['nodes'], report['open_leaves'], report['excluded_leaves']) == (45, 14, 16)
    assert not report['entire_registered_original_domain_retained']
    leaves = tuple(sorted(x['index'] for x in report['leaf_table'] if not x['excluded']))
    assert leaves == H.EXPECTED
    for path, digest in report['source_sha256'].items():
        assert sha(path) == digest, path
    for entry in manifest['nodes']:
        assert sha(H.TREE / entry['file']) == entry['sha256']
    cap = ROOT / 'b_work/recovery_20261105/extracted_b340/unpacked/b340_complete_original_package/accepted_repo/research/nine/computer_assisted/full_angle_common_side_row_v1'
    adapter = EXACT.Adapter(ROOT / 'b_work/b16a_I32_complete_H_checkpoint', cap)
    assert adapter.K.V.Q == F(1105, 256)
    started = time.monotonic()
    outcomes = []
    for index in leaves:
        entry = manifest['nodes'][index]
        node = json.loads((H.TREE / entry['file']).read_text())
        assert node['status'] == node['record']['status'] == 'OPEN' and node['children'] == []
        assert not node['record']['rounds']
        assert node['initial'] == node['record']['initial'] == node['record']['final']
        parent = H.restore(node['record']['final'], adapter)
        assert not any(step[0] == 'sat' for step in parent['path'])
        cases = []
        for choice in ALTERNATIVES:
            initial = EXACT.CORE.sat_child(parent, PAIR, choice, adapter)
            answer = probe(initial, adapter, args.max_rounds)
            answer.update(choice=list(choice), initial=EXACT.CORE.state_view(initial))
            cases.append(answer)
        # This exact cover uses only the immediately checked terminals.  Later
        # proposals do not strengthen its OPEN alternatives or final states.
        cover, survivors = EXACT.CORE.check_complete_cover(parent, PAIR,
            [(c['choice'], c['zero_round_cover_record']) for c in cases], adapter)
        result = dict(parent_index=index, parent_node_sha256=entry['sha256'],
            parent_final=node['record']['final'], pair=list(PAIR), cases=cases,
            exact_zero_round_cover=cover,
            proposed_terminal_alternatives=sum(c['terminal'] is not None for c in cases),
            immediate_exact_terminal_alternatives=cover['excluded_alternatives'],
            proposed_complete_parent=all(c['terminal'] is not None for c in cases),
            exact_zero_round_complete_parent=not survivors)
        outcomes.append(result)
        print(json.dumps({k: result[k] for k in ('parent_index',
            'proposed_terminal_alternatives', 'immediate_exact_terminal_alternatives',
            'proposed_complete_parent', 'exact_zero_round_complete_parent')}), flush=True)
    adapter.recheck()
    for path, digest in report['source_sha256'].items():
        assert sha(path) == digest, path
    for entry in manifest['nodes']:
        assert sha(H.TREE / entry['file']) == entry['sha256']
    for path, digest in freeze['files'].items():
        assert sha(path) == digest, path
    assert sha(H.REPORT) == H.REPORT_SHA and sha(H.TREE / 'manifest.json') == H.TREE_SHA
    assert not any(x in sys.modules for x in ('numpy', 'scipy', 'highspy'))
    result = dict(schema='B16_14_parent_complete_DG8_exact_screen_v1',
        status='PASS_READ_ONLY_COMPLETE_DG8_SCREEN',
        regional_scope='merged closed I21/I22 only',
        old_full45_report_sha256=H.REPORT_SHA, old_manifest_sha256=H.TREE_SHA,
        source_binding_sha256=sha(HERE / 'SOURCE_BINDING.json'),
        old_all45_weighted_arithmetic_reused_by_exact_identity=True,
        old_source_pins_rehashed=len(report['source_sha256']),
        checked_parents=14, checked_complete_eight_covers=14, checked_children=112,
        max_empty_proposal_rounds_per_child=args.max_rounds,
        immediate_exact_excluded_alternatives=sum(x['immediate_exact_terminal_alternatives'] for x in outcomes),
        proposed_excluded_alternatives=sum(x['proposed_terminal_alternatives'] for x in outcomes),
        exact_zero_round_complete_parents=[x['parent_index'] for x in outcomes if x['exact_zero_round_complete_parent']],
        proposed_complete_parents=[x['parent_index'] for x in outcomes if x['proposed_complete_parent']],
        later_propagation_requires_ordinary_round_replay=True,
        outcomes=outcomes, seconds=time.monotonic()-started,
        numerical_solver_called=False, new_inequality_family=False,
        active_tree_or_record_written=False, new_original_cells=0, new_masks=0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps(dict(status=result['status'], output_sha256=sha(args.output),
        immediate_exclusions=result['immediate_exact_excluded_alternatives'],
        proposed_exclusions=result['proposed_excluded_alternatives'],
        complete_parents=result['proposed_complete_parents'], seconds=result['seconds'])), flush=True)


if __name__ == '__main__':
    main()
