#!/usr/bin/env python3
"""Read-only exact screening of repeated existing physical propagation.

The input states have a completed full exact proof. This screen calls only
the already accepted interval/frame functions. It installs no new state and
does not claim a proof continuation until ordinary round records are checked.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from copy import deepcopy
import argparse
import hashlib
import json
import sys

ROOT = Path('/workspace/scratch/f9f48fcfb253')
sys.path.insert(0, str(ROOT / 'b_work'))
import verify_b_accepted_center_disk_tree_v1 as EXACT

TREE = ROOT / 'd_work/b16_restored45_interval_continuation_v1'
REPORT = ROOT / 'd_work/B16_INTERVAL_CONTINUATION45_FRESH_EXACT_REPLAY.json'
TREE_SHA = '941243cf54bde2070916a29c95c1a2bdba7b5c5e8651ec690c1f482788c210db'
REPORT_SHA = '03754a15723bc8e9fc67a685a980ccaa50d034487ca94b827849d1acc31be451'
EXPECTED = (1, 5, 13, 18, 21, 24, 26, 28, 33, 34, 36, 38, 40, 42)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def restore(raw, adapter):
    state = dict(id=raw['id'], path=deepcopy(raw['path']))
    for field in ('angles', 'positions', 'scalar'):
        state[field] = tuple(tuple(map(F, interval)) for interval in raw[field])
    state['differences'] = {tuple(row['pair']): tuple(tuple(map(F, interval)) for interval in row['intervals'])
                            for row in raw['differences']}
    state['choices'] = adapter.choices(state['path'])
    EXACT.CORE.valid_state(state)
    assert EXACT.CORE.state_view(state) == raw
    return state


def early_or_propagated(state, adapter):
    # This is exactly the propagated-state portion of the frozen K.rebuild.
    # It omits affine-row construction because no objective is proposed.
    K = adapter.K; V = K.V
    effective, label = V.effective_boxes(state['angles'], state['choices'], K.LEGACY)
    if label is not None:
        return None, dict(kind='accepted_effective_angle_terminal', label=label)
    positions, heights, insets, label = V.center_bounds(effective, state['positions'], state['choices'], K.LEGACY)
    if label is not None:
        return None, dict(kind='accepted_center_interval_terminal', label=label)
    scalar = tuple((max(a, c), min(b, d)) for (a, b), (c, d)
                   in zip(state['scalar'], K.analytic(effective)))
    for index, (low, high) in enumerate(scalar):
        if low > high:
            return None, dict(kind='empty_analytic_scalar', witness=list(map(str, (index, low, high))))
    differences = {}
    for pair in combinations(range(9), 2):
        physical = V.difference_bounds(pair, positions, insets, K.LEGACY)
        prior = state['differences'].get(pair, physical)
        actual = tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(physical, prior))
        for axis, (low, high) in enumerate(actual):
            if low > high:
                return None, dict(kind='empty_difference', pair=list(pair), axis=axis,
                                  lower=str(low), upper=str(high))
        differences[pair] = actual
    return dict(deepcopy(state), positions=tuple(map(tuple, positions)), scalar=scalar,
                differences=differences), None


def interval_subset(before, after):
    assert before['id'] == after['id'] and before['path'] == after['path']
    assert before['choices'] == after['choices']
    for field in ('angles', 'positions', 'scalar'):
        assert len(before[field]) == len(after[field])
        for (a, b), (c, d) in zip(before[field], after[field]):
            assert a <= c <= d <= b, field
    for pair, prior in before['differences'].items():
        for (a, b), (c, d) in zip(prior, after['differences'][pair]):
            assert a <= c <= d <= b


def main():
    if not __debug__:
        raise RuntimeError('Exact assertions are required')
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--max-rounds', type=int, default=32)
    args = parser.parse_args()
    assert 1 <= args.max_rounds <= 64 and not args.output.exists()
    here = Path(__file__).resolve().parent
    freeze = json.loads((here / 'SOURCE_BINDING.json').read_text())
    for name, digest in freeze['files'].items():
        assert sha(name) == digest
    assert sha(REPORT) == REPORT_SHA and sha(TREE / 'manifest.json') == TREE_SHA
    report = json.loads(REPORT.read_text()); manifest = json.loads((TREE / 'manifest.json').read_text())
    assert report['status'] == 'PASS_PARTIAL_PHYSICAL_TREE'
    assert report['entire_registered_original_domain_retained'] is False
    assert (report['nodes'], report['open_leaves'], report['excluded_leaves']) == (45, 14, 16)
    leaves = tuple(sorted(row['index'] for row in report['leaf_table'] if not row['excluded']))
    assert leaves == EXPECTED
    for name, digest in report['source_sha256'].items():
        assert sha(name) == digest
    cap = ROOT / 'b_work/recovery_20261105/extracted_b340/unpacked/b340_complete_original_package/accepted_repo/research/nine/computer_assisted/full_angle_common_side_row_v1'
    adapter = EXACT.Adapter(ROOT / 'b_work/b16a_I32_complete_H_checkpoint', cap)
    assert adapter.K.V.Q == F(1105, 256)
    outcomes = []
    for index in leaves:
        entry = manifest['nodes'][index]
        node_path = TREE / entry['file']
        assert sha(node_path) == entry['sha256']
        node = json.loads(node_path.read_text())
        assert node['status'] == node['record']['status'] == 'OPEN' and node['children'] == []
        assert node['record']['rounds'] == [] and node['record']['initial'] == node['record']['final'] == node['initial']
        state = restore(node['record']['final'], adapter)
        transitions = []; terminal = None; status = None
        for step in range(args.max_rounds + 1):
            propagated, terminal = early_or_propagated(state, adapter)
            if terminal is not None:
                assert adapter.verify_early_terminal(state, terminal) is True
                status = 'EXISTING_EARLY_TERMINAL_AFTER_PROPAGATION'; break
            if step == args.max_rounds:
                status = 'OPEN_BOUNDED_SCREEN_LIMIT'; break
            EXACT.CORE.valid_state(propagated)
            interval_subset(state, propagated)
            angles, frame_terminal, identities = adapter.infer_angles(state['angles'], propagated['scalar'])
            transition = dict(before=EXACT.CORE.state_view(state), propagated=EXACT.CORE.state_view(propagated),
                              proposals=[], printed_rows=[], physical_frame_inferences=identities)
            if frame_terminal is not None:
                terminal = dict(kind='proved_frame_contradiction', label=frame_terminal)
                transitions.append(transition); status = 'EXISTING_FRAME_TERMINAL_IN_EMPTY_PROPOSAL_ROUND'; break
            scalar = tuple((max(a, c), min(b, d)) for (a, b), (c, d)
                           in zip(propagated['scalar'], adapter.analytic(angles)))
            bad = next(((i, low, high) for i, (low, high) in enumerate(scalar) if low > high), None)
            if bad is not None:
                i, low, high = bad
                terminal = dict(kind='proved_empty_analytic_frame', index=i, lower=str(low), upper=str(high))
                transitions.append(transition); status = 'EXISTING_ANALYTIC_FRAME_TERMINAL_IN_EMPTY_PROPOSAL_ROUND'; break
            after = dict(deepcopy(propagated), angles=angles, scalar=scalar)
            EXACT.CORE.valid_state(after); interval_subset(state, after)
            transition['after'] = EXACT.CORE.state_view(after)
            if after == state:
                status = 'OPEN_EXACT_PROPAGATION_FIXED_POINT'; terminal = None; break
            transitions.append(transition); state = after
        outcome = dict(index=index, source_node_sha256=entry['sha256'], status=status,
                       proposed_empty_objective_rounds=len(transitions), terminal=terminal,
                       initial=node['record']['final'], transitions=transitions,
                       current=EXACT.CORE.state_view(state))
        outcomes.append(outcome)
        print(json.dumps({key: outcome[key] for key in ('index', 'status', 'proposed_empty_objective_rounds', 'terminal')}), flush=True)
    adapter.recheck()
    for name, digest in report['source_sha256'].items():
        assert sha(name) == digest
    for name, digest in freeze['files'].items():
        assert sha(name) == digest
    assert sha(TREE / 'manifest.json') == TREE_SHA and sha(REPORT) == REPORT_SHA
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy'))
    result = dict(status='PASS_READ_ONLY_EXACT_B16_REPEATED_PROPAGATION_SCREEN',
        original_id='negative-16a2fc93c8d133f0', regional_scope='merged closed I21/I22 only',
        source_full45_report_sha256=REPORT_SHA, source_manifest_sha256=TREE_SHA,
        source_binding_sha256=sha(here / 'SOURCE_BINDING.json'), prior_input_pins_rehashed=len(report['source_sha256']),
        prior_all45_weighted_arithmetic_reused_not_repeated=True, checked_remaining_leaves=14,
        promising_terminal_leaves=[row['index'] for row in outcomes if row['terminal'] is not None],
        fixed_point_leaves=[row['index'] for row in outcomes if row['status'] == 'OPEN_EXACT_PROPAGATION_FIXED_POINT'],
        bounded_screen_limit_leaves=[row['index'] for row in outcomes if row['status'] == 'OPEN_BOUNDED_SCREEN_LIMIT'],
        max_rounds=args.max_rounds, outcomes=outcomes,
        ordinary_round_replay_still_required=True, new_tree_or_record_written=False,
        numerical_solver_called=False, new_original_cells=0, new_masks=0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as handle:
        json.dump(result, handle, indent=2); handle.write('\n')
    print(json.dumps(dict(status=result['status'], report_sha256=sha(args.output),
        terminal_leaves=result['promising_terminal_leaves'], fixed_points=result['fixed_point_leaves'],
        limits=result['bounded_screen_limit_leaves'])), flush=True)


if __name__ == '__main__':
    main()
