#!/usr/bin/env python3
"""Conditional exact-only screen of external B16 leaves against regional bounds.

The external 127-node weighted proof has NOT been replayed by this program.
No intersection is installed in a proof state.  The only source of added box
endpoints is the freshly checked root record of the existing 45-node regional
tree, which has no child choices and covers the same full I21/I22 rectangle.
"""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import sys

ROOT = Path('/workspace/scratch/f9f48fcfb253')
HERE = Path(__file__).resolve().parent
SNAPSHOT = ROOT / 'repo/research/nine/.runs/b16_external127_snapshot_v1'
SNAPSHOT_SHA = '4de9cda71a6b54e2c8fd9e02637c465a93509f668c20af77ccbdb033d4889c3b'
spec = importlib.util.spec_from_file_location('b16_frozen_empty_round_probe', ROOT / 'b_work/b16_dg_exact_screen_v1/screen.py')
D = importlib.util.module_from_spec(spec)
spec.loader.exec_module(D)
H = D.H
EXACT = H.EXACT
import verify_b_complete_guards_trees as COMPLETE
import verify_b_all_row_guards as GUARDS


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def intersect(leaf, necessary):
    assert leaf['id'] == necessary['id']
    prefix = necessary['path']
    assert leaf['path'][:len(prefix)] == prefix
    assert not any(step[0] in ('sat', 'proxy') for step in prefix)
    result = deepcopy(leaf)
    tightened = []
    bad = []
    for field in ('angles', 'positions', 'scalar'):
        values = []
        assert len(leaf[field]) == len(necessary[field])
        for index, ((a, b), (c, d)) in enumerate(zip(leaf[field], necessary[field])):
            low, high = max(a, c), min(b, d)
            if low != a or high != b:
                tightened.append(dict(field=field, key=index, before=[str(a), str(b)],
                    source=[str(c), str(d)], after=[str(low), str(high)]))
            if low > high:
                bad.append(dict(field=field, key=index, lower=str(low), upper=str(high)))
            values.append((low, high))
        result[field] = tuple(values)
    assert set(leaf['differences']) == set(necessary['differences']) and len(leaf['differences']) == 36
    differences = {}
    for pair, box in leaf['differences'].items():
        values = []
        for axis, ((a, b), (c, d)) in enumerate(zip(box, necessary['differences'][pair])):
            low, high = max(a, c), min(b, d)
            if low != a or high != b:
                tightened.append(dict(field='differences', key=list(pair)+[axis],
                    before=[str(a), str(b)], source=[str(c), str(d)], after=[str(low), str(high)]))
            if low > high:
                bad.append(dict(field='differences', key=list(pair)+[axis], lower=str(low), upper=str(high)))
            values.append((low, high))
        differences[pair] = tuple(values)
    result['differences'] = differences
    if not bad:
        EXACT.CORE.valid_state(result)
        H.interval_subset(leaf, result)
    return result, tightened, bad


def guard_screen(state):
    guards = [dict(name='accepted_shared_sharp_boundary_terminal',
                   literal=GUARDS.SHARP.evaluate_any_guard(state)),
              dict(name='accepted_full_angle_AHID_terminal', literal=GUARDS.FULL.evaluate(state)),
              dict(name='accepted_opposite_tilt_ABID_terminal', literal=COMPLETE.OPPOSITE.evaluate(state))]
    for extra in (7, 8):
        guards.append(dict(name='accepted_full_angle_AB_extra_terminal', extra=extra,
                           literal=COMPLETE.FULL.evaluate(state, extra)))
    return dict(results=guards, hits=[x for x in guards if x['literal']['status'].startswith('PASS_')])


def probe(state, adapter):
    result = D.probe(state, adapter, 4)
    if result['terminal'] is None:
        current = H.restore(result['current'], adapter)
        result['existing_guard_screen'] = guard_screen(current)
    else:
        result['existing_guard_screen'] = dict(results=[], hits=[])
    return result


def main():
    if not __debug__:
        raise RuntimeError('Exact assertions are required')
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    assert not args.output.exists()
    freeze = json.loads((HERE / 'SOURCE_BINDING.json').read_text())
    for path, expected in freeze['files'].items():
        assert sha(path) == expected, path
    assert sha(SNAPSHOT / 'SNAPSHOT_RECEIPT.json') == SNAPSHOT_SHA
    snap = json.loads((SNAPSHOT / 'SNAPSHOT_RECEIPT.json').read_text())
    for item in snap['members']:
        assert sha(SNAPSHOT / item['member']) == item['sha256']
    assert snap['current45_root_box_is_subset_of_external_root_box'] is True
    assert snap['external_candidate_arithmetic_freshly_replayed'] is False
    assert sha(H.REPORT) == H.REPORT_SHA and sha(H.TREE / 'manifest.json') == H.TREE_SHA
    old_report = json.loads(H.REPORT.read_text())
    for path, expected in old_report['source_sha256'].items():
        assert sha(path) == expected, path
    own_manifest = json.loads((H.TREE / 'manifest.json').read_text())
    own_root_entry = own_manifest['nodes'][0]
    assert sha(H.TREE / own_root_entry['file']) == own_root_entry['sha256']
    own_root = json.loads((H.TREE / own_root_entry['file']).read_text())
    assert own_root['record']['status'] == 'OPEN' and len(own_root['record']['rounds']) == 3
    assert own_root['record']['final']['path'] == own_root['initial']['path']
    cap = ROOT / 'b_work/recovery_20261105/extracted_b340/unpacked/b340_complete_original_package/accepted_repo/research/nine/computer_assisted/full_angle_common_side_row_v1'
    adapter = EXACT.Adapter(ROOT / 'b_work/b16a_I32_complete_H_checkpoint', cap)
    necessary = H.restore(own_root['record']['final'], adapter)
    candidate = json.loads((SNAPSHOT / 'candidate/manifest.json').read_text())
    assert sha(SNAPSHOT / 'candidate/manifest.json') == snap['candidate_manifest_sha256']
    outcomes = []
    for index in sorted(snap['open_leaf_indices']):
        entry = candidate['nodes'][index]
        node_path = SNAPSHOT / 'candidate' / entry['file']
        assert sha(node_path) == entry['sha256']
        node = json.loads(node_path.read_text())
        assert node['status'] == node['record']['status'] == 'OPEN' and node['children'] == []
        leaf = H.restore(node['record']['final'], adapter)
        baseline = probe(leaf, adapter)
        strengthened, changed, bad = intersect(leaf, necessary)
        conditional = None if bad else probe(strengthened, adapter)
        terminal = bool(bad) or conditional['terminal'] is not None or bool(conditional['existing_guard_screen']['hits'])
        baseline_terminal = baseline['terminal'] is not None or bool(baseline['existing_guard_screen']['hits'])
        outcome = dict(index=index, external_node_sha256=entry['sha256'],
            external_weighted_final_state_unverified=True, baseline=baseline,
            necessary_root_bound_intersection_changes=changed, empty_intersections=bad,
            strengthened=conditional, conditional_terminal=terminal,
            baseline_terminal=baseline_terminal,
            only_after_regional_root_intersection=terminal and not baseline_terminal)
        outcomes.append(outcome)
        print(json.dumps(dict(index=index, tightened_intervals=len(changed),
            empty_intersections=len(bad), baseline_terminal=baseline_terminal,
            conditional_terminal=terminal,
            existing_terminal=None if conditional is None else conditional['terminal'],
            guard_hits=[] if conditional is None else [x['name'] for x in conditional['existing_guard_screen']['hits']])), flush=True)
    adapter.recheck()
    for path, expected in old_report['source_sha256'].items():
        assert sha(path) == expected, path
    for item in snap['members']:
        assert sha(SNAPSHOT / item['member']) == item['sha256']
    for path, expected in freeze['files'].items():
        assert sha(path) == expected, path
    assert not any(x in sys.modules for x in ('numpy', 'scipy', 'highspy'))
    result = dict(schema='B16_external127_same_region_root_bound_screen_v1',
        status='PASS_CONDITIONAL_READ_ONLY_SAME_REGION_SCREEN',
        regional_scope='same complete closed I21/I22 rectangle only',
        external_snapshot_sha256=SNAPSHOT_SHA,
        external_candidate_manifest_sha256=snap['candidate_manifest_sha256'],
        necessary_root_manifest_sha256=H.TREE_SHA, necessary_root_full_report_sha256=H.REPORT_SHA,
        necessary_root_node_sha256=own_root_entry['sha256'],
        necessary_root_final=own_root['record']['final'],
        source_binding_sha256=sha(HERE / 'SOURCE_BINDING.json'),
        checked_candidate_open_leaves=len(outcomes),
        baseline_terminal_indices=[x['index'] for x in outcomes if x['baseline_terminal']],
        conditional_terminal_indices=[x['index'] for x in outcomes if x['conditional_terminal']],
        intersection_only_terminal_indices=[x['index'] for x in outcomes if x['only_after_regional_root_intersection']],
        outcomes=outcomes,
        external_full127_arithmetic_replay_still_required=True,
        regional_root_bounds_require_literal_same_domain_transport_before_use=True,
        no_equality_graft_claim=True, no_branch_or_auxiliary_predicate_transported=True,
        numerical_solver_called=False, active_tree_mutation=False,
        new_bound_family_installed=False, new_original_cells=0, new_masks=0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps(dict(status=result['status'], report_sha256=sha(args.output),
        baseline_terminal_indices=result['baseline_terminal_indices'],
        conditional_terminal_indices=result['conditional_terminal_indices'],
        intersection_only_terminal_indices=result['intersection_only_terminal_indices'])), flush=True)


if __name__ == '__main__':
    main()
