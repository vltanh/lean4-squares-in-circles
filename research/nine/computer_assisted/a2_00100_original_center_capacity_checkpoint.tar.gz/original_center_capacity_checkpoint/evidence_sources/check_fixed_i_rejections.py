#!/usr/bin/env python3
"""Semantic damaged controls for the complete f92 original-parent replay."""
from pathlib import Path
from fractions import Fraction as Q
import contextlib, hashlib, io, json, shutil, tempfile, traceback
import verify_fixed_i_parent as V

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/'b_macro/v2/results/negative-f92d74e712afa6be.json'
TILES=HERE/'fixed_i_grid/negative-f92d74e712afa6be'
UNION=HERE/'lower_i_union/results/negative-f92d74e712afa6be_lower_I_union.json'

def change(path,fn):
    value=json.loads(path.read_text());fn(value);path.write_text(json.dumps(value)+'\n')

def missing_tile(tiles,union):
    (tiles/'tile_63.json').unlink()

def shifted_shared_face(tiles,union):
    change(tiles/'tile_08.json',lambda x:x['I_box'][0].__setitem__(0,str(Q(x['I_box'][0][0])+Q(1,1<<30))))

def negative_weight(tiles,union):
    change(tiles/'tile_01.json',lambda x:x['terminal']['weights'][0].__setitem__(1,-1))

def damaged_physical_row(tiles,union):
    change(tiles/'tile_01.json',lambda x:x['terminal']['rows'][0].__setitem__('rhs',str(Q(x['terminal']['rows'][0]['rhs'])+1)))

def unjustified_induction_bound(tiles,union):
    change(union,lambda x:x['rounds'][0]['proposals'][0].__setitem__('upper',str(Q(x['rounds'][0]['proposals'][0]['upper'])-Q(1,10))))

def missing_lower_union_face(tiles,union):
    def mutate(x):
        endpoint=str(Q(x['prior']['I_union'][0][1])-Q(1,1<<30))
        x['prior']['I_union'][0][1]=endpoint
        x['additional_predicate']['center_rectangle'][0][1]=endpoint
    change(union,mutate)

if __name__=='__main__':
    results=[]
    for mutation in [missing_tile,shifted_shared_face,negative_weight,damaged_physical_row,unjustified_induction_bound,missing_lower_union_face]:
        with tempfile.TemporaryDirectory(prefix='n9_fixed_i_control_')as tmp:
            tmp=Path(tmp);tiles=tmp/'tiles';union=tmp/'union.json'
            shutil.copytree(TILES,tiles);shutil.copyfile(UNION,union);mutation(tiles,union)
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    V.verify(PARENT,tiles,union,HERE.parent/'current_proof')
            except (AssertionError,KeyError,ValueError)as error:
                frames=traceback.extract_tb(error.__traceback__)
                item={'damage':mutation.__name__,'status':'REJECTED','exception':type(error).__name__,
                      'at_function':frames[-1].name,'at_file':Path(frames[-1].filename).name,'at_line':frames[-1].lineno}
            else:raise AssertionError(('Damaged proof unexpectedly accepted',mutation.__name__))
            results.append(item);print(json.dumps(item),flush=True)
    report={'schema':'n9_fixed_i_semantic_rejection_controls_v1','status':'PASS',
            'rejected_controls':len(results),'controls':results,
            'checker_sha256':hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest(),
            'control_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'lean_lake_ci_run':False}
    (HERE/'fixed_i_parent_rejection_controls.json').write_text(json.dumps(report,indent=2)+'\n')
