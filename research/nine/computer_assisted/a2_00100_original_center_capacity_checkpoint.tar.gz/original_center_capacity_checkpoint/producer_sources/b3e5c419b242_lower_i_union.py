#!/usr/bin/env python3
"""One bounded full-union induction after the frozen 8x8 diagnostic.

This never creates a new tile or subdivides an existing one. The caller
is the union of tiles 0 and 8, which is itself one closed rectangle.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction as F

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'b_macro'))
import b_pass_v2 as B
M=B.M
PARENT='negative-f92d74e712afa6be'
SOURCE=HERE.parent/'b_macro/v2/results'/(PARENT+'.json')
OBJ=json.loads(SOURCE.read_text())
PATH=OBJ['path']
def loadbox(xs):return tuple(tuple(F(s)for s in q)for q in xs)
ANGLES=loadbox(OBJ['final_angles']);POS=loadbox(OBJ['final_positions'])
SCALAR=loadbox(OBJ['final_scalar'])
DIFF={tuple(d['pair']):loadbox(d['intervals'])for d in OBJ['final_differences']}
_,_,CHOICES=M.V.reconstruct(PATH)
xa,xb=POS[16];ya,yb=POS[17]
UNION=((xa,xa+(xb-xa)/4),(ya,ya+(yb-ya)/8))
for tile in [0,8]:
    data=json.loads((HERE/'fixed_i_grid'/PARENT/f'tile_{tile:02d}.json').read_text())
    assert data['status']=='OPEN'
    assert loadbox(data['I_box'])[1]==UNION[1]
assert loadbox(json.loads((HERE/'fixed_i_grid'/PARENT/'tile_00.json').read_text())['I_box'])[0][0]==UNION[0][0]
assert loadbox(json.loads((HERE/'fixed_i_grid'/PARENT/'tile_08.json').read_text())['I_box'])[0][1]==UNION[0][1]

def initial(cell):
    positions=list(POS);positions[16],positions[17]=UNION
    state={'id':cell['id'],'path':PATH,'angles':ANGLES,'positions':tuple(positions),
           'choices':CHOICES,'scalar':SCALAR}
    prior={'kind':'SOURCE_BOUND_V2_PARENT_PLUS_EXACT_UNION_OF_FROZEN_TILES_0_8',
           'file':str(SOURCE),'sha256':M.sha(SOURCE),'deductions':'requires complete v2 replay',
           'parent_id':PARENT,'I_union':M.render(UNION)}
    return state,prior,None

def collect(state,differences):
    merged=dict(DIFF)
    for pair,vals in differences.items():
        prior=merged[pair]
        merged[pair]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(prior,vals))
    return B.collect(state,merged)

if __name__=='__main__':
    M.initial=initial;M.collect=collect
    M.HERE=HERE/'lower_i_union';M.HERE.mkdir(exist_ok=True)
    M.VERSION='n9_whole_lower_i_union_five_round_diagnostic_v1'
    cell={'id':PARENT+'_lower_I_union','path':PATH}
    M.run(cell,5)
    dest=M.HERE/'results'/(cell['id']+'.json')
    record=json.loads(dest.read_text())
    record['scope']='COMPLETE_UNION_OF_FIXED_TILES_0_AND_8_ONLY; NOT_WHOLE_PARENT_BY_ITSELF'
    record['original_parent']=PARENT
    record['additional_predicate']={'original':'I','center_rectangle':M.render(UNION)}
    record['grid_status']='Frozen 8x8 cover unchanged; no further subdivision'
    record['accepted_new_cells']=0
    record['additional_sources']={str(p):M.sha(p)for p in [Path(__file__),Path(B.__file__),Path(B.P.__file__),Path(B.F.__file__),Path(B.A.__file__),Path(B.T.__file__),Path(B.S.__file__)]}
    dest.write_text(json.dumps(record,indent=2)+'\n')
    print('COMPLETE_LOWER_UNION_RESULT',record['status'],flush=True)
