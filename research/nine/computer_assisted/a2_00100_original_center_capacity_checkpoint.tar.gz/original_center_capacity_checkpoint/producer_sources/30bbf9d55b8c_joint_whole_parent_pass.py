#!/usr/bin/env python3
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import sys,json,hashlib,time,argparse,warnings
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from scipy.sparse import csr_matrix,hstack
from scipy.optimize._highspy import _core as H
HERE=Path(__file__).resolve().parent
BUNDLE=HERE/'shared_capacity_three_b_v4'
sys.path.insert(0,str(BUNDLE))
import verify_shared_bound as K
import altitude_capacity as A
sys.path.insert(0,str(HERE.parent/'rounded_support'))
import point_disk_rows as D
V=K.V
sys.path.insert(0,str(BUNDLE/'sources'))
import review_guarded_frame_bounds_independent as R
REG=HERE.parent/'lean4-squares-in-circles/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
PREFIX=HERE/'pair_support_open_checkpoint/physical_pilots/combined_bounds/prefixes'
SCALE=1<<40;ROUND=1<<20;EPS=F(1,2000)
VERSION='whole_parent_altitude_pointdisk_capacity_v1'
N=K;T=K

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def render(xs):return [[str(a),str(b)]for a,b in xs]
def render_diff(d):return [{'pair':list(k),'intervals':render(v)}for k,v in sorted(d.items())]
def ceil_grid(value):return F(-((-value*ROUND).numerator//(-value*ROUND).denominator),ROUND)
def terms(vals):return [[i,int(round(-float(x)*SCALE))]for i,x in enumerate(vals)if int(round(-float(x)*SCALE))>0]
def save(record):
 (HERE/'joint_results').mkdir(exist_ok=True);(HERE/'joint_results'/(record['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')

def initial(cell):
 path=cell['path'];angles,pos,choices=V.reconstruct(path)
 angles=tuple(map(tuple,angles));pos=tuple(map(tuple,pos));prior=PREFIX/(cell['id']+'.json')
 if not prior.exists():
  matches=list((HERE/'pair_support_open_checkpoint').rglob(cell['id']+'.json'))
  for p in matches:
   try:
    obj=json.loads(p.read_text())
    if obj.get('path')==path and 'rounds'in obj and all(all(len(p['objective'])==1 and p['objective'][0][0]<18 for p in rr['proposals']) for rr in obj['rounds']):prior=p;break
   except Exception:pass
 if prior.exists():
  obj=json.loads(prior.read_text());pos,count=K.coordinate_prior(obj,path,angles,pos,choices)
  source={'kind':'fresh_replayed_coordinate_prefix','file':str(prior),'sha256':sha(prior),'deductions':count}
 else:source={'kind':'original_path_only','deductions':0}
 return {'id':cell['id'],'path':path,'angles':angles,'positions':pos,'choices':choices,'scalar':K.analytic(angles)},source,None

def collect(state,differences):
 rows,absolute,terminal=R.collect_guarded(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'])
 if terminal:return rows,absolute,terminal,state['positions'],state['scalar'],differences,[]
 rows,absolute,pos,scalar,diffs,guards=K.rebuild(state['path'],state['angles'],state['positions'],state['choices'],state['scalar'],differences)
 extra,gg=A.generate_rows(diffs);rows+=extra;guards += [dict(extension_rule='altitude_capacity',**g)for g in gg]
 rows += D.generate_rows(scalar,diffs)
 return rows,absolute,None,pos,scalar,diffs,guards
def highs(rows,n):
 rr=[];cc=[];vv=[];bb=[]
 for i,(co,b,name) in enumerate(rows):
  for k,v in co:rr.append(i);cc.append(k);vv.append(float(v))
  rr.append(i);cc.append(n);vv.append(-1.);bb.append(float(b))
 mat=csr_matrix((vv,(rr,cc)),shape=(len(rows),n+1))
 lp=H.HighsLp();lp.num_col_=n+1;lp.num_row_=len(rows);lp.col_cost_=np.r_[np.zeros(n),1.];lp.col_lower_=np.r_[np.full(n,-np.inf),-1.];lp.col_upper_=np.full(n+1,np.inf);lp.row_lower_=np.full(len(rows),-np.inf);lp.row_upper_=np.array(bb)
 lp.a_matrix_.format_=H.MatrixFormat.kRowwise;lp.a_matrix_.start_=mat.indptr;lp.a_matrix_.index_=mat.indices;lp.a_matrix_.value_=mat.data
 h=H._Highs();h.setOptionValue('output_flag',False);h.setOptionValue('threads',1);h.setOptionValue('time_limit',20.);h.passModel(lp);return h

def run(cell,rounds=3):
 start=time.monotonic();state,prior,prior_tables=initial(cell);differences={};record={'schema':VERSION,'id':cell['id'],'path':cell['path'],'status':'OPEN','scope':'WHOLE_UNCHANGED_ORIGINAL_PARENT','new_branch_nodes':0,'maximum_new_rounds':rounds,'prior':prior,'rounds':[],
 'sources':{str(p):sha(p) for p in [Path(__file__),Path(N.__file__),Path(T.__file__),Path(V.__file__),Path(R.__file__),Path(A.__file__),Path(D.__file__)]}}
 if prior_tables is not None:
  name=cell['id']+'_prior_replay_tables.json';(HERE/'joint_results').mkdir(exist_ok=True);(HERE/'joint_results'/name).write_text(json.dumps(prior_tables,indent=2)+'\n');record['prior_printed_tables']=name
 print(cell['id'],'INITIAL_REPLAY_PASS',round(time.monotonic()-start,2),flush=True)
 for ri in range(rounds+1):
  rows,absolute,terminal,propagated,scalar,current_diff,guards=collect(state,differences)
  item={'round':ri,'angles_before':render(state['angles']),'positions_before':render(state['positions']),'scalar_before':render(state['scalar']),'differences_before':render_diff(differences),'propagated_positions':render(propagated),'physical_scalar_intersection':render(scalar),'effective_differences':render_diff(current_diff),'three_square_guards':guards,'rows':len(rows),'proposals':[]}
  if terminal:
   record.update(status='CANDIDATE_CLOSED',terminal={'kind':'exact_interval_or_accepted_terminal','label':terminal,'state':item});break
  h=highs(rows,len(absolute));h.run();status=h.getModelStatus()
  if status!=H.HighsModelStatus.kOptimal:record.update(solver_status=str(status));break
  solution=h.getSolution();phase=float(solution.col_value[-1]);item['phase_margin']=phase
  if phase>1e-8:
   ws=terms(solution.row_dual);co,b=R.weighted_sum(rows,absolute,ws);reserve=-b-sum(m*abs(c) for m,c in zip(absolute,co))
   if reserve>0:
    record.update(status='CANDIDATE_CLOSED',terminal={'kind':'positive_exact_reserve','state':item,'weights':ws,'reserve':str(reserve),'rows':R.printed_rows(rows,{i for i,w in ws}),'absolute_variable_bounds':list(map(str,absolute)),'weighted_coefficients':list(map(str,co)),'weighted_rhs':str(b)});break
   item['rejected_numeric_candidate']=str(reserve)
  if ri==rounds:record['final_test']=item;break
  h.changeColCost(len(absolute),0.);h.changeColBounds(len(absolute),0.,0.)
  targets=[]
  for k,(lo,hi) in enumerate(tuple(propagated)+tuple(scalar)):
   for sg in [-1,1]:targets.append(('scalar',k,sg,[(k,sg)],hi if sg==1 else -lo))
  for (i,j),ds in sorted(current_diff.items()):
   for ax,(lo,hi) in enumerate(ds):
    for sg in [-1,1]:targets.append(('difference',(i,j,ax),sg,[(2*j+ax,sg),(2*i+ax,-sg)],hi if sg==1 else -lo))
  nextpos=[list(p) for p in propagated];nextscalar=[list(p) for p in scalar];nextdiff={p:[list(q) for q in v] for p,v in current_diff.items()};previous=[];used=set();LPfail=0
  for kind,key,sg,objective,old in targets:
   for k,co in previous:h.changeColCost(k,0.)
   for k,co in objective:h.changeColCost(k,-float(co))
   previous=objective;h.setOptionValue('time_limit',h.getRunTime()+3.);h.run()
   if h.getModelStatus()!=H.HighsModelStatus.kOptimal:LPfail+=1;continue
   optimum=h.getObjectiveValue()
   if float(old)+optimum<float(EPS):continue
   ws=terms(h.getSolution().row_dual);co,b=R.weighted_sum(rows,absolute,ws)
   for k,c in objective:co[k]-=F(c)
   correction=sum(m*abs(c) for m,c in zip(absolute,co));proved=b+correction;upper=ceil_grid(proved)
   if old-upper<EPS:continue
   proposal={'kind':kind,'key':list(key) if isinstance(key,tuple) else key,'sign':sg,'objective':[[k,c] for k,c in objective],'upper':str(upper),'proved_upper':str(proved),'weights':ws,'summed_rhs':str(b),'residual_coefficients':[[k,str(c)] for k,c in enumerate(co) if c],'residual_correction':str(correction)}
   item['proposals'].append(proposal);used.update(i for i,w in ws)
   if kind=='scalar':target=nextpos[key] if key<18 else nextscalar[key-18]
   else:target=nextdiff[(key[0],key[1])][key[2]]
   if sg==1:target[1]=min(target[1],upper)
   else:target[0]=max(target[0],-upper)
  item['printed_rows']=R.printed_rows(rows,used);item['absolute_variable_bounds']=list(map(str,absolute));item['numeric_objectives_without_result']=LPfail
  positions=tuple(map(tuple,nextpos));scalar=tuple(map(tuple,nextscalar));differences={p:tuple(map(tuple,v)) for p,v in nextdiff.items()}
  if any(a>b for a,b in positions+scalar) or any(a>b for v in differences.values() for a,b in v):
   record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal={'kind':'proved_empty_interval'});break
  angles,contradiction,identities=R.infer_angles(state['angles'],scalar);item['physical_frame_inferences']=identities
  if contradiction:
   record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal={'kind':contradiction});break
  analytic=R.analytic_frames(angles);scalar=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(scalar,analytic))
  if any(a>b for a,b in scalar):
   record['rounds'].append(item);record.update(status='CANDIDATE_CLOSED',terminal={'kind':'proved_empty_analytic_frame'});break
  state.update(angles=angles,positions=positions,scalar=scalar)
  item.update(angles_after=render(angles),positions_after=render(positions),scalar_after=render(scalar),differences_after=render_diff(differences));record['rounds'].append(item);record['seconds']=time.monotonic()-start;save(record)
  print(cell['id'],'ROUND',ri,'proved',len(item['proposals']),'triple_rows',len(guards),'seconds',round(record['seconds'],2),flush=True)
  if not item['proposals']:break
 record.update(seconds=time.monotonic()-start,final_angles=render(state['angles']),final_positions=render(state['positions']),final_scalar=render(state['scalar']),final_differences=render_diff(differences));save(record);print('RESULT',cell['id'],record['status'],round(record['seconds'],2),flush=True);return {k:v for k,v in record.items() if k in ['id','status','seconds','new_branch_nodes']}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--id');ap.add_argument('--rounds',type=int,default=5);a=ap.parse_args();assert 0<=a.rounds<=8
 cells=json.loads(REG.read_text())['cells']
 selected=[c for c in cells if c['status']=='OPEN'and(c['id']==a.id if a.id else not(c['sign']=='negative'and c['path'][1][-1]==0))]
 for c in selected:
  if (HERE/'joint_results'/(c['id']+'.json')).exists():continue
  try:run(c,a.rounds)
  except Exception as e:
   import traceback;print(c['id'],'ERROR',traceback.format_exc(),flush=True)
if __name__=='__main__':main()
