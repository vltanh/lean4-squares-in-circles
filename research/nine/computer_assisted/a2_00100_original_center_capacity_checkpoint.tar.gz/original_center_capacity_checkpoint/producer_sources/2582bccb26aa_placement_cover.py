#!/usr/bin/env python3
"""Exact complete one-original center-box covering by other original incircles.
A complete cover is a whole-parent terminal, not a numeric point exclusion.
"""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json,sys,hashlib
RHO2=F(91,60)**2

def far2(rect,other):
    return sum(max(abs(a-c),abs(a-d),abs(b-c),abs(b-d))**2 for (a,b),(c,d)in zip(rect,other))
def near2(rect):return sum(F(0)if a<=0<=b else min(a*a,b*b)for a,b in rect)
def encode(rect):return [[str(a),str(b)]for a,b in rect]
def cover(positions,target,budget=10000,maxdepth=20):
    boxes=[positions[2*i:2*i+2]for i in range(9)];root=boxes[target];leaves=[];nodes=0;pending=[]
    def rec(rect,path):
        nonlocal nodes
        nodes+=1
        if nodes>budget:pending.append({'path':path,'box':encode(rect),'reason':'budget'});return None
        best=min((far2(rect,b),j)for j,b in enumerate(boxes)if j!=target)
        if best[0]<1:
            leaf={'path':path,'box':encode(rect),'kind':'incircle','original':best[1],'squared_distance_upper':str(best[0]),'reserve':str(1-best[0])};leaves.append(leaf);return leaf
        q=near2(rect)
        if q>RHO2:
            leaf={'path':path,'box':encode(rect),'kind':'outside_center_disk','squared_distance_lower':str(q),'reserve':str(q-RHO2)};leaves.append(leaf);return leaf
        if len(path)>=maxdepth:pending.append({'path':path,'box':encode(rect),'reason':'depth'});return None
        axis=max(range(2),key=lambda k:rect[k][1]-rect[k][0]);a,b=rect[axis];m=(a+b)/2
        for child,interval in enumerate(((a,m),(m,b))):
            box=[tuple(x)for x in rect];box[axis]=interval;rec(tuple(box),path+[[axis,child]])
    rec(tuple(map(tuple,root)),[])
    return {'status':'COMPLETE'if not pending else'OPEN','target_original':target,'positions':encode(positions),'root_box':encode(root),'nodes':nodes,'leaves':leaves,'pending':pending,'depth':max((len(l['path'])for l in leaves),default=0),'witness_counts':dict(Counter(str(l.get('original',l['kind']))for l in leaves))}

def main():
    recordfile=Path(sys.argv[1]);record=json.loads(recordfile.read_text());target=int(sys.argv[2])if len(sys.argv)>2 else 8
    rr=record['rounds'][-1];positions=tuple(tuple(F(x)for x in p)for p in rr['positions_after'])
    r=cover(positions,target)
    r.update(original_id=record['id'],proof_record_sha256=hashlib.sha256(recordfile.read_bytes()).hexdigest(),completed_rounds=len(record['rounds']),new_branch_nodes_in_original_proof=0,whole_mask_closed=False)
    out=recordfile.with_name(recordfile.stem+'_placement_cover.json');out.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items()if k not in('positions','leaves','pending') }));print('pending',len(r['pending']))
if __name__=='__main__':main()
