#!/usr/bin/env python3
"""Replay every complete original-parent proof in this portable portfolio."""
import hashlib,importlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    frozen=json.loads((HERE/'SHA256_MANIFEST.json').read_text())
    assert frozen['schema']=='n9_original_center_capacity_immutable_files_v1'
    for file,expected in frozen['files'].items():assert sha(HERE/file)==expected,('payload_file_changed',file)
    index=json.loads((HERE/'portfolio_index.json').read_text());entries=index['entries'];ids=[e['id']for e in entries]
    assert len(ids)==len(set(ids))and entries
    from verify_joint_original import replay
    out=HERE/'new_reviews';out.mkdir(exist_ok=True);reports=[];totals={'prior_coordinate_deductions':0,'new_exact_deductions':0,'printed_rows_checked':0,'complete_terminal_domains':0,'center_cover_rectangles':0,'center_cover_internal_splits':0,'fixed_grid_tiles':0,'fixed_grid_union_domains':0}
    for entry in entries:
        certificate=HERE/entry['certificate'];assert sha(certificate)==entry['certificate_sha256']
        kind=entry['kind']
        if kind=='fixed_grid_union':
            assert entry['checker']in('verify_fixed_i_parent.py','verify_fixed_i_parent_v2.py')
            verify=importlib.import_module(entry['checker'][:-3]).verify
            assert sha(HERE/entry['union'])==entry['union_sha256']
            report=verify(certificate,HERE/entry['tiles'],HERE/entry['union'],HERE,out/(entry['id']+'_complete.json'))
            prior=report['parent_proof'];totals['prior_coordinate_deductions']+=prior['prior_coordinate_deductions'];totals['new_exact_deductions']+=prior['new_deductions']+report['lower_union_deductions'];totals['printed_rows_checked']+=prior['printed_rows_checked']+report['new_printed_rows_checked']
            totals['complete_terminal_domains']+=report['static_tiles_checked']+1;totals['fixed_grid_tiles']+=64;totals['fixed_grid_union_domains']+=1
        else:
            assert kind in('dual','center_cover')
            cover=HERE/entry['cover']if kind=='center_cover'else None
            if cover is not None:assert sha(cover)==entry['cover_sha256']
            report=replay(certificate,cover)
            totals['prior_coordinate_deductions']+=report['prior_coordinate_deductions'];totals['new_exact_deductions']+=report['new_deductions'];totals['printed_rows_checked']+=report['printed_rows_checked']
            if kind=='center_cover':
                c=report['center_cover'];totals['complete_terminal_domains']+=c['terminal_rectangles'];totals['center_cover_rectangles']+=c['terminal_rectangles'];totals['center_cover_internal_splits']+=c['internal_rectangle_splits']
            else:totals['complete_terminal_domains']+=1
        assert report['status']=='PASS_COMPLETE_ORIGINAL_PARENT'and report['id']==entry['id']
        reports.append({'id':report['id'],'kind':kind,'status':report['status']})
    summary={'status':'PASS_ALL_COMPLETE_ORIGINAL_PARENTS','complete_original_ids':ids,'complete_original_count':len(ids),'before':index['baseline_cells'],'after':{'closed':index['baseline_cells']['closed']+len(ids),'open':index['baseline_cells']['open']-len(ids)},'whole_masks':index['whole_masks'],'totals':totals,'reports':reports,'unsupported_rules_accepted':False,'lean_lake_ci_run':False,'human_or_kernel_verification':False}
    (out/'portable_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
    return summary
if __name__=='__main__':main()
