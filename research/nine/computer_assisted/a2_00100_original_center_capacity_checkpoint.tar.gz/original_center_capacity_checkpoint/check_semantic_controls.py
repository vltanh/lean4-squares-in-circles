#!/usr/bin/env python3
"""Targeted rejection checks for the new rules and complete cover contract."""
import copy,hashlib,json,tempfile
from pathlib import Path
import verify_joint_original as V
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def candidate(name):return json.loads((HERE/'certificates'/(name+'.json')).read_text())

def damage_row(r,prefix):
    allrows=[z for rr in r['rounds']for z in rr['printed_rows']]
    if 'terminal'in r:allrows+=r['terminal'].get('rows',[])
    row=next(z for z in allrows if z['name'].startswith(prefix));row['coefficients'][0][1]='99'
def point(r):damage_row(r,'original_point_incircle_')
def directional(r):damage_row(r,'directional_support_gap_')
def altitude(r):
    rows=[z for rr in r['rounds']for z in rr['printed_rows']]+r['terminal']['rows']
    row=next(z for z in rows if z['name']=='original_stronger_altitude_capacity_1_8_3')
    row['name']='original_stronger_altitude_capacity_1_6_3'
def bound(r):r['rounds'][0]['proposals'][0]['upper']='-999'
def path(r):r['path']=r['path'][:-1]
def source(r):r['additional_sources'][next(iter(r['additional_sources']))]='0'*64

controls=[('changed_point_incircle_coefficient','positive-8f760b2d708ad21d',point),
 ('changed_directional_support_coefficient','positive-3da90694b58b6ef7',directional),
 ('unproved_altitude_middle_original','negative-493c2b626cdbf986',altitude),
 ('unproved_installed_bound','positive-8f760b2d708ad21d',bound),
 ('changed_original_parent','positive-8f760b2d708ad21d',path),
 ('changed_additional_source','negative-a3ab8823d7fe0fa6',source)]
results=[]
with tempfile.TemporaryDirectory()as tmp:
    d=Path(tmp)
    for name,ident,mutate in controls:
        r=candidate(ident);mutate(r);file=d/(name+'.json');file.write_text(json.dumps(r))
        cover=None
        original_cover=HERE/'covers'/(ident+'_placement_cover.json')
        if original_cover.exists():
            c=json.loads(original_cover.read_text());c['proof_record_sha256']=sha(file)
            cover=d/(name+'_cover.json');cover.write_text(json.dumps(c))
        try:V.replay(file,cover)
        except (AssertionError,KeyError,ValueError,IndexError)as e:results.append({'control':name,'status':'REJECTED','reason':str(e)[:220]})
        else:raise AssertionError('damaged certificate accepted: '+name)
    ident='positive-3b5d35fda8ec4119';c=json.loads((HERE/'covers'/(ident+'_placement_cover.json')).read_text());c['leaves'].pop()
    cover=d/'missing_cover_child.json';cover.write_text(json.dumps(c))
    try:V.replay(HERE/'certificates'/(ident+'.json'),cover)
    except (AssertionError,KeyError,ValueError,IndexError)as e:results.append({'control':'missing_closed_cover_child','status':'REJECTED','reason':str(e)[:220]})
    else:raise AssertionError('incomplete cover accepted')
report={'status':'PASS','damaged_controls_rejected':len(results),'controls':results}
(HERE/'new_reviews/semantic_controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
