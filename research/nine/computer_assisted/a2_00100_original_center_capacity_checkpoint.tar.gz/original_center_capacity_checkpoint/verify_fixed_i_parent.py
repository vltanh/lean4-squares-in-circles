#!/usr/bin/env python3
"""Independent exact replay of one complete fixed original via an 8x8 cover.

No discovery producer, optimizer, point generator, or grid driver is imported.
The accepted original geometry and the separately implemented joint physical
row checker are reused. Every child premise, row, scalar induction and the
closed-face union is checked here. Requires Python standard library only.
"""
import argparse, hashlib, json, sys, time
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path

HERE=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def boxes(value):return tuple(tuple(Q(v)for v in pair)for pair in value)

def verify(parent_path,tiles_dir,union_path,joint_root,out_path=None):
    started=time.monotonic()
    parent_path,tiles_dir,union_path,joint_root=map(Path,(parent_path,tiles_dir,union_path,joint_root))
    sys.path.insert(0,str(joint_root))
    import verify_joint_original as J
    K=J.K
    # This callback replays every original-parent deduction; a saved report
    # or unverified declared final state is never accepted as the premise.
    parent_report,parent=J.replay(parent_path,allow_open=True,return_state=True)
    assert parent_report['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'
    assert parent['id']=='negative-f92d74e712afa6be'
    ident=parent['id'];path=parent['path'];angles=parent['angles']
    scalar=parent['scalar'];choices=parent['choices'];basepos=parent['positions']
    parentdiff=parent['differences']
    manifest=json.loads((tiles_dir/'manifest.json').read_text())
    assert manifest['schema']=='n9_fixed_i_center_8x8_diagnostic_v1'
    assert manifest['id']==ident and manifest['path']==path
    assert manifest['parent_sha256']==digest(parent_path)
    assert manifest['grid_size']==[8,8] and manifest['adaptive_splits']==0
    assert manifest['additional_bound_rounds_per_tile']==0
    assert manifest['static_dual_tests_per_tile']==1
    xa,xb=basepos[16];ya,yb=basepos[17]
    assert boxes(manifest['covered_box'])==((xa,xb),(ya,yb))
    assert xa<xb and ya<yb
    for source,sha in manifest['sources'].items():assert digest(J.local_source(source))==sha,('grid_source_changed',source)
    expected_files={f'tile_{i:02d}.json'for i in range(64)}
    assert {p.name for p in tiles_dir.glob('tile_*.json')}==expected_files

    def rebuild(pos,oldscalar,oldangles,differences):
        # This preliminary collector is the frozen physical original
        # constructor, not the new producer's early-terminal function.
        _,_,early=K.collect_rows(K.V,path,oldangles,pos,choices)
        if early:return None,None,early,None,None,None,None
        base,bounds,prop,phys,diffs,guards=K.rebuild(path,oldangles,pos,choices,oldscalar,differences)
        return base,bounds,None,prop,phys,diffs,guards

    def check_state(saved,prop,phys,diffs,guards):
        assert boxes(saved['propagated_positions'])==prop
        assert boxes(saved['physical_scalar_intersection'])==phys
        assert saved['effective_differences']==K.diffview(diffs)
        assert saved['three_square_guards'][:len(guards)]==guards

    def check_dual(saved,terminal,base,bounds,phys,diffs,oldangles):
        printed=terminal['rows']
        rows,names=J.rows_for_record(dict(saved,printed_rows=printed),base,phys,diffs,oldangles)
        used={k for k,w in terminal['weights']}
        assert used=={r['index']for r in printed}
        co,rhs=K.sum_rows(rows,bounds,terminal['weights'])
        reserve=-rhs-sum(m*abs(c)for m,c in zip(bounds,co))
        assert reserve>0 and reserve==Q(terminal['reserve'])
        assert co==list(map(Q,terminal['weighted_coefficients']))
        assert rhs==Q(terminal['weighted_rhs'])
        assert list(map(str,bounds))==terminal['absolute_variable_bounds']
        return reserve,len(used),names

    terminal_counts=Counter();tile_reports=[];used_rules=[];printed_count=0
    exact_boxes={};tile_hashes={};reserves=[]
    for i in range(64):
        file=tiles_dir/f'tile_{i:02d}.json';saved=json.loads(file.read_text());tile_hashes[file.name]=digest(file)
        ix,iy=divmod(i,8)
        x=(xa+(xb-xa)*ix/8,xa+(xb-xa)*(ix+1)/8)
        y=(ya+(yb-ya)*iy/8,ya+(yb-ya)*(iy+1)/8)
        assert saved['tile']==i and saved['ix']==ix and saved['iy']==iy and saved['parent_id']==ident
        assert boxes(saved['I_box'])==(x,y)
        exact_boxes[i]=(x,y)
        if i in (0,8):
            assert saved['status']=='OPEN'
            continue
        assert saved['status']=='CANDIDATE_CLOSED'
        pos=list(basepos);pos[16]=x;pos[17]=y;pos=tuple(pos)
        base,bounds,early,prop,phys,diffs,guards=rebuild(pos,scalar,angles,parentdiff)
        terminal=saved['terminal']
        if early:
            assert terminal['kind']=='exact_interval_or_accepted_terminal' and terminal['label']==early
            terminal_counts[early]+=1
            tile_reports.append({'tile':i,'kind':'frozen_original_geometric_terminal','label':early})
        else:
            assert terminal['kind']=='positive_exact_reserve'
            check_state(saved,prop,phys,diffs,guards)
            reserve,used,names=check_dual(saved,terminal,base,bounds,phys,diffs,angles)
            reserves.append(reserve);printed_count+=used;used_rules+=names
            terminal_counts['positive_exact_reserve']+=1
            tile_reports.append({'tile':i,'kind':'positive_exact_reserve','reserve':str(reserve),'printed_rows':used})
        print(ident,'PASS STATIC TILE',i,flush=True)

    # Closed rectangles 0 and 8 are adjacent with the same vertical range.
    # Their exact union includes their shared face and is one rectangle.
    assert exact_boxes[0][0][1]==exact_boxes[8][0][0]
    assert exact_boxes[0][1]==exact_boxes[8][1]
    union=((exact_boxes[0][0][0],exact_boxes[8][0][1]),exact_boxes[0][1])
    assert union==((xa,xa+(xb-xa)/4),(ya,ya+(yb-ya)/8))
    record=json.loads(union_path.read_text())
    assert record['schema']=='n9_whole_lower_i_union_five_round_diagnostic_v1'
    assert record['id']==ident+'_lower_I_union' and record['path']==path
    assert record['status']=='CANDIDATE_CLOSED'
    assert record['scope']=='COMPLETE_UNION_OF_FIXED_TILES_0_AND_8_ONLY; NOT_WHOLE_PARENT_BY_ITSELF'
    assert record['original_parent']==ident
    assert record['new_branch_nodes']==0 and record['maximum_new_rounds']==5 and len(record['rounds'])<=5
    assert record['prior']['kind']=='SOURCE_BOUND_V2_PARENT_PLUS_EXACT_UNION_OF_FROZEN_TILES_0_8'
    assert record['prior']['sha256']==digest(parent_path) and record['prior']['parent_id']==ident
    assert boxes(record['prior']['I_union'])==union
    assert record['additional_predicate']['original']=='I'
    assert boxes(record['additional_predicate']['center_rectangle'])==union
    sources=dict(record['sources'])
    for source,sha in record['additional_sources'].items():
        assert source not in sources or sources[source]==sha;sources[source]=sha
    for source,sha in sources.items():assert digest(J.local_source(source))==sha,('union_source_changed',source)

    pos=list(basepos);pos[16],pos[17]=union;pos=tuple(pos)
    oldangles=angles;oldscalar=scalar;difference={};deductions=0;round_reports=[]
    # The producer retained the original parent's relational bounds on
    # every round. Re-establish that exact intersection independently.
    def inherited_intersection(current):
        merged=dict(parentdiff)
        for pair,intervals in current.items():
            assert pair in merged
            merged[pair]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(merged[pair],intervals))
        assert all(a<=b for intervals in merged.values()for a,b in intervals)
        return merged

    for ri,rr in enumerate(record['rounds']):
        assert rr['round']==ri
        assert boxes(rr['angles_before'])==oldangles and boxes(rr['positions_before'])==pos and boxes(rr['scalar_before'])==oldscalar
        assert rr['differences_before']==K.diffview(difference)
        base,bounds,early,prop,phys,diffs,guards=rebuild(pos,oldscalar,oldangles,inherited_intersection(difference))
        assert early is None
        check_state(rr,prop,phys,diffs,guards)
        assert list(map(str,bounds))==rr['absolute_variable_bounds']
        rows,names=J.rows_for_record(rr,base,phys,diffs,oldangles);used_rules+=names
        newpos=[list(v)for v in prop];newscalar=[list(v)for v in phys]
        newdiff={pair:[list(v)for v in intervals]for pair,intervals in diffs.items()}
        used=set()
        for proposal in rr['proposals']:
            upper=K.audit_bound(rows,bounds,proposal)
            sign=proposal['sign'];key=proposal['key'];assert sign in(-1,1)
            if proposal['kind']=='scalar':
                assert type(key)is int and 0<=key<54
                assert proposal['objective']==[[key,sign]]
                target=newpos[key]if key<18 else newscalar[key-18]
            else:
                assert proposal['kind']=='difference'and len(key)==3
                i,j,axis=key;assert 0<=i<j<9 and axis in(0,1)
                assert proposal['objective']==[[2*j+axis,sign],[2*i+axis,-sign]]
                target=newdiff[i,j][axis]
            if sign==1:target[1]=min(target[1],upper)
            else:target[0]=max(target[0],-upper)
            used.update(i for i,w in proposal['weights']);deductions+=1
        assert used=={r['index']for r in rr['printed_rows']}
        printed_count+=len(used)
        pos=tuple(map(tuple,newpos));oldscalar=tuple(map(tuple,newscalar))
        difference={pair:tuple(map(tuple,intervals))for pair,intervals in newdiff.items()}
        assert all(a<=b for a,b in pos+oldscalar)
        assert all(a<=b for intervals in difference.values()for a,b in intervals)
        oldangles=K.angles_from_scalar(oldangles,oldscalar,rr['physical_frame_inferences'])
        physical=K.analytic(oldangles)
        oldscalar=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(oldscalar,physical))
        assert all(a<=b for a,b in oldscalar)
        assert boxes(rr['angles_after'])==oldangles and boxes(rr['positions_after'])==pos and boxes(rr['scalar_after'])==oldscalar
        assert rr['differences_after']==K.diffview(difference)
        round_reports.append({'round':ri,'deductions':len(rr['proposals']),'printed_rows':len(used)})
        print(ident,'PASS COMPLETE LOWER UNION ROUND',ri,len(rr['proposals']),flush=True)

    terminal=record['terminal'];rr=terminal['state']
    assert terminal['kind']=='positive_exact_reserve'and rr['round']==len(record['rounds'])
    assert boxes(rr['angles_before'])==oldangles and boxes(rr['positions_before'])==pos and boxes(rr['scalar_before'])==oldscalar
    assert rr['differences_before']==K.diffview(difference)
    base,bounds,early,prop,phys,diffs,guards=rebuild(pos,oldscalar,oldangles,inherited_intersection(difference))
    assert early is None
    check_state(rr,prop,phys,diffs,guards)
    reserve,used,names=check_dual(rr,terminal,base,bounds,phys,diffs,oldangles)
    reserves.append(reserve);printed_count+=used;used_rules+=names
    assert boxes(record['final_angles'])==oldangles and boxes(record['final_positions'])==pos and boxes(record['final_scalar'])==oldscalar
    assert record['final_differences']==K.diffview(difference)
    assert len(tile_reports)==62

    # No tile is sampled: the 62 proved rectangles plus this adjacent
    # two-rectangle union cover the full original I-center rectangle.
    # Every other original variable keeps its entire proved parent domain.
    report={
        'schema':'n9_complete_original_fixed_i_grid_replay_v1',
        'id':ident,'status':'PASS_COMPLETE_ORIGINAL_PARENT','whole_original_parent_closed':True,
        'whole_mask_closed':False,'original_path_sha256':hashlib.sha256(json.dumps(path,separators=(',',':')).encode()).hexdigest(),
        'parent_proof':parent_report,'grid_size':[8,8],'all_64_tiles_accounted_for':True,
        'static_tiles_checked':62,'static_terminal_counts':dict(terminal_counts),
        'static_tile_reports':tile_reports,'static_tile_sha256':tile_hashes,
        'lower_union_tiles':[0,8],'lower_union':[[str(a),str(b)]for a,b in union],
        'lower_union_deductions':deductions,'lower_union_rounds':round_reports,
        'lower_union_terminal_rows':used,'lower_union_positive_reserve':str(reserve),
        'least_positive_reserve':str(min(reserves)),'new_printed_rows_checked':printed_count,
        'independently_rebuilt_new_rules':used_rules,'unsupported_rules_accepted':False,
        'grid_manifest_sha256':digest(tiles_dir/'manifest.json'),'union_certificate_sha256':digest(union_path),
        'verifier_sha256':digest(__file__),'joint_verifier_sha256':digest(J.__file__),
        'independent_rules_sha256':digest(joint_root/'independent_all_rules.py'),
        'seconds':time.monotonic()-started,'lean_lake_ci_run':False,'human_or_kernel_verification':False,
    }
    if out_path is not None:Path(out_path).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in('parent_proof','static_tile_reports','static_tile_sha256','independently_rebuilt_new_rules')}),flush=True)
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--parent',default=str(HERE.parent/'b_macro/v2/results/negative-f92d74e712afa6be.json'))
    ap.add_argument('--tiles',default=str(HERE/'fixed_i_grid/negative-f92d74e712afa6be'))
    ap.add_argument('--union',default=str(HERE/'lower_i_union/results/negative-f92d74e712afa6be_lower_I_union.json'))
    ap.add_argument('--joint-root',default=str(HERE.parent/'current_proof'))
    ap.add_argument('--out',default=str(HERE/'fixed_i_parent_exact_replay.json'))
    args=ap.parse_args()
    verify(args.parent,args.tiles,args.union,args.joint_root,args.out)
