# Complete original-center capacity portfolio

This portable package supplies complete proofs for nine original IDs listed in
`portfolio_index.json`, against the immutable register at PR 11 commit
`cab1367cd3792ff73034a81e3017cec2779b6cf1`. The register starts with 174 CLOSED
and 57 OPEN cells. These nine distinct closures give 183 CLOSED and 48 OPEN.
Every parent retains its exact original path, all nine squares, all 36 physical
pairs, all 36 original corner conditions, marked cones, the strict CD bit and
the strict-radius caller.

Run the entire exact replay with standard-library Python:

    python verify_all.py

No optimizer, external package, Lean, Lake or CI is needed for replay.
Discovery used numeric optimization to propose deductions. Each accepted
bound is reconstructed as an exact nonnegative rational sum with outward
rounding and a paid coefficient residual. Original physical-frame identities
and all simultaneous state transitions are independently checked.

## Complete parent domains

The portfolio contains three kinds of terminal proof:

1. A whole-parent rational contradiction after a finite bound induction.
   A8f and B ab8 also have short original-pair distance contradictions in the
   hand proofs.
2. A complete finite cover of the original I-center rectangle. Each leaf
   conflicts with another unchanged original incircle or lies outside the
   proved original-center disk. The independent checker verifies every
   shared face and both closed children at each split.
3. A fixed 8 by 8 I-center partition. Every tile outside a specified Cartesian
   rectangle closes by an exact physical contradiction. One complete bound
   induction excludes that entire rectangle, including every pending tile.
   All 64 closed tiles are accounted for before the original is credited.
   Each union certificate alone is only a proof for its indicated rectangle.

The two center covers and three fixed grids are finite proof tables inside
original cells. They create no new original IDs, masks, positional roots or
roadmap gates. The all-mask ledger remains 8 CLOSED and 24 OPEN. Mask 001/00,
its reversal 100/00 and the unrestricted theorem remain OPEN.

## Files and acceptance

`certificates/` contains exact printed bound and terminal tables. `covers/`
and `fixed_grid_*/` contain complete center partitions. `proofs/` contains
physical hand derivations, original caller and coverage documents, and short
terminals. `source_bindings.json` maps original search-machine paths to
immutable delivered source bytes. The historical producer paths are
identifiers; the independent checker uses the portable local mappings.

`shared_capacity_three_b_v4/` contains the minimal unchanged accepted
baseline needed by its own `verify_index()`, including its three earlier B
certificates and their source bindings. Those certificates bind dependencies
and are not newly counted originals. Unsuccessful search forests and partial
trials are omitted.

`SHA256_MANIFEST.json` binds every immutable source, certificate, proof and
accepted report. Replay outputs go to `new_reviews/`, excluded from that
manifest so repeated replay can regenerate timings without changing the
frozen evidence. `accepted_reports/` contains the saved complete checks.
Both `sources` and `additional_sources` recorded by every producer are
verified. Checkers reconstruct the new physical rows independently and do
not import the new discovery producers.

The replay checks exact arithmetic, physical-row reconstruction, complete
original paths, guard entailments, source identity, bound induction and
finite coverage. No human-only derivation or proof-kernel verification is
claimed. The hand proofs explain why the reconstructed inequalities follow
from the same original physical configuration.

Optional semantic rejection checks can be run with:

    python check_semantic_controls.py

These controls change a point/incircle coefficient, a directional-support
coefficient, an altitude premise, an installed bound, an original path, an
additional source binding, or a required closed cover child. Every altered
certificate must be rejected.
