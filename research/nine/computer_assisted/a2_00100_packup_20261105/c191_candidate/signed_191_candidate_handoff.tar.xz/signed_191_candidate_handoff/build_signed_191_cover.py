"""Bounded discovery for the complete signed-height Cb882/191 scalar domain.

The output is candidate evidence only; independent scalar and physical replay
must precede any whole-original conclusion. Every accepted box also passes an
exact integer Bernstein check inside this untrusted producer.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import comb
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import numpy as np
from scipy.optimize import linprog
import json, time, hashlib

HERE=Path(__file__).resolve().parent
OUT=HERE/'signed_191_scalar'
ROOT=(F(1,23),F(5,12),F(5,12))
DEG=6; SIDE=7; SIZE=343; SCALE=5888
ZERO=(0,0,0)
EXPS=tuple(product(range(SIDE),repeat=3))
MAX_NODES=500; MAX_LPS=1500
NODES=0; LPS=0

def con(c):return {ZERO:int(c)}
def var(i,c=1,d=1):
    e=[0]*3;e[i]=d;return {tuple(e):int(c)}
def add(*ps):
    out={}
    for p in ps:
        for e,c in p.items():out[e]=out.get(e,0)+c
    return {e:c for e,c in out.items()if c}
def scale(p,c):
    return {e:v*c for e,v in p.items()if v*c}
def mul(p,q):
    out={}
    for e,c in p.items():
        for f,d in q.items():
            g=tuple(a+b for a,b in zip(e,f));assert max(g)<=DEG
            out[g]=out.get(g,0)+c*d
    return {e:c for e,c in out.items()if c}
def prod(ps):
    out=con(1)
    for p in ps:out=mul(out,p)
    return out
D=[add(con(1),var(i,-1,4))for i in range(3)]
FULL=prod(D)

def features(signs,bi_owner,id_owner,id_axis):
    assert signs[2]==-1 and bi_owner in(0,1)and id_owner in(1,2)
    extra=con(1)if id_axis==0 else var(id_owner,2)
    base=scale(mul(FULL,extra),-2*SCALE)
    absolute=[]
    for left,right,owner,axis in ((0,1,bi_owner,0),(1,2,id_owner,id_axis)):
        other=right if owner==left else left
        one=add(con(1),mul(var(left,signs[left]),var(right,signs[right])))
        delta=add(var(left,signs[left]),var(right,-signs[right]))
        if axis==0:
            rem=prod([add(con(1),var(owner,1,2)),add(con(1),var(other,-1,2))]
                     +[D[k]for k in range(3)if k not in(left,right)])
            rem=mul(rem,extra)
        else:
            # D_common / [2*x_owner*(1+x_other^2)].
            rem=prod([D[owner],add(con(1),var(other,-1,2))]
                     +[D[k]for k in range(3)if k not in(left,right)])
        base=add(base,scale(mul(mul(one,one),rem),SCALE))
        absolute.append(scale(mul(mul(one,delta),rem),SCALE))
    # +h_B.
    rem=mul(prod([add(con(1),var(0,-1,2)),D[1],D[2]]),extra)
    base=add(base,scale(mul(add(con(1),var(0,2),var(0,-1,2)),rem),SCALE//2))
    # -h_D + (2 beta_D/23), and the optional sharp-minus-base toll.
    rem=mul(prod([D[0],D[1],add(con(1),var(2,-1,2))]),extra)
    base=add(base,scale(mul(add(con(-23),var(2,-38),var(2,23,2)),rem),SCALE//46))
    toll=scale(mul(add(var(2,143),var(2,-943,2)),rem),SCALE//368)
    # BI unsigned height loss, at most (beta_owner/alpha_owner)/16.
    rem=mul(prod([add(con(1),var(bi_owner,1,2))]
                 +[D[k]for k in range(3)if k!=bi_owner]),extra)
    base=add(base,scale(mul(var(bi_owner),rem),-SCALE//8))
    if id_axis==0:
        # Shallow ID normal (alpha, s beta); maximize ny*v over [1/16,3/8].
        num,den=(3,8) if signs[id_owner]>0 else (1,16)
        rem=prod([add(con(1),var(id_owner,1,2))]
                 +[D[k]for k in range(3)if k!=id_owner])
        base=add(base,scale(mul(var(id_owner),rem),-signs[id_owner]*2*SCALE*num//den))
    else:
        # Steep ID normal (beta,-s alpha); D_common already contains 2*x_owner.
        num,den=(3,8) if signs[id_owner]<0 else (1,16)
        rem=mul(add(con(1),var(id_owner,-1,2)),FULL)
        base=add(base,scale(rem,signs[id_owner]*SCALE*num//den))
    ps=[base,*absolute,toll]
    assert len(ps)==4
    assert all(isinstance(c,int)for p in ps for c in p.values())
    return [[p.get(e,0)for e in EXPS]for p in ps]

def addr(path):
    a=[(0,0)]*3
    for axis,side in path:
        n,d=a[axis];a[axis]=(2*n+side,d+1)
    return a
def float_matrix(axis,address):
    n,d=address;l=float(ROOT[axis])*n/(2**d);w=float(ROOT[axis])/(2**d)
    return np.array([[sum(comb(r,m)*l**(r-m)*w**m*comb(j,m)/comb(DEG,m)
                          for m in range(min(j,r)+1))for r in range(SIDE)]for j in range(SIDE)])
def floats(ps,address):
    result=np.array(ps,dtype=float).reshape((4,SIDE,SIDE,SIDE))/SCALE
    for axis in range(3):
        result=np.moveaxis(np.tensordot(float_matrix(axis,address[axis]),result,
                                        axes=([1],[axis+1])),0,axis+1)
    return result.reshape((4,SIZE))
def integer_matrix(axis,address):
    n,d=address;r=ROOT[axis];lo=r.numerator*n;step=r.numerator;den=r.denominator*(2**d)
    return [[sum(comb(k,m)*lo**(k-m)*step**m*den**(DEG-k)*comb(j,m)*(60//comb(DEG,m))
                 for m in range(min(j,k)+1))for k in range(SIDE)]for j in range(SIDE)]
def exact(ps,path,weights,power):
    W=1<<power
    assert all(-W<=v<=W for v in weights[:2])and 0<=weights[2]<=W
    result=[W*ps[0][j]+sum(weights[k]*ps[k+1][j]for k in range(3))for j in range(SIZE)]
    address=addr(path)
    for axis in range(3):
        matrix=integer_matrix(axis,address[axis]);output=[0]*SIZE
        stride=SIDE**(2-axis);block=SIDE*stride
        for start in range(0,SIZE,block):
            for offset in range(stride):
                values=[result[start+k*stride+offset]for k in range(SIDE)]
                for j in range(SIDE):output[start+j*stride+offset]=sum(matrix[j][k]*values[k]for k in range(SIDE))
        result=output
    return min(result)>=0

def test(ps,path):
    global LPS
    address=addr(path);b=floats(ps,address)
    grid=np.array(EXPS).T
    w=sum(float(ROOT[i])*(n+grid[i]/DEG)/(2**d)for i,(n,d)in enumerate(address))
    # Steep branches have positive constant terms; weighted margin remains useful.
    LPS+=1
    res=linprog([0.,0.,0.,-1.],A_ub=np.column_stack([-b[1:].T,w]),b_ub=b[0],
                bounds=[(-1,1),(-1,1),(0,1),(None,None)],method='highs',options={'presolve':True})
    if not res.success:return None
    for power in(12,16,20,24,30,40):
        W=1<<power;weights=[round(float(x)*W)for x in res.x[:3]]
        if exact(ps,path,weights,power):
            return dict(path=path,weights=weights,weight_power=power,discovery_margin=float(res.x[3]))
    return None

def dump(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def run():
    global NODES
    assert not OUT.exists();OUT.mkdir()
    start=time.monotonic();domains=[];exhausted=False
    for sb,si,bo,io,axis in product((-1,1),(-1,1),(0,1),(1,2),(0,1)):
        signs=[sb,si,-1];name=f'b{sb}_i{si}_bo{bo}_io{io}_ax{axis}.json'
        ps=features(signs,bo,io,axis);stack=[[]];leaves=[];visits=0
        while stack and NODES<MAX_NODES and LPS<MAX_LPS:
            path=stack.pop();answer=test(ps,path);NODES+=1;visits+=1
            if answer is not None:leaves.append(answer)
            else:
                a=addr(path)
                split=max(range(3),key=lambda i:float(ROOT[i])/(2**a[i][1]))
                stack.extend([path+[[split,1]],path+[[split,0]]])
        data=dict(schema='signed_191_scalar_cover_candidate_v1',root_upper=list(map(str,ROOT)),
                  signs=signs,bi_owner=bo,id_owner=io,id_axis=axis,nodes=visits,
                  leaves=leaves,frontier=stack,scalar_degree=DEG,scale=SCALE)
        dump(OUT/name,data)
        domains.append(dict(file=name,signs=signs,bi_owner=bo,id_owner=io,id_axis=axis,
                            nodes=visits,leaves=len(leaves),frontier=len(stack)))
        print(json.dumps(dict(domain=len(domains),file=name,nodes=visits,leaves=len(leaves),
                              frontier=len(stack),total_nodes=NODES,lps=LPS,seconds=time.monotonic()-start)),flush=True)
        if stack:exhausted=True;break
    manifest=dict(schema='signed_191_scalar_manifest_candidate_v1',domains=domains,nodes=NODES,
                  lp_calls=LPS,node_cap=MAX_NODES,lp_cap=MAX_LPS,root_upper=list(map(str,ROOT)),
                  complete=(len(domains)==32 and not exhausted),
                  open=sum(d['frontier']for d in domains)+(32-len(domains)),
                  seconds=time.monotonic()-start,independent_exact_replay_pending=True,
                  new_original_cells=0,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    dump(OUT/'MANIFEST.json',manifest)
    print(json.dumps(manifest),flush=True)

if __name__=='__main__':run()
