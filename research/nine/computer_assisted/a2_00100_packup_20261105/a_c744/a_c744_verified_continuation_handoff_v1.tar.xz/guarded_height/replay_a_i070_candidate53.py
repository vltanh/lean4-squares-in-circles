from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
import sys,json,hashlib
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import independent_a_c744_i070_height as HEIGHT
sys.path.insert(0,'/workspace/scratch/f9f48fcfb253/ac_work/tree')
import verify_c887_unit_four_corner_tree as V
import independent_physical_sat_diagonal_replay as S
binding=HEIGHT.verify_binding();checker=V.Checker()
class Adapter(V.Adapter):
 def rebuild(self,state,printed):
  ordinary=[r for r in printed if r['name']!=HEIGHT.NAME];rows,bounds,physical=super().rebuild(state,ordinary)
  assert self.K.V.Q==F(1105,256)and self.K.V.EDGES==((0,1,0),(1,2,0),(2,3,1),(4,5,0),(5,6,0))
  for r in printed:
   if r['name']!=HEIGHT.NAME:continue
   literal=(tuple((k,F(v))for k,v in r['coefficients']),F(r['rhs']),r['name']);HEIGHT.verify_literal(literal,state,binding)
   assert r['index']not in rows;rows[r['index']]=literal
  return rows,bounds,physical
adapter=Adapter(checker);source=Path('/workspace/lean4-squares-in-circles/research/nine/.runs/a_continue/angle151/node_0053.json');record=json.loads(source.read_text());v=record['initial'];state=dict(id=v['id'],path=v['path'],choices=adapter.choices(v['path']))
for k in('angles','positions','scalar'):state[k]=tuple(tuple(map(F,z))for z in v[k])
for k in('differences','diagonal'):state[k]={tuple(e['pair']):tuple(tuple(map(F,z))for z in e['intervals'])for e in v[k]}
audit,after=S.check_record(record,state,adapter);assert after is None
used=[r for r in record['terminal']['rows']if r['name']==HEIGHT.NAME];assert len(used)==1
controls=[]
for label,which,bounds in [('I_lower_outside',8,('-500001/1000000','1/4')),('I_upper_outside',8,('-1/4','500001/1000000')),('bounded_B_does_not_replace_I',8,('-1','1'))]:
 s=deepcopy(state);angles=list(s['angles']);angles[which]=tuple(map(F,bounds));angles[1]=(F(-1,2),F(1,2));s['angles']=tuple(angles)
 try:HEIGHT.verify_literal(HEIGHT.LITERAL,s,binding)
 except AssertionError:controls.append(label)
 else:raise AssertionError(('unguarded height accepted',label))
s=deepcopy(state);s['id']='positive-wrong-original'
try:HEIGHT.verify_literal(HEIGHT.LITERAL,s,binding)
except AssertionError:controls.append('wrong_original_rejected')
else:raise AssertionError('wrong original accepted')
assert len(controls)==4 and not any(n in sys.modules for n in('numpy','scipy','highspy'))
report=dict(status='PASS_GUARDED_I070_HEIGHT_SOURCE_ATTACHMENT_AND_ACTUAL_CANDIDATE53_SUFFIX',source_record=dict(path=str(source),sha256=HEIGHT.sha(source)),source_binding_sha256=HEIGHT.BINDING_SHA,
 exact_audit=audit,weighted_I070_occurrences=1,guarded_selected_extra=8,certified_I_interval=v['angles'][8],controls=controls,
 all_nine_originals_actual_links_strict_weak_CD_and_closed_faces_retained=True,conditional_scope_only=True,
 whole151_cover_and_source_initial_ancestry_gate_pending=True,historical_completed_0_1_2_4_proofs_reused_not_replayed=True,
 fresh_scalar_domains=28,fresh_scalar_leaves=127,fresh_scalar_coefficients=15875,new_originals=0,new_masks=0,
 source_sha256=HEIGHT.source_bindings(),blocking_findings=[])
report['source_sha256'][str(Path(__file__).resolve())]=HEIGHT.sha(__file__)
(HERE/'A_I070_HEIGHT_CANDIDATE53_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],audit['reserve'],flush=True)
