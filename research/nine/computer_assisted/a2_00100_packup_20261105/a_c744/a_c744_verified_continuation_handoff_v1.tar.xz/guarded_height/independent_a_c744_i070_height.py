"""Exact guarded A-c744 I-height row from the accepted bounded-extra7/10 theorem.

The selected original is I (index8). No other frame may discharge its guard.
Only literal reconstruction/attachment is provided; coverage stays external.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib,importlib.util,json,sys
if not __debug__:raise RuntimeError('Exact conditional attachment requires assertions.')
HERE=Path(__file__).resolve().parent;PACK=HERE/'a_i070_source';BINDING=PACK/'HEIGHT_BINDING.json'
BINDING_SHA='ee4f6b6793ca90812f0ff1554988b969784b4348b22b4d482e44f72f84cb8f19'
TARGET='positive-c744bc031d40ee64';ROOT=[['angle',3,1],['angle_cut',[0,'0'],0],['inward_row_escape',[7,8],[4]]]
NAME='conditional_actual_AB_I070_height';LITERAL=(((3,F(1)),(7,F(1)),(17,F(-2))),F(-7,10),NAME)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def verify_binding():
 assert sha(BINDING)==BINDING_SHA;b=read(BINDING)
 assert b['original_id']==TARGET and b['original_path']==ROOT
 assert b['selected_extra_original']==8 and b['slope_interval']==['-1/2','1/2']
 for name,h in b['files'].items():assert sha(PACK/name)==h,name
 review=read(PACK/'ACTUAL_AB_070_ROOT_PHYSICAL_REVIEW.json');fresh=read(PACK/'FRESH_SCALAR_REPLAY.json')
 assert review['status']=='PASS_ROOT_BOUNDED_EXTRA_070_SCALAR_PHYSICAL_AND_SCOPE_REVIEW'
 assert review['reports']['ACTUAL_AB_070_ROOT_FRESH_REPLAY.json']==sha(PACK/'ACTUAL_AB_070_ROOT_FRESH_REPLAY.json')
 assert fresh['status']=='PASS_COMPLETE_EXACT_TWO_LINK_SCALAR_COVER'
 assert(fresh['domains'],fresh['leaves'],fresh['bernstein_coefficients'],fresh['frontier'])==(28,127,15875,0)
 assert fresh['coefficient']=='701/1000'and fresh['target_variation']=='7/10'and fresh['strict_except_all_zero']is True
 assert fresh['checker_sha256']==sha(PACK/'reviewed_afad_source/check_conditional_three_angle.py')
 for e in fresh['audits']:assert sha(PACK/'reviewed_afad_source/cover'/e['file'])==e['sha256']
 for e in review['inherited_premises_checked']:assert sha(PACK/'inherited'/e['path'])==e['sha256']
 source=b['i64_original_transport'];assert sha(source['path'])==source['sha256']=='e1c1983cfa0f17c718aa226a8d5853be48eb51f3d890f43a989be08a7f3d9fcf'
 spec=importlib.util.spec_from_file_location('accepted_original_i64_transport_for_I070',source['path']);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 old=module.verify_binding();assert module.BINDING_SHA==source['binding_sha256']
 assert old['original_id']==TARGET and old['valid_on_whole_original']is True
 whole=read(module.checked_ref(old['whole_original_parent']));assert module.check_guard(whole['record']['final'])
 assert {x['component']for x in old['old_necessary_weak_rows']}=={0,1,2,4}
 assert F(3,5)<F(7,10)and 2*F(7,10)**2<1
 assert b['new_originals']==b['new_masks']==0
 return b

def assert_caller(state):
 assert state['id']==TARGET and state['path'][:len(ROOT)]==ROOT
 assert len(state['angles'])==9 and len(state['positions'])==18 and len(state['scalar'])==36
 assert all(F(-1)<=F(lo)<=F(hi)<=F(1)for lo,hi in state['angles'])
 lo,hi=map(F,state['angles'][8]);assert F(-1,2)<=lo<=hi<=F(1,2),'selected original I slope guard'
 assert F(state['angles'][3][0])>=0
 raw=state['differences'];dif=raw if isinstance(raw,dict)else{tuple(e['pair']):e['intervals']for e in raw}
 assert set(dif)==set(combinations(range(9),2))
 dg,di=dif[3,6],dif[3,8]
 assert -1<F(dg[0][0])<=F(dg[0][1])<1 and F(dg[1][0])>=0 and F(di[0][1])<0
 return True

def verify_literal(literal,state,binding):
 assert binding['original_id']==TARGET and binding['original_path']==ROOT and binding['selected_extra_original']==8
 assert_caller(state)
 co,rhs,name=literal;assert tuple((k,F(v))for k,v in co)==LITERAL[0]and F(rhs)==LITERAL[1]and name==NAME
 return True

def source_bindings():
 b=verify_binding();paths=[Path(__file__).resolve(),BINDING,*[PACK/n for n in b['files']],Path(b['i64_original_transport']['path'])]
 return {str(p):sha(p)for p in paths}
