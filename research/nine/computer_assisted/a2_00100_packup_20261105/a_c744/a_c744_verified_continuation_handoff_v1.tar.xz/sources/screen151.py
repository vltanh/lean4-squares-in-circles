from pathlib import Path
from fractions import Fraction as F
import sys,json
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_a_c744_component3_a1_consequence_runtime as R
ROOT=Path(__file__).resolve().parent;out=ROOT/'screen151';out.mkdir(exist_ok=True)
used=0;raw=R.E.H._Highs
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,n):return getattr(self.inner,n)
 def run(self):
  global used
  assert used<1500;used+=1;(out/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,limit=1500))+'\n');return self.inner.run()
R.E.H._Highs=Counted
parent=json.loads((T/'a_c744_whole_support_caps/record.json').read_text())['record']['final'];context=R.Context(R.state_from_view(parent),3)
s=R.state_from_view(json.loads((ROOT/'bound108/node_00151.json').read_text())['final'])
for mode,side in (('negative_outer',0),('central',1)):
 child=context.angle_child(s,8,-F(1,2),side)
 for guard in (False,True)if mode=='central'else(False,):
  rows,bounds,prop,term=context.collect(child);assert term is None
  if guard:
   assert -F(1,2)<=child['angles'][8][0]<=child['angles'][8][1]<=F(1,2)
   rows.append(([(3,F(1)),(7,F(1)),(17,F(-2))],-F(7,10),'conditional_actual_AB_I070_height'))
  else:rows.append(([(3,F(1)),(7,F(1)),(17,F(-2))],-F(16,25),'selected_original_I064_height'))
  h,phase,point,term=R.E.phase_solve(rows,bounds)
  r=dict(initial=R.stateview(child),rounds=[],status='CANDIDATE_CLOSED'if term else'OPEN',phase=phase,point=point)
  if term:r.update(terminal_state=R.stateview(child),terminal=term)
  else:r['final']=R.stateview(child)
  (out/f'{mode}_{int(guard)}.json').write_text(json.dumps(r,indent=2)+'\n');print(mode,guard,r['status'],phase,'calls',used,flush=True)
