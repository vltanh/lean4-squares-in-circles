import sys,json,time,pathlib,hashlib,shutil
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
T=pathlib.Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
import physical_split_normalized_corner_five_proxy as SPLIT
ROOT=pathlib.Path(__file__).resolve().parent;OUT=ROOT/'sat_counted';OUT.mkdir(exist_ok=True)
class Budget(Exception):pass
used=0;raw=R.E.H._Highs
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,name):return getattr(self.inner,name)
 def run(self):
  global used
  if used>=1500:raise Budget('1500 actual HiGHS.run calls')
  used+=1
  (OUT/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,limit=1500,prior_pilot_calls_unknown=True))+'\n')
  return self.inner.run()
R.E.H._Highs=Counted
context=R.Context();TOTAL=0
for original in map(int,sys.argv[1:]):
 tree=OUT/f'leaf_{original}'
 assert not tree.exists()
 source=ROOT/'bound108'/f'node_{original:05}.json';old=json.loads(source.read_text());state=R.state_from_view(old['final'])
 pilot=ROOT/'sat_branches'/tree.name
 if pilot.exists():
  shutil.copytree(pilot,tree);nodes=json.loads((tree/'manifest.json').read_text())['nodes'];TOTAL+=len(nodes)
 else:tree.mkdir();nodes=[]
 def save():
  for n in reversed(nodes):
   if n['children']:n['status']='CANDIDATE_COVER_CLOSED'if all(nodes[k]['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for k in n['children'])else'OPEN'
  (tree/'manifest.json').write_text(json.dumps(dict(original_leaf=original,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),nodes=nodes,new_originals=0,actual_highs_run_calls=used,pilot_reused=pilot.exists()),indent=2)+'\n')
 def add(s,restriction=None,parent=None):
  global TOTAL
  i=len(nodes);n=dict(index=i,parent=parent,restriction=restriction,children=[],status='OPEN',file=f'node_{i:04}.json');nodes.append(n);TOTAL+=1
  p=tree/n['file'];p.write_text(json.dumps(dict(status='OPEN',initial=R.stateview(s),rounds=[],final=R.stateview(s)),indent=2)+'\n');n['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();return i
 if not nodes:add(state)
 queue=[n['index']for n in nodes if not n['children']and n['status']=='OPEN']
 for n in nodes:
  if n['status']in('CANDIDATE_CLOSED','OPEN'):
   record=json.loads((tree/n['file']).read_text());context.AH.add_seed_record(record)
 try:
  while queue and TOTAL<=369:
   i=queue.pop(0);n=nodes[i];p=tree/n['file'];before=json.loads(p.read_text());state=R.state_from_view(before['final']);start=time.monotonic();startcalls=used
   r,after,point=R.E.search_node(context,state,0)
   assert r['initial']==before['initial'] and before['rounds']==[]
   p.write_text(json.dumps(r,indent=2)+'\n');n.update(status=r['status'],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
   print(original,i,r['status'],'calls',used-startcalls,'totalcalls',used,'nodes',TOTAL,flush=True)
   if after is not None and len(nodes)<41 and TOTAL+8<=369:
    pairs=R.E.best_pairs(after,point,1)
    split=dict(kind='complete_physical_sat',pair=list(pairs[0][1]),diagnostic_gap=pairs[0][0])if pairs and pairs[0][0]<-1e-8 else SPLIT.split_choice(after,point)
    if split:
     rs=[]
     if split['kind']=='complete_physical_sat':
      for choice in product(split['pair'],(0,1),(-1,1)):rs.append((dict(kind='physical_sat',pair=split['pair'],choice=list(choice)),context.child(after,split['pair'],choice)))
     elif split['kind']=='complete_physical_proxy':
      for choice in product((0,1),(-1,1)):rs.append((dict(kind='physical_proxy',pair=split['pair'],choice=list(choice)),context.proxy_child(after,split['pair'],choice)))
     else:
      for side in (0,1):rs.append((dict(kind='closed_angle',owner=split['owner'],cut=split['cut'],side=side),context.angle_child(after,split['owner'],F(split['cut']),side)))
     n.update(split=split,complete_children=True)
     for restriction,child in rs:
      k=add(child,restriction,i);n['children'].append(k);queue.append(k)
   save()
 except Budget:
  save();print('BUDGET_STOP',used,TOTAL,flush=True);break
 print('RESULT',original,nodes[0]['status'],len(nodes),'OPEN',sum(not n['children']and n['status']=='OPEN'for n in nodes),flush=True)
