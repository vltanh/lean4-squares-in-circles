from pathlib import Path
import sys,json,hashlib,shutil,time
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
ROOT=Path(__file__).resolve().parent;prior=ROOT/'sat_counted/leaf_144';out=ROOT/'selected_bound144';shutil.copytree(prior,out)
used=json.loads((ROOT/'sat_counted/COUNTER.json').read_text())['actual_highs_run_calls'];start_calls=used;raw=R.E.H._Highs
class Budget(Exception):pass
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,n):return getattr(self.inner,n)
 def run(self):
  global used
  if used>=1500:raise Budget()
  used+=1;(out/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,inherited_actual_calls=start_calls,limit=1500))+'\n')
  return self.inner.run()
R.E.H._Highs=Counted;context=R.Context()
m=json.loads((out/'manifest.json').read_text());nodes=m['nodes']
def save():
 for n in reversed(nodes):
  if n['children']:n['status']='CANDIDATE_COVER_CLOSED'if all(nodes[k]['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for k in n['children'])else'OPEN'
 m['actual_highs_run_calls']=used;m['selected_bound_continuation']=dict(source_manifest_sha256=hashlib.sha256((prior/'manifest.json').read_bytes()).hexdigest(),inherited_actual_calls=start_calls)
 (out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
try:
 for n in nodes:
  if n['children']or n['status']!='OPEN':continue
  p=out/n['file'];old=json.loads(p.read_text());s=R.state_from_view(old['final']);before=used
  rows,bounds,prop,term=context.collect(s);assert term is None
  h,phase,point,term=R.E.phase_solve(rows,bounds)
  if term is None:
   context.gram_active=False
   try:after,rr,term=R.E.bound_round(context,s,rows,bounds,prop,h,objective_limit=108)
   finally:context.gram_active=True
   rr['phase']=phase;r=dict(initial=R.stateview(s),rounds=[rr],status='CANDIDATE_CLOSED'if term else'OPEN')
   if term:r['terminal']=term
   else:
    context.AH.SEED_NAMES.update(x['name']for x in rr['printed_rows']);last,_,_=R.E.search_node(context,after,0);r.update({k:v for k,v in last.items()if k not in('initial','rounds')})
  else:r=dict(initial=R.stateview(s),rounds=[],status='CANDIDATE_CLOSED',terminal_state=R.stateview(s),terminal=term)
  new=dict(old);new['rounds']=old['rounds']+r['rounds'];new.update({k:v for k,v in r.items()if k not in('initial','rounds')})
  if new['status']=='CANDIDATE_CLOSED':new.pop('final',None)
  p.write_text(json.dumps(new,indent=2)+'\n');n.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),status=new['status']);save()
  print(n['index'],n['status'],'deductions',sum(len(rr['proposals'])for rr in r['rounds']),'calls',used-before,'total',used,flush=True)
except Budget:save();print('BUDGET_STOP',used,flush=True)
print('FINAL',nodes[0]['status'],'OPEN',sum(not n['children']and n['status']=='OPEN'for n in nodes),flush=True)
