from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sys,json,hashlib
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import verify_c887_unit_four_corner_tree as V
import independent_physical_sat_diagonal_replay as S
import independent_physical_proxy_cover as P
import verify_c887_physical_tree as A
R=Path(__file__).resolve().parent;folder=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve();assert not output.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checker=V.Checker();adapter=V.Adapter(checker)
def parse(v):
 s=dict(id=v['id'],path=v['path'],choices=adapter.choices(v['path']))
 for k in ('angles','positions','scalar'):s[k]=tuple(tuple(map(F,z))for z in v[k])
 for k in ('differences','diagonal'):s[k]={tuple(e['pair']):tuple(tuple(map(F,z))for z in e['intervals'])for e in v[k]}
 return s
manifest=json.loads((folder/'manifest.json').read_text());assert manifest['original_leaf']==144
full=json.loads((R/'CHECKPOINT167_FULL_REPLAY.json').read_text());assert full['all_current_records_and_prefixes_freshly_replayed']is True
base=R/'checkpoint167/node_00144.json';assert full['input_sha256'][str(base)]==sha(base)
initial=parse(json.loads(base.read_text())['final']);nodes=manifest['nodes'];assert [n['index']for n in nodes]==list(range(len(nodes)))
seen=set();audits=[];covers=[]
def visit(i,state,parent=None):
 assert i not in seen;seen.add(i);n=nodes[i];assert n['parent']==parent;p=folder/n['file'];assert sha(p)==n['sha256'];record=json.loads(p.read_text())
 audit,after=S.check_record(record,state,adapter);audits.append(dict(index=i,sha256=sha(p),**audit))
 if after is None:assert n['children']==[]and n['status']=='CANDIDATE_CLOSED';return True
 if not n['children']:assert n['status']=='OPEN';return False
 split=n['split'];assert n['complete_children']is True;children=n['children'];rs=[nodes[k]['restriction']for k in children]
 if split['kind']=='complete_physical_sat':
  expected=set(product(split['pair'],(0,1),(-1,1)));assert len(rs)==len(expected)and {tuple(r['choice'])for r in rs}==expected
  assert all(r['kind']=='physical_sat'and r['pair']==split['pair']for r in rs)
  states=[S.sat_child(after,split['pair'],r['choice'],adapter)for r in rs]
 elif split['kind']=='complete_physical_proxy':
  expected=set(product((0,1),(-1,1)));assert len(rs)==4 and {tuple(r['choice'])for r in rs}==expected
  assert all(r['kind']=='physical_proxy'and r['pair']==split['pair']for r in rs)
  states=[P.proxy_child(after,split['pair'],r['choice'],adapter)for r in rs]
 else:
  assert split['kind']=='closed_angle_bisection'and len(rs)==2 and {r['side']for r in rs}=={0,1}
  assert all(r['kind']=='closed_angle'and r['owner']==split['owner']and r['cut']==split['cut']for r in rs)
  states=[A.angle_child(after,split['owner'],F(split['cut']),r['side'],adapter)for r in rs]
 results=[visit(k,s,i)for k,s in zip(children,states)];closed=all(results);assert n['status']==('CANDIDATE_COVER_CLOSED'if closed else'OPEN');covers.append(i);return closed
closed=visit(0,initial);assert seen==set(range(len(nodes)))
assert not any(n in sys.modules for n in ('numpy','scipy','highspy'))
report=dict(status='PASS_COMPLETE_RETAINED_LEAF144_CLOSED'if closed else'PASS_COMPLETE_RETAINED_LEAF144_PARTIAL',source_current_original_prefix_report_sha256=sha(R/'CHECKPOINT167_FULL_REPLAY.json'),source_leaf_record_sha256=sha(base),nodes=len(nodes),complete_covers=len(covers),excluded_leaves=sum(not n['children']and n['status']=='CANDIDATE_CLOSED'for n in nodes),open_leaves=sum(not n['children']and n['status']=='OPEN'for n in nodes),fresh_arithmetic=audits,new_original_cells=0,new_masks=0)
output.write_text(json.dumps(report,indent=2)+'\n');print(report['status'],report['nodes'],report['excluded_leaves'],report['open_leaves'],flush=True)
