from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sys,json,hashlib,shutil
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
ROOT=Path(__file__).resolve().parent;prior=ROOT/'bh151_bound';out=ROOT/'dg151_bound';shutil.copytree(prior,out);used=json.loads((prior/'COUNTER.json').read_text())['actual_highs_run_calls'];raw=R.E.H._Highs
class Budget(Exception):pass
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,n):return getattr(self.inner,n)
 def run(self):
  global used
  if used>=1500:raise Budget()
  used+=1;(out/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,limit=1500))+'\n');return self.inner.run()
R.E.H._Highs=Counted
class Context(R.Context):
 def collect(self,s):
  rows,bounds,prop,term=super().collect(s)
  if term is None:
   central=-F(1,2)<=s['angles'][8][0]<=s['angles'][8][1]<=F(1,2)
   name='conditional_actual_AB_I070_height'if central else'certified_a_c744_original_i64_height_63458318a3681d677745baf4a00d8a738a5705c6276659174e59f440fa9a06e3'
   rows.append(([(3,F(1)),(7,F(1)),(17,F(-2))],-F(7,10)if central else-F(16,25),name))
  return rows,bounds,prop,term
context=Context();source=ROOT/'checkpoint167/node_00151.json';m=json.loads((out/'manifest.json').read_text());nodes=m['nodes'];new_indices=[]
for parent in (3,7):
 n=nodes[parent];state=R.state_from_view(json.loads((out/n['file']).read_text())['final']);assert n['status']=='OPEN'and not n['children'];n.update(split=dict(kind='complete_physical_sat',pair=[3,6]),complete_children=True)
 for choice in product((3,6),(0,1),(-1,1)):
  child=context.child(state,(3,6),choice);v=R.stateview(child);i=len(nodes);p=out/f'node_{i:04}.json';p.write_text(json.dumps(dict(initial=v,rounds=[],status='OPEN',final=v),indent=2)+'\n');nodes.append(dict(index=i,parent=parent,restriction=dict(kind='physical_sat',pair=[3,6],choice=list(choice)),children=[],file=p.name,status='OPEN',sha256=hashlib.sha256(p.read_bytes()).hexdigest()));n['children'].append(i);new_indices.append(i)
def save():
 for n in reversed(nodes):
  if n['children']:n['status']='CANDIDATE_COVER_CLOSED'if all(nodes[k]['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for k in n['children'])else'OPEN'
 m.update(nodes=nodes,actual_highs_run_calls=used,dg_continuation_source_sha256=hashlib.sha256((prior/'manifest.json').read_bytes()).hexdigest());(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
save()
try:
 for n in [nodes[i]for i in new_indices]:
  if n['status']!='OPEN':continue
  p=out/n['file'];old=json.loads(p.read_text());s=R.state_from_view(old['final']);before=used
  rows,bounds,prop,term=context.collect(s)
  if term is None:h,phase,point,term=R.E.phase_solve(rows,bounds)
  if term is not None:r=dict(initial=R.stateview(s),rounds=[],status='CANDIDATE_CLOSED',terminal_state=R.stateview(s),terminal=term)
  else:
   context.gram_active=False
   try:after,rr,term=R.E.bound_round(context,s,rows,bounds,prop,h,objective_limit=108)
   finally:context.gram_active=True
   rr['phase']=phase;r=dict(initial=R.stateview(s),rounds=[rr],status='CANDIDATE_CLOSED'if term else'OPEN')
   if term:r['terminal']=term
   else:
    context.AH.SEED_NAMES.update(x['name']for x in rr['printed_rows']);last,_,_=R.E.search_node(context,after,0);r.update({k:v for k,v in last.items()if k not in('initial','rounds')})
  p.write_text(json.dumps(r,indent=2)+'\n');n.update(status=r['status'],sha256=hashlib.sha256(p.read_bytes()).hexdigest());save()
  print(n['index'],n['restriction']['choice'],n['status'],'deductions',sum(len(rr['proposals'])for rr in r['rounds']),'calls',used-before,'total',used,flush=True)
except Budget:save();print('BUDGET_STOP',used,flush=True)
print('FINAL',nodes[0]['status'],'OPEN',sum(not n['children']and n['status']=='OPEN'for n in nodes),flush=True)
