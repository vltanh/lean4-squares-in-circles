from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sys,json,hashlib
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
ROOT=Path(__file__).resolve().parent;out=ROOT/'bh151_bound';out.mkdir(exist_ok=False);used=0;raw=R.E.H._Highs
class Budget(Exception):pass
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,n):return getattr(self.inner,n)
 def run(self):
  global used
  if used>=1500:raise Budget()
  used+=1;(out/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,limit=1500))+'\n');return self.inner.run()
R.E.H._Highs=Counted
class Context(R.Context):
 def collect(self,s):
  rows,bounds,prop,term=super().collect(s)
  if term is None:
   central=-F(1,2)<=s['angles'][8][0]<=s['angles'][8][1]<=F(1,2)
   name='conditional_actual_AB_I070_height'if central else'certified_a_c744_original_i64_height_63458318a3681d677745baf4a00d8a738a5705c6276659174e59f440fa9a06e3'
   rows.append(([(3,F(1)),(7,F(1)),(17,F(-2))],-F(7,10)if central else-F(16,25),name))
  return rows,bounds,prop,term
context=Context();source=ROOT/'checkpoint167/node_00151.json';v=json.loads(source.read_text())['final'];nodes=[]
def add(record,parent,restriction):
 i=len(nodes);p=out/f'node_{i:04}.json';p.write_text(json.dumps(record,indent=2)+'\n');n=dict(index=i,parent=parent,restriction=restriction,children=[],file=p.name,status=record['status'],sha256=hashlib.sha256(p.read_bytes()).hexdigest());nodes.append(n);return i
add(dict(initial=v,rounds=[],status='OPEN',final=v),None,None);nodes[0].update(complete_children=True,split=dict(kind='complete_physical_sat',pair=[1,7]))
for choice in product((1,7),(0,1),(-1,1)):
 p=ROOT/'inspect151_bh'/('node_'+'_'.join(map(str,choice))+'.json');r=json.loads(p.read_text());i=add(r,0,dict(kind='physical_sat',pair=[1,7],choice=list(choice)));nodes[0]['children'].append(i)
def save():
 nodes[0]['status']='CANDIDATE_COVER_CLOSED'if all(n['status']=='CANDIDATE_CLOSED'for n in nodes[1:])else'OPEN'
 (out/'manifest.json').write_text(json.dumps(dict(original_leaf=151,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),nodes=nodes,actual_highs_run_calls=used,new_originals=0),indent=2)+'\n')
save()
try:
 for n in nodes[1:]:
  if n['status']!='OPEN':continue
  p=out/n['file'];old=json.loads(p.read_text());s=R.state_from_view(old['final']);before=used
  rows,bounds,prop,term=context.collect(s)
  if term is None:h,phase,point,term=R.E.phase_solve(rows,bounds)
  if term is not None:r=dict(initial=R.stateview(s),rounds=[],status='CANDIDATE_CLOSED',terminal_state=R.stateview(s),terminal=term)
  else:
   context.gram_active=False
   try:after,rr,term=R.E.bound_round(context,s,rows,bounds,prop,h,objective_limit=108)
   finally:context.gram_active=True
   rr['phase']=phase;r=dict(initial=R.stateview(s),rounds=[rr],status='CANDIDATE_CLOSED'if term else'OPEN')
   if term:r['terminal']=term
   else:
    context.AH.SEED_NAMES.update(x['name']for x in rr['printed_rows']);last,_,_=R.E.search_node(context,after,0);r.update({k:v for k,v in last.items()if k not in('initial','rounds')})
  p.write_text(json.dumps(r,indent=2)+'\n');n.update(status=r['status'],sha256=hashlib.sha256(p.read_bytes()).hexdigest());save()
  print(n['index'],n['restriction']['choice'],n['status'],'deductions',sum(len(rr['proposals'])for rr in r['rounds']),'calls',used-before,'total',used,flush=True)
except Budget:save();print('BUDGET_STOP',used,flush=True)
print('FINAL',nodes[0]['status'],'OPEN',sum(n['status']=='OPEN'for n in nodes[1:]),flush=True)
