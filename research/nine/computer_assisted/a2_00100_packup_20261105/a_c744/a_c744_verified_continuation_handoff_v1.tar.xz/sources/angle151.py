from pathlib import Path
from fractions import Fraction as F
from math import hypot
from itertools import product
import sys,json,hashlib
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
ROOT=Path(__file__).resolve().parent;out=ROOT/'angle151';out.mkdir(exist_ok=False)
used=json.loads((ROOT/'screen151/COUNTER.json').read_text())['actual_highs_run_calls'];raw=R.E.H._Highs
class Budget(Exception):pass
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,n):return getattr(self.inner,n)
 def run(self):
  global used
  if used>=1500:raise Budget()
  used+=1;(out/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,limit=1500))+'\n');return self.inner.run()
R.E.H._Highs=Counted
class Context(R.Context):
 def collect(self,s):
  rows,bounds,prop,term=super().collect(s)
  if term is None:
   central=-F(1,2)<=s['angles'][8][0]<=s['angles'][8][1]<=F(1,2)
   name='conditional_actual_AB_I070_height'if central else'certified_a_c744_original_i64_height_63458318a3681d677745baf4a00d8a738a5705c6276659174e59f440fa9a06e3'
   rows.append(([(3,F(1)),(7,F(1)),(17,F(-2))],-F(7,10)if central else-F(16,25),name))
  return rows,bounds,prop,term
context=Context();source=ROOT/'checkpoint167/node_00151.json';initial=R.state_from_view(json.loads(source.read_text())['final']);nodes=[];queue=[]
def save():
 for n in reversed(nodes):
  if n['children']:n['status']='CANDIDATE_COVER_CLOSED'if all(nodes[k]['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for k in n['children'])else'OPEN'
 m=dict(original_leaf=151,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),nodes=nodes,new_originals=0,actual_highs_run_calls=used,guarded_I070_rows_require_independent_attachment=True)
 (out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
def add(s,parent,restriction):
 k=len(nodes);v=R.stateview(s);n=dict(index=k,parent=parent,restriction=restriction,children=[],status='OPEN',file=f'node_{k:04}.json');nodes.append(n);p=out/n['file'];p.write_text(json.dumps(dict(initial=v,rounds=[],status='OPEN',final=v),indent=2)+'\n');n['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();return k
add(initial,None,None)
def split(n,s,owner,cut):
 n.update(split=dict(kind='closed_angle_bisection',owner=owner,cut=str(cut)),complete_children=True)
 for side in (0,1):
  child=context.angle_child(s,owner,cut,side);k=add(child,n['index'],dict(kind='closed_angle',owner=owner,cut=str(cut),side=side));n['children'].append(k);queue.append(k)
split(nodes[0],initial,8,-F(1,2));queue.clear()
for i in (1,2):
 s=R.state_from_view(json.loads((out/nodes[i]['file']).read_text())['final']);split(nodes[i],s,6,F(0))
save()
try:
 while queue:
  i=queue.pop(0);n=nodes[i];p=out/n['file'];old=json.loads(p.read_text());s=R.state_from_view(old['final']);before=used
  record,after,point=R.E.search_node(context,s,0);p.write_text(json.dumps(record,indent=2)+'\n');n.update(status=record['status'],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  weighted=sum(r['name']=='conditional_actual_AB_I070_height'for r in record.get('terminal',{}).get('rows',[]))
  print(i,n['status'],'calls',used-before,'total',used,'I070',weighted,flush=True)
  if after is not None and len(nodes)<63:
   candidates=[]
   for owner,(lo,hi)in enumerate(after['angles']):
    if hi-lo<=F(1,128):continue
    a,b=point[18+owner],point[27+owner];norm=hypot(a,b);a,b=a/norm,b/norm;x,y=point[2*owner:2*owner+2]
    excess=max((x+(e*a-t*b)/2)**2+(y+(e*b+t*a)/2)**2-1105/256 for e,t in product((-1,1),repeat=2));candidates.append((excess,owner))
   _,owner=max(candidates);lo,hi=after['angles'][owner];split(n,after,owner,(lo+hi)/2)
  save()
except Budget:save();print('BUDGET_STOP',used,flush=True)
print('FINAL',nodes[0]['status'],'nodes',len(nodes),'OPEN',sum(not n['children']and n['status']=='OPEN'for n in nodes),flush=True)
