from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sys,json,hashlib
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import verify_c887_unit_four_corner_tree as V
import independent_physical_sat_diagonal_replay as S
R=Path(__file__).resolve().parent;out=R/'inspect151_bh';out.mkdir(exist_ok=False)
checker=V.Checker();adapter=V.Adapter(checker);v=json.loads((R/'checkpoint167/node_00151.json').read_text())['final'];s=dict(id=v['id'],path=v['path'],choices=adapter.choices(v['path']))
for key in ('angles','positions','scalar'):s[key]=tuple(tuple(map(F,z))for z in v[key])
for key in ('differences','diagonal'):s[key]={tuple(e['pair']):tuple(tuple(map(F,z))for z in e['intervals'])for e in v[key]}
children=[]
for choice in product((1,7),(0,1),(-1,1)):
 child=S.sat_child(s,(1,7),choice,adapter);view=S.state_view(child);rows,bounds,*_=checker.K.rebuild(child['path'],child['angles'],child['positions'],child['choices'],child['scalar'],child['differences'])
 negative=[(i,r)for i,r in enumerate(rows)if not r[0]and r[1]<0]
 r=dict(status='OPEN',initial=view,rounds=[],final=view)
 if negative:
  index,(co,rhs,name)=negative[0];terminal=dict(kind='positive_exact_reserve',weights=[[index,1<<40]],rows=[dict(index=index,name=name,coefficients=[],rhs=str(rhs))],absolute_variable_bounds=list(map(str,bounds)),weighted_coefficients=['0']*len(bounds),weighted_rhs=str(rhs),reserve=str(-rhs));r=dict(status='CANDIDATE_CLOSED',initial=view,rounds=[],terminal_state=view,terminal=terminal)
 children.append((choice,r));(out/('node_'+'_'.join(map(str,choice))+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(choice,r['status'],flush=True)
report,openstates=S.check_complete_cover(s,(1,7),children,adapter);report.update(source_leaf_record_sha256=hashlib.sha256((R/'checkpoint167/node_00151.json').read_bytes()).hexdigest(),numerical_solves=0)
(out/'EXACT_BH_SCREEN.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],report['excluded_alternatives'],flush=True)
