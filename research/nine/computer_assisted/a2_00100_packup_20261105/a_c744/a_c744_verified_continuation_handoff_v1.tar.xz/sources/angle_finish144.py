from pathlib import Path
from fractions import Fraction as F
from math import hypot
from itertools import product
import sys,json,hashlib,shutil
T=Path('/workspace/scratch/f9f48fcfb253/ac_work/tree');sys.path.insert(0,str(T))
import ac_objective_unit_four_corner_runtime as R
ROOT=Path(__file__).resolve().parent;prior=ROOT/'selected_bound144';out=ROOT/'angle_finish144';shutil.copytree(prior,out)
used=json.loads((prior/'COUNTER.json').read_text())['actual_highs_run_calls'];raw=R.E.H._Highs
class Budget(Exception):pass
class Counted:
 def __init__(self):self.inner=raw()
 def __getattr__(self,n):return getattr(self.inner,n)
 def run(self):
  global used
  if used>=1500:raise Budget()
  used+=1;(out/'COUNTER.json').write_text(json.dumps(dict(actual_highs_run_calls=used,limit=1500))+'\n');return self.inner.run()
R.E.H._Highs=Counted;context=R.Context();m=json.loads((out/'manifest.json').read_text());nodes=m['nodes'];queue=[]
def save():
 for n in reversed(nodes):
  if n['children']:n['status']='CANDIDATE_COVER_CLOSED'if all(nodes[k]['status']in('CANDIDATE_CLOSED','CANDIDATE_COVER_CLOSED')for k in n['children'])else'OPEN'
 m['actual_highs_run_calls']=used;m['angle_continuation_source_sha256']=hashlib.sha256((prior/'manifest.json').read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
def split(n,s,owner,cut):
 n.update(split=dict(kind='closed_angle_bisection',owner=owner,cut=str(cut)),complete_children=True)
 for side in (0,1):
  child=context.angle_child(s,owner,cut,side);v=R.stateview(child);k=len(nodes);c=dict(index=k,parent=n['index'],restriction=dict(kind='closed_angle',owner=owner,cut=str(cut),side=side),children=[],status='OPEN',file=f'node_{k:04}.json');nodes.append(c);n['children'].append(k)
  p=out/c['file'];p.write_text(json.dumps(dict(initial=v,rounds=[],status='OPEN',final=v),indent=2)+'\n');c['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();queue.append(k)
for i in (24,28,32):
 s=R.state_from_view(json.loads((out/nodes[i]['file']).read_text())['final']);split(nodes[i],s,3,F(2,3))
save()
try:
 while queue:
  i=queue.pop(0);n=nodes[i];p=out/n['file'];old=json.loads(p.read_text());s=R.state_from_view(old['final']);before=used
  record,after,point=R.E.search_node(context,s,0);p.write_text(json.dumps(record,indent=2)+'\n');n.update(status=record['status'],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  print(i,n['status'],'calls',used-before,'total',used,flush=True)
  if after is not None and len(nodes)<61:
   candidates=[]
   for owner,(lo,hi)in enumerate(after['angles']):
    if hi-lo<=F(1,128):continue
    a,b=point[18+owner],point[27+owner];norm=hypot(a,b);a,b=a/norm,b/norm;x,y=point[2*owner:2*owner+2]
    excess=max((x+(e*a-t*b)/2)**2+(y+(e*b+t*a)/2)**2-1105/256 for e,t in product((-1,1),repeat=2));candidates.append((excess,owner))
   _,owner=max(candidates);lo,hi=after['angles'][owner];split(n,after,owner,(lo+hi)/2)
  save()
except Budget:save();print('BUDGET_STOP',used,flush=True)
print('FINAL',nodes[0]['status'],'nodes',len(nodes),'OPEN',sum(not n['children']and n['status']=='OPEN'for n in nodes),flush=True)
