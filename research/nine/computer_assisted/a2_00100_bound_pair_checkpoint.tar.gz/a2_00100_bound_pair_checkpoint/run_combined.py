#!/usr/bin/env python3
"""Exact inherited coordinate-bound induction plus complete physical pair trees.

Prefix objective certificates are replayed before tighter positions are used.
Every new leaf is rechecked under those proved bounds with the unchanged v14
row routine in a private namespace. Original fixed paths never change.
"""
import argparse,concurrent.futures,hashlib,json,sys,time,traceback,warnings
from fractions import Fraction as F
from pathlib import Path
from types import FunctionType
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path.insert(0,str(HERE/'whole_cell_payload'))
import weak_outer_numeric_strict_bulk_v14_verify as V
from frontier_bounded_cells import children,verify_cell_union
from bound_prefix import replay_prefix

def bounded_state(path,prefix_path,bounds):
 assert path[:len(prefix_path)]==prefix_path
 box,pos,choices=V.reconstruct(path)
 pos=tuple((max(a,l),min(b,u)) for (a,b),(l,u) in zip(pos,bounds))
 assert all(l<=u for l,u in pos)
 return box,pos,choices

def replay_bound_leaf(leaf,prefix_path,bounds):
 assert leaf['context_version']=='strict_bulk_2026_11_03_v14'
 state=bounded_state(leaf['path'],prefix_path,bounds)
 def reconstruct(request):
  assert request==leaf['path'];return state
 namespace=dict(V.replay_current_leaf.__globals__);namespace['reconstruct']=reconstruct
 routine=FunctionType(V.replay_current_leaf.__code__,namespace)
 return routine(leaf)

def run(job):
 row,seed,limit,*extra=job
 core_first=bool(extra and extra[0])
 import numpy as np
 import weak_outer_numeric_strict_bulk_v14_lp as M
 import weak_outer_numeric_strict_bulk_v14_branch as B
 warnings.filterwarnings('ignore');M.linprog=B.capture_lp
 start=time.monotonic();prefix=row['path'];record=json.loads((HERE/'prefixes'/(row['id']+'.json')).read_text())
 assert record['id']==row['id'] and record['path']==prefix
 bounds,deductions=replay_prefix(record)
 fl=lambda z:tuple(tuple(float(v) for v in interval) for interval in z)
 leaves=list(seed.get('leaves',[]));pending=[f['path'] for f in seed['frontier']] if 'frontier' in seed else [prefix]
 frontier=[];decisions=[];errors=[];nodes=0
 # Always give the whole parent a direct test under its certified root bounds.
 direct=True
 while (direct or pending) and nodes<limit:
  path=prefix if direct else pending.pop();was_direct=direct;direct=False;nodes+=1
  box,pos,ch=bounded_state(path,prefix,bounds)
  hit,point,data=M.solve(fl(box),fl(pos),ch)
  if hit is not None:
   leaf=json.loads(json.dumps({'path':path,**hit,'uses_inherited_bounds':True}))
   try:
    reserve,terminal=replay_bound_leaf(leaf,prefix,bounds)
    leaf['checked_reserve']=str(reserve);leaf['checked_terminal']=terminal
    if was_direct:
     leaves=[leaf];pending=[];break
    leaves.append(leaf);continue
   except Exception:errors.append({'path':path,'candidate':leaf,'error':traceback.format_exc()})
  if was_direct:continue
  if point is None:
   frontier.append({'path':path,'reason':'NO_LP_POINT'});continue
  selected={(pair,kind) for pair,kind,_ in ch};centers=point.reshape(9,2);pairs=[]
  for i in range(9):
   for j in range(i+1,9):
    if ((i,j),'sat') not in selected:pairs.append((float(max(abs(centers[j]-centers[i]))),(i,j)))
  if not pairs:
   frontier.append({'path':path,'reason':'ALL_SAT_PAIRS_RETAINED_RELAXATION_FEASIBLE','relaxed_variables':list(map(float,B._last))});continue
  core=next((pair for pair in ((2,3),(3,6),(0,4)) if (pair,'sat') not in selected),None) if core_first else None
  if core is not None:pair=core;kind='sat'
  else:
   _,pair=min(pairs);kind='sat' if (pair,'proxy') in selected else 'proxy'
  query=(kind,pair);decisions.append({'path':path,'query':[kind,list(pair)],'relaxed_centers':list(map(float,point))})
  for step in reversed(children(query)):
   child=path+[step];V.reconstruct(child);pending.append(child)
 frontier.extend({'path':p,'reason':'NODE_LIMIT'} for p in pending)
 closed=not frontier and not errors
 if closed:verify_cell_union(prefix,leaves)
 return {'id':row['id'],'sign':row['sign'],'path':prefix,'status':'CLOSED' if closed else 'OPEN','nodes':nodes,
         'inherited_partial_nodes':seed.get('nodes',0),'verified_bound_deductions':deductions,
         'prefix_sha256':hashlib.sha256((HERE/'prefixes'/(row['id']+'.json')).read_bytes()).hexdigest(),
         'proved_parent_positions':[[str(a),str(b)] for a,b in bounds],
         'leaves':leaves,'frontier':frontier,'decisions':decisions,'errors':errors,'seconds':time.monotonic()-start,'core_first':core_first}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--nodes',type=int,default=48);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--limit',type=int);ap.add_argument('--name',default='combined48_report');ap.add_argument('--core-first',action='store_true');ap.add_argument('--fresh',action='store_true');ap.add_argument('--ids',nargs='*');args=ap.parse_args()
 register=json.loads((HERE/'whole_cell_payload/fixed_231_register.json').read_text());baseline={r['id']:r for r in register['cells'] if r['status']=='OPEN'}
 closed=set();seeds={}
 for name in ('pair_pilot_report.json','physical_scale24_report.json','near_parents_first_report.json','near_parents_second_report.json','near_parents_final_report.json'):
  path=PARENT/name
  if not path.exists():continue
  for row in json.loads(path.read_text())['results']:
   if row['status']=='CLOSED':closed.add(row['id'])
   if row['id'] not in seeds or row.get('nodes',0)>seeds[row['id']].get('nodes',0):seeds[row['id']]=row
 closed.update(('negative-64094241c36c4fc8','negative-e82c87a207fdb074','positive-1077638afc8dc284','positive-9cc839d8f2504bca','positive-a76638de241e6faf','positive-fbac60a51d1e7f99','negative-0b5d0bfec10c8526'))
 # These broad parents are concurrently assigned to independent agents.
 assigned={'positive-2d5aba857f2f7602','positive-2c719a20ef7510de'}
 targets=[r for r in baseline.values() if r['id'] not in closed|assigned]
 if args.ids:targets=[r for r in targets if r['id'] in args.ids]
 targets.sort(key=lambda r:(len(seeds.get(r['id'],{}).get('frontier',[])),-len(r['path'])))
 if args.limit:targets=targets[:args.limit]
 for r in targets:
  source=Path('/workspace/scratch/d0343140cf14')/(r['sign']+'_work')/'tight_bound_discovery'/(r['id']+'.json')
  (HERE/'prefixes'/source.name).write_bytes(source.read_bytes())
 result=[];start=time.monotonic()
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  jobs={pool.submit(run,(r,r if args.fresh else seeds.get(r['id'],r),args.nodes,args.core_first)):r['id'] for r in targets}
  for future in concurrent.futures.as_completed(jobs):
   try:r=future.result()
   except Exception:r={'id':jobs[future],'status':'OPEN','error':traceback.format_exc()}
   result.append(r)
   report={'scope':'Complete fixed parent proofs with independently replayed acyclic bound prefixes; unproved parents stayOPEN',
           'target_ids':[r['id'] for r in targets],'node_limit':args.nodes,'completed':len(result),'closed_original_parents':sum(r['status']=='CLOSED' for r in result),'results':result,'seconds':time.monotonic()-start,'whole_mask_closed':False}
   target=HERE/(args.name+'.json');temp=target.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(target)
   print(r['id'],r['status'],'nodes',r.get('nodes'),'leaves',len(r.get('leaves',[])),'frontier',len(r.get('frontier',[])),'seconds',round(r.get('seconds',0),1),flush=True)
if __name__=='__main__':main()
