# Seven further complete original 001/00 cells

This frozen package continues commit 2da31921d94e3868629eea9e36e4f5e286e1ae9e.
It proves seven distinct original parent predicates, reducing the same
231-cell register from 152 CLOSED / 79 OPEN to 159 CLOSED / 72 OPEN.
It closes no whole mask. All 24 previously OPEN masks remain OPEN.

The seven certificates use 245 acyclic parent-coordinate deductions,
279 complete terminal leaves, and 159 positive-reserve weighted leaves.
The remaining 120 terminals are exact interval or accepted analytic checks.
The printed tables contain 3,506 explicit rows across rounds and leaves.

## Exact replay

Python 3 and its standard library suffice for the reviewers. From this
directory:

```sh
python review_combined.py combined_closed_v1.json --name fresh_exact_review
python check_combined_tables.py fresh_exact_review_tables.json --report fresh_printed_review.json
```

The reviewer reconstructs all acyclic bound rounds, all physical rows and
all complete parent unions. It imports no discovery producer. The separate
printed checker sums all rational multipliers independently. Inherited
physical sources are byte-identical to the accepted original archive;
the delivered manifest binds each source, certificate and report. The
source register has the immutable original predicates and is intentionally
not replaced by the latest status register when replaying these new proofs.

`combined_negative_controls.json` records rejection of four damaged
certificates: missing child, invalid bound, zero contradiction weights,
and wrong original parent prefix. `cell_index.json` identifies every new
complete parent and all 72 unchanged OPEN parents. The geometric assembly
is in `A2_00100_BOUND_PAIR_CONTINUATION.md`; the unique-penultimate theorem
is an additional reviewed hand consequence, not a premise of these seven
certificates and not a cell closure by itself.

No optimizer assertion, Lean, Lake, CI, human review or proof-kernel
verification is claimed. Partial search forests are not included as proofs.
