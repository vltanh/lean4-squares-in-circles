from pathlib import Path
import copy
import gzip
import hashlib
import io
import json
import shutil
import tarfile

BASE = Path('/workspace/scratch/f694a78df3e7')
ROOT = BASE / 'pr11/research/nine'
SOURCE = BASE / 'physical_pilots/combined_bounds'
DEST = BASE / 'integration/checkpoint_7'
DEST.mkdir(exist_ok=True)

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before_file = DEST / 'previous_fixed_register.json'
if not before_file.exists():
    shutil.copy2(ROOT / 'gates/A2_00100_FIXED_FRONTIER.json', before_file)
before = json.loads(before_file.read_text())
assert (before['closed_cells'], before['open_cells']) == (152, 79)
data = json.loads((SOURCE / 'combined_closed_v1.json').read_text())
assert sha(SOURCE / 'combined_closed_v1.json') == '23e291552bb6a945c35504d9cd055fcdfd08ef1f05a125c6421872c23c1c6fa8'
review = json.loads((SOURCE / 'root_combined_v1.json').read_text())
assert review['status'] == 'PASS' and review['original_parents'] == 7
assert review['source_report_sha256'] == sha(SOURCE / 'combined_closed_v1.json')
arithmetic = json.loads((BASE / 'root_review/combined_printed_arithmetic.json').read_text())
assert arithmetic['status'] == 'PASS_PRINTED_ARITHMETIC'
assert arithmetic['table_sha256'] == sha(SOURCE / 'root_combined_v1_tables.json')
assert arithmetic['bound_deductions'] == 245 and arithmetic['terminal_leaves'] == 279

for name in ['combined_closed_v1.json', 'root_combined_v1.json', 'root_combined_v1_tables.json',
             'review_combined.py', 'review_tight_bounds_independent.py',
             'bound_prefix.py', 'run_combined.py', 'PROOF_SCHEMA.md', 'combined_negative_controls.json']:
    shutil.copy2(SOURCE / name, DEST / name)
for name in ['check_combined_tables.py', 'combined_printed_arithmetic.json']:
    shutil.copy2(BASE / 'root_review' / name, DEST / name)

payload = DEST / 'whole_cell_payload'
payload.mkdir(exist_ok=True)
with tarfile.open(ROOT / 'computer_assisted/a2_00100_fixed_frontier_checkpoint.tar.gz', 'r:gz') as original_archive:
    members = {Path(m.name).name: m for m in original_archive.getmembers() if m.isfile()}
    source_count = 0
    for file in sorted((SOURCE / 'whole_cell_payload').glob('*.py')):
        assert file.name in members
        assert original_archive.extractfile(members[file.name]).read() == file.read_bytes()
        shutil.copy2(file, payload / file.name)
        source_count += 1
assert source_count == 27
shutil.copy2(SOURCE / 'whole_cell_payload/fixed_231_register.json', payload / 'fixed_231_register.json')
register_payload = json.loads((payload / 'fixed_231_register.json').read_text())
assert [(c['id'], c['path']) for c in before['cells']] == [(c['id'], c['path']) for c in register_payload['cells']]

after = copy.deepcopy(before)
cells = {c['id']: c for c in after['cells']}
old_ids = {c['id'] for c in before['cells'] if c['status'] == 'CLOSED'}
prefix_dir = DEST / 'prefixes'
prefix_dir.mkdir(exist_ok=True)
new_ids = []
index_records = []
for record in data['results']:
    ident = record['id']
    assert ident not in new_ids and ident not in old_ids
    assert record['status'] == 'CLOSED' and not record['frontier'] and not record.get('errors')
    c = cells[ident]
    assert c['status'] == 'OPEN' and c['path'] == record['path']
    assert ident == c['sign'] + '-' + hashlib.sha256(json.dumps(c['path'], separators=(',', ':')).encode()).hexdigest()[:16]
    prefix = SOURCE / 'prefixes' / (ident + '.json')
    assert sha(prefix) == record['prefix_sha256']
    shutil.copy2(prefix, prefix_dir / prefix.name)
    new_ids.append(ident)
    evidence = {'archive': 'a2_00100_bound_pair_checkpoint.tar.gz',
                'method': 'proved_parent_bounds_then_complete_physical_pair_tree',
                'certificate': 'combined_closed_v1.json', 'record_id': ident,
                'bound_prefix': 'prefixes/' + ident + '.json',
                'prefix_sha256': record['prefix_sha256'],
                'independent_report': 'root_combined_v1.json',
                'printed_arithmetic_report': 'combined_printed_arithmetic.json',
                'bound_deductions': record['verified_bound_deductions'],
                'terminal_leaves': len(record['leaves'])}
    c.update(status='CLOSED', evidence=evidence, method=evidence['method'], terminal_leaves=len(record['leaves']))
    index_records.append({'id': ident, 'path': c['path'], **evidence})
assert len(new_ids) == 7
assert sum(c['status'] == 'CLOSED' for c in cells.values()) == 159
assert sum(c['status'] == 'OPEN' for c in cells.values()) == 72
assert [(c['id'], c['path']) for c in after['cells']] == [(c['id'], c['path']) for c in before['cells']]
after.update(closed_cells=159, open_cells=72, latest_new_closed_cells=7,
             cumulative_new_closed_since_53=106,
             assembly='../A2_00100_BOUND_PAIR_CONTINUATION.md',
             cell_review='../A2_00100_BOUND_PAIR_CONTINUATION.md',
             manifest='../computer_assisted/a2_00100_bound_pair_manifest.json',
             open_cell_discovery_report='../computer_assisted/a2_00100_bound_pair_manifest.json')
after['preceding_assembly'] = '../A2_00100_PHYSICAL_PAIR_CLOSURE_CHECKPOINT.md'
after['preceding_manifest'] = '../computer_assisted/a2_00100_physical_pair_closure_manifest.json'
write_json(ROOT / 'gates/A2_00100_FIXED_FRONTIER.json', after)
write_json(DEST / 'cell_index.json', {
    'status': 'PASS_DISTINCT_COMPLETE_ORIGINAL_PARENTS', 'before': {'closed': 152, 'open': 79},
    'after': {'closed': 159, 'open': 72}, 'new_cells': index_records,
    'remaining_open_ids': sorted(c['id'] for c in cells.values() if c['status'] == 'OPEN'),
    'original_ids_and_paths_unchanged': True, 'whole_mask_closed': False})

theorem = BASE / 'global_masks/WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md'
assert sha(theorem) == '618e099086b5a98b60a38456e25dcce00d57075169aa716b1d59f0813b4ab407'
shutil.copy2(theorem, ROOT / theorem.name)
shutil.copy2(theorem, DEST / theorem.name)
for name in ['A2_00100_BOUND_PAIR_CONTINUATION.md', 'WEAK_OUTER_UNIQUE_PENULTIMATE_INDEPENDENT_REVIEW.md']:
    shutil.copy2(ROOT / name, DEST / name)
shutil.copy2(Path(__file__), DEST / Path(__file__).name)

(DEST / 'README.md').write_text('''# Seven further complete original 001/00 cells

This frozen package continues commit 2da31921d94e3868629eea9e36e4f5e286e1ae9e.
It proves seven distinct original parent predicates, reducing the same
231-cell register from 152 CLOSED / 79 OPEN to 159 CLOSED / 72 OPEN.
It closes no whole mask. All 24 previously OPEN masks remain OPEN.

The seven certificates use 245 acyclic parent-coordinate deductions,
279 complete terminal leaves, and 159 positive-reserve weighted leaves.
The remaining 120 terminals are exact interval or accepted analytic checks.
The printed tables contain 3,506 explicit rows across rounds and leaves.

## Exact replay

Python 3 and its standard library suffice for the reviewers. From this
directory:

```sh
python review_combined.py combined_closed_v1.json --name fresh_exact_review
python check_combined_tables.py fresh_exact_review_tables.json --report fresh_printed_review.json
```

The reviewer reconstructs all acyclic bound rounds, all physical rows and
all complete parent unions. It imports no discovery producer. The separate
printed checker sums all rational multipliers independently. Inherited
physical sources are byte-identical to the accepted original archive;
the delivered manifest binds each source, certificate and report. The
source register has the immutable original predicates and is intentionally
not replaced by the latest status register when replaying these new proofs.

`combined_negative_controls.json` records rejection of four damaged
certificates: missing child, invalid bound, zero contradiction weights,
and wrong original parent prefix. `cell_index.json` identifies every new
complete parent and all 72 unchanged OPEN parents. The geometric assembly
is in `A2_00100_BOUND_PAIR_CONTINUATION.md`; the unique-penultimate theorem
is an additional reviewed hand consequence, not a premise of these seven
certificates and not a cell closure by itself.

No optimizer assertion, Lean, Lake, CI, human review or proof-kernel
verification is claimed. Partial search forests are not included as proofs.
''')

file_hashes = {str(p.relative_to(DEST)): sha(p) for p in sorted(DEST.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
write_json(DEST / 'manifest.json', {'schema': 'a2-00100-bound-pair-payload-v1',
    'files_sha256': file_hashes, 'original_archive_git_blob': '4a104744e1bf439e006a1c034eea284fd22fa8c8',
    'matched_inherited_python_files': source_count,
    'verifier_sha256': 'ec1b7de7b15bcc9d89d12087bff974c68e6d056bdaae26b482d514027ec97993',
    'whole_mask_closed': False})

out = ROOT / 'computer_assisted/a2_00100_bound_pair_checkpoint.tar.gz'
with out.open('wb') as binary:
    with gzip.GzipFile(filename='', mode='wb', fileobj=binary, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for p in sorted(DEST.rglob('*')):
                if not p.is_file():
                    continue
                name = str(Path('a2_00100_bound_pair_checkpoint') / p.relative_to(DEST))
                data_bytes = p.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data_bytes)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data_bytes))

write_json(ROOT / 'computer_assisted/a2_00100_bound_pair_manifest.json', {
    'schema': 'a2-00100-bound-pair-delivery-v1', 'baseline_commit': '2da31921d94e3868629eea9e36e4f5e286e1ae9e',
    'target_mask': '001/00', 'reversal_partner': '100/00', 'strict_q': '1105/256',
    'archive': out.name, 'archive_sha256': sha(out), 'archive_bytes': out.stat().st_size,
    'archive_directory': 'a2_00100_bound_pair_checkpoint', 'original_cell_count': 231,
    'new_closed_original_cells': 7, 'cumulative_new_since_53': 106,
    'before': {'closed': 152, 'open': 79}, 'after': {'closed': 159, 'open': 72},
    'bound_deductions': 245, 'terminal_leaves': 279, 'weighted_leaves': 159,
    'printed_rows_across_rounds_and_leaves': 3506,
    'whole_masks': {'closed': 8, 'open': 24, 'new': 0},
    'positional_roots': {'closed_historical': 5838, 'open': 2077, 'new': 0},
    'roadmap_gate_count': 15, 'new_roadmap_closures': 0, 'lean_lake_ci_run': False,
    'proof': '../A2_00100_BOUND_PAIR_CONTINUATION.md',
    'register': '../gates/A2_00100_FIXED_FRONTIER.json', 'index': 'cell_index.json',
    'arithmetic_reports': ['root_combined_v1.json', 'combined_printed_arithmetic.json'],
    'inherited_frozen_verifier_sha256': 'ec1b7de7b15bcc9d89d12087bff974c68e6d056bdaae26b482d514027ec97993',
    'old_baseline_arithmetic_repeated': False, 'human_or_kernel_verification': False,
    'additional_hand_theorem': '../WEAK_OUTER_UNIQUE_PENULTIMATE_ORIGINAL_HAND_PROOF.md',
    'theorem_is_premise_of_these_seven_proofs': False})
print(json.dumps({'status': 'ASSEMBLED', 'archive_bytes': out.stat().st_size,
                  'archive_sha256': sha(out), 'new_original_ids': new_ids,
                  'closed': 159, 'open': 72, 'files': len(file_hashes)}, indent=2))
