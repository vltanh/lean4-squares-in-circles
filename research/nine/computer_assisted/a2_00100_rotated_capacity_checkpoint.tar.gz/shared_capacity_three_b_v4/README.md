# Portable independent replay: first three v4 B-family originals

This release proves exactly these complete unchanged original parents:

- `negative-336d2542a912859a`
- `negative-f9e691c011ecb5af`
- `negative-364c20a39079cecd`

It contains 124 inherited coordinate deductions, 1,592 new exact deductions,
and 1,931 printed row occurrences. It adds zero branches. Each original
path and ID is checked against the frozen 168/63 register. The preceding
three A-family v1 proofs are separate, immutable evidence; together the
six new original closures bring that checkpoint to 174 CLOSED / 57 OPEN.
No whole mask, positional root or roadmap gate is declared closed here.

## Reproduce

From this extracted directory, using standard-library Python:

    python verify_shared_bound.py --all
    python check_rejection_controls.py
    python check_v4_hand_terminals.py

A single original can be replayed with:

    python verify_shared_bound.py --id negative-336d2542a912859a

The normal verifier checks source/input hashes, full original path and
prior deductions, every old-state row, simultaneous bound installation,
all physical frame inversions, and the terminal contradiction. It does
not import a numerical optimizer, discovery producer, or new discovery
row generator. Accepted frozen historical unweighted geometry is reused.

`independent_v4_rows.py` independently constructs interval support-radius,
rotated three-original strip, and strict forced-gap rows with Fractions
and exact integer square root. It uses box-vertex projections. Seven
semantic damaged records are rejected, and four exact boundary controls
check that contacts at longitudinal gap +1 or −1 are retained correctly.

## Hand proofs and terminal meanings

`reports/THREE_B_ORIGINALS_INDEPENDENT_REVIEW.md` gives the complete review
scope and short physical terminals. Both 336 and f9 imply the same
impossible original D frame: `|t_D|>2/7` and `g_D>13/32`, whereas the exact
factorization in that review gives `g_D<13/32`. The 364 proof gives equal
H/I x coordinates and vertical distance below one, contradicting their
physical incircle center distance. Its two weighted rows cancel exactly
and leave `0<=−1`.

The new forced-gap and rotated-strip implications are proved in
`proofs/FORCED_DISTANCE_AND_ROTATED_STRIP_HAND_PROOF.md`. The shared
three-original strip theorem, original inset family and owner-free
support proofs are included separately. All arithmetic and interval
preconditions remain tied to the original physical variables.

The two analytic-frame terminals occur after the last simultaneous
bounds and exact slope inversion. The frozen producer serializes its
preceding committed angle/position/scalar state at this early exit,
while its final differences include the new proposals. The independent
verifier checks that convention explicitly and reconstructs the actual
empty scalar intersection; it never accepts the terminal label alone.

## Files and integrity

- `certificates/`: the three unchanged discovery records.
- `priors/`: exact inherited prefixes, replayed from the original paths.
- `geometry/`: minimal accepted historical physical-row dependencies.
- `sources/`: byte-bound discovery sources for provenance only.
- `reports/`: complete independent replay reports, separate terminal
  arithmetic reviews, damaged controls, and baseline assembly audit.
- `replay_index.json`: relative input/source binding map.
- `SHA256_MANIFEST.json`: hashes every delivered file other than itself.

The baseline assembly audit confirms that the preceding v1 checkpoint
kept all 231 original paths and closed exactly its three named A cells.
Its completed early branch contains 14 fixed original descendants and
1,305 previously proved baseline leaves; the accepted baseline cover is
reused without repeating historical leaf arithmetic. This audit does
not enlarge any v4 original's domain.

No Lean, Lake or CI was run. Internal independent source, mathematical
and rational-arithmetic reviews are not human or proof-kernel verification.
