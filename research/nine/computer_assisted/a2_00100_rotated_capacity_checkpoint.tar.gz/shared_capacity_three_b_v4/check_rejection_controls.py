#!/usr/bin/env python3
"""Semantic controls for v4's guards, deduction sums and two terminal rules.

The normal verifier separately binds input bytes. Here temporary records
deliberately bypass that binding to exercise the mathematical checks.
"""
from copy import deepcopy
from fractions import Fraction as Q
from pathlib import Path
from tempfile import TemporaryDirectory
from itertools import combinations
import json
import verify_shared_bound as V
from independent_v4_rows import forced_gaps

ROOT=Path(__file__).resolve().parent
controls=[]
with TemporaryDirectory(prefix='semantic_controls_',dir=ROOT) as tmp:
    def reject(ident,label,edit):
        saved_entry=deepcopy(V.INDEX['certificates'][ident])
        record=json.loads((ROOT/saved_entry['certificate']).read_text())
        edit(record)
        target=Path(tmp)/(label+'.json')
        target.write_text(json.dumps(record))
        V.INDEX['certificates'][ident]=dict(saved_entry,certificate=str(target.relative_to(ROOT)))
        try:
            V.verify_certificate(ident)
        except AssertionError as error:
            controls.append(dict(control=label,status='REJECTED',assertion=str(error)))
        else:
            raise RuntimeError('Damaged record accepted: '+label)
        finally:
            V.INDEX['certificates'][ident]=saved_entry

    def change_guard(record,family,field):
        for rr in record['rounds']:
            for guard in rr['three_square_guards']:
                if guard.get('extension_rule')==family:
                    guard[field]=str(Q(guard[field])+1)
                    return
        raise RuntimeError('Requested guard family is not exercised')

    first='negative-336d2542a912859a'
    third='negative-364c20a39079cecd'
    reject(first,'changed_original_path',lambda d:d['path'][0].__setitem__(2,1))
    reject(first,'unproved_installed_bound',lambda d:d['rounds'][0]['proposals'][0].__setitem__(
        'upper',str(Q(d['rounds'][0]['proposals'][0]['proved_upper'])-1)))
    reject(first,'altered_rotated_strip_width',lambda d:change_guard(d,'rational_rotated_strip','width_upper'))
    reject(first,'altered_forced_gap_root',lambda d:change_guard(d,'forced_distance_gap','rational_gap_lower'))
    reject(first,'altered_terminal_frame_inversion',lambda d:d['rounds'][-1]['physical_frame_inferences'][3][
        'new_slope_interval'].__setitem__(1,'0'))
    reject(first,'unsupported_terminal_label',lambda d:d['terminal'].__setitem__('kind','proved_empty_interval'))
    reject(third,'altered_positive_terminal_multiplier',lambda d:d['terminal']['weights'][0].__setitem__(
        1,d['terminal']['weights'][0][1]+1))

# Contacts at z=+/-1 are genuine possibilities when the transverse gap is
# zero. A non-strict exclusion test would incorrectly eliminate them.
contact_controls=[]
for lo,hi,expected in [(-1,0,{-1}),(0,1,{1}),(-1,1,set()),(Q(-1,2),Q(1,2),{-1,1})]:
    boxes={pair:((Q(-2),Q(2)),(Q(-2),Q(2))) for pair in combinations(range(9),2)}
    boxes[(0,1)]=((Q(0),Q(0)),(Q(lo),Q(hi)))
    radii={pair:Q(1) for pair in boxes}
    rows,guards=forced_gaps(boxes,radii)
    selected=[g for g in guards if g['pair']==[0,1] and g['transverse_direction']==['1','0']]
    signs={g['longitudinal_sign'] for g in selected}
    assert signs==expected
    contact_controls.append(dict(longitudinal_interval=list(map(str,(lo,hi))),
                                 expected_signs=sorted(expected),actual_signs=sorted(signs),status='PASS'))
result=dict(status='PASS',rejected=len(controls),controls=controls,
            exact_contact_controls=contact_controls)
(ROOT/'reports/portable_rejection_controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='PASS',rejected=len(controls),exact_contact_controls=len(contact_controls))))
