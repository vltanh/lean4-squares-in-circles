#!/usr/bin/env python3
"""Exact arithmetic of the three short hand terminals, separate from replay.

This script does not establish the premises: the full independent verifier
must derive them from their complete original parents.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib
import json

ROOT=Path(__file__).resolve().parent
EXPECTED={
    'negative-336d2542a912859a':'53689dba3b649e96830f88bd4f248fcb2a377d2352e79010af7a18203c0360a9',
    'negative-f9e691c011ecb5af':'5c4aa77cb285009e747237c8cdad48680da3bb2277bf36959838964ce208f910',
    'negative-364c20a39079cecd':'e948b926a91dbad6a9e3b0489569cbd5b753796bd5bfdbfa57d79560c50b4676',
}
records={}
for ident,expected in EXPECTED.items():
    raw=(ROOT/'certificates'/(ident+'.json')).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==expected
    records[ident]=json.loads(raw)

# Polynomial coefficient identity, in increasing powers of m:
# 53(1+m)^2-81(1+m^2)=2(7m-2)(7-2m).
left=[Q(53)-81,Q(106),Q(53)-81]
right=[2*Q(-2)*7,2*(Q(7)*7+Q(-2)*(-2)),2*Q(7)*(-2)]
assert left==right==[Q(-28),Q(106),Q(-28)]
squared_gap=Q(13,32)**2-Q(53,324)
assert squared_gap==Q(121,82944)>0
results=[]
for ident,g_lower in (
    ('negative-336d2542a912859a',Q(215767,524288)),
    ('negative-f9e691c011ecb5af',Q(53425,131072)),
):
    record=records[ident]
    assert record['terminal']==dict(kind='proved_empty_analytic_frame')
    rr=record['rounds'][-1]
    inference=rr['physical_frame_inferences'][3]
    assert inference['original']==3
    lo,hi=map(Q,inference['new_slope_interval'])
    assert -1<=lo<=hi<0
    magnitude=-hi
    assert magnitude>Q(2,7) and g_lower>Q(13,32)
    proposals=[p for p in rr['proposals'] if p['kind']=='scalar' and p['key']==48 and p['sign']==-1]
    assert len(proposals)==1 and -Q(proposals[0]['upper'])==g_lower
    results.append(dict(id=ident,status='PASS_SHARED_D_FRAME_HAND_TERMINAL',
                        magnitude_lower=str(magnitude),magnitude_excess=str(magnitude-Q(2,7)),
                        inset_lower=str(g_lower),inset_excess=str(g_lower-Q(13,32))))

ident='negative-364c20a39079cecd'
terminal=records[ident]['terminal']
assert terminal['kind']=='positive_exact_reserve'
assert len(terminal['rows'])==2
coefficients=[Q(0)]*54
rhs=Q(0)
for row in terminal['rows']:
    rhs+=Q(row['rhs'])/2
    for column,value in row['coefficients']:
        coefficients[column]+=Q(value)/2
assert all(c==0 for c in coefficients) and rhs==-1
guards=[g for g in terminal['state']['three_square_guards']
        if g.get('name') in {row['name'] for row in terminal['rows']}]
assert len(guards)==2
for g in guards:
    assert g['pair']==[7,8] and g['transverse_interval']==['0','0']
    assert list(map(Q,g['longitudinal_interval']))==[Q(-482409,524288),Q(482409,524288)]
    assert g['radius_lower']==g['rational_gap_lower']=='1'
assert Q(482409,524288)<1
results.append(dict(id=ident,status='PASS_HI_TWO_ROW_HAND_TERMINAL',
                    all_54_coefficients_zero=True,negative_rhs='-1',
                    center_gap_upper='482409/524288',strict_shortfall=str(1-Q(482409,524288))))
report=dict(status='PASS',scope='Short terminal arithmetic only; original-parent premise replay is required separately.',
            shared_D_polynomial_coefficients=list(map(str,left)),
            shared_D_squared_gap=str(squared_gap),terminals=results)
(ROOT/'reports/v4_hand_terminals.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
