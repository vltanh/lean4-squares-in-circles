#!/usr/bin/env python3
"""Finite three-round discovery for all surviving C887 I21 sharp failures."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'c887_I21_sharp_complete_screen/completed_discovery_manifest.json'
OUT = HERE / 'c887_I21_sharp_bound3'
PRODUCER = HERE / 'c887_sharp_complement_bounds.py'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert not OUT.exists()
source_bytes = SOURCE.read_bytes()
source_hash = hashlib.sha256(source_bytes).hexdigest()
manifest = copy.deepcopy(json.loads(source_bytes))
assert manifest['schema'] == 'declared_inherited_CD_tile_sharp_guard_cover_v1'
assert [entry['index'] for entry in manifest['children']] == list(range(20))
assert manifest['selected_row'] == [0, 7, 8, 3]
assert manifest['beta_bound'] == '1/200' and manifest['variation_bound'] == '53/100'
assert manifest['complete_closed_domains'] == 20 and manifest['closed_faces_retained'] is True
assert all(entry['kind'] in ('interval_exclusion', 'bound_terminal', 'open_bound_state')
           for entry in manifest['children'])
assert sha(PRODUCER) == 'e394a7ecb6df2cc618f26f7d23dcd6cb95bddb18dd3eb30e8316c31a11d867ff'
parent = manifest['parent']
assert sha(parent['path']) == parent['sha256']
manifest['continued_discovery_source'] = dict(path=str(SOURCE), sha256=source_hash)
manifest['local_bound_round_budget'] = 3
manifest['workers'] = 2
manifest['new_original_cells'] = manifest['new_masks'] = 0
manifest['sources'][str(Path(__file__).resolve())] = sha(__file__)
manifest['sources'][str(SOURCE)] = source_hash
jobs = []
for entry in manifest['children']:
    if entry['kind'] != 'open_bound_state':
        continue
    previous = entry['bound']
    assert sha(previous['path']) == previous['sha256']
    old = json.loads(Path(previous['path']).read_text())
    assert old['status'] == 'OPEN' and old['rounds'] == [] and 'final' in old
    assert old['final_test']['round'] == 0 and old['final_test']['proposals'] == []
    assert old['sharp_restriction']['parent'] == parent
    assert old['sharp_restriction']['branch'] == entry['index']
    assert old['sharp_restriction']['conditional_row'] == entry['row']
    manifest['sources'][previous['path']] = previous['sha256']
    jobs.append((entry['index'], copy.deepcopy(previous), old['sharp_restriction']))


def check_inputs():
    assert SOURCE.read_bytes() == source_bytes
    for name, value in manifest['sources'].items():
        assert sha(name) == value, name


check_inputs()
OUT.mkdir()
specification = OUT / 'FINITE_THREE_ROUND_SPECIFICATION.json'
specification.write_text(json.dumps(manifest, indent=2) + '\n')
specification_hash = sha(specification)


def save():
    check_inputs()
    assert sha(specification) == specification_hash
    temporary = OUT / 'completed_discovery_manifest.json.partial'
    temporary.write_text(json.dumps(manifest, indent=2) + '\n')
    temporary.replace(OUT / 'completed_discovery_manifest.json')


def work(job):
    index, previous, restriction = job
    check_inputs()
    output = OUT / ('branch_%02d' % index)
    log = OUT / ('branch_%02d.log' % index)
    assert not output.exists() and not log.exists()
    print('START_CLOSED_SHARP_FAILURE_BOUNDS', index, flush=True)
    with log.open('w') as stream:
        process = subprocess.run([
            sys.executable, '-u', str(PRODUCER), parent['path'], str(output),
            str(index), '--row', 'AHID', '--beta', manifest['beta_bound'],
            '--variation', manifest['variation_bound'], '--rounds', '3',
        ], cwd=HERE, stdout=stream, stderr=subprocess.STDOUT)
    assert process.returncode == 0, (index, process.returncode, str(log))
    bound = output / 'bound_rounds.json'
    record = json.loads(bound.read_text())
    assert record['id'] == 'negative-887236b78100baf3'
    assert record['schema'] == 'CD_inherited_sharp_complement_bound_discovery_v1'
    assert record['scope'] == 'ONE_CLOSED_SHARP_GUARD_FAILURE_OF_DECLARED_INHERITED_TILE'
    assert record['status'] in ('OPEN', 'CANDIDATE_CLOSED') and 'final' in record
    assert record['sharp_restriction'] == restriction
    assert len(record['rounds']) <= 3
    if record['status'] == 'OPEN':
        assert record['final_test']['round'] == len(record['rounds'])
        assert record['final_test']['proposals'] == []
    else:
        assert 'terminal' in record
    check_inputs()
    return index, dict(
        kind='bound_terminal' if record['status'] == 'CANDIDATE_CLOSED' else 'open_bound_state',
        bound=dict(path=str(bound), sha256=sha(bound), schema=record['schema']),
        status=record['status'], rounds=len(record['rounds']),
        actual_returncode=process.returncode, earlier_zero_round_screen=previous)


save()
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(work, job) for job in jobs]):
        index, answer = future.result()
        manifest['children'][index].update(answer)
        save()
        print('FINISHED_CLOSED_SHARP_FAILURE_BOUNDS', index, answer['status'],
              answer['rounds'], flush=True)
if all(entry['kind'] in ('interval_exclusion', 'bound_terminal') for entry in manifest['children']):
    complete = dict(manifest, schema='complete_inherited_CD_tile_sharp_guard_cover_v1',
                    status='COMPLETE_CANDIDATE_SHARP_COVER_REQUIRES_INDEPENDENT_REPLAY')
    (OUT / 'complete_cover.json').write_text(json.dumps(complete, indent=2) + '\n')
save()
print('COMPLETE_FINITE_C887_I21_SHARP_THREE_ROUND_PASS', flush=True)
