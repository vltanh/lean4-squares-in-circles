"""Replay the completed finite twenty-domain continuation; fourteen stay OPEN."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    assert __debug__
    manifest_bytes = (ROOT / 'SHA256_MANIFEST.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    def unchanged():
        assert (ROOT / 'SHA256_MANIFEST.json').read_bytes() == manifest_bytes
        for name, value in manifest['files'].items():
            path = (ROOT / name).resolve()
            assert path.is_relative_to(ROOT)
            assert hashlib.sha256(path.read_bytes()).hexdigest() == value, name
    unchanged()
    with (ROOT / 'ROUND3_ENERGY_REPLAY.log').open('w') as log:
        subprocess.run([sys.executable, '-B', '-S', str(ROOT / 'energy_proof/verify_all.py')],
                       cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    energy = json.loads((ROOT / 'energy_proof/COMPLETE_REPLAY.json').read_text())
    assert energy['status'] == 'PASS_SHARED_THREE_SQUARE_ENERGY_ROWS'
    assert energy['energy_lower_bound'] == '7/2'
    assert energy['exact_geometric_evaluators'] == 2 and energy['row_identities_checked'] == 1877
    from verify_CD_sharp_cover import SharpCoverChecker
    checker = SharpCoverChecker(context=ROOT, ancestry=ROOT / 'ancestry', strict_root=ROOT)
    report = checker.replay(ROOT / 'DECLARED_TWENTY_DOMAIN_BOUND3_COVER.json', allow_partial=True)
    checker.recheck()
    expected = dict(status='PASS_DECLARED_SHARP_COVER_WITH_OPEN_FAILURES',
                    complete_closed_guard_failures=20, interval_failure_domains=5,
                    bound_terminal_failure_domains=1, nested_complete_failure_domains=0,
                    open_failure_domains=14, bound_rounds=49, bound_deductions=3771,
                    bound_premise_rows=11391, terminal_rows=20,
                    complete_fixed_tiles=0, new_original_cells=0, new_masks=0,
                    complete_twenty_failure_cover_checked=False)
    for key, value in expected.items():
        assert report[key] == value, key
    assert report['open_failure_indices'] == [1, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16]
    for name, module in sys.modules.items():
        origin = getattr(module, '__file__', None)
        if origin and Path(origin).resolve().is_relative_to('/workspace'):
            assert Path(origin).resolve().is_relative_to(ROOT), name
    unchanged()
    report['portable_round3_inputs_checked'] = len(manifest['files'])
    report['physical_energy_theorem_replayed'] = True
    report['exact_energy_row_identities_replayed'] = 1877
    report['all_packet_inputs_rehashed_after_replay'] = True
    (ROOT / 'ROUND3_PORTABLE_REPLAY.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(expected, indent=2))

if __name__ == '__main__':
    main()
