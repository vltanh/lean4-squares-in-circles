#!/usr/bin/env python3
"""Predeclared 8x8 center cover; a single static exact dual per tile.

This is a discovery/recording tool, not an independently trusted verifier.
There is no adaptive subdivision or added bound round in any tile.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import sys, json, time, argparse, traceback, hashlib
from pathlib import Path
from fractions import Fraction as Q

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'b_macro'))
import b_pass_v2 as B
M=B.M
M.collect=B.collect

IDS=['negative-1a0e5a68ae364a5e','negative-f92d74e712afa6be']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def boxload(x):return tuple(tuple(Q(y)for y in z)for z in x)

def run(parent_id,first=0,last=64):
    source=HERE.parent/'b_macro/v2/results'/(parent_id+'.json')
    obj=json.loads(source.read_text())
    assert obj['id']==parent_id and obj['status']=='OPEN'
    path=obj['path'];_,_,choices=M.V.reconstruct(path)
    base={'id':parent_id,'path':path,'angles':boxload(obj['final_angles']),
          'positions':boxload(obj['final_positions']),'choices':choices,
          'scalar':boxload(obj['final_scalar'])}
    differences={tuple(d['pair']):boxload(d['intervals'])for d in obj['final_differences']}
    xa,xb=base['positions'][16];ya,yb=base['positions'][17]
    outdir=HERE/'fixed_i_grid'/parent_id;outdir.mkdir(parents=True,exist_ok=True)
    source_paths=[Path(__file__),Path(B.__file__),Path(M.__file__),Path(M.K.__file__),
                  Path(M.V.__file__),Path(M.R.__file__),Path(B.P.__file__),
                  Path(B.F.__file__),Path(B.A.__file__),Path(B.T.__file__),Path(B.S.__file__)]
    manifest={'schema':'n9_fixed_i_center_8x8_diagnostic_v1','id':parent_id,
              'scope':'WHOLE_PARENT_COVER_CONDITIONAL_ON_SOURCE_BOUND_V2_INDUCTION',
              'parent_source':str(source),'parent_sha256':sha(source),'path':path,
              'grid_size':[8,8],'covered_box':[[str(xa),str(xb)],[str(ya),str(yb)]],
              'coverage':'All 64 products of consecutive closed equal eighths; shared faces retained',
              'adaptive_splits':0,'additional_bound_rounds_per_tile':0,
              'static_dual_tests_per_tile':1,
              'sources':{str(p):sha(p)for p in source_paths},
              'acceptance':'Independent geometry, source-bound parent induction and all 64 tile proofs required',
              'lean_lake_ci_run':False}
    (outdir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    for tile in range(first,last):
        dest=outdir/f'tile_{tile:02d}.json'
        if dest.exists():continue
        ix,iy=divmod(tile,8)
        xpos=(xa+(xb-xa)*ix/8,xa+(xb-xa)*(ix+1)/8)
        ypos=(ya+(yb-ya)*iy/8,ya+(yb-ya)*(iy+1)/8)
        positions=list(base['positions']);positions[16]=xpos;positions[17]=ypos
        state=dict(base,positions=tuple(positions))
        record={'tile':tile,'ix':ix,'iy':iy,'I_box':M.render([xpos,ypos]),
                'status':'OPEN','parent_id':parent_id}
        started=time.monotonic()
        try:
            rows,absolute,terminal,pos,scalar,diffs,guards=M.collect(state,differences)
            record.update(rows=len(rows),propagated_positions=M.render(pos),
                          physical_scalar_intersection=M.render(scalar),
                          effective_differences=M.render_diff(diffs),three_square_guards=guards)
            if terminal:
                record.update(status='CANDIDATE_CLOSED',terminal={'kind':'exact_interval_or_accepted_terminal','label':terminal})
            else:
                h=M.highs(rows,len(absolute));h.run();status=h.getModelStatus()
                record['solver_status']=str(status)
                if status==M.H.HighsModelStatus.kOptimal:
                    solution=h.getSolution();phase=float(solution.col_value[-1]);record['phase_margin']=phase
                    if phase>1e-8:
                        weights=M.terms(solution.row_dual)
                        co,rhs=M.R.weighted_sum(rows,absolute,weights)
                        reserve=-rhs-sum(a*abs(v)for a,v in zip(absolute,co))
                        if reserve>0:
                            record.update(status='CANDIDATE_CLOSED',terminal={
                                'kind':'positive_exact_reserve','weights':weights,
                                'reserve':str(reserve),
                                'rows':M.R.printed_rows(rows,{i for i,w in weights}),
                                'absolute_variable_bounds':list(map(str,absolute)),
                                'weighted_coefficients':list(map(str,co)),
                                'weighted_rhs':str(rhs)})
                        else:record['rejected_numeric_reserve']=str(reserve)
                    else:
                        record['diagnostic_relaxed_centers']=solution.col_value[:18]
        except Exception:
            record['error']=traceback.format_exc()
        record['seconds']=round(time.monotonic()-started,3)
        dest.write_text(json.dumps(record,indent=2)+'\n')
        print(parent_id,tile,record['status'],record.get('phase_margin'),record['seconds'],flush=True)
    records=[json.loads(p.read_text())for p in sorted(outdir.glob('tile_*.json'))]
    closed=[r['tile']for r in records if r['status']=='CANDIDATE_CLOSED']
    opened=[r['tile']for r in records if r['status']!='CANDIDATE_CLOSED']
    result={'id':parent_id,'tiles_tested':len(records),'candidate_closed':closed,'open':opened,
            'all_64_candidate_closed':len(records)==64 and not opened,
            'status':'COMPLETE_CANDIDATE_PARENT_PROOF'if len(records)==64 and not opened else 'OPEN_PARENT_NO_CLOSURE',
            'independent_replay_status':'PENDING','new_cells_accepted':0}
    (outdir/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--id',choices=IDS);ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=64);a=ap.parse_args()
    for parent in ([a.id]if a.id else IDS):run(parent,a.start,a.stop)
