#!/usr/bin/env python3
"""Record the exact empty inherited difference on one frozen center tile.
This record is a candidate until independently replayed with the entire grid.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,hashlib,sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'current_proof/shared_capacity_three_b_v4'))
import verify_shared_bound as K

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def boxes(values):return tuple(tuple(F(v)for v in pair)for pair in values)
def render(values):return [[str(v)for v in pair]for pair in values]

ident='negative-e0dbb1642ee58e72'
source=ROOT/'b_macro/v2/results'/(ident+'.json')
parent=json.loads(source.read_text())
grid=ROOT/'global_nine_capacity/fixed_i_grid'/ident
tile=json.loads((grid/'tile_40.json').read_text())
summary=json.loads((grid/'summary.json').read_text())
assert summary['tiles_tested']==64 and summary['open']==[40]
assert tile['parent_id']==ident and tile['tile']==40 and tile['status']=='OPEN'
angles=boxes(parent['final_angles']);scalar=boxes(parent['final_scalar'])
positions=list(boxes(parent['final_positions']));union=boxes(tile['I_box']);positions[16:18]=union;positions=tuple(positions)
difference={tuple(d['pair']):boxes(d['intervals'])for d in parent['final_differences']}
_,_,choices=K.V.reconstruct(parent['path'])
effective,terminal=K.V.effective_boxes(angles,choices,K.LEGACY);assert terminal is None
propagated,heights,insets,terminal=K.V.center_bounds(effective,positions,choices,K.LEGACY);assert terminal is None
witnesses=[]
for pair in combinations(range(9),2):
 physical=K.V.difference_bounds(pair,propagated,insets,K.LEGACY)
 for axis in (0,1):
  inherited=difference[pair][axis];fresh=physical[axis]
  intersection=(max(inherited[0],fresh[0]),min(inherited[1],fresh[1]))
  if intersection[0]>intersection[1]:
   witnesses.append({'pair':list(pair),'axis':axis,'parent_interval':list(map(str,inherited)),'physical_interval':list(map(str,fresh)),'intersection':list(map(str,intersection)),'gap':str(intersection[0]-intersection[1])})
assert witnesses
record={
 'schema':'n9_frozen_i_grid_covering_rectangle_five_round_v1',
 'id':ident+'_covering_I_rectangle','path':parent['path'],'status':'CANDIDATE_CLOSED',
 'scope':'COMPLETE_FROZEN_GRID_COVERING_RECTANGLE_ONLY; NOT_WHOLE_PARENT_BY_ITSELF',
 'original_parent':ident,'new_branch_nodes':0,'maximum_new_rounds':5,'rounds':[],
 'prior':{'kind':'SOURCE_BOUND_PARENT_PLUS_FROZEN_GRID_COVERING_RECTANGLE','file':str(source),'sha256':digest(source),'parent_id':ident,'I_union':render(union),'pending_tiles':[40],'covered_tiles':[40],'deductions':'requires complete independently replayed original-parent induction'},
 'additional_predicate':{'original':'I','center_rectangle':render(union),'covered_tiles':[40],'pending_tiles':[40]},
 'terminal':{'kind':'proved_empty_parent_difference_intersection','effective_angles':render(effective),'propagated_positions':render(propagated),'witnesses':witnesses},
 'final_angles':render(angles),'final_positions':render(positions),'final_scalar':render(scalar),'final_differences':parent['final_differences'],
 'sources':{str(p):digest(p)for p in [Path(__file__),Path(K.__file__),Path(K.V.__file__)]},
 'additional_sources':{},'grid_status':'Frozen 8x8 cover unchanged; singleton tile40; no further subdivision','accepted_new_cells':0
}
out=ROOT/'rounded_support/fixed_i_interval_terminals'/(ident+'_covering_I_rectangle.json');out.parent.mkdir(exist_ok=True);assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'certificate':str(out),'sha256':digest(out),'witnesses':witnesses},indent=2))
