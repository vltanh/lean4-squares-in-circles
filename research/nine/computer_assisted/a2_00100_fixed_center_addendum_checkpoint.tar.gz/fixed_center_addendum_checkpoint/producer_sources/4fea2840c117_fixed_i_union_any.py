#!/usr/bin/env python3
"""One bounded induction on the smallest frozen-grid rectangle containing all pending tiles.
No further case split; proof may overlap already closed tiles.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import sys,json
from pathlib import Path
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'b_macro'))
import b_pass_v2 as B
M=B.M
PARENT=sys.argv[1]
SOURCE=Path(sys.argv[2]);OBJ=json.loads(SOURCE.read_text());assert OBJ['id']==PARENT;PATH=OBJ['path']
def box(xs):return tuple(tuple(F(s)for s in q)for q in xs)
ANGLES=box(OBJ['final_angles']);POS=box(OBJ['final_positions']);SCALAR=box(OBJ['final_scalar'])
DIFF={tuple(d['pair']):box(d['intervals'])for d in OBJ['final_differences']}
_,_,CHOICES=M.V.reconstruct(PATH)
GRID=ROOT/'global_nine_capacity/fixed_i_grid'/PARENT
SUMMARY=json.loads((GRID/'summary.json').read_text());PENDING=SUMMARY['open'];assert PENDING and SUMMARY['tiles_tested']==64
IX=[t//8 for t in PENDING];IY=[t%8 for t in PENDING];XMIN,XMAX=min(IX),max(IX);YMIN,YMAX=min(IY),max(IY)
xa,xb=POS[16];ya,yb=POS[17]
UNION=((xa+(xb-xa)*XMIN/8,xa+(xb-xa)*(XMAX+1)/8),(ya+(yb-ya)*YMIN/8,ya+(yb-ya)*(YMAX+1)/8))
COVERED=[ix*8+iy for ix in range(XMIN,XMAX+1)for iy in range(YMIN,YMAX+1)]
for tile in PENDING:
 d=json.loads((GRID/f'tile_{tile:02d}.json').read_text());assert d['status']=='OPEN'
 assert all(a<=c<=e<=b for (a,b),(c,e)in zip(UNION,box(d['I_box'])))

def initial(cell):
 positions=list(POS);positions[16],positions[17]=UNION
 state={'id':cell['id'],'path':PATH,'angles':ANGLES,'positions':tuple(positions),'choices':CHOICES,'scalar':SCALAR}
 prior={'kind':'SOURCE_BOUND_PARENT_PLUS_FROZEN_GRID_COVERING_RECTANGLE','file':str(SOURCE),'sha256':M.sha(SOURCE),'deductions':'requires complete v2 replay','parent_id':PARENT,'I_union':M.render(UNION),'pending_tiles':PENDING,'covered_tiles':COVERED}
 return state,prior,None

def collect(state,differences):
 merged=dict(DIFF)
 for pair,vals in differences.items():
  prior=merged[pair];merged[pair]=tuple((max(a,c),min(b,d))for(a,b),(c,d)in zip(prior,vals))
 return B.collect(state,merged)

if __name__=='__main__':
 M.initial=initial;M.collect=collect;M.HERE=HERE/'fixed_i_unions_any';M.HERE.mkdir(exist_ok=True);M.VERSION='n9_frozen_i_grid_covering_rectangle_five_round_v1'
 cell={'id':PARENT+'_covering_I_rectangle','path':PATH};dest=M.HERE/'results'/(cell['id']+'.json');assert not dest.exists()
 M.run(cell,5);record=json.loads(dest.read_text());record['scope']='COMPLETE_FROZEN_GRID_COVERING_RECTANGLE_ONLY; NOT_WHOLE_PARENT_BY_ITSELF'
 record['original_parent']=PARENT;record['additional_predicate']={'original':'I','center_rectangle':M.render(UNION),'covered_tiles':COVERED,'pending_tiles':PENDING}
 record['grid_status']='Frozen 8x8 cover unchanged; no further subdivision';record['accepted_new_cells']=0
 record['additional_sources']={str(p):M.sha(p)for p in [Path(__file__),Path(B.__file__),Path(B.P.__file__),Path(B.F.__file__),Path(B.A.__file__),Path(B.T.__file__),Path(B.S.__file__)]}
 dest.write_text(json.dumps(record,indent=2)+'\n');print('COMPLETE_FIXED_RECTANGLE_RESULT',PARENT,record['status'],flush=True)
