#!/usr/bin/env python3
"""Replay every complete original in this separately frozen addendum."""
import hashlib
import importlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    frozen = json.loads((HERE / 'SHA256_MANIFEST.json').read_text())
    assert frozen['schema'] == 'n9_fixed_center_addendum_immutable_files_v1'
    for name, expected in frozen['files'].items():
        assert sha(HERE / name) == expected, ('payload_file_changed', name)
    index = json.loads((HERE / 'portfolio_index.json').read_text())
    assert index['schema'] == 'n9_fixed_center_addendum_portfolio_v1'
    assert sha(HERE / 'original_register.json') == index['original_register_sha256']
    assert sha(HERE / 'previous_checkpoint_manifest.json') == index['previous_checkpoint_manifest_sha256']
    previous = json.loads((HERE / 'previous_checkpoint_manifest.json').read_text())
    assert previous['archive_sha256'] == index['previous_checkpoint_archive_sha256']
    assert previous['after'] == index['before']
    previous_ids = [entry['id'] for entry in previous['complete_originals']]
    assert previous_ids == index['previously_closed_original_ids']
    entries = index['entries']
    ids = [entry['id'] for entry in entries]
    assert entries and len(ids) == len(set(ids)) and not set(ids).intersection(previous_ids)
    out = HERE / 'new_reviews'
    out.mkdir(exist_ok=True)
    totals = {
        'prior_coordinate_deductions': 0,
        'whole_parent_new_deductions': 0,
        'rectangle_new_deductions': 0,
        'new_exact_deductions': 0,
        'printed_rows_checked': 0,
        'complete_terminal_domains': 0,
        'fixed_grid_tiles': 0,
        'static_terminal_domains': 0,
        'complete_rectangle_domains': 0,
    }
    reports = []
    for entry in entries:
        assert entry['kind'] == 'fixed_grid_union'
        for path_key, hash_key in [('certificate', 'certificate_sha256'), ('union', 'union_sha256'), ('checker', 'checker_sha256')]:
            assert sha(HERE / entry[path_key]) == entry[hash_key]
        assert entry['checker'] in ('verify_fixed_i_parent_v3.py', 'verify_fixed_i_parent_v4.py')
        verify = importlib.import_module(entry['checker'][:-3]).verify
        report = verify(HERE / entry['certificate'], HERE / entry['tiles'], HERE / entry['union'], HERE, out / Path(entry['accepted_report']).name)
        assert report['status'] == 'PASS_COMPLETE_ORIGINAL_PARENT' and report['id'] == entry['id']
        assert report['whole_original_parent_closed'] is True and report['whole_mask_closed'] is False
        assert report['all_64_tiles_accounted_for'] is True
        parent = report['parent_proof']
        totals['prior_coordinate_deductions'] += parent['prior_coordinate_deductions']
        totals['whole_parent_new_deductions'] += parent['new_deductions']
        totals['rectangle_new_deductions'] += report['lower_union_deductions']
        totals['new_exact_deductions'] += parent['new_deductions'] + report['lower_union_deductions']
        totals['printed_rows_checked'] += parent['printed_rows_checked'] + report['new_printed_rows_checked']
        totals['complete_terminal_domains'] += report['static_tiles_checked'] + 1
        totals['static_terminal_domains'] += report['static_tiles_checked']
        totals['complete_rectangle_domains'] += 1
        totals['fixed_grid_tiles'] += 64
        reports.append({'id': entry['id'], 'status': report['status'], 'report': str(Path('new_reviews') / Path(entry['accepted_report']).name)})
    summary = {
        'schema': 'n9_fixed_center_addendum_complete_replay_v1',
        'status': 'PASS_ALL_COMPLETE_ORIGINAL_PARENTS',
        'complete_original_ids': ids,
        'complete_original_count': len(ids),
        'previous_checkpoint_archive_sha256': index['previous_checkpoint_archive_sha256'],
        'before': index['before'],
        'after': {'closed': index['before']['closed'] + len(ids), 'open': index['before']['open'] - len(ids)},
        'whole_masks': index['whole_masks'],
        'totals': totals,
        'reports': reports,
        'unsupported_rules_accepted': False,
        'lean_lake_ci_run': False,
        'proof_kernel_verification': False,
        'whole_mask_closed': False,
    }
    (out / 'portable_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
    return summary


if __name__ == '__main__':
    main()
