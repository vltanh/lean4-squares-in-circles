# Fixed-center addendum: complete original cells

This separate packet adds complete original-cell proofs to the earlier
nine-proof original-center capacity checkpoint. The earlier checkpoint's
archive and manifest are preserved byte-for-byte. `portfolio_index.json`
identifies its digest, the previously closed IDs, and every additional
original proved by this addendum. The new IDs are checked to be distinct
from each other and from the preceding nine.

Extract this archive and run, using standard-library Python:

    python fixed_center_addendum_checkpoint/verify_all.py

Each original keeps its entire original path, all nine physical square
frames, all 36 original corner conditions, all 36 original physical pairs,
marked cones, the strict CD bit, and the strict-radius caller. The proof
starts with exact replay of its whole-parent bound induction. It then
uses a closed 8 by 8 I-center grid. Every tile outside one specified
rectangle is independently excluded, and one complete proof excludes
that entire rectangle. All shared faces remain covered.

For `positive-2c719a20ef7510de`, the rectangle contains all 48 tiles in
the rightmost six horizontal eighths. Three complete implication rounds
lead to a three-row contradiction whose coefficients cancel exactly.
The other 16 tiles are independently excluded.

For `negative-e0dbb1642ee58e72`, the rectangle is tile 40. It needs no
additional weighted bound round: physical propagation on the whole tile
contradicts two already proved parent pair-difference intervals. The
checker explicitly recomputes the rational disjoint intervals. The other
63 tiles are independently excluded.

See `proofs/A2_00100_TWO_MORE_FIXED_CENTER_COVER_CLOSURES.md` for the
physical hand/table assembly, exact rectangles, short terminals and
accounting. The frozen geometry and physical-row checker are copied
unchanged from the accepted checkpoint. The new v3 and v4 cover checkers
are separate immutable files. No discovery producer or optimizer is
imported by replay. All recorded source and additional-source hashes
are checked through portable mappings in `source_bindings.json`.

`SHA256_MANIFEST.json` binds all immutable payload files. Fresh replay
reports go to `new_reviews/`; saved accepted reports are in
`accepted_reports/`. The frozen original register contains the historical
174 CLOSED / 57 OPEN baseline. The manifest of the preceding nine-proof
checkpoint accounts for the transition to 183 CLOSED / 48 OPEN. This
addendum's independent, disjoint IDs provide the next exact increment.

The all-mask count remains 8 CLOSED and 24 OPEN. No whole-mask closure,
unrestricted theorem, Lean, Lake, CI or proof-kernel verification is
claimed.
