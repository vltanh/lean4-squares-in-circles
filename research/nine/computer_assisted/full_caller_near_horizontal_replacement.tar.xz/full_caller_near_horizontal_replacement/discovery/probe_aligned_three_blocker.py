#!/usr/bin/env python3
"""Untrusted exact-real discovery for a proposed aligned three-blocker lemma."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / 'aligned_three_blocker_probe'
Z3 = HERE / 'solver_dependencies/bin/z3'


def main():
    OUT.mkdir(exist_ok=False)
    definitions = '''(set-option :timeout 45000)
(set-logic QF_NRA)
(declare-const a Real)
(declare-const b Real)
(declare-const beta Real)
(declare-const x Real)
(declare-const y Real)
(declare-const v Real)
(assert (>= a 0))
(assert (>= beta 0))
(assert (<= beta a))
(assert (= (+ (* a a) (* b b)) 1))
(assert (or (= b beta) (= b (- beta))))
(define-fun h () Real (/ (+ a beta) 2))
(define-fun r () Real (/ (+ 1 a beta) 2))
(assert (and (>= v 0) (<= v (/ 1 8))))
; D=(1,0), X=(0,v), G=(1/2,-1), all aligned unit squares.
; C retains its original frame and strict weak forward cone to D.
(assert (>= (- 1 x) y))
(assert (>= (- 1 x) (- y)))
(assert (< (- 1 x) (+ h (/ 1 2))))
(define-fun separated ((dx Real) (dy Real)) Bool
  (or (>= dx (+ h (/ 1 2))) (<= dx (- (+ h (/ 1 2))))
      (>= dy (+ h (/ 1 2))) (<= dy (- (+ h (/ 1 2))))
      (>= (+ (* a dx) (* b dy)) r)
      (<= (+ (* a dx) (* b dy)) (- r))
      (>= (+ (* (- b) dx) (* a dy)) r)
      (<= (+ (* (- b) dx) (* a dy)) (- r))))
(assert (separated (- 1 x) (- y)))
(assert (separated (- x) (- v y)))
(assert (separated (- (/ 1 2) x) (- (- 1) y)))
; Necessary contained-incircle bounds, not replacement physical predicates.
(assert (>= (+ (* (- 1 x) (- 1 x)) (* y y)) 1))
(assert (>= (+ (* x x) (* (- y v) (- y v))) 1))
(assert (>= (+ (* (- x (/ 1 2)) (- x (/ 1 2))) (* (+ y 1) (+ y 1))) 1))
(check-sat-using (then simplify solve-eqs nlsat))
(get-info :reason-unknown)
(get-info :all-statistics)
'''
    source = OUT / 'FULL_ORIGINAL_C_THREE_ALIGNED_BLOCKERS.smt2'
    source.write_text(definitions)
    before = sha256(source.read_bytes()).hexdigest()
    start = time.monotonic()
    result = subprocess.run([str(Z3), str(source)], capture_output=True, text=True, timeout=55)
    raw = OUT / 'RAW_SOLVER_OUTPUT.txt'
    raw.write_text(result.stdout + result.stderr)
    assert sha256(source.read_bytes()).hexdigest() == before
    report = dict(status='DISCOVERY_ONLY_NOT_A_CERTIFICATE',
                  first_line=result.stdout.splitlines()[0] if result.stdout else '',
                  returncode=result.returncode, seconds=time.monotonic()-start,
                  original_physical_square_C_retained=True,
                  all_four_owned_axes_and_both_chiralities_retained=True,
                  equality_contacts_retained=True, strictly_weak_CD_retained=True,
                  specification_sha256=before,
                  raw_output_sha256=sha256(raw.read_bytes()).hexdigest(),
                  solver_sha256=sha256(Z3.read_bytes()).hexdigest(),
                  producer_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                  new_original_cells=0, new_masks=0)
    (OUT / 'DISCOVERY_REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
