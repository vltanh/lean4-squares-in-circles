#!/usr/bin/env python3
"""Portable exact companion for the reviewed full-caller conditional theorem."""
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
HAND_SHA = '3b3164cccab5bf09401eb2c3d8e56ac5dfdc9fc6bccb8a0e9a1d9390c188d7f1'
CHECKER_SHA = 'de255bcd67bab36e291e09fe690fceb49bd7072350a8788b2f6077cfebe086ab'
REVIEW_SHA = '08dc39539840ecad57aa19d08944bb7bd72c503033e4248b57f71e24fff89cd8'
REVIEWER_SHA = '4745c12d8c7df8039332d01c745588a56fc4efe5b65938bdbd1d71cbdfb35ff7'


def main():
    assert __debug__
    raw = (HERE / 'SHA256_MANIFEST.json').read_bytes()
    manifest = json.loads(raw)
    inventory = manifest['immutable_inputs']
    def unchanged():
        assert (HERE / 'SHA256_MANIFEST.json').read_bytes() == raw
        for name, expected in inventory.items():
            path = (HERE / name).resolve()
            assert path.is_relative_to(HERE)
            assert sha256(path.read_bytes()).hexdigest() == expected, name
    unchanged()
    for name in ('verify_all.py', 'check_aligned_three_blocker.py',
                 'FULL_CALLER_NEAR_HORIZONTAL_REPLACEMENT_HAND_PROOF.md',
                 'INDEPENDENT_PHYSICAL_AND_ARITHMETIC_REVIEW.json'):
        assert name in inventory
    assert inventory['FULL_CALLER_NEAR_HORIZONTAL_REPLACEMENT_HAND_PROOF.md'] == HAND_SHA
    assert inventory['check_aligned_three_blocker.py'] == CHECKER_SHA
    assert inventory['INDEPENDENT_PHYSICAL_AND_ARITHMETIC_REVIEW.json'] == REVIEW_SHA
    assert inventory['review_inputs/review_aligned_three_blocker.py'] == REVIEWER_SHA
    accepted_review = json.loads((HERE / 'INDEPENDENT_PHYSICAL_AND_ARITHMETIC_REVIEW.json').read_text())
    assert accepted_review['status'] == 'PASS_CONTINUOUS_BLOCKER_AND_FULL_CALLER_ATTACHMENT'
    assert accepted_review['hand_sha256'] == HAND_SHA
    assert accepted_review['author_companion_sha256'] == CHECKER_SHA
    expected_hands = (
        'WEAK_OUTER_NUMERIC_NEAR_HORIZONTAL_REPLACEMENT_ROW_HAND_TERMINAL.md',
        'GLOBAL_OUTER_LINK_EXTRACTION_REPLACEMENT_ROW_INDEPENDENT_REVIEW.md',
        'PHYSICAL_TWO_SQUARE_CAP_SUPPORT_AND_UNRESTRICTED_FOUR_PLUS_THREE_CHAINS_2026_10_31.md',
        'UNIVERSAL_MAIN_ENDPOINT_TILT_TOLL.md', 'SHARP_SMALL_MAIN_ENDPOINT_TILT_TOLL.md')
    for name in expected_hands:
        assert 'inherited_hand_inputs/' + name in inventory
    spec = importlib.util.spec_from_file_location('local_aligned_blocker_exact_checker',
                                                 HERE / 'check_aligned_three_blocker.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert Path(module.__file__).resolve() == HERE / 'check_aligned_three_blocker.py'
    result = module.verify()
    assert result['status'] == 'PASS_EXACT_BLOCKER_ARITHMETIC_AND_ESCAPE_ROWS'
    assert result['polynomial_identities'] == 6
    assert result['independently_expanded_escape_rows'] == 16
    assert result['complete_optional_product_domains'] == 144
    assert result['new_original_cells'] == result['new_masks'] == 0
    assert accepted_review['literal_escape_rows'] == {
        label: [{k: row[k] for k in ('coefficients', 'rhs')} for row in rows]
        for label, rows in result['literal_escape_families'].items()}
    # Preserve the independently reviewed evaluator byte-for-byte. Only its
    # explicit input/output directory globals are routed inside this packet.
    review_spec = importlib.util.spec_from_file_location('local_independent_blocker_reviewer',
                                                        HERE / 'review_inputs/review_aligned_three_blocker.py')
    reviewer = importlib.util.module_from_spec(review_spec)
    review_spec.loader.exec_module(reviewer)
    assert Path(reviewer.__file__).resolve() == HERE / 'review_inputs/review_aligned_three_blocker.py'
    replay_dir = HERE / 'review_replay'
    replay_dir.mkdir(exist_ok=True)
    reviewer.PACKET = HERE
    reviewer.HERE = replay_dir
    reviewer.main()
    review_report = json.loads((replay_dir / 'FULL_CALLER_ALIGNED_BLOCKER_INDEPENDENT_REVIEW.json').read_text())
    for key, value in accepted_review.items():
        if key != 'inherited_hand_sha256':
            assert review_report[key] == value, key
    assert {Path(name).name: value for name, value in review_report['inherited_hand_sha256'].items()} == {
        Path(name).name: value for name, value in accepted_review['inherited_hand_sha256'].items()}
    for name, expected in review_report['inherited_hand_sha256'].items():
        path = Path(name).resolve()
        assert path.is_relative_to(HERE) and sha256(path.read_bytes()).hexdigest() == expected
    inherited = subprocess.run([sys.executable, '-B', '-S', str(HERE / 'inherited_row_arithmetic.py')],
                               cwd=HERE, check=True, capture_output=True, text=True)
    inherited_report = json.loads(inherited.stdout)
    assert inherited_report['status'] == 'PASS'
    assert inherited_report['epsilon'] == '1/8'
    assert inherited_report['q_minimum_squared_reserve'] == 188
    assert inherited_report['sharp_toll_endpoint_squared_reserves'] == [6270736, 773606]
    assert inherited_report['four_beta_endpoint_squared_reserve'] == 10586
    unchanged()
    report = dict(
        schema='full_caller_near_horizontal_replacement_exact_companion_v1',
        status='PASS_REVIEWED_CONDITIONAL_FULL_CALLER_TERMINAL',
        source_manifest_sha256=sha256(raw).hexdigest(), immutable_inputs=len(inventory),
        hand_sha256=HAND_SHA, independent_arithmetic_checker_sha256=CHECKER_SHA,
        exact_companion=result, inherited_row_arithmetic=inherited_report,
        independent_exact_companion_replayed=True, independent_review_sha256=REVIEW_SHA,
        independent_evaluator_sha256=REVIEWER_SHA,
        continuous_geometric_coverage='Bound hand proof, including independent physical review',
        all_frozen_inputs_rehashed=True,
        conditional_callers=['001/00', '011/00'], reversal_callers=['100/00', '110/00'],
        all_nine_originals_retained=True, all_closed_guard_faces_retained=True,
        untrusted_solver_probe_used_for_acceptance=False,
        complete_original_exclusions=0, complete_mask_exclusions=0,
        lean_lake_ci_run=False)
    (HERE / 'COMPLETE_REPLAY.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ('exact_companion', 'inherited_row_arithmetic')}, indent=2))


if __name__ == '__main__':
    main()
