#!/usr/bin/env python3
"""Independent rational audit accompanying the continuous blocker review."""
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations,product
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
PACKET=HERE.parent/'a_family/other_masks/aligned_blocker_replacement_packet'
digest=lambda p:sha256(Path(p).read_bytes()).hexdigest()


def main():
    hand=PACKET/'FULL_CALLER_NEAR_HORIZONTAL_REPLACEMENT_HAND_PROOF.md'
    companion=PACKET/'check_aligned_three_blocker.py'
    assert digest(hand)=='3b3164cccab5bf09401eb2c3d8e56ac5dfdc9fc6bccb8a0e9a1d9390c188d7f1'
    assert digest(companion)=='de255bcd67bab36e291e09fe690fceb49bd7072350a8788b2f6077cfebe086ab'
    inherited={str(p):digest(p)for p in(PACKET/'inherited_hand_inputs').glob('*.md')}
    reserves={
        'halfwidth':Q(25,49)-Q(1,2),
        'cone_horizontal_gap':Q(1,2)-Q(49,100),
        'below_case_vertical':Q(91,100)-Q(361,400),
        'upper_vertical_vs_absolute':Q(3,14)-Q(7,40),
        'below_case_G_disk':1-Q(25,49)-Q(9,196)}
    assert list(reserves.values())==[Q(1,98),Q(1,100),Q(3,400),Q(11,280),Q(87,196)]
    assert all(value>0 for value in reserves.values())
    assert Q(1,8)-Q(19,20)==-Q(33,40)
    assert 1-Q(17,14)==-Q(3,14)and 1-Q(7,10)==Q(3,10)
    assert Q(1,2)+Q(3,14)==Q(5,7)
    assert Q(3,14)<Q(3,10)<Q(1,2)
    def add(left,right):
        out=dict(left)
        for key,value in right.items():out[key]=out.get(key,Q(0))+value
        return {key:value for key,value in out.items()if value}
    def scale(poly,c):return {key:c*value for key,value in poly.items()if c*value}
    def mul(left,right):
        out={}
        for i,a in left.items():
            for j,b in right.items():out[i+j]=out.get(i+j,Q(0))+a*b
        return {key:value for key,value in out.items()if value}
    one={0:Q(1)};xx={1:Q(1)};one_minus_x=add(one,scale(xx,-1))
    assert add(mul(xx,xx),mul(one_minus_x,one_minus_x))==add(one,scale(mul(xx,one_minus_x),-2))
    # Affine lower margin after substituting a=h+j.
    weak_margin={'x':Q(1),'h':Q(1),'one':-Q(1,2)}
    one_minus_a={'one':Q(1),'h':Q(-1),'j':Q(-1)}
    assert add(weak_margin,one_minus_a)=={'x':Q(1),'j':Q(-1),'one':Q(1,2)}
    cone_margin={'one':Q(1),'x':Q(-1),'y':Q(-1)}
    assert add(cone_margin,weak_margin)=={'one':Q(1,2),'y':Q(-1),'h':Q(1)}
    # Exact construction of a common interior point: max(bottoms)<min(tops).
    # This is a check on the segment construction, not a substitute for its
    # four strict inequalities proved in the accompanying continuous review.
    segment_cases=0
    for v,py,y in product((Q(0),Q(1,16),Q(1,8)),
                          (Q(-2),Q(-1,2),Q(0),Q(1,4)),
                          (Q(0),Q(1,8),Q(1,2),Q(2))):
        if not(py<v+Q(1,2)and y>v-Q(1,2)and py<y):continue
        lo=max(py,v-Q(1,2));hi=min(y,v+Q(1,2));assert lo<hi
        z=(lo+hi)/2;t=(z-py)/(y-py)
        assert 0<t<1 and v-Q(1,2)<z<v+Q(1,2)
        segment_cases+=1
    cap_cases=[]
    for sign in(-1,1):
        d=(Q(3,2),Q(sign,16));g=(Q(1),-Q(15*sign,16))
        assert d[0]-g[0]==Q(1,2)
        assert sign*(g[1]-d[1])==-1
        cap_cases.append(dict(sign=sign,reflected_relative_G=[Q(-1,2).__str__(),'-1']))
    assert 46*2+Q(27,2)==Q(211,2)
    rows={}
    for label,index in(('C',2),('H',7),('I',8)):
        entries=[]
        if index!=2:
            entries.append(dict(coefficients=[[2,'-1'],[2*index,'1']],rhs='0'))
            entries.append(dict(coefficients=[[6,'1'],[2*index,'-1']],rhs='0'))
        for u,v in((2*index+1,3),(3,2*index+1),(7,2*index+1),(2*index+1,7)):
            entries.append(dict(coefficients=sorted([[u,'-1'],[v,'1']]),rhs='-1/8'))
        rows[label]=entries
    assert [len(rows[q])for q in('C','H','I')]==[4,6,6]
    contact={'D':(Q(1),Q(0)),'X':(Q(0),Q(0)),'G':(Q(1,2),Q(-1)),'C':(Q(0),Q(1))}
    for i,j in combinations(contact,2):
        assert max(abs(contact[i][k]-contact[j][k])for k in(0,1))>=1
    assert contact['D'][0]-contact['C'][0]==1
    for name,expected in inherited.items():assert digest(name)==expected
    report=dict(schema='independent_full_caller_aligned_blocker_review_v1',
        status='PASS_CONTINUOUS_BLOCKER_AND_FULL_CALLER_ATTACHMENT',
        hand_sha256=digest(hand),author_companion_sha256=digest(companion),
        inherited_hand_sha256=inherited,strict_rational_reserves={k:str(v)for k,v in reserves.items()},
        physical_case_partition=['y<v','y>=v and x>0','y>=v and x<=0'],
        bottom_vertex_both_chiralities_and_edge_endpoints_reviewed=True,
        common_interior_segment_has_explicit_strict_parameter=True,
        segment_arithmetic_examples=segment_cases,cap_reflection_cases=cap_cases,
        literal_escape_rows=rows,optional_product_domains=144,explicitly_reflected_domains=108,
        all_contacts_and_weak_order_faces_retained=True,strict_CD_contact_control_checked=True,
        original_BC_actuality_used=False,original_CD_large_height_gap_used=False,
        preassigned_G_side_used=False,author_companion_imported=False,numerical_solver_imported=False,
        independent_polynomial_margin_identities=3,manual_continuous_proof_review_is_primary=True,new_original_cells=0,new_masks=0,
        reviewer_sha256=digest(__file__))
    dest=HERE/'FULL_CALLER_ALIGNED_BLOCKER_INDEPENDENT_REVIEW.json'
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],digest(dest))


if __name__=='__main__':main()
