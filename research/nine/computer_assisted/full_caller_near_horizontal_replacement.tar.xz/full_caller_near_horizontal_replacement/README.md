# Conditional full-caller near-horizontal replacement terminal

Run `python -B -S verify_all.py` after extracting this packet. The entry point
checks all frozen inputs before and after the exact arithmetic companion and
the inherited near-horizontal row's exact constant replay.

The complete proof is in
`FULL_CALLER_NEAR_HORIZONTAL_REPLACEMENT_HAND_PROOF.md`. Its new geometric
step is independently reviewed in
`INDEPENDENT_PHYSICAL_AND_ARITHMETIC_REVIEW.json`. The arithmetic companion
does not substitute for the continuous original-square proof.

For either unchanged original caller `001/00` or `011/00`, no unchanged extra
X in {H,I} can lie horizontally between B and D and within height 1/8 of both
B and D. This retains all original physical squares and strict comparisons.
Unlike the old original-001 attachment, it requires neither actual BC nor a
large normalized CD transverse gap nor a preselected G-height orientation.
Its equality obstruction uses the original aligned X,D,G and the unchanged
strict weak CD predicate. Reversal yields the corresponding other two uses.

For `011/00`, the direct X=C height terminal and both extra-X terminals give
the optional complete 4×6×6 closed escape cover recorded by the companion.
None of those surviving domains is declared excluded here. No original-cell,
fixed-mask, A.2, or global packing closure is claimed.

The small full-physical nonlinear discovery query returned UNKNOWN at its
declared 45-second limit. Its raw output is preserved under `discovery/`.
The verifier never uses the solver status as proof evidence.

No Lean, Lake or CI was run.
