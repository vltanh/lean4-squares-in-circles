#!/usr/bin/env python3
"""Exact arithmetic/coverage companion; continuous geometry is in the bound hand proof."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def add(*polynomials):
    answer = {}
    for poly in polynomials:
        for monomial, coefficient in poly.items():
            answer[monomial] = answer.get(monomial, F(0)) + coefficient
    return {m: c for m, c in answer.items() if c}


def scale(poly, coefficient):
    return {m: F(coefficient)*c for m, c in poly.items() if coefficient*c}


def multiply(left, right):
    answer = {}
    for a, ca in left.items():
        for b, cb in right.items():
            monomial = tuple(x+y for x, y in zip(a, b))
            answer[monomial] = answer.get(monomial, F(0)) + ca*cb
    return {m: c for m, c in answer.items() if c}


def verify():
    one = {(0,)*7: F(1)}
    a, b, x, y, v, h, j = [{tuple(int(k == i) for k in range(7)): F(1)}
                            for i in range(7)]
    def equal(left, right):
        assert not add(left, scale(right, -1)), (left, right)
    half = scale(one, F(1, 2))
    frame_h = scale(add(a, b), F(1, 2))
    frame_j = scale(add(a, scale(b, -1)), F(1, 2))
    equal(add(frame_h, frame_j), a)
    equal(add(frame_h, scale(frame_j, -1)), b)
    equal(add(multiply(frame_h, frame_h), multiply(frame_j, frame_j)),
          scale(add(multiply(a, a), multiply(b, b)), F(1, 2)))
    equal(add(multiply(x, x), multiply(add(one, scale(x, -1)), add(one, scale(x, -1)))),
          add(one, scale(multiply(x, add(one, scale(x, -1))), -2)))
    # Strict weak CD and h+j<=1 make the bottom vertex horizontally interior.
    equal(add(x, scale(j, -1), half),
          add(x, h, scale(half, -1), one, scale(h, -1), scale(j, -1)))
    # Cone, strict weakness and v>=0 put that vertex below X's open top face.
    equal(add(v, half, scale(y, -1), h),
          add(one, scale(x, -1), scale(y, -1), x, h, scale(half, -1), v))

    reserves = dict(
        halfwidth_rational_upper=F(5, 7)**2-F(1, 2),
        cone_gap_rational_lower=F(1, 2)-F(7, 10)**2,
        below_X_vertical_gap=F(91, 100)-F(19, 20)**2,
        vertical_absolute_comparison=F(3, 14)-F(7, 40),
        blocker_G_distance=1-(F(5, 7)**2+F(3, 14)**2))
    assert reserves == dict(halfwidth_rational_upper=F(1, 98),
                           cone_gap_rational_lower=F(1, 100),
                           below_X_vertical_gap=F(3, 400),
                           vertical_absolute_comparison=F(11, 280),
                           blocker_G_distance=F(87, 196))
    assert all(value > 0 for value in reserves.values())
    assert 1-F(17, 14) == -F(3, 14)
    assert 1-F(7, 10) == F(3, 10)
    assert F(3, 14) < F(3, 10) < F(1, 2)
    assert F(1, 8)-F(19, 20) == -F(33, 40)
    assert 1-F(17, 14) == -F(3, 14)
    assert 1-F(33, 40) == F(7, 40)
    assert F(1, 2)+F(3, 14) == F(5, 7)
    assert F(5, 7)**2+F(3, 14)**2 == F(109, 196)
    assert 2*46+F(27, 2) == F(211, 2)
    for sign in (-1, 1):
        dy = F(sign, 16)
        gy = -F(15*sign, 16)
        assert gy-dy == -sign
        # Reflect every original by this sign; G is then one unit below D.
        assert sign*(gy-dy) == -1
        assert F(3, 2)-1 == F(1, 2)
        assert F(3, 2)-F(1, 2) == 1
    assert F(7, 8) > 0 and F(9, 8) < 2

    # Independent literal affine escape families, all in lhs<=rhs convention.
    families = {}
    for label, original in (('C', 2), ('H', 7), ('I', 8)):
        entries = []
        if label != 'C':
            entries += [dict(kind='left_order', coefficients=[[2, '-1'], [2*original, '1']], rhs='0'),
                        dict(kind='right_order', coefficients=[[6, '1'], [2*original, '-1']], rhs='0')]
        for kind, positive, negative in (
            ('above_B', 2*original+1, 3), ('below_B', 3, 2*original+1),
            ('below_D', 7, 2*original+1), ('above_D', 2*original+1, 7)):
            coefficients = sorted([[positive, '-1'], [negative, '1']])
            entries.append(dict(kind=kind, coefficients=coefficients, rhs='-1/8'))
        families[label] = entries
    assert [len(families[k]) for k in ('C', 'H', 'I')] == [4, 6, 6]
    coverage_checks = equality_checks = 0
    values = (F(-1), F(-1, 8), F(0), F(1, 8), F(1))
    for label, original in (('C', 2), ('H', 7), ('I', 8)):
        for xx, bx_y, dx_y, xx_y in product(
                (F(-1, 2), F(0), F(1), F(2), F(5, 2)), values, values, values):
            ordered = 0 <= xx <= 2
            if label == 'C' and not ordered:
                continue  # Original BC/CD cones already prove C's horizontal order.
            positions = {2: F(0), 6: F(2), 2*original: xx,
                         3: bx_y, 7: dx_y, 2*original+1: xx_y}
            terminal = ordered and abs(xx_y-bx_y) <= F(1, 8) and abs(dx_y-xx_y) <= F(1, 8)
            membership = [sum(F(c)*positions[k] for k, c in entry['coefficients']) <= F(entry['rhs'])
                          for entry in families[label]]
            assert terminal or any(membership)
            if any(abs(gap) == F(1, 8) for gap in (xx_y-bx_y, dx_y-xx_y)):
                assert any(membership)
                equality_checks += 1
            coverage_checks += 1

    # A physical equality control proves the strict weak comparison is essential.
    # All four units are aligned. All contacts stay allowed.
    controls = {'D': (F(1), F(0)), 'X': (F(0), F(0)),
                'G': (F(1, 2), F(-1)), 'C': (F(0), F(1))}
    labels = list(controls)
    for i in range(len(labels)):
        for k in range(i+1, len(labels)):
            p, q = controls[labels[i]], controls[labels[k]]
            assert abs(p[0]-q[0]) >= 1 or abs(p[1]-q[1]) >= 1
    d = controls['D'][0]-controls['C'][0]
    assert d == abs(controls['D'][1]-controls['C'][1]) == 1
    assert d <= 1 and not d < 1

    return dict(
        status='PASS_EXACT_BLOCKER_ARITHMETIC_AND_ESCAPE_ROWS',
        scope='Arithmetic companion to the complete bound continuous hand proof',
        polynomial_identities=6, strict_rational_reserves={k: str(q) for k, q in reserves.items()},
        complete_geometric_cases=['C below X', 'C at or above X and x>0', 'C at or above X and x<=0'],
        cap_reflection_cases=2, independently_expanded_escape_rows=16,
        escape_family_sizes=[4, 6, 6], complete_optional_product_domains=144,
        explicitly_reflected_optional_product_domains=108,
        exact_escape_polarity_checks=coverage_checks, closed_threshold_face_checks=equality_checks,
        strict_comparison_negative_control='PASS_physical_equality_control_is_retained',
        literal_escape_families=families,
        original_square_frames_and_all_physical_contacts_retained=True,
        whole_original_closed=False, whole_mask_closed=False,
        new_original_cells=0, new_masks=0, lean_lake_ci_run=False,
        evaluator_sha256=sha256(Path(__file__).read_bytes()).hexdigest())


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
