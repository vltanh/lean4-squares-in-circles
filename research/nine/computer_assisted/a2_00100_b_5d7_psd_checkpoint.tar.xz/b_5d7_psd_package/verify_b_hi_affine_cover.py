#!/usr/bin/env python3
"""Independently replay the complete fixed H2x4 cover of one I rectangle."""
from pathlib import Path
from fractions import Fraction as F
import json
import sys
import time
import verify_b_affine_cover as A

HERE = Path(__file__).resolve().parent


def verify_hi_record(record, parent, J):
    tile = record['tile']
    assert len(tile) == 4 and record['parts'] == [4, 4, 2, 4]
    assert record['originals'] == [8, 7]
    ix, iy, hx, hy = tile
    assert all(type(index) is int for index in tile)
    assert 0 <= ix < 4 and 0 <= iy < 4 and 0 <= hx < 2 and 0 <= hy < 4
    conditional = list(parent['positions'])
    for axis, index, count in ((0, hx, 2), (1, hy, 4)):
        lo, hi = parent['positions'][14+axis]
        conditional[14+axis] = (lo+(hi-lo)*F(index, count), lo+(hi-lo)*F(index+1, count))
    assert record['h_rectangle'] == J.K.view(conditional[14:16])
    conditional_parent = dict(parent, positions=tuple(conditional))
    converted = dict(record, tile=ix*4+iy, ix=ix, iy=iy, target_original=8,
                     center_box=record['rectangle'])
    result = A.verify_tile(converted, conditional_parent, J)
    result['tile'] = list(tile)
    return result


def run(ident, ix, iy, parent, J, folder=None):
    started = time.monotonic()
    folder = Path(folder) if folder is not None else HERE / 'fixed_hi_grid_capacity' / ident / f'{ix}_{iy}'
    manifest_file = folder / 'manifest.json'
    manifest = json.loads(manifest_file.read_text())
    assert manifest['id'] == ident == parent['id'] and manifest['path'] == parent['path']
    assert manifest['I_tile'] == [ix, iy] and manifest['parts'] == [4, 4, 2, 4]
    assert manifest['originals'] == [8, 7]
    assert manifest['H_parent_rectangle'] == J.K.view(parent['positions'][14:16])
    prefix = J.local_source(manifest['parent_source'])
    assert A.digest(prefix) == manifest['parent_sha256']
    terminals = []
    files = {str(manifest_file): A.digest(manifest_file)}
    for tile in range(8):
        path = folder / f'tile_{tile:02d}.json'
        record = json.loads(path.read_text())
        assert record['tile'] == [ix, iy, tile//4, tile%4]
        result = verify_hi_record(record, parent, J)
        terminals.append(result)
        files[str(path)] = A.digest(path)
        print(ident, 'HI AFFINE TILE', result['tile'], result['status'], flush=True)
    opened = [r['tile'] for r in terminals if r['status'] == 'OPEN']
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy'))
    report = dict(schema='independent_B_fixed_HI_affine_cover_v1', id=ident,
                   status='PASS_COMPLETE_CONDITIONAL_I_RECTANGLE' if not opened else 'PASS_PARTIAL_HI_COVER_REMAINDER_EXPLICIT',
                   I_tile=[ix, iy], original_parent_path=parent['path'], h_parts=[2, 4],
                   tiles=terminals, remaining_HI_tiles=opened, source_sha256=files,
                   prefix_sha256=A.digest(prefix), new_original_cells=0, new_masks=0,
                   numerical_producer_or_optimizer_imported=False, seconds=time.monotonic()-started)
    return report


if __name__ == '__main__':
    ident = sys.argv[1]
    ix, iy = map(int, sys.argv[2:4])
    affine_report, parent = A.run(ident)
    J = sys.modules['verify_joint_original']
    report = run(ident, ix, iy, parent, J)
    (HERE / f'HI_AFFINE_REPLAY_{ident}_{ix}_{iy}.json').write_text(json.dumps(report, indent=2) + '\n')
    print(report['status'], report['remaining_HI_tiles'], flush=True)
