# B5d7: one complete original cell

This standalone packet excludes `negative-5d7c9f118e060b2a` of mask
`001/00`. It provides one original-cell closure and zero mask closures.

Run the complete independent exact replay:

```sh
python -B -S verify_all.py
```

The replay uses standard-library Python and no numerical optimizer.
All required ancestry bytes are included, with a strict audit hook
confining workspace reads to this directory.

The proof covers I by sixteen closed rectangles, and subdivides only
I(2,3) by a complete fixed H2×4 cover. Its twenty-three final rectangles
have thirteen affine rational contradictions, four exact interval
contradictions and six quadratic rational contradictions. It retains
all nine original physical unit squares, all36 corners and pairs, the
exact original path and the strict CD predicate.

`HAND_PROOF.md` explains the physical implications and complete table.
`COVER_TABLE.json` provides every final rectangle and a checked rational
reserve floor. `COMPLETE_REPLAY.json` is the combined independent report.
The complete central-arc theorem and its accepted review are included
under `ancestry/proofs/`, because one terminal uses its unconditional
all-nine radial lower bound.

The raw interrupted diagnostic and numerical-state bytes for one HI
run are preserved. A separate source-bound continuation proposed
rational square vectors from that state; the final exact certificate
and independent polynomial replay establish its contradiction. The
numerical data and numerical solver status are never proof premises.

Historical checkers and source-bound ancestor bytes remain unchanged.
The path-resolution adapter only maps historical names to explicitly
frozen files. No Lean, Lake or CI was run.
