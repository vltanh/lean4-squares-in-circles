#!/usr/bin/env python3
"""One fixed 2x4 H cover inside a specified member of the fixed I4x4 cover."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
from pathlib import Path
from fractions import Fraction as Q
import json
import sys
import time
import hashlib
import traceback
import fixed_i_grid_capacity as C

HERE = Path(__file__).resolve().parent
M = C.M


def run(ident, ix, iy):
    i_manifest_file = HERE / 'fixed_i_grid_capacity' / ident / 'manifest.json'
    i_manifest = json.loads(i_manifest_file.read_text())
    prefix = Path(i_manifest['parent_source'])
    assert C.sha(prefix) == i_manifest['parent_sha256']
    parent = json.loads(prefix.read_text())
    _, _, choices = M.V.reconstruct(parent['path'])
    original_pos = C.boxload(parent['final_positions'])
    base_positions = list(original_pos)
    for axis, index in enumerate((ix, iy)):
        assert 0 <= index < 4
        lo, hi = original_pos[16 + axis]
        base_positions[16 + axis] = (lo+(hi-lo)*index/4, lo+(hi-lo)*(index+1)/4)
    base = dict(id=ident, path=parent['path'], choices=choices,
                angles=C.boxload(parent['final_angles']), positions=tuple(base_positions),
                scalar=C.boxload(parent['final_scalar']))
    differences = {tuple(d['pair']): C.boxload(d['intervals']) for d in parent['final_differences']}
    out = HERE / 'fixed_hi_grid_capacity' / ident / f'{ix}_{iy}'
    out.mkdir(parents=True, exist_ok=True)
    sources = dict(i_manifest['sources'], **{str(Path(__file__).resolve()): C.sha(__file__)})
    manifest = dict(schema='fixed_B_I4_H2x4_cover_v1', id=ident, path=parent['path'],
                    parent_source=str(prefix), parent_sha256=C.sha(prefix), I_tile=[ix, iy],
                    originals=[8, 7], parts=[4, 4, 2, 4],
                    I_rectangle=M.render(base_positions[16:18]), H_parent_rectangle=M.render(original_pos[14:16]),
                    I_manifest_sha256=C.sha(i_manifest_file), sources=sources, new_original_cells=0)
    manifest_file = out / 'manifest.json'
    if manifest_file.exists():
        assert json.loads(manifest_file.read_text()) == manifest
    else:
        manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
    for tile in range(8):
        hx, hy = divmod(tile, 4)
        dest = out / f'tile_{tile:02d}.json'
        if dest.exists():
            continue
        positions = list(base_positions)
        for axis, index, count in ((0, hx, 2), (1, hy, 4)):
            lo, hi = original_pos[14 + axis]
            positions[14 + axis] = (lo+(hi-lo)*index/count, lo+(hi-lo)*(index+1)/count)
        state = dict(base, positions=tuple(positions))
        record = dict(schema='fixed_B_HI_affine_tile_v1', id=ident, parent_id=ident,
                      tile=[ix, iy, hx, hy], originals=[8, 7], parts=[4, 4, 2, 4],
                      rectangle=M.render(positions[16:18]), h_rectangle=M.render(positions[14:16]),
                      status='OPEN', original_closure_credit=0)
        start = time.monotonic()
        try:
            rows, absolute, terminal, pos, scalar, diffs, guards = M.collect(state, differences)
            if not terminal:
                rows += C.P4.rows(diffs)
                rows += C.AREA.generate_linear(diffs)
            record.update(rows=len(rows), propagated_positions=M.render(pos),
                          physical_scalar_intersection=M.render(scalar),
                          effective_differences=M.render_diff(diffs), three_square_guards=guards)
            if terminal:
                record.update(status='CANDIDATE_CLOSED', terminal=dict(
                    kind='exact_interval_or_accepted_terminal', label=terminal))
            else:
                h = M.highs(rows, len(absolute))
                h.run()
                record['solver_status'] = str(h.getModelStatus())
                if h.getModelStatus() == M.H.HighsModelStatus.kOptimal:
                    solution = h.getSolution()
                    record['phase_margin'] = float(solution.col_value[-1])
                    if solution.col_value[-1] > 1e-8:
                        weights = M.terms(solution.row_dual)
                        co, rhs = M.R.weighted_sum(rows, absolute, weights)
                        reserve = -rhs-sum(a*abs(v) for a, v in zip(absolute, co))
                        if reserve > 0:
                            record.update(status='CANDIDATE_CLOSED', terminal=dict(
                                kind='positive_exact_reserve', weights=weights, reserve=str(reserve),
                                rows=M.R.printed_rows(rows, {i for i, w in weights}),
                                absolute_variable_bounds=list(map(str, absolute)),
                                weighted_coefficients=list(map(str, co)), weighted_rhs=str(rhs)))
        except Exception:
            record['error'] = traceback.format_exc()
        record['seconds'] = time.monotonic()-start
        dest.write_text(json.dumps(record, indent=2) + '\n')
        print(ident, record['tile'], record['status'], record.get('phase_margin'), flush=True)
    records = [json.loads((out / f'tile_{i:02d}.json').read_text()) for i in range(8)]
    summary = dict(id=ident, I_tile=[ix, iy], parts=[2, 4],
                   candidate_closed=[i for i, r in enumerate(records) if r['status']=='CANDIDATE_CLOSED'],
                   open=[i for i, r in enumerate(records) if r['status']!='CANDIDATE_CLOSED'],
                   new_original_cells=0, independent_replay='PENDING')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    run(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]))
