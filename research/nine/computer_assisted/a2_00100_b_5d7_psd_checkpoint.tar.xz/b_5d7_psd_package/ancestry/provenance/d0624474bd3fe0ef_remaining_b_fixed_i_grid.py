#!/usr/bin/env python3
"""One predeclared 4x4 I-center cover of each unchanged original parent.

Discovery records only.  Each tile has one static exact dual test, no new
bound rounds and no adaptive subdivision.  Independent source-bound parent
induction and a complete cover proof are required before parent acceptance.
"""
import os
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[key] = '1'

import argparse
import hashlib
import json
import sys
import time
import traceback
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, '/workspace/scratch/29af4f6e10bf/current_proof')
import v3_whole_parent_pass as M
import planar_four_center_rows as P4
import square_area_moment_rows as AREA
TARGET_ORIGINAL = 8
REG = HERE.parent / 'pr11/research/nine/gates/A2_00100_FIXED_FRONTIER.json'
IDS = [c['id'] for c in json.loads(REG.read_text())['cells'] if c['status']=='OPEN' and c['sign']=='negative' and c['path'][1][-1]==0 and c['id'] not in ('negative-0e4fa3209b6f7b12','negative-6ad5eef3b91c1fbd')]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def boxload(value):
    return tuple(tuple(Q(y) for y in z) for z in value)


def run(parent_id):
    assert parent_id in IDS
    sources = [Path('/workspace/scratch/0220f3e5a56d/b_family/resumed'), Path('/workspace/scratch/0220f3e5a56d/b_family/continued'), Path('/workspace/scratch/29af4f6e10bf/b_macro/v2/results')]
    source = next(base / (parent_id+'.json') for base in sources if (base / (parent_id+'.json')).exists())
    obj = json.loads(source.read_text())
    assert obj['id'] == parent_id and obj['status'] == 'OPEN'
    assert 'final_positions' in obj and 'final_scalar' in obj
    path = obj['path']
    _, _, choices = M.V.reconstruct(path)
    base = {
        'id': parent_id, 'path': path,
        'angles': boxload(obj['final_angles']),
        'positions': boxload(obj['final_positions']),
        'choices': choices, 'scalar': boxload(obj['final_scalar']),
    }
    differences = {
        tuple(d['pair']): boxload(d['intervals'])
        for d in obj['final_differences']
    }
    x_index = 2 * TARGET_ORIGINAL
    y_index = x_index + 1
    xa, xb = base['positions'][x_index]
    ya, yb = base['positions'][y_index]
    outdir = HERE / 'fixed_i_grid_capacity' / parent_id
    outdir.mkdir(parents=True, exist_ok=True)
    source_paths = [Path(__file__),Path(P4.__file__),Path(AREA.__file__)] + [Path(x.__file__) for x in [M,M.K,M.V,M.R,M.A,M.D,M.S,M.P,M.Hh,M.Dh]]
    manifest = {
        'schema': 'n9_fixed_h_center_4x4_diagnostic_v1', 'id': parent_id,
        'scope': 'WHOLE_PARENT_COVER_CONDITIONAL_ON_SOURCE_BOUND_V2_INDUCTION',
        'parent_source': str(source), 'parent_sha256': sha(source), 'path': path,
        'target_original': TARGET_ORIGINAL, 'original_count': 9,
        'grid_size': [4, 4],
        'center_box': [[str(xa), str(xb)], [str(ya), str(yb)]],
        'coverage': 'All 16 products of consecutive closed equal quarters; shared faces retained',
        'original_predicates': 'All original parent predicates and all nine original squares retained',
        'adaptive_splits': 0, 'additional_bound_rounds_per_tile': 0,
        'static_dual_tests_per_tile': 1,
        'sources': {str(p): sha(p) for p in source_paths},
        'acceptance': 'Independent geometry, source-bound parent induction and complete cover proof required',
        'lean_lake_ci_run': False,
    }
    manifest_path = outdir / 'manifest.json'
    if manifest_path.exists():
        assert json.loads(manifest_path.read_text()) == manifest, 'Frozen source or domain changed'
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    for tile in range(16):
        ix, iy = divmod(tile, 4)
        xpos = (xa + (xb - xa) * ix / 4, xa + (xb - xa) * (ix + 1) / 4)
        ypos = (ya + (yb - ya) * iy / 4, ya + (yb - ya) * (iy + 1) / 4)
        center_box = M.render([xpos, ypos])
        dest = outdir / f'tile_{tile:02d}.json'
        if dest.exists():
            old = json.loads(dest.read_text())
            assert old['parent_id'] == parent_id and old['tile'] == tile
            assert old['target_original'] == TARGET_ORIGINAL
            assert old['center_box'] == center_box
            continue
        positions = list(base['positions'])
        positions[x_index] = xpos
        positions[y_index] = ypos
        state = dict(base, positions=tuple(positions))
        record = {
            'tile': tile, 'ix': ix, 'iy': iy,
            'target_original': TARGET_ORIGINAL, 'center_box': center_box,
            'status': 'OPEN', 'parent_id': parent_id,
        }
        started = time.monotonic()
        try:
            rows, absolute, terminal, pos, scalar, diffs, guards = M.collect(state, differences)
            if not terminal:
                rows += P4.rows(diffs)
                rows += AREA.generate_linear(diffs)
            record.update(
                rows=len(rows), propagated_positions=M.render(pos),
                physical_scalar_intersection=M.render(scalar),
                effective_differences=M.render_diff(diffs),
                three_square_guards=guards,
            )
            if terminal:
                record.update(status='CANDIDATE_CLOSED', terminal={
                    'kind': 'exact_interval_or_accepted_terminal', 'label': terminal,
                })
            else:
                h = M.highs(rows, len(absolute))
                h.run()
                status = h.getModelStatus()
                record['solver_status'] = str(status)
                if status == M.H.HighsModelStatus.kOptimal:
                    solution = h.getSolution()
                    phase = float(solution.col_value[-1])
                    record['phase_margin'] = phase
                    if phase > 1e-8:
                        weights = M.terms(solution.row_dual)
                        co, rhs = M.R.weighted_sum(rows, absolute, weights)
                        reserve = -rhs - sum(a * abs(v) for a, v in zip(absolute, co))
                        if reserve > 0:
                            record.update(status='CANDIDATE_CLOSED', terminal={
                                'kind': 'positive_exact_reserve', 'weights': weights,
                                'reserve': str(reserve),
                                'rows': M.R.printed_rows(rows, {i for i, w in weights}),
                                'absolute_variable_bounds': list(map(str, absolute)),
                                'weighted_coefficients': list(map(str, co)),
                                'weighted_rhs': str(rhs),
                            })
                        else:
                            record['rejected_numeric_reserve'] = str(reserve)
                    else:
                        record['diagnostic_relaxed_centers'] = solution.col_value[:18]
        except Exception:
            record['error'] = traceback.format_exc()
        record['seconds'] = round(time.monotonic() - started, 3)
        dest.write_text(json.dumps(record, indent=2) + '\n')
        with (outdir / 'run.log').open('a') as log:
            print(parent_id, tile, record['status'], record.get('phase_margin'), record['seconds'], file=log)
    records = [json.loads((outdir / f'tile_{i:02d}.json').read_text()) for i in range(16)]
    assert {r['tile'] for r in records} == set(range(16))
    closed = [r['tile'] for r in records if r['status'] == 'CANDIDATE_CLOSED']
    opened = [r['tile'] for r in records if r['status'] != 'CANDIDATE_CLOSED']
    result = {
        'id': parent_id, 'target_original': TARGET_ORIGINAL,
        'center_box': manifest['center_box'], 'tiles_tested': len(records),
        'candidate_closed': closed, 'open': opened,
        'all_16_candidate_closed': len(records) == 16 and not opened,
        'status': 'COMPLETE_CANDIDATE_PARENT_PROOF' if len(records) == 16 and not opened else 'OPEN_PARENT_NO_CLOSURE',
        'independent_replay_status': 'PENDING', 'new_cells_accepted': 0,
    }
    (outdir / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({
        'id': parent_id, 'target_original': TARGET_ORIGINAL,
        'closed': len(closed), 'open': opened,
        'complete': result['all_16_candidate_closed'],
    }), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--id', choices=IDS)
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--stop', type=int)
    args = parser.parse_args()
    for ident in ([args.id] if args.id else IDS[args.start:args.stop]):run(ident)
