#!/usr/bin/env python3
"""Recover universal rational square suggestions from a saved numerical dual.

This changes no physical premise. Every suggested square must be expanded
and every resulting positive row certificate must be checked independently.
The unfinished diagnostic record is retained verbatim as provenance.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
from pathlib import Path
from fractions import Fraction as Q
import json
import shutil
import sys
import numpy as np
import b_tile_model as BM


def main(folder):
    folder = Path(folder)
    path = folder / 'diagnostics.json'
    raw = folder / 'interrupted_diagnostics.json'
    assert not raw.exists()
    shutil.copy2(path, raw)
    record = json.loads(path.read_text())
    assert not record.get('new_rational_squares')
    rows, absolute, state, details, frozen = BM.collect(
        record['id'], tuple(record['tile']),
        None if record['h_tile'] is None else tuple(record['h_tile']))
    assert details['physical_state'] == record['physical_state']
    assert len(rows) == record['initial_rows'] and frozen['sources'] == record['sources']
    arrays = np.load(folder / 'complete_numerical_state.npz')
    assert len(arrays['linear_dual_normalized']) == len(rows)
    matrix = arrays['psd_dual_normalized']
    assert matrix.shape == (55, 55) and np.isfinite(matrix).all()
    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
    midpoint = np.array([float(Q(x)) for x in record['normalization_midpoint']])
    radius = np.array([float(Q(x)) for x in record['normalization_radius']])
    transform = np.eye(55)
    for i in range(54):
        transform[i+1, 0] = -midpoint[i] / radius[i]
        transform[i+1, i+1] = 1 / radius[i]
    squares = []
    for i, value in enumerate(eigenvalues):
        if value <= max(eigenvalues) * 1e-10:
            continue
        coefficients = eigenvectors[:, i] @ transform
        coefficients /= max(abs(coefficients))
        rational = [Q(round(float(x)*(1 << 24)), 1 << 24) for x in coefficients]
        squares.append(dict(index=len(frozen['squares']) + len(squares), coefficients=list(map(str, rational))))
    assert squares
    record.update(new_rational_squares=squares,
                  stop_reason='saved_numerical_dual_recovered_as_universal_square_suggestions',
                  complete_numerical_state_file='complete_numerical_state.npz',
                  complete_numerical_state_sha256=BM.J.sha(folder / 'complete_numerical_state.npz'),
                  recovery=dict(raw_diagnostics_sha256=BM.J.sha(raw),
                                producer=str(Path(__file__).resolve()), producer_sha256=BM.J.sha(__file__),
                                numerical_status_is_not_a_proof=True))
    path.write_text(json.dumps(record, indent=2) + '\n')
    print(record['id'], record['tile'], record['h_tile'], 'RECOVERED UNIVERSAL SQUARES', len(squares), flush=True)


if __name__ == '__main__':
    main(sys.argv[1])
