#!/usr/bin/env python3
"""Exact complete I4x4/H2x4 cover replay for one original B-family cell."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import sys
import time

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert __debug__, 'Assertions are part of this exact replay.'
    started = time.monotonic()
    inventory = json.loads((HERE / 'SHA256_MANIFEST.json').read_text())
    for name, expected in inventory['files'].items():
        path = (HERE / name).resolve()
        assert path.is_relative_to(HERE) and digest(path) == expected, ('frozen file changed', name)
    index = json.loads((HERE / 'INDEX.json').read_text())
    ident = index['id']
    assert index['schema'] == 'B_fixed_I_HI_packet_index_v1'
    assert index['originals'] == [8, 7] and index['parts'] == [4, 4, 2, 4]
    assert index['new_original_cells'] == 1 and index['new_masks'] == 0
    from verify_b_hi_active_psd_tiles import Checker
    checker = Checker(HERE, HERE / 'ancestry', HERE)
    import verify_b_affine_cover as affine
    import verify_b_hi_affine_cover as hi_affine
    affine_report, parent = affine.run(ident)
    assert affine_report['status'] == 'PASS_AFFINE_PARTIAL_COVER_REMAINDER_EXPLICIT'
    unresolved = [tuple(divmod(tile, 4)) for tile in affine_report['remaining_I_tiles']]
    addressed = [tuple(entry['tile']) for entry in index['psd_I_tiles']]
    addressed += [tuple(entry['I_tile']) for entry in index['hi_covers']]
    assert sorted(addressed) == sorted(unresolved) and len(addressed) == len(set(addressed))
    outcomes = {tuple(divmod(entry['tile'], 4)): dict(entry) for entry in affine_report['tiles']}
    assert set(outcomes) == {(x, y) for x in range(4) for y in range(4)}
    psd_reports = []
    recovery_bindings = []

    def psd(entry, full_tile):
        filename = (HERE / entry['certificate']).resolve()
        assert filename.is_relative_to(HERE / 'data/psd')
        diagnostic_file = filename.with_name('diagnostics.json')
        diagnostic = json.loads(diagnostic_file.read_text())
        if 'recovery' in diagnostic:
            recovery = diagnostic['recovery']
            raw = filename.with_name('interrupted_diagnostics.json')
            numerical = filename.with_name('complete_numerical_state.npz')
            producer = checker.locate(recovery['producer'])
            assert digest(raw) == recovery['raw_diagnostics_sha256']
            assert digest(numerical) == diagnostic['complete_numerical_state_sha256']
            assert digest(producer) == recovery['producer_sha256']
            recovery_bindings.append(dict(tile=list(full_tile), raw_sha256=digest(raw),
                numerical_state_sha256=digest(numerical), recovery_producer_sha256=digest(producer),
                numerical_values_not_used_as_proof_premises=True))
        report = checker.replay(filename)
        assert report['status'] == 'PASS_COMPLETE_PHYSICAL_TILE'
        assert report['id'] == ident and report['full_tile'] == list(full_tile)
        assert report['original_parent_path'] == parent['path']
        assert report['coordinate_divisions'] == ([4, 4] if len(full_tile)==2 else [4, 4, 2, 4])
        psd_reports.append(report)
        return dict(status='PASS_EXACT_PSD_RESERVE', reserve=report['reserve'], rows=report['terminal_rows'])

    for entry in index['psd_I_tiles']:
        tile = tuple(entry['tile'])
        assert len(tile) == 2 and outcomes[tile]['status'] == 'OPEN'
        outcomes[tile] = psd(entry, tile)
    hi_reports = []
    for cover in index['hi_covers']:
        coarse = tuple(cover['I_tile'])
        assert len(coarse) == 2 and outcomes[coarse]['status'] == 'OPEN'
        folder = (HERE / cover['folder']).resolve()
        assert folder.is_relative_to(HERE / 'data/fixed_hi_grid_capacity')
        report = hi_affine.run(ident, *coarse, parent, checker.J, folder=folder)
        hi_reports.append(report)
        assert [entry['tile'] for entry in cover['psd_tiles']] == report['remaining_HI_tiles']
        assert [entry['tile'] for entry in report['tiles']] == [list(coarse)+[hx,hy] for hx in range(2) for hy in range(4)]
        del outcomes[coarse]
        for entry in report['tiles']:
            tile = tuple(entry['tile'])
            assert tile not in outcomes
            outcomes[tile] = dict(entry)
        for entry in cover['psd_tiles']:
            tile = tuple(entry['tile'])
            assert len(tile) == 4 and tile[:2] == coarse and outcomes[tile]['status'] == 'OPEN'
            outcomes[tile] = psd(entry, tile)
    table = json.loads((HERE / 'COVER_TABLE.json').read_text())
    assert table['id'] == ident and table['originals'] == [8, 7] and table['parts'] == [4, 4, 2, 4]
    assert [tuple(entry['tile']) for entry in table['entries']] == sorted(outcomes)
    for entry in table['entries']:
        actual = outcomes[tuple(entry['tile'])]
        assert actual['status'] == entry['status'] and actual['rows'] == entry['rows']
        if 'reserve_floor' in entry:
            assert F(actual['reserve']) >= F(entry['reserve_floor']) > 0
        else:
            assert actual['label'] == entry['label']
    assert len(outcomes) == 16+7*len(index['hi_covers'])
    assert all(entry['status'].startswith('PASS_EXACT_') for entry in outcomes.values())
    assert not any(name in sys.modules for name in ('numpy', 'scipy', 'highspy'))
    counts = {name: sum(entry['status']==name for entry in outcomes.values()) for name in
              ('PASS_EXACT_POSITIVE_RESERVE', 'PASS_EXACT_INTERVAL', 'PASS_EXACT_PSD_RESERVE')}
    result = dict(schema='complete_B_original_I_HI_cover_v1', id=ident, path=parent['path'],
                  status='PASS_COMPLETE_ORIGINAL_PARENT', original_physical_squares=9,
                  original_corners=36, original_pairs=36, strict_CD_original_path_retained=True,
                  fixed_closed_rectangle_cover=[4, 4], h_cover_parts=[2, 4],
                  h_cover_count=len(index['hi_covers']), cover_rectangles=len(outcomes),
                  affine_terminals=counts['PASS_EXACT_POSITIVE_RESERVE'],
                  interval_terminals=counts['PASS_EXACT_INTERVAL'], psd_terminals=counts['PASS_EXACT_PSD_RESERVE'],
                  terminal_rows=sum(entry['rows'] for entry in outcomes.values()),
                  prefix_sha256=affine_report['prefix_sha256'], affine_report=affine_report,
                  hi_affine_reports=hi_reports, psd_reports=psd_reports,
                  diagnostic_recovery_bindings=recovery_bindings,
                  table_sha256=digest(HERE / 'COVER_TABLE.json'), new_original_cells=1,
                  new_masks=0, whole_mask_closed=False, source_bound_original_ancestor_replayed=True,
                  independent_exact_rows_and_nonnegative_weights=True,
                  numerical_producer_or_optimizer_imported=False, all_workspace_reads_confined_to_packet=True,
                  lean_lake_ci_run=False, seconds=time.monotonic()-started)
    (HERE / 'COMPLETE_REPLAY.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('id', 'status', 'cover_rectangles', 'terminal_rows',
          'new_original_cells', 'new_masks', 'seconds')}), flush=True)
    return result


if __name__ == '__main__':
    main()
