#!/usr/bin/env python3
"""Freeze the separate complete-attachment preparation without installation."""
if not __debug__:
    raise RuntimeError('Source freeze requires assertions.')
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def main():
    report_path=HERE/'fresh_controls/COMPLETE_ATTACHMENT_CONTROLS.json'
    report=json.loads(report_path.read_text())
    assert report['status']=='PASS_PREPARED_STRENGTHENED_STRICT011_COMPLETE_ATTACHMENT_CONTROLS'
    assert len(report['fixtures'])==5 and len(report['rejected_controls'])==15
    assert report['actual_LP_weighted_use_gate_passed']is False
    assert report['successful_conditional_terminal_use_exercised']is False
    for name,expected in report['source_hashes'].items():assert digest(HERE/name)==expected
    execution=json.loads((HERE/'CONTROL_EXECUTION.json').read_text())
    assert execution['observed_exit_code']==0 and execution['report_sha256']==digest(report_path)
    inventory={}
    for path in sorted(HERE.rglob('*')):
        assert not path.is_symlink()
        if not path.is_file():continue
        name=str(path.relative_to(HERE));assert name!='PREMISE_BINDINGS.json'
        assert path.suffix not in('.log','.pyc')
        inventory[name]=dict(bytes=path.stat().st_size,sha256=digest(path))
    binding=dict(schema='prepared_strict011_strengthened_complete_attachment_v1',
        status='FRESH_COMPLETE_ROOT_FIXTURES_PASS_REVIEW_AND_ACTUAL_USE_GATES_PENDING',
        mask='011/00',radius_mode='strict',root='full-strict-01100-representative-root-v1',
        complete_tree_schema='fresh_full_strict011_strengthened_representative_tree_v1',
        foundation_manifest_sha256='ac389f6184af6503294a13fb30c1da82e38d052a5d579bf43ccd4a0017b0485b',
        corner_layer_binding_sha256='efcf09c0494c1f36875533aeb3e4562173f84c49e8856de2d25b81eba781f778',
        universal021_application_binding_sha256='4c1fb0040f43281fd6e21bbece48d7293d0310a7341f490930c40ef51b689023',
        controls_sha256=digest(report_path),unmodified_walk_ast=True,
        active_driver_modified=False,actual_LP_weighted_use_gate_passed=False,
        successful_conditional_terminal_use_exercised=False,fresh_scalar_replay_performed=False,
        numerical_solver_called=False,original_cell_credit=0,whole_mask_credit=0,
        files=inventory)
    with (HERE/'PREMISE_BINDINGS.json').open('x')as stream:json.dump(binding,stream,indent=2,sort_keys=True);stream.write('\n')
    for name,entry in inventory.items():assert digest(HERE/name)==entry['sha256']
    print(json.dumps(dict(status=binding['status'],files=len(inventory),bytes=sum(x['bytes']for x in inventory.values()),
                         binding_sha256=digest(HERE/'PREMISE_BINDINGS.json'))))
if __name__=='__main__':main()
