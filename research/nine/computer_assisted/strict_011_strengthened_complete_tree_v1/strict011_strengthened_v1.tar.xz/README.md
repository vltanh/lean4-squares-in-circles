# Prepared strengthened strict-011 complete-tree verifier

This new verifier preparation connects the reviewed same-state four-product
corner rows and H/I+C universal `21/100` guards to the unchanged complete
root/4/8/2 proof walk. It uses a new tree schema and leaves the active driver
and all accepted sources unchanged.

The explicit source transformation is in `WRAPPER_TRANSFORMATION.json`.
The five core traversal/path/hash function ASTs are checked unchanged.
`COMPLETE_TREE_ATTACHMENT.md` states the induction, strict physical scope,
lazy fresh scalar gate and remaining actual-use obligations.

## Replay command

Supply every path explicitly, including the model and arithmetic workspace:

```sh
python -B -S /absolute/path/to/this-bundle/verify_strengthened_complete_tree.py \
  /absolute/path/to/new-schema-tree/manifest.json \
  /absolute/path/to/new-report.json \
  --workspace /absolute/path/to/foundation/dependencies/workspace \
  --model-folder /absolute/path/to/foundation/strict_011_representative_root_v1 \
  --corner-folder /absolute/path/to/strict011_four_product_layer_v2 \
  --guard-folder /absolute/path/to/strict011_universal_021_applications_v2 \
  --scalar-output-folder /absolute/path/to/a-new-scalar-output-folder
```

The report path and scalar output folder must not already exist. A scalar
folder is created only if a complete certified state actually satisfies a
conditional guard; that event always runs the accepted scalar checker fresh.
The old tree schema is rejected. Root documents, node files and all source
bindings are immutable inputs.

For fresh preparation controls, use `check_complete_attachment.py` with
explicit `--foundation`, `--corner-folder`, `--guard-folder` and a new
`--output-folder`. It creates five complete whole-root fixtures and damaged
controls. The positive corner weights in those fixtures are constructed
rational examples, with no numerical solve or actual-LP-use claim.

This preparation has no successful conditional terminal use and no fresh
scalar replay. It installs no driver and proves no whole mask. The real
positive-weight LP/full-ancestry gate, conditional-use gate and independent
complete-attachment review remain separate requirements.
