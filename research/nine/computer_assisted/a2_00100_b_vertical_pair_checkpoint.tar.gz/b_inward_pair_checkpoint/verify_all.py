#!/usr/bin/env python3
"""Complete exact replay and original-prefix map for the two B parents."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
HERE=Path(__file__).resolve().parent
IDS=['negative-e9388ab13ca6220a','negative-2ee3f4820947eb83']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def file(name):
 p=Path(name);assert not p.is_absolute()and '..'not in p.parts
 f=HERE/p;assert f.is_file()and f.resolve().is_relative_to(HERE);return f
def read(name):return json.loads(file(name).read_text())
def main():
 assert __debug__,'Exact checks require assertions enabled.'
 frozen=read('SHA256_MANIFEST.json');assert frozen['schema']=='n9_b_vertical_extra_pair_immutable_files_v1'
 for name,h in frozen['files'].items():assert sha(file(name))==h,('changed_file',name)
 ix=read('portfolio_index.json');assert ix['schema']=='n9_b_vertical_extra_pair_portfolio_v1'
 old=read('original_register.json');cur=read('input_current_register.json')
 assert sha(file('original_register.json'))==ix['original_register_sha256']and sha(file('input_current_register.json'))==ix['input_current_register_sha256']
 assert len(old['cells'])==len(cur['cells'])==231
 om={c['id']:c for c in old['cells']};cm={c['id']:c for c in cur['cells']};assert set(om)==set(cm)
 for ident in om:assert om[ident]['path']==cm[ident]['path']
 assert all(om[i]['status']=='OPEN'and cm[i]['status']=='OPEN'for i in IDS)
 assert sum(c['status']=='CLOSED'for c in cur['cells'])==193
 a8=read('preceding_A8_manifest.json');assert sha(file('preceding_A8_manifest.json'))==ix['preceding_A8_manifest_sha256']
 assert a8['status']=='PASS_ALL_COMPLETE_ORIGINAL_PARENTS'and a8['before']=={'closed':193,'open':38}and a8['after']==ix['before']=={'closed':195,'open':36}
 a8ids=[e['id']for e in a8['complete_originals']];assert len(a8ids)==2 and not set(a8ids).intersection(IDS)and all(cm[i]['status']=='OPEN'for i in a8ids)
 assert ix['after']=={'closed':197,'open':34}and ix['target_mask']=='001/00'and ix['strict_q']=='1105/256'and ix['whole_masks']=={'closed':8,'open':24}
 assert [e['id']for e in ix['entries']]==IDS
 from verify_joint_original import replay as replay_dual
 from verify_B_unit_frame_terminal import replay as replay_unit
 bindings=read('source_bindings.json');expected={};reports=[]
 for no,e in enumerate(ix['entries']):
  r=read(e['certificate']);assert sha(file(e['certificate']))==e['certificate_sha256']and sha(file(e['checker']))==e['checker_sha256']
  assert r['path']==cm[e['id']]['path']and r['new_branch_nodes']==0
  sources=dict(r['sources']);sources.update(r.get('additional_sources',{}))
  for name,h in sources.items():assert name in bindings and sha(file(bindings[name]))==h;expected[name]=h
  p=r['prior'];assert p['file']in bindings and sha(file(bindings[p['file']]))==p['sha256'];expected[p['file']]=p['sha256']
  inherited=read(e['inherited_open_state']);assert sha(file(e['inherited_open_state']))==e['inherited_open_state_sha256']==r['continuation_input']['sha256']
  assert inherited['status']=='OPEN'and len(inherited['rounds'])==5 and inherited['rounds']==r['rounds'][:5]
  report=(replay_dual if no==0 else replay_unit)(file(e['certificate']))
  assert report['status']=='PASS_COMPLETE_ORIGINAL_PARENT'and report['whole_original_parent_closed']is True and report['certificate_sha256']==e['certificate_sha256']
  for key in ['prior_coordinate_deductions','printed_rows_checked','terminal_rows','rounds']:assert report[key]==e[key]
  assert report['new_deductions']==e['new_exact_deductions']
  if no==0:assert Q(report['reserve'])>Q(2,125)
  else:assert Q(report['reserve'])==Q(1574587035,274877906944)>Q(1,200)
  saved=read(e['accepted_report']);assert sha(file(e['accepted_report']))==e['accepted_report_sha256']
  for k in ['id','status','certificate_sha256','prior_coordinate_deductions','new_deductions','printed_rows_checked','terminal_rows','reserve']:assert saved[k]==report[k]
  reports.append(report)
 assert set(expected)==set(bindings)
 sc=read(ix['scope_file']);children=[c for c in cur['cells']if c['path'][:len(sc['prefix'])]==sc['prefix']]
 assert len(sc['prefix'])==16 and sc['prefix'][-1]==['proxy',[7,8],[1,1]]and len(children)==sc['original_count']==7
 assert [c['id']for c in children]==sc['original_ids']and [c['status']for c in children]==sc['input_statuses']
 assert [c['id']for c in children if c['status']=='OPEN']==sc['newly_closed_originals']==IDS and sum(c['status']=='CLOSED'for c in children)==5
 totals={'prior_coordinate_deductions':sum(r['prior_coordinate_deductions']for r in reports),'new_exact_deductions':sum(r['new_deductions']for r in reports),'printed_rows_checked':sum(r['printed_rows_checked']for r in reports),'complete_terminal_domains':2,'new_internal_case_splits':0}
 assert totals=={'prior_coordinate_deductions':70,'new_exact_deductions':2595,'printed_rows_checked':5801,'complete_terminal_domains':2,'new_internal_case_splits':0}
 summary={'status':'PASS_ALL_COMPLETE_ORIGINAL_PARENTS','complete_original_ids':IDS,'complete_original_count':2,'before':ix['before'],'after':ix['after'],'whole_masks':ix['whole_masks'],'totals':totals,'existing_prefix':sc['prefix'],'existing_prefix_original_count':7,'completed_existing_domains':1,'whole_mask_closed':False,'lean_lake_ci_run':False,'terminal_adapter':'verify_B_unit_frame_terminal.py','raw_certificates_unchanged':True}
 out=HERE/'new_reviews';out.mkdir(exist_ok=True);(out/'portable_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
