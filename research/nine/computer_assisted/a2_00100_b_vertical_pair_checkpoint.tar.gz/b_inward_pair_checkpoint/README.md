# Complete existing B vertical-extra-pair routing

This packet excludes two unchanged B originals, negative-e9388ab13ca6220a
and negative-2ee3f4820947eb83. They complete one existing seven-original
prefix, whose other five registered originals were already closed.

Run with Python standard library after extraction:

    python b_inward_pair_checkpoint/verify_all.py

The e938 proof uses the unchanged accepted physical/arithmetic checker.
The 2ee proof preserves its raw empty-angle certificate and uses a small
explicit terminal adapter. The adapter replays nine complete rounds with
the unchanged checker, independently audits all 233 last-round proposals,
and obtains alpha_G<=489247/524288 and |beta_G|<=92115/262144. Their squared
sum is 273303319909/274877906944<1, contradicting G's exact unit frame.
No unproved final angle state is used or installed.

The proofs contain 70 prior coordinate deductions, 2,595 subsequent bound
deductions and 5,801 printed rows. There are two complete terminal domains
and no new internal case split. The second terminal's two scalar bounds
are distinct from the first terminal's 37-row positive rational sum.

All source snapshots, original paths, coordinate priors and inherited
OPEN states are included with exact hashes. Discovery code is retained
as provenance and is not imported by the independent replay. The baseline
174/57 register fixes original paths; the 193/38 input register is the
198c3d1 snapshot. The preceding A8 manifest accounts for two independent
closures before this B packet, so the combined accounting is 195/36 to
197/34. Neither packet closes the whole mask. Source-bound accepted
reports document prior checks, and all arithmetic is replayed anew.

No Lean, Lake, CI, human or proof-kernel verification is claimed.
