#!/usr/bin/env python3
"""Independent complete replay of a terminal original-unit-frame contradiction.

The accepted canonical checker replays every complete preceding round.
This adapter independently reconstructs and audits every proposal in the
last round, then checks alpha_G^2+|beta_G|^2<1 from two proved upper bounds.
The original raw empty-angle certificate is preserved without modification.
No producer, optimizer, or new physical-row implementation is imported.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib,sys,time
HERE=Path(__file__).resolve().parent
import verify_joint_original as J
K=J.K

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def box(values):return tuple(tuple(Q(x)for x in a)for a in values)

def replay(source):
 started=time.monotonic();source=Path(source);r=json.loads(source.read_text());ident=r['id']
 assert ident=='negative-2ee3f4820947eb83'
 assert r['scope']=='WHOLE_UNCHANGED_ORIGINAL_PARENT'and r['new_branch_nodes']==0
 assert r['status']=='CANDIDATE_CLOSED'and r['terminal']=={'kind':'proved_empty_original_angle_interval'}
 assert r['schema']=='b_macro_joint_frame_pointdisk_sharp_capacity_v2'and len(r['rounds'])==10
 rr=r['rounds'][-1];assert rr['round']==9
 # This generated view asserts only the nine complete rounds. Every one
 # is replayed from the unchanged original path by the accepted checker.
 prefix=json.loads(json.dumps(r));prefix.update(status='OPEN',rounds=r['rounds'][:-1],final_angles=rr['angles_before'],final_positions=rr['positions_before'],final_scalar=rr['scalar_before'],final_differences=rr['differences_before'])
 prefix.pop('terminal',None)
 out=HERE/'new_reviews';out.mkdir(exist_ok=True)
 prefix_path=out/(ident+'_prefix_only.json');prefix_path.write_text(json.dumps(prefix,indent=2)+'\n')
 prior,state=J.replay(prefix_path,allow_open=True,return_state=True)
 assert prior['status']=='PASS_CERTIFIED_PARENT_STATE_OPEN'and prior['rounds']==9
 angles,pos,sca,difference,choices=state['angles'],state['positions'],state['scalar'],state['differences'],state['choices']
 assert box(rr['angles_before'])==angles and box(rr['positions_before'])==pos and box(rr['scalar_before'])==sca and rr['differences_before']==K.diffview(difference)
 base,bounds,prop,phys,diffs,guards=K.rebuild(r['path'],angles,pos,choices,sca,difference)
 assert box(rr['propagated_positions'])==prop and box(rr['physical_scalar_intersection'])==phys and rr['effective_differences']==K.diffview(diffs)
 assert rr['three_square_guards'][:len(guards)]==guards and rr['absolute_variable_bounds']==list(map(str,bounds))
 rows,names=J.rows_for_record(rr,base,phys,diffs,angles)
 newpos=[list(x)for x in prop];newsca=[list(x)for x in phys];newdiff={p:[list(x)for x in v]for p,v in diffs.items()};used=set()
 for p in rr['proposals']:
  upper=K.audit_bound(rows,bounds,p);sg=p['sign'];key=p['key'];assert sg in(-1,1)
  if p['kind']=='scalar':
   assert type(key)is int and 0<=key<54 and p['objective']==[[key,sg]]
   target=newpos[key]if key<18 else newsca[key-18]
  else:
   assert p['kind']=='difference'and len(key)==3
   i,j,ax=key;assert 0<=i<j<9 and ax in(0,1)and p['objective']==[[2*j+ax,sg],[2*i+ax,-sg]]
   target=newdiff[i,j][ax]
  if sg==1:target[1]=min(target[1],upper)
  else:target[0]=max(target[0],-upper)
  used.update(i for i,w in p['weights'])
 assert used=={x['index']for x in rr['printed_rows']}
 pos_after=tuple(map(tuple,newpos));sca_after=tuple(map(tuple,newsca));diff_after={p:tuple(map(tuple,v))for p,v in newdiff.items()}
 assert all(a<=b for a,b in pos_after+sca_after)and all(a<=b for vv in diff_after.values()for a,b in vv)
 # The producer stopped before installing a terminal angle state. Its
 # saved centers/frames are the preceding state, while its saved
 # difference bounds are the freshly proved final-round intersections.
 assert box(r['final_angles'])==angles and box(r['final_positions'])==pos and box(r['final_scalar'])==sca and r['final_differences']==K.diffview(diff_after)
 assert not any(k in rr for k in('angles_after','positions_after','scalar_after','differences_after'))
 owner=6;al,au=sca_after[owner];zl,zu=sca_after[18+owner]
 assert 0<al<=au<=1 and 0<=zl<=zu<1
 assert au==Q(489247,524288)and zu==Q(92115,262144)
 squared_upper=au*au+zu*zu;reserve=1-squared_upper
 assert reserve>0
 # Original physical side frame: alpha>=0, z=|beta|, alpha^2+z^2=1.
 # Hence 1<=au^2+zu^2<1, a complete contradiction on this parent.
 report={'id':ident,'status':'PASS_COMPLETE_ORIGINAL_PARENT','whole_original_parent_closed':True,'bound_induction_branch_nodes':0,'prior_coordinate_deductions':prior['prior_coordinate_deductions'],'new_deductions':prior['new_deductions']+len(rr['proposals']),'rounds':10,'printed_rows_checked':prior['printed_rows_checked']+len(used),'terminal_kind':'exact_original_unit_frame_upper_norm_contradiction','terminal_original':owner,'terminal_rows':2,'terminal_physical_identities':1,'final_round_bound_deductions':len(rr['proposals']),'final_round_printed_rows':len(used),'alpha_upper':str(au),'absolute_beta_upper':str(zu),'squared_norm_upper':str(squared_upper),'reserve':str(reserve),'reserve_meaning':'1 minus alpha_upper squared minus absolute_beta_upper squared','center_cover':None,'unsupported_rules_accepted':False,'certificate_sha256':sha(source),'reviewer_sha256':sha(__file__),'canonical_checker_sha256':sha(J.__file__),'independent_rules_sha256':sha(HERE/'independent_all_rules.py'),'raw_certificate_unchanged':True,'all_complete_prefix_rounds_replayed':True,'all_terminal_round_bounds_replayed':True,'terminal_uses_no_unproved_angle_state':True,'whole_mask_closed':False,'human_or_kernel_verification':False,'seconds':time.monotonic()-started}
 (out/(ident+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True);return report
if __name__=='__main__':
 assert __debug__,'Exact checks require assertions enabled.'
 replay(sys.argv[1])
