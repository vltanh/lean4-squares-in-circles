#!/usr/bin/env python3
"""Portable exact checks for conditional sharp boundary theorems.

The continuous implication is in the included hand proofs. This runner
checks rational criteria, guard formulas and complete finite complements;
it does not claim to have covered an original cell or an entire mask.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
import hashlib,json,runpy,sys

HERE=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def audit(event,args):
    if event=='open'and isinstance(args[0],str):
        p=Path(args[0])
        if p.is_absolute()and str(p).startswith('/workspace/'):
            assert p.is_relative_to(HERE),('External workspace read forbidden',str(p))
sys.addaudithook(audit)
manifest=json.loads((HERE/'MANIFEST.json').read_text())
for path,value in manifest['files'].items():assert digest(HERE/path)==value,path
for path,record in json.loads((HERE/'SOURCE_BINDINGS.json').read_text()).items():
    assert digest(HERE/record['local'])==record['sha256'],path
sys.argv=['check_shared_strict_row_terminal.py',
          '--hand-proof',str(HERE/'ALL_SIGN_CORRELATED_CORNER_ROW_HAND_STRENGTHENING.md'),
          '--criterion',str(HERE/'weak_outer_correlated_corner_row_arithmetic.py'),
          '--state',str(HERE/'B462_BOUNDARY_CONTROL.json'),
          '--report',str(HERE/'ROOT_EXACT_REPORT.json')]
runpy.run_path(str(HERE/'check_shared_strict_row_terminal.py'),run_name='__main__')
r=json.loads((HERE/'ROOT_EXACT_REPORT.json').read_text())
assert r['status']=='PASS_CONDITIONAL_BOUNDARY_TERMINALS_AND_FINITE_COMPLEMENTS'
assert r['new_original_cells']==0 and r['new_masks']==0
assert sum(x['check_count']for x in r['exact_source_criteria'])==150
base=[tuple(map(F,p))for p in json.loads((HERE/'B462_BOUNDARY_CONTROL.json').read_text())['centers']]
swap=list(base);swap[1],swap[7]=swap[7],swap[1]
slide=list(base);slide[1]=(slide[1][0],slide[1][1]-F(1,4));slide[7]=(slide[7][0],slide[7][1]-F(1,4))
checks=[]
for name,centers in [('aligned',base),('B_H_swapped',swap),('slider_quarter',slide)]:
    assert all((x+F(s,2))**2+(y+F(t,2))**2<=F(1105,256)
               for x,y in centers for s,t in product((-1,1),repeat=2))
    assert all(max(abs(centers[j][a]-centers[i][a])for a in(0,1))>=1
               for i,j in combinations(range(9),2))
    marked=((0,1),(1,2),(2,3),(4,5),(5,6))
    assert all(centers[j][0]-centers[i][0]>=abs(centers[j][1]-centers[i][1])for i,j in marked)
    assert all(centers[j][0]-centers[i][0]>=1 for i,j in marked if(i,j)!=(2,3))
    assert centers[3][0]-centers[2][0]==1
    assert centers[3][1]-centers[2][1]>F(2,3)and centers[7][0]<=centers[8][0]
    checks.append(dict(name=name,corners_checked=36,pairs_checked=36,strict_weak_CD_satisfied=False))
assert not any(x in sys.modules for x in('numpy','scipy','highspy'))
result=dict(status='PASS_COMPLETE_CONDITIONAL_SHARP_BOUNDARY_THEOREMS',
            exact_rational_criterion_checks=150,signed_variation_checks=512,
            physical_closed_Q_controls=checks,
            explicit_complement_counts={'ABID':17,'AHID':18},
            source_manifest_sha256=digest(HERE/'MANIFEST.json'),
            exact_report_sha256=digest(HERE/'ROOT_EXACT_REPORT.json'),
            external_workspace_reads_allowed=False,numerical_optimizer_imported=False,
            continuous_hand_proofs_required=True,new_original_cells=0,new_masks=0,
            lean_lake_ci_run=False)
(HERE/'REPLAY_REPORT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
