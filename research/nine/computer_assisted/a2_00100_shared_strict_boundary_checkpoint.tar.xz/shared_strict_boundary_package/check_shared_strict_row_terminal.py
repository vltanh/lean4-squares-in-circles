#!/usr/bin/env python3
"""Exact specialization and guard checks for a conditional sharp terminal.

This does not prove an original-cell cover. The accepted continuous hand
theorem is a prerequisite. All arithmetic uses fractions; no optimization.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json

import shared_strict_row_terminal as S

HERE=Path(__file__).resolve().parent
DEFAULT_HAND=Path('/workspace/scratch/fee12ff81cbd/pr11/research/nine/ALL_SIGN_CORRELATED_CORNER_ROW_HAND_STRENGTHENING.md')
DEFAULT_CRITERION=Path('/workspace/scratch/29af4f6e10bf/current_proof/shared_capacity_three_b_v4/geometry/weak_outer_correlated_corner_row_arithmetic.py')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def exact_point_state(centers):
    values=[F(v) for xy in centers for v in xy]+[F(1)]*9+[F(0)]*18+[F(1,2)]*9
    return dict(positions=[(v,v)for v in values[:18]],
                scalar=[(v,v)for v in values[18:]],angles=[(F(0),F(0))]*9,differences={})

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--hand-proof',type=Path,default=DEFAULT_HAND)
    ap.add_argument('--criterion',type=Path,default=DEFAULT_CRITERION)
    ap.add_argument('--state',type=Path,default=HERE/'B462_BOUNDARY_CONTROL.json')
    ap.add_argument('--report',type=Path,default=HERE/'SHARED_ABID_STRICT_TERMINAL_CHECK.json')
    args=ap.parse_args()
    assert digest(args.hand_proof)=='0d233bddea414938482cb312519da061a546d26c4ee5a5bb83a14b48c178ed02'
    assert digest(args.criterion)=='b67785b140fbdd448bd43d720299491c96649be3fe76c08a4e73fe5725431c4e'
    spec=importlib.util.spec_from_file_location('accepted_correlated_arithmetic',args.criterion)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    criteria=[module.criterion(b,U,F(7,10))for b,U in S.PARAMETERS]
    assert all(r['status']=='PASS'for r in criteria)
    assert F(criteria[2]['parameters']['epsilon'])==F(58049449601280546655747607,327651328921587200064000000)

    # Independently expand all eight sign expressions for both physical rows.
    # Check exact equality to the absolute variation on rational examples in
    # every possible height-order sector, rather than duplicate the generator.
    signed_checks=0
    for row in S.ROWS:
        for heights in product((F(-2),F(-1,3),F(0),F(5,7)),repeat=4):
            z=[F(0)]*18
            for i,y in zip(row,heights):z[2*i+1]=y
            values=[-sum(c*z[k]for k,c in terms)for terms,rhs,name in S.signed_height_rows(F(1),row)]
            variation=sum(abs(heights[k+1]-heights[k])for k in range(3))
            assert max(values)==variation
            signed_checks+=1
        for b,U in S.PARAMETERS:
            escapes=S.complement_rows(b,U,row)
            assert len(escapes)==(17 if row==S.ROW else 18)
            # Coefficients at the explicit order boundaries identify the
            # correct physical original, including AHID's extra A/H order.
            for terms,rhs,name in escapes:
                if '_abs_beta_escape_'in name:
                    i=int(name.rsplit('_',1)[1]);assert terms==((36+i,F(-1)),)and rhs==-b

    prior=json.loads(args.state.read_text());state=prior['state']
    full=S.evaluate_any_guard(state)
    assert full['status']=='NO_SHARP_ROW_GUARD_IMPLIED'
    cylinder=copy.deepcopy(state)
    cylinder['positions'][16]=['1/4','3/4']
    for i in S.ROW:cylinder['positions'][2*i+1]=['-9/80','-1/80']
    for i in S.SEVEN:cylinder['angles'][i]=['-1/30','1/30']
    cylinder_result=S.evaluate_guard(cylinder)
    assert cylinder_result['status']=='PASS_SHARP_PHYSICAL_ROW_GUARD'
    assert cylinder_result['certified_variation_upper']=='3/10'

    centers=prior['centers']
    cases={}
    cases['original']=copy.deepcopy(centers)
    cases['B_H_swapped']=copy.deepcopy(centers)
    cases['B_H_swapped'][1],cases['B_H_swapped'][7]=cases['B_H_swapped'][7],cases['B_H_swapped'][1]
    cases['downward_slider_quarter']=copy.deepcopy(centers)
    cases['downward_slider_quarter'][1][1]='-5/16'
    cases['downward_slider_quarter'][7][1]='-21/16'
    case_results={name:S.evaluate_any_guard(exact_point_state(c))for name,c in cases.items()}
    assert all(r['status']=='PASS_SHARP_PHYSICAL_ROW_GUARD'for r in case_results.values())
    assert case_results['B_H_swapped']['row']==[0,7,8,3]
    assert case_results['downward_slider_quarter']['beta_bound']=='1/200'
    # The algebraic endpoint has U=(sqrt(849)-25)/8.  Its strict comparison
    # against 53/100 is equivalent to sqrt(849)<731/25.
    assert F(731,25)**2-F(849)==F(3736,625)>0
    pos,scalar,angles,diffs=S.unpack(state)
    order_reserve=pos[6][0]-pos[16][1]
    assert order_reserve==F(434432029724121,5000000000000000)>0
    result=dict(schema='shared_sharp_original_row_terminal_check_v2',
        status='PASS_CONDITIONAL_BOUNDARY_TERMINALS_AND_FINITE_COMPLEMENTS',
        full_B462_state=full,explicit_B462_boundary_cylinder=cylinder_result,
        exact_control_guards=case_results,exact_source_criteria=criteria,
        signed_variation_identities_checked=signed_checks,
        complement_domains_per_parameter_row={'ABID':17,'AHID':18},
        complement_domains_after_certified_I_less_D={'ABID':16,'AHID':17},
        certified_I_less_D_reserve=str(order_reserve),
        slider_endpoint_variation='(sqrt(849)-25)/8',
        slider_endpoint_strict_U_squared_reserve='3736/625',
        source_sha256={str(p):digest(p)for p in [args.hand_proof,args.criterion,Path(S.__file__),Path(__file__),args.state]},
        complete_original_closed=False,new_original_cells=0,new_masks=0)
    args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in('exact_source_criteria','full_B462_state','explicit_B462_boundary_cylinder','exact_control_guards','source_sha256')},indent=2))

if __name__=='__main__':main()
