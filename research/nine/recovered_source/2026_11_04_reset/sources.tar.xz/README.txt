PR #11 source recovery before intermediate-run cleanup

PATHS.json records every original path, byte count and SHA-256.
sources/<SHA-256> contains each distinct source or note exactly once.
This archive contains no bulk JSON proof runs, run logs or executable binaries.
Draft and historical sources are preserved without claiming accepted proof status.
Existing Git checkouts and accepted proof archives are retained by the main cleanup.
To recover a file, read its sources/<SHA-256> member, verify that hash,
and write it beneath a new chosen directory. Original paths are provenance.
